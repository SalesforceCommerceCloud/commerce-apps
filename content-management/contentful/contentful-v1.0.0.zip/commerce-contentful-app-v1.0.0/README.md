# Contentful Integration Commerce App

This package supplies **Contentful Content**, **Contentful Image** and
**Contentful Video** React components for SFNext. Embed them directly in storefront
routes or select content through Page Designer. The shared server helpers
`loadContentfulEntry()`, `loadContentfulImage()` and `loadContentfulVideo()` return
complete component data; render it with `<ContentfulContent data={content} />`,
`<ContentfulImage data={image} />` or `<ContentfulVideo data={video} />`.

See `docs/storefront-components.md` in the source repository for complete route
examples for each component, a combined page and optional video posters. Entries
use storefront renderer mappings; published image/video assets need no wrapper
entries or model mappings. Page Designer pickers require the site's Content Picker
permission. Register the supplied CSP contributor for image/video delivery.

For SFNext rendering, it requires an existing storefront (minimum declared version 2026.7.0),
`@salesforce/storefront-next-runtime` 1.1.0 or later for `EmbeddedSubtreeProvider`,
ECOM compatibility mode 22.7 or later, a configured B2C CLI, and a Contentful space
and Delivery API token.

For the full setup guide, mapping examples, CSP configuration and troubleshooting,
see the [source repository](https://git.soma.salesforce.com/michael-mcmahon/contentful-commerceapp).
The repository's root README and `docs/` are the main consumer documentation.

## SFRA cartridge

The same CAP also installs `plugin_contentful_sfra` alongside the shared
`int_contentful` and `bm_contentful` cartridges. On an SFRA site, configure the
Contentful connection in BM and use the **Contentful** Page Designer group.
Image/video components use the saved ECOM credentials immediately; entries use
`plugin_contentful_sfra/cartridge/scripts/contentful/config.js`, which returns
TypeScript-authored renderer mappings and a locale transformer. The starter entry mapping supports `sfnextDemoAboutUsCard`.

Published SFRA components emit uncached `ContentfulFragment-Entry/Image/Video` remote includes,
so the containing page can retain its cache policy. Customer controllers use
`getIncludeUrl(options)` from `plugin_contentful_sfra/cartridge/scripts/fragments` and
an ISML `<isinclude url="..." />`; see the source guide for the complete example.
Keep assembled HTML from being cached by a browser/CDN when fresh fragments are required.

Skip the SFNext overlay, MRT environment variables and Vite setup for SFRA.
The SFRA proof of concept supplies mapped content with bounded nested regions and the same image/video authoring
controls as SFNext. The separate `ContentfulPreview-Show` route supports authorized drafts and save-driven refresh. Read `docs/sfra.md` in the source
repository for configuration and sandbox installation verification requirements.

SFRA also includes the isolated `ContentfulPreview-Show` draft preview route.
Configure its Preview API key and shared `contentfulPreviewSecret` in BM.
The **Live Preview** section saves the secret for SFRA and shows a copyable
`CONTENTFUL_PREVIEW_SECRET` assignment after a new-value save for manual MRT setup. See
[SFRA Live Preview setup](https://git.soma.salesforce.com/michael-mcmahon/contentful-commerceapp/blob/main/docs/sfra-live-preview.md)
for preview URLs, mappings, CSP and optional inspector support.

## Install and configure (SFNext)

From this extracted package directory, run:

```sh
b2c cap install . --site-id YOUR_SITE_ID
```

If working from the source repository root, run `npm ci` and `npm run build`, then
use `npm exec -- b2c cap install ./dist/package --site-id YOUR_SITE_ID`. Install only the
assembled package or its ZIP, not the repository root.

1. Copy the complete `storefront-next/` overlay into your SFNext repository root,
   including `src/`, `vite-plugins/` and `.claude/` (include hidden
   directories). The included
   `.claude/skills/generate-contentful-mappings/` skill generates storefront
   mappings; `generate-contentful-models/` designs missing Contentful models from
   components and can create them when requested. Keep both skill folders together. Matching files are overwritten, including
   `src/extensions/contentful/config/model-mappings.json`. Restore your custom JSON
   from version control after copying and before validation/rebuilding.
   Repository users can run `npm run install:storefront -- /path/to/storefront`
   from the repository root. In the storefront run `pnpm add @contentful/live-preview@^4.10.26`
   (required to build the supplied route). Import `{ contentfulMappings }` from
   `'./vite-plugins/contentful-mappings'` in `vite.config.ts` and add
   `contentfulMappings()` to the existing `plugins` array. Vite is already a storefront
   dependency. Review/edit
   `src/extensions/contentful/config/model-mappings.json`, then regenerate the registry/cartridge metadata.
2. Register `createContentfulCspContributor` in the storefront's security middleware
   to allow Contentful image and video delivery, then build and deploy. See the
   repository's `docs/configuration.md` for registration and regional origins.
3. In Business Manager, select the site and open **Merchant Tools → Contentful →
   Configuration → Guided setup**, the recommended connection setup path. Expand
   **Contentful Setup** for the personal access token link. Enter a PAT and select
   its region; Guided setup makes no writes to Contentful. Connect, select a space, then a
   Delivery API key in that space, then one of its enabled
   environments/aliases. Choose **Validate and save connection**.
   See the repository's `docs/guided-setup/README.md` for PAT connection details.
   Manual edits remain available under **Connection details**; reference depth and
   retry/timeout settings are under **Storefront settings**. Grant Configuration
   permission to connection administrators.
4. Copy the MRT environment variables snippet displayed after saving and apply it
   to the associated deployed MRT environment. `CONTENTFUL_CDA_TOKEN` is required;
   local `.env` values and BM saves do not configure deployed MRT secrets. Non-secret
   settings synchronize from BM preferences. Configure entry-to-renderer mappings
   in storefront source code as described below, then build and deploy.
5. Optionally verify the integration with the built-in **Contentful Image** component:
   select a published image on a Page Designer page, save, publish and verify it on
   the storefront. No content model or renderer mapping is required. To enable picker
   access, open **Administration → Organization → Roles & Permissions → the authors'
   existing role → Business Manager Modules**. Click **Select Context**, choose
   **Sites**, select the merchant site and **Apply**. Under **Contentful**, enable
   **Content Picker** with full access and click **Update**. Confirm the authors belong
   to that role and already have Page Designer access, then reload Page Designer.
   Organization context and read-only access do not grant this site-specific custom
   action. Configuration access is separate and is not needed to use the picker.

Model mappings are storefront-owned JSON, validated at storefront startup/build and read on the server. The
copied file includes About Us and homepage demo mappings. There is no defaults fallback; `{}` disables all models. Every change
requires a storefront rebuild and deployment. The registered Vite plugin validates
structure and renderer registration on every fresh development startup and build; restart development after
mapping edits. These checks do not establish prop compatibility or deployment.
Non-secret connection settings synchronize from BM; tokens remain separately configured in each runtime.

Optional Contentful Live Preview includes an automatically discovered route at
`src/extensions/contentful/routes/_empty.contentful-preview.tsx`, `ContentPreviewProvider` and
server preview helpers, including a separate preview CSP contributor consumed by
the authorized preview middleware. Keep the media contributor registered separately and
follow the repository's `docs/live-preview.md` for middleware, routes and Contentful setup.

The overlay also supplies `/contentful-about-us` and `/contentful-home` under the
normal storefront shell. About Us preserves the existing contact form; the homepage
lets Contentful compose editorial and live-Commerce sections. Neither replaces an
ordinary storefront route. Provision models/entries/assets using the source
repository's `docs/contentful-demos.md`; CAP installation
alone does not create them. Preserve the matching demo mappings when restoring
custom mappings.
