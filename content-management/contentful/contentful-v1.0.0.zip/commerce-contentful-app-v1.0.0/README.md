# Contentful Integration Commerce App

This package supplies **Contentful Content**, **Contentful Image** and
**Contentful Video** React components for SFNext. Embed them directly in storefront
routes or select content through Page Designer. The shared server helpers
`loadContentfulEntry()`, `loadContentfulImage()` and `loadContentfulVideo()` return
complete component data; render it with `<ContentfulContent data={content} />`,
`<ContentfulImage data={image} />` or `<ContentfulVideo data={video} />`.

See the [direct embedding guide](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/main/docs/storefront-components.md) for complete route
examples for each component, a combined page and optional video posters. Entries
use storefront renderer mappings; published image/video assets need no wrapper
entries or model mappings. Page Designer pickers require the site's Content Picker
permission. Register the supplied CSP contributor for image/video delivery.

For SFNext rendering, it requires an existing storefront (minimum declared version 2026.7.0),
`@salesforce/storefront-next-runtime` 1.1.0 or later for `EmbeddedSubtreeProvider`,
ECOM compatibility mode 22.7 or later, a configured B2C CLI, and a Contentful space
and Delivery API token.

For the full setup guide, mapping examples, CSP configuration and troubleshooting,
see the [source repository](https://github.com/SalesforceCommerceCloud/commerce-app-contentful).
The repository's [quick start](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/main/README.md) and
[documentation](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/tree/main/docs) are the main consumer guides.

## Install and configure (SFNext)

From this extracted package directory, run:

```sh
b2c cap install . --site-id YOUR_SITE_ID
```

If working from the source repository root, run `npm ci` and `npm run build`, then
use `npm exec -- b2c cap install ./dist/package --site-id YOUR_SITE_ID`. Install only the
assembled package or its ZIP, not the repository root.

1. Copy the complete `storefront-next/` overlay into your SFNext repository root,
   including `src/`, `vite-plugins/` and `.claude/` (include hidden
   directories). The included
   `.claude/skills/generate-contentful-mappings/` skill generates storefront
   mappings; `generate-contentful-models/` designs missing Contentful models from
   components and can create them when requested. Keep both skill folders together. Matching files are overwritten, including
   `src/extensions/contentful/config/model-mappings.json`. Restore your custom JSON
   from version control after copying and before validation/rebuilding.
   Repository users can run `npm run install:storefront -- /path/to/storefront`
   from the repository root. In the storefront run `pnpm add @contentful/live-preview@^4.10.26`
   (required to build the supplied route). Import `{ contentfulMappings }` from
   `'./vite-plugins/contentful-mappings'` in `vite.config.ts` and add
   `contentfulMappings()` to the existing `plugins` array. Vite is already a storefront
   dependency. Review/edit
   `src/extensions/contentful/config/model-mappings.json`, then regenerate the registry/cartridge metadata.
2. Register `createContentfulCspContributor` in the storefront's security middleware
   to allow Contentful image and video delivery, then build and deploy. See the
   [configuration guide](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/main/docs/configuration.md) for registration and regional origins.
3. In Business Manager, select the site and open **Merchant Tools → Contentful →
   Configuration → Guided Setup**, the recommended connection setup path. Use
   the personal access token link in the instructions. Enter a PAT and select
   its region; Guided Setup makes no writes to Contentful. Connect, select a space, then a
   Delivery API key in that space, then one of its enabled
   environments/aliases. Choose **Save**.
   See the [Guided Setup guide](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/main/docs/guided-setup/README.md) for PAT connection details.
   Manual edits remain available under **Connected Environment**; reference depth and
   retry/timeout settings are under **Content Retrieval**. Grant Configuration
   permission to connection administrators.
4. Use the Guided Setup credential links to copy each key and set it in the
   native service credential **Password** field. Save in each editor; status updates automatically after page loads or popup
   closure. Native Services administration permission is required. Then copy
   the Managed Runtime Environment Variables snippet displayed after saving and apply it
   to the associated deployed MRT environment. `CONTENTFUL_CDA_TOKEN` is required;
   local `.env` values and BM saves do not configure deployed MRT secrets. Non-secret
   settings synchronize from BM preferences. Configure entry-to-renderer mappings
   in storefront source code as described below, then build and deploy.
5. Optionally verify the integration with the built-in **Contentful Image** component:
   select a published image on a Page Designer page, save, publish and verify it on
   the storefront. No content model or renderer mapping is required. To enable picker
   access, open **Administration → Organization → Roles & Permissions → the authors'
   existing role → Business Manager Modules**. Click **Select Context**, choose
   **Sites**, select the merchant site and **Apply**. Under **Contentful**, enable
   **Content Picker** with full access and click **Update**. Confirm the authors belong
   to that role and already have Page Designer access, then reload Page Designer.
   Organization context and read-only access do not grant this site-specific custom
   action. Configuration access is separate and is not needed to use the picker.

Model mappings are storefront-owned JSON, validated at storefront startup/build and read on the server. The
copied file includes About Us and homepage demo mappings. There is no defaults fallback; `{}` disables all models. Every change
requires a storefront rebuild and deployment. The registered Vite plugin validates
structure and renderer registration on every fresh development startup and build; restart development after
mapping edits. These checks do not establish prop compatibility or deployment.
Non-secret connection settings synchronize from BM; tokens remain separately configured in each runtime.

Optional Contentful Live Preview includes an automatically discovered route at
`src/extensions/contentful/routes/_empty.contentful-preview.tsx`, `ContentPreviewProvider` and
server preview helpers, including a separate preview CSP contributor consumed by
the authorized preview middleware. Keep the media contributor registered separately and
follow the [Live Preview guide](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/main/docs/live-preview.md) for middleware, routes and Contentful setup.
Set `CONTENTFUL_PREVIEW_SECRET` directly in each associated MRT environment to a
long random value distinct from Contentful API keys, and use the same value in
Contentful preview URLs. **Configuration → Live Preview** provides these instructions;
BM does not store or deploy this secret. Inspector and editor-origin preferences
synchronize to MRT.

The overlay also supplies `/contentful-about-us` and `/contentful-home` under the
normal storefront shell. About Us preserves the existing contact form; the homepage
lets Contentful compose editorial and live-Commerce sections. Neither replaces an
ordinary storefront route. Provision models/entries/assets using the
[demonstration setup guide](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/main/docs/contentful-demos.md); CAP installation
alone does not create them. Preserve the matching demo mappings when restoring
custom mappings.
