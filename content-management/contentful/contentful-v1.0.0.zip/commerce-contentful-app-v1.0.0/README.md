# Contentful Integration Commerce App

This package adds **Contentful Content**, **Contentful Image**, and **Contentful Video**
to an existing Salesforce Storefront Next storefront. Use them directly in routes or through
Page Designer. Entries use storefront renderer mappings; published image/video
assets need no wrapper entries or mappings.

See the [README requirements](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/README.md#requirements)
and [runtime compatibility](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/development.md#storefront-next-compatibility).
The installation steps below apply to an extracted package; use the
[quick start](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/README.md#quick-start)
for App Catalog or checkout-based installation.

## Install This Extracted Package

Run from this extracted, already-built package directory:

```sh
b2c cap install . --site-id YOUR_SITE_ID
```

1. Copy the complete `storefront-next/` overlay into the Storefront Next repository root,
   including `src/`, `vite-plugins/`, and hidden `.claude/` skill directories.
   Matching files are overwritten. Restore custom
   `src/extensions/contentful/config/model-mappings.json` from version control and
   review the diff before building. Keep both included skills with the storefront.
2. Install the SDK dependency from the
   [README quick start](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/README.md#quick-start).
   [Register `contentfulMappings()` and the media CSP contributor](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/storefront-next.md#configuration),
   configure mappings, regenerate the registry/cartridge metadata, then build and deploy.
3. Complete [Guided Setup](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/commerce-app.md#guided-setup)
   for the site. Set the indicated Business Manager service credential passwords and deploy the MRT
   environment-variable snippet; BM saves do not configure MRT secrets.
4. Check **Contentful → Status**, then select a published image in Page Designer,
   publish the page, and verify it on the storefront. Authors need the site's
   [Content Picker permission](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/commerce-app.md#grant-the-content-picker-permission).

## Guides

- [Commerce App](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/commerce-app.md)
- [Direct route embedding with server loaders and React components](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/storefront-components.md)
- [Model mappings and renderer authoring](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/model-mappings.md)
- [Live Preview](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/live-preview.md)
- [About Us and homepage demos](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/contentful-demos.md)
- [Troubleshooting](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/debugging.md)

The demo routes require Contentful models, entries, and assets provisioned separately;
CAP installation does not create them. For Live Preview credentials and middleware, follow the
[Live Preview setup](https://github.com/SalesforceCommerceCloud/commerce-app-contentful/blob/release/docs/live-preview.md#setup).
