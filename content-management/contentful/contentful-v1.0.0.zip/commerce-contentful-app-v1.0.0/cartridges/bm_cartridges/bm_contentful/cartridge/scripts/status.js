"use strict";
var Resource = require("dw/web/Resource");
var service = require("int_contentful/cartridge/scripts/services/cdaService");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/** Probe the configured API with stable status codes and localized, content-free display messages. */
function probe(site, preview) {
    var config = preview ? service.getPreviewConfig({ site: site }) : service.getConfig({ site: site });
    // Missing optional connection settings mean unconfigured, not a failed network probe.
    if (!config.spaceId || !config.token) {
        return {
            mode: Resource.msg(preview ? "mode.preview" : "mode.delivery", "contentfulManagement", null),
            state: "notConfigured",
            detail: Resource.msg("connection.missing", "contentfulManagement", null),
        };
    }
    var result = {
        mode: Resource.msg(preview ? "mode.preview" : "mode.delivery", "contentfulManagement", null),
        state: "unavailable",
        detail: Resource.msg("connection.unavailable", "contentfulManagement", null),
    };
    try {
        var response_1 = preview ? service.fetchPreviewContentTypes({ site: site }) : service.fetchContentTypes({ site: site });
        // Result is native; object is untrusted JSON and must demonstrate a collection response.
        if (response_1.ok && response_1.object && Array.isArray(response_1.object.items)) {
            result.state = "connected";
            result.detail = Resource.msg("connection.connected", "contentfulManagement", null);
        }
        else if (response_1.error === 401 || response_1.error === 403) {
            result.detail = Resource.msg("connection.denied", "contentfulManagement", null);
        }
        else if (response_1.error === 404) {
            result.detail = Resource.msg("connection.notFound", "contentfulManagement", null);
        }
        else if (response_1.error === 429) {
            result.detail = Resource.msg("connection.rateLimit", "contentfulManagement", null);
        }
        // Native Result.error is an integer, but framework failures use non-HTTP codes.
        if (!response_1.ok && response_1.error >= 100 && response_1.error <= 599) {
            result.detail = Resource.msgf("connection.http", "contentfulManagement", null, result.detail, response_1.error);
        }
    }
    catch (error) {
        diagnostics.log("warn", "management.probe_failed", { errorType: diagnostics.errorType(error) });
    }
    return result;
}
module.exports = { probe: probe };
