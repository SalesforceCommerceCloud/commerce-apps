"use strict";
var Site = require("dw/system/Site");
/** Resolve BM's selected merchant site, excluding its organization site and browser IDs. */
function getSelectedSite() {
    var current = Site.getCurrent();
    // Native getCurrent always returns a Site, including BM's organization site.
    var id = current.getID();
    return Site.getAllSites()
        .toArray()
        .some(function (candidate) { return candidate.getID() === id; })
        ? current
        : null;
}
module.exports = { getSelectedSite: getSelectedSite };
