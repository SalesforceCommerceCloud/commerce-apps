"use strict";
/** Read a fresh, non-secret Configuration model under the native site-specific module grant.
 * @output ContentfulManagement : Object
 */
/* exported execute */
var execute = function execute(pdict) {
    var configuration = require("bm_contentful/cartridge/scripts/configuration");
    pdict.ContentfulManagement = { csrf: null };
    if (!session.userAuthenticated ||
        request.httpMethod !== "GET" ||
        request.httpHeaders.get("x-requested-with") !== "XMLHttpRequest") {
        response.setStatus(403);
    }
    else {
        var site = require("bm_contentful/cartridge/scripts/site").getSelectedSite();
        pdict.ContentfulManagement = configuration.view(site);
        if (!site) {
            response.setStatus(400);
        }
    }
    configuration.respond(pdict.ContentfulManagement, response);
    return PIPELET_NEXT;
};
