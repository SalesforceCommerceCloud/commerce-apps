"use strict";
/** Standalone Script pipelet: BM authenticates and checks the picker module. */
/* exported execute */
var execute = function execute(pdict) {
    require("bm_contentful/cartridge/scripts/picker").sessionToken(request, response);
    return PIPELET_NEXT;
};
