/** Localized editor text arrives from the BM initializer; never infer language from Contentful data. */
(() => {
    "use strict";
    window.ContentfulLocalization = {
        /** Bind a dictionary and locale to one editor initialization. */
        create(config) {
            const dictionary = config.localization || {};
            const locale = config.locale || "en";
            const localeInfo = new Intl.Locale(locale);
            const direction = localeInfo.getTextInfo?.().direction ?? localeInfo.textInfo?.direction ?? "ltr";
            const plurals = new Intl.PluralRules(locale);
            /** Format numbers using the same locale as the BM UI messages. */
            function number(value, digits = 0) {
                return new Intl.NumberFormat(locale, {
                    minimumFractionDigits: digits,
                    maximumFractionDigits: digits,
                }).format(value);
            }
            /** Substitute numbered placeholders once, preserving punctuation, apostrophes and literal replacement values. */
            function text(key, ...values) {
                return (dictionary[key] ?? key).replace(/\{(\d+)\}/g, (placeholder, index) =>
                    values[index] === undefined ? placeholder : String(values[index]),
                );
            }
            return {
                locale,
                direction,
                number,
                text,
                /** Select a complete count message by CLDR plural category; untranslated categories fall back to other. */
                count(key, value) {
                    const categoryKey = `${key}.${plurals.select(value)}`;
                    return text(dictionary[categoryKey] === undefined ? `${key}.other` : categoryKey, number(value));
                },
            };
        },
    };
})();
