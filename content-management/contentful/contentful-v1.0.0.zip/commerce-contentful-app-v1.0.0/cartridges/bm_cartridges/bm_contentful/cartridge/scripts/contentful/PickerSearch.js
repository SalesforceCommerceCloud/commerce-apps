"use strict";
/** Standalone Script pipelet: BM authenticates and checks the registered module. */
/* exported execute */
var execute = function execute(pdict) {
    require("bm_contentful/cartridge/scripts/picker").search(request, response);
    return PIPELET_NEXT;
};
