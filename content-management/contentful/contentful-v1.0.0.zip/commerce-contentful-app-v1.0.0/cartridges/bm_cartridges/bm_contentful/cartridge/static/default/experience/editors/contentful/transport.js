/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** Shared browser-session transport for the isolated entry and image editor iframes. */
(() => {
    "use strict";
    /**
     * Snapshot same-origin HTTPS BM endpoints and the token parameter name for one editor
     * configuration. Remove stale query tokens and use window.origin for sandboxed srcdoc.
     * Return fixed initialization guidance instead of throwing when configuration is invalid.
     */
    function readEndpoints(config) {
        const messages = window.ContentfulLocalization.create(config);
        if (config.error) {
            return { error: config.error };
        }
        if (!config.searchUrl || !config.sessionUrl || !config.csrf?.name) {
            return { error: messages.text("initError") };
        }
        try {
            const endpoint = new URL(config.searchUrl);
            const sessionEndpoint = new URL(config.sessionUrl);
            if (
                endpoint.protocol !== "https:" ||
                endpoint.origin !== window.origin ||
                sessionEndpoint.origin !== endpoint.origin ||
                sessionEndpoint.protocol !== "https:"
            ) {
                throw new Error("Invalid BM endpoint");
            }
            endpoint.searchParams.delete(config.csrf.name);
            sessionEndpoint.searchParams.delete(config.csrf.name);
            return {
                error: "",
                searchUrl: endpoint.toString(),
                sessionUrl: sessionEndpoint.toString(),
                csrfName: config.csrf.name,
                origin: endpoint.origin,
            };
        } catch {
            return {
                error: messages.text("originError"),
            };
        }
    }

    /**
     * Obtain a fresh browser-session CSRF token, then POST lookup parameters using local
     * XHR. Validate response origin, JSON, pagination and any optional caller-specific item check before
     * resolving. Reject session/transport/payload failures with safe diagnostics, and honor
     * cancellation in either request stage. No token is cached, persisted or logged.
     */
    async function requestItems(endpoints, parameters, signal, validateItem) {
        if (endpoints.error) {
            throw new Error(endpoints.error);
        }
        // Page Designer deliberately deletes window.parent/top/frameElement.
        // A same-origin BM request obtains a token bound to the browser session.
        let csrf;
        try {
            const response = await fetch(endpoints.sessionUrl, {
                credentials: "same-origin",
                cache: "no-store",
                redirect: "error",
                signal,
                headers: { "X-Requested-With": "XMLHttpRequest" },
            });
            if (!response.ok || !response.headers.get("content-type")?.includes("application/json")) {
                throw new Error("Session unavailable");
            }
            csrf = await response.json();
            if (csrf.name !== endpoints.csrfName || typeof csrf.token !== "string" || !csrf.token) {
                throw new Error("Invalid session response");
            }
        } catch (error) {
            if (error.name === "AbortError") {
                throw error;
            }
            console.error("contentful.editor.request_failed", { stage: "session" });
            throw new Error("Session unavailable", { cause: error });
        }
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            /** Forward caller cancellation to the active XHR. */
            const abort = () => xhr.abort();
            /** Remove abort wiring and resolve validated data or reject the lookup error. */
            function finish(error, result) {
                signal?.removeEventListener("abort", abort);
                if (error) {
                    reject(error);
                } else {
                    resolve(result);
                }
            }
            /** Report safe stage/status metadata and reject without logging credentials or payloads. */
            function failure(stage, reason) {
                const details = { stage };
                if (stage === "response") {
                    details.httpStatus = xhr.status;
                    details.responseType = xhr.getResponseHeader("content-type")?.includes("application/json")
                        ? "json"
                        : "non_json";
                }
                if (reason === "csrf_invalid") {
                    details.reason = reason;
                }
                console.error("contentful.editor.request_failed", details);
                const error = new Error("Search unavailable");
                error.httpStatus = xhr.status;
                error.code = reason;
                finish(error);
            }
            xhr.onload = () => {
                if (
                    xhr.status < 200 ||
                    xhr.status >= 300 ||
                    !xhr.getResponseHeader("content-type")?.includes("application/json") ||
                    (xhr.responseURL && new URL(xhr.responseURL).origin !== endpoints.origin)
                ) {
                    let reason;
                    if (xhr.status === 403 && xhr.getResponseHeader("content-type")?.includes("application/json")) {
                        try {
                            if (JSON.parse(xhr.responseText).code === "csrf_invalid") {
                                reason = "csrf_invalid";
                            }
                        } catch {
                            /* Native error responses need not contain JSON. */
                        }
                    }
                    failure("response", reason);
                    return;
                }
                try {
                    const result = JSON.parse(xhr.responseText);
                    if (
                        !Array.isArray(result.items) ||
                        (validateItem && result.items.some((item) => !validateItem(item))) ||
                        (result.nextOffset !== null && (!Number.isInteger(result.nextOffset) || result.nextOffset < 0))
                    ) {
                        throw new Error("Invalid search response");
                    }
                    finish(null, result);
                } catch {
                    failure("payload");
                }
            };
            xhr.onerror = () => failure("network");
            xhr.ontimeout = () => failure("timeout");
            xhr.onabort = () => finish(new DOMException("Request aborted", "AbortError"));
            if (signal?.aborted) {
                finish(new DOMException("Request aborted", "AbortError"));
                return;
            }
            signal?.addEventListener("abort", abort, { once: true });
            try {
                xhr.open("POST", endpoints.searchUrl, true);
                xhr.timeout = 20000;
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
                // This is a browser request header, not Script API response.setHttpHeader.
                xhr.setRequestHeader("Cache-Control", "no-store");
                xhr.send(
                    new URLSearchParams({
                        ...parameters,
                        [csrf.name]: csrf.token,
                    }).toString(),
                );
            } catch {
                failure("network");
            }
        });
    }

    window.ContentfulPickerTransport = {
        /** Create an editor-local transport with immutable endpoints and no shared session-token state. */
        create(config) {
            const endpoints = readEndpoints(config);
            return {
                error: endpoints.error,
                /** Fetch one lookup, optionally applying item validation supplied by the entry editor. */
                request(parameters, signal, validateItem) {
                    return requestItems(endpoints, parameters, signal, validateItem);
                },
            };
        },
    };
})();
