"use strict";
var Resource = require("dw/web/Resource");
var siteSelection = require("./site");
var CSRFProtection = require("dw/web/CSRFProtection");
var service = require("int_contentful/cartridge/scripts/services/cdaService");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
var getSelectedSite = siteSelection.getSelectedSite;
/**
 * Prepare either picker lookup with JSON/no-cache responses, POST/CSRF enforcement
 * and the platform-selected merchant site. Return trusted lookup values and a response writer,
 * or null after writing a fixed rejection response. Native BM routing retains module
 * authentication/authorization; this helper never accepts a browser-supplied site ID.
 * @param {dw.system.Request} request current BM request
 * @param {dw.system.Response} response JSON response
 */
function prepareLookup(request, response, idParameter, inputError) {
    response.setContentType("application/json");
    // Cache-Control is platform-managed and prohibited by setHttpHeader().
    // Use the public expiry API; BM responses must never enter the page cache.
    response.setExpires(0);
    /** Write a status and JSON payload using the shared response settings. */
    function send(status, body) {
        response.setStatus(status);
        response.getWriter().print(JSON.stringify(body));
    }
    if (request.httpMethod !== "POST") {
        response.setHttpHeader("Allow", "POST");
        send(405, { error: Resource.msg("api.post", "contentfulPicker", null) });
        return null;
    }
    if (!CSRFProtection.validateRequest()) {
        // Distinguish our explicit rejection from native pre-pipeline validation.
        // Never include the token, request URL or referrer in diagnostics.
        diagnostics.log("warn", "picker.csrf_invalid", {});
        send(403, {
            code: "csrf_invalid",
            error: Resource.msg("api.csrf", "contentfulPicker", null),
        });
        return null;
    }
    var site = getSelectedSite();
    // Only a selected merchant site may choose credentials; BM's organization site cannot.
    if (!site) {
        send(400, { error: Resource.msg("api.site", "contentfulPicker", null) });
        return null;
    }
    var parameters = request.httpParameterMap;
    // HttpParameter supplies trimmed strings/defaults. IDs are opaque; the request
    // builder URL-encodes them rather than imposing a second provider ID grammar.
    var query = parameters.get("q").getStringValue("");
    var id = parameters.get(idParameter).getStringValue("");
    var offset = Number(parameters.get("offset").getStringValue("0"));
    // Skip must be a nonnegative integer. This interactive picker caps deep browsing
    // at 10,000 because large skip values make searches increasingly expensive.
    // Hydration and text search are separate operations; reject ambiguous combinations.
    if (!Number.isInteger(offset) || offset < 0 || offset > 10000 || (id && query)) {
        send(400, { error: Resource.msg(inputError, "contentfulPicker", null) });
        return null;
    }
    return { site: site, send: send, query: query, id: id, offset: offset };
}
/**
 * BM-only endpoint, registered under the Contentful content picker module.
 * BM owns authentication/module authorization; POST/CSRF are checked here too.
 * Derive the selected merchant site from the platform, never browser parameters.
 * Return JSON directly: MenuFrame/redirect responses are unsuitable for the iframe.
 * @param {dw.system.Request} request current BM request
 * @param {dw.system.Response} response JSON response
 */
function search(request, response) {
    var lookup = prepareLookup(request, response, "entryId", "api.entryInput");
    if (!lookup) {
        return;
    }
    var site = lookup.site, send = lookup.send, query = lookup.query, entryId = lookup.id, offset = lookup.offset;
    try {
        var result = service.searchContentEntries({ site: site, query: query, entryId: entryId, offset: offset });
        send(200, result);
    }
    catch (error) {
        diagnostics.log("error", "picker.search_failed", { errorType: diagnostics.errorType(error) });
        send(502, {
            error: Resource.msg("api.entryError", "contentfulPicker", null),
        });
    }
}
/**
 * Serve published image/video summaries or fixed JSON errors without response caching.
 * Require POST, a valid browser-session CSRF token and the current merchant site;
 * native BM routing enforces authentication and the picker module grant first.
 * assetId requests hydrate exactly one saved selection; q/offset requests browse/search.
 * Reject malformed inputs with 400 and report service failures as 502 without raw errors.
 * @param {dw.system.Request} request current BM request
 * @param {dw.system.Response} response JSON response
 * @param {boolean} video use the video collection filter instead of image
 */
function mediaAssets(request, response, video) {
    var lookup = prepareLookup(request, response, "assetId", video ? "api.videoInput" : "api.imageInput");
    if (!lookup) {
        return;
    }
    var site = lookup.site, send = lookup.send, query = lookup.query, assetId = lookup.id, offset = lookup.offset;
    try {
        var searchAssets = video ? service.searchContentVideoAssets : service.searchContentAssets;
        var result = searchAssets({ site: site, query: query, assetId: assetId, offset: offset });
        send(200, result);
    }
    catch (error) {
        diagnostics.log("error", video ? "picker.videos_failed" : "picker.assets_failed", {
            errorType: diagnostics.errorType(error),
        });
        send(502, {
            error: Resource.msg(video ? "api.videoError" : "api.imageError", "contentfulPicker", null),
        });
    }
}
/**
 * Handle published-image browsing/hydration through the shared secured media endpoint.
 * @param {dw.system.Request} request current BM request
 * @param {dw.system.Response} response JSON response
 */
function assets(request, response) {
    mediaAssets(request, response, false);
}
/**
 * Handle published-video browsing/hydration through the shared secured media endpoint.
 * @param {dw.system.Request} request current BM request
 * @param {dw.system.Response} response JSON response
 */
function videos(request, response) {
    mediaAssets(request, response, true);
}
/**
 * Obtain a token in the actual browser BM session, never the editor REST session.
 * BM authenticates and authorizes this under the same picker module as Search.
 * The required non-simple header prevents cross-origin browser calls without a
 * CORS preflight, which this endpoint does not allow. No JSONP or CORS headers.
 * @param {dw.system.Request} request current BM request
 * @param {dw.system.Response} response JSON response
 */
function sessionToken(request, response) {
    response.setContentType("application/json");
    response.setExpires(0);
    if (request.httpMethod !== "GET" || request.httpHeaders.get("x-requested-with") !== "XMLHttpRequest") {
        response.setStatus(403);
        response.getWriter().print(JSON.stringify({ error: Resource.msg("api.session", "contentfulPicker", null) }));
        return;
    }
    response.setStatus(200);
    response
        .getWriter()
        .print(JSON.stringify({ name: CSRFProtection.getTokenName(), token: CSRFProtection.generateToken() }));
}
module.exports = { assets: assets, videos: videos, search: search, sessionToken: sessionToken };
