"use strict";
var siteSelection = require("./site");
var getSelectedSite = siteSelection.getSelectedSite;
var CSRFProtection = require("dw/web/CSRFProtection");
var Resource = require("dw/web/Resource");
var Registry = require("dw/svc/LocalServiceRegistry");
var configuration = require("./configuration");
var status = require("./status");
var preferences = require("./preferences");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/** Accepted request actions; checked before temporary session or provider access. */
var SUPPORTED_ACTIONS = new Set(["cancel", "connect", "resume", "options", "save", "checkCredential"]);
/** Accepted API selections for the native credential connectivity check. */
var CREDENTIAL_KINDS = new Set(["delivery", "preview"]);
var SESSION_KEY = "contentfulGuidedSetup";
var TTL = 15 * 60 * 1000;
var ERROR_MESSAGES = {
    request_denied: "setup.requestDenied",
    site_required: "setup.siteRequired",
    site_changed: "setup.siteChanged",
    setup_expired: "setup.expired",
    credential_invalid: "setup.credentialInvalid",
    management_unauthorized: "setup.managementUnauthorized",
    contentful_busy: "setup.contentfulBusy",
    spaces_denied: "setup.spacesDenied",
    spaces_failed: "setup.spacesFailed",
    options_denied: "setup.optionsDenied",
    options_failed: "setup.optionsFailed",
    space_unavailable: "setup.spaceUnavailable",
    key_unavailable: "setup.keyUnavailable",
    key_failed: "setup.keyFailed",
    save_failed: "setup.saveFailed",
    delivery_not_enabled: "setup.deliveryNotEnabled",
};
/** Region defaults describe provider endpoints, not restrictions on manually configured hosts. */
function hosts(region) {
    var suffix = region === "eu" ? "eu.contentful.com" : "contentful.com";
    return { management: "api.".concat(suffix), delivery: "cdn.".concat(suffix), preview: "preview.".concat(suffix) };
}
/** Govern Management API requests; redact entire communication logs, including key responses. */
function get(host, path, token) {
    var result = Registry.createService("contentful.management.api", {
        createRequest: function (svc) {
            svc.setURL("https://".concat(host).concat(path));
            svc.setRequestMethod("GET");
            svc.setAuthentication("NONE");
            svc.addHeader("Authorization", "Bearer ".concat(token));
            return null;
        },
        parseResponse: function (svc, client) {
            return JSON.parse(client.text);
        },
        getRequestLogMessage: function () {
            return "Contentful guided setup request (redacted)";
        },
        getResponseLogMessage: function () {
            return "Contentful guided setup response (redacted)";
        },
        filterLogMessage: function () {
            return "Contentful guided setup communication (redacted)";
        },
    }).call();
    // Only successful JSON bodies enter discovery; classify failed requests by their native status.
    if (!result.ok || !result.object) {
        throw Object.assign(new Error("Contentful setup request failed"), { httpStatus: result.error });
    }
    return result.object;
}
/** Fixed codes describe our operation and HTTP status, never upstream response bodies. */
function failure(code) {
    return Object.assign(new Error("Contentful setup failed"), { code: code });
}
function managementRead(stage, work) {
    try {
        return work();
    }
    catch (error) {
        if (error.httpStatus === 401) {
            throw failure("management_unauthorized");
        }
        if (error.httpStatus === 429) {
            throw failure("contentful_busy");
        }
        if ([403, 404].includes(error.httpStatus)) {
            if (stage === "options") {
                throw failure(error.httpStatus === 403 ? "options_denied" : "space_unavailable");
            }
            if (stage === "spaces") {
                throw failure(error.httpStatus === 403 ? "spaces_denied" : "spaces_failed");
            }
            throw failure("".concat(stage, "_unavailable"));
        }
        throw failure("".concat(stage, "_failed"));
    }
}
/** Collect at most ten discovery pages, failing instead of silently omitting available choices. */
function collection(host, path, token) {
    var items = [];
    for (var skip = 0; skip < 10000; skip += 1000) {
        var page = get(host, "".concat(path, "?limit=1000&skip=").concat(String(skip)), token);
        // JSON parsing alone does not establish a collection: a bad total could terminate discovery early.
        if (!Array.isArray(page.items) || !Number.isInteger(page.total)) {
            throw new Error("Invalid collection");
        }
        items = items.concat(page.items);
        if (items.length >= page.total) {
            return items;
        }
        if (page.items.length === 0) {
            break;
        }
    }
    throw new Error("Contentful collection exceeds setup pagination bounds");
}
/** Environment IDs also identify alias grants; never expand an alias into its target. */
function grants(key) {
    return key.environments.map(function (link) { return link.sys.id; });
}
/** Return only non-secret key metadata; the browser uses grant IDs to filter its choices. */
function keyChoices(items, spaceId) {
    return items.map(function (key) { return ({
        id: key.sys.id,
        spaceId: spaceId,
        label: key.name || key.sys.id,
        environments: grants(key),
    }); });
}
/** A credential is required; CR/LF would split its Authorization header. Export encoding is separate. */
function secret(value) {
    if (!value || /[\r\n]/.test(value)) {
        throw new Error("Invalid key");
    }
    return value;
}
/**
 * Authenticated Configuration-module POST endpoint for temporary PAT-assisted setup.
 * The credential stays in the BM privacy session; access is site-bound and expires
 * after 15 minutes. Saving/cancelling, provider 401 or a later expired-flow request
 * discards our copy. This does not revoke or manage the user's PAT, and the token
 * never becomes a site preference.
 * Every provider operation is a GET; only explicit connection saves write local BM settings.
 */
function execute(request, response, session) {
    response.setContentType("application/json");
    response.setExpires(0);
    function send(status, body) {
        response.setStatus(status);
        response.getWriter().print(JSON.stringify(body));
    }
    // Module permission does not establish POST/CSRF safety; credentials also require a live BM session.
    if (!session.userAuthenticated || request.httpMethod !== "POST" || !CSRFProtection.validateRequest()) {
        send(403, { code: "request_denied", error: Resource.msg("setup.requestDenied", "contentfulManagement", null) });
        return;
    }
    var site = getSelectedSite();
    if (!site) {
        send(400, { code: "site_required", error: Resource.msg("setup.siteRequired", "contentfulManagement", null) });
        return;
    }
    function parameter(key) {
        return request.httpParameterMap.get(key).getStringValue("");
    }
    try {
        var action = parameter("action");
        // Reject unsupported actions before inspecting session state or calling the provider.
        if (!SUPPORTED_ACTIONS.has(action)) {
            throw new Error("Invalid action");
        }
        // This check needs BM authorization/CSRF, but no PAT or live discovery session.
        if (action === "checkCredential") {
            // An open native editor can outlive BM’s selected-site context. The browser
            // supplies only a stale-page guard; it never selects the site or credential.
            if (parameter("expectedSiteId") !== site.getID()) {
                throw failure("site_changed");
            }
            var kind_1 = parameter("kind");
            if (!CREDENTIAL_KINDS.has(kind_1)) {
                throw new Error("Invalid credential kind");
            }
            var target = configuration.credentialTargets(site).find(function (item) { return item.kind === kind_1; });
            send(200, Object.assign({}, status.probe(site, kind_1 === "preview"), { isSet: target.isSet }));
            return;
        }
        if (action === "cancel") {
            session.privacy[SESSION_KEY] = null;
            send(200, {});
            return;
        }
        if (action === "connect") {
            // A new attempt replaces the old credential even when its replacement is invalid.
            // Do not retain a submitted PAT until Contentful confirms a readable collection.
            session.privacy[SESSION_KEY] = null;
            // Keep this connect-action selection distinct from the endpoint hosts
            // used by later actions.
            var selectedRegion_1 = parameter("region");
            // These choices select the supported provider endpoint defaults, not token syntax.
            if (!["us", "eu"].includes(selectedRegion_1)) {
                throw new Error("Invalid region");
            }
            var token_1;
            try {
                token_1 = secret(parameter("personalAccessToken"));
            }
            catch (error) {
                throw Object.assign(error, { code: "credential_invalid" });
            }
            managementRead("spaces", function () {
                var spaces = get(hosts(selectedRegion_1).management, "/spaces?limit=1", token_1);
                // A successful HTTP/JSON response alone does not establish the discovery contract.
                if (!Array.isArray(spaces.items) || !Number.isInteger(spaces.total) || spaces.total < 0) {
                    throw new Error("Invalid space collection");
                }
            });
            session.privacy[SESSION_KEY] = JSON.stringify({
                token: token_1,
                region: selectedRegion_1,
                siteId: site.getID(),
                expires: Date.now() + TTL,
            });
            send(200, { connected: true });
            return;
        }
        var raw = session.privacy[SESSION_KEY];
        var flow_1 = raw ? JSON.parse(raw) : null;
        // Temporary authorization cannot cross merchant sites or outlive this short setup session.
        if (!flow_1 || flow_1.siteId !== site.getID() || flow_1.expires <= Date.now()) {
            session.privacy[SESSION_KEY] = null;
            if (action === "resume") {
                send(200, { connected: false });
                return;
            }
            throw failure("setup_expired");
        }
        var region_1 = hosts(flow_1.region);
        if (action === "resume") {
            send(200, {
                connected: true,
                spaces: managementRead("spaces", function () { return collection(region_1.management, "/spaces", flow_1.token); }).map(function (space) { return ({
                    id: space.sys.id,
                    label: space.name || space.sys.id,
                }); }),
            });
            return;
        }
        var space_1 = parameter("spaceId");
        // Both discovery and saving need a selected space; IDs remain opaque until URL construction.
        if (!space_1) {
            throw new Error("Missing space");
        }
        var base_1 = "/spaces/".concat(encodeURIComponent(space_1));
        if (action === "options") {
            var discovered = managementRead("options", function () { return ({
                keys: keyChoices(collection(region_1.management, "".concat(base_1, "/api_keys"), flow_1.token), space_1),
                aliases: collection(region_1.management, "".concat(base_1, "/environment_aliases"), flow_1.token),
                environments: collection(region_1.management, "".concat(base_1, "/environments"), flow_1.token),
            }); });
            var keys = discovered.keys;
            var aliases_1 = discovered.aliases;
            var environments = discovered.environments;
            send(200, {
                keys: keys,
                aliases: aliases_1.map(function (item) { return ({ id: item.sys.id, label: item.sys.id }); }),
                // An alias may also appear in the environment collection; show it only as an alias.
                environments: environments
                    .filter(function (item) { return !aliases_1.some(function (alias) { return alias.sys.id === item.sys.id; }); })
                    .map(function (item) { return ({
                    id: item.sys.id,
                    label: item.name && item.name !== item.sys.id ? "".concat(item.name, " (").concat(item.sys.id, ")") : item.sys.id,
                }); }),
            });
            return;
        }
        var keyId_1 = parameter("keyId");
        var environment = parameter("environment");
        // Reject incomplete selections before fetching keys or persisting settings.
        if (!keyId_1 || !environment) {
            throw new Error("Missing key or environment");
        }
        // Re-read key metadata and grants: they may have changed since discovery.
        var key_1 = managementRead("key", function () {
            return get(region_1.management, "".concat(base_1, "/api_keys/").concat(encodeURIComponent(keyId_1)), flow_1.token);
        });
        if (!grants(key_1).includes(environment)) {
            throw Object.assign(new Error("Environment not enabled for key"), { code: "delivery_not_enabled" });
        }
        var delivery = secret(key_1.accessToken);
        var values = {
            contentfulSpaceId: space_1,
            contentfulEnvironment: environment,
            contentfulHost: region_1.delivery,
            contentfulPreviewHost: region_1.preview,
        };
        var targets = configuration.credentialTargets(site);
        var credentials = [
            Object.assign({}, targets[0], { token: delivery }),
        ];
        var snippet = "CONTENTFUL_CDA_TOKEN=".concat(JSON.stringify(delivery));
        // Contentful creates/deletes the Delivery and linked Preview key as a pair.
        // Connectivity is checked later through the saved native service credentials.
        var preview = managementRead("key", function () {
            return secret(get(region_1.management, "".concat(base_1, "/preview_api_keys/").concat(encodeURIComponent(key_1.preview_api_key.sys.id)), flow_1.token).accessToken);
        });
        credentials.push(Object.assign({}, targets[1], { token: preview }));
        snippet += "\nCONTENTFUL_PREVIEW_TOKEN=".concat(JSON.stringify(preview));
        try {
            preferences.writePreferences(site, values);
        }
        catch (error) {
            throw Object.assign(error, { code: "save_failed" });
        }
        session.privacy[SESSION_KEY] = null;
        // Intentional, explicit administrator-only secret export; no general view model contains keys.
        send(200, { snippet: snippet, credentials: credentials });
    }
    catch (error) {
        // Only our fixed codes may select translated UI messages; never expose provider exception text.
        var code = Object.prototype.hasOwnProperty.call(ERROR_MESSAGES, error.code) ? error.code : undefined;
        if (code === "management_unauthorized") {
            session.privacy[SESSION_KEY] = null;
        }
        diagnostics.log("warn", "setup.failed", { errorType: diagnostics.errorType(error), code: code });
        send(400, {
            code: code,
            error: Resource.msg(code ? ERROR_MESSAGES[code] : "setup.error", "contentfulManagement", null),
        });
    }
}
module.exports = { execute: execute };
