"use strict";
/** Standalone BM Script pipelet; native Configuration permission precedes POST/CSRF checks. */
/* exported execute */
var execute = function execute(pdict) {
    require("bm_contentful/cartridge/scripts/guidedSetup").execute(request, response, session);
    return PIPELET_NEXT;
};
