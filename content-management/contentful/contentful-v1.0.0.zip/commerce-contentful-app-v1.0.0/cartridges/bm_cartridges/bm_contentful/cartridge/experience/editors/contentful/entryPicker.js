/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
"use strict";
var URLUtils = require("dw/web/URLUtils");
var CSRFProtection = require("dw/web/CSRFProtection");
var Resource = require("dw/web/Resource");
var localization = require("../../../scripts/localization");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/**
 * Pass only same-origin BM routing and the CSRF parameter name to the iframe.
 * init executes in a REST session, not the browser's BM session: do not generate
 * a CSRF token here. The iframe obtains its token from a separate authenticated BM request.
 * Contentful credentials stay on ECOM. Entries are searched on demand, not preloaded.
 * Page Designer still persists the custom attribute as { entryId }, never a string.
 * @param {dw.experience.CustomEditor} editor Page Designer editor configuration
 */
function init(editor) {
    localization.initialize(editor);
    try {
        editor.configuration.put("sessionUrl", URLUtils.https("ContentfulPicker-Session").toString());
        editor.configuration.put("searchUrl", URLUtils.https("ContentfulPicker-Search").toString());
        editor.configuration.put("csrf", {
            name: CSRFProtection.getTokenName(),
        });
    }
    catch (error) {
        diagnostics.log("error", "picker.init_failed", { errorType: diagnostics.errorType(error) });
        editor.configuration.put("error", Resource.msg("initError", "contentfulPicker", null));
    }
}
module.exports = { init: init };
