/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
"use strict";
var PageMgr = require("dw/experience/PageMgr");
var HashMap = require("dw/util/HashMap");
var dialog = require("./assetDialog");
var Resource = require("dw/web/Resource");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/**
 * Initialize the compact property editor with the dialog's BM endpoints, then register
 * its native modal dependency. The host supplies the current value to that dependency;
 * browser code commits a replacement only after Apply. Initialization failures surface
 * fixed retry guidance without exposing exception details or Contentful credentials.
 * @param {dw.experience.CustomEditor} editor Page Designer custom editor
 */
function init(editor) {
    dialog.init(editor);
    editor.configuration.put("dialog", false);
    try {
        editor.dependencies.put("assetDialog", PageMgr.getCustomEditor("contentful.assetDialog", new HashMap()));
    }
    catch (error) {
        diagnostics.log("error", "picker.init_failed", { errorType: diagnostics.errorType(error) });
        editor.configuration.put("error", Resource.msg("initError", "contentfulPicker", null));
    }
}
module.exports = { init: init };
