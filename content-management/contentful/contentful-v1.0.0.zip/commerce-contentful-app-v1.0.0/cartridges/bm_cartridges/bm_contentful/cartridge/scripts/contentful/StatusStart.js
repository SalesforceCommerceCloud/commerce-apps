"use strict";
/**
 * Build status using independent Delivery and Preview probes for BM's selected site.
 * @output ContentfulManagement : Object
 */
/* exported execute */
var execute = function execute(pdict) {
    var Resource = require("dw/web/Resource");
    var site = require("bm_contentful/cartridge/scripts/site").getSelectedSite();
    var view = { page: "Status", error: "" };
    pdict.ContentfulManagement = view;
    if (!site) {
        view.error = Resource.msg("error.site", "contentfulManagement", null);
        return PIPELET_NEXT;
    }
    var preferences = site.getPreferences().getCustom();
    var status = require("bm_contentful/cartridge/scripts/status");
    view.siteId = site.getID();
    view.spaceId = preferences.contentfulSpaceId || Resource.msg("state.notConfigured", "contentfulManagement", null);
    view.environment = preferences.contentfulEnvironment || "master";
    view.deliveryKeySet = Boolean(preferences.contentfulCdaToken);
    view.previewKeySet = Boolean(preferences.contentfulPreviewToken);
    view.connections = [status.probe(site, false), status.probe(site, true)];
    return PIPELET_NEXT;
};
