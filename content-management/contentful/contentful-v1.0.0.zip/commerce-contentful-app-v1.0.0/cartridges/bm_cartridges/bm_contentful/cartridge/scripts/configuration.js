"use strict";
var previewSettings = require("int_contentful/cartridge/scripts/previewSettings");
var Resource = require("dw/web/Resource");
var CSRFProtection = require("dw/web/CSRFProtection");
// Keep this descriptor synchronized with SitePreferences metadata and the CAP settings.
// Password fields never contain saved values. Only an explicitly entered, successfully
// saved preview secret may enter the one-response MRT export outside the fields.
var SETTINGS = [
    {
        id: "contentfulSpaceId",
        type: "text",
        fallback: "",
        section: "Connection",
    },
    {
        id: "contentfulEnvironment",
        type: "text",
        fallback: "master",
        section: "Connection",
    },
    {
        id: "contentfulHost",
        type: "text",
        fallback: "cdn.contentful.com",
        section: "Connection",
    },
    {
        id: "contentfulPreviewHost",
        group: "Preview API",
        type: "text",
        fallback: "",
        section: "Connection",
    },
    {
        id: "contentfulFetchRetries",
        type: "number",
        fallback: 2,
        min: 0,
        max: 3,
        section: "Rendering",
    },
    {
        id: "contentfulFetchTimeoutMs",
        type: "number",
        fallback: 4000,
        min: 1,
        max: 30000,
        section: "Rendering",
    },
    {
        id: "contentfulCdaToken",
        type: "password",
        section: "Connection",
    },
    {
        id: "contentfulPreviewToken",
        group: "Preview API",
        type: "password",
        section: "Connection",
    },
    {
        id: "contentfulPreviewSecret",
        type: "password",
        section: "LivePreview",
    },
    {
        id: "contentfulPreviewInspector",
        type: "boolean",
        fallback: false,
        section: "LivePreview",
    },
    {
        id: "contentfulPreviewEditorOrigin",
        type: "text",
        fallback: "",
        section: "LivePreview",
    },
    {
        id: "contentfulReferenceDepth",
        type: "number",
        fallback: 3,
        min: 0,
        max: 10,
        section: "Rendering",
    },
];
/** Read a submitted form value without changing its stored preference identifier. */
function parameter(parameters, key) {
    return parameters.get(key).getStringValue("");
}
/** Resolve field labels/help for this BM request and expose values with write-only password indicators. */
function formValues(preferences) {
    return SETTINGS.map(function (setting) {
        var field = {
            id: setting.id,
            label: Resource.msg("field.".concat(setting.id, ".label"), "contentfulManagement", null),
            help: Resource.msg("field.".concat(setting.id, ".help"), "contentfulManagement", null),
            type: setting.type,
            section: setting.section,
            group: setting.group,
            min: setting.min,
            max: setting.max,
        };
        var value = preferences[setting.id];
        if (setting.type === "password") {
            field.isSet = Boolean(value);
        }
        else {
            field.value = value === undefined || value === null ? setting.fallback : value;
        }
        return field;
    });
}
/** Validate authored settings with localized errors; return only permitted preference updates. */
function parseSubmission(parameters) {
    var values = {};
    SETTINGS.forEach(function (setting) {
        var input = parameter(parameters, setting.id);
        if (setting.type === "password") {
            var clear = parameter(parameters, "".concat(setting.id, "Clear")) === "true";
            // Conflicting browser controls can still be submitted by a crafted request.
            if (clear && input) {
                throw new Error(Resource.msg("validation.keyConflict", "contentfulManagement", null));
            }
            if (clear || input) {
                values[setting.id] = clear ? "" : input;
            }
        }
        else if (setting.type === "boolean") {
            if (input !== "" && input !== "true" && input !== "false") {
                throw new Error(Resource.msg("validation.boolean", "contentfulManagement", null));
            }
            values[setting.id] = input === "true";
        }
        else if (setting.type === "number") {
            var value = Number(input === "" ? setting.fallback : input);
            // Bound reference expansion, retries and timeout cost; browser constraints are bypassable.
            if (!Number.isInteger(value) || value < setting.min || value > setting.max) {
                throw new Error(Resource.msgf("validation.integer", "contentfulManagement", null, Resource.msg("field.".concat(setting.id, ".label"), "contentfulManagement", null)));
            }
            values[setting.id] = value;
        }
        else {
            values[setting.id] = input;
        }
    });
    // IDs remain opaque here; outbound callers encode each URL path segment.
    values.contentfulEnvironment = values.contentfulEnvironment || "master";
    values.contentfulHost = values.contentfulHost || "cdn.contentful.com";
    try {
        previewSettings.resolve(values);
    }
    catch (error) {
        error.message = Resource.msg("validation.editorOrigin", "contentfulManagement", null);
        throw error;
    }
    return values;
}
/** Build fresh configuration fields and CSRF data without exposing stored credentials. */
function view(site) {
    var result = {
        page: "Configuration",
        fields: [],
        sections: ["Connection", "LivePreview", "Rendering"],
        error: "",
        saved: false,
    };
    if (!site) {
        result.error = Resource.msg("error.site", "contentfulManagement", null);
        return result;
    }
    result.siteId = site.getID();
    result.fields = formValues(site.getPreferences().getCustom());
    result.csrf = { name: CSRFProtection.getTokenName(), token: CSRFProtection.generateToken() };
    return result;
}
module.exports = { SETTINGS: SETTINGS, formValues: formValues, parseSubmission: parseSubmission, view: view };
