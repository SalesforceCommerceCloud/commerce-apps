"use strict";
/**
 * Standalone summary-page adapter; native BM enforces the picker module grant.
 * @output ContentfulManagement : Object
 */
/* exported execute */
var execute = function execute(pdict) {
    var Resource = require("int_contentful/cartridge/scripts/uiResources");
    var site = require("bm_contentful/cartridge/scripts/site").getSelectedSite();
    // Split localized placeholders before passing text fragments to ISML.
    var permissionParts = String(Resource.msg("picker.permissions", "contentfulManagement", null)).split("{0}");
    var view = {
        page: "Picker",
        error: "",
        permissionParts: permissionParts,
    };
    pdict.ContentfulManagement = view;
    if (!site) {
        view.error = Resource.msg("error.site", "contentfulManagement", null);
        return PIPELET_NEXT;
    }
    view.siteId = site.getID();
    var preferences = site.getPreferences().getCustom();
    if (preferences.contentfulSpaceId) {
        var appHost = preferences.contentfulHost === "cdn.eu.contentful.com" ? "app.eu.contentful.com" : "app.contentful.com";
        var space = encodeURIComponent(preferences.contentfulSpaceId);
        var environment = encodeURIComponent(preferences.contentfulEnvironment || "master");
        view.contentModelsUrl = "https://".concat(appHost, "/spaces/").concat(space, "/environments/").concat(environment, "/content_types");
    }
    return PIPELET_NEXT;
};
