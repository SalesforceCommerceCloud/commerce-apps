/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Run one isolated editor instance in either compact property-panel or native-modal
 * mode. Only { assetId } crosses the saved-value boundary; search state and transient
 * credentials stay in the iframe. The host owns modal Apply/Cancel and focus trapping.
 */
(() => {
    "use strict";
    let config = {},
        value = null,
        savedAsset = null,
        required = true,
        disabled = false;
    let transport;
    let messages;
    let configError = "",
        warning = "",
        searchError = "";
    let unavailable = false,
        loading = false,
        dialog = false,
        mediaType = "image",
        items = [],
        nextOffset = null;
    let revision = 0,
        selectionRevision = 0,
        controller,
        hydrationController,
        timer;
    let modalOpen = false;
    let hydrationId = "";
    document.body.className = "contentful-asset-picker";
    /** Build static markup without HTML parsing; Contentful metadata is assigned as text later. */
    function element(tag, attributes, children = []) {
        const node = document.createElement(tag);
        for (const [name, attribute] of Object.entries(attributes)) {
            node.setAttribute(name, attribute);
        }
        node.append(...children);
        return node;
    }
    const button = (id, attributes = {}) =>
        element("button", { id, type: "button", class: "contentful-asset-button", ...attributes });
    document.body.appendChild(
        element("div", { class: "slds-form-element" }, [
            element("section", { id: "contentful-asset-panel" }, [
                element("div", { id: "contentful-asset-preview" }),
                element("div", { class: "contentful-asset-actions" }, [
                    button("contentful-asset-choose"),
                    button("contentful-asset-clear"),
                ]),
            ]),
            element("section", { id: "contentful-asset-browser", hidden: "" }, [
                element("label", { class: "slds-form-element__label", for: "contentful-asset-search" }),
                element("input", {
                    id: "contentful-asset-search",
                    class: "slds-input",
                    type: "search",
                    autocomplete: "off",
                    "aria-describedby": "contentful-asset-status",
                }),
                element("p", { id: "contentful-asset-selection", class: "contentful-asset-caption" }),
                element("div", { id: "contentful-asset-dialog-preview", hidden: "" }),
                element("div", { id: "contentful-asset-grid", class: "contentful-asset-grid", role: "group" }),
                button("contentful-asset-more", { hidden: "" }),
            ]),
            element("p", {
                id: "contentful-asset-status",
                class: "slds-form-element__help",
                role: "status",
                "aria-live": "polite",
            }),
            button("contentful-asset-retry", { hidden: "" }),
        ]),
    );
    const panel = document.getElementById("contentful-asset-panel");
    const browser = document.getElementById("contentful-asset-browser");
    const preview = document.getElementById("contentful-asset-preview");
    const selection = document.getElementById("contentful-asset-selection");
    const dialogPreview = document.getElementById("contentful-asset-dialog-preview");
    const choose = document.getElementById("contentful-asset-choose");
    const clear = document.getElementById("contentful-asset-clear");
    const input = document.getElementById("contentful-asset-search");
    const grid = document.getElementById("contentful-asset-grid");
    const status = document.getElementById("contentful-asset-status");
    const more = document.getElementById("contentful-asset-more");
    const retry = document.getElementById("contentful-asset-retry");
    /**
     * Use the stable media enum only to select complete resource messages. It is never
     * a translated noun or a fragment interpolated into the displayed sentence.
     */
    function configureMediaLabels() {
        panel.setAttribute("aria-label", messages.text(`${mediaType}.panel`));
        browser.setAttribute("aria-label", messages.text(`${mediaType}.browser`));
        choose.textContent = messages.text(`${mediaType}.choose`);
        document.querySelector('label[for="contentful-asset-search"]').textContent = messages.text(
            `${mediaType}.search`,
        );
        input.placeholder = messages.text(`${mediaType}.search`);
        grid.setAttribute("aria-label", messages.text(`${mediaType}.choices`));
        more.textContent = messages.text(`${mediaType}.more`);
        clear.textContent = messages.text("clear");
        retry.textContent = messages.text("retry");
    }
    /** Format optional byte metadata without assuming duration or dimensions exist on video assets. */
    function fileSize(bytes) {
        if (bytes == null) {
            return "";
        }
        if (bytes < 1024) {
            return messages.text("size.bytes", messages.number(bytes));
        }
        if (bytes < 1024 * 1024) {
            return messages.text("size.kb", messages.number(bytes / 1024, 1));
        }
        return messages.text("size.mb", messages.number(bytes / (1024 * 1024), 1));
    }
    /** Show a decorative video indicator without fetching every result's original media file. */
    function videoCard() {
        const marker = document.createElement("span");
        marker.className = "contentful-asset-video-marker";
        marker.setAttribute("aria-hidden", "true");
        marker.textContent = messages.text("video.indicator");
        return marker;
    }
    /** Preview only the selected video with native controls and no autoplay or video transformations. */
    function video(asset) {
        const player = document.createElement("video");
        player.controls = true;
        player.preload = "metadata";
        player.playsInline = true;
        player.setAttribute("aria-label", asset.label);
        player.dataset.assetId = asset.id;
        const source = document.createElement("source");
        source.src = asset.url;
        source.type = asset.contentType;
        player.appendChild(source);
        return player;
    }
    /** Preserve playback across redraws, replacing a video only when the selected source changes. */
    function updateVideoPreview(container, asset, visible) {
        const current = container.querySelector("video");
        if (!visible || !asset) {
            current?.remove();
            return;
        }
        const source = current?.querySelector("source");
        if (
            current?.dataset.assetId === asset.id &&
            source?.getAttribute("src") === asset.url &&
            source.type === asset.contentType
        ) {
            current.setAttribute("aria-label", asset.label);
            return;
        }
        current?.remove();
        container.prepend(video(asset));
    }
    /** Return the current valid ID, or an empty string for cleared/malformed editor values. */
    function selectedId() {
        return typeof value?.assetId === "string" && value.assetId.trim().length > 0 ? value.assetId : "";
    }
    /**
     * Create a decorative lazy thumbnail from the provider URL in a media summary.
     * Apply Contentful transformations to eligible API-returned image formats/file sizes;
     * other images use their original URL. No referrer is sent to the image host.
     */
    function image(asset) {
        const img = document.createElement("img");
        let source = asset.url;
        // Contentful returns asset URLs for its image service; no hostname list is needed.
        // Unsupported formats and oversized files use the original URL.
        if (
            // Match standardized MIME tokens, independently of localized image/video labels.
            /^image\/(jpe?g|png|webp|gif|avif|tiff)$/.test(asset.contentType) &&
            (asset.fileSize === undefined || asset.fileSize <= 100_000_000)
        ) {
            try {
                // Parse only to add image transforms; browser resolution and CSP own URL validity.
                const url = new URL(asset.url, window.origin);
                url.searchParams.set("w", "320");
                url.searchParams.set("h", "200");
                url.searchParams.set("fit", "pad");
                source = url.toString();
            } catch {
                // Keep the original URL when it cannot be parsed for transformations.
            }
        }
        img.alt = "";
        img.loading = "lazy";
        img.referrerPolicy = "no-referrer";
        img.src = source;
        return img;
    }
    /**
     * Publish host-form validity from required/configuration/selection availability.
     * A transient lookup failure keeps prior validity; a confirmed missing asset is invalid.
     */
    function validate() {
        const id = selectedId();
        const valid = !configError && ((!required && value === null) || Boolean(id && !unavailable));
        emit({ type: "sfcc:valid", payload: valid });
        choose.setAttribute("aria-invalid", String(!valid));
    }
    /**
     * Rebuild the preview/results and update controls, status, retry visibility and validity
     * from instance state. Render dynamic labels as text and preserve selection independently
     * of the current search results. Callers restore keyboard focus after replacing buttons.
     */
    function render() {
        const blocked = disabled || Boolean(configError);
        panel.hidden = dialog;
        browser.hidden = !dialog;
        choose.disabled = blocked || modalOpen;
        clear.disabled = blocked || !value || modalOpen;
        input.disabled = blocked;
        more.disabled = blocked || loading;
        more.hidden = nextOffset === null;
        grid.setAttribute("aria-busy", String(loading));
        if (mediaType === "image") {
            preview.textContent = "";
            if (savedAsset) {
                preview.appendChild(image(savedAsset));
            }
        } else {
            updateVideoPreview(preview, savedAsset, !dialog);
        }
        dialogPreview.hidden = mediaType !== "video";
        updateVideoPreview(dialogPreview, savedAsset, dialog && mediaType === "video");
        const caption = preview.querySelector(".contentful-asset-caption") || document.createElement("p");
        caption.className = "contentful-asset-caption";
        caption.textContent =
            savedAsset?.label ||
            (selectedId() ? messages.text(`${mediaType}.saved`, selectedId()) : messages.text(`${mediaType}.none`));
        preview.appendChild(caption);
        selection.textContent = messages.text(`${mediaType}.selected`, caption.textContent);
        grid.textContent = "";
        items.forEach((asset) => {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "contentful-asset-card";
            button.disabled = blocked;
            button.setAttribute("aria-pressed", String(asset.id === selectedId()));
            button.appendChild(mediaType === "video" ? videoCard() : image(asset));
            const label = document.createElement("span");
            label.textContent = asset.label;
            button.appendChild(label);
            if (asset.width && asset.height) {
                const dimensions = document.createElement("small");
                dimensions.textContent = messages.text(
                    "dimensions",
                    messages.number(asset.width),
                    messages.number(asset.height),
                );
                button.appendChild(dimensions);
            }
            if (mediaType === "video") {
                const metadata = document.createElement("small");
                metadata.textContent = [asset.contentType, asset.fileName, fileSize(asset.fileSize)]
                    .filter(Boolean)
                    .join(" · ");
                button.appendChild(metadata);
            }
            // Stage a dialog choice, supersede saved-ID hydration and restore this card's focus.
            button.addEventListener("click", () => {
                selectionRevision++;
                hydrationController?.abort();
                value = { assetId: asset.id };
                savedAsset = asset;
                unavailable = false;
                warning = "";
                // This updates the breakout form only. The trigger commits on host Apply.
                emit({ type: "sfcc:value", payload: value });
                emit({ type: "sfcc:interacted" });
                render();
                grid.querySelectorAll("button")[items.indexOf(asset)]?.focus();
            });
            grid.appendChild(button);
        });
        if (configError || searchError || warning) {
            status.textContent = configError || searchError || warning;
        } else if (loading) {
            status.textContent = messages.text("searching");
        } else if (dialog) {
            status.textContent = messages.count(
                `${mediaType}.${nextOffset !== null ? "resultsMore" : "results"}`,
                items.length,
            );
        } else {
            status.textContent = messages.text(`${mediaType}.prompt`);
        }
        status.classList.toggle("contentful-asset-status_error", Boolean(configError || warning || searchError));
        retry.hidden = Boolean(configError) || !(searchError || warning);
        retry.disabled = blocked || loading;
        validate();
    }
    /** Cancel pending debounce/network work and invalidate any search response already in flight. */
    function cancelSearch() {
        clearTimeout(timer);
        controller?.abort();
        revision++;
        loading = false;
    }
    /** Request the BM endpoint's media summaries; the service owns usable-file filtering. */
    function requestItems(parameters, signal) {
        return transport.request(parameters, signal);
    }
    /**
     * Load a dialog search page, replacing results at offset zero or appending/deduplicating
     * later pages. Ignore superseded responses, preserve the selected asset on failure,
     * and focus the first newly appended card after successful pagination.
     */
    async function search(offset = 0) {
        cancelSearch();
        if (disabled || configError || !dialog) {
            return;
        }
        const current = revision;
        const previousCount = items.length;
        controller = new AbortController();
        searchError = "";
        loading = true;
        render();
        try {
            const result = await requestItems({ q: input.value.trim(), offset: String(offset) }, controller.signal);
            if (current !== revision) {
                return;
            }
            items = [
                ...new Map(
                    (offset ? [...items, ...result.items] : result.items).map((asset) => [asset.id, asset]),
                ).values(),
            ];
            nextOffset = result.nextOffset;
        } catch (error) {
            if (current !== revision || error.name === "AbortError") {
                return;
            }
            searchError = messages.text(`${mediaType}.searchError`);
        } finally {
            if (current === revision) {
                loading = false;
                render();
                if (offset && !searchError) {
                    grid.querySelectorAll("button")[previousCount]?.focus();
                }
            }
        }
    }
    /**
     * Resolve the saved/staged ID separately from search without changing the saved value.
     * Confirmed absence invalidates it; transient failures preserve its existing validity,
     * including a previous missing result for the same ID. Ignore superseded lookups.
     */
    async function hydrateSelection() {
        const current = ++selectionRevision;
        hydrationController?.abort();
        hydrationController = new AbortController();
        const id = selectedId();
        savedAsset = null;
        warning = "";
        if (id !== hydrationId || !id) {
            unavailable = Boolean(value && !id);
        }
        hydrationId = id;
        render();
        if (!id || configError || disabled) {
            return;
        }
        try {
            const result = await requestItems({ assetId: id }, hydrationController.signal);
            if (current !== selectionRevision) {
                return;
            }
            savedAsset = result.items.find((asset) => asset.id === id) || null;
            unavailable = !savedAsset;
            warning = unavailable ? messages.text(`${mediaType}.unavailable`) : "";
        } catch (error) {
            if (current !== selectionRevision || error.name === "AbortError") {
                return;
            }
            warning = messages.text(`${mediaType}.lookupError`);
        }
        if (current === selectionRevision) {
            render();
        }
    }
    // Open the registered native modal; its callback commits only an applicable Apply result.
    // Cancel, disabled state or a newer selection leave the original value unchanged.
    choose.addEventListener("click", () => {
        if (disabled || configError || modalOpen) {
            return;
        }
        const current = selectionRevision;
        modalOpen = true;
        render();
        emit(
            {
                type: "sfcc:breakout",
                payload: { id: "assetDialog", type: "modal", title: messages.text(`${mediaType}.dialog`) },
            },
            (result) => {
                modalOpen = false;
                if (
                    !disabled &&
                    current === selectionRevision &&
                    result.type === "sfcc:breakoutApply" &&
                    typeof result.value?.assetId === "string" &&
                    result.value.assetId.trim().length > 0
                ) {
                    value = { assetId: result.value.assetId };
                    emit({ type: "sfcc:value", payload: value });
                    hydrateSelection();
                }
                emit({ type: "sfcc:interacted" });
                render();
                choose.focus();
            },
        );
    });
    // Persist an explicit clear and cancel obsolete hydration through the shared selection path.
    clear.addEventListener("click", () => {
        if (disabled || configError || modalOpen) {
            return;
        }
        value = null;
        emit({ type: "sfcc:value", payload: null });
        emit({ type: "sfcc:interacted" });
        hydrateSelection();
    });
    // Debounce text searches without changing the saved image; defer IME input until composition ends.
    input.addEventListener("input", (event) => {
        cancelSearch();
        items = [];
        nextOffset = null;
        searchError = "";
        render();
        if (!event.isComposing) {
            timer = setTimeout(() => search(), 300);
        }
    });
    // Search the completed IME text once the composition has settled.
    input.addEventListener("compositionend", () => {
        clearTimeout(timer);
        timer = setTimeout(() => search(), 300);
    });
    // Request only the server-provided next page, with no concurrent pagination request.
    more.addEventListener("click", () => {
        if (!loading && nextOffset !== null) {
            search(nextOffset);
        }
    });
    // Retry the failed operation: search discovery or exact saved-image hydration.
    retry.addEventListener("click", () => {
        if (searchError) {
            search();
        } else {
            hydrateSelection();
        }
    });
    // Initialize from the host; dialog mode always requires a selection before Apply is valid.
    subscribe("sfcc:ready", (state) => {
        cancelSearch();
        config = state.config;
        messages = window.ContentfulLocalization.create(config);
        document.documentElement.lang = messages.locale;
        document.documentElement.dir = messages.direction;
        dialog = Boolean(config.dialog);
        mediaType = config.mediaType === "video" ? "video" : "image";
        configureMediaLabels();
        transport = window.ContentfulPickerTransport.create(config);
        configError = transport.error;
        value = state.value ?? null;
        required = dialog || state.isRequired;
        disabled = state.isDisabled;
        items = [];
        nextOffset = null;
        hydrateSelection();
        if (dialog) {
            search();
            input.focus();
        }
    });
    // Hydrate a value supplied by the host without echoing another saved-value event.
    subscribe("sfcc:value", (next) => {
        value = next ?? null;
        hydrateSelection();
    });
    // Stop all work when disabled; recheck the selection and reload dialog results when enabled.
    subscribe("sfcc:disabled", (next) => {
        disabled = next;
        cancelSearch();
        selectionRevision++;
        hydrationController?.abort();
        render();
        if (!disabled) {
            hydrateSelection();
            if (dialog) {
                search();
            }
        }
    });
    // Update property-panel requiredness while retaining the modal's required-selection rule.
    subscribe("sfcc:required", (next) => {
        required = dialog || next;
        validate();
    });
    // Cancel pending work and invalidate late completions when the iframe is dismissed.
    window.addEventListener("pagehide", () => {
        cancelSearch();
        selectionRevision++;
        hydrationController?.abort();
    });
})();
