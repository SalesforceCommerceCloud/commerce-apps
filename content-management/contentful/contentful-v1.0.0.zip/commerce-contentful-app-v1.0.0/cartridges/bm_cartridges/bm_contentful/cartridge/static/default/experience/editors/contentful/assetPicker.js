(function(i){"use strict";class o extends i.LitElement{constructor(){super(),this.config={},this.value=null,this.savedAsset=null,this.required=!0,this.disabled=!1,this.messages=window.ContentfulLocalization.create({}),this.configError="",this.warning="",this.searchError="",this.unavailable=!1,this.loading=!1,this.dialog=!1,this.mediaType="image",this.items=[],this.nextOffset=null,this.revision=0,this.selectionRevision=0,this.modalOpen=!1,this.hydrationId="",this.searchText="",this.initialize()}createRenderRoot(){return this}fileSize(e){return e==null?"":e<1024?this.messages.text("size.bytes",this.messages.number(e)):e<1024*1024?this.messages.text("size.kb",this.messages.number(e/1024,1)):this.messages.text("size.mb",this.messages.number(e/(1024*1024),1))}receiveValue(e){const t=e?.assetId;this.value=e==null?null:{assetId:typeof t=="string"&&t.trim()?t:""}}selectedId(){return this.value?.assetId||""}cancelSearch(){clearTimeout(this.timer),this.controller?.abort(),this.revision++,this.loading=!1}requestItems(e,t){return this.transport.request(e,t)}async search(e=0){if(this.cancelSearch(),this.disabled||this.configError||!this.dialog)return;const t=this.revision,s=this.items.length;this.controller=new AbortController,this.searchError="",this.loading=!0,this.validate();try{const a=await this.requestItems({q:this.searchText.trim(),offset:String(e)},this.controller.signal);if(t!==this.revision)return;this.items=[...new Map((e?[...this.items,...a.items]:a.items).map(n=>[n.id,n])).values()],this.nextOffset=a.nextOffset}catch(a){const n=a;if(t!==this.revision||n.name==="AbortError")return;this.searchError=this.messages.text(`${this.mediaType}.searchError`)}finally{t===this.revision&&(this.loading=!1,this.validate(),e&&!this.searchError&&(await this.updateComplete,this.querySelectorAll(".contentful-asset-card")[s]?.focus()))}}async hydrateSelection(){const e=++this.selectionRevision;this.hydrationController?.abort(),this.hydrationController=new AbortController;const t=this.selectedId();if(this.savedAsset=null,this.warning="",(t!==this.hydrationId||!t)&&(this.unavailable=!!(this.value&&!t)),this.hydrationId=t,this.validate(),!(!t||this.configError||this.disabled)){try{const s=await this.requestItems({assetId:t},this.hydrationController.signal);if(e!==this.selectionRevision)return;this.savedAsset=s.items.find(a=>a.id===t)||null,this.unavailable=!this.savedAsset,this.warning=this.unavailable?this.messages.text(`${this.mediaType}.unavailable`):""}catch(s){const a=s;if(e!==this.selectionRevision||a.name==="AbortError")return;this.warning=this.messages.text(`${this.mediaType}.lookupError`)}e===this.selectionRevision&&this.validate()}}image(e){let t=e.url;if(/^image\/(jpe?g|png|webp|gif|avif|tiff)$/.test(e.contentType)&&(e.fileSize===void 0||e.fileSize<=1e8))try{const s=new URL(e.url,window.origin);s.searchParams.set("w","320"),s.searchParams.set("h","200"),s.searchParams.set("fit","pad"),t=s.toString()}catch{}return i.html`<img alt="" loading="lazy" referrerpolicy="no-referrer" src=${t} />`}video(e){return i.keyed(JSON.stringify([e.id,e.url,e.contentType]),i.html`<video controls preload="metadata" playsinline aria-label=${e.label} data-asset-id=${e.id}
                ><source src=${e.url} type=${e.contentType}
            /></video>`)}validity(){const e=this.selectedId();return!this.configError&&(!this.required&&this.value===null||!!(e&&!this.unavailable))}validate(){emit({type:"sfcc:valid",payload:this.validity()}),this.requestUpdate()}card(e){return i.html`<button
            type="button"
            class="contentful-asset-card"
            ?disabled=${this.disabled||!!this.configError}
            aria-pressed=${String(e.id===this.selectedId())}
            @click=${t=>this.selectAsset(e,t.currentTarget)}
            >${this.mediaType==="video"?i.html`<span class="contentful-asset-video-marker" aria-hidden="true">${this.messages.text("video.indicator")}</span>`:this.image(e)}<span>${e.label}</span>${e.width&&e.height?i.html`<small>${this.messages.text("dimensions",this.messages.number(e.width),this.messages.number(e.height))}</small>`:i.nothing}${this.mediaType==="video"?i.html`<small>${[e.contentType,e.fileName,this.fileSize(e.fileSize)].filter(Boolean).join(" · ")}</small>`:i.nothing}</button
        >`}selectAsset(e,t){if(this.disabled||this.configError)return;this.selectionRevision++,this.hydrationController?.abort();const s={assetId:e.id};this.value=s,this.savedAsset=e,t.focus(),this.unavailable=!1,this.warning="",emit({type:"sfcc:value",payload:s}),emit({type:"sfcc:interacted"}),this.validate()}selectedPreview(){return this.savedAsset?this.mediaType==="image"?this.image(this.savedAsset):this.dialog?i.nothing:this.video(this.savedAsset):i.nothing}render(){const e=this.disabled||!!this.configError,t=this.configError||this.searchError||this.warning,s=this.savedAsset?.label||(this.selectedId()?this.messages.text(`${this.mediaType}.saved`,this.selectedId()):this.messages.text(`${this.mediaType}.none`));let a=this.messages.text(`${this.mediaType}.prompt`);return t?a=t:this.loading?a=this.messages.text("searching"):this.dialog&&(a=this.messages.count(`${this.mediaType}.${this.nextOffset!==null?"resultsMore":"results"}`,this.items.length)),i.html`<div class="slds-form-element"
            ><section
                id="contentful-asset-panel"
                ?hidden=${this.dialog}
                aria-label=${this.messages.text(`${this.mediaType}.panel`)}
                ><div id="contentful-asset-preview"
                    >${this.selectedPreview()}<p class="contentful-asset-caption">${s}</p></div
                ><div class="contentful-asset-actions"
                    ><button
                        id="contentful-asset-choose"
                        type="button"
                        class="contentful-asset-button"
                        ?disabled=${e||this.modalOpen}
                        aria-invalid=${String(!this.validity())}
                        @click=${this.onChoose}
                        >${this.messages.text(`${this.mediaType}.choose`)}</button
                    ><button
                        id="contentful-asset-clear"
                        type="button"
                        class="contentful-asset-button"
                        ?disabled=${e||!this.value||this.modalOpen}
                        @click=${this.onClear}
                        >${this.messages.text("clear")}</button
                    ></div
                ></section
            ><section
                id="contentful-asset-browser"
                ?hidden=${!this.dialog}
                aria-label=${this.messages.text(`${this.mediaType}.browser`)}
                ><label class="slds-form-element__label" for="contentful-asset-search"
                    >${this.messages.text(`${this.mediaType}.search`)}</label
                ><input
                    id="contentful-asset-search"
                    class="slds-input"
                    type="search"
                    autocomplete="off"
                    aria-describedby="contentful-asset-status"
                    placeholder=${this.messages.text(`${this.mediaType}.searchPlaceholder`)}
                    ?disabled=${e}
                    @input=${this.onInput}
                    @compositionend=${this.onCompositionEnd}
                /><p id="contentful-asset-selection" class="contentful-asset-caption"
                    >${this.messages.text(`${this.mediaType}.selected`,s)}</p
                ><div id="contentful-asset-dialog-preview" ?hidden=${this.mediaType!=="video"}
                    >${this.dialog&&this.mediaType==="video"&&this.savedAsset?this.video(this.savedAsset):i.nothing}</div
                ><div
                    id="contentful-asset-grid"
                    class="contentful-asset-grid"
                    role="group"
                    aria-label=${this.messages.text(`${this.mediaType}.choices`)}
                    aria-busy=${String(this.loading)}
                    >${i.repeat(this.items,n=>n.id,n=>this.card(n))}</div
                ><button
                    id="contentful-asset-more"
                    type="button"
                    class="contentful-asset-button"
                    ?hidden=${this.nextOffset===null}
                    ?disabled=${e||this.loading}
                    @click=${this.onMore}
                    >${this.messages.text(`${this.mediaType}.more`)}</button
                ></section
            ><p
                id="contentful-asset-status"
                class=${`slds-form-element__help${t?" contentful-asset-status_error":""}`}
                role="status"
                aria-live="polite"
                >${a}</p
            ><button
                id="contentful-asset-retry"
                type="button"
                class="contentful-asset-button"
                ?hidden=${!!this.configError||!(this.searchError||this.warning)}
                ?disabled=${e||this.loading}
                @click=${this.onRetry}
                >${this.messages.text("retry")}</button
            ></div
        >`}onChoose(){if(this.disabled||this.configError||this.modalOpen)return;const e=this.selectionRevision;this.modalOpen=!0,this.validate(),emit({type:"sfcc:breakout",payload:{id:"assetDialog",type:"modal",title:this.messages.text(`${this.mediaType}.dialog`)}},async t=>{if(this.modalOpen=!1,!this.disabled&&e===this.selectionRevision&&t.type==="sfcc:breakoutApply"&&typeof t.value?.assetId=="string"&&t.value.assetId.trim().length>0){const s={assetId:t.value.assetId};this.value=s,emit({type:"sfcc:value",payload:s}),this.hydrateSelection()}emit({type:"sfcc:interacted"}),this.validate(),await this.updateComplete,this.querySelector("#contentful-asset-choose").focus()})}onClear(){this.disabled||this.configError||this.modalOpen||(this.value=null,emit({type:"sfcc:value",payload:null}),emit({type:"sfcc:interacted"}),this.hydrateSelection())}onInput(e){this.searchText=e.target.value,this.cancelSearch(),this.items=[],this.nextOffset=null,this.searchError="",this.validate(),e.isComposing||(this.timer=setTimeout(()=>this.search(),300))}onCompositionEnd(){clearTimeout(this.timer),this.timer=setTimeout(()=>this.search(),300)}onMore(){!this.loading&&this.nextOffset!==null&&this.search(this.nextOffset)}onRetry(){this.searchError?this.search():this.hydrateSelection()}initialize(){subscribe("sfcc:ready",async e=>{this.cancelSearch(),this.config=e.config,this.messages=window.ContentfulLocalization.create(this.config),document.documentElement.lang=this.messages.locale,document.documentElement.dir=this.messages.direction,this.dialog=!!this.config.dialog,this.mediaType=this.config.mediaType==="video"?"video":"image",this.transport=window.ContentfulPickerTransport.create(this.config),this.configError=this.transport.error,this.receiveValue(e.value),this.required=this.dialog||e.isRequired,this.disabled=e.isDisabled,this.items=[],this.nextOffset=null,this.hydrateSelection(),this.dialog&&(this.search(),await this.updateComplete,this.querySelector("input").focus())}),subscribe("sfcc:value",e=>{this.receiveValue(e),this.hydrateSelection()}),subscribe("sfcc:disabled",e=>{this.disabled=e,this.cancelSearch(),this.selectionRevision++,this.hydrationController?.abort(),this.validate(),this.disabled||(this.hydrateSelection(),this.dialog&&this.search())}),subscribe("sfcc:required",e=>{this.required=this.dialog||e,this.validate()}),this.onPageHide=()=>this.dispose()}dispose(){this.cancelSearch(),this.selectionRevision++,this.hydrationController?.abort()}connectedCallback(){super.connectedCallback(),window.addEventListener("pagehide",this.onPageHide)}disconnectedCallback(){window.removeEventListener("pagehide",this.onPageHide),super.disconnectedCallback(),this.dispose()}}customElements.define("contentful-asset-editor",o),document.body.className="contentful-asset-picker",document.body.append(document.createElement("contentful-asset-editor"))})(ContentfulEditorRuntime);
