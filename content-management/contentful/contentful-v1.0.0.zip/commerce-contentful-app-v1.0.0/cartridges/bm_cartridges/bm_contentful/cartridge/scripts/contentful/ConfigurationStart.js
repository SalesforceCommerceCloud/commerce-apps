"use strict";
/**
 * Standalone Script pipelet adapter; this entry point has no CommonJS exports.
 * Build the Configuration page for BM's selected merchant site.
 * @output ContentfulManagement : Object
 */
/* exported execute */
var execute = function execute(pdict) {
    var site = require("bm_contentful/cartridge/scripts/site").getSelectedSite();
    pdict.ContentfulManagement = require("bm_contentful/cartridge/scripts/configuration").view(site);
    return PIPELET_NEXT;
};
