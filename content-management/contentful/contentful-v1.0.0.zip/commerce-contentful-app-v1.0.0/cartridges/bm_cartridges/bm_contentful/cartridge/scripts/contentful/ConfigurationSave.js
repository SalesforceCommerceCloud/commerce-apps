"use strict";
/**
 * Save authorized configuration changes and return a fresh non-secret JSON model.
 * Native BM routing enforces the module grant; this action owns POST/CSRF checks.
 * @output ContentfulManagement : Object
 */
/* exported execute */
var execute = function execute(pdict) {
    var Resource = require("int_contentful/cartridge/scripts/uiResources");
    var CSRFProtection = require("dw/web/CSRFProtection");
    var configuration = require("bm_contentful/cartridge/scripts/configuration");
    var preferences = require("bm_contentful/cartridge/scripts/preferences");
    var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
    var site = require("bm_contentful/cartridge/scripts/site").getSelectedSite();
    var errorMessage = "";
    var saved = false;
    if (site) {
        if (request.httpMethod !== "POST" || !CSRFProtection.validateRequest()) {
            errorMessage = Resource.msg("error.request", "contentfulManagement", null);
        }
        else {
            var values = void 0;
            try {
                values = configuration.parseSubmission(request.httpParameterMap);
            }
            catch (error) {
                diagnostics.log("warn", "management.configuration_input_invalid", {
                    errorType: diagnostics.errorType(error),
                });
                // The parser throws only fixed, localized validation messages.
                errorMessage = error.message;
            }
            if (values) {
                try {
                    preferences.writePreferences(site, values);
                    saved = true;
                }
                catch (error) {
                    diagnostics.log("warn", "management.configuration_write_failed", {
                        errorType: diagnostics.errorType(error),
                    });
                    errorMessage = Resource.msg("error.save", "contentfulManagement", null);
                }
            }
        }
    }
    var view = configuration.view(site);
    if (errorMessage) {
        view.error = errorMessage;
    }
    view.saved = saved;
    pdict.ContentfulManagement = view;
    configuration.respond(view, response);
    return PIPELET_NEXT;
};
