(function(s){"use strict";const p=new Map(Object.entries({request_denied:"setup.requestDenied",site_required:"setup.siteRequired",site_changed:"setup.siteChanged",setup_expired:"setup.expired",credential_invalid:"setup.credentialInvalid",management_unauthorized:"setup.managementUnauthorized",contentful_busy:"setup.contentfulBusy",spaces_denied:"setup.spacesDenied",spaces_failed:"setup.spacesFailed",options_denied:"setup.optionsDenied",options_failed:"setup.optionsFailed",space_unavailable:"setup.spaceUnavailable",key_unavailable:"setup.keyUnavailable",key_failed:"setup.keyFailed",save_failed:"setup.saveFailed",delivery_not_enabled:"setup.deliveryNotEnabled"}));class f extends s.LitElement{constructor(){super(),this.credentialTimers=new Map,this.initialized=!1,this.revision=0,this.exportRevision=0,this.expanded=new Set,this.leave=()=>{this.cancel(),this.clearExports(),this.clearPat()},this.restore=t=>{this.clearPat(),t.persisted&&this.model.csrf&&this.resume()},this.busy=!1,this.connected=!1,this.spaces=[],this.available={keys:[],aliases:[],environments:[]},this.spaceId="",this.keyId="",this.environment="",this.finished=!1,this.setupStatus="",this.setupSnippet="",this.credentials=[],this.drafts={},this.copyNotification=null,this.manualUnavailable=!1,this.hasPat=!1,this.patError=""}static{this.properties=Object.fromEntries(["model","busy","connected","spaces","available","spaceId","keyId","environment","finished","setupStatus","setupSnippet","credentials","drafts","copyNotification","manualUnavailable","hasPat","patError"].map(t=>[t,{state:!0}]))}createRenderRoot(){return this}shouldUpdate(){return this.isConnected}connectedCallback(){if(!this.initialized){const t=this.getAttribute("data-initial-model");this.removeAttribute("data-initial-model"),this.model=JSON.parse(t),this.initialized=!0}super.connectedCallback(),window.addEventListener("pagehide",this.leave),window.addEventListener("pageshow",this.restore),this.requestUpdate(),this.model.csrf&&this.resume()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("pagehide",this.leave),window.removeEventListener("pageshow",this.restore),this.leave()}t(t){return this.model.messages[t]}icon(t,e="cf-icon"){return s.html`<svg class=${e} aria-hidden="true" focusable="false">
            <use href=${`${this.dataset.icons}#${t}`}></use>
        </svg>`}cancel(){this.controller?.abort(),this.revision++,this.busy=!1}clearPat(){this.querySelectorAll("[data-setup-pat]").forEach(t=>{t.value=""}),this.hasPat=!1,this.patError=""}clearExports(){this.exportRevision++,this.credentialTimers.forEach(t=>window.clearTimeout(t)),this.credentialTimers.clear(),this.credentials=[],clearTimeout(this.copyNotificationTimer),this.copyNotification=null,this.setupSnippet="",this.querySelectorAll("code").forEach(t=>{t.textContent=""})}async request(t,e){const i=this.revision,o=new URL(t,window.location.href);if(o.origin!==window.location.origin||o.protocol!=="https:")throw new Error("Invalid endpoint");const a=await fetch(o.href,{method:e?"POST":"GET",credentials:"same-origin",cache:"no-store",redirect:"error",headers:{"X-Requested-With":"XMLHttpRequest","Content-Type":"application/x-www-form-urlencoded","Cache-Control":"no-store"},body:e?.toString(),signal:this.controller.signal}),n=a.headers.get("Content-Type")?.includes("application/json"),l=n?await a.json():{};if(i!==this.revision||!this.isConnected)throw new DOMException("Request superseded","AbortError");if(!a.ok||!n)throw Object.assign(new Error("Configuration request failed"),{code:l?.code||([401,403].includes(a.status)?"request_denied":"")});return l}async readModel(t,e){const i=await this.request(t,e);if(i?.page!=="Configuration")throw new Error("Configuration model unavailable");if(!i.csrf&&(!i.error||i.fields.length))throw new Error("Editable configuration requires CSRF");return i}post(t,e={}){return this.request(this.dataset.endpoint,new URLSearchParams({...e,action:t,[this.model.csrf.name]:this.model.csrf.token}))}async run(t,e=!1){if(this.busy)return;const i=++this.revision;this.controller=new AbortController,this.busy=!0,e||(this.setupStatus=this.t("setup.working"));try{await t()}catch(o){if(i!==this.revision||!this.isConnected)return;const a=o;if(e)this.model={...this.model,saved:!1,error:this.t("error.request")};else{["setup_expired","management_unauthorized","credential_invalid"].includes(a.code)&&this.connection({connected:!1});const n=this.t(p.get(a.code)||"setup.error");["credential_invalid","management_unauthorized"].includes(a.code)?(this.patError=n,this.setupStatus=""):this.setupStatus=n}}finally{i===this.revision&&(this.busy=!1)}}connection(t){this.clearPat(),this.connected=t.connected,this.spaces=t.connected?t.spaces:[],this.available={keys:[],aliases:[],environments:[]},this.spaceId="",this.keyId="",this.environment="",this.finished=!1,this.setupStatus=t.connected&&!t.spaces.length?this.t("setup.noSpaces"):""}resume(){return this.run(async()=>{this.connection(await this.post("resume"))})}connect(){const t=this.querySelector("#cf-setup-pat");if(!t.checkValidity()){this.patError=this.t("setup.patRequired");return}const e=t.value;t.value="",this.hasPat=!1,this.patError="";const i=this.querySelector("#cf-setup-region").value;return this.clearExports(),this.run(async()=>{await this.post("connect",{personalAccessToken:e,region:i}),this.connection(await this.post("resume"))})}async changeSpace(t){this.cancel(),this.clearExports(),this.spaceId=t.currentTarget.value,this.keyId="",this.environment="",this.available={keys:[],aliases:[],environments:[]},this.setupStatus="",this.spaceId&&await this.run(async()=>{this.available=await this.post("options",{spaceId:this.spaceId}),this.setupStatus=this.available.keys.length?"":this.t("setup.noKeys")})}get selectedKey(){return this.available.keys.find(t=>t.id===this.keyId)}changeKey(t){this.keyId=t.currentTarget.value,this.environment="",this.clearExports(),this.setupStatus=this.selectedKey&&!this.environmentChoices.length?this.t("setup.noEnvironments"):""}get environmentChoices(){const t=this.selectedKey?.environments||[];return[...this.available.aliases,...this.available.environments].filter(e=>t.includes(e.id))}saveConnection(){return this.clearExports(),this.run(async()=>{const t=this.revision,e=this.selectedKey;if(!e||!this.environment)return;const i=await this.post("save",{spaceId:e.spaceId,keyId:e.id,environment:this.environment});this.finished=!0,this.setupSnippet=i.snippet,this.credentials=i.credentials,this.setupStatus="";try{const o=await this.readModel(this.dataset.configurationUrl);this.drafts=Object.fromEntries(Object.entries(this.drafts).filter(([a])=>this.model.fields.some(n=>n.id===a&&n.section==="Rendering"))),this.model=o,this.clearPat(),this.manualUnavailable=!1}catch(o){if(t!==this.revision||!this.isConnected)throw o;this.manualUnavailable=!0,this.setupStatus=this.t("setup.refreshFailed")}})}cancelSetup(){return this.clearPat(),this.clearExports(),this.run(async()=>{await this.post("cancel"),this.connection({connected:!1})})}fieldInput(t,e){const i=e.currentTarget;this.drafts={...this.drafts,[t.id]:t.type==="boolean"?i.checked:i.value}}submit(t){t.preventDefault();const e=new URLSearchParams(Array.from(new FormData(t.currentTarget)));return this.clearExports(),this.clearPat(),this.run(async()=>{const i=await this.readModel(this.dataset.saveUrl,e);this.model=i,i.saved&&(this.drafts={})},!0)}reset(t){t.preventDefault(),this.clearExports(),this.clearPat(),this.drafts={}}async copy(t){const e=this.exportRevision;let i=this.setupSnippet,o="#cf-setup-snippet",a="#cf-export-copy-status",n="[data-setup-copy]";t.startsWith("credential-")&&(i=this.credentials.find(d=>t===`credential-${d.kind}`).token,o=`#cf-${t}-token`,a=`#cf-${t}-copy-status`,n=`#cf-${t}-copy`);let l=!0;try{await navigator.clipboard.writeText(i)}catch{l=!1}if(e!==this.exportRevision||!this.isConnected)return;if(!l){const d=this.querySelector(o);d.focus();const h=document.createRange();h.selectNodeContents(d);const u=window.getSelection();u.removeAllRanges(),u.addRange(h)}clearTimeout(this.copyNotificationTimer);let c="setup.copied";l||(c=t.startsWith("credential-")?"setup.keyCopyFallback":"setup.copyFallback");const r={kind:t,message:this.t(c)};if(this.copyNotification=r,await this.updateComplete,this.copyNotification!==r)return;const m=this.querySelector(a),b=this.querySelector(n);m.showPopover({source:b}),this.copyNotificationTimer=window.setTimeout(()=>{this.copyNotification=null},l?3e3:8e3)}checkCredential(t){const e=this.exportRevision;return this.credentials=this.credentials.map(i=>i.kind===t?{...i,state:"checking",detail:""}:i),this.run(async()=>{try{const i=await this.post("checkCredential",{kind:t,expectedSiteId:this.model.siteId});e===this.exportRevision&&(this.credentials=this.credentials.map(o=>o.kind===t?{...o,...i}:o),this.model={...this.model,credentials:this.model.credentials.map(o=>o.kind===t?{...o,isSet:i.isSet}:o)},this.setupStatus="")}catch(i){if(e===this.exportRevision){const o=i,a=this.t(p.get(o.code)||"setup.credentialCheckFailed");this.credentials=this.credentials.map(n=>n.kind===t?{...n,state:"unavailable",detail:a}:n),this.setupStatus=""}}})}editCredential(t,e){t.preventDefault(),this.copy(`credential-${e.kind}`);const i=window.open(e.url,`contentful-${e.kind}`,"popup,width=1000,height=760");if(window.clearTimeout(this.credentialTimers.get(e.kind)),!i){this.setupStatus=this.t("setup.popupBlocked");return}let o,a=!1;const n=()=>{const l=i.closed;let c=l;if(l)a=!0;else try{const r=i.document;r.URL!=="about:blank"&&(o&&r!==o&&(a=!0),o=r,c=r.readyState==="complete")}catch{}a&&c&&!this.busy&&(a=!1,this.checkCredential(e.kind)),!l||a?this.credentialTimers.set(e.kind,window.setTimeout(n,500)):this.credentialTimers.delete(e.kind)};this.credentialTimers.set(e.kind,window.setTimeout(n,500))}credentialBlocks(){return s.html`<section aria-labelledby="cf-service-credentials" class="slds-p-top_medium">
            <h3 id="cf-service-credentials" class="cf-subsection-title slds-p-bottom_small"
                >${this.t("setup.serviceCredentials")}</h3
            >
            <p class="cf-description slds-p-bottom_medium">${this.t("setup.credentialHelp")}</p>
            <div class="slds-scrollable_x" role="region" aria-label=${this.t("setup.serviceCredentials")} tabindex="0">
                <table class="cf-credential-table slds-table slds-table_cell-buffer slds-table_bordered">
                    <thead
                        ><tr>
                            <th scope="col">${this.t("setup.credential")}</th>
                            <th scope="col">${this.t("setup.apiKey")}</th>
                            <th scope="col">${this.t("status.state")}</th>
                        </tr></thead
                    >
                    <tbody
                        >${s.repeat(this.credentials,t=>t.kind,t=>{const e=`credential-${t.kind}`,i=t.state||(t.isSet?"configured":"notConfigured"),o=this.t(i==="unavailable"?"setup.credentialError":`state.${i}`),a=i==="configured"?this.t("setup.credentialConfigured"):t.detail||"",n=a?`${o}: ${a}`:o;let l="neutral",c="close";return i==="configured"||i==="connected"?(l="good",c=i==="connected"?"success":"key"):i==="unavailable"?(l="error",c="error"):i==="checking"&&(c="refresh"),s.html`<tr data-credential=${t.kind}>
                                    <td class="slds-cell-wrap">
                                        ${t.url?s.html`<a href=${t.url} @click=${r=>this.editCredential(r,t)}><strong>${this.t(`mode.${t.kind}`)}</strong></a>`:s.html`${this.t(`mode.${t.kind}`)}<p>${this.t("setup.credentialMissing")}</p>`}
                                    </td>
                                    <td class="slds-cell-wrap"
                                        ><div class="cf-code-block slds-box slds-theme_shade slds-p-around_small">
                                            <code
                                                id=${`cf-${e}-token`}
                                                class="cf-code-lines"
                                                tabindex="0"
                                                .textContent=${t.token}
                                            ></code>
                                            <button
                                                id=${`cf-${e}-copy`}
                                                type="button"
                                                class="slds-button slds-button_icon slds-button_icon-border-filled"
                                                title=${this.t("setup.copyKey")}
                                                aria-label=${this.t("setup.copyKey")}
                                                aria-controls=${`cf-${e}-copy-status`}
                                                @click=${()=>this.copy(e)}
                                                >${this.icon("copy","slds-button__icon")}</button
                                            >
                                        </div>
                                        ${this.copyNotification?.kind===e?s.html`<span id=${`cf-${e}-copy-status`} class="cf-copy-notification slds-p-around_small" popover="auto" role="status">${this.copyNotification.message}</span>`:s.nothing}
                                    </td>
                                    <td class="slds-cell-wrap"
                                        ><p
                                            role="status"
                                            class=${`cf-status cf-status--${l}`}
                                            title=${a}
                                            aria-label=${n}
                                            >${this.icon(c)}<span>${o}</span></p
                                        >
                                    </td>
                                </tr>`})}</tbody
                    >
                </table>
            </div>
        </section>`}exportBlock(){const t=this.setupSnippet;return s.html`<div ?hidden=${!t} data-setup-export class="slds-p-top_medium">
            <h3 id="cf-export-label" class="cf-subsection-title slds-p-bottom_small">${this.t("setup.export")}</h3>
            <p class="cf-description slds-p-bottom_medium" data-export-help>${this.t("setup.exportHelp")}</p>
            <div
                class="cf-code-block slds-box slds-theme_shade slds-p-around_small"
                role="group"
                aria-labelledby="cf-export-label"
            >
                <code id="cf-setup-snippet" class="cf-code-lines" tabindex="0" .textContent=${t}></code>
                <button
                    type="button"
                    class="slds-button slds-button_icon slds-button_icon-border-filled"
                    data-setup-copy
                    title=${this.t("setup.copy")}
                    aria-label=${this.t("setup.copy")}
                    aria-controls="cf-export-copy-status"
                    @click=${()=>this.copy("setup")}
                    >${this.icon("copy","slds-button__icon")}</button
                >
            </div>
            ${this.copyNotification?.kind==="setup"?s.html`<p
                          id="cf-export-copy-status"
                          data-copy-notification
                          data-export-copy-status
                          popover="auto"
                          role="status"
                          aria-live="polite"
                          class="cf-copy-notification slds-p-around_small"
                          >${this.copyNotification.message}</p
                      >`:s.nothing}
        </div>`}field(t){const e=this.drafts[t.id]??t.value,i=this.busy||this.manualUnavailable,o=s.html`<label class="slds-form-element__label" for=${t.id} title=${t.help}
            >${t.label}${this.icon("info","cf-field-help cf-icon")}</label
        >`;let a;return t.type==="boolean"?a=s.html`<div class="slds-checkbox"
                ><input
                    type="checkbox"
                    id=${t.id}
                    name=${t.id}
                    value="true"
                    .checked=${s.live(e===!0)}
                    ?disabled=${i}
                    aria-describedby=${`${t.id}Description`}
                    @change=${n=>this.fieldInput(t,n)}
                /><label class="slds-checkbox__label" for=${t.id} title=${t.help}
                    ><span class="slds-checkbox_faux" aria-hidden="true"></span
                    ><span class="slds-form-element__label">${t.label}</span></label
                ></div
            >`:t.type==="number"?a=s.html`${o}<input
                    class="slds-input"
                    type="number"
                    id=${t.id}
                    name=${t.id}
                    .value=${s.live(String(e))}
                    min=${t.min}
                    max=${t.max}
                    step="1"
                    ?disabled=${i}
                    aria-describedby=${`${t.id}Description`}
                    @input=${n=>this.fieldInput(t,n)}
                />`:a=s.html`${o}<input
                    class="slds-input"
                    type="text"
                    id=${t.id}
                    name=${t.id}
                    .value=${s.live(String(e))}
                    placeholder=${t.id==="contentfulPreviewEditorOrigin"?this.t("field.contentfulPreviewEditorOrigin.placeholder"):""}
                    ?disabled=${i}
                    aria-describedby=${`${t.id}Description`}
                    @input=${n=>this.fieldInput(t,n)}
                />`,s.html`<div class="slds-form-element slds-p-bottom_medium"
            ><div class="slds-form-element__control"
                >${a}<span class="slds-assistive-text" id=${`${t.id}Description`}>${t.help}</span></div
            ></div
        >`}connectionApis(){return s.repeat(this.model.credentials,t=>t.kind,t=>{const e=t.kind==="preview",i=e?"Preview API":"Delivery API",o=e?"PreviewApiHeading":"DeliveryApiHeading",a=this.t(`credential.${t.kind}.label`);return s.html`<section class="cf-subsection slds-border_top slds-p-top_medium" aria-labelledby=${o}>
                    <h3 class="cf-subsection-title slds-p-bottom_medium" id=${o}
                        >${this.t(e?"group.PreviewApi":"group.DeliveryApi")}</h3
                    >
                    <div class="cf-status-card slds-box slds-m-bottom_medium" data-connected-key=${t.kind}>
                        <h4 class="cf-card-label"
                            >${t.url?s.html`<a href=${t.url} target="_blank" rel="noopener noreferrer">${a}<span class="slds-assistive-text">${this.t("link.newTab")}</span></a>`:a}</h4
                        >
                        <p class=${`cf-status ${t.isSet?"cf-status--good":"cf-status--neutral"}`}>
                            ${this.icon(t.isSet?"key":"close")}<span
                                >${this.t(t.isSet?"state.configured":"state.notConfigured")}</span
                            >
                        </p>
                        ${t.url?s.nothing:s.html`<p class="cf-description slds-p-top_small">${this.t("setup.credentialMissing")}</p>`}
                    </div>
                    ${s.repeat(this.model.fields.filter(n=>n.group===i),n=>n.id,n=>this.field(n))}
                </section>`})}manual(){return s.html`<form
            class="cf-settings-form slds-form"
            method="post"
            action=${this.dataset.saveUrl}
            autocomplete="off"
            @submit=${this.submit}
            @reset=${this.reset}
        >
            <input type="hidden" name=${this.model.csrf.name} value=${this.model.csrf.token} />
            ${s.repeat(this.model.sections,t=>t,t=>s.html`<details
                        class="cf-section slds-box slds-m-bottom_large"
                        aria-labelledby=${`${t}Heading`}
                        .open=${this.expanded.has(t)}
                        @toggle=${e=>{e.currentTarget.open?this.expanded.add(t):this.expanded.delete(t)}}
                    >
                        <summary class="cf-section-summary" id=${`${t}Heading`}
                            ><h2 class="cf-section-title">${this.t(`section.${t}`)}</h2></summary
                        ><div class="cf-section-fields slds-p-top_medium">
                            ${t==="Connection"?s.html`<p class="cf-description slds-p-bottom_medium">${this.t("section.Connection.description")}</p>`:s.nothing}
                            ${t==="LivePreview"?s.html`<p class="cf-description slds-p-bottom_medium">${this.t("previewSecret.description")}</p>`:s.nothing}
                            ${s.repeat(this.model.fields.filter(e=>e.section===t&&!e.group),e=>e.id,e=>this.field(e))}
                            ${t==="Connection"?this.connectionApis():s.nothing}
                        </div></details
                    >`)}
            <button class="slds-button slds-button_brand" type="submit" ?disabled=${this.busy||this.manualUnavailable}
                >${this.t("configuration.save")}</button
            >
        </form>`}choices(t){return s.html`<option value="">${this.t("setup.choose")}</option>${s.repeat(t,e=>e.id,e=>s.html`<option value=${e.id}>${e.label}</option>`)}`}guided(){const t=this.selectedKey,e=!this.busy&&!this.finished&&!!(this.spaceId&&t&&this.environment),[i,o]=this.t("setup.description").split("{0}");return s.html`<section
            id="contentful-guided-setup"
            class="cf-section slds-box slds-m-bottom_large"
            aria-labelledby="GuidedSetupHeading"
            aria-busy=${String(this.busy)}
        >
            <h2 id="GuidedSetupHeading" class="cf-section-title slds-p-bottom_medium"
                >${this.t("setup.title")}
                ${this.finished?s.html`<span data-setup-completed class="cf-status cf-status--good" role="status">${this.icon("success")}<span>${this.t("setup.completed")}</span></span>`:s.nothing}</h2
            >
            ${!this.connected&&!this.finished?s.html`<p class="cf-description slds-p-bottom_medium" data-setup-description
                          >${i}<a
                              href="https://app.contentful.com/account/profile/cma_tokens"
                              target="_blank"
                              rel="noopener noreferrer"
                              >${this.t("setup.personalAccessToken")}<span class="slds-assistive-text"
                                  >${this.t("link.newTab")}</span
                              ></a
                          >${o}</p
                      >`:s.nothing}
            ${this.connected&&!this.finished?s.html`<p class="cf-description slds-p-bottom_medium" data-setup-selection-help>${this.t("setup.selectionHelp")}</p>`:s.nothing}
            <div data-setup-connect ?hidden=${this.connected}>
                <div class=${`slds-form-element slds-p-bottom_medium${this.patError?" slds-has-error":""}`}
                    ><label class="slds-form-element__label" for="cf-setup-pat" title=${this.t("setup.patHelp")}
                        >${this.t("setup.pat")}${this.icon("info","cf-field-help cf-icon")}</label
                    ><div class="slds-form-element__control"
                        ><input
                            class="slds-input"
                            id="cf-setup-pat"
                            data-setup-pat
                            type="password"
                            required
                            pattern=".*\\S.*"
                            autocomplete="off"
                            spellcheck="false"
                            autocapitalize="none"
                            aria-describedby=${this.patError?"cf-setup-pat-help cf-setup-pat-error":"cf-setup-pat-help"}
                            aria-invalid=${this.patError?"true":s.nothing}
                            ?disabled=${this.busy}
                            @input=${a=>{this.hasPat=a.currentTarget.validity.valid,this.patError=""}}
                            @change=${a=>{this.patError=a.currentTarget.validity.valid?"":this.t("setup.patRequired")}}
                            @keydown=${a=>{a.key==="Enter"&&!this.busy&&this.hasPat&&(a.preventDefault(),this.connect())}}
                        /><span id="cf-setup-pat-help" class="slds-assistive-text">${this.t("setup.patHelp")}</span
                        >${this.patError?s.html`<div id="cf-setup-pat-error" data-setup-pat-error class="slds-form-element__help" role="alert">${this.patError}</div>`:s.nothing}</div
                    ></div
                >
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-region">${this.t("setup.region")}</label
                    ><div class="slds-form-element__control"
                        ><select class="slds-select" id="cf-setup-region" ?disabled=${this.busy}
                            ><option value="us">US</option
                            ><option value="eu">EU</option></select
                        ></div
                    ></div
                >
            </div>
            <div data-setup-choices ?hidden=${!this.connected||this.finished}>
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-space">${this.t("setup.space")}</label
                    ><div class="slds-form-element__control"
                        ><select
                            class="slds-select"
                            id="cf-setup-space"
                            required
                            ?disabled=${this.busy||!this.spaces.length}
                            .value=${this.spaceId}
                            @change=${this.changeSpace}
                            >${this.choices(this.spaces)}</select
                        ></div
                    ></div
                >
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-key">${this.t("setup.apiKey")}</label
                    ><div class="slds-form-element__control"
                        ><select
                            class="slds-select"
                            id="cf-setup-key"
                            required
                            ?disabled=${this.busy||!this.available.keys.length}
                            .value=${this.keyId}
                            @change=${this.changeKey}
                            >${this.choices(this.available.keys)}</select
                        ></div
                    ></div
                >
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-environment"
                        >${this.t("setup.environment")}</label
                    ><div class="slds-form-element__control"
                        ><select
                            class="slds-select"
                            id="cf-setup-environment"
                            required
                            ?disabled=${this.busy||!this.environmentChoices.length}
                            .value=${this.environment}
                            @change=${a=>{this.clearExports(),this.environment=a.currentTarget.value}}
                            ><option value="">${this.t("setup.choose")}</option
                            >${["aliases","environments"].map(a=>{const n=this.available[a].filter(l=>t?.environments.includes(l.id));return n.length?s.html`<optgroup label=${this.t(`setup.${a}`)}
                                          >${s.repeat(n,l=>l.id,l=>s.html`<option value=${l.id}>${l.label}</option>`)}</optgroup
                                      >`:s.nothing})}</select
                        ></div
                    ></div
                >
            </div>
            ${this.finished?s.nothing:s.html`<div>
                          ${this.connected?s.html`<button class="slds-button slds-button_brand" type="button" data-setup-save ?disabled=${!e} @click=${this.saveConnection}>${this.t("setup.save")}</button>`:s.html`<button class="slds-button slds-button_brand" type="button" data-setup-connect-button ?disabled=${this.busy||!this.hasPat} @click=${this.connect}>${this.t("setup.connect")}</button>`}
                          ${this.connected||this.hasPat?s.html`<button class="slds-button slds-button_neutral" type="button" data-setup-cancel ?disabled=${this.busy} @click=${this.cancelSetup}>${this.t("setup.cancel")}</button>`:s.nothing}
                      </div>`}
            <div data-setup-status role="status" aria-live="polite"
                >${this.setupStatus?s.html`<p class="cf-description slds-p-top_small"><span data-setup-status-text>${this.setupStatus}</span></p>`:s.nothing}</div
            >
            <div data-setup-next-steps ?hidden=${!this.setupSnippet}>
                <p class="cf-description">${this.t("setup.nextSteps")}</p>
                ${this.credentialBlocks()} ${this.exportBlock()}
            </div>
        </section>`}render(){return s.html`<div
            id="contentful-management"
            class="contentful-management slds-p-around_large slds-theme_default"
            aria-busy=${String(this.busy)}
            ><h1 class="cf-page-title slds-text-heading_medium slds-p-bottom_large"
                >${this.t("configuration.title")}</h1
            >
            ${this.model.error?s.html`<p class="cf-notice slds-scoped-notification slds-theme_error slds-p-around_small slds-m-bottom_medium" role="alert">${this.icon("error")}${this.model.error}</p>`:s.nothing}
            ${this.model.saved?s.html`<p class="cf-notice slds-scoped-notification slds-theme_success slds-p-around_small slds-m-bottom_medium" role="status">${this.icon("success")}${this.t("configuration.saved")}</p>`:s.nothing}
            ${this.model.csrf?s.html`<p class="cf-description slds-p-bottom_large">${this.t("configuration.description")}</p>${this.guided()}${this.manual()}`:s.nothing}
        </div>`}}customElements.define("contentful-configuration",f)})(ContentfulEditorRuntime);
