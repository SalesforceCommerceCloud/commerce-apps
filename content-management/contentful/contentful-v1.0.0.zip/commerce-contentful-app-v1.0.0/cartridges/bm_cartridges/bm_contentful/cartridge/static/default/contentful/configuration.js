/** Keep password replacement/clearing mutually exclusive; export only the newly saved preview secret. */
(() => {
    "use strict";
    function reconcile() {
        document.querySelectorAll("#contentful-management .cf-key-actions").forEach((actions) => {
            const input = actions.parentElement.querySelector('input[type="password"]');
            const clear = actions.querySelector('input[type="checkbox"]');
            // No saved key: the server omits the clear option entirely.
            if (!clear) {
                return;
            }
            const replacing = input.value.trim().length > 0;
            if (replacing) {
                clear.checked = false;
            }
            clear.disabled = replacing;
            input.disabled = clear.checked;
        });
    }
    // Delegation also covers the freshly rendered form after a guided save.
    ["input", "change"].forEach((name) =>
        document.addEventListener(name, (event) => {
            if (event.target.closest?.("#contentful-management")) {
                reconcile();
            }
        }),
    );
    document.addEventListener("reset", (event) => {
        if (event.target.closest?.("#contentful-management")) {
            queueMicrotask(reconcile);
        }
    });
    window.addEventListener("pageshow", reconcile);
    reconcile();
    const exported = document.querySelector("[data-preview-secret-export]");
    if (exported) {
        const snippet = exported.querySelector("[data-preview-secret-snippet]");
        snippet.textContent = snippet.textContent.trim();
        const copy = exported.querySelector("[data-preview-secret-copy]");
        const feedback = exported.querySelector("[data-preview-secret-copy-status]");
        let cleared = false;
        function clearExport() {
            cleared = true;
            snippet.textContent = "";
            feedback.textContent = "";
            exported.hidden = true;
        }
        copy.addEventListener("click", async () => {
            try {
                await navigator.clipboard.writeText(snippet.textContent);
                if (!cleared) {
                    feedback.textContent = copy.dataset.copied;
                }
            } catch {
                if (!cleared) {
                    snippet.focus();
                    const range = document.createRange();
                    range.selectNodeContents(snippet);
                    const selection = window.getSelection();
                    selection.removeAllRanges();
                    selection.addRange(range);
                    feedback.textContent = copy.dataset.fallback;
                }
            }
        });
        window.addEventListener("pagehide", clearExport);
        document.addEventListener("submit", clearExport);
    }
})();
