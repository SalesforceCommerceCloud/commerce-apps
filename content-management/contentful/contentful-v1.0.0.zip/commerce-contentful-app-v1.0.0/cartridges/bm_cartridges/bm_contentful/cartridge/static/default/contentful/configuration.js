(function(i){"use strict";const d=new Map(Object.entries({request_denied:"setup.requestDenied",site_required:"setup.siteRequired",setup_expired:"setup.expired",credential_invalid:"setup.credentialInvalid",management_unauthorized:"setup.managementUnauthorized",contentful_busy:"setup.contentfulBusy",spaces_denied:"setup.spacesDenied",spaces_failed:"setup.spacesFailed",options_denied:"setup.optionsDenied",options_failed:"setup.optionsFailed",space_unavailable:"setup.spaceUnavailable",key_unavailable:"setup.keyUnavailable",key_failed:"setup.keyFailed",preview_key_unavailable:"setup.previewKeyUnavailable",preview_key_failed:"setup.previewKeyFailed",save_failed:"setup.saveFailed",delivery_failed:"setup.deliveryFailed",preview_failed:"setup.previewFailed",delivery_not_enabled:"setup.deliveryNotEnabled",delivery_denied:"setup.deliveryDenied",delivery_unavailable:"setup.deliveryUnavailable",preview_denied:"setup.previewDenied",preview_unavailable:"setup.previewUnavailable"}));class p extends i.LitElement{constructor(){super(),this.initialized=!1,this.revision=0,this.exportRevision=0,this.expanded=new Set,this.leave=()=>{this.cancel(),this.clearExports(),this.clearPasswords()},this.restore=e=>{for(const t of this.model.fields.filter(s=>s.type==="password")){const s=this.querySelector(`#${t.id}`);this.fieldInput(t,{currentTarget:s})}e.persisted&&this.model.csrf&&this.resume()},this.previewSnippet="",this.busy=!1,this.connected=!1,this.spaces=[],this.available={keys:[],aliases:[],environments:[]},this.spaceId="",this.keyId="",this.environment="",this.includePreview=!1,this.finished=!1,this.setupStatus="",this.complete=!1,this.setupSnippet="",this.passwordEntered=new Set,this.clears=new Set,this.drafts={},this.copyNotification=null,this.manualUnavailable=!1,this.hasPat=!1}static{this.properties=Object.fromEntries(["model","busy","connected","spaces","available","spaceId","keyId","environment","includePreview","finished","setupStatus","complete","setupSnippet","previewSnippet","passwordEntered","clears","drafts","copyNotification","manualUnavailable","hasPat"].map(e=>[e,{state:!0}]))}createRenderRoot(){return this}shouldUpdate(){return this.isConnected}connectedCallback(){if(!this.initialized){const e=this.getAttribute("data-initial-model");this.removeAttribute("data-initial-model"),this.model=JSON.parse(e),this.previewSnippet=this.model.previewSecretExport||"",delete this.model.previewSecretExport,this.previewSnippet&&this.expanded.add("LivePreview"),this.initialized=!0}super.connectedCallback(),window.addEventListener("pagehide",this.leave),window.addEventListener("pageshow",this.restore),this.requestUpdate(),this.model.csrf&&this.resume()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("pagehide",this.leave),window.removeEventListener("pageshow",this.restore),this.leave()}t(e){return this.model.messages[e]}icon(e,t="cf-icon"){return i.html`<svg class=${t} aria-hidden="true" focusable="false">
            <use href=${`${this.dataset.icons}#${e}`}></use>
        </svg>`}cancel(){this.controller?.abort(),this.revision++,this.busy=!1}clearPasswords(){this.querySelectorAll('input[type="password"]').forEach(e=>{e.value=""}),this.passwordEntered=new Set,this.hasPat=!1}clearExports(){this.exportRevision++,clearTimeout(this.copyNotificationTimer),this.copyNotification=null,this.setupSnippet="",this.previewSnippet="",this.querySelectorAll("code").forEach(e=>{e.textContent=""})}async request(e,t){const s=this.revision,n=new URL(e,window.location.href);if(n.origin!==window.location.origin||n.protocol!=="https:")throw new Error("Invalid endpoint");const a=await fetch(n.href,{method:t?"POST":"GET",credentials:"same-origin",cache:"no-store",redirect:"error",headers:{"X-Requested-With":"XMLHttpRequest","Content-Type":"application/x-www-form-urlencoded","Cache-Control":"no-store"},body:t?.toString(),signal:this.controller.signal}),l=a.headers.get("Content-Type")?.includes("application/json"),o=l?await a.json():{};if(s!==this.revision||!this.isConnected)throw new DOMException("Request superseded","AbortError");if(!a.ok||!l)throw Object.assign(new Error("Configuration request failed"),{code:o?.code||([401,403].includes(a.status)?"request_denied":"")});return o}async readModel(e,t){const s=await this.request(e,t);if(s?.page!=="Configuration")throw new Error("Configuration model unavailable");if(!s.csrf&&(!s.error||s.fields.length))throw new Error("Editable configuration requires CSRF");return s}post(e,t={}){return this.request(this.dataset.endpoint,new URLSearchParams({...t,action:e,[this.model.csrf.name]:this.model.csrf.token}))}async run(e,t=!1){if(this.busy)return;const s=++this.revision;this.controller=new AbortController,this.busy=!0,t||(this.setupStatus=this.t("setup.working"),this.complete=!1);try{await e()}catch(n){if(s!==this.revision||!this.isConnected)return;const a=n;t?this.model={...this.model,saved:!1,error:this.t("error.request")}:(["setup_expired","management_unauthorized"].includes(a.code)&&this.connection({connected:!1}),this.setupStatus=this.t(d.get(a.code)||"setup.error"))}finally{s===this.revision&&(this.busy=!1)}}connection(e){this.clearPasswords(),this.connected=e.connected,this.spaces=e.connected?e.spaces:[],this.available={keys:[],aliases:[],environments:[]},this.spaceId="",this.keyId="",this.environment="",this.includePreview=!1,this.finished=!1,this.setupStatus=e.connected&&!e.spaces.length?this.t("setup.noSpaces"):""}resume(){return this.run(async()=>{this.connection(await this.post("resume"))})}connect(){const e=this.querySelector("#cf-setup-pat"),t=e.value;e.value="",this.hasPat=!1;const s=this.querySelector("#cf-setup-region").value;return this.clearExports(),this.run(async()=>{await this.post("connect",{personalAccessToken:t,region:s}),this.connection(await this.post("resume"))})}async changeSpace(e){this.cancel(),this.clearExports(),this.spaceId=e.currentTarget.value,this.keyId="",this.environment="",this.available={keys:[],aliases:[],environments:[]},this.setupStatus="",this.spaceId&&await this.run(async()=>{this.available=await this.post("options",{spaceId:this.spaceId}),this.setupStatus=this.available.keys.length?"":this.t("setup.noKeys")})}get selectedKey(){return this.available.keys.find(e=>e.id===this.keyId)}changeKey(e){this.keyId=e.currentTarget.value,this.environment="",this.clearExports(),this.setupStatus=this.selectedKey&&!this.environmentChoices.length?this.t("setup.noEnvironments"):""}get environmentChoices(){const e=this.selectedKey?.environments||[];return[...this.available.aliases,...this.available.environments].filter(t=>e.includes(t.id))}saveConnection(){return this.clearExports(),this.run(async()=>{const e=this.revision,t=this.selectedKey;if(!t||!this.environment)return;const s=await this.post("save",{spaceId:t.spaceId,keyId:t.id,environment:this.environment,includePreview:String(this.includePreview)});this.finished=!0,this.setupSnippet=s.snippet,this.setupStatus=this.t("setup.saved"),this.complete=!0;try{const n=await this.readModel(this.dataset.configurationUrl);this.drafts=Object.fromEntries(Object.entries(this.drafts).filter(([a])=>this.model.fields.some(l=>l.id===a&&l.section==="Rendering"))),this.model=n,this.clears=new Set,this.clearPasswords(),this.manualUnavailable=!1}catch(n){if(e!==this.revision||!this.isConnected)throw n;this.manualUnavailable=!0,this.complete=!1,this.setupStatus=this.t("setup.refreshFailed")}})}disconnect(){return this.clearPasswords(),this.clearExports(),this.run(async()=>{await this.post("cancel"),this.connection({connected:!1})})}fieldInput(e,t){const s=t.currentTarget;if(e.type==="password"){const n=new Set(this.passwordEntered),a=new Set(this.clears);s.value.trim()?(n.add(e.id),a.delete(e.id)):n.delete(e.id),this.passwordEntered=n,this.clears=a}else this.drafts={...this.drafts,[e.id]:e.type==="boolean"?s.checked:s.value}}clearField(e,t){const s=new Set(this.clears);t.currentTarget.checked?s.add(e):s.delete(e),this.clears=s}submit(e){e.preventDefault();const t=new URLSearchParams(Array.from(new FormData(e.currentTarget)));return this.clearExports(),this.clearPasswords(),this.run(async()=>{const s=await this.readModel(this.dataset.saveUrl,t);this.previewSnippet=s.previewSecretExport||"",delete s.previewSecretExport,this.previewSnippet&&this.expanded.add("LivePreview"),this.model=s,s.saved&&(this.drafts={},this.clears=new Set)},!0)}reset(e){e.preventDefault(),this.clearExports(),this.clearPasswords(),this.drafts={},this.clears=new Set}async copy(e){const t=this.exportRevision;let s=!0;try{await navigator.clipboard.writeText(e==="setup"?this.setupSnippet:this.previewSnippet)}catch{s=!1}if(t!==this.exportRevision||!this.isConnected)return;if(!s){const o=this.querySelector(e==="setup"?"#cf-setup-snippet":"[data-preview-secret-snippet]");o.focus();const c=document.createRange();c.selectNodeContents(o);const r=window.getSelection();r.removeAllRanges(),r.addRange(c)}clearTimeout(this.copyNotificationTimer);const n={kind:e,message:this.t(s?"setup.copied":"setup.copyFallback")};if(this.copyNotification=n,await this.updateComplete,this.copyNotification!==n)return;const a=this.querySelector(e==="setup"?"#cf-export-copy-status":"#cf-preview-secret-copy-status"),l=this.querySelector(e==="setup"?"[data-setup-copy]":"[data-preview-secret-copy]");a.showPopover({source:l}),this.copyNotificationTimer=window.setTimeout(()=>{this.copyNotification=null},s?3e3:8e3)}exportBlock(e){const t=e==="setup",s=t?this.setupSnippet:this.previewSnippet,n=t?"cf-export-copy-status":"cf-preview-secret-copy-status";return i.html`<div
            ?hidden=${!s}
            data-setup-export=${t?"":i.nothing}
            data-preview-secret-export=${t?i.nothing:""}
            class="slds-p-top_medium"
        >
            <h3
                id=${t?"cf-export-label":"cf-preview-export-label"}
                class="cf-subsection-title slds-p-bottom_small"
                >${this.t("setup.export")}</h3
            >
            <div
                class="cf-code-block slds-box slds-theme_shade slds-p-around_small"
                role="group"
                aria-labelledby=${t?"cf-export-label":"cf-preview-export-label"}
            >
                <code
                    id=${t?"cf-setup-snippet":i.nothing}
                    data-preview-secret-snippet=${t?i.nothing:""}
                    class="cf-code-lines"
                    tabindex="0"
                    .textContent=${s}
                ></code>
                <button
                    type="button"
                    class="slds-button slds-button_icon slds-button_icon-border-filled"
                    data-setup-copy=${t?"":i.nothing}
                    data-preview-secret-copy=${t?i.nothing:""}
                    title=${this.t("setup.copy")}
                    aria-label=${this.t("setup.copy")}
                    aria-controls=${n}
                    @click=${()=>this.copy(e)}
                    >${this.icon("copy","slds-button__icon")}</button
                >
            </div>
            ${this.copyNotification?.kind===e?i.html`<p
                          id=${n}
                          data-copy-notification
                          data-export-copy-status=${t?"":i.nothing}
                          data-preview-secret-copy-status=${t?i.nothing:""}
                          popover="auto"
                          role="status"
                          aria-live="polite"
                          class="cf-copy-notification slds-p-around_small"
                          >${this.copyNotification.message}</p
                      >`:i.nothing}
            <p class="cf-description slds-p-vertical_small"
                >${this.t(t?"setup.exportHelp":"previewSecret.exportHelp")}</p
            >
        </div>`}field(e){const t=this.drafts[e.id]??e.value,s=this.busy||this.manualUnavailable,n=i.html`<label class="slds-form-element__label" for=${e.id} title=${e.help}
            >${e.label}${this.icon("info","cf-field-help cf-icon")}</label
        >`;let a;return e.type==="password"?a=i.html`${n}<input
                    class="slds-input"
                    type="password"
                    id=${e.id}
                    name=${e.id}
                    autocomplete="new-password"
                    ?disabled=${s||this.clears.has(e.id)}
                    aria-describedby=${`${e.id}Help ${e.id}Description`}
                    @input=${l=>this.fieldInput(e,l)}
                    @change=${l=>this.fieldInput(e,l)}
                />
                <div class="cf-key-actions slds-p-top_small"
                    >${e.isSet?i.html`<div class="slds-checkbox"
                                  ><input
                                      type="checkbox"
                                      id=${`${e.id}Clear`}
                                      name=${`${e.id}Clear`}
                                      value="true"
                                      .checked=${i.live(this.clears.has(e.id))}
                                      ?disabled=${s||this.passwordEntered.has(e.id)}
                                      @change=${l=>this.clearField(e.id,l)}
                                  /><label class="slds-checkbox__label" for=${`${e.id}Clear`}
                                      ><span class="slds-checkbox_faux" aria-hidden="true"></span
                                      ><span class="slds-form-element__label">${this.t("key.clear")}</span></label
                                  ></div
                              >`:i.nothing}<p
                        class=${`cf-status ${e.isSet?"cf-status--good":"cf-status--neutral"} slds-form-element__help`}
                        id=${`${e.id}Help`}
                        >${this.icon(e.isSet?"key":"close")}<span
                            >${this.t(e.isSet?"key.configured":"key.notConfigured")}</span
                        ></p
                    ></div
                >`:e.type==="boolean"?a=i.html`<div class="slds-checkbox"
                ><input
                    type="checkbox"
                    id=${e.id}
                    name=${e.id}
                    value="true"
                    .checked=${i.live(t===!0)}
                    ?disabled=${s}
                    aria-describedby=${`${e.id}Description`}
                    @change=${l=>this.fieldInput(e,l)}
                /><label class="slds-checkbox__label" for=${e.id} title=${e.help}
                    ><span class="slds-checkbox_faux" aria-hidden="true"></span
                    ><span class="slds-form-element__label">${e.label}</span></label
                ></div
            >`:e.type==="number"?a=i.html`${n}<input
                    class="slds-input"
                    type="number"
                    id=${e.id}
                    name=${e.id}
                    .value=${i.live(String(t))}
                    min=${e.min}
                    max=${e.max}
                    step="1"
                    ?disabled=${s}
                    aria-describedby=${`${e.id}Description`}
                    @input=${l=>this.fieldInput(e,l)}
                />`:a=i.html`${n}<input
                    class="slds-input"
                    type="text"
                    id=${e.id}
                    name=${e.id}
                    .value=${i.live(String(t))}
                    placeholder=${e.id==="contentfulPreviewEditorOrigin"?this.t("field.contentfulPreviewEditorOrigin.placeholder"):""}
                    ?disabled=${s}
                    aria-describedby=${`${e.id}Description`}
                    @input=${l=>this.fieldInput(e,l)}
                />`,i.html`<div class="slds-form-element slds-p-bottom_medium"
            ><div class="slds-form-element__control"
                >${a}<span class="slds-assistive-text" id=${`${e.id}Description`}>${e.help}</span></div
            ></div
        >`}manual(){return i.html`<form
            class="cf-settings-form slds-form"
            method="post"
            action=${this.dataset.saveUrl}
            autocomplete="off"
            @submit=${this.submit}
            @reset=${this.reset}
        >
            <input type="hidden" name=${this.model.csrf.name} value=${this.model.csrf.token} />
            ${i.repeat(this.model.sections,e=>e,e=>i.html`<details
                        class="cf-section slds-box slds-m-bottom_large"
                        aria-labelledby=${`${e}Heading`}
                        .open=${this.expanded.has(e)}
                        @toggle=${t=>{t.currentTarget.open?this.expanded.add(e):this.expanded.delete(e)}}
                    >
                        <summary class="cf-section-summary" id=${`${e}Heading`}
                            ><h2 class="cf-section-title">${this.t(`section.${e}`)}</h2></summary
                        ><div class="cf-section-fields slds-p-top_medium">
                            ${e==="LivePreview"?i.html`<p class="cf-description slds-p-bottom_medium">${this.t("previewSecret.description")}</p>`:i.nothing}
                            ${i.repeat(this.model.fields.filter(t=>t.section===e&&!t.group),t=>t.id,t=>this.field(t))}
                            ${e==="LivePreview"?this.exportBlock("preview"):i.nothing}
                            ${e==="Connection"?i.html`<section
                                          class="cf-subsection slds-border_top slds-p-top_medium"
                                          aria-labelledby="PreviewApiHeading"
                                          ><h3 class="cf-subsection-title slds-p-bottom_medium" id="PreviewApiHeading"
                                              >${this.t("group.PreviewApi")}</h3
                                          >${i.repeat(this.model.fields.filter(t=>t.group==="Preview API"),t=>t.id,t=>this.field(t))}</section
                                      >`:i.nothing}
                        </div></details
                    >`)}
            <button class="slds-button slds-button_brand" type="submit" ?disabled=${this.busy||this.manualUnavailable}
                >${this.t("configuration.save")}</button
            >
        </form>`}choices(e){return i.html`<option value="">${this.t("setup.choose")}</option>${i.repeat(e,t=>t.id,t=>i.html`<option value=${t.id}>${t.label}</option>`)}`}guided(){const e=this.selectedKey,t=!this.busy&&!this.finished&&!!(this.spaceId&&e&&this.environment);return i.html`<section
            id="contentful-guided-setup"
            class="cf-section slds-box slds-m-bottom_large"
            aria-labelledby="GuidedSetupHeading"
            aria-busy=${String(this.busy)}
        >
            <h2 id="GuidedSetupHeading" class="cf-section-title slds-p-bottom_medium">${this.t("setup.title")}</h2
            ><p class="cf-description slds-p-bottom_medium">${this.t("setup.description")}</p>
            <details class="cf-subsection slds-box slds-m-bottom_medium"
                ><summary class="cf-section-summary"
                    ><h3 class="cf-subsection-title">${this.t("setup.contentfulSetup")}</h3></summary
                ><div class="slds-p-top_medium"
                    ><p class="cf-description slds-p-bottom_medium">${this.t("setup.contentfulSetupHelp")}</p
                    ><p class="cf-description slds-p-bottom_medium"
                        ><a
                            href="https://app.contentful.com/account/profile/cma_tokens"
                            target="_blank"
                            rel="noopener noreferrer"
                            >${this.t("setup.createPat")}<span class="slds-assistive-text"
                                >${this.t("link.newTab")}</span
                            ></a
                        ></p
                    ></div
                ></details
            >
            <div data-setup-connect ?hidden=${this.connected}>
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-pat" title=${this.t("setup.patHelp")}
                        >${this.t("setup.pat")}${this.icon("info","cf-field-help cf-icon")}</label
                    ><div class="slds-form-element__control"
                        ><input
                            class="slds-input"
                            id="cf-setup-pat"
                            data-setup-pat
                            type="password"
                            autocomplete="off"
                            spellcheck="false"
                            autocapitalize="none"
                            aria-describedby="cf-setup-pat-help"
                            ?disabled=${this.busy}
                            @input=${s=>{this.hasPat=!!s.currentTarget.value.trim()}}
                            @keydown=${s=>{s.key==="Enter"&&!this.busy&&this.hasPat&&(s.preventDefault(),this.connect())}}
                        /><span id="cf-setup-pat-help" class="slds-assistive-text"
                            >${this.t("setup.patHelp")}</span
                        ></div
                    ></div
                >
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-region">${this.t("setup.region")}</label
                    ><div class="slds-form-element__control"
                        ><select class="slds-select" id="cf-setup-region" ?disabled=${this.busy}
                            ><option value="us">US</option
                            ><option value="eu">EU</option></select
                        ></div
                    ></div
                >
                <button
                    class="slds-button slds-button_brand"
                    type="button"
                    data-setup-connect-button
                    ?disabled=${this.busy||!this.hasPat}
                    @click=${this.connect}
                    >${this.t("setup.connect")}</button
                >
            </div>
            <div data-setup-choices ?hidden=${!this.connected||this.finished}>
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-space">${this.t("setup.space")}</label
                    ><div class="slds-form-element__control"
                        ><select
                            class="slds-select"
                            id="cf-setup-space"
                            required
                            ?disabled=${this.busy||!this.spaces.length}
                            .value=${this.spaceId}
                            @change=${this.changeSpace}
                            >${this.choices(this.spaces)}</select
                        ></div
                    ></div
                >
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-key"
                        >${this.t("field.contentfulCdaToken.label")}</label
                    ><div class="slds-form-element__control"
                        ><select
                            class="slds-select"
                            id="cf-setup-key"
                            required
                            ?disabled=${this.busy||!this.available.keys.length}
                            .value=${this.keyId}
                            @change=${this.changeKey}
                            >${this.choices(this.available.keys)}</select
                        ></div
                    ></div
                >
                <div class="slds-form-element slds-p-bottom_medium"
                    ><label class="slds-form-element__label" for="cf-setup-environment"
                        >${this.t("setup.environment")}</label
                    ><div class="slds-form-element__control"
                        ><select
                            class="slds-select"
                            id="cf-setup-environment"
                            required
                            ?disabled=${this.busy||!this.environmentChoices.length}
                            .value=${this.environment}
                            @change=${s=>{this.clearExports(),this.environment=s.currentTarget.value}}
                            ><option value="">${this.t("setup.choose")}</option
                            >${["aliases","environments"].map(s=>{const n=this.available[s].filter(a=>e?.environments.includes(a.id));return n.length?i.html`<optgroup label=${this.t(`setup.${s}`)}
                                          >${i.repeat(n,a=>a.id,a=>i.html`<option value=${a.id}>${a.label}</option>`)}</optgroup
                                      >`:i.nothing})}</select
                        ></div
                    ></div
                >
                <div class="slds-grid slds-grid_align-spread slds-grid_vertical-align-center slds-wrap"
                    ><div class="slds-form-element slds-p-bottom_medium"
                        ><div class="slds-form-element__control"
                            ><div class="slds-checkbox"
                                ><input
                                    type="checkbox"
                                    id="cf-setup-preview"
                                    .checked=${i.live(this.includePreview)}
                                    ?disabled=${this.busy}
                                    @change=${s=>{this.clearExports(),this.includePreview=s.currentTarget.checked}}
                                /><label class="slds-checkbox__label" for="cf-setup-preview"
                                    ><span class="slds-checkbox_faux" aria-hidden="true"></span
                                    ><span class="slds-form-element__label">${this.t("setup.preview")}</span></label
                                ></div
                            ></div
                        ></div
                    >
                    <div class="slds-p-bottom_medium">
                        <button
                            class="slds-button slds-button_brand"
                            type="button"
                            data-setup-save
                            ?disabled=${!t}
                            @click=${this.saveConnection}
                            >${this.t("setup.save")}</button
                        ><button
                            class="slds-button slds-button_neutral"
                            type="button"
                            data-setup-cancel
                            ?disabled=${this.busy}
                            @click=${this.disconnect}
                            >${this.t("setup.cancel")}</button
                        >
                    </div>
                </div>
            </div>
            ${this.exportBlock("setup")}
            <p
                data-setup-status
                role="status"
                aria-live="polite"
                class=${`cf-description slds-p-top_small${this.complete?" cf-status cf-status--good cf-completion":""}`}
                ><span data-setup-status-icon ?hidden=${!this.complete}>${this.icon("success")}</span
                ><span data-setup-status-text>${this.setupStatus}</span></p
            >
        </section>`}render(){return i.html`<div
            id="contentful-management"
            class="contentful-management slds-p-around_large slds-theme_default"
            aria-busy=${String(this.busy)}
            ><h1 class="cf-page-title slds-text-heading_medium slds-p-bottom_large"
                >${this.t("configuration.title")}</h1
            >
            ${this.model.error?i.html`<p class="cf-notice slds-scoped-notification slds-theme_error slds-p-around_small slds-m-bottom_medium" role="alert">${this.icon("error")}${this.model.error}</p>`:i.nothing}
            ${this.model.saved?i.html`<p class="cf-notice slds-scoped-notification slds-theme_success slds-p-around_small slds-m-bottom_medium" role="status">${this.icon("success")}${this.t("configuration.saved")}</p>`:i.nothing}
            ${this.model.csrf?i.html`<p class="cf-description slds-p-bottom_large">${this.t("configuration.description")}</p>${this.guided()}${this.manual()}`:i.nothing}
        </div>`}}customElements.define("contentful-configuration",p)})(ContentfulEditorRuntime);
