/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
"use strict";
var URLUtils = require("dw/web/URLUtils");
var imageDialog = require("./assetDialog");
var Resource = require("dw/web/Resource");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/**
 * Reuse the asset dialog's session bootstrap configuration, selecting the published
 * video endpoint and video presentation. Credentials remain on ECOM and the native
 * host owns Apply/Cancel for the staged { assetId } value.
 * @param {dw.experience.CustomEditor} editor Page Designer dialog configuration
 */
function init(editor) {
    imageDialog.init(editor);
    editor.configuration.put("mediaType", "video");
    try {
        editor.configuration.put("searchUrl", URLUtils.https("ContentfulPicker-Videos").toString());
    }
    catch (error) {
        diagnostics.log("error", "picker.init_failed", { errorType: diagnostics.errorType(error) });
        editor.configuration.put("error", Resource.msg("initError", "contentfulPicker", null));
    }
}
module.exports = { init: init };
