"use strict";
/** Standalone Script pipelet: BM authenticates and checks the registered module. */
/* exported execute */
/**
 * Delegate the authenticated Assets action to its POST/CSRF/site-validated JSON helper.
 * Return PIPELET_NEXT so the pipeline's stop-node delivers the written response.
 * This Script pipelet runs without CommonJS module/exports globals.
 */
var execute = function execute(pdict) {
    require("bm_contentful/cartridge/scripts/picker").assets(request, response);
    return PIPELET_NEXT;
};
