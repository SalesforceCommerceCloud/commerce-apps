/* PATs are transient: submit once to BM, clear the input, and never use storage, URLs or console logging. */
(() => {
    "use strict";
    const root = document.querySelector("#contentful-guided-setup");
    if (!root) {
        return;
    }
    const find = (selector) => root.querySelector(selector);
    const message = (name) => find(`[data-setup-${name}]`).textContent.trim();
    const errorMessages = new Map(
        Array.from(root.querySelectorAll("[data-setup-error]"), (element) => [
            element.dataset.setupError,
            element.textContent.trim(),
        ]),
    );
    function errorMessage(error) {
        // Only server-rendered translations for fixed codes; never display returned error text.
        return errorMessages.get(error?.code) || message("error");
    }
    async function post(action, values = {}) {
        const endpoint = new URL(root.dataset.endpoint, window.location.href);
        if (endpoint.origin !== window.location.origin || endpoint.protocol !== "https:") {
            throw new Error("Invalid endpoint");
        }
        const body = new URLSearchParams({ ...values, action, [root.dataset.csrfName]: root.dataset.csrfToken });
        const response = await fetch(endpoint.href, {
            method: "POST",
            credentials: "same-origin",
            cache: "no-store",
            redirect: "error",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "X-Requested-With": "XMLHttpRequest",
                "Cache-Control": "no-store",
            },
            body: body.toString(),
        });
        if (!response.headers.get("Content-Type")?.includes("application/json")) {
            throw Object.assign(new Error("Setup request failed"), {
                code: [401, 403].includes(response.status) ? "request_denied" : undefined,
            });
        }
        const result = await response.json();
        if (!response.ok) {
            throw Object.assign(new Error("Setup request failed"), {
                code: result?.code || ([401, 403].includes(response.status) ? "request_denied" : undefined),
            });
        }
        return result;
    }
    function selectCode(element) {
        element.focus();
        const range = document.createRange();
        range.selectNodeContents(element);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
    }
    let copyFeedback;
    let feedbackTimer;
    function hideCopyFeedback() {
        clearTimeout(feedbackTimer);
        if (!copyFeedback) {
            return;
        }
        copyFeedback.hidePopover?.();
        copyFeedback.hidden = true;
        copyFeedback = null;
    }
    function showCopyFeedback(button, feedback, text, copied) {
        hideCopyFeedback();
        copyFeedback = feedback;
        feedback.textContent = text;
        feedback.hidden = false;
        feedback.showPopover?.();
        const bounds = button.getBoundingClientRect();
        const width = feedback.getBoundingClientRect().width;
        feedback.style.top = `${bounds.bottom + 8}px`;
        feedback.style.left = `${Math.max(8, Math.min(bounds.right - width, window.innerWidth - width - 8))}px`;
        feedbackTimer = setTimeout(hideCopyFeedback, copied ? 3000 : 8000);
    }
    window.addEventListener("scroll", hideCopyFeedback, true);
    window.addEventListener("resize", hideCopyFeedback);
    const pat = find("#cf-setup-pat");
    const connect = find("[data-setup-connect-button]");
    const space = find("#cf-setup-space");
    const key = find("#cf-setup-key");
    const environment = find("#cf-setup-environment");
    const preview = find("#cf-setup-preview");
    const save = find("[data-setup-save]");
    const status = find("[data-setup-status]");
    function setStatus(text, complete = false) {
        find("[data-setup-status-text]").textContent = text;
        find("[data-setup-status-icon]").hidden = !complete;
        ["cf-status", "cf-status--good", "cf-completion"].forEach((name) => status.classList.toggle(name, complete));
    }
    const snippet = find("#cf-setup-snippet");
    let revision = 0;
    let keys = [];
    let available = {};
    let busy = false;
    let finished = false;
    function clearExport() {
        hideCopyFeedback();
        snippet.textContent = "";
        find("[data-setup-export]").hidden = true;
    }
    function options(select, values = []) {
        select.replaceChildren(new Option(message("placeholder"), ""));
        values.forEach((item) => select.add(new Option(item.label, item.id)));
        select.disabled = values.length === 0;
    }
    function selectedKey() {
        return keys.find((item) => item.id === key.value);
    }
    function enableSave() {
        connect.disabled = busy || !pat.value.trim();
        save.disabled = busy || finished || !space.value || !selectedKey() || !environment.value;
    }
    async function run(work) {
        if (busy) {
            return;
        }
        busy = true;
        root.setAttribute("aria-busy", "true");
        root.querySelectorAll("button, select, input").forEach((control) => {
            control.disabled = true;
        });
        setStatus(message("working"));
        try {
            await work();
        } catch (error) {
            if (["setup_expired", "management_unauthorized"].includes(error.code)) {
                connected({ connected: false });
            }
            setStatus(errorMessage(error));
        } finally {
            busy = false;
            root.removeAttribute("aria-busy");
            root.querySelectorAll("button, select, input").forEach((control) => {
                control.disabled = false;
            });
            [space, key, environment].forEach((select) => {
                select.disabled = select.options.length <= 1;
            });
            enableSave();
        }
    }
    function connected(data) {
        pat.value = "";
        find("[data-setup-connect]").hidden = data.connected;
        find("[data-setup-choices]").hidden = !data.connected;
        options(space, data.spaces);
        keys = [];
        available = {};
        options(key);
        options(environment);
        preview.checked = false;
        finished = false;
        setStatus(data.connected && data.spaces.length === 0 ? message("no-spaces") : "");
    }
    pat.addEventListener("input", enableSave);
    pat.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && !connect.disabled) {
            event.preventDefault();
            connect.click();
        }
    });
    connect.addEventListener("click", () =>
        run(async () => {
            // Clear before any other work, including error paths. The server retains only
            // a short-lived, site-bound copy after validating CMA access.
            const personalAccessToken = pat.value;
            pat.value = "";
            clearExport();
            ++revision;
            await post("connect", { personalAccessToken, region: find("#cf-setup-region").value });
            connected(await post("resume"));
        }),
    );
    space.addEventListener("change", () => {
        clearExport();
        keys = [];
        available = {};
        options(key);
        options(environment);
        enableSave();
        const current = ++revision;
        setStatus("");
        if (!space.value) {
            return;
        }
        run(async () => {
            const data = await post("options", { spaceId: space.value });
            if (current !== revision) {
                return;
            }
            keys = data.keys;
            available = data;
            options(key, keys);
            setStatus(keys.length === 0 ? message("no-keys") : "");
        });
    });
    key.addEventListener("change", () => {
        clearExport();
        options(environment);
        const selected = selectedKey();
        if (selected) {
            ["aliases", "environments"].forEach((name) => {
                // An alias grant enables that alias ID, never direct access to its target.
                const items = available[name].filter((item) => selected.environments.includes(item.id));
                if (!items.length) {
                    return;
                }
                const group = document.createElement("optgroup");
                group.label = message(name);
                items.forEach((item) => group.append(new Option(item.label, item.id)));
                environment.append(group);
            });
        }
        environment.disabled = environment.options.length <= 1;
        setStatus(selected && environment.disabled ? message("no-environments") : "");
        enableSave();
    });
    [environment, preview].forEach((control) =>
        control.addEventListener("change", () => {
            clearExport();
            enableSave();
        }),
    );
    /**
     * Reload persisted Connection Details after a successful guided save, using only the
     * Form fragment endpoint. Do not fall back to Start/full-page HTML: even background
     * shell rendering can affect BM assets. Validate response shape before DOM replacement.
     * Preserve unsaved Storefront Settings/disclosure state, but let refreshed connection
     * values replace old drafts. If refresh fails, the caller retains the already-issued
     * export and reports that separate failure; the old form stays disabled until reload.
     */
    async function refreshManualSettings() {
        const manual = document.querySelector("form.cf-settings-form");
        if (!manual) {
            return;
        }
        // Preserve the user's pending storefront edits and disclosure state. Guided
        // Setup changes only Connection Details, whose saved values must replace drafts.
        const pending = Array.from(
            manual.querySelectorAll("#RenderingHeading + .cf-section-fields input"),
            (input) => ({
                name: input.name,
                value: input.value,
                checked: input.checked,
            }),
        );
        const expanded = new Set(Array.from(manual.querySelectorAll("details[open] summary"), (summary) => summary.id));
        manual.querySelectorAll("input, button").forEach((control) => {
            control.disabled = true;
        });
        const url = new URL(root.dataset.configurationFormUrl, window.location.href);
        if (url.origin !== window.location.origin || url.protocol !== "https:") {
            throw new Error("Invalid configuration URL");
        }
        const response = await fetch(url.href, {
            credentials: "same-origin",
            cache: "no-store",
            redirect: "error",
            headers: { "X-Requested-With": "XMLHttpRequest" },
        });
        if (!response.ok || !response.headers.get("Content-Type")?.includes("text/html")) {
            throw new Error("Configuration refresh failed");
        }
        const parsed = new DOMParser().parseFromString(await response.text(), "text/html");
        const fresh = parsed.body.firstElementChild;
        if (
            parsed.doctype ||
            parsed.head.children.length ||
            parsed.body.children.length !== 1 ||
            !fresh?.matches("form.cf-settings-form") ||
            fresh.querySelector("script, style, link, iframe")
        ) {
            throw new Error("Configuration form unavailable");
        }
        // The Form endpoint renders only this fragment. Reject full pages and assets;
        // the live BM shell owns its styles and scripts.
        const replacement = document.importNode(fresh, true);
        pending.forEach((value) => {
            const input = replacement.elements.namedItem(value.name);
            if (input) {
                input.value = value.value;
                input.checked = value.checked;
            }
        });
        replacement.querySelectorAll("details").forEach((details) => {
            details.open = expanded.has(details.querySelector("summary").id);
        });
        manual.replaceWith(replacement);
    }
    save.addEventListener("click", () =>
        run(async () => {
            clearExport();
            const selected = selectedKey();
            if (!selected || !environment.value) {
                return;
            }
            const data = await post("save", {
                spaceId: selected.spaceId,
                keyId: selected.id,
                environment: environment.value,
                includePreview: String(preview.checked),
            });
            finished = true;
            snippet.textContent = data.snippet;
            find("[data-setup-export]").hidden = false;
            find("[data-setup-choices]").hidden = true;
            setStatus(message("saved"), true);
            try {
                await refreshManualSettings();
            } catch {
                // The connection is already saved: retain the export and distinguish
                // a form refresh failure from a failed preference write.
                setStatus(message("refresh-failed"));
            }
        }),
    );
    find("[data-setup-cancel]").addEventListener("click", () =>
        run(async () => {
            ++revision;
            pat.value = "";
            clearExport();
            await post("cancel");
            connected({ connected: false });
        }),
    );
    const exportCopy = find("[data-setup-copy]");
    const exportCopyStatus = find("[data-export-copy-status]");
    exportCopy.addEventListener("click", async () => {
        try {
            await navigator.clipboard.writeText(snippet.textContent);
            showCopyFeedback(exportCopy, exportCopyStatus, message("copied"), true);
        } catch {
            selectCode(snippet);
            showCopyFeedback(exportCopy, exportCopyStatus, message("copy-fallback"), false);
        }
    });
    window.addEventListener("pagehide", () => {
        pat.value = "";
        clearExport();
    });
    run(async () => connected(await post("resume")));
})();
