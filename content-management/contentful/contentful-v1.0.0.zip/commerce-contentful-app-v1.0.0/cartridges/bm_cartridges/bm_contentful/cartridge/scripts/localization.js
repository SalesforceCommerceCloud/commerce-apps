"use strict";
var Resource = require("dw/web/Resource");
var HashMap = require("dw/util/HashMap");
var MESSAGE_KEYS = [
    "entry.clear",
    "entry.more",
    "entry.overflow",
    "entry.searching",
    "entry.hint",
    "entry.empty",
    "entry.prompt",
    "entry.csrf",
    "entry.searchError",
    "entry.unavailable",
    "entry.lookupCsrf",
    "entry.lookupDenied",
    "entry.lookupError",
    "entry.saved",
    "entry.label",
    "entry.placeholder",
    "entry.choices",
    "video.indicator",
    "clear",
    "retry",
    "searching",
    "dimensions",
    "size.bytes",
    "size.kb",
    "size.mb",
    "image.panel",
    "image.browser",
    "image.choose",
    "image.search",
    "image.choices",
    "image.more",
    "image.saved",
    "image.none",
    "image.selected",
    "image.prompt",
    "image.searchError",
    "image.unavailable",
    "image.lookupError",
    "image.dialog",
    "video.panel",
    "video.browser",
    "video.choose",
    "video.search",
    "video.choices",
    "video.more",
    "video.saved",
    "video.none",
    "video.selected",
    "video.prompt",
    "video.searchError",
    "video.unavailable",
    "video.lookupError",
    "video.dialog",
    "initError",
    "originError",
];
var COUNT_KEYS = [
    "entry.matches",
    "entry.matchesMore",
    "entry.recent",
    "entry.recentMore",
    "image.results",
    "image.resultsMore",
    "video.results",
    "video.resultsMore",
];
var PLURAL_CATEGORIES = ["zero", "one", "two", "few", "many", "other"];
/**
 * Resolve editor UI messages in the BM request locale, independently of the content locale.
 * Only localized strings and the UI locale enter the serialized configuration. Missing plural
 * categories use the translated other form; platform bundles supply the English fallback.
 * @param {dw.experience.CustomEditor} editor custom editor or native breakout dependency
 */
function initialize(editor) {
    var localization = new HashMap();
    MESSAGE_KEYS.forEach(function (key) { return localization.put(key, Resource.msg(key, "contentfulPicker", null)); });
    // Resolve every plural category so languages with zero/two/few/many can supply full messages.
    COUNT_KEYS.forEach(function (key) {
        var fallback = Resource.msg("".concat(key, ".other"), "contentfulPicker", null);
        PLURAL_CATEGORIES.forEach(function (category) {
            var messageKey = "".concat(key, ".").concat(category);
            localization.put(messageKey, Resource.msg(messageKey, "contentfulPicker", fallback));
        });
    });
    editor.configuration.put("localization", localization);
    editor.configuration.put("locale", request.locale === "default" ? "en" : request.locale.replace(/_/g, "-"));
}
module.exports = { initialize: initialize };
