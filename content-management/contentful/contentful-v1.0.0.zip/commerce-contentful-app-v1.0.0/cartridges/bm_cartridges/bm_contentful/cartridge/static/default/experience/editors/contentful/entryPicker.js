/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

(() => {
    "use strict";
    // This sandbox has no server telemetry transport; these diagnostics remain in DevTools.
    window.addEventListener("error", (event) => {
        console.error("contentful.editor.runtime_error", { line: event.lineno, column: event.colno });
    });
    window.addEventListener("unhandledrejection", () => {
        console.error("contentful.editor.unhandled_rejection");
    });
    let entries = [];
    let contentTypeNames = null;
    let recentEntries = null;
    let recentHasMore = false;
    let value = null;
    let savedEntry = null;
    let selectionUnavailable = false;
    let selectionWarning = "";
    let searchError = "";
    let config = {};
    let transport;
    let loading = false;
    let nextOffset = null;
    let timer;
    let controller;
    let revision = 0;
    let selectionRevision = 0;
    let required = true;
    let disabled = false;
    let configError = "";
    let messages;
    let expanded = false;
    let query = "";
    let choices = [];
    let activeIndex = -1;
    document.body.className = "contentful-entry-picker";
    /** Build static markup without HTML parsing; Contentful labels and IDs are assigned as text later. */
    function element(tag, attributes, children = []) {
        const node = document.createElement(tag);
        for (const [name, attribute] of Object.entries(attributes)) {
            node.setAttribute(name, attribute);
        }
        node.append(...children);
        return node;
    }
    document.body.appendChild(
        element("div", { class: "slds-form-element" }, [
            element("div", { class: "contentful-entry-header" }, [
                element("label", {
                    class: "slds-form-element__label contentful-entry-label_assistive",
                    for: "contentful-entry",
                }),
                element("p", {
                    id: "contentful-status",
                    class: "slds-form-element__help",
                    role: "status",
                    "aria-live": "polite",
                }),
            ]),
            element("div", { class: "slds-form-element__control" }, [
                element("div", { class: "contentful-entry-input" }, [
                    element("input", {
                        id: "contentful-entry",
                        class: "slds-input",
                        type: "text",
                        role: "combobox",
                        autocomplete: "off",
                        "aria-autocomplete": "list",
                        "aria-haspopup": "listbox",
                        "aria-expanded": "false",
                        "aria-controls": "contentful-options",
                        "aria-describedby": "contentful-status",
                    }),
                    element("span", { class: "contentful-entry-indicator", "aria-hidden": "true" }),
                ]),
                element("div", {
                    id: "contentful-options",
                    class: "contentful-entry-options",
                    role: "listbox",
                    hidden: "",
                }),
            ]),
        ]),
    );
    const input = document.getElementById("contentful-entry");
    const listbox = document.getElementById("contentful-options");
    const status = document.getElementById("contentful-status");
    const anchoredPopover =
        typeof listbox.showPopover === "function" &&
        typeof CSS !== "undefined" &&
        CSS.supports("position-anchor", "--contentful-entry") &&
        CSS.supports("inset-block-start", "anchor(end)") &&
        CSS.supports("inline-size", "anchor-size(inline)");
    if (anchoredPopover) {
        listbox.setAttribute("popover", "manual");
    }

    // Custom attributes persist an object; the storefront loader unwraps the entry ID.
    function selectedId() {
        return typeof value?.entryId === "string" ? value.entryId : "";
    }
    function selectedLabel() {
        const entry = savedEntry?.id === selectedId() ? savedEntry : null;
        if (entry) {
            return entry.label;
        }
        return selectedId() ? messages.text("entry.saved", selectedId()) : "";
    }
    function validate() {
        const id = selectedId();
        const valid = (!required && !id) || Boolean(id && !selectionUnavailable);
        input.setAttribute("aria-invalid", String(!valid));
        emit({ type: "sfcc:valid", payload: valid });
    }
    function compareNames(left, right) {
        return left.localeCompare(right, messages.locale, { sensitivity: "base", numeric: true });
    }
    function setActive(index) {
        activeIndex = index;
        const options = listbox.querySelectorAll('[role="option"]');
        options.forEach((option, i) => {
            option.classList.toggle("contentful-entry-option_active", i === index);
            option.setAttribute("aria-selected", String(i === index));
        });
        if (index < 0 || !options[index]) {
            input.removeAttribute("aria-activedescendant");
        } else {
            input.setAttribute("aria-activedescendant", options[index].id);
            options[index].scrollIntoView({ block: "nearest" });
        }
    }
    function close() {
        cancelSearch();
        expanded = false;
        query = "";
        activeIndex = -1;
        input.value = selectedLabel();
        render();
    }
    function choose(index) {
        if (disabled || configError || !choices[index]) {
            return;
        }
        if (choices[index].loadMore) {
            search(query, nextOffset);
            return;
        }
        selectionRevision++;
        savedEntry = choices[index].id ? choices[index] : null;
        selectionUnavailable = false;
        selectionWarning = "";
        value = savedEntry ? { entryId: savedEntry.id } : null;
        close();
        emit({ type: "sfcc:value", payload: value });
        emit({ type: "sfcc:interacted" });
    }
    function addOption(parent, entry) {
        const index = choices.length;
        choices.push(entry);
        const option = document.createElement("div");
        option.id = `contentful-option-${index}`;
        option.className = "contentful-entry-option";
        option.setAttribute("role", "option");
        option.setAttribute("aria-selected", "false");
        option.textContent = entry.label;
        option.addEventListener("click", () => choose(index));
        parent.appendChild(option);
    }
    function contentTypeLabel(id) {
        return contentTypeNames && Object.hasOwn(contentTypeNames, id) ? contentTypeNames[id] : id;
    }
    function render() {
        input.disabled = disabled || Boolean(configError);
        if (input.disabled) {
            expanded = false;
        }
        input.setAttribute("aria-required", String(required));
        input.setAttribute("aria-expanded", String(expanded));
        if (anchoredPopover && !expanded && listbox.matches(":popover-open")) {
            listbox.hidePopover();
        }
        listbox.hidden = !expanded;
        // Reserve space for iframe auto-sizing; a top-layer popup cannot extend outside the iframe.
        document.body.classList.toggle("contentful-entry-open", anchoredPopover && expanded);
        listbox.textContent = "";
        choices = [];
        input.setAttribute("aria-busy", String(loading));
        const visible = entries.toSorted((left, right) => {
            return (
                compareNames(contentTypeLabel(left.contentType), contentTypeLabel(right.contentType)) ||
                left.contentType.localeCompare(right.contentType) ||
                compareNames(left.label, right.label) ||
                left.id.localeCompare(right.id)
            );
        });
        if (expanded) {
            if (selectedId()) {
                addOption(listbox, { id: "", label: messages.text("entry.clear") });
            }
            let group;
            let groupType;
            visible.forEach((entry) => {
                if (!group || groupType !== entry.contentType) {
                    groupType = entry.contentType;
                    group = document.createElement("div");
                    group.setAttribute("role", "group");
                    const heading = document.createElement("div");
                    heading.id = `contentful-group-${choices.length}`;
                    heading.className = "contentful-entry-group-label";
                    heading.textContent = contentTypeLabel(groupType);
                    group.setAttribute("aria-labelledby", heading.id);
                    group.appendChild(heading);
                    listbox.appendChild(group);
                }
                addOption(group, entry);
            });
            if (nextOffset !== null && !loading) {
                addOption(listbox, { label: messages.text("entry.more"), loadMore: true });
            }
            if (!query.trim() && recentHasMore && !loading) {
                const more = document.createElement("div");
                more.className = "contentful-entry-empty";
                more.setAttribute("role", "note");
                more.textContent = messages.text("entry.overflow");
                listbox.appendChild(more);
            }
            if (!visible.length) {
                const empty = document.createElement("div");
                empty.className = "contentful-entry-empty";
                empty.textContent = loading
                    ? messages.text("entry.searching")
                    : searchError ||
                      (query.trim().length < 2 ? messages.text("entry.hint") : messages.text("entry.empty"));
                listbox.appendChild(empty);
            }
        }
        if (anchoredPopover && expanded && !listbox.matches(":popover-open")) {
            listbox.showPopover();
        }
        setActive(-1);
        const error = configError || searchError || selectionWarning;
        status.className = `slds-form-element__help${error ? " contentful-entry-status_error" : ""}`;
        if (error) {
            status.textContent = error;
        } else if (loading) {
            status.textContent = messages.text("entry.searching");
        } else if (expanded && query) {
            status.textContent = messages.count(
                nextOffset !== null ? "entry.matchesMore" : "entry.matches",
                visible.length,
            );
        } else if (expanded && recentEntries) {
            status.textContent = messages.count(recentHasMore ? "entry.recentMore" : "entry.recent", visible.length);
        } else {
            status.textContent = messages.text("entry.prompt");
        }
        validate();
    }
    function cancelSearch() {
        clearTimeout(timer);
        controller?.abort();
        revision++;
        loading = false;
    }
    /**
     * Request entry summaries through shared session/CSRF transport. Keep entry-shape
     * checks and the optional content-type display-name dictionary local to this editor;
     * a response from an older configuration must not replace the current dictionary.
     */
    async function requestItems(parameters, signal) {
        const requestConfig = config;
        const result = await transport.request(
            parameters,
            signal,
            (entry) =>
                typeof entry.id === "string" &&
                typeof entry.label === "string" &&
                typeof entry.contentType === "string",
        );
        if (
            config === requestConfig &&
            result.contentTypeNames &&
            typeof result.contentTypeNames === "object" &&
            !Array.isArray(result.contentTypeNames) &&
            Object.values(result.contentTypeNames).every((name) => typeof name === "string" && name.trim())
        ) {
            contentTypeNames = { ...contentTypeNames, ...result.contentTypeNames };
        }
        return result;
    }
    async function search(text, offset = 0) {
        cancelSearch();
        if (disabled || configError) {
            return;
        }
        const current = revision;
        searchError = "";
        if (!text.trim() && recentEntries !== null) {
            entries = recentEntries;
            nextOffset = null;
            render();
            return;
        }
        controller = new AbortController();
        loading = true;
        render();
        try {
            const result = await requestItems({ q: text.trim(), offset: String(offset) }, controller.signal);
            if (current !== revision) {
                return;
            }
            const combined = offset ? [...entries, ...result.items] : result.items;
            entries = [...new Map(combined.map((entry) => [entry.id, entry])).values()];
            nextOffset = result.nextOffset;
            if (!text.trim()) {
                recentEntries = entries;
                recentHasMore = result.hasMore;
            }
        } catch (error) {
            if (current !== revision) {
                return;
            }
            searchError =
                error.code === "csrf_invalid" ? messages.text("entry.csrf") : messages.text("entry.searchError");
            console.error("contentful.editor.search_failed");
        } finally {
            if (current === revision) {
                loading = false;
                render();
            }
        }
    }
    async function hydrateSelection() {
        const current = ++selectionRevision;
        const id = selectedId();
        savedEntry = null;
        selectionUnavailable = false;
        selectionWarning = "";
        entries = [];
        close();
        if (!id || configError) {
            return;
        }
        try {
            const result = await requestItems({ entryId: id });
            if (current !== selectionRevision) {
                return;
            }
            savedEntry = result.items.find((entry) => entry.id === id) || null;
            selectionUnavailable = !savedEntry;
            selectionWarning = savedEntry ? "" : messages.text("entry.unavailable");
        } catch (error) {
            if (current !== selectionRevision) {
                return;
            }
            console.error("contentful.editor.selection_check_failed");
            // A transient lookup failure must not erase or invalidate saved content.
            if (error.code === "csrf_invalid") {
                selectionWarning = messages.text("entry.lookupCsrf");
            } else {
                selectionWarning = messages.text(error.httpStatus === 403 ? "entry.lookupDenied" : "entry.lookupError");
            }
        }
        if (!expanded) {
            input.value = selectedLabel();
        }
        render();
    }
    function open() {
        if (disabled || configError || expanded) {
            return;
        }
        expanded = true;
        query = "";
        entries = recentEntries || [];
        nextOffset = null;
        search("");
    }
    input.addEventListener("focus", () => {
        open();
        input.select();
    });
    input.addEventListener("click", open);
    input.addEventListener("input", (event) => {
        query = input.value;
        expanded = true;
        cancelSearch();
        searchError = "";
        entries = [];
        nextOffset = null;
        render();
        if (!disabled && !event.isComposing) {
            timer = setTimeout(() => search(query), 300);
        }
    });
    // Keep DOM focus on the combobox when a pointer selects an option.
    listbox.addEventListener("mousedown", (event) => event.preventDefault());
    input.addEventListener("blur", () => {
        close();
        emit({ type: "sfcc:interacted" });
    });
    input.addEventListener("keydown", (event) => {
        if (event.isComposing || disabled || configError) {
            return;
        }
        if (["ArrowDown", "ArrowUp"].includes(event.key)) {
            event.preventDefault();
            open();
            if (choices.length) {
                let nextIndex = activeIndex < 0 ? choices.length - 1 : Math.max(activeIndex - 1, 0);
                if (event.key === "ArrowDown") {
                    nextIndex = Math.min(activeIndex + 1, choices.length - 1);
                }
                setActive(nextIndex);
            }
        } else if (event.key === "Enter" && expanded && activeIndex >= 0) {
            event.preventDefault();
            choose(activeIndex);
        } else if (event.key === "Escape" && expanded) {
            event.preventDefault();
            close();
        } else if (event.key === "Tab") {
            close();
        }
    });
    subscribe("sfcc:ready", (state) => {
        config = state.config;
        messages = window.ContentfulLocalization.create(config);
        document.documentElement.lang = messages.locale;
        document.documentElement.dir = messages.direction;
        document.querySelector('label[for="contentful-entry"]').textContent = messages.text("entry.label");
        input.placeholder = messages.text("entry.placeholder");
        listbox.setAttribute("aria-label", messages.text("entry.choices"));
        contentTypeNames = null;
        recentEntries = null;
        recentHasMore = false;
        transport = window.ContentfulPickerTransport.create(config);
        configError = transport.error;
        console[configError ? "error" : "info"](
            configError ? "contentful.editor.initialization_failed" : "contentful.editor.ready",
            { hostDisabled: state.isDisabled },
        );
        value = state.value || null;
        required = state.isRequired;
        disabled = state.isDisabled;
        hydrateSelection();
    });
    subscribe("sfcc:value", (next) => {
        value = next || null;
        hydrateSelection();
    });
    subscribe("sfcc:disabled", (next) => {
        disabled = next;
        close();
    });
    subscribe("sfcc:required", (next) => {
        required = next;
        input.setAttribute("aria-required", String(required));
        validate();
    });
})();
