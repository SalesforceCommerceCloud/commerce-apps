(function(n){"use strict";class c extends n.LitElement{static{this.properties={activeIndex:{state:!0},inputText:{state:!0}}}constructor(){super(),this.entries=[],this.contentTypeNames=null,this.recentEntries=null,this.recentHasMore=!1,this.value=null,this.savedEntry=null,this.selectionUnavailable=!1,this.selectionWarning="",this.searchError="",this.config={},this.loading=!1,this.nextOffset=null,this.revision=0,this.selectionRevision=0,this.required=!0,this.disabled=!1,this.configError="",this.messages=window.ContentfulLocalization.create({}),this.expanded=!1,this.query="",this.activeIndex=-1,this.inputText="",this.anchoredPopover=typeof HTMLElement.prototype.showPopover=="function"&&typeof CSS<"u"&&CSS.supports("position-anchor","--contentful-entry")&&CSS.supports("inset-block-start","anchor(end)")&&CSS.supports("inline-size","anchor-size(inline)"),this.initialize()}createRenderRoot(){return this}receiveValue(e){const t=e?.entryId;this.value=typeof t=="string"?{entryId:t}:null}selectedId(){return this.value?.entryId||""}selectedLabel(){const e=this.savedEntry?.id===this.selectedId()?this.savedEntry:null;return e?e.label:this.selectedId()?this.messages.text("entry.saved",this.selectedId()):""}compareNames(e,t){return e.localeCompare(t,this.messages.locale,{sensitivity:"base",numeric:!0})}choose(e){const t=this.choices[e];if(this.disabled||this.configError||!t)return;if(t.loadMore){this.search(this.query,this.nextOffset);return}this.selectionRevision++,this.savedEntry=t.id?t:null,this.selectionUnavailable=!1,this.selectionWarning="";const i=this.savedEntry?{entryId:this.savedEntry.id}:null;this.value=i,this.close(),emit({type:"sfcc:value",payload:i}),emit({type:"sfcc:interacted"})}contentTypeLabel(e){return this.contentTypeNames&&Object.hasOwn(this.contentTypeNames,e)?this.contentTypeNames[e]:e}cancelSearch(){clearTimeout(this.timer),this.controller?.abort(),this.revision++,this.loading=!1}async requestItems(e,t){const i=this.config,s=await this.transport.request(e,t);return this.config===i&&s.contentTypeNames&&(this.contentTypeNames={...this.contentTypeNames,...s.contentTypeNames}),s}async search(e,t=0){if(this.cancelSearch(),this.disabled||this.configError)return;const i=this.revision;if(this.searchError="",!e.trim()&&this.recentEntries!==null){this.entries=this.recentEntries,this.nextOffset=null,this.refresh();return}this.controller=new AbortController,this.loading=!0,this.refresh();try{const s=await this.requestItems({q:e.trim(),offset:String(t)},this.controller.signal);if(i!==this.revision)return;const r=t?[...this.entries,...s.items]:s.items;this.entries=[...new Map(r.map(o=>[o.id,o])).values()],this.nextOffset=s.nextOffset,e.trim()||(this.recentEntries=this.entries,this.recentHasMore=s.hasMore)}catch(s){const r=s;if(i!==this.revision)return;this.searchError=r.code==="csrf_invalid"?this.messages.text("entry.csrf"):this.messages.text("entry.searchError")}finally{i===this.revision&&(this.loading=!1,this.refresh())}}async hydrateSelection(){const e=++this.selectionRevision,t=this.selectedId();if(this.savedEntry=null,this.selectionUnavailable=!1,this.selectionWarning="",this.entries=[],this.close(),!(!t||this.configError)){try{const i=await this.requestItems({entryId:t});if(e!==this.selectionRevision)return;this.savedEntry=i.items.find(s=>s.id===t)||null,this.selectionUnavailable=!this.savedEntry,this.selectionWarning=this.savedEntry?"":this.messages.text("entry.unavailable")}catch(i){const s=i;if(e!==this.selectionRevision)return;s.code==="csrf_invalid"?this.selectionWarning=this.messages.text("entry.lookupCsrf"):this.selectionWarning=this.messages.text(s.httpStatus===403?"entry.lookupDenied":"entry.lookupError")}this.expanded||(this.inputText=this.selectedLabel()),this.refresh()}}open(){this.disabled||this.configError||this.expanded||(this.expanded=!0,this.query="",this.entries=this.recentEntries||[],this.nextOffset=null,this.search(""))}validity(){const e=this.selectedId();return!this.required&&!e||!!(e&&!this.selectionUnavailable)}validate(){emit({type:"sfcc:valid",payload:this.validity()}),this.requestUpdate()}refresh(){(this.disabled||this.configError)&&(this.expanded=!1),this.activeIndex=-1,this.validate()}close(){this.cancelSearch(),this.expanded=!1,this.query="",this.activeIndex=-1,this.inputText=this.selectedLabel(),this.refresh()}setActive(e){this.activeIndex=e}option(e,t){return n.html`<div
            id=${`contentful-option-${t}`}
            class=${`contentful-entry-option${t===this.activeIndex?" contentful-entry-option_active":""}`}
            role="option"
            aria-selected=${String(t===this.activeIndex)}
            @click=${()=>this.choose(t)}
            >${e.label}</div
        >`}visibleEntries(){return this.entries.toSorted((e,t)=>this.compareNames(this.contentTypeLabel(e.contentType),this.contentTypeLabel(t.contentType))||e.contentType.localeCompare(t.contentType)||this.compareNames(e.label,t.label)||e.id.localeCompare(t.id))}get choices(){return this.expanded?[...this.selectedId()?[{id:"",label:this.messages.text("entry.clear")}]:[],...this.visibleEntries(),...this.nextOffset!==null&&!this.loading?[{label:this.messages.text("entry.more"),loadMore:!0}]:[]]:[]}render(){const e=this.disabled||!!this.configError,t=this.visibleEntries(),i=new Map;for(const o of t)i.has(o.contentType)||i.set(o.contentType,[]),i.get(o.contentType).push(o);const s=this.configError||this.searchError||this.selectionWarning;let r=this.messages.text("entry.prompt");return s?r=s:this.loading?r=this.messages.text("entry.searching"):this.expanded&&this.query?r=this.messages.count(this.nextOffset!==null?"entry.matchesMore":"entry.matches",t.length):this.expanded&&this.recentEntries&&(r=this.messages.count(this.recentHasMore?"entry.recentMore":"entry.recent",t.length)),n.html`<div class="slds-form-element"
            ><div class="contentful-entry-header"
                ><label class="slds-form-element__label contentful-entry-label_assistive" for="contentful-entry"
                    >${this.messages.text("entry.label")}</label
                ><p
                    id="contentful-status"
                    class=${`slds-form-element__help${s?" contentful-entry-status_error":""}`}
                    role="status"
                    aria-live="polite"
                    >${r}</p
                ></div
            ><div class="slds-form-element__control"
                ><div class="contentful-entry-input"
                    ><input
                        id="contentful-entry"
                        class="slds-input"
                        type="text"
                        role="combobox"
                        autocomplete="off"
                        aria-autocomplete="list"
                        aria-haspopup="listbox"
                        aria-controls="contentful-options"
                        aria-describedby="contentful-status"
                        aria-required=${String(this.required)}
                        aria-expanded=${String(this.expanded)}
                        aria-busy=${String(this.loading)}
                        aria-invalid=${String(!this.validity())}
                        aria-activedescendant=${this.activeIndex<0?n.nothing:`contentful-option-${this.activeIndex}`}
                        ?disabled=${e}
                        placeholder=${this.messages.text("entry.placeholder")}
                        .value=${this.inputText}
                        @focus=${this.onFocus}
                        @click=${this.open}
                        @input=${this.onInput}
                        @blur=${this.onBlur}
                        @keydown=${this.onKey} /><span
                        class="contentful-entry-indicator"
                        aria-hidden="true"
                    ></span></div
                ><div
                    id="contentful-options"
                    class="contentful-entry-options"
                    role="listbox"
                    ?hidden=${!this.expanded}
                    popover=${this.anchoredPopover?"manual":n.nothing}
                    aria-label=${this.messages.text("entry.choices")}
                    @mousedown=${this.onMouseDown}
                    >${this.expanded?n.html`${this.selectedId()?this.option({id:"",label:this.messages.text("entry.clear")},0):n.nothing}${Array.from(i,([o,a])=>{const l=`contentful-group-${t.indexOf(a[0])+ +!!this.selectedId()}`;return n.html`<div role="group" aria-labelledby=${l}
                                          ><div id=${l} class="contentful-entry-group-label"
                                              >${this.contentTypeLabel(o)}</div
                                          >${a.map(h=>this.option(h,t.indexOf(h)+ +!!this.selectedId()))}</div
                                      >`})}${this.nextOffset!==null&&!this.loading?this.option({label:this.messages.text("entry.more"),loadMore:!0},t.length+ +!!this.selectedId()):n.nothing}${!this.query.trim()&&this.recentHasMore&&!this.loading?n.html`<div class="contentful-entry-empty" role="note">${this.messages.text("entry.overflow")}</div>`:n.nothing}${t.length?n.nothing:n.html`<div class="contentful-entry-empty">${this.loading?this.messages.text("entry.searching"):this.searchError||(this.query.trim().length<2?this.messages.text("entry.hint"):this.messages.text("entry.empty"))}</div>`}`:n.nothing}</div
                ></div
            ></div
        >`}updated(){if(!this.isConnected)return;const e=this.querySelector("#contentful-options");document.body.classList.toggle("contentful-entry-open",this.anchoredPopover&&this.expanded),this.anchoredPopover&&(this.expanded?e.matches(":popover-open")||e.showPopover():e.matches(":popover-open")&&e.hidePopover()),this.activeIndex>=0&&e.querySelectorAll('[role="option"]')[this.activeIndex].scrollIntoView({block:"nearest"})}onFocus(){this.open(),this.querySelector("input").select()}onMouseDown(e){e.preventDefault()}onInput(e){this.inputText=e.target.value,this.query=this.inputText,this.expanded=!0,this.cancelSearch(),this.searchError="",this.entries=[],this.nextOffset=null,this.refresh(),!this.disabled&&!e.isComposing&&(this.timer=setTimeout(()=>this.search(this.query),300))}onBlur(){this.close(),emit({type:"sfcc:interacted"})}onKey(e){if(!(e.isComposing||this.disabled||this.configError))if(["ArrowDown","ArrowUp"].includes(e.key)){if(e.preventDefault(),this.open(),this.choices.length){let t=this.activeIndex<0?this.choices.length-1:Math.max(this.activeIndex-1,0);e.key==="ArrowDown"&&(t=Math.min(this.activeIndex+1,this.choices.length-1)),this.setActive(t)}}else e.key==="Enter"&&this.expanded&&this.activeIndex>=0?(e.preventDefault(),this.choose(this.activeIndex)):e.key==="Escape"&&this.expanded?(e.preventDefault(),this.close()):e.key==="Tab"&&this.close()}connectedCallback(){super.connectedCallback(),window.addEventListener("pagehide",this.onPageHide)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("pagehide",this.onPageHide),this.dispose()}dispose(){this.activeIndex=-1,this.cancelSearch(),this.selectionRevision++,this.expanded=!1,document.body.classList.remove("contentful-entry-open")}initialize(){this.onPageHide=()=>this.dispose(),subscribe("sfcc:ready",e=>{this.config=e.config,this.messages=window.ContentfulLocalization.create(this.config),document.documentElement.lang=this.messages.locale,document.documentElement.dir=this.messages.direction,this.contentTypeNames=null,this.recentEntries=null,this.recentHasMore=!1,this.transport=window.ContentfulPickerTransport.create(this.config),this.configError=this.transport.error,this.receiveValue(e.value),this.required=e.isRequired,this.disabled=e.isDisabled,this.hydrateSelection()}),subscribe("sfcc:value",e=>{this.receiveValue(e),this.hydrateSelection()}),subscribe("sfcc:disabled",e=>{this.disabled=e,this.close()}),subscribe("sfcc:required",e=>{this.required=e,this.validate()})}}customElements.define("contentful-entry-editor",c),document.body.className="contentful-entry-picker",document.body.append(document.createElement("contentful-entry-editor"))})(ContentfulEditorRuntime);
