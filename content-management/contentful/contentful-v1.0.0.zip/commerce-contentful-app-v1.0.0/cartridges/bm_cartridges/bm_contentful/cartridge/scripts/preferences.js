"use strict";
var Transaction = require("dw/system/Transaction");
/** Apply verified preference writes atomically; shared by manual and guided setup. */
function writePreferences(site, values) {
    Transaction.wrap(function () {
        // Preflight also rejects missing metadata for clears: their null readback would
        // otherwise look like a successfully cleared empty string.
        var definitions = site.getPreferences().describe();
        Object.keys(values).forEach(function (id) {
            if (!definitions.getCustomAttributeDefinition(id)) {
                throw new Error("Required preference metadata is missing");
            }
        });
        Object.keys(values).forEach(function (id) {
            // Keep the public setter's MRT synchronization notification. It can
            // swallow metadata/type failures, so verify inside the transaction
            // and throw to roll back all preceding writes on any mismatch.
            site.setCustomPreferenceValue(id, values[id]);
            var actual = site.getCustomPreferenceValue(id);
            // Cleared string/password attributes can be represented as null.
            if (actual !== values[id] && !(values[id] === "" && actual === null)) {
                throw new Error("Preference write verification failed");
            }
        });
    });
}
module.exports = { writePreferences: writePreferences };
