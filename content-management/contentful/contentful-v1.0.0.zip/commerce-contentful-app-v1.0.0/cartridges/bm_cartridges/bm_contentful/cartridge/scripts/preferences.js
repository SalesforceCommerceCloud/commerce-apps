"use strict";
var Transaction = require("dw/system/Transaction");
/** Apply verified preference writes atomically; shared by manual and guided setup. */
function writePreferences(site, values) {
    Transaction.wrap(function () {
        // Preflight also rejects missing metadata for clears: their null readback would
        // otherwise look like a successfully cleared empty string.
        var definitions = site.getPreferences().describe();
        Object.keys(values).forEach(function (id) {
            if (!definitions.getCustomAttributeDefinition(id)) {
                throw new Error("Required preference metadata is missing");
            }
        });
        Object.keys(values).forEach(function (id) {
            // Use the public setter and verify each value within the transaction.
            // Throw on any mismatch so all preceding writes are rolled back.
            site.setCustomPreferenceValue(id, values[id]);
            var actual = site.getCustomPreferenceValue(id);
            // Cleared string attributes can be represented as null.
            if (actual !== values[id] && !(values[id] === "" && actual === null)) {
                throw new Error("Preference write verification failed");
            }
        });
    });
}
module.exports = { writePreferences: writePreferences };
