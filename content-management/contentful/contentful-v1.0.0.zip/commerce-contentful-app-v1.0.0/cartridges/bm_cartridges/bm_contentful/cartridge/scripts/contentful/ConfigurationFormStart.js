"use strict";
/**
 * Read-only GET/XHR fragment under the existing site-specific Configuration module grant;
 * native BM routing enforces that grant, while this adapter checks login and request shape.
 * Resolve the selected merchant site and build a fresh CSRF-bearing form.
 * The same ConfigurationForm template is included by the normal page. Never render its
 * MenuFrame/assets in this background request: the live BM shell already owns them.
 * Re-rendering another full shell is the suspected cause of post-save cross-page styling
 * failures; local tests establish fragment shape, not live BM shell/style behavior.
 * @output ContentfulManagement : Object
 */
/* exported execute */
var execute = function execute(pdict) {
    response.setExpires(0);
    pdict.ContentfulManagement = { csrf: null };
    if (!session.userAuthenticated ||
        request.httpMethod !== "GET" ||
        request.httpHeaders.get("x-requested-with") !== "XMLHttpRequest") {
        response.setStatus(403);
        return PIPELET_NEXT;
    }
    var site = require("bm_contentful/cartridge/scripts/site").getSelectedSite();
    pdict.ContentfulManagement = require("bm_contentful/cartridge/scripts/configuration").view(site);
    if (!site) {
        response.setStatus(400);
    }
    return PIPELET_NEXT;
};
