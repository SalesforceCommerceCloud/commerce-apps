"use strict";
var Registry = require("dw/svc/LocalServiceRegistry");
var diagnostics = require("../diagnostics");
/**
 * Derive the installed credential ID using the same site substitution as CAP installation.
 *
 * @param site - Trusted selected site, never a site ID supplied by a browser request.
 * @param kind - Contentful API whose site-specific credential should be selected.
 * @returns The site-specific native credential ID; does not check whether the credential exists.
 */
function id(site, kind) {
    return "contentful.".concat(site.getID(), ".").concat(kind);
}
/**
 * Resolve a site's native credential through the public service API without a provider request.
 *
 * @param site - Trusted selected site whose credential should be resolved.
 * @param kind - Contentful API whose site-specific credential should be selected.
 * @returns The native credential, or null when resolution fails, including before the site's CAP installation.
 * @remarks Callers may read its password only server-side. Failures log safe metadata without credential values.
 */
function get(site, kind) {
    try {
        var service = Registry.createService("contentful.cda.api", {});
        service.setCredentialID(id(site, kind));
        return service.getConfiguration().getCredential();
    }
    catch (error) {
        diagnostics.log("warn", "credential.unavailable", { errorType: diagnostics.errorType(error) });
        // A missing credential (for example before the site's CAP install) is unconfigured.
        return null;
    }
}
module.exports = { id: id, get: get };
