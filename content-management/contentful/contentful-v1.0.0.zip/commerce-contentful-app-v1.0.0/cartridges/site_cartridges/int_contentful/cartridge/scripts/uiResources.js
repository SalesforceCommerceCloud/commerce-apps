"use strict";
var Resource = require("dw/web/Resource");
var StringUtils = require("dw/util/StringUtils");
/**
 * Resolve app UI copy independently of Business Manager's data-editing locale.
 * Explicit bundle names keep native Resource loading/caching, with UI region,
 * UI language, then English fallbacks. Never change the request or data locale.
 */
function msg(key, bundle, defaultMessage) {
    var locale = request.locale.replace(/-/g, "_");
    var language = locale.split("_")[0];
    var english = Resource.msg(key, "".concat(bundle, "_en"), defaultMessage);
    var languageMessage = Resource.msg(key, "".concat(bundle, "_").concat(language), english);
    return Resource.msg(key, "".concat(bundle, "_").concat(locale), languageMessage);
}
/** Preserve native Java MessageFormat semantics for the app's server-formatted messages. */
var msgf = function (key, bundle, defaultMessage) {
    var args = [msg(key, bundle, defaultMessage)];
    return StringUtils.format.apply(StringUtils, args.concat(Array.prototype.slice.call(arguments, 3)));
};
module.exports = { msg: msg, msgf: msgf };
