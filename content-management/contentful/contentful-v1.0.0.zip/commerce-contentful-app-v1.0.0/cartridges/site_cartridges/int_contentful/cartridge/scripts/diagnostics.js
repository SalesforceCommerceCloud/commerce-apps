/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
"use strict";
var Logger = require("dw/system/Logger");
var Site = require("dw/system/Site");
var logger = Logger.getLogger("contentful", "contentful");
/** Only caller-selected identifiers/counters are accepted; never pass config, errors or payloads. */
function log(level, event, details) {
    var site = Site.getCurrent();
    var metadata = { siteId: site ? site.getID() : "unknown" };
    Object.assign(metadata, details);
    logger[level]("contentful.{0} {1}", event, JSON.stringify(metadata));
}
// Do not serialize exception messages/stacks: upstream exceptions can contain credentials or content.
function errorType(error) {
    var name = error && error.name;
    return ["Error", "SyntaxError", "TypeError", "RangeError", "TimeoutError", "AbortError"].includes(name)
        ? name
        : "UnknownError";
}
module.exports = { log: log, errorType: errorType };
