"use strict";
var Status = require("dw/system/Status");
var Resource = require("dw/web/Resource");
var service = require("int_contentful/cartridge/scripts/services/cdaService");
var diagnostics = require("../diagnostics");
function status(level, code, messageKey, remediationKey, metadata) {
    metadata.status = code;
    metadata.reason = messageKey;
    diagnostics.log(code === "HEALTHY" ? "info" : "warn", "health.result", metadata);
    var result = new Status(level, code);
    result.addDetail("message", Resource.msg(messageKey, "contentfulHealth", null));
    if (remediationKey) {
        result.addDetail("remediation", Resource.msg(remediationKey, "contentfulHealth", null));
    }
    return result;
}
/** Lightweight, live ECOM connectivity probe; an empty content-type collection is healthy. */
function checkConnectionHealth() {
    var started = Date.now();
    var config;
    var stage = "configuration";
    function report(level, code, messageKey, remediationKey, details) {
        var metadata = details || {};
        metadata.durationMs = Date.now() - started;
        metadata.stage = stage;
        metadata.spaceId = config && config.spaceId;
        metadata.environment = config && config.environment;
        return status(level, code, messageKey, remediationKey, metadata);
    }
    try {
        config = service.getConfig();
        if (!config.spaceId || !config.token) {
            return report(Status.ERROR, "UNHEALTHY", "health.missing", "health.configure");
        }
        stage = "content_types";
        var response_1 = service.fetchContentTypes();
        if (!response_1.ok) {
            var code = response_1.error;
            if (code === 401 || code === 403) {
                return report(Status.ERROR, "DEGRADED", "health.auth", "health.credentials", { httpStatus: code });
            }
            if (code === 429) {
                return report(Status.ERROR, "DEGRADED", "health.rate", "health.retry", { httpStatus: code });
            }
            return report(Status.ERROR, "UNHEALTHY", "health.failed", "health.connection", {
                httpStatus: code,
            });
        }
        if (!response_1.object || !Array.isArray(response_1.object.items)) {
            return report(Status.ERROR, "UNHEALTHY", "health.invalid", "health.connection");
        }
        return report(Status.OK, "HEALTHY", "health.ok");
    }
    catch (error) {
        diagnostics.log("error", "health.exception", { stage: stage, errorType: diagnostics.errorType(error) });
        // Never expose upstream exception text, tokens, or response bodies in the BM UI.
        return report(Status.ERROR, "UNHEALTHY", "health.failed", "health.connection");
    }
}
module.exports = { checkConnectionHealth: checkConnectionHealth };
