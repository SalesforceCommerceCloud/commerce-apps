/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
"use strict";
/**
 * Contentful Content Delivery API (CDA) service wrapper.
 *
 * All outbound traffic goes through the SFCC service framework
 * (dw/svc/LocalServiceRegistry) — never dw.net.HTTPClient directly — so that
 * the rate limiting and circuit breaker configured on the `contentful.cda.api`
 * service profile (see impex/install/services.xml) govern every call.
 *
 * Connection settings are read from custom site preferences configured by the
 * merchant in Business Manager (see impex/install/meta). The CDA token is
 * stored as a `password`-type site preference and is never logged.
 */
var LocalServiceRegistry = require("dw/svc/LocalServiceRegistry");
var Site = require("dw/system/Site");
var diagnostics = require("../diagnostics");
var SERVICE_ID = "contentful.cda.api";
/**
 * Read the Contentful connection configuration from site preferences.
 * @returns {Object} connection settings
 */
function getConfig(options) {
    options = options || {};
    var prefs = (options.site || Site.getCurrent()).getPreferences().getCustom();
    return {
        spaceId: prefs.contentfulSpaceId || "",
        environment: prefs.contentfulEnvironment || "master",
        host: prefs.contentfulHost || "cdn.contentful.com",
        token: prefs.contentfulCdaToken || "",
    };
}
/** Explicit Status-page Preview configuration; never a default or credential fallback. */
function getPreviewConfig(options) {
    var site = (options && options.site) || Site.getCurrent();
    var prefs = site.getPreferences().getCustom();
    var config = getConfig({ site: site });
    config.host =
        prefs.contentfulPreviewHost ||
            (config.host === "cdn.eu.contentful.com" ? "preview.eu.contentful.com" : "preview.contentful.com");
    config.token = prefs.contentfulPreviewToken || "";
    return config;
}
/**
 * Create the CDA service. The request builder receives the resolved config and
 * targets entries, assets or the content-type collection; the response parser returns parsed JSON.
 * @returns {dw.svc.Service} configured service instance
 */
function createService() {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        /**
         * Build an authenticated GET for the selected resource. Assets use their own
         * media MIME filter and optional ID/search/order parameters, without entry
         * content-type or include parameters. Use the resolved server-side credentials.
         */
        createRequest: function (svc, config) {
            var contentTypes = config.resource === "content_types";
            var assets = config.resource === "assets";
            var resource = assets ? "assets" : "entries";
            if (contentTypes) {
                resource = "content_types";
            }
            var path = "/spaces/".concat(encodeURIComponent(config.spaceId), "/environments/").concat(encodeURIComponent(config.environment), "/").concat(resource);
            var query = "?limit=".concat(config.limit || 1, "&skip=").concat(config.skip || 0);
            if (contentTypes && config.typeIds) {
                query += "&sys.id[in]=".concat(encodeURIComponent(config.typeIds.join(",")));
            }
            if (assets) {
                query += "&mimetype_group=".concat(config.mimeGroup || "image");
                if (config.assetId) {
                    query += "&sys.id=".concat(encodeURIComponent(config.assetId));
                }
                if (config.order) {
                    query += "&order=".concat(encodeURIComponent(config.order));
                }
                if (config.query) {
                    query += "&query=".concat(encodeURIComponent(config.query));
                }
            }
            if (!contentTypes && !assets) {
                query += "&include=0";
                if (config.entryId) {
                    query += "&sys.id=".concat(encodeURIComponent(config.entryId));
                }
                if (config.order) {
                    query += "&order=".concat(encodeURIComponent(config.order));
                }
                if (config.query) {
                    query += "&query=".concat(encodeURIComponent(config.query));
                }
            }
            svc.setURL("https://".concat(config.host).concat(path).concat(query));
            svc.setRequestMethod("GET");
            svc.addHeader("Authorization", "Bearer ".concat(config.token));
            svc.addHeader("Content-Type", "application/json");
            return null;
        },
        parseResponse: function (svc, response) {
            return JSON.parse(response.text);
        },
        filterLogMessage: function (msg) {
            // Redact bearer tokens from communication logs.
            return msg.replace(/Bearer [^\r\n"]+/g, "Bearer ***");
        },
    });
}
function callService(config, svc) {
    var started = Date.now();
    var details = {
        serviceId: SERVICE_ID,
        spaceId: config.spaceId,
        environment: config.environment,
        resource: config.resource || "entries",
        skip: config.skip || 0,
    };
    diagnostics.log("debug", "service.request", details);
    try {
        var result = (svc || createService()).call(config);
        details.durationMs = Date.now() - started;
        details.httpStatus = result.error;
        details.ok = result.ok;
        // Result status/reasons are framework enums, not provider response text.
        details.serviceStatus = result.status;
        details.unavailableReason = result.unavailableReason;
        diagnostics.log(details.ok ? "debug" : "error", "service.result", details);
        return result;
    }
    catch (error) {
        details.durationMs = Date.now() - started;
        details.errorType = diagnostics.errorType(error);
        diagnostics.log("error", "service.exception", details);
        throw error;
    }
}
/** List available content types without depending on any configured model, slug or mappings. */
function fetchContentTypes(options) {
    var config = getConfig(options);
    config.resource = "content_types";
    config.limit = (options && options.limit) || 1;
    return callService(config);
}
/** Explicit Preview connectivity probe for the BM Status page; the CAP hook uses fetchContentTypes. */
function fetchPreviewContentTypes(options) {
    var config = getPreviewConfig(options);
    config.resource = "content_types";
    config.limit = (options && options.limit) || 1;
    return callService(config);
}
/** Missing connection settings mean no authenticated provider request can be made. */
function validatePickerConfig(config) {
    if (!config.spaceId || !config.token) {
        throw new Error("Missing Contentful configuration");
    }
}
/** Read schemas only for the bounded set of types in an entry result. */
function fetchPickerTypes(config, ids, svc) {
    var types = Object.create(null);
    for (var offset = 0; offset < ids.length; offset += 100) {
        var batch = ids.slice(offset, offset + 100);
        var result = callService(Object.assign({}, config, {
            resource: "content_types",
            typeIds: batch,
            limit: 100,
        }), svc);
        // JSON parsing alone does not establish a collection; validate it before traversal.
        if (!result.ok || !result.object || !Array.isArray(result.object.items)) {
            throw new Error("Contentful type metadata unavailable");
        }
        result.object.items.slice(0, 100).forEach(function (type) {
            // Provider metadata IDs are opaque and the sys.id[in] query scopes this response.
            types[type.sys.id] = type;
        });
    }
    return types;
}
/**
 * Published-entry discovery for the BM picker. Search text never enters diagnostics;
 * credentials and complete upstream entries never enter the JSON response.
 * A saved entryId is resolved without a text-search fallback.
 * @param {{site?: dw.system.Site, query?: string, entryId?: string, offset?: number}} [options] search inputs
 */
function searchContentEntries(options) {
    options = options || {};
    var site = options.site || Site.getCurrent();
    var empty = { items: [], hasMore: false, nextOffset: null, contentTypeNames: {} };
    var config = getConfig({ site: site });
    validatePickerConfig(config);
    // BM owns request parsing; callers supply typed options and IDs remain opaque.
    var query = options.query || "";
    var entryId = options.entryId || "";
    var offset = options.offset || 0;
    var svc = createService();
    function read(overrides) {
        var requestConfig = Object.assign({}, config, overrides);
        var result = callService(requestConfig, svc);
        var data = result.object;
        // Arbitrary successful JSON must not become a pageable Contentful collection.
        if (!result.ok || !data || !Array.isArray(data.items) || !Number.isInteger(data.total) || data.total < 0) {
            throw new Error("Contentful lookup failed");
        }
        return data;
    }
    function summarize(items, hasMore, nextOffset) {
        // Entry and content-type IDs come from the provider collection contract;
        // revalidating a local grammar would silently hide legitimate provider IDs.
        var ids = [];
        items.forEach(function (entry) {
            var id = entry.sys.contentType.sys.id;
            if (!ids.includes(id)) {
                ids.push(id);
            }
        });
        var types = Object.create(null);
        try {
            types = fetchPickerTypes(config, ids, svc);
        }
        catch (error) {
            diagnostics.log("warn", "picker.content_types_unavailable", { errorType: diagnostics.errorType(error) });
        }
        var contentTypeNames = Object.create(null);
        var summaries = items.map(function (entry) {
            var contentType = entry.sys.contentType.sys.id;
            var type = types[contentType];
            if (type && type.name && type.name.trim()) {
                contentTypeNames[contentType] = type.name.trim();
            }
            var label = type && entry.fields[type.displayField];
            return {
                id: entry.sys.id,
                contentType: contentType,
                label: typeof label === "string" && label.trim() ? label : entry.sys.id,
            };
        });
        return { items: summaries, hasMore: hasMore, nextOffset: nextOffset, contentTypeNames: contentTypeNames };
    }
    // A blank picker offers a bounded recent set across all content types, never a
    // complete catalog preload. CDA timestamps reflect the published version.
    if (!query && !entryId) {
        if (offset) {
            return empty;
        }
        var recent = read({ limit: 100, skip: 0, order: "-sys.updatedAt,sys.id" });
        return summarize(recent.items.slice(0, 100), recent.total > 100, null);
    }
    var id = entryId || (!offset ? query : "");
    if (id) {
        var exact = read({ entryId: id, limit: 1, skip: 0 });
        // The provider's sys.id filter establishes identity, as it does for asset hydration.
        // Exact saved selections do not depend on storefront rendering configuration.
        if (exact.items.length || entryId) {
            return summarize(exact.items.slice(0, 1), false, null);
        }
    }
    // Contentful ignores tokens shorter than two characters. Do not send a
    // whitespace/punctuation-only or single-letter-token query as a catalog search.
    var terms = query.split(/[\s.,!?;:'"()[\]{}<>/\\|@#$%^&*+=~`_-]+/);
    if (!terms.some(function (term) { return term.length >= 2; })) {
        return empty;
    }
    var data = read({ query: query, limit: 25, skip: offset });
    var next = offset + Math.min(data.items.length, 25);
    var hasMore = data.items.length > 0 && next < data.total && next <= 10000;
    var result = summarize(data.items.slice(0, 25), hasMore, hasMore ? next : null);
    diagnostics.log("info", "picker.loaded", { itemCount: result.items.length, skip: offset });
    return result;
}
/**
 * Browse/search a published media type using the selected site's Delivery credentials,
 * independently of entry mappings. assetId performs exact saved-ID
 * hydration with no text fallback; otherwise return up to 24 recent/text-matched assets
 * per page with bounded offsets. Queries containing only short tokens return no results.
 * Trust the collection/MIME query contract and skip assets without a file URL.
 * Return only the display metadata needed by the picker, preserving provider values.
 * Pagination advances by upstream item count, including assets omitted by filtering.
 * BM validates request parameters once; throw for absent configuration or upstream failures rather than treating them
 * as empty results; never return credentials or raw responses to the browser.
 * @param {{site?: dw.system.Site, query?: string, assetId?: string, offset?: number}|undefined} options search inputs
 * @param {string} mimeGroup image or video, supplied only by the public wrappers
 */
function searchMediaAssets(options, mimeGroup) {
    options = options || {};
    var config = getConfig({ site: options.site || Site.getCurrent() });
    validatePickerConfig(config);
    // BM owns request parsing; callers supply typed options and IDs remain opaque.
    var query = options.query || "";
    var assetId = options.assetId || "";
    var offset = options.offset === undefined ? 0 : options.offset;
    var empty = { items: [], hasMore: false, nextOffset: null };
    // Contentful ignores short tokens; never turn those queries into catalog lists.
    var terms = query.split(/[\s.,!?;:'"()[\]{}<>/\\|@#$%^&*+=~`_-]+/);
    if (query && !terms.some(function (term) { return term.length >= 2; })) {
        return empty;
    }
    var requestConfig = Object.assign({}, config, {
        resource: "assets",
        mimeGroup: mimeGroup,
        limit: assetId ? 1 : 24,
        skip: assetId ? 0 : offset,
        assetId: assetId,
        query: query,
        order: "-sys.updatedAt,sys.id",
    });
    var result = callService(requestConfig);
    if (!result.ok) {
        throw new Error("Contentful assets unavailable");
    }
    var data = result.object;
    var items = [];
    data.items.slice(0, assetId ? 1 : 24).forEach(function (asset) {
        var id = asset.sys.id;
        var fields = asset.fields;
        var file = fields.file;
        // /assets and mimetype_group already establish resource type and media kind.
        // Skip only assets without a usable file; preserve the API's URL and metadata.
        if (!file || !file.url) {
            return;
        }
        var item = {
            id: id,
            label: (fields.title || "").trim() || id,
            description: fields.description || "",
            contentType: file.contentType,
            url: file.url,
            fileName: file.fileName,
            fileSize: file.details && file.details.size,
        };
        // Dimensions are optional image metadata, not video metadata.
        var image = mimeGroup === "image" && file.details && file.details.image;
        if (image) {
            item.width = image.width;
            item.height = image.height;
        }
        items.push(item);
    });
    var next = offset + Math.min(data.items.length, 24);
    var hasMore = !assetId && data.items.length > 0 && next < data.total && next <= 10000;
    diagnostics.log("info", mimeGroup === "video" ? "picker.videos_loaded" : "picker.assets_loaded", {
        itemCount: items.length,
        skip: offset,
    });
    return { items: items, hasMore: hasMore, nextOffset: hasMore ? next : null };
}
/**
 * Browse or hydrate published image assets, retaining the existing image-picker API.
 * @param {{site?: dw.system.Site, query?: string, assetId?: string, offset?: number}} [options] search inputs
 */
function searchContentAssets(options) {
    return searchMediaAssets(options, "image");
}
/**
 * Browse or hydrate published video assets without assuming image transforms or video metadata.
 * @param {{site?: dw.system.Site, query?: string, assetId?: string, offset?: number}} [options] search inputs
 */
function searchContentVideoAssets(options) {
    return searchMediaAssets(options, "video");
}
module.exports = {
    searchContentVideoAssets: searchContentVideoAssets,
    searchContentAssets: searchContentAssets,
    searchContentEntries: searchContentEntries,
    getConfig: getConfig,
    getPreviewConfig: getPreviewConfig,
    createService: createService,
    fetchContentTypes: fetchContentTypes,
    fetchPreviewContentTypes: fetchPreviewContentTypes,
    SERVICE_ID: SERVICE_ID,
};
