"use strict";
/** Non-secret, per-site settings. An explicit origin is never read from request parameters. */
function resolve(preferences) {
    var configured = typeof preferences.contentfulPreviewEditorOrigin === "string"
        ? preferences.contentfulPreviewEditorOrigin.trim()
        : "";
    var origin = configured ||
        (preferences.contentfulHost === "cdn.eu.contentful.com" ||
            preferences.contentfulPreviewHost === "preview.eu.contentful.com"
            ? "https://app.eu.contentful.com"
            : "https://app.contentful.com");
    var match = /^https:\/\/([A-Za-z0-9.-]+|\[[A-Fa-f0-9:]+\])(?::([0-9]{1,5}))?$/i.exec(origin);
    if (!match || (match[2] !== undefined && (Number(match[2]) < 1 || Number(match[2]) > 65535))) {
        throw new Error("Invalid Contentful editor origin");
    }
    return {
        inspector: preferences.contentfulPreviewInspector === true,
        editorOrigin: "https://".concat(match[1].toLowerCase()).concat(match[2] && Number(match[2]) !== 443 ? ":".concat(Number(match[2])) : ""),
    };
}
module.exports = { resolve: resolve };
