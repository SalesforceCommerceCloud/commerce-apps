"use strict";
/** Resolve on each load: the current site's cartridge path owns the selected provider. */
function getConfig() {
    var selected = require("*/cartridge/scripts/contentful/config");
    var config = selected.getConfig();
    if (!config || typeof config !== "object") {
        throw new Error("Invalid SFRA configuration");
    }
    if (!config.mappings || typeof config.mappings !== "object" || Array.isArray(config.mappings)) {
        throw new Error("Invalid SFRA mappings");
    }
    if (typeof config.transformLocale !== "function") {
        throw new Error("Invalid SFRA locale transformer");
    }
    return config;
}
module.exports = { getConfig: getConfig };
