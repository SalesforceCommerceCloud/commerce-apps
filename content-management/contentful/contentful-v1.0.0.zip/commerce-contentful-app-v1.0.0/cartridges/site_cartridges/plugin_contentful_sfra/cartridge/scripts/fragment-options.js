"use strict";
/** Preserve opaque IDs and authored text; native stringValue trims both. */
function raw(parameters, key) {
    var value = parameters.get(key).rawValue;
    return value === null ? undefined : value;
}
/** Props are inert JSON data, kept separate from routing and trusted configuration. */
function parseProps(json) {
    var props = JSON.parse(json);
    if (!props || typeof props !== "object" || Array.isArray(props)) {
        throw new Error("Invalid Contentful fragment props");
    }
    return props;
}
/** Every fragment handler uses the same generic payload boundary. */
function read(parameters) {
    var id = raw(parameters, "id");
    if (!id || !id.trim()) {
        throw new Error("Invalid Contentful fragment selection");
    }
    var result = { id: id };
    result.locale = raw(parameters, "locale");
    var props = raw(parameters, "props");
    if (props !== undefined) {
        result.props = parseProps(props);
    }
    return result;
}
module.exports = { read: read };
