"use strict";
var options = require("./fragment-options");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/** Published HTML only. The Web Adapter invokes this independently of parent cache hits. */
function run(handler) {
    response.setExpires(0);
    response.setContentType("text/html;charset=UTF-8");
    if (!request.includeRequest || request.httpMethod !== "GET") {
        response.setStatus(404);
        return;
    }
    var input;
    try {
        input = options.read(request.httpParameterMap);
    }
    catch (error) {
        diagnostics.log("warn", "sfra.fragment.invalid", { errorType: diagnostics.errorType(error) });
        response.setStatus(400);
        return;
    }
    try {
        var html = handler(input);
        response.getWriter().print(html);
    }
    catch (error) {
        // Keep failures empty and uncached, so the containing page survives and the next include can recover.
        diagnostics.log("error", "sfra.fragment.failed", {
            entryId: input.id,
            errorType: diagnostics.errorType(error),
        });
    }
}
module.exports = { run: run };
