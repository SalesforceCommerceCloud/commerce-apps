"use strict";
var Template = require("dw/util/Template");
var HashMap = require("dw/util/HashMap");
function renderData(data, previewLocale, props) {
    if (!data) {
        return "";
    }
    var model = new HashMap();
    var callerProps = props || {};
    var values = Object.assign({}, data.values);
    var prepared = data.prepare ? data.prepare(values, callerProps) : values;
    model.put("contentful", prepared);
    model.put("contentfulProps", callerProps);
    var inspector = {};
    // Raw provenance lets templates print each attribute value with ISML encoding.
    var provenance = {};
    // Only generated attribute names and HTML-encoded provenance enter the raw attribute slot.
    function encode(value) {
        return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    for (var _i = 0, _a = Object.keys(data.sources || {}); _i < _a.length; _i++) {
        var key = _a[_i];
        var source = data.sources[key];
        if (previewLocale) {
            inspector[key] =
                "data-contentful-".concat(source.kind, "-id=\"").concat(encode(source.id), "\" data-contentful-field-id=\"").concat(encode(source.field), "\" data-contentful-locale=\"").concat(encode(previewLocale), "\"");
            provenance[key] = { kind: source.kind, id: source.id, field: source.field, locale: previewLocale };
        }
    }
    model.put("contentfulInspector", inspector);
    model.put("contentfulProvenance", provenance);
    var regions = new HashMap();
    for (var _b = 0, _c = Object.keys(data.regions || {}); _b < _c.length; _b++) {
        var region = _c[_b];
        regions.put(region, data.regions[region].map(function (child) { return renderData(child, previewLocale); }).join(""));
    }
    model.put("contentfulRegions", regions);
    return new Template(data.template).render(model).text;
}
module.exports = { renderData: renderData };
