"use strict";
var fragments = require("../../../scripts/fragments");
var content = require("../../../scripts/content");
var renderer = require("../../../scripts/render");
var media = require("../../../scripts/media");
/** Also reusable as a trusted mapped renderer's preparation callback. */
function prepare(values, props) {
    var result = Object.assign({}, values);
    var sources = media.imageSources(values);
    result.src = sources.src;
    result.srcSet = sources.srcSet;
    if (result.width !== undefined) {
        result.width = String(result.width);
    }
    if (result.height !== undefined) {
        result.height = String(result.height);
    }
    result.alt = typeof values.label === "string" ? values.label : "";
    if (typeof values.alt === "string") {
        result.alt = values.alt;
    }
    if (props.decorative === true) {
        result.alt = "";
    }
    else if (typeof props.altText === "string" && props.altText.trim()) {
        result.alt = props.altText;
    }
    return result;
}
function load(id, locale) {
    return content.load(id, locale, {
        resource: "assets",
        adapt: function (payload, _config, storefrontLocale) {
            var fields = payload.items[0].fields;
            var file = fields && fields.file;
            if (!file) {
                return null;
            }
            var asset = file;
            if (typeof asset.url !== "string" ||
                typeof asset.contentType !== "string" ||
                !asset.contentType.startsWith("image/") ||
                !/^(https?:\/\/|\/\/)/i.test(asset.url)) {
                return null;
            }
            var label = typeof fields.title === "string" ? fields.title : "";
            if (typeof fields.description === "string") {
                label = fields.description;
            }
            var values = {
                url: asset.url,
                label: label,
                mime: asset.contentType,
                locale: storefrontLocale,
            };
            if (asset.details) {
                values.fileSize = asset.details.size;
                if (asset.details.image) {
                    values.width = asset.details.image.width;
                    values.height = asset.details.image.height;
                }
            }
            return { template: "contentful/sfra/image", values: values, prepare: prepare };
        },
    });
}
function renderFragment(input) {
    return renderer.renderData(load(input.id, input.locale), undefined, input.props);
}
function render(context) {
    var selection = context.content.get("contentfulAsset");
    return fragments.renderInclude({
        action: "ContentfulFragment-Image",
        id: selection ? selection.get("assetId") : "",
        locale: request.locale,
        props: { altText: context.content.get("altText"), decorative: context.content.get("decorative") },
    });
}
module.exports = { render: render, renderFragment: renderFragment, load: load, prepare: prepare };
