"use strict";
/** Reuse these trusted template/region definitions across content type mappings. */
var editorial = { template: "contentful/sfra/editorial", regions: [] };
var grid = { template: "contentful/sfra/grid", regions: ["left", "right"] };
var mappings = {
    sfnextDemoAboutUsCard: {
        renderer: editorial,
        fields: {
            title: "title",
            description: "description",
            imageUrl: "image.fields.file.url",
            imageAlt: "imageAlt",
        },
    },
    sfnextDemoAboutUsGrid: {
        renderer: grid,
        regions: { left: "left", right: "right" },
    },
};
module.exports = mappings;
