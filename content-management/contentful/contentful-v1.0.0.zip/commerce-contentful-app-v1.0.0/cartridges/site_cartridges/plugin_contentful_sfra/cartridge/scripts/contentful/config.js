"use strict";
var mappings = require("../config/mappings");
/** Salesforce locale IDs use underscores; Contentful commonly uses BCP 47 hyphens. */
function transformLocale(storefrontLocale) {
    return storefrontLocale.replace(/_/g, "-");
}
/** Customer cartridges may replace this module or explicitly extend it with module.superModule. */
function getConfig() {
    return {
        mappings: mappings,
        transformLocale: transformLocale,
    };
}
module.exports = { getConfig: getConfig };
