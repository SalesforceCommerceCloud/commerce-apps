"use strict";
var LocalServiceRegistry = require("dw/svc/LocalServiceRegistry");
var connection = require("int_contentful/cartridge/scripts/services/cdaService");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/** Shopper fetching is separate from picker search; credentials/profile remain shared. */
function fetchResource(resource, id, locale, depth) {
    return fetch(connection.getConfig(), resource, id, locale, depth);
}
/** Explicit draft API: never fall back to Delivery credentials or hosts. */
function fetchPreviewEntry(id, locale, depth) {
    return fetch(connection.getPreviewConfig(), "entries", id, locale, depth);
}
function fetch(config, resource, id, locale, depth) {
    if (!config.spaceId || !config.token) {
        return null;
    }
    var service = LocalServiceRegistry.createService(connection.SERVICE_ID, {
        createRequest: function (svc) {
            var path = "/spaces/".concat(encodeURIComponent(config.spaceId), "/environments/").concat(encodeURIComponent(config.environment), "/").concat(resource);
            var query = "?sys.id=".concat(encodeURIComponent(id), "&limit=1");
            // No transformed locale delegates locale selection to Contentful's configured default.
            if (locale != null) {
                query += "&locale=".concat(encodeURIComponent(locale));
            }
            if (resource === "entries") {
                query += "&include=".concat(depth);
            }
            svc.setURL("https://".concat(config.host).concat(path).concat(query));
            svc.setRequestMethod("GET");
            svc.addHeader("Authorization", "Bearer ".concat(config.token));
            return null;
        },
        parseResponse: function (svc, client) {
            return JSON.parse(client.text);
        },
        // Shopper payloads must remain private even if communication logging is enabled.
        getRequestLogMessage: function () {
            return "Contentful SFRA request";
        },
        getResponseLogMessage: function () {
            return "Contentful SFRA response";
        },
        filterLogMessage: function () {
            return "Contentful SFRA communication redacted";
        },
    });
    var result = service.call();
    diagnostics.log(result.ok ? "debug" : "error", "sfra.service.result", {
        entryId: id,
        httpStatus: result.error,
        serviceStatus: result.status,
    });
    return result.ok ? result.object : null;
}
module.exports = { fetchResource: fetchResource, fetchPreviewEntry: fetchPreviewEntry };
