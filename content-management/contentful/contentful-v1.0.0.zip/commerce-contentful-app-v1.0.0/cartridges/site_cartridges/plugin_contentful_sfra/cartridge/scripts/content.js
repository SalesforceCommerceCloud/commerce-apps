"use strict";
var Site = require("dw/system/Site");
var service = require("./service");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
var configuration = require("./configuration");
/** Resolve IDs before settings; drafts and raw upstream data never leave this boundary. */
function load(id, requestedLocale, loader) {
    if (typeof id !== "string" || !id.trim()) {
        return null;
    }
    try {
        var config = configuration.getConfig();
        var site = Site.getCurrent();
        var resolvedLocale = requestedLocale === "default" ? site.getDefaultLocale() : requestedLocale;
        var sfLocale = resolvedLocale && resolvedLocale !== "default" && resolvedLocale.trim() ? resolvedLocale : undefined;
        // Without a resolved storefront locale, let Contentful select its configured default.
        var locale = sfLocale ? config.transformLocale(sfLocale) : undefined;
        if (locale != null && (typeof locale !== "string" || !locale.trim())) {
            throw new Error("Invalid transformed locale");
        }
        var configuredDepth = loader.referenceDepth
            ? site.getCustomPreferenceValue("contentfulReferenceDepth")
            : null;
        var depth = configuredDepth == null ? 3 : Number(configuredDepth);
        if (!Number.isInteger(depth) || depth < 0 || depth > 10) {
            return null;
        }
        var raw = service.fetchResource(loader.resource, id, locale, depth);
        if (!raw ||
            typeof raw !== "object" ||
            !Array.isArray(raw.items) ||
            !raw.items.length) {
            return null;
        }
        var payload = raw;
        return loader.adapt(payload, config, sfLocale);
    }
    catch (error) {
        diagnostics.log("error", "sfra.loader.failed", { entryId: id, errorType: diagnostics.errorType(error) });
        return null;
    }
}
module.exports = { load: load };
