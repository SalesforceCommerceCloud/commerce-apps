"use strict";
var fragments = require("../../../scripts/fragments");
var content = require("../../../scripts/content");
var renderer = require("../../../scripts/render");
var image = require("./contentfulImage");
function text(value) {
    return typeof value === "string" ? value : "";
}
/** Also reusable as a trusted mapped renderer's preparation callback. */
function prepare(values, props) {
    var result = Object.assign({}, values);
    var settings = Object.assign({}, values, props);
    var label = text(props.videoLabel);
    if (label.trim()) {
        result.label = label;
    }
    result.autoPlay = settings.autoPlay === true;
    result.muted = result.autoPlay || settings.muted === true;
    result.loop = settings.loop === true;
    var preload = settings.preload;
    result.preload = preload === "auto" || preload === "metadata" || preload === "none" ? preload : "auto";
    var captions = text(settings.captionsUrl === undefined ? values.captions : settings.captionsUrl).trim();
    result.captions = /^(https?:\/\/|\/|[^:/?#]+(?:[/?#]|$))/i.test(captions) ? captions : "";
    result.language = (text(settings.captionsLanguage).trim() || text(values.language) || text(values.locale)).replace(/_/g, "-");
    return result;
}
function load(id, locale) {
    return content.load(id, locale, {
        resource: "assets",
        adapt: function (payload, _config, storefrontLocale) {
            var fields = payload.items[0].fields;
            var file = fields && fields.file;
            if (!file) {
                return null;
            }
            var asset = file;
            if (typeof asset.url !== "string" ||
                typeof asset.contentType !== "string" ||
                !asset.contentType.startsWith("video/") ||
                !/^(https?:\/\/|\/\/)/i.test(asset.url)) {
                return null;
            }
            var label = typeof fields.title === "string" ? fields.title : "";
            if (typeof fields.description === "string" && fields.description.trim()) {
                label = fields.description;
            }
            return {
                template: "contentful/sfra/video",
                values: { url: asset.url, label: label, mime: asset.contentType, locale: storefrontLocale },
                prepare: prepare,
            };
        },
    });
}
function renderFragment(input) {
    var data = load(input.id, input.locale);
    var props = input.props || {};
    var poster = props.posterAssetId;
    if (data && poster) {
        var asset = image.load(poster, input.locale);
        if (asset) {
            data.values.poster = asset.values.url;
        }
    }
    return renderer.renderData(data, undefined, props);
}
function render(context) {
    var selection = context.content.get("contentfulAsset");
    var poster = context.content.get("posterAsset");
    return fragments.renderInclude({
        action: "ContentfulFragment-Video",
        id: selection ? selection.get("assetId") : "",
        locale: request.locale,
        props: {
            posterAssetId: poster && poster.get("assetId"),
            videoLabel: context.content.get("videoLabel"),
            autoPlay: context.content.get("autoPlay"),
            muted: context.content.get("muted"),
            loop: context.content.get("loop"),
            preload: context.content.get("preload"),
            captionsUrl: context.content.get("captionsUrl"),
            captionsLanguage: context.content.get("captionsLanguage"),
        },
    });
}
module.exports = { render: render, renderFragment: renderFragment, load: load, prepare: prepare };
