"use strict";
var URLUtils = require("dw/web/URLUtils");
var Template = require("dw/util/Template");
var HashMap = require("dw/util/HashMap");
/** A local, stable URL; only explicit routing fields and public presentation props are serialized. */
function getIncludeUrl(input) {
    var url = URLUtils.url(input.action);
    url.append("id", input.id);
    if (input.locale !== undefined && input.locale !== null) {
        url.append("locale", input.locale);
    }
    if (input.props !== undefined) {
        url.append("props", JSON.stringify(input.props));
    }
    return url;
}
/** Return native include markup without fetching content or changing the parent's cache policy. */
function renderInclude(input) {
    if (!input.id || !input.id.trim()) {
        return "";
    }
    var model = new HashMap();
    model.put("contentfulIncludeUrl", getIncludeUrl(input));
    return new Template("contentful/sfra/include").render(model).text;
}
module.exports = { getIncludeUrl: getIncludeUrl, renderInclude: renderInclude };
