/* global ContentfulLivePreviewSDK */
(() => {
    const body = document.body;
    let stopped = false;
    let timer;
    let unsubscribe;
    function cleanup() {
        stopped = true;
        clearTimeout(timer);
        if (unsubscribe) {
            unsubscribe();
        }
    }
    window.addEventListener("pagehide", cleanup, { once: true });
    // External scripts keep inline configuration and CSP nonces out of this cartridge.
    Promise.resolve()
        .then(() =>
            ContentfulLivePreviewSDK.ContentfulLivePreview.init({
                locale: body.dataset.contentfulPreviewLocale,
                targetOrigin: body.dataset.contentfulPreviewOrigin,
                enableInspectorMode: body.dataset.contentfulPreviewInspector === "true",
                enableLiveUpdates: true,
            }),
        )
        .then(() => {
            if (stopped) {
                return;
            }
            unsubscribe = ContentfulLivePreviewSDK.ContentfulLivePreview.subscribe("save", {
                callback() {
                    clearTimeout(timer);
                    timer = setTimeout(() => window.location.reload(), 150);
                },
            });
        })
        .catch(() => {
            // Server-rendered content remains usable when SDK initialization fails.
        });
})();
