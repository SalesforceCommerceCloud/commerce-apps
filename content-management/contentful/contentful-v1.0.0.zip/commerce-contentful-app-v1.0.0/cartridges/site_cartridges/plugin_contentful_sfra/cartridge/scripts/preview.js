"use strict";
var previewSettings = require("int_contentful/cartridge/scripts/previewSettings");
var Site = require("dw/system/Site");
var Bytes = require("dw/util/Bytes");
var MessageDigest = require("dw/crypto/MessageDigest");
var configuration = require("./configuration");
var service = require("./service");
var mapping = require("./mapping");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/** Fixed-size digests avoid early exits on matching prefixes; no native timingSafeEqual exists. */
function matches(candidate, secret) {
    var a = new MessageDigest(MessageDigest.DIGEST_SHA_256).digestBytes(new Bytes(candidate));
    var b = new MessageDigest(MessageDigest.DIGEST_SHA_256).digestBytes(new Bytes(secret));
    var different = 0;
    for (var index = 0; index < a.length; index++) {
        different |= a.byteAt(index) ^ b.byteAt(index);
    }
    return different === 0;
}
/** This boundary authorizes before configuration, mapping or any upstream request. */
function load(parameters, storefrontLocale) {
    if (!parameters.cfpreview.submitted) {
        return { status: 404 };
    }
    try {
        var site = Site.getCurrent();
        var secret = site.getCustomPreferenceValue("contentfulPreviewSecret");
        var token = site.getCustomPreferenceValue("contentfulPreviewToken");
        if (!request.httpSecure || !secret || !token || !matches(parameters.cfpreview.stringValue, secret)) {
            return { status: 403 };
        }
        var id = parameters.entryId.stringValue;
        if (!id || !id.trim()) {
            return { status: 404 };
        }
        var config = configuration.getConfig();
        var override = parameters.cf_locale.stringValue;
        var locale = override ||
            config.transformLocale(storefrontLocale === "default" ? site.getDefaultLocale() : storefrontLocale);
        // The SDK and Preview API must use exactly one locale; wildcard/multilocale responses are unsupported.
        if (typeof locale !== "string" || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(locale)) {
            return { status: 400 };
        }
        var settings = previewSettings.resolve({
            contentfulHost: site.getCustomPreferenceValue("contentfulHost"),
            contentfulPreviewHost: site.getCustomPreferenceValue("contentfulPreviewHost"),
            contentfulPreviewInspector: site.getCustomPreferenceValue("contentfulPreviewInspector"),
            contentfulPreviewEditorOrigin: site.getCustomPreferenceValue("contentfulPreviewEditorOrigin"),
        });
        var configuredDepth = site.getCustomPreferenceValue("contentfulReferenceDepth");
        var depth = configuredDepth == null ? 3 : Number(configuredDepth);
        if (!Number.isInteger(depth) || depth < 0 || depth > 10) {
            return { status: 400 };
        }
        var raw = service.fetchPreviewEntry(id, locale, depth);
        if (!raw || !Array.isArray(raw.items) || !raw.items.length) {
            return { status: 404 };
        }
        var data = mapping.adapt(raw, config.mappings, settings.inspector);
        if (!data) {
            return { status: 404 };
        }
        return { status: 200, data: data, locale: locale, settings: settings };
    }
    catch (error) {
        diagnostics.log("error", "sfra.preview.failed", { errorType: diagnostics.errorType(error) });
        return { status: 404 };
    }
}
module.exports = { load: load };
