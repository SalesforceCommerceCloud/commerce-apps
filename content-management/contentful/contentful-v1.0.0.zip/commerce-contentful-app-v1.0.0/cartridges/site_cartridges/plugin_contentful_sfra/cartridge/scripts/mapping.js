"use strict";
var BLOCKED = ["__proto__", "constructor", "prototype"];
var RESERVED = [
    "children",
    "ref",
    "key",
    "data",
    "component",
    "componentData",
    "designMetadata",
    "regionId",
    "dangerouslySetInnerHTML",
];
function object(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function name(value) {
    return typeof value === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(value) && !BLOCKED.includes(value);
}
function json(value, depth, limit) {
    if (depth > limit) {
        return false;
    }
    if (value === null || typeof value === "string" || typeof value === "boolean") {
        return true;
    }
    if (typeof value === "number") {
        return Number.isFinite(value);
    }
    if (Array.isArray(value)) {
        return value.every(function (item) { return json(item, depth + 1, limit); });
    }
    return (object(value) &&
        Object.prototype.toString.call(value) === "[object Object]" &&
        Object.keys(value).every(function (key) { return (limit === Number.POSITIVE_INFINITY || name(key)) && json(value[key], depth + 1, limit); }));
}
/** Configuration is deployed code-owned data, but guards prevent unsafe props and traversal. */
function validate(mapping) {
    if (Object.keys(mapping).some(function (key) { return !["renderer", "fields", "defaults", "labelField", "regions"].includes(key); })) {
        throw new Error("Unknown mapping option");
    }
    for (var _i = 0, _a = ["fields", "defaults", "regions"]; _i < _a.length; _i++) {
        var group = _a[_i];
        var values = mapping[group] === undefined ? {} : mapping[group];
        if (!object(values) || Object.keys(values).length > (group === "regions" ? 20 : 100)) {
            throw new Error("Invalid mapping group");
        }
        for (var _b = 0, _c = Object.keys(values); _b < _c.length; _b++) {
            var key = _c[_b];
            if (!name(key) || (group !== "regions" && (/^on/i.test(key) || RESERVED.includes(key)))) {
                throw new Error("Unsafe mapping key");
            }
            var value = values[key];
            if (group === "defaults") {
                if (!json(value, 0, 8)) {
                    throw new Error("Invalid default");
                }
            }
            else if (typeof value !== "string" ||
                value.length > 2048 ||
                value.split(".").length > 16 ||
                !value.split(".").every(name)) {
                throw new Error("Invalid path");
            }
        }
    }
}
/** Traverse requested paths only; selecting a JSON object does not recursively expand its links. */
function field(resource, path, payload, source) {
    var value = resource.fields;
    var segments = path.split(".");
    var _loop_1 = function (index) {
        var segment = segments[index];
        if (value === null || typeof value !== "object") {
            return { value: undefined };
        }
        var sys = value.sys;
        if (sys && sys.type === "Link") {
            var links = [];
            if (payload.includes && (sys.linkType === "Asset" || sys.linkType === "Entry")) {
                links = payload.includes[sys.linkType] || [];
            }
            value = links.find(function (item) { return item.sys.id === sys.id; });
            if (!value) {
                return { value: undefined };
            }
            if (source) {
                source.id = sys.id;
                source.kind = sys.linkType === "Asset" ? "asset" : "entry";
                source.field = segment === "fields" ? segments[index + 1] || "" : "";
            }
        }
        if (!Object.prototype.hasOwnProperty.call(value, segment)) {
            return { value: undefined };
        }
        value = value[segment];
    };
    for (var index = 0; index < segments.length; index++) {
        var state_1 = _loop_1(index);
        if (typeof state_1 === "object")
            return state_1.value;
    }
    return value;
}
function adapt(payload, mappings, inspector) {
    var remaining = 100;
    // Reuse validation within this load only; site-specific providers can change between loads.
    var validatedModels = [];
    var entries = payload.items.concat((payload.includes && payload.includes.Entry) || []);
    function visit(entry, ancestors, depth) {
        if (depth > 8 || remaining <= 0 || ancestors.includes(entry.sys.id)) {
            return null;
        }
        remaining--;
        var model = entry.sys.contentType && entry.sys.contentType.sys.id;
        if (!model || BLOCKED.includes(model) || !Object.prototype.hasOwnProperty.call(mappings, model)) {
            return null;
        }
        var mapping = mappings[model];
        var view = mapping.renderer;
        if (!validatedModels.includes(model)) {
            if (!object(view)) {
                return null;
            }
            if (typeof view.template !== "string" ||
                !view.template.trim() ||
                !Array.isArray(view.regions) ||
                !view.regions.every(function (region) { return typeof region === "string"; }) ||
                (view.prepare !== undefined && typeof view.prepare !== "function")) {
                throw new Error("Invalid renderer definition");
            }
            validate(mapping);
            for (var _i = 0, _a = Object.keys(mapping.regions || {}); _i < _a.length; _i++) {
                var region = _a[_i];
                if (!view.regions.includes(region)) {
                    throw new Error("Undeclared renderer region");
                }
            }
            validatedModels.push(model);
        }
        var values = mapping.defaults ? JSON.parse(JSON.stringify(mapping.defaults)) : {};
        var sources = {};
        for (var _b = 0, _c = Object.keys(mapping.fields || {}); _b < _c.length; _b++) {
            var key = _c[_b];
            var source = void 0;
            if (inspector) {
                source = { id: entry.sys.id, kind: "entry", field: mapping.fields[key].split(".")[0] };
            }
            var value = field(entry, mapping.fields[key], payload, source);
            if (value !== undefined) {
                if (!json(value, 0, Number.POSITIVE_INFINITY)) {
                    throw new Error("Invalid mapped value");
                }
                values[key] = value;
                if (source && source.field) {
                    sources[key] = source;
                }
            }
        }
        var tree = { template: view.template, values: values };
        if (view.prepare) {
            tree.prepare = view.prepare;
        }
        if (inspector) {
            tree.sources = sources;
        }
        if (mapping.regions) {
            tree.regions = {};
            for (var _d = 0, _e = Object.keys(mapping.regions); _d < _e.length; _d++) {
                var region = _e[_d];
                var value = field(entry, mapping.regions[region], payload);
                var links = [];
                if (value != null) {
                    links = Array.isArray(value) ? value : [value];
                }
                var children = [];
                var _loop_2 = function (link) {
                    if (!link || !link.sys || link.sys.type !== "Link" || link.sys.linkType !== "Entry") {
                        return "continue";
                    }
                    var child = entries.find(function (item) { return item.sys.id === link.sys.id; });
                    if (!child) {
                        return "continue";
                    }
                    var mapped = visit(child, ancestors.concat(entry.sys.id), depth + 1);
                    if (mapped) {
                        children.push(mapped);
                    }
                };
                for (var _f = 0, links_1 = links; _f < links_1.length; _f++) {
                    var link = links_1[_f];
                    _loop_2(link);
                }
                tree.regions[region] = children;
            }
        }
        return tree;
    }
    return visit(payload.items[0], [], 0);
}
module.exports = { adapt: adapt };
