"use strict";
var preview = require("../scripts/preview");
var renderer = require("../scripts/render");
var Template = require("dw/util/Template");
var HashMap = require("dw/util/HashMap");
var URLUtils = require("dw/web/URLUtils");
var diagnostics = require("int_contentful/cartridge/scripts/diagnostics");
/** Native public controller: authorization is inside preview.load, before draft access. */
function Show() {
    response.setExpires(0);
    // Cache-Control is platform-managed and is not an allowed native setHttpHeader name.
    response.setHttpHeader("Referrer-Policy", "no-referrer");
    response.setHttpHeader("X-Robots-Tag", "noindex, nofollow");
    response.setContentType("text/html;charset=UTF-8");
    var result = preview.load(request.httpParameterMap, request.locale);
    response.setStatus(result.status);
    if (result.status !== 200) {
        response.getWriter().print("Contentful preview unavailable.");
        return;
    }
    var html;
    try {
        var model = new HashMap();
        model.put("contentfulHtml", renderer.renderData(result.data, result.locale));
        model.put("contentfulPreview", {
            locale: result.locale,
            origin: result.settings.editorOrigin,
            inspector: result.settings.inspector,
        });
        model.put("contentfulPreviewSdk", URLUtils.staticURL("/js/vendor/contentful-live-preview.js").toString());
        model.put("contentfulPreviewScript", URLUtils.staticURL("/js/preview.js").toString());
        html = new Template("contentful/sfra/preview").render(model).text;
    }
    catch (error) {
        diagnostics.log("error", "sfra.preview.failed", { errorType: diagnostics.errorType(error) });
        response.setStatus(404);
        response.getWriter().print("Contentful preview unavailable.");
        return;
    }
    // Native Response cannot read/merge CSP. Preserve an existing merchant policy.
    // Modern browsers give an enforced frame-ancestors directive precedence over X-Frame-Options.
    if (!response.containsHttpHeader("Content-Security-Policy")) {
        response.setHttpHeader("Content-Security-Policy", "frame-ancestors ".concat(result.settings.editorOrigin));
    }
    response.getWriter().print(html);
}
Show.public = true;
module.exports = { Show: Show };
