"use strict";
var fragment = require("../scripts/fragment");
var content = require("../experience/components/ContentfulSFRA/contentfulContent");
var image = require("../experience/components/ContentfulSFRA/contentfulImage");
var video = require("../experience/components/ContentfulSFRA/contentfulVideo");
function Entry() {
    fragment.run(content.renderFragment);
}
function Image() {
    fragment.run(image.renderFragment);
}
function Video() {
    fragment.run(video.renderFragment);
}
Entry.public = true;
Image.public = true;
Video.public = true;
module.exports = { Entry: Entry, Image: Image, Video: Video };
