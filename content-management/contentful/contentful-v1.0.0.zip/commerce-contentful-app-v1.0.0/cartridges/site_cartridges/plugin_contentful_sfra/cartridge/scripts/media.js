"use strict";
/** Responsive Contentful URLs without depending on browser/Node URL APIs in Rhino. */
function imageSources(data) {
    var source = String(data.url);
    if (!/^image\/(jpe?g|png|webp|gif|avif|tiff)$/.test(String(data.mime)) || Number(data.fileSize) > 100000000) {
        return { src: source, srcSet: "" };
    }
    try {
        if (!/^(https?:)?\/\/[^/?#\s]+(?:[/?#]|$)/i.test(source)) {
            return { src: source, srcSet: "" };
        }
        var hashAt = source.indexOf("#");
        var hash_1 = hashAt < 0 ? "" : source.slice(hashAt);
        var url = hashAt < 0 ? source : source.slice(0, hashAt);
        var queryAt = url.indexOf("?");
        var base_1 = queryAt < 0 ? url : url.slice(0, queryAt);
        var query_1 = queryAt < 0
            ? []
            : url
                .slice(queryAt + 1)
                .split("&")
                .filter(function (pair) { return decodeURIComponent(pair.split("=")[0].replace(/\+/g, " ")) !== "w"; });
        var largest_1 = Math.min(data.width === undefined ? 4000 : Number(data.width), 4000);
        var widths = [320, 640, 960, 1280, 1920, 2560, largest_1]
            .filter(function (width, index, all) { return width <= largest_1 && all.indexOf(width) === index; })
            .sort(function (a, b) { return a - b; });
        var resize_1 = function (width) { return "".concat(base_1, "?").concat(query_1.concat("w=".concat(width)).join("&")).concat(hash_1); };
        return { src: resize_1(largest_1), srcSet: widths.map(function (width) { return "".concat(resize_1(width), " ").concat(width, "w"); }).join(", ") };
    }
    catch (error) {
        void error;
        return { src: source, srcSet: "" };
    }
}
module.exports = { imageSources: imageSources };
