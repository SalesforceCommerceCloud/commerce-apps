"use strict";
var fragments = require("../../../scripts/fragments");
var content = require("../../../scripts/content");
var mapping = require("../../../scripts/mapping");
var renderer = require("../../../scripts/render");
function load(id, locale) {
    return content.load(id, locale, {
        resource: "entries",
        referenceDepth: true,
        adapt: function (payload, config) { return mapping.adapt(payload, config.mappings); },
    });
}
function renderFragment(input) {
    return renderer.renderData(load(input.id, input.locale), undefined, input.props);
}
function render(context) {
    var selection = context.content.get("contentfulEntry");
    return fragments.renderInclude({
        action: "ContentfulFragment-Entry",
        id: selection ? selection.get("entryId") : "",
        locale: request.locale,
        props: {},
    });
}
module.exports = { render: render, renderFragment: renderFragment, load: load };
