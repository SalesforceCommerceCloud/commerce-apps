# Live Contentful discovery

Start with the Content Delivery API (CDA) for the published model contract used by
the picker/storefront. The Content Management API (CMA) can inspect unpublished
models and full authoring definitions; it needs a management token with access to
the specified space/environment. Neither choice authorizes model or entry writes.

The helper reads `CONTENTFUL_SPACE_ID`, optional `CONTENTFUL_ENVIRONMENT` (default
`master`), and `CONTENTFUL_CDA_TOKEN` or `CONTENTFUL_CMA_TOKEN`. The CMA variable is
for this helper only, not an additional CAP runtime setting. Space/environment
variables here are discovery inputs; runtime non-secret settings come from BM. Do not place credentials
in command arguments. Use the tool's secret environment facility or an existing
local environment excluded from version control; do not print its contents.

From the copied skill directory, with credentials already available in the process
environment (Node 22.13+ on the 22.x line or 24+):

```sh
node scripts/query-models.cjs --output /tmp/contentful-models.json
node scripts/query-models.cjs --api cma --region eu --output /tmp/contentful-authoring-models.json
node scripts/query-models.cjs --host models.example.test --output /tmp/custom-models.json
```

The helper makes only GET requests. It defaults to the US/EU CDA or CMA host selected
by `--api` and `--region`; `--host HOSTNAME` selects a custom endpoint without a
domain allowlist. Supply a hostname without a scheme or path. Output contains model
definitions and retrieval context, never credentials. Failed or incomplete discovery
is reported as an error rather than a partial inventory. Existing output
files are not overwritten. Model descriptions/validations may contain proprietary
information; place inventories in the integrator's chosen output directory.

For richer discovery, use a connector or read-only requests to:

```text
GET /spaces/{space}/environments/{environment}/content_types
GET /spaces/{space}/environments/{environment}/entries?content_type={type}&include={effectiveDepth}&limit={smallSample}
```

Use the second endpoint on CDA/CPA for representative rendering values; CMA entry
fields have locale-keyed shapes. For representative entries/assets, send the active
SFNext locale as the `locale` query parameter, using the same identifier in both
systems. The content-type inventory itself needs no content-locale preference. Read linked resources from `includes`, and do not
assume a single-entry endpoint resolves links. Confirm omitted fields, validations,
locale fallback and available publication state rather than treating sample values
as guarantees. Cross-space links are not supported by this CAP's adapter.

Authoritative references:

- [CDA content model endpoint](https://www.contentful.com/developers/docs/references/content-delivery-api/content-types/get-the-content-model-of-a-space/)
- [CDA authentication and pagination](https://www.contentful.com/developers/docs/references/content-delivery-api/overview/)
- [Content Management API](https://www.contentful.com/developers/docs/references/content-management-api/)
