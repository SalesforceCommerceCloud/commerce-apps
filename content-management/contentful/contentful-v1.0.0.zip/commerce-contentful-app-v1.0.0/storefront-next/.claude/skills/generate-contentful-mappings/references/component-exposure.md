# Expose storefront components for Contentful mappings

Use this workflow when the user requests exposing/registering components for
mapping. Ordinary mapping generation reports these candidates without modifying
component source. A request to expose suitable matches authorizes the necessary
local component, metadata, adapter and generated-file changes; do not require a
second approval for a clear compatible selection. Resolve ambiguous model/component
choices using the user's intended presentation and existing storefront conventions.
Contentful writes and deployment remain separate.

## Establish eligibility and scope

Inspect the actual module and its consumers, types, stories, decorators, registry
generator and imports. Check the candidate can render from serializable mapped
props during SSR and hydration in the existing storefront provider tree. Required
callbacks, arbitrary React children, non-JSON values, independent loaders or
unavailable product/cart context are not solved by adding registration metadata.
Follow imports/re-exports to find the component actually rendered.

Report a compact candidate comparison: content type API ID, component source/export,
compatible props, missing metadata, loader/context/region blockers, proposed change
and proposed renderer ID. Distinguish a truly unregistered module from decorated
source awaiting registry regeneration. IDs must be unique across the current
registry and other decorated source; reuse existing valid metadata instead of
creating duplicate registrations. A proposed ID is not yet an available renderer.

## Choose the smallest compatible implementation

For a direct-prop presentation component, add registration metadata following nearby
registered modules. Preserve its existing exports, props, rendering and callers.
The CAP uses a named metadata class alongside the default React export, for example:

```tsx
import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";

@Component("article", { name: "Article", group: "Contentful" })
@RegionDefinition([])
export class ArticleMetadata {}

// Keep the existing default React component and its props unchanged.
```

Adapt this pattern to the installed generator rather than assuming every decorator
API or export shape is supported. For named-only modules, shared primitives or
modules whose exports include a loader, prefer a separate registered presentation
adapter when appropriate. Give it the expected React export and a unique metadata
ID; delegate to the reusable view with explicitly mapped JSON props. Do not strip
an existing loader, change ordinary routes, or move token fetching into the browser
to make the view eligible. If the view intrinsically requires loader data or
unavailable context, report the blocker instead of inventing placeholder data.

An adapter can reshape already supplied props where necessary for the requested
integration; keep mapping JSON data-only. Do not add transform expressions or
configured import paths to mappings. Describe any introduced conversion and verify
its actual input/output types. Avoid broad refactors unrelated to the selected model.

Editable `@AttributeDefinition` fields are not required for Contentful mappings.
Add them only when direct Page Designer editing is separately requested; the outer
Contentful component already selects the entry. Optional live-preview inspector
hooks are also separate from basic registration. Adding metadata may make a
component available to Page Designer authors; report the new type and intended use.

## Regions

Use `@RegionDefinition([])` for a leaf in the metadata-class convention. For a
container, preserve existing declarations and declare only region IDs that the
React view renders using SFNext `Region`, with the injected `component` prop.
If region rendering must be added, follow nearby working components and verify
that existing children/layout behavior remains intact. Do not overwrite a current
children API simply to satisfy the mapping.

Map regions only from Entry references or Entry-reference arrays, verify inclusion/
exclusion rules and supply mappings for eligible child types. Asset references
belong in compatible JSON props rather than regions. Check fetch reference depth,
cycles and expansion bounds against the installed adapter contract.

## Generate, verify and persist

1. Inspect the storefront's package scripts/config and run its existing registry
   and cartridge metadata generation workflow. Do not hand-edit static registry
   imports/IDs or cartridge JSON as a substitute for generation.
2. Confirm the exact generated `registerImporter` ID, imported module/export and
   loader metadata. Verify both independent server and client loaders are absent;
   a fallback export alone is not a loader. Metadata alone does not prove eligibility.
3. Check the changed view/adapter with the storefront's applicable formatting,
   lint/type checks and focused render tests. Cover any conversion or region behavior
   introduced; for metadata-only changes, generation and build checks are sufficient
   unless repository instructions require additional tests.
4. Continue the main skill's merged-candidate validation and write
   `src/extensions/contentful/config/model-mappings.json`. Run the existing Vite
   mapping plugin/build to verify generated renderer membership. Do not persist
   proposed IDs that generation failed to register.
5. Review the combined source/generated/config diff, preserving unrelated edits.
   Report new component types, adapters, exact saved configuration path, checks run,
   failures and remaining deployed SSR/browser verification. Do not claim that a
   passing parser or local build proves deployment or live Contentful rendering.
