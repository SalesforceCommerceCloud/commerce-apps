"use strict";

const { writeFile } = require("node:fs/promises");

/** Read-only model discovery; injectable I/O keeps tests off live services. */
async function queryModels(
    { spaceId, environment = "master", token, api = "cda", region = "us", host },
    { fetchImpl = fetch, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)) } = {},
) {
    if (!spaceId || !environment || !token) {
        throw new Error("Space, environment and API token are required.");
    }
    if (!["cda", "cma"].includes(api) || !["us", "eu"].includes(region)) {
        throw new Error("Use api cda/cma and region us/eu.");
    }
    host = host?.trim() || `${api === "cma" ? "api" : "cdn"}${region === "eu" ? ".eu" : ""}.contentful.com`;
    const base = `https://${host}/spaces/${encodeURIComponent(spaceId)}/environments/${encodeURIComponent(environment)}/content_types`;
    const models = [];
    const ids = new Set();
    let skip = 0;
    let expectedTotal;
    while (true) {
        const url = `${base}?limit=100&skip=${skip}&order=sys.id`;
        let response;
        for (let attempt = 0; attempt < 3; attempt++) {
            try {
                response = await fetchImpl(url, {
                    headers: { Authorization: `Bearer ${token}` },
                    signal: AbortSignal.timeout(15000),
                    redirect: "error",
                });
            } catch {
                if (attempt === 2) {
                    throw new Error("Contentful request failed; check connectivity and access.");
                }
                await sleep(250 * (attempt + 1));
                continue;
            }
            if (response.ok) {
                break;
            }
            if ((response.status !== 429 && response.status < 500) || attempt === 2) {
                throw new Error(`Contentful returned HTTP ${response.status}; check API/token/space/environment.`);
            }
            const reset = Number(response.headers.get("X-Contentful-RateLimit-Reset"));
            await sleep(
                response.status === 429 && Number.isFinite(reset) && reset > 0
                    ? Math.min(reset * 1000, 5000)
                    : 250 * (attempt + 1),
            );
        }
        let page;
        try {
            page = await response.json();
        } catch {
            throw new Error("Contentful returned invalid JSON.");
        }
        if (
            !Array.isArray(page.items) ||
            !Number.isInteger(page.total) ||
            page.total < 0 ||
            page.total > 10000 ||
            page.skip !== skip
        ) {
            throw new Error(
                "Invalid model pagination or more than 10000 models; narrow discovery using another read-only tool.",
            );
        }
        if (expectedTotal !== undefined && expectedTotal !== page.total) {
            throw new Error("Model collection changed during discovery; rerun.");
        }
        expectedTotal = page.total;
        for (const model of page.items) {
            if (typeof model.sys?.id !== "string" || !Array.isArray(model.fields) || ids.has(model.sys.id)) {
                throw new Error("Invalid or duplicate model in discovery response.");
            }
            ids.add(model.sys.id);
            models.push({
                id: model.sys.id,
                name: model.name,
                description: model.description,
                displayField: model.displayField,
                fields: model.fields,
            });
        }
        skip += page.items.length;
        if (skip > page.total || (skip < page.total && page.items.length === 0)) {
            throw new Error("Incomplete model pagination.");
        }
        if (skip === page.total) {
            break;
        }
    }
    return { spaceId, environment, api, region, host, retrievedAt: new Date().toISOString(), models };
}

async function main(args = process.argv.slice(2)) {
    if (args.includes("--help")) {
        console.log("Usage: node query-models.cjs --output FILE [--api cda|cma] [--region us|eu] [--host HOSTNAME]");
        return;
    }
    const options = { api: "cda", region: "us" };
    for (let i = 0; i < args.length; i += 2) {
        if (
            !["--output", "--api", "--region", "--host"].includes(args[i]) ||
            !args[i + 1] ||
            args[i + 1].startsWith("--")
        ) {
            throw new Error("Use --output FILE [--api cda|cma] [--region us|eu] [--host HOSTNAME].");
        }
        options[args[i].slice(2)] = args[i + 1];
    }
    if (!options.output) {
        throw new Error("An output file is required.");
    }
    const inventory = await queryModels({
        ...options,
        spaceId: process.env.CONTENTFUL_SPACE_ID?.trim(),
        environment: process.env.CONTENTFUL_ENVIRONMENT?.trim() || "master",
        token: (options.api === "cma" ? process.env.CONTENTFUL_CMA_TOKEN : process.env.CONTENTFUL_CDA_TOKEN)?.trim(),
    });
    await writeFile(options.output, `${JSON.stringify(inventory, null, 2)}\n`, { flag: "wx", mode: 0o600 });
    console.log(`Retrieved ${inventory.models.length} models.`);
}

if (require.main === module) {
    main().catch((error) => {
        // Filesystem messages may include paths; never log headers, response bodies or raw network errors.
        console.error(error.code ? `Output failed (${error.code}).` : error.message);
        process.exitCode = 1;
    });
}
module.exports = { queryModels, main };
