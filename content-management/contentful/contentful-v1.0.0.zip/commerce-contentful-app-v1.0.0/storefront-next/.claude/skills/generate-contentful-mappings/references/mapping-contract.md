# Portable Contentful mapping contract

This reference travels with the skill; no CAP checkout is required. It reflects the
package's data-only mapping parser and selected-entry renderer. Inspect the installed
storefront's parser, adapter, loader and runtime dependencies before treating these
rules as the deployed contract. The validator executes that installed parser;
missing integration files or TypeScript dependencies must be resolved before validation.

## Mapping format

The top-level JSON object is keyed by Contentful content type API ID, not name.
Each model permits only:

| Key        | Meaning                                                                                                                   |
| ---------- | ------------------------------------------------------------------------------------------------------------------------- |
| `renderer` | Required full registered ID, `group.componentId`. No module paths or JSX tags. `Content.contentfulContent` is prohibited. |
| `fields`   | Optional object: React prop name → path relative to the entry's `fields`. Default `{}`; no implicit mappings.             |
| `defaults` | Optional object: React prop name → literal JSON value. Default `{}`.                                                      |
| `regions`  | Optional object: declared/rendered component region ID → Entry-reference path. Default omitted.                           |

The authoritative file is `src/extensions/contentful/config/model-mappings.json`.
It is imported only through `lib/model-mappings.server.ts` and deployed with the
storefront. Missing, null, blank or invalid configuration fails validation; there
is no fallback. `{}` disables all models. Preserve models needed by the consumer
when replacing the file. The supplied JSON is a starter, not a renderer allowlist.
The supplied Vite plugin checks structure and generated registry membership at
fresh development startup/build after registry generation. Its result does not
establish loader eligibility, prop compatibility, schema compatibility or deployed
behavior; the skill must still inspect those contracts.

BM has no mapping information: it browses all published types and uses Contentful
display fields for labels. Mapping updates require a storefront rebuild/deployment.

## Paths, props and references

- Model IDs are opaque Contentful keys (including dots), with no local character or size grammar.
  Prop names/path segments use 1–128 alphanumeric, underscore or hyphen characters;
  prototype keys `__proto__`, `constructor`, `prototype` are prohibited. Renderer
  group/name each start with a letter and use alphanumeric/underscore/hyphen characters.
- Paths have at most 16 segments and 2048 characters. Numeric segments address array
  indexes. No wildcards, expressions or transforms.
- Traverse same-space Asset/Entry links using response `includes`/`items`. For example,
  `image.fields.file.url`, `image.fields.description`, `author.fields.name`.
- Mapping a terminal object/array passes its JSON shape unchanged, including embedded
  Link objects. Mapping a reference itself passes its Link; it does not render a child.
- Missing fields, unresolved links and intermediate null preserve defaults. A null
  leaf overrides its default. Objects/arrays require compatible component props.
- Asset URLs can be protocol-relative. Map alternative text explicitly. Rich Text
  requires a renderer accepting its document object; a plain-text card description
  is not a Rich Text renderer. No HTML/Markdown conversion is provided.
- Props beginning with `on` (case-insensitive) and `children`, `ref`, `key`, `data`,
  `component`, `componentData`, `designMetadata`, `regionId`,
  `dangerouslySetInnerHTML` are rejected.
- Renderers must be registered, accept direct mapped props, and have no independent
  server/client loaders. Registration alone cannot establish prop/context compatibility
  or deployment status. Editable Page Designer attributes are not required.

A region must be declared and rendered with SFNext `Region`. Its source is an Entry
reference or ordered Entry-reference array, not an Asset. Each child content type
needs a mapping. Missing/null/empty paths add no children; unavailable/unmapped
children are skipped. Descendants are read-only inside the outer Page Designer
component. Cross-space references are unsupported; cyclic branches are skipped.

## Limits and runtime requirements

| Constraint                                 | Current value                                                                   |
| ------------------------------------------ | ------------------------------------------------------------------------------- |
| Props per `fields` / `defaults` object     | 100 each                                                                        |
| Region paths per model                     | 20                                                                              |
| Literal default nesting                    | Eight levels                                                                    |
| `contentfulReferenceDepth` site preference | Default 3; integer 0–10; controls API `include` separately from rendering depth |
| Recursive region rendering                 | Eight reference edges and 100 entry occurrences; array order preserved          |

The package's region implementation requires SFNext template 2026.7.0 and runtime
SDK 1.1.0 or later (`EmbeddedSubtreeProvider`). Check the installed loader's imports
and consumer dependencies rather than relying on this reference alone. Mappings live only in storefront source with no total model-count or serialized-size
limit. Non-secret connection settings and reference depth are synchronized site preferences. Credentials are not usable from preference sync; MRT
fetching/mapping happens server-side. Entry/asset locales come from SFNext's active
site context via `getContentfulLocale(context)` (resolving Salesforce's `default`
sentinel to the current site's default locale), with `cf_locale` overriding it only for
authorized entry live preview. Both systems use the same locale identifiers; there
is no configurable locale, locale mapping or implicit alternate-language fallback. The skill's Node helpers need Node 22.13+ on
the 22.x line or 24+. Installed `.ts` parser execution also needs the storefront's
TypeScript dependency. Discovery uses only Node built-ins.

## Example to adapt, not assume

These model/field IDs are illustrative, not discoveries from an integrator's space:

```json
{
  "promotion": {
    "renderer": "Content.contentCard",
    "fields": {
      "title": "title",
      "description": "body",
      "imageUrl": "image.fields.file.url",
      "imageAlt": "image.fields.description"
    },
    "defaults": { "showBorder": false }
  },
  "page": {
    "renderer": "Contentful.aboutUsPage",
    "fields": { "title": "title" },
    "regions": { "headline": "sections" }
  }
}
```

Use the page/region example only if its deployed component renders `headline`,
`sections` is an Entry-reference array allowing the mapped child types, and each
selected renderer actually fits the requested layout. API schemas and component
source are authoritative for these choices; parser acceptance alone cannot
confirm them.

## Route consumers

The same mappings also serve consumer route loaders through the server-only
`loadContentfulEntry({ entryId, context })` helper. It accepts a string identifier
and returns serializable renderer data or null. The Page Designer adapter alone
unwraps the saved `{ entryId }` custom attribute. JSX does not load an entry by ID.
Direct image/video embedding uses separate `loadContentfulImage` and
`loadContentfulVideo` helpers from `load-image.server.ts`/`load-video.server.ts`.
They resolve published assets without entry mappings; the video helper also supplies
locale and an optional image poster. These wrapper components have loaders and
remain ineligible as entry mapping targets.

Whole-page mappings still require deployed registered direct-prop renderers with
no loaders; regions must be declared and rendered. The CAP installs no page model
or ordinary shopper route; it supplies a separate authorized `/contentful-preview`
extension route. Do not invent route-only mapping keys, props or relaxed eligibility.

## Optional inspector metadata

Live preview adds source provenance alongside mapped props without changing mapping
syntax. `useContentfulInspector(component)` tags React prop names using the actual
Entry/Asset field source, including configured reference paths and nested regions.
Missing fields resolved by defaults are untagged. Attribute generation delegates to the official Contentful React inspector hook
inside the lazy authorized provider. Disabled inspection emits no attributes.
Custom renderers opt in; registry
registration alone does not establish inspector support. The consumer installs
`@contentful/live-preview` and follows its deployed preview guide; mapping generation
must never emit API tokens or infer authorization from Page Designer preview mode.

The CAP supplies a dedicated authorized preview extension route; ordinary consumer
routes still own page routing. Do not infer preview authorization or inspector
support from mapping validity. See the deployed preview guide for route customization.
