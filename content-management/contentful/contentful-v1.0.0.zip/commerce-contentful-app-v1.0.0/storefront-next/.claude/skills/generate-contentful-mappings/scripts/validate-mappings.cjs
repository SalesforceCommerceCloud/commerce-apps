"use strict";

const { readFileSync, existsSync } = require("node:fs");
const path = require("node:path");
const { createRequire } = require("node:module");
const vm = require("node:vm");

const USAGE = "Usage: node validate-mappings.cjs FILE --storefront-root ROOT [--parser RELATIVE_PATH]";

function loadParser({ storefrontRoot, parserFile }) {
    if (!storefrontRoot) {
        throw new Error("Supply --storefront-root ROOT.");
    }
    const root = path.resolve(storefrontRoot);
    const parserPath = path.resolve(root, parserFile || "src/extensions/contentful/lib/mappings.ts");
    const relative = path.relative(root, parserPath);
    if (relative.startsWith("..") || path.isAbsolute(relative) || !existsSync(parserPath)) {
        throw new Error(
            "Installed parser not found inside the storefront; install the integration or use --parser RELATIVE_PATH.",
        );
    }
    const projectRequire = createRequire(path.join(root, "package.json"));
    let parseMappings;
    if (/\.tsx?$/.test(parserPath)) {
        let ts;
        try {
            ts = projectRequire("typescript");
        } catch {
            throw new Error("Install the storefront TypeScript dependency to execute its parser.");
        }
        const source = ts.transpileModule(readFileSync(parserPath, "utf8"), {
            compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
            reportDiagnostics: true,
        });
        if (source.diagnostics?.some((item) => item.category === ts.DiagnosticCategory.Error)) {
            throw new Error("Installed parser could not be transpiled.");
        }
        const module = { exports: {} };
        // Execute the trusted storefront's data-only parser; not a security sandbox.
        new vm.Script(source.outputText, { filename: parserPath }).runInNewContext({
            module,
            exports: module.exports,
            require: createRequire(parserPath),
            __filename: parserPath,
            __dirname: path.dirname(parserPath),
        });
        parseMappings = module.exports.parseMappings;
    } else {
        parseMappings = projectRequire(parserPath).parseMappings;
    }
    if (typeof parseMappings !== "function") {
        throw new Error("Installed parser does not export parseMappings; inspect its contract.");
    }
    return { parseMappings, parserPath, mode: "installed-storefront" };
}

function validateMappings(mappingFile, options) {
    const { parseMappings, parserPath, mode } = loadParser(options);
    let input;
    try {
        input = JSON.parse(readFileSync(mappingFile, "utf8"));
    } catch {
        throw new Error("Mappings must be a readable JSON file.");
    }
    const parsed = parseMappings(input);
    return { models: Object.keys(parsed).length, serializedCharacters: JSON.stringify(input).length, mode, parserPath };
}

function main(args = process.argv.slice(2)) {
    if (args.includes("--help")) {
        console.log(USAGE);
        return;
    }
    const [file, ...flags] = args;
    const options = {};
    const names = {
        "--storefront-root": "storefrontRoot",
        "--parser": "parserFile",
    };
    for (let i = 0; i < flags.length; i++) {
        if (!Object.hasOwn(names, flags[i]) || !flags[i + 1] || flags[i + 1].startsWith("--")) {
            throw new Error(USAGE);
        }
        options[names[flags[i]]] = flags[++i];
    }
    if (!file) {
        throw new Error(USAGE);
    }
    const summary = validateMappings(file, options);
    console.log(
        `${summary.mode}: parser accepted ${summary.models} mappings (${summary.serializedCharacters} serialized characters).`,
    );
    console.log(`Parser: ${summary.parserPath}`);
    console.log("Registry/prop/region compatibility and deployment still require evaluation.");
}

if (require.main === module) {
    try {
        main();
    } catch (error) {
        console.error(error.message);
        process.exitCode = 1;
    }
}
module.exports = { validateMappings, main };
