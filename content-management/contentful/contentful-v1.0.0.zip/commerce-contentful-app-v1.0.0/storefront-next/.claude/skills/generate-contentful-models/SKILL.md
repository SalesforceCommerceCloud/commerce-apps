---
name: generate-contentful-models
description: Design Contentful content models from SFNext React components when suitable models are missing. Generate reproducible model-creation artifacts and compatible mapping proposals; create and activate models in a specified Contentful environment when requested, then validate and save storefront mappings. Use the companion mapping skill for matching models that already exist.
---

# Generate Contentful models from storefront components

Start with the customer's storefront and selected presentation components. Design
an author-friendly content model that supplies their actual JSON props and regions,
not a mechanical copy of every React prop. Generate a version-controlled model
creation artifact and matching mapping proposal. When model creation is requested
for a specified space/environment, apply the proposed changes within that scope,
verify the resulting schema and complete the storefront mapping workflow.

## Scope and shared contracts

Identify the consumer storefront root and inspect its instructions, working-tree
diff and installed Contentful integration. No CAP checkout is required. This skill
ships alongside [generate-contentful-mappings](../generate-contentful-mappings/SKILL.md);
read its component-discovery and mapping-contract guidance rather than duplicating
its parser or registry validator. Use the installed storefront contracts as the
authority. If the companion is absent, report the incomplete installation and
continue only with a clearly provisional model proposal, not verified mappings.

A request to design/generate models writes local artifacts, not remote schemas.
A request to create/apply models in a specified environment authorizes those model
writes and activation unless the user requests draft types; do not ask again for
a scope already supplied. Resolve missing target information or ambiguous editorial
choices before dependent writes, while completing independent analysis/artifacts.
Do not create spaces/environments, alter existing types/entries, expose component
source or deploy MRT unless requested. Sample entries/assets are optional work,
not implied by creating a model.

## Inspect components and existing models

Use the companion's discovery workflow to inspect registered and unregistered
components, following prop types, defaults, implementations, stories and real call
sites. Distinguish content props from injected metadata, callbacks, styling and
commerce state. Check loaders, provider dependencies, SSR, declared/rendered regions
and the generated registry. Unregistered candidates can inform a model proposal;
use the companion's exposure workflow only when component exposure is requested.
Do not put provisional renderer IDs in live mapping configuration.

When access exists, inventory the target's types through a read-only CMA connector
or the companion's `scripts/query-models.cjs --api cma --output FILE` helper, using
its documented environment-based credentials and `--host` for custom endpoints.
CMA includes authoring definitions; CDA-only discovery cannot establish that a type
ID is unused. Check for reusable models and field IDs before proposing a new type.
Read target locales for localization/default decisions. Without API access, generate
an offline proposal and state that collisions, locales and application are unverified.
Never require credentials just to inspect local components or generate a draft.

## Design the model and mapping together

Read [model design](references/model-design.md) for type decisions, references and
the worked example. For each selected component, explain the proposed content type
ID/name, display field, field IDs/names/types, required/localized flags, validations,
editorial choices and corresponding React prop/region paths. Use component evidence
to recommend choices; ask only about unresolved decisions that materially affect
the requested model. Reuse a suitable existing type instead of creating duplicates.

Exclude runtime-only props and loader data. Model images as Asset references when
appropriate, and nested regions as typed Entry references with compatible child
models. Respect the adapter's supported paths, include depth and region bounds.
Generate child model definitions as needed; report unavailable child renderers.
Do not infer Rich Text support from a component name or a `string` body prop.

Save a creation-only Contentful migration script using the storefront's existing
convention, or `contentful/migrations/001-create-<model-id>.cjs` when none exists.
Keep the artifact and any mapping proposal separate from the live mapping JSON
until models/renderer IDs are verified. The [promotion example](assets/create-promotion.cjs)
and [mapping fragment](assets/promotion-mappings.json) illustrate the contract;
adapt them to discovered models/components rather than executing them unchanged.
Preserve unrelated local artifacts. No tokens or headers belong in artifacts.

## Apply requested model creation

Read [applying and verifying models](references/apply-models.md) before remote
writes. Present the concrete artifact/target as part of the work. With existing
authorization, proceed using an available CMA connector or the customer's installed
Contentful migration tooling; do not introduce a storefront runtime dependency.
Keep explicit stable IDs, check collisions and target identity, and handle partial
creation/activation without overwriting existing definitions or blind replay.
A draft-only request ends with local artifacts and a clear application plan.

## Verify and complete mappings

Read back created content types from CMA and confirm IDs, fields, validations,
display fields and activation state against the proposal. Report any differences
or partial application; do not describe a migration file or CLI exit code alone as
verified model creation. Draft type creation is not activation, and activated types
are not published entries/assets.

Once the model contract and generated renderer IDs are confirmed, use the companion
skill to merge, validate and save
`src/extensions/contentful/config/model-mappings.json`. Preserve unrelated mappings
and edits; run the existing Vite mapping plugin/build and relevant storefront checks.
If the request is model-design-only, return the validated mapping proposal without
changing live configuration. Keep unverified/proposed model mappings out of the
live file unless the user explicitly requests staged configuration; label any such
configuration as awaiting remote verification.

Report component evidence, editorial decisions, reused/created/draft/activated
models, artifact paths, exact saved mapping path (or reason none was written),
checks performed and remaining sample-content/SSR/browser/deployment verification.
Never fabricate a successful remote result or expose credentials in diagnostics.
