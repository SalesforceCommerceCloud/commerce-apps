# Derive an authoring model from a React view

Read the actual view and its usage, not only its TypeScript interface. Props give
shape constraints; editorial meaning determines the authoring experience. A model
can serve multiple compatible views; one type per React component is not required.

| Component evidence                                                          | Contentful model decision                                                                               |
| --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| Short title/label string                                                    | `Symbol` (Short text); use a meaningful title as `displayField`                                         |
| Paragraph string rendered as text                                           | `Text` (Long text); do not supply a Rich Text document                                                  |
| Explicit Rich Text document prop and renderer                               | `RichText`, with supported nodes/links checked against the renderer                                     |
| Boolean/number/integer                                                      | `Boolean`/`Number`/`Integer`; infer integer/ranges only with evidence                                   |
| String literal union                                                        | `Symbol` with an `in` validation matching supported values                                              |
| Image URL and alt props                                                     | Usually an Asset `Link` restricted to image MIME group; map file URL/description separately             |
| Rendered SFNext region                                                      | Entry `Link` or array of Entry links, restricted to compatible content type IDs                         |
| Plain array/object prop                                                     | Compatible array/object shape; using JSON is an explicit editorial choice, not automatic link expansion |
| `component`, `regionId`, callbacks, React nodes, tokens, product/cart state | No inferred CMS field; retain framework injection or report an adapter/context blocker                  |

Required React props need a source/default that guarantees a usable value, but
`prop?: string` alone does not decide whether editors should be required to fill
it. Explain editorial requirements and empty-state behavior. Choose localization
from the customer's languages and actual target locales, not from an assumed
`en-US`. Contentful default values are locale-keyed; React/mapping defaults apply
at render time and need not become CMS defaults. Avoid forcing CSS class names or
implementation details into the author's model.

Use stable API IDs supported by the installed mapping parser, with descriptive
names/help text for authors. Preserve existing IDs when reusing a model. Distinguish
"no matching schema" from "matching unpublished schema" using CMA discovery. A
new type must not replace an existing type merely because it shares a suggested ID.

## References and regions

Use Asset references instead of fabricated asset content types. Map an image via
`image.fields.file.url` and `image.fields.description` only when these values fit
the renderer; Contentful URLs may be protocol-relative. Do not invent URL transforms
or assume descriptions are always populated. Explain alt-text requirements.

For Entry links, `linkContentType` restricts allowed types. In arrays, put link-type
validations on `items.validations`, and any array-size validation on the field.
A declared/rendered region still needs eligible child mappings, fetched includes,
adequate reference depth and compatible region inclusion/exclusion rules. Create
interdependent types before activation when reference validations require them;
verify the chosen tool's plan/order rather than assuming sequential activation works.
Terminal objects/arrays mapped as props retain their JSON/Link shapes; the adapter
does not recursively expand all links. Do not design cross-space references for
this integration's same-space adapter.

## Worked example: promotion to content card

Assume source/registry inspection confirms `Content.contentCard` accepts `title`,
`description`, `imageUrl`, `imageAlt`, `showBackground`, and `showBorder`, has no
loaders and needs no extra provider. The supplied examples define `promotion` with:

| Field   | Authoring definition                                 | Mapping                                                                     |
| ------- | ---------------------------------------------------- | --------------------------------------------------------------------------- |
| `title` | Required Short text; entry display field             | `title: "title"`                                                            |
| `body`  | Optional Long text, plain text                       | `description: "body"`                                                       |
| `image` | Optional single Asset reference restricted to images | `imageUrl: "image.fields.file.url"`, `imageAlt: "image.fields.description"` |

The mapping sets `showBackground` and `showBorder` to `false` as presentation
choices. The example's fields are explicitly nonlocalized; this is an example
decision, not a recommended default for every customer. `title` being required is
an editorial choice. It creates no entries or assets. Its mapping file is a fragment
to merge, not a replacement for the complete storefront configuration. It assumes
this renderer exists; re-inspect the consumer rather than treating the example as
a fixed renderer catalogue.

## Sources

- [Content type schema and validations](https://www.contentful.com/developers/docs/references/content-management-api/content-types/)
- [Migration DSL](https://github.com/contentful/contentful-migration#documentation--references)
- [Contentful data model](https://www.contentful.com/developers/docs/concepts/data-model/)
