# Apply and verify model creation

Local proposal generation needs no management token. Remote creation requires
management access to the explicit space/environment, plus the user's requested
write scope. Neither a Delivery token nor permission to generate a local artifact
authorizes remote writes. If the user already requested creation/activation for
that target, proceed after preparing the concrete artifact; do not add another
approval step. Honor requests to leave content types in draft.

## Choose the existing tool

Prefer the customer's existing Contentful CLI/migration workflow for a reviewable,
version-controlled schema change, or an available authorized CMA connector. The
packaged `.cjs` example exports a migration function; running `node FILE.cjs`
does not execute a remote migration. Copy/adapt it to the consumer's migration
location and inspect its changes before applying it.

With the customer's CLI already installed and authenticated, a typical command is:

```sh
contentful space migration --space-id SPACE_ID --environment-id ENVIRONMENT_ID contentful/migrations/001-create-promotion.cjs
```

Inspect the installed CLI's `--help` and configuration for its supported host,
authentication and execution options. Do not assume a dry-run flag or that merely
invoking an interactive migration command is read-only; it can execute writes.
Where noninteractive execution is needed and the target/artifact is already
authorized, use the tool's supported execution option. Without that authorization,
finish the local artifact and application instructions. Use the configured CMA
host/region or custom endpoint without introducing a hostname allowlist. Do not
silently send custom-host credentials to a default endpoint.

Use credentials through the tool's existing authentication or secret environment
facility, never token arguments or committed configuration. The sibling discovery
helper documents `CONTENTFUL_CMA_TOKEN` for its own use; do not assume the CLI reads
that same variable. No new MRT environment variable or runtime npm package is
needed. Confirm required developer tooling is available; if it is missing, report
the runnable artifact and missing tool rather than claiming application succeeded.

## Stable IDs, collisions and activation

Read each target ID through CMA immediately before creation. Reuse a confirmed
compatible existing type; if its shape differs, report the collision and resolve
an ID/reuse decision instead of updating it implicitly. The example is creation-only
and not a migration-history runner; do not replay it as though it were idempotent.

For direct CMA use, create with a caller-selected ID via
`PUT /spaces/{space}/environments/{environment}/content_types/{id}`. Because this
endpoint can also update types, do not turn an existing-ID response into an update.
If updating an existing type is separately requested, use its current version and
preserve fields outside the requested change.

After creating the required types, activate them through the tool's normal publish
workflow, or `PUT .../content_types/{id}/published` with the current
`X-Contentful-Version`. Check migration-tool activation behavior and verify its
result. A request for draft types cannot be fulfilled using a tool that activates
automatically without adjusting the approach. Activation is distinct from publishing
content entries/assets; do not create/publish sample content unless requested.

On timeouts/unknown write outcomes, refetch stable IDs and compare schemas before
retrying. On permission, validation, collision or version-conflict failures, stop
the affected writes and report created/draft/activated/failed types individually.
Avoid blind full-script retries or deleting created types as automatic rollback.
Read-only inventory retry behavior does not establish safe write retries.

## Readback and storefront handoff

Read the resulting definitions from CMA; compare IDs, fields/types, required and
localized flags, validations and display fields. Verify activation state through
CMA and published-model visibility when Delivery access is available. Existing
entry/asset publication and locale fallback are separate checks.

Use the companion mapping skill for the installed parser, renderer checks, JSON
merge and Vite validation. It owns the complete
`src/extensions/contentful/config/model-mappings.json`; no duplicate parser or
Business Manager mapping configuration is introduced. If creation is pending,
retain a mapping fragment beside the model artifact and identify it as proposed.
Report exact target, artifact, model IDs/states and what was actually verified.

## Sources

- [Scripted migrations](https://www.contentful.com/developers/docs/tutorials/cli/scripting-migrations/)
- [Create a type with a specified ID](https://www.contentful.com/developers/docs/references/content-management-api/content-types/create-a-content-type-with-a-specified-id/)
- [Activate a content type](https://www.contentful.com/developers/docs/references/content-management-api/content-types/activate-a-content-type/)
