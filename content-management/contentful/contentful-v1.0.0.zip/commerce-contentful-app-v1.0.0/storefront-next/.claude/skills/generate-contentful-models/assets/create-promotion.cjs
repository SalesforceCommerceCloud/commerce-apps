"use strict";

// Illustrative creation-only migration. Inspect the consumer and target IDs before use.
module.exports = (migration) => {
    const promotion = migration
        .createContentType("promotion")
        .name("Promotion")
        .description("Promotional content for a compatible content card renderer.")
        .displayField("title");

    promotion.createField("title").name("Title").type("Symbol").required(true).localized(false);
    promotion.createField("body").name("Supporting copy").type("Text").required(false).localized(false);
    promotion
        .createField("image")
        .name("Image")
        .type("Link")
        .linkType("Asset")
        .validations([{ linkMimetypeGroup: ["image"] }])
        .required(false)
        .localized(false);
};
