import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { transformWithEsbuild, type Plugin } from "vite";
import { parseMappings } from "../src/extensions/contentful/lib/mappings";

/** Validate storefront-owned mappings during Vite build and dev startup. */
export function contentfulMappings(): Plugin {
    let root: string;
    return {
        name: "contentful-mappings",
        configResolved(config) {
            root = config.root;
        },
        // SFNext generates its registry asynchronously in buildStart. A sequential
        // post hook waits for generation rather than inspecting a stale prior build.
        buildStart: {
            order: "post",
            sequential: true,
            async handler() {
                const file = resolve(root, "src/extensions/contentful/config/model-mappings.json");
                let raw: unknown;
                try {
                    raw = JSON.parse(readFileSync(file, "utf8"));
                } catch {
                    throw new Error(`Contentful mappings (${file}): file must exist and contain valid JSON.`);
                }
                let mappings: ReturnType<typeof parseMappings>;
                try {
                    mappings = parseMappings(raw);
                } catch (error) {
                    const message = error instanceof Error ? error.message : "Invalid mapping configuration";
                    throw new Error(`Contentful mappings (${file}): ${message}`, { cause: error });
                }
                if (Object.keys(mappings).length === 0) {
                    return;
                }
                const registryFile = resolve(root, "src/lib/page-designer/static-registry.ts");
                let source: string;
                try {
                    source = readFileSync(registryFile, "utf8");
                } catch {
                    throw new Error(
                        `Contentful mappings: missing generated registry ${registryFile}. Enable SFNext static registry generation.`,
                    );
                }
                // Inspect registrations without importing/executing React components,
                // server modules or the registry's application-specific aliases.
                const { code } = await transformWithEsbuild(source, registryFile, { loader: "ts" });
                const program = this.parse(code);
                const initializer = program.body
                    .map((node) => (node.type === "ExportNamedDeclaration" ? node.declaration : node))
                    .find((node) => node?.type === "FunctionDeclaration" && node.id?.name === "initializeRegistry");
                if (!initializer || initializer.type !== "FunctionDeclaration") {
                    throw new Error(
                        `Contentful mappings: unsupported generated registry ${registryFile}; initializeRegistry is missing.`,
                    );
                }
                const parameter = initializer.params[0];
                const target = parameter?.type === "AssignmentPattern" ? parameter.left : parameter;
                const registered = new Set<string>();
                for (const statement of initializer.body.body) {
                    if (statement.type !== "ExpressionStatement" || statement.expression.type !== "CallExpression") {
                        continue;
                    }
                    const { callee, arguments: args } = statement.expression;
                    if (
                        callee.type === "MemberExpression" &&
                        !callee.computed &&
                        callee.object.type === "Identifier" &&
                        target?.type === "Identifier" &&
                        callee.object.name === target.name &&
                        callee.property.type === "Identifier" &&
                        callee.property.name === "registerImporter" &&
                        args[0]?.type === "Literal" &&
                        typeof args[0].value === "string"
                    ) {
                        registered.add(args[0].value);
                    }
                }
                for (const [model, mapping] of Object.entries(mappings)) {
                    if (!registered.has(mapping.renderer)) {
                        throw new Error(
                            `Contentful mappings (${file}): model "${model}" references renderer "${mapping.renderer}", which is not registered in ${registryFile}. Check its @Component metadata and static registry generation.`,
                        );
                    }
                }
            },
        },
    };
}
