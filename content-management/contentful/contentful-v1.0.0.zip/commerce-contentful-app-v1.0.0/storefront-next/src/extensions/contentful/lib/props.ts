/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { CdaEntry, CdaAsset } from "./types";
import type { ContentfulMappings, JsonValue } from "./mappings";
import type { ContentfulDiagnostic } from "./diagnostics";
import type { ContentfulSource, ContentfulFieldSource } from "./content-preview-types";
export interface ContentfulRenderData {
    /** Preview-only provenance, separate from renderer props and PD occurrence identity. */
    source?: ContentfulSource;
    renderer: string;
    props: Record<string, JsonValue>;
    regions?: { id: string; components: ContentfulRenderData[] }[];
}
/** Walk only the requested path, resolving same-space links from the fetched response. */
function readFieldPath(
    entry: CdaEntry,
    path: string,
    assets: Map<string, CdaAsset>,
    entries: Map<string, CdaEntry>,
    source?: ContentfulFieldSource,
): unknown {
    let value: unknown = entry.fields;
    const segments = path.split(".");
    for (const [index, segment] of segments.entries()) {
        if (value === null || typeof value !== "object") {
            return undefined;
        }
        const sys = (value as { sys?: { type?: string; linkType?: string; id?: string } }).sys;
        if (sys?.type === "Link") {
            value = undefined;
            if (sys.id) {
                if (sys.linkType === "Asset") {
                    value = assets.get(sys.id);
                } else if (sys.linkType === "Entry") {
                    value = entries.get(sys.id);
                }
            }
            if (!value) {
                return undefined;
            }
            if (source && segment === "fields" && segments[index + 1]) {
                delete source.entryId;
                delete source.assetId;
                if (sys.linkType === "Asset") {
                    source.assetId = sys.id;
                } else {
                    source.entryId = sys.id;
                }
                source.fieldId = segments[index + 1];
            }
        }
        if (!Object.prototype.hasOwnProperty.call(value, segment)) {
            return undefined;
        }
        value = (value as Record<string, unknown>)[segment];
    }
    return value;
}

/** Validate JSON data without resolving links or changing the selected value. */
function isJsonValue(value: unknown, ancestors = new WeakSet<object>()): value is JsonValue {
    if (value === null || typeof value === "string" || typeof value === "boolean") {
        return true;
    }
    if (typeof value === "number") {
        return Number.isFinite(value);
    }
    if (typeof value !== "object" || ancestors.has(value)) {
        return false;
    }
    if (!Array.isArray(value) && Object.prototype.toString.call(value) !== "[object Object]") {
        return false;
    }
    ancestors.add(value);
    const valid = Object.values(value).every((item) => isJsonValue(item, ancestors));
    ancestors.delete(value);
    return valid;
}

/** Resolve field paths on the server and pass the selected values through unchanged. */
function adaptEntry(
    entry: CdaEntry,
    assets: Map<string, CdaAsset>,
    mappings: ContentfulMappings,
    entries: Map<string, CdaEntry>,
    diagnostic: ContentfulDiagnostic | undefined,
    ancestors: Set<string>,
    depth: number,
    budget: { remaining: number },
    inspector: boolean,
): ContentfulRenderData | null {
    if (ancestors.has(entry.sys.id) || depth > 8 || budget.remaining <= 0) {
        let reason = depth > 8 ? "depth_limit" : "node_limit";
        if (ancestors.has(entry.sys.id)) {
            reason = "cycle";
        }
        diagnostic?.(
            "contentful.region.branch_skipped",
            {
                entryId: entry.sys.id,
                reason,
            },
            "warn",
        );
        return null;
    }
    budget.remaining--;
    const model = entry.sys.contentType?.sys.id;
    const mapping = model && Object.prototype.hasOwnProperty.call(mappings, model) ? mappings[model] : undefined;
    if (!mapping) {
        diagnostic?.("contentful.mapping.model_missing", { entryId: entry.sys.id, contentType: model }, "warn");
        return null;
    }
    const props = JSON.parse(JSON.stringify(mapping.defaults)) as Record<string, JsonValue>;
    const source: ContentfulSource = { entryId: entry.sys.id, fields: {} };
    for (const [target, path] of Object.entries(mapping.fields)) {
        const fieldSource: ContentfulFieldSource = { entryId: entry.sys.id, fieldId: path.split(".")[0] };
        const value = readFieldPath(entry, path, assets, entries, inspector ? fieldSource : undefined);
        if (value === undefined) {
            diagnostic?.(
                "contentful.mapping.field_missing",
                {
                    entryId: entry.sys.id,
                    contentType: model,
                    prop: target,
                    fieldPath: path,
                    hasDefault: Object.prototype.hasOwnProperty.call(props, target),
                },
                "debug",
            );
            continue;
        }
        if (!isJsonValue(value)) {
            diagnostic?.(
                "contentful.mapping.value_invalid",
                { entryId: entry.sys.id, contentType: model, prop: target, fieldPath: path },
                "error",
            );
            throw new Error(`Mapped prop ${target} requires a JSON value`);
        }
        props[target] = value;
        if (inspector) {
            source.fields[target] = fieldSource;
        }
    }
    const result: ContentfulRenderData = { renderer: mapping.renderer, props };
    if (inspector) {
        result.source = source;
    }
    if (mapping.regions) {
        const branch = new Set(ancestors).add(entry.sys.id);
        result.regions = Object.entries(mapping.regions).map(([id, path]) => {
            const value = readFieldPath(entry, path, assets, entries);
            let links: unknown[] = [];
            if (value != null) {
                links = Array.isArray(value) ? value : [value];
            }
            const components: ContentfulRenderData[] = [];
            for (const link of links) {
                const sys = (link as { sys?: { type?: string; linkType?: string; id?: string } } | null)?.sys;
                if (sys?.type !== "Link" || sys.linkType !== "Entry" || !sys.id) {
                    diagnostic?.(
                        "contentful.region.reference_invalid",
                        { entryId: entry.sys.id, regionId: id, fieldPath: path },
                        "warn",
                    );
                    continue;
                }
                const child = entries.get(sys.id);
                if (!child) {
                    diagnostic?.(
                        "contentful.region.reference_missing",
                        { entryId: entry.sys.id, referencedEntryId: sys.id, regionId: id },
                        "warn",
                    );
                    continue;
                }
                const mapped = adaptEntry(
                    child,
                    assets,
                    mappings,
                    entries,
                    diagnostic,
                    branch,
                    depth + 1,
                    budget,
                    inspector,
                );
                if (mapped) {
                    components.push(mapped);
                }
            }
            return { id, components };
        });
    }
    return result;
}

/** Build only configured regions from the fetched response; ordinary JSON props stay unchanged. */
export function adaptContentfulProps(
    entry: CdaEntry,
    assets: Map<string, CdaAsset>,
    mappings: ContentfulMappings,
    entries: Map<string, CdaEntry> = new Map(),
    diagnostic?: ContentfulDiagnostic,
    inspector = false,
): ContentfulRenderData | null {
    return adaptEntry(entry, assets, mappings, entries, diagnostic, new Set(), 0, { remaining: 100 }, inspector);
}
