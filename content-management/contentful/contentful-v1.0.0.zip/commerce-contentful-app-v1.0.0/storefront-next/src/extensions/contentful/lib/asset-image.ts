/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

/** Public, serializable image props; no connection settings or raw asset data. */
export interface ContentfulImageData {
    assetId: string;
    url: string;
    alt: string;
    contentType: string;
    width?: number;
    height?: number;
    fileSize?: number;
}

/**
 * Build a fallback src and responsive srcSet using Contentful width transformations,
 * capped at the source width and 4000 pixels (4000 when source width is unknown).
 * Preserve existing query parameters/fragments and the supplied scheme or protocol-relative
 * form. Unsupported formats, oversized files and unparseable URLs use the original src
 * without a srcSet. Browser URL resolution and CSP still control image loading.
 */
export function contentfulImageSources(image: ContentfulImageData): { src: string; srcSet?: string } {
    // Contentful supplies the URL; the browser resolves it and enforces the storefront CSP.
    const source = image.url;
    // This list controls resize transformation eligibility, not which images can display.
    // Formats outside the list (including SVG) and files over the transformation size
    // limit use their original URL; the browser still handles displaying those images.
    if (
        !/^image\/(jpe?g|png|webp|gif|avif|tiff)$/.test(image.contentType) ||
        (image.fileSize !== undefined && image.fileSize > 100_000_000)
    ) {
        return { src: source };
    }
    const protocolRelative = source.startsWith("//");
    let url: URL;
    try {
        // A temporary scheme lets URL parse protocol-relative Contentful image URLs.
        url = new URL(protocolRelative ? `https:${source}` : source);
    } catch {
        // Leave invalid URLs to the browser rather than interrupting rendering.
        return { src: source };
    }
    const schemeLength = protocolRelative ? url.protocol.length : 0;
    const largest = Math.min(image.width ?? 4000, 4000);
    const widths = [...new Set([320, 640, 960, 1280, 1920, 2560, largest].filter((width) => width <= largest))].sort(
        (a, b) => a - b,
    );
    /** Serialize one width variant by reusing the parsed URL and replacing only its w parameter. */
    const resize = (width: number) => {
        url.searchParams.set("w", String(width));
        // Remove only the temporary scheme; preserve any scheme supplied by Contentful.
        return url.toString().slice(schemeLength);
    };
    return { src: resize(largest), srcSet: widths.map((width) => `${resize(width)} ${width}w`).join(", ") };
}
