import rawMappings from "../config/model-mappings.json";
import { parseMappings } from "./mappings";

/** Storefront-owned configuration: import only from server loaders, never return in loader data. */
export const contentfulModelMappings = parseMappings(rawMappings);
