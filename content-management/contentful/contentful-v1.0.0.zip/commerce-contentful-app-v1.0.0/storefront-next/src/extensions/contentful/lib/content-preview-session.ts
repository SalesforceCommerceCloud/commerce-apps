/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ContentfulLivePreview } from "@contentful/live-preview";

/** The SDK React provider owns initialization. This is only the save-to-server-refresh adapter. */
export function subscribeContentPreviewSaves(
    sdk: Pick<typeof ContentfulLivePreview, "subscribe">,
    onSave: () => void,
    onError: () => void,
): () => void {
    let active = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let unsubscribe: (() => void) | undefined;
    try {
        unsubscribe = sdk.subscribe("save", {
            callback: () => {
                if (!active) {
                    return;
                }
                clearTimeout(timer);
                timer = setTimeout(() => {
                    if (active) {
                        onSave();
                    }
                }, 300);
            },
        });
    } catch {
        onError();
    }
    return () => {
        active = false;
        clearTimeout(timer);
        unsubscribe?.();
    };
}
