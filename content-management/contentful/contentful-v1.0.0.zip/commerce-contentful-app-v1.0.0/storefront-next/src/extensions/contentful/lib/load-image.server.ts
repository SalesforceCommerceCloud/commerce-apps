/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Load complete published-image component data using current-site settings and private MRT credentials.
 * Accept a string asset ID from a server route or Page Designer adapter; return image data or null.
 * This is the image-specific name for the existing loadContentfulAsset API, which remains supported.
 */
export { loadContentfulAsset as loadContentfulImage } from "./asset.server";
