/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import type { ContentfulConfig } from "./types";

/** Normalize synchronized non-secret preferences without ever reading BM password fields. */
function text(value: unknown, fallback = ""): string {
    return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

/** Resolve connection settings on the server from the current site's BM preferences. */
export function getContentfulConfig(
    preferences: Record<string, unknown>,
    preview: { enabled: boolean; locale: string | undefined },
): ContentfulConfig {
    const deliveryHost = text(preferences.contentfulHost, "cdn.contentful.com");
    const previewHost = text(
        preferences.contentfulPreviewHost,
        deliveryHost === "cdn.eu.contentful.com" ? "preview.eu.contentful.com" : "preview.contentful.com",
    );
    const locale = preview.locale;
    if (!locale || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(locale)) {
        throw new Error("Missing or invalid storefront locale");
    }
    return {
        spaceId: text(preferences.contentfulSpaceId),
        environment: text(preferences.contentfulEnvironment, "master"),
        host: preview.enabled ? previewHost : deliveryHost,
        // MRT drafts require request authorization.
        previewMode: preview.enabled,
        locale,
        fetchRetries: preferences.contentfulFetchRetries,
        fetchTimeoutMs: preferences.contentfulFetchTimeoutMs,
    };
}

/** Only secrets come from MRT environment variables; masked BM values are never usable credentials. */
export function getContentfulToken(previewMode: boolean): string | undefined {
    const token = previewMode ? process.env.CONTENTFUL_PREVIEW_TOKEN : process.env.CONTENTFUL_CDA_TOKEN;
    return token?.trim() || undefined;
}

/** Standalone images always use the published Delivery API. */
export function getContentfulDeliveryConfig(
    preferences: Record<string, unknown>,
    locale: string | undefined,
): ContentfulConfig {
    return getContentfulConfig(preferences, { enabled: false, locale });
}
