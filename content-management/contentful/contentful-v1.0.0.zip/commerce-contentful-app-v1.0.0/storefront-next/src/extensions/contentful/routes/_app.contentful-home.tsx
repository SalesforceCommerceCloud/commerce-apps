/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import { useLoaderData, type LoaderFunctionArgs } from "react-router";
import ContentfulContent from "@/components/contentful-content";
import { SeoMeta } from "@/components/seo-meta";
import { Link } from "@/components/link";
import { loadContentfulEntry } from "@/extensions/contentful/lib/load-entry.server";
import { CONTENTFUL_HOME_ENTRY_ID, CONTENTFUL_HOME_OWNER_ID } from "@/extensions/contentful/lib/home-demo";
import { loadContentfulHomeCommerce } from "@/extensions/contentful/lib/home-commerce.server";
import { ContentfulHomeCommerceContext } from "@/extensions/contentful/lib/home-commerce";
import { buildCanonicalUrl } from "@/utils/canonical-url";

// The installed React Router applies this export to document and single-fetch responses.
// Preview access belongs to the authorized preview route; this shopper demo remains published-only.
export const headers = () => ({ "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow" });

/**
 * _app supplies the storefront shell. Await only the editorial root, then return the
 * per-occurrence Commerce promises for section-level streaming. Deliberately omit request
 * from loadContentfulEntry: query flags must not enable drafts on this demonstration URL.
 * A null root includes configuration/mapping/upstream failures, so respond 503 rather than
 * claiming that Contentful returned 404. Commerce failures instead remain section-local.
 */
export async function loader({ request, context }: LoaderFunctionArgs) {
    const content = await loadContentfulEntry({ entryId: CONTENTFUL_HOME_ENTRY_ID, context });
    if (!content) {
        throw new Response("Contentful homepage unavailable", { status: 503, headers: headers() });
    }
    const url = new URL(request.url);
    const image = content.props.socialImageUrl;
    return {
        content,
        commerce: loadContentfulHomeCommerce(content, context),
        pageUrl: buildCanonicalUrl(url.origin, url.pathname, url.search),
        ogImageUrl: typeof image === "string" && image ? new URL(image, url.origin).href : undefined,
    };
}

export default function ContentfulHomeRoute() {
    const { content, commerce, pageUrl, ogImageUrl } = useLoaderData<typeof loader>();
    return (
        <>
            <SeoMeta
                rawTitle
                title={typeof content.props.title === "string" ? content.props.title : undefined}
                description={
                    typeof content.props.metaDescription === "string" ? content.props.metaDescription : undefined
                }
                noIndex
                openGraph={{ type: "website", url: pageUrl, image: ogImageUrl }}
            />
            <ContentfulHomeCommerceContext.Provider value={commerce}>
                <ContentfulContent data={content} component={{ id: CONTENTFUL_HOME_OWNER_ID }} />
            </ContentfulHomeCommerceContext.Provider>
        </>
    );
}

export function ErrorBoundary() {
    return (
        <section className="max-w-screen-2xl mx-auto px-4 py-12">
            <h1 className="text-2xl font-semibold">Contentful homepage is unavailable</h1>
            <p className="py-4">This demonstration page is temporarily unavailable. Please try again later.</p>
            <Link to="/">Return to the store</Link>
        </section>
    );
}
