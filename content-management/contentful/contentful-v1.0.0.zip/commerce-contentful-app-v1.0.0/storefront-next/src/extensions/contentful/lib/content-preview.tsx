/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { createContext, useContext } from "react";
import type { ContentPreviewState, ContentfulSource, ContentfulFieldSource } from "./content-preview-types";

interface ContentPreviewContextValue extends ContentPreviewState {
    /** Supplied by the lazy SDK React bridge, keeping SDK imports out of shopper renderers. */
    tagField?: (field: ContentfulFieldSource & { locale: string }) => Record<string, string> | null;
}
export const ContentPreviewContext = createContext<ContentPreviewContextValue>({ enabled: false, locale: "" });
export const ContentfulSourceContext = createContext<ContentfulSource | undefined>(undefined);
export const useContentPreview = (): ContentPreviewState => useContext(ContentPreviewContext);

/** Resolve mapped prop provenance, then let Contentful's React hook generate inspector attributes. */
export function useContentfulInspector(component?: { id?: string; contentfulSource?: ContentfulSource }) {
    const preview = useContext(ContentPreviewContext);
    const inherited = useContext(ContentfulSourceContext);
    const source = component?.contentfulSource ?? inherited;
    return (prop: string): Record<string, string> => {
        const field = source?.fields[prop];
        if (!preview.enabled || !field) {
            return {};
        }
        return preview.tagField?.({ ...field, locale: preview.locale }) ?? {};
    };
}
