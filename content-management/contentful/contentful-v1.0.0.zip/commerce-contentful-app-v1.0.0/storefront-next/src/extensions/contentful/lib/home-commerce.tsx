/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { createContext, useContext } from "react";
import type { ShopperProducts, ShopperSearch } from "@/scapi";
import type { ComponentType } from "@/components/region";

export type ContentfulHomeCommerceResult =
    | { kind: "products"; data: ShopperSearch.schemas["ProductSearchResult"] }
    | { kind: "categories"; data: ShopperProducts.schemas["Category"][] }
    | { kind: "unavailable" };
/**
 * React Router serializes these route-loader promises for Suspense/Await consumers.
 * This module is browser-safe context/types only; server querying stays in its .server
 * companion. Empty context intentionally makes commerce adapters show their local
 * unavailable view in the generic preview route, which supplies no catalog data.
 */
export type ContentfulHomeCommerce = Record<string, Promise<ContentfulHomeCommerceResult>>;
export const ContentfulHomeCommerceContext = createContext<ContentfulHomeCommerce>({});
/** Resolve the rendered occurrence, not its shared Contentful entry ID. */
export function useContentfulHomeCommerce(component?: ComponentType) {
    const results = useContext(ContentfulHomeCommerceContext);
    return component?.id ? results[component.id] : undefined;
}
