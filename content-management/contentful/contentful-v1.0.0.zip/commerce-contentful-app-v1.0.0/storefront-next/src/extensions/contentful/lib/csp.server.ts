/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import type { CspContributor } from "@salesforce/storefront-next-runtime/security";

/** Add Contentful image and video delivery to the storefront's existing CSP at server startup. */
export function createContentfulCspContributor(): CspContributor {
    return {
        id: "contentful-images",
        isActive: () => true,
        contribute: () => ({
            "img-src": ["https://images.ctfassets.net"],
            "media-src": [
                "https://videos.ctfassets.net",
                "https://assets.ctfassets.net",
                "https://downloads.ctfassets.net",
                "https://videos.eu.ctfassets.net",
                "https://assets.eu.ctfassets.net",
                "https://downloads.eu.ctfassets.net",
            ],
        }),
    };
}
