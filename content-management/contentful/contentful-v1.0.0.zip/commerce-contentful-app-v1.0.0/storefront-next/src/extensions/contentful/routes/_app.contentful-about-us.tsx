/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import { useLoaderData, type LoaderFunctionArgs } from "react-router";
import ContentfulContent from "@/components/contentful-content";
import { SeoMeta } from "@/components/seo-meta";
import { Link } from "@/components/link";
import { loadContentfulEntry } from "@/extensions/contentful/lib/load-entry.server";
import { CONTENTFUL_ABOUT_US_ENTRY_ID } from "@/extensions/contentful/lib/about-us-demo";
import { buildCanonicalUrl } from "@/utils/canonical-url";

// A deliberately uncached demonstration; no duplicate page should enter search indexes.
export const headers = () => ({ "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow" });

/**
 * _app supplies the existing header/navigation/footer; the mapped root embeds Contact.
 * Omit request from the shared entry helper so preview query flags cannot enable drafts.
 * This standalone example has no copied-content fallback: a failed load must remain visible.
 */
export async function loader({ request, context }: LoaderFunctionArgs) {
    const content = await loadContentfulEntry({ entryId: CONTENTFUL_ABOUT_US_ENTRY_ID, context });
    // null includes configuration/mapping/upstream failures, not just an absent entry.
    if (!content) {
        throw new Response("Contentful About Us unavailable", { status: 503, headers: headers() });
    }
    const url = new URL(request.url);
    const pageUrl = buildCanonicalUrl(url.origin, url.pathname, url.search);
    const image = content.props.socialImageUrl;
    return {
        content,
        pageUrl,
        ogImageUrl: typeof image === "string" && image ? new URL(image, url.origin).href : undefined,
    };
}

export default function ContentfulAboutUsRoute() {
    const { content, pageUrl, ogImageUrl } = useLoaderData<typeof loader>();
    return (
        <>
            <SeoMeta
                title={typeof content.props.title === "string" ? content.props.title : undefined}
                description={
                    typeof content.props.metaDescription === "string" ? content.props.metaDescription : undefined
                }
                noIndex
                openGraph={{ type: "article", url: pageUrl, image: ogImageUrl }}
            />
            <ContentfulContent data={content} component={{ id: "contentful-about-us-page" }} />
        </>
    );
}

export function ErrorBoundary() {
    return (
        <section className="max-w-screen-2xl mx-auto px-4 py-12">
            <h1 className="text-2xl font-semibold">Contentful About Us is unavailable</h1>
            <p className="py-4">This demonstration page is temporarily unavailable. Please try again later.</p>
            <Link to="/">Return to the store</Link>
        </section>
    );
}
