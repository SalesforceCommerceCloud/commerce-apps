/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { registry as regionRegistry } from "@/lib/page-designer/registry";
import { contentfulRendererRegistry } from "@/extensions/contentful/lib/renderer-registry";
import type { LoaderFunctionArgs } from "react-router";
import { getSitePreferencesLazy } from "@salesforce/storefront-next-runtime/data-store";
import { contentfulModelMappings } from "@/extensions/contentful/lib/model-mappings.server";
import { getContentfulLocale } from "./locale.server";
import { getLogger } from "@/lib/logger.server";
import { getContentfulConfig, getContentfulToken } from "@/extensions/contentful/lib/get-config.server";
import { fetchContentfulEntry } from "@/extensions/contentful/lib/entry.server";

import { diagnosticErrorType, type ContentfulDiagnostic } from "@/extensions/contentful/lib/diagnostics";

import { authorizeContentPreview, getContentPreview } from "./content-preview.server";

import type { ContentfulRenderData } from "./props";
import { isContentfulResourceId } from "./resource-id";

/**
 * Resolve an entry for a route or Page Designer component on the server.
 * Fetches Contentful using storefront-owned mappings, BM settings and private MRT credentials.
 * Returns serializable renderer data, or null on absence/invalidity/failure.
 * Call from a server loader, never from a React render function or client loader.
 */
export async function loadContentfulEntry({
    entryId,
    context,
    request,
}: {
    entryId: string;
    request?: Request;
    context: LoaderFunctionArgs["context"];
}): Promise<ContentfulRenderData | null> {
    const logger = getLogger(context);
    const diagnostic: ContentfulDiagnostic = (event, metadata, level = "error") => logger[level](event, metadata);
    // Validate before reading credentials/preferences; never log invalid identifiers.
    if (!isContentfulResourceId(entryId)) {
        diagnostic("contentful.selection.invalid", {}, "warn");
        return null;
    }
    // Reject unauthorized preview before preference reads or error-to-null handling.
    authorizeContentPreview(request);
    let stage = "preferences";
    let renderer: string | undefined;
    try {
        const preferences = (await getSitePreferencesLazy(context)) ?? {};
        stage = "configuration";
        const preview = getContentPreview(request, getContentfulLocale(context));
        const config = getContentfulConfig(preferences, preview);
        diagnostic("contentful.mappings.loaded", { modelCount: Object.keys(contentfulModelMappings).length }, "debug");
        stage = "entry";
        const data = await fetchContentfulEntry(
            config,
            getContentfulToken(config.previewMode),
            entryId,
            diagnostic,
            contentfulModelMappings,
            preferences?.contentfulReferenceDepth,
        );
        if (!data) {
            return null;
        }
        // Region renders descendants through the storefront registry, while the root
        // retains our undecorated adapter. Validate every target before returning a tree.
        const descendants = new Set<string>();
        const visit = (node: typeof data) => {
            for (const region of node.regions ?? []) {
                for (const child of region.components) {
                    descendants.add(child.renderer);
                    visit(child);
                }
            }
        };
        visit(data);
        const targets = [
            { id: data.renderer, registry: contentfulRendererRegistry },
            ...[...descendants].map((id) => ({ id, registry: regionRegistry })),
        ];
        for (const target of targets) {
            renderer = target.id;
            if (!target.registry.has(renderer) || renderer === "Content.contentfulContent") {
                diagnostic("contentful.renderer.unregistered", { entryId, renderer });
                return null;
            }
            // Native Region consumes pre-collected loader data; it does not execute loaders.
            // These Contentful descendants are synthesized after that collection step.
            if (target.registry.hasLoaders(renderer)) {
                diagnostic("contentful.renderer.loaders_unsupported", { entryId, renderer });
                return null;
            }
        }
        stage = "renderer_import";
        await Promise.all(targets.map((target) => target.registry.loadAndRegister(target.id)));
        diagnostic("contentful.renderer.ready", { entryId, renderer: data.renderer }, "debug");
        return data;
    } catch (error) {
        diagnostic("contentful.loader.failed", {
            stage,
            entryId,
            renderer,
            errorType: diagnosticErrorType(error),
        });
        return null;
    }
}
