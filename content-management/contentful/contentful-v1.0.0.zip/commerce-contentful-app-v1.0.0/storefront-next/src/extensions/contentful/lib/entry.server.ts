/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { CdaResponse } from "./types";
import { adaptContentfulProps, type ContentfulRenderData } from "./props";
import type { ContentfulConfig } from "./types";
import type { ContentfulMappings } from "./mappings";

import type { ContentfulDiagnostic } from "./diagnostics";
import { requestContentful } from "./request.server";
import { isContentfulResourceId } from "./resource-id";

export type ContentfulSelection = string;

/**
 * Validate a string entry ID before it becomes an upstream API request.
 * Page Designer's custom-attribute object is unwrapped by contentful-content/loaders.server.ts.
 * Do not add custom-editor storage shapes to this shared fetching API.
 */
export function readSelection(value: unknown): ContentfulSelection | null {
    return isContentfulResourceId(value) ? value : null;
}

/** Fetch and map one selected entry on every call; credentials and raw responses stay on MRT. */
export async function fetchContentfulEntry(
    config: ContentfulConfig,
    token: string | undefined,
    selection: unknown,
    diagnostic: ContentfulDiagnostic | undefined,
    mappings: ContentfulMappings,
    referenceDepth: unknown = 3,
): Promise<ContentfulRenderData | null> {
    const selected = readSelection(selection);
    if (!selected || !config.spaceId || !token) {
        diagnostic?.(
            !selected ? "contentful.selection.invalid" : "contentful.configuration.missing",
            { hasSpaceId: Boolean(config.spaceId), hasToken: Boolean(token) },
            !selected ? "warn" : "error",
        );
        return null;
    }
    // BM's integer preference is synchronized to MRT; missing values default to 3.
    // Validate here as well so direct callers cannot issue an unsupported include request.
    const validDepth =
        typeof referenceDepth === "number" &&
        Number.isInteger(referenceDepth) &&
        referenceDepth >= 0 &&
        referenceDepth <= 10;
    const includeDepth = validDepth ? referenceDepth : 3;
    if (!validDepth) {
        diagnostic?.("contentful.configuration.reference_depth_invalid", { fallbackDepth: 3 }, "warn");
    }
    const metadata = {
        entryId: selected,
        spaceId: config.spaceId,
        environment: config.environment,
        previewMode: config.previewMode,
        referenceDepth: includeDepth,
        locale: config.locale,
    };
    const url = new URL(
        `https://${config.host}/spaces/${encodeURIComponent(config.spaceId)}/environments/${encodeURIComponent(config.environment)}/entries`,
    );
    url.searchParams.set("sys.id", selected);
    // Only the collection endpoint supports includes, even when fetching one selected entry.
    url.searchParams.set("include", String(includeDepth));
    url.searchParams.set("limit", "1");
    if (config.locale) {
        url.searchParams.set("locale", config.locale);
    }
    const result = await requestContentful({
        url,
        token,
        fetchRetries: config.fetchRetries,
        fetchTimeoutMs: config.fetchTimeoutMs,
        resource: "entry",
        metadata,
        diagnostic,
        adapt: (response) => {
            const payload = response as CdaResponse;
            const entry = payload.items?.[0];
            if (!entry || entry.sys.id !== selected) {
                diagnostic?.(
                    "contentful.entry.unavailable",
                    { ...metadata, reason: !entry ? "not_found" : "id_mismatch" },
                    "warn",
                );
                return null;
            }
            const assets = new Map((payload.includes?.Asset ?? []).map((asset) => [asset.sys.id, asset]));
            const entries = new Map(
                [...(payload.includes?.Entry ?? []), ...(payload.items ?? [])].map(
                    (item) => [item.sys.id, item] as const,
                ),
            );
            const block = adaptContentfulProps(entry, assets, mappings, entries, diagnostic, config.previewMode);
            if (!block) {
                diagnostic?.("contentful.entry.unavailable", { ...metadata, reason: "model_unmapped" }, "warn");
            }
            return block;
        },
    });
    if (!result) {
        return null;
    }
    diagnostic?.(
        "contentful.entry.loaded",
        { ...metadata, renderer: result.data.renderer, attempt: result.attempt, durationMs: result.durationMs },
        "info",
    );
    return result.data;
}
