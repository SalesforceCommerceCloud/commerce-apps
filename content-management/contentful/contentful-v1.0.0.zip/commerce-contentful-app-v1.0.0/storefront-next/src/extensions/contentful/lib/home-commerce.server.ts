/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { LoaderFunctionArgs } from "react-router";
import { siteContext, type SiteContext } from "@salesforce/storefront-next-runtime/site-context";
import { fetchCarouselProducts } from "@/components/product-carousel/loaders";
import { fetchCategories } from "@/lib/api/categories.server";
import { getLogger } from "@/lib/logger.server";
import type { ContentfulRenderData } from "./props";
import type { ContentfulHomeCommerce, ContentfulHomeCommerceResult } from "./home-commerce";
import { CONTENTFUL_HOME_OWNER_ID } from "./home-demo";

/**
 * Prepare route-owned Commerce results for the two demo adapters without invoking
 * registry child loaders (the Contentful renderer path deliberately rejects those).
 * Return handled promises, not awaited catalog data: React Router streams each section
 * through home-commerce.tsx while critical editorial content can render immediately.
 * Nothing is cached or fetched from a component render.
 *
 * Keys MUST match component-tree.ts: the route's owner ID plus root/region/index paths.
 * Contentful entry IDs are not occurrence IDs; repeated references and reordered sections
 * need distinct result slots. Keep this traversal and CONTENTFUL_HOME_OWNER_ID aligned
 * with the component passed to ContentfulContent by _app.contentful-home.tsx.
 */
export function loadContentfulHomeCommerce(
    content: ContentfulRenderData,
    context: LoaderFunctionArgs["context"],
): ContentfulHomeCommerce {
    const results: ContentfulHomeCommerce = {};
    const logger = getLogger(context);
    const currency = (context.get(siteContext) as SiteContext).currency ?? undefined;
    let count = 0;
    const visit = (node: ContentfulRenderData, path: string) => {
        let kind: "products" | "categories" | undefined;
        if (node.renderer === "Contentful.homeProducts") {
            kind = "products";
        } else if (node.renderer === "Contentful.homeCategories") {
            kind = "categories";
        }
        if (kind) {
            const id = `${CONTENTFUL_HOME_OWNER_ID}:contentful:${path}`;
            const category = kind === "products" ? node.props.categoryId : node.props.parentId;
            const limit = node.props.limit;
            // A bounded component tree can still issue many catalog queries. Apply a separate
            // query budget and product cap here, even if the model's validations were edited.
            // Pass IDs to existing Commerce helpers; authored values never become request URLs.
            const valid =
                typeof category === "string" &&
                category.trim().length > 0 &&
                category.length <= 256 &&
                (kind !== "products" ||
                    (typeof limit === "number" && Number.isInteger(limit) && limit >= 1 && limit <= 24));
            if (++count > 12 || !valid) {
                logger.warn("contentful.home.commerce.unavailable", {
                    renderer: node.renderer,
                    reason: "invalid_configuration",
                });
                results[id] = Promise.resolve({ kind: "unavailable" });
            } else {
                // Handle rejection immediately, including synchronous client/config errors. Returning these
                // promises lets React Router stream each non-critical section without delaying the hero.
                results[id] = Promise.resolve()
                    .then(async (): Promise<ContentfulHomeCommerceResult> => {
                        if (kind === "products") {
                            return {
                                kind,
                                data: await fetchCarouselProducts(context, {
                                    categoryId: category,
                                    limit: limit as number,
                                    currency,
                                }),
                            };
                        }
                        return { kind, data: await fetchCategories(context, category, 1) };
                    })
                    .catch((): ContentfulHomeCommerceResult => {
                        logger.warn("contentful.home.commerce.unavailable", {
                            renderer: node.renderer,
                            reason: "request_failed",
                        });
                        return { kind: "unavailable" };
                    });
            }
        }
        // Follow rendered regions only, preserving their order and path indices. Ordinary
        // JSON props may contain links but do not create components or Commerce work.
        for (const region of node.regions ?? []) {
            region.components.forEach((child, index) => visit(child, `${path}/${region.id}/${index}`));
        }
    };
    visit(content, "root");
    return results;
}
