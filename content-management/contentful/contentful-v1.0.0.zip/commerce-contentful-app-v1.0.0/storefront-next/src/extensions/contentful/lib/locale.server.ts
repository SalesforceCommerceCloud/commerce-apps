/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import type { LoaderFunctionArgs } from "react-router";
import { siteContext } from "@salesforce/storefront-next-runtime/site-context";
import { getSite } from "@/lib/utils.server";

/** Page Designer's `default` is a Salesforce sentinel, not a Contentful locale ID. */
export function getContentfulLocale(context: LoaderFunctionArgs["context"]): string {
    const requested = getSite(context).locale;
    const locale = requested === "default" ? context.get(siteContext)?.site.defaultLocale : requested;
    if (!locale || locale === "default" || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(locale)) {
        throw new Error("Missing or invalid storefront locale");
    }
    return locale;
}
