/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
/** Dot-separated path starting at the selected entry's fields. */
export type FieldMapping = string;
export interface ContentfulModelMapping {
    renderer: string;
    fields: Record<string, FieldMapping>;
    defaults: Record<string, JsonValue>;
    regions?: Record<string, FieldMapping>;
}
export type ContentfulMappings = Record<string, ContentfulModelMapping>;
function safeId(value: unknown): value is string {
    return (
        typeof value === "string" &&
        /^[A-Za-z0-9_-]{1,128}$/.test(value) &&
        !["__proto__", "constructor", "prototype"].includes(value)
    );
}
function safePath(value: unknown): value is string {
    if (typeof value !== "string" || value.length > 2048) {
        return false;
    }
    const segments = value.split(".");
    return segments.length <= 16 && segments.every(safeId);
}
function safeProp(value: string): boolean {
    return (
        safeId(value) &&
        !/^on/i.test(value) &&
        ![
            "children",
            "ref",
            "key",
            "data",
            "component",
            "componentData",
            "designMetadata",
            "regionId",
            "dangerouslySetInnerHTML",
        ].includes(value)
    );
}
function object(value: unknown): value is Record<string, unknown> {
    return !!value && typeof value === "object" && !Array.isArray(value);
}
function jsonValue(value: unknown, depth: number): boolean {
    if (depth > 8) {
        return false;
    }
    if (value === null || typeof value === "string" || typeof value === "boolean") {
        return true;
    }
    if (typeof value === "number") {
        return isFinite(value);
    }
    if (Array.isArray(value)) {
        return value.every((item) => {
            return jsonValue(item, depth + 1);
        });
    }
    if (!object(value)) {
        return false;
    }
    return Object.keys(value).every((key) => {
        return safeId(key) && jsonValue(value[key], depth + 1);
    });
}
/** Parse only data: renderer IDs resolve through SFNext, never through configured import paths. */
export function parseMappings(raw: unknown): ContentfulMappings {
    const input: unknown = typeof raw === "string" ? JSON.parse(raw) : raw;
    if (!object(input)) {
        throw new Error("Mappings must be a JSON object");
    }
    const source = input;
    const models = Object.keys(source).sort();
    const output: ContentfulMappings = {};
    models.forEach((model) => {
        if (!model.trim() || ["__proto__", "constructor", "prototype"].includes(model)) {
            throw new Error("Invalid model ID");
        }
        const mapping = source[model];
        if (
            !object(mapping) ||
            typeof mapping.renderer !== "string" ||
            !/^[A-Za-z][A-Za-z0-9_-]*\.[A-Za-z][A-Za-z0-9_-]*$/.test(mapping.renderer) ||
            mapping.renderer === "Content.contentfulContent"
        ) {
            throw new Error("Invalid registered renderer ID");
        }
        Object.keys(mapping).forEach((key) => {
            if (!["renderer", "fields", "defaults", "labelField", "regions"].includes(key)) {
                throw new Error("Unknown mapping option");
            }
        });
        const fields = (mapping.fields === undefined ? {} : mapping.fields) as Record<string, unknown>;
        const defaults = (mapping.defaults === undefined ? {} : mapping.defaults) as Record<string, unknown>;
        if (
            !object(fields) ||
            !object(defaults) ||
            Object.keys(fields).length > 100 ||
            Object.keys(defaults).length > 100
        ) {
            throw new Error("Fields and defaults must be objects with at most 100 props");
        }
        const resolved: Record<string, FieldMapping> = {};
        Object.keys(fields)
            .sort()
            .forEach((target) => {
                if (!safeProp(target)) {
                    throw new Error("Invalid or reserved target prop");
                }
                const field = fields[target];
                if (!safePath(field)) {
                    throw new Error("Invalid field path");
                }
                resolved[target] = field;
            });
        const literals: Record<string, JsonValue> = {};
        Object.keys(defaults)
            .sort()
            .forEach((target) => {
                if (!safeProp(target) || !jsonValue(defaults[target], 0)) {
                    throw new Error("Invalid default prop");
                }
                literals[target] = defaults[target] as JsonValue;
            });
        // Legacy labelField is accepted but unused; BM labels use Contentful displayField.
        const regions = mapping.regions === undefined ? {} : mapping.regions;
        if (!object(regions) || Object.keys(regions).length > 20) {
            throw new Error("Regions must be an object with at most 20 paths");
        }
        const resolvedRegions: Record<string, FieldMapping> = {};
        Object.keys(regions)
            .sort()
            .forEach((id) => {
                if (!safeId(id) || !safePath(regions[id])) {
                    throw new Error("Invalid region mapping");
                }
                resolvedRegions[id] = regions[id];
            });
        output[model] = { renderer: mapping.renderer, fields: resolved, defaults: literals };
        if (Object.keys(resolvedRegions).length) {
            output[model].regions = resolvedRegions;
        }
    });
    return output;
}
