/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import type { LoaderFunctionArgs } from "react-router";
import { getSitePreferencesLazy } from "@salesforce/storefront-next-runtime/data-store";
import { getContentfulLocale } from "./locale.server";
import { getLogger } from "@/lib/logger.server";
import { getContentfulDeliveryConfig, getContentfulToken } from "./get-config.server";
import type { ContentfulConfig } from "./types";
import { diagnosticErrorType, type ContentfulDiagnostic } from "./diagnostics";
import type { ContentfulImageData } from "./asset-image";
import type { ContentfulVideoData, ContentfulVideoComponentData } from "./asset-video";
import { requestContentful } from "./request.server";
import { isContentfulResourceId } from "./resource-id";

/** Contentful's locale-resolved asset fields; an unavailable/unprocessed file may be absent. */
interface AssetResponse {
    fields: {
        title?: string;
        description?: string;
        file?: {
            url?: string;
            contentType: string;
            details?: { size?: number; image?: { width: number; height: number } };
        };
    };
}

/**
 * Adapt a published image to serializable props, skipping absent files and other media types.
 * The single-asset endpoint establishes identity and response field types; preserve its
 * URL and optional metadata for browser resolution, rendering and image transformations.
 */
function adaptAsset(payload: unknown, assetId: string): ContentfulImageData | null {
    const { fields } = payload as AssetResponse;
    const file = fields.file;
    if (!file?.url || !file.contentType.startsWith("image/")) {
        return null;
    }
    return {
        assetId,
        url: file.url,
        alt: fields.description ?? fields.title ?? "",
        contentType: file.contentType,
        width: file.details?.image?.width,
        height: file.details?.image?.height,
        fileSize: file.details?.size,
    };
}

/**
 * Fetch one published asset from the configured Delivery endpoint, independent of entry
 * mappings and preview mode. Invalid selections/configuration return null without fetching.
 * Retry network/parse errors, rate limits and server failures within the configured bounds;
 * exhausted retries, missing/unsupported assets and other HTTP failures return null.
 * Diagnostics never include content or credentials.
 */
async function fetchPublishedAsset<T>(
    config: ContentfulConfig,
    token: string | undefined,
    assetId: unknown,
    diagnostic: ContentfulDiagnostic | undefined,
    adapt: (payload: unknown, assetId: string) => T | null,
    kind: "image" | "video",
): Promise<T | null> {
    if (!isContentfulResourceId(assetId)) {
        diagnostic?.("contentful.asset.selection_invalid", {}, "warn");
        return null;
    }
    if (!config.spaceId || !token || config.previewMode || config.locale === "*") {
        diagnostic?.("contentful.asset.configuration_missing", {}, "warn");
        return null;
    }
    // The caller must supply Delivery configuration; preview configurations are rejected above.
    const url = new URL(
        `https://${config.host}/spaces/${encodeURIComponent(config.spaceId)}/environments/${encodeURIComponent(config.environment)}/assets/${encodeURIComponent(assetId)}`,
    );
    if (config.locale) {
        url.searchParams.set("locale", config.locale);
    }
    const metadata = {
        assetId,
        spaceId: config.spaceId,
        environment: config.environment,
        previewMode: false,
        locale: config.locale,
    };
    const result = await requestContentful({
        url,
        token,
        fetchRetries: config.fetchRetries,
        fetchTimeoutMs: config.fetchTimeoutMs,
        resource: "asset",
        metadata,
        diagnostic,
        adapt: (payload) => {
            const asset = adapt(payload, assetId);
            if (!asset) {
                diagnostic?.("contentful.asset.unavailable", { ...metadata, reason: `unsupported_${kind}` }, "warn");
            }
            return asset;
        },
    });
    if (!result) {
        return null;
    }
    diagnostic?.(
        "contentful.asset.loaded",
        { ...metadata, attempt: result.attempt, durationMs: result.durationMs },
        "info",
    );
    return result.data;
}

/** Fetch a published image while preserving the established image-only API and diagnostics. */
export function fetchContentfulAsset(
    config: ContentfulConfig,
    token: string | undefined,
    assetId: unknown,
    diagnostic?: ContentfulDiagnostic,
): Promise<ContentfulImageData | null> {
    return fetchPublishedAsset(config, token, assetId, diagnostic, adaptAsset, "image");
}

/** Adapt a published video file without assuming image dimensions, transformations or generated captions/posters. */
function adaptVideoAsset(payload: unknown, assetId: string): ContentfulVideoData | null {
    const { fields } = payload as AssetResponse;
    const file = fields.file;
    // Unlike the filtered picker query, a saved ID can point at a different media kind.
    if (!file?.url || !file.contentType.startsWith("video/")) {
        return null;
    }
    return {
        assetId,
        url: file.url,
        contentType: file.contentType,
        label: fields.description?.trim() ? fields.description : fields.title || "",
    };
}

/** Fetch a published video through the same bounded Delivery request path as images. */
export function fetchContentfulVideoAsset(
    config: ContentfulConfig,
    token: string | undefined,
    assetId: unknown,
    diagnostic?: ContentfulDiagnostic,
): Promise<ContentfulVideoData | null> {
    return fetchPublishedAsset(config, token, assetId, diagnostic, adaptVideoAsset, "video");
}

/**
 * Load a published asset using synchronized BM Delivery settings, private MRT credentials and request-context logging.
 * Accept a string ID; the Page Designer loader unwraps its editor object separately.
 * Return adapted props or null for invalid selections, unavailable assets or handled failures.
 */
async function loadPublishedAsset<T>(
    {
        assetId,
        context,
    }: {
        assetId: string;
        context: LoaderFunctionArgs["context"];
    },
    fetchAsset: (
        config: ContentfulConfig,
        token: string | undefined,
        assetId: unknown,
        diagnostic?: ContentfulDiagnostic,
    ) => Promise<T | null>,
): Promise<T | null> {
    const logger = getLogger(context);
    /** Forward only the fetcher's safe event metadata to the request logger at the supplied severity. */
    const diagnostic: ContentfulDiagnostic = (event, metadata, level = "error") => logger[level](event, metadata);
    try {
        if (!isContentfulResourceId(assetId)) {
            diagnostic("contentful.asset.selection_invalid", {}, "warn");
            return null;
        }
        const preferences = (await getSitePreferencesLazy(context)) ?? {};
        return await fetchAsset(
            getContentfulDeliveryConfig(preferences, getContentfulLocale(context)),
            getContentfulToken(false),
            assetId,
            diagnostic,
        );
    } catch (error) {
        diagnostic("contentful.asset.loader_failed", { assetId, errorType: diagnosticErrorType(error) });
        return null;
    }
}

/** Resolve current-site Delivery preferences and locale for each published image load; no content is cached. */
export function loadContentfulAsset(args: {
    assetId: string;
    context: LoaderFunctionArgs["context"];
}): Promise<ContentfulImageData | null> {
    return loadPublishedAsset(args, fetchContentfulAsset);
}

/** Resolve current-site Delivery preferences and locale for each published video load; preview settings never enable drafts. */
export function loadContentfulVideoAsset(args: {
    assetId: string;
    context: LoaderFunctionArgs["context"];
}): Promise<ContentfulVideoData | null> {
    return loadPublishedAsset(args, fetchContentfulVideoAsset);
}

/**
 * Load complete published-video component data for a route or Page Designer adapter.
 * Resolve settings/credentials once and fetch the optional poster alongside the video.
 * An invalid/missing video returns null; an invalid/unavailable poster is omitted.
 * The request locale supplies the default captions language. No content is cached.
 */
export function loadContentfulVideo({
    assetId,
    posterAssetId,
    context,
}: {
    assetId: string;
    posterAssetId?: string;
    context: LoaderFunctionArgs["context"];
}): Promise<ContentfulVideoComponentData | null> {
    return loadPublishedAsset({ assetId, context }, async (config, token, id, diagnostic) => {
        const [video, poster] = await Promise.all([
            fetchContentfulVideoAsset(config, token, id, diagnostic),
            posterAssetId ? fetchContentfulAsset(config, token, posterAssetId, diagnostic) : null,
        ]);
        if (!video) {
            return null;
        }
        // Delivery configuration already resolved and validated this request locale.
        return { ...video, posterUrl: poster?.url, locale: config.locale! };
    });
}
