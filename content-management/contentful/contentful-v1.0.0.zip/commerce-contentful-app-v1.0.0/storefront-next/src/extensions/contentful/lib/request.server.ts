/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { diagnosticErrorType, type ContentfulDiagnostic } from "./diagnostics";

/** BM integer preferences are validated again here for direct callers and missing data. */
function setting(value: unknown, fallback: number, min: number, max: number): number {
    return typeof value === "number" && Number.isInteger(value) && value >= min && value <= max ? value : fallback;
}

/**
 * Fetch JSON and adapt it without retaining content. Retry network/JSON failures,
 * HTTP 429 and 5xx responses. Other HTTP failures and adaptation failures stop immediately.
 * Keep resource-specific adaptation and safe event metadata in the calling fetcher.
 */
export async function requestContentful<T>({
    url,
    token,
    resource,
    metadata,
    diagnostic,
    adapt,
    fetchRetries,
    fetchTimeoutMs,
}: {
    fetchRetries?: unknown;
    fetchTimeoutMs?: unknown;
    url: URL;
    token: string;
    resource: "entry" | "asset";
    metadata: Record<string, unknown>;
    diagnostic?: ContentfulDiagnostic;
    adapt: (payload: unknown) => T | null;
}): Promise<{ data: T; attempt: number; durationMs: number } | null> {
    const retries = setting(fetchRetries, 2, 0, 3);
    const timeout = setting(fetchTimeoutMs, 4000, 1, 30_000);
    const attemptEvent = resource === "entry" ? "contentful.fetch.attempt" : "contentful.asset.fetch_attempt";
    const attemptFailedEvent =
        resource === "entry" ? "contentful.fetch.attempt_failed" : "contentful.asset.fetch_attempt_failed";
    const failedEvent = resource === "entry" ? "contentful.fetch.failed" : "contentful.asset.fetch_failed";
    const started = Date.now();
    for (let attempt = 1; attempt <= retries + 1; attempt++) {
        let stage = "fetch";
        let httpStatus: number | undefined;
        let retryable = true;
        try {
            diagnostic?.(attemptEvent, { ...metadata, attempt }, "debug");
            const response = await fetch(url, {
                headers: { Authorization: `Bearer ${token}` },
                signal: AbortSignal.timeout(timeout),
            });
            httpStatus = response.status;
            if (response.status === 404 || response.status === 410) {
                diagnostic?.(
                    `contentful.${resource}.unavailable`,
                    { ...metadata, httpStatus, reason: "not_found" },
                    "warn",
                );
                return null;
            }
            if (!response.ok) {
                retryable = response.status === 429 || (response.status >= 500 && response.status < 600);
                throw new Error("Contentful HTTP failure");
            }
            stage = "response_parse";
            const payload: unknown = await response.json();
            stage = "mapping";
            retryable = false;
            const data = adapt(payload);
            return data === null ? null : { data, attempt, durationMs: Date.now() - started };
        } catch (error) {
            const willRetry = retryable && attempt <= retries;
            diagnostic?.(
                attemptFailedEvent,
                { ...metadata, stage, httpStatus, attempt, errorType: diagnosticErrorType(error), willRetry },
                "warn",
            );
            if (!willRetry) {
                diagnostic?.(
                    failedEvent,
                    { ...metadata, attempts: attempt, durationMs: Date.now() - started },
                    "error",
                );
                return null;
            }
            await new Promise((resolve) => setTimeout(resolve, 150 * attempt));
        }
    }
    return null;
}
