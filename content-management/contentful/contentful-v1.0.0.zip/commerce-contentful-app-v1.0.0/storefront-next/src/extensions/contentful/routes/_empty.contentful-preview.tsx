/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

import { data, useLoaderData, type LoaderFunctionArgs } from "react-router";
import { getContentfulLocale } from "@/extensions/contentful/lib/locale.server";
import ContentfulContent from "@/components/contentful-content";
import { ContentPreviewProvider } from "@/components/content-preview-provider";
import {
    authorizeContentPreview,
    getContentPreview,
    getContentPreviewSettings,
} from "@/extensions/contentful/lib/content-preview.server";
import { loadContentfulEntry } from "@/extensions/contentful/lib/load-entry.server";
import { readSelection } from "@/extensions/contentful/lib/entry.server";

const previewHeaders = {
    "Cache-Control": "private, no-store",
    "Referrer-Policy": "no-referrer",
    "X-Robots-Tag": "noindex, nofollow",
};

export const meta = () => [{ name: "robots", content: "noindex,nofollow" }];
// Document and loader-data responses are non-cacheable even before the root
// preview middleware is registered. Root middleware is still required for framing.
export const headers = () => previewHeaders;

function notFound(): Response {
    return new Response("Content preview unavailable", { status: 404, headers: previewHeaders });
}

/** Isolated preview of any mapped entry; no saved Page Designer component is required. */
export async function loader({ request, context }: LoaderFunctionArgs) {
    if (!authorizeContentPreview(request)) {
        throw notFound();
    }
    const entryId = readSelection(new URL(request.url).searchParams.get("entryId"));
    if (!entryId) {
        throw notFound();
    }
    const preview = getContentPreview(request, getContentfulLocale(context));
    const previewSettings = await getContentPreviewSettings(context);
    const content = await loadContentfulEntry({ entryId, context, request });
    if (!content) {
        throw notFound();
    }
    return data(
        { preview, previewSettings, content, ownerId: `contentful-preview:${entryId}` },
        { headers: previewHeaders },
    );
}

// Save events explicitly revalidate this route; do not use the home route's policy.
export const shouldRevalidate = () => true;

/** Site preferences control inspection and editor origin; customize this module for layout or a different URL. */
export default function ContentfulPreviewRoute() {
    const { preview, previewSettings, content, ownerId } = useLoaderData<typeof loader>();
    return (
        <ContentPreviewProvider
            preview={preview}
            inspector={previewSettings.inspector}
            targetOrigin={previewSettings.editorOrigin}
        >
            <ContentfulContent data={content} component={{ id: ownerId }} />
        </ContentPreviewProvider>
    );
}
