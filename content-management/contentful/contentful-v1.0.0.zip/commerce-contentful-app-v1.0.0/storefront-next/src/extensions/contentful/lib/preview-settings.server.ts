// Keep normalization aligned with int_contentful/scripts/previewSettings; tests share contract cases.
export interface PreviewSettings {
    inspector: boolean;
    editorOrigin: string;
}
/** Non-secret, per-site settings. An explicit origin is never read from request parameters. */
export function resolveContentPreviewSettings(preferences: Record<string, unknown>): PreviewSettings {
    const configured =
        typeof preferences.contentfulPreviewEditorOrigin === "string"
            ? preferences.contentfulPreviewEditorOrigin.trim()
            : "";
    const origin =
        configured ||
        (preferences.contentfulHost === "cdn.eu.contentful.com" ||
        preferences.contentfulPreviewHost === "preview.eu.contentful.com"
            ? "https://app.eu.contentful.com"
            : "https://app.contentful.com");
    const match = /^https:\/\/([A-Za-z0-9.-]+|\[[A-Fa-f0-9:]+\])(?::([0-9]{1,5}))?$/i.exec(origin);
    if (!match || (match[2] !== undefined && (Number(match[2]) < 1 || Number(match[2]) > 65535))) {
        throw new Error("Invalid Contentful editor origin");
    }
    return {
        inspector: preferences.contentfulPreviewInspector === true,
        editorOrigin: `https://${match[1].toLowerCase()}${match[2] && Number(match[2]) !== 443 ? `:${Number(match[2])}` : ""}`,
    };
}
