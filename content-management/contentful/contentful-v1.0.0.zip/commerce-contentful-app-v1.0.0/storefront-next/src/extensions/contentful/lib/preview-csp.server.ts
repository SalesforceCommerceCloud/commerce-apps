/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { CspContributor } from "@salesforce/storefront-next-runtime/security";

/**
 * Preview framing policy only. Consumed by contentPreviewMiddleware AFTER authorization;
 * do not register this as a boot-static contributor on ordinary shopper responses.
 * Inactive by default to make accidental global registration safe. The trusted
 * response adapter explicitly enables it; authorization stays in the middleware.
 * X-Frame-Options and authorization are separate middleware responsibilities.
 */
export function createContentfulPreviewCspContributor(
    enabled = false,
    editorOrigin = "https://app.contentful.com",
): CspContributor {
    return {
        id: "contentful-preview",
        isActive: () => enabled,
        contribute: () => ({ "frame-ancestors": [editorOrigin] }),
    };
}

// The current SDK middleware consumes only boot-static directives. Apply this
// contributor to the final response instead, preserving nonce/BM directives.
/** Trusted preview-only adapter; the caller must authorize before invoking it. */
export function applyContentfulPreviewCsp(response: Response, editorOrigin: string): Response {
    const origins =
        createContentfulPreviewCspContributor(true, editorOrigin).contribute({ baseDirectives: {} })[
            "frame-ancestors"
        ] ?? [];
    for (const name of ["Content-Security-Policy", "Content-Security-Policy-Report-Only"]) {
        const original = response.headers.get(name);
        // Preserve existing sources (including BM); remove 'none', which cannot accompany an origin.
        const directives = (original ?? "")
            .split(";")
            .map((value) => value.trim())
            .filter(Boolean);
        const index = directives.findIndex((value) => /^frame-ancestors(?:\s|$)/i.test(value));
        const sources =
            index < 0
                ? ["'self'"]
                : directives[index]
                      .split(/\s+/)
                      .slice(1)
                      .filter((value) => value !== "'none'");
        const clause = `frame-ancestors ${[...new Set([...sources, ...origins])].join(" ")}`;
        if (index < 0) {
            directives.push(clause);
        } else {
            directives[index] = clause;
        }
        if (original || name === "Content-Security-Policy") {
            response.headers.set(name, directives.join("; "));
        }
    }
    return response;
}
