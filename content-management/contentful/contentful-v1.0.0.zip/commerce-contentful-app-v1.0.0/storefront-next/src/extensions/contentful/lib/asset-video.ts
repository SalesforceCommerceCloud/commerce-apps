/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** Published video file metadata; Contentful does not supply image transformations or associated poster/caption assets. */
export interface ContentfulVideoData {
    assetId: string;
    url: string;
    contentType: string;
    label: string;
}

/** JSON loader result, including an independently selected poster and the resolved request locale for captions. */
export interface ContentfulVideoComponentData extends ContentfulVideoData {
    posterUrl?: string;
    locale: string;
}
