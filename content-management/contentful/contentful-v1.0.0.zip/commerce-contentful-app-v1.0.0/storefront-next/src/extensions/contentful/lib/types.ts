/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_CONTENTFUL */

/** Server connection settings resolved from non-secret BM site preferences. */
export interface ContentfulConfig {
    /** Contentful space id. */
    spaceId: string;
    /** Contentful environment (e.g. `master`). */
    environment: string;
    /** CDA host — `cdn.contentful.com` for delivery, `preview.contentful.com` for preview. */
    host: string;
    /** When true, the app uses the preview host + token to render draft content. */
    previewMode: boolean;
    /** Per-request retry and timeout preferences; the transport applies bounded defaults. */
    fetchRetries?: unknown;
    fetchTimeoutMs?: unknown;
    /** Explicit locale keeps returned fields and inspector tags consistent. */
    locale?: string;
}

/** Minimal subset of the Contentful CDA response shape used by field mapping. */
export interface CdaEntry {
    sys: { id: string; contentType?: { sys: { id: string } } };
    fields: Record<string, unknown>;
}

export interface CdaAsset {
    sys: { id: string };
    fields: { title?: string; description?: string; file?: { url?: string } };
}

export interface CdaResponse {
    items: CdaEntry[];
    includes?: { Entry?: CdaEntry[]; Asset?: CdaAsset[] };
}
