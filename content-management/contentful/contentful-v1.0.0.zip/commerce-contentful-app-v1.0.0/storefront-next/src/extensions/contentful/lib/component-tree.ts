/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ComponentType } from "@/components/region";
import type { ContentfulRenderData } from "./props";

/** Generated, read-only Region input; never use these identities for Page Designer writes. */
export function createContentfulComponentTree(data: ContentfulRenderData, ownerId: string): ComponentType {
    const build = (node: ContentfulRenderData, path: string): ComponentType =>
        ({
            id: `${ownerId}:contentful:${path}`,
            typeId: node.renderer,
            data: node.props,
            visible: true,
            ...(node.source ? { contentfulSource: node.source } : {}),
            regions: (node.regions ?? []).map((region) => ({
                id: region.id,
                components: region.components.map((child, index) => build(child, `${path}/${region.id}/${index}`)),
            })),
        }) as ComponentType;
    return build(data, "root");
}
