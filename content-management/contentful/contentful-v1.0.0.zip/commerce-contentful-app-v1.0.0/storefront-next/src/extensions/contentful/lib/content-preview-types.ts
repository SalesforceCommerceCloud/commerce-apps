/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** Safe browser state. Authorization is always checked independently on MRT. */
export interface ContentPreviewState {
    enabled: boolean;
    locale: string;
}
export interface ContentfulFieldSource {
    entryId?: string;
    assetId?: string;
    fieldId: string;
}
export interface ContentfulSource {
    entryId: string;
    fields: Record<string, ContentfulFieldSource>;
}
export const CONTENT_PREVIEW_PARAM = "cfpreview";
