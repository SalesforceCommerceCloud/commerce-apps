/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { getSitePreferencesLazy } from "@salesforce/storefront-next-runtime/data-store";
import type { LoaderFunctionArgs } from "react-router";
import { resolveContentPreviewSettings } from "./preview-settings.server";
import { timingSafeEqual } from "node:crypto";
import type { MiddlewareFunction } from "react-router";
import { CONTENT_PREVIEW_PARAM, type ContentPreviewState } from "./content-preview-types";

import { applyContentfulPreviewCsp } from "./preview-csp.server";

function denied(): Response {
    return new Response("Content preview is unavailable or unauthorized", {
        status: 403,
        headers: { "Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer" },
    });
}

/** A query flag is not authorization. Missing configuration fails closed. Never log the URL. */
export function authorizeContentPreview(request?: Request): boolean {
    const url = request ? new URL(request.url) : undefined;
    const enabled = Boolean(url?.searchParams.has(CONTENT_PREVIEW_PARAM));
    if (enabled) {
        const secret = process.env.CONTENTFUL_PREVIEW_SECRET?.trim();
        const candidate = url!.searchParams.get(CONTENT_PREVIEW_PARAM) ?? "";
        if (!secret || !process.env.CONTENTFUL_PREVIEW_TOKEN?.trim()) {
            throw denied();
        }
        const expected = Buffer.from(secret);
        const supplied = Buffer.from(candidate);
        if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) {
            throw denied();
        }
    }
    return enabled;
}

/** Resolve the Contentful locale from the storefront, with an authorized preview override only. */
export function getContentPreview(request: Request | undefined, storefrontLocale: unknown): ContentPreviewState {
    const enabled = authorizeContentPreview(request);
    const locale =
        (enabled && request ? new URL(request.url).searchParams.get("cf_locale") : undefined) ||
        (typeof storefrontLocale === "string" ? storefrontLocale : "");
    // No wildcard locales: the adapter expects one localized field value, not a locale map.
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(locale)) {
        throw denied();
    }
    return { enabled, locale };
}

/** Resolve only after preview authorization; return no credentials or connection settings. */
export async function getContentPreviewSettings(context: LoaderFunctionArgs["context"]) {
    try {
        return resolveContentPreviewSettings((await getSitePreferencesLazy(context)) ?? {});
    } catch {
        throw denied();
    }
}

/** Wrap outside the existing security middleware so its final headers are adjusted only for authorized previews. */
export function applyContentPreviewHeaders(response: Response, editorOrigin: string): Response {
    response.headers.set("Cache-Control", "private, no-store");
    response.headers.set("Referrer-Policy", "no-referrer");
    response.headers.set("X-Robots-Tag", "noindex, nofollow");
    response.headers.delete("X-Frame-Options");
    return applyContentfulPreviewCsp(response, editorOrigin);
}

export const contentPreviewMiddleware: MiddlewareFunction<Response> = async ({ request, context }, next) => {
    if (!authorizeContentPreview(request)) {
        return next();
    }
    let response: Response;
    try {
        response = await next();
    } catch (error) {
        if (error instanceof Response) {
            const settings = await getContentPreviewSettings(context);
            throw applyContentPreviewHeaders(error, settings.editorOrigin);
        }
        throw error;
    }
    // Site/data-store middleware runs inside next(); its lazy preferences loader
    // must be registered before resolving the origin for the final response.
    const settings = await getContentPreviewSettings(context);
    return applyContentPreviewHeaders(response, settings.editorOrigin);
};
