/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** Accept a resource ID, excluding paths, queries and Page Designer storage objects. */
export function isContentfulResourceId(value: unknown): value is string {
    // Keep request/credential syntax out of diagnostics while treating provider IDs as opaque.
    return (
        typeof value === "string" && value.length > 0 && value !== "." && value !== ".." && !/[\s/\\?#:&=%]/.test(value)
    );
}
