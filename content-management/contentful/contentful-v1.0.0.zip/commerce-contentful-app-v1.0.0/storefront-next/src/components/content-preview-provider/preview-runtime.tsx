/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { useEffect, useMemo, type ReactNode } from "react";
import { ContentfulLivePreviewProvider, useContentfulInspectorMode } from "@contentful/live-preview/react";
import { ContentfulLivePreview } from "@contentful/live-preview";
import { useRevalidator } from "react-router";
import { createLogger } from "@/lib/logger";
import { ContentPreviewContext } from "@/extensions/contentful/lib/content-preview";
import { subscribeContentPreviewSaves } from "@/extensions/contentful/lib/content-preview-session";
import type { ContentPreviewState } from "@/extensions/contentful/lib/content-preview-types";

const logger = createLogger();

function PreviewBridge({ children, preview }: { children: ReactNode; preview: ContentPreviewState }) {
    const tagField = useContentfulInspectorMode();
    const value = useMemo(() => ({ ...preview, tagField }), [preview, tagField]);
    const { revalidate } = useRevalidator();
    useEffect(() => {
        if (window.parent === window) {
            return;
        }
        // SDK provider initialization precedes this effect. No raw-entry edit subscription:
        // the server remains responsible for fetching and transforming content.
        return subscribeContentPreviewSaves(
            ContentfulLivePreview,
            () => {
                logger.debug("contentful.preview.refresh", {});
                void revalidate().catch(() => logger.warn("contentful.preview.refresh_failed", {}));
            },
            () => logger.warn("contentful.preview.sdk_failed", {}),
        );
    }, [revalidate]);
    return <ContentPreviewContext.Provider value={value}>{children}</ContentPreviewContext.Provider>;
}

export default function PreviewRuntime({
    children,
    preview,
    targetOrigin,
    inspector,
}: {
    children: ReactNode;
    preview: ContentPreviewState;
    inspector: boolean;
    targetOrigin: string;
}) {
    return (
        <ContentfulLivePreviewProvider
            locale={preview.locale}
            targetOrigin={targetOrigin}
            enableInspectorMode={inspector}
            enableLiveUpdates
        >
            <PreviewBridge preview={preview}>{children}</PreviewBridge>
        </ContentfulLivePreviewProvider>
    );
}
