/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, lazy, Suspense, type ReactNode } from "react";
import { createLogger } from "@/lib/logger";
import type { ContentPreviewState } from "@/extensions/contentful/lib/content-preview-types";

const LazyPreviewRuntime = lazy(() => import("./preview-runtime"));
const logger = createLogger();

/** Preview tooling failure must not hide otherwise renderable storefront content. */
class PreviewBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
    state = { failed: false };
    static getDerivedStateFromError() {
        return { failed: true };
    }
    componentDidCatch() {
        logger.warn("contentful.preview.sdk_failed", {});
    }
    render() {
        return this.state.failed ? this.props.fallback : this.props.children;
    }
}

/** Thin SFNext wrapper. Mount once, with server-validated state and stable SDK options. */
export function ContentPreviewProvider({
    children,
    preview,
    inspector = false,
    targetOrigin = "https://app.contentful.com",
}: {
    children: ReactNode;
    preview: ContentPreviewState;
    inspector?: boolean;
    targetOrigin?: string;
}) {
    if (!preview.enabled) {
        return <>{children}</>;
    }
    return (
        <PreviewBoundary fallback={children}>
            <Suspense fallback={children}>
                <LazyPreviewRuntime preview={preview} targetOrigin={targetOrigin} inspector={inspector}>
                    {children}
                </LazyPreviewRuntime>
            </Suspense>
        </PreviewBoundary>
    );
}
