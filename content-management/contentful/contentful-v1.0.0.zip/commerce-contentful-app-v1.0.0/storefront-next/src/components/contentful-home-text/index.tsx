/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import type { ComponentType } from "@/components/region";
import ContentCard from "@/components/content-card";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
@Component("homeText", { name: "Contentful homepage text", group: "Contentful" })
@RegionDefinition([])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulHomeTextMetadata {}

export default function ContentfulHomeText({
    heading,
    body,
    component,
}: {
    heading?: string;
    body?: string;
    component?: ComponentType;
}) {
    const inspector = useContentfulInspector(component);
    return (
        <section className="pt-16" {...inspector("heading")}>
            <div className="section-container">
                <div className="max-w-4xl mx-auto layout-gutter text-center">
                    <ContentCard
                        title={heading}
                        description={body}
                        showBackground={false}
                        showBorder={false}
                        cardFooterClassName="items-center text-center p-0"
                        cardDescriptionClassName="text-center"
                        className="[&_h3]:text-3xl [&_h3]:md:text-4xl [&_h3]:font-normal [&_h3]:text-brand-black [&_h3]:mb-6 [&_h3]:tracking-tight [&_p]:text-sm [&_p]:text-brand-gray-700 [&_p]:leading-relaxed [&_p]:font-normal [&_p:last-of-type]:text-base [&_p:last-of-type]:text-brand-gray-600"
                    />
                </div>
            </div>
        </section>
    );
}
