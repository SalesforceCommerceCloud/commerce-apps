/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import type { ComponentType } from "@/components/region";
import HeroCarousel from "@/components/hero-carousel";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
@Component("homeHeroCarousel", { name: "Contentful homepage hero-carousel", group: "Contentful" })
@RegionDefinition([{ id: "slides", name: "Slides", maxComponents: 10 }])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulHomeHeroCarouselMetadata {}

/**
 * Pass the mapped component tree through to native HeroCarousel. Its region implementation
 * must delegate slide rendering through the registry; flattening children to plain slide
 * props loses our slide inspector wrapper and authored accessibility/presentation fields.
 * Declare the supported props explicitly because the native Suspense wrapper may erase
 * ComponentProps<typeof HeroCarousel>'s component type to unknown.
 */
export default function ContentfulHomeHeroCarousel({
    component,
    ...props
}: {
    component?: ComponentType;
    internalName?: string;
    autoPlay?: boolean;
    autoPlayInterval?: number;
    showNavigation?: boolean;
    showDots?: boolean;
}) {
    const inspector = useContentfulInspector(component);
    return (
        <section {...inspector("internalName")}>
            <HeroCarousel {...props} component={component} />
        </section>
    );
}
