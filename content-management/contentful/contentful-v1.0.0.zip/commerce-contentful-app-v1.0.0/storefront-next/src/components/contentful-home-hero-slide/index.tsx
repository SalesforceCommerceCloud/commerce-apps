/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import type { ComponentProps } from "react";
import type { ComponentType } from "@/components/region";
import Hero from "@/components/hero";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
@Component("homeHeroSlide", { name: "Contentful homepage hero-slide", group: "Contentful" })
@RegionDefinition([])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulHomeHeroSlideMetadata {}

/**
 * Native Hero consumes the carousel-injected overlay, fillHeight and image priority/loading
 * props. Keep those intact when delegating. Heading level 2 matches the fallback carousel
 * beneath the page's hidden h1; the default native Hero level would introduce extra h1s.
 */
export default function ContentfulHomeHeroSlide({
    component,
    ...props
}: ComponentProps<typeof Hero> & { component?: ComponentType }) {
    const inspector = useContentfulInspector(component);
    return (
        <div className="h-full" {...inspector("title")}>
            <Hero headingLevel={2} {...props} />
        </div>
    );
}
