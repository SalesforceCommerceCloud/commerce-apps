/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { LoaderFunctionArgs } from "react-router";
import { getLogger } from "@/lib/logger.server";
import { loadContentfulVideo as loadVideo } from "@/extensions/contentful/lib/load-video.server";
import type { ContentfulVideoComponentData } from "@/extensions/contentful/lib/asset-video";

/**
 * Unwrap Page Designer's video and optional poster attributes and delegate to the shared server helper.
 * Missing/cleared video IDs skip loading; supplied IDs must be nonblank strings.
 * Routes call loadContentfulVideo with string IDs directly, without the editor storage shape.
 */
export async function loadContentfulVideo(args: {
    componentData: unknown;
    context: LoaderFunctionArgs["context"];
    request?: Request;
}): Promise<ContentfulVideoComponentData | null> {
    const component = args.componentData as {
        data?: { contentfulAsset?: { assetId?: unknown }; posterAsset?: { assetId?: unknown } };
    } | null;
    const assetId = component?.data?.contentfulAsset?.assetId;
    if (assetId == null) {
        return null;
    }
    if (typeof assetId !== "string" || !assetId.trim()) {
        getLogger(args.context).warn("contentful.asset.selection_invalid", {});
        return null;
    }
    const posterId = component?.data?.posterAsset?.assetId;
    return loadVideo({
        assetId,
        posterAssetId: typeof posterId === "string" && posterId.trim() ? posterId : undefined,
        context: args.context,
    });
}
