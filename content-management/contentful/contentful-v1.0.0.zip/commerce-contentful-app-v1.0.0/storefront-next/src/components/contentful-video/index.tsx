/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ReactElement } from "react";
import { Component } from "@/lib/decorators/component";
import { AttributeDefinition } from "@/lib/decorators/attribute-definition";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import type { ContentfulVideoComponentData } from "@/extensions/contentful/lib/asset-video";

@Component("contentfulVideo", {
    name: "Contentful Video",
    description: "Display a published video from the connected Contentful space.",
    group: "Content",
})
@RegionDefinition([])
export class ContentfulVideoMetadata {
    @AttributeDefinition({
        name: "Video",
        description: "Choose a published video. Browser codec support determines playback.",
        type: "custom",
        required: true,
        editorDefinition: { type: "contentful.videoPicker" },
    })
    contentfulAsset!: { assetId: string };

    @AttributeDefinition({
        name: "Poster image",
        description: "Optionally choose a published image to display before playback.",
        type: "custom",
        required: false,
        editorDefinition: { type: "contentful.assetPicker" },
    })
    posterAsset?: { assetId: string };

    @AttributeDefinition({
        name: "Custom video label",
        description:
            "Override the Contentful description or title used to label the player. This does not replace captions.",
        type: "string",
        required: false,
    })
    videoLabel?: string;

    @AttributeDefinition({
        name: "Autoplay",
        description: "Request automatic playback. Autoplay always starts muted and remains subject to browser policy.",
        type: "boolean",
        defaultValue: false,
    })
    autoPlay?: boolean;

    @AttributeDefinition({
        name: "Muted",
        description: "Start playback with audio muted. Autoplay always starts muted.",
        type: "boolean",
        defaultValue: false,
    })
    muted?: boolean;

    @AttributeDefinition({
        name: "Loop",
        description: "Restart playback when the video ends. Playback controls remain available.",
        type: "boolean",
        defaultValue: false,
    })
    loop?: boolean;

    @AttributeDefinition({
        name: "Preload",
        description: "Hint how much to download before playback. Autoplay can override this hint.",
        type: "enum",
        values: ["metadata", "none", "auto"],
        required: false,
        defaultValue: "auto",
    })
    preload?: "metadata" | "none" | "auto";

    @AttributeDefinition({
        name: "Captions URL",
        description:
            "Optional WebVTT captions URL. The host must permit cross-origin access and be allowed by storefront media CSP.",
        type: "url",
        required: false,
    })
    captionsUrl?: string;

    @AttributeDefinition({
        name: "Captions language",
        description: "BCP 47 language tag, such as en-US. Leave blank to use the storefront locale.",
        type: "string",
        required: false,
    })
    captionsLanguage?: string;
}

/**
 * Render a published file in the native player with a pause/control mechanism and inline playback.
 * Autoplay forces initial muting. Captions are explicitly authored WebVTT, not generated from asset metadata.
 * Preserve source/poster URLs for browser resolution and CSP; missing loader data renders nothing.
 */
export default function ContentfulVideo({
    data,
    videoLabel,
    autoPlay = false,
    muted = false,
    loop = false,
    preload = "auto",
    captionsUrl,
    captionsLanguage,
    className,
}: {
    data?: ContentfulVideoComponentData | null;
    videoLabel?: string;
    autoPlay?: boolean;
    muted?: boolean;
    loop?: boolean;
    preload?: "metadata" | "none" | "auto";
    captionsUrl?: string;
    captionsLanguage?: string;
    className?: string;
}): ReactElement | null {
    if (!data) {
        return null;
    }
    const captions = captionsUrl?.trim();
    return (
        <video
            key={data.url}
            controls
            playsInline
            autoPlay={autoPlay}
            muted={autoPlay || muted}
            loop={loop}
            preload={preload}
            poster={data.posterUrl}
            aria-label={videoLabel?.trim() ? videoLabel : data.label || undefined}
            crossOrigin={captions ? "anonymous" : undefined}
            className={className}
            style={{ display: "block", width: "100%", height: "auto" }}
        >
            <source src={data.url} type={data.contentType} />
            {captions ? (
                <track
                    kind="captions"
                    src={captions}
                    srcLang={(captionsLanguage?.trim() || data.locale).replaceAll("_", "-")}
                    label="Captions"
                    default
                />
            ) : null}
        </video>
    );
}

/** Render nothing while SFNext awaits the component's server loader. */
export function fallback(): null {
    return null;
}
export { loadContentfulVideo as loader } from "./loaders.server";
