/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
import { Region, type ComponentType } from "@/components/region";
import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";

@Component("aboutUsGrid", { name: "Contentful About Us two-column section", group: "Contentful" })
@RegionDefinition([
    { id: "left", name: "Left card", maxComponents: 1 },
    { id: "right", name: "Right card", maxComponents: 1 },
])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulAboutUsGridMetadata {}

export default function ContentfulAboutUsGrid({ component }: { component?: ComponentType }) {
    const inspector = useContentfulInspector(component);
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" {...inspector("internalName")}>
            {component && <Region component={component} regionId="left" />}
            {component && <Region component={component} regionId="right" />}
        </div>
    );
}
