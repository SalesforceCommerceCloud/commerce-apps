/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { LoaderFunctionArgs } from "react-router";
import { getLogger } from "@/lib/logger.server";
import { loadContentfulImage as loadImage } from "@/extensions/contentful/lib/load-image.server";

/**
 * Unwrap Page Designer's contentfulAsset: { assetId } custom attribute and load its
 * published image server-side. Missing/cleared IDs skip loading; supplied IDs must be
 * nonblank strings. The shared asset API validates the ID format and returns
 * serializable image data rather than raw CDA data.
 */
export async function loadContentfulImage(args: {
    componentData: unknown;
    context: LoaderFunctionArgs["context"];
    request?: Request;
}) {
    const component = args.componentData as { data?: { contentfulAsset?: { assetId?: unknown } } } | null;
    const assetId = component?.data?.contentfulAsset?.assetId;
    if (assetId == null) {
        return null;
    }
    if (typeof assetId !== "string" || !assetId.trim()) {
        getLogger(args.context).warn("contentful.asset.selection_invalid", {});
        return null;
    }
    return loadImage({ assetId, context: args.context });
}
