/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ReactElement } from "react";
import { Component } from "@/lib/decorators/component";
import { AttributeDefinition } from "@/lib/decorators/attribute-definition";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import { contentfulImageSources, type ContentfulImageData } from "@/extensions/contentful/lib/asset-image";

@Component("contentfulImage", {
    name: "Contentful Image",
    description: "Display a published image from the connected Contentful space.",
    group: "Content",
})
@RegionDefinition([])
export class ContentfulImageMetadata {
    @AttributeDefinition({
        name: "Image",
        description: "Choose a published image from the connected Contentful space.",
        type: "custom",
        required: true,
        editorDefinition: { type: "contentful.assetPicker" },
    })
    contentfulAsset!: { assetId: string };

    @AttributeDefinition({
        name: "Custom alternative text",
        description: "Override the Contentful description. Leave blank to use the image description or title.",
        type: "string",
        required: false,
    })
    altText?: string;

    @AttributeDefinition({
        name: "Decorative image",
        description: "Use empty alternative text for an image that adds no information.",
        type: "boolean",
        defaultValue: false,
    })
    decorative?: boolean;
}

/**
 * Render server-loaded image data at its natural aspect ratio with responsive sources.
 * Decorative mode forces empty alt text; otherwise a nonblank custom value overrides
 * the asset's description/title. Missing data renders nothing. Images load lazily.
 */
export default function ContentfulImage({
    data,
    altText,
    decorative = false,
    className,
}: {
    data?: ContentfulImageData | null;
    altText?: string;
    decorative?: boolean;
    className?: string;
}): ReactElement | null {
    if (!data) {
        return null;
    }
    const sources = contentfulImageSources(data);
    const resolvedAlt = altText?.trim() ? altText : data.alt;
    return (
        <img
            src={sources.src}
            srcSet={sources.srcSet}
            sizes={sources.srcSet ? "100vw" : undefined}
            alt={decorative ? "" : resolvedAlt}
            width={data.width}
            height={data.height}
            loading="lazy"
            decoding="async"
            className={className}
            style={{ width: "100%", height: "auto" }}
        />
    );
}

/** Render nothing while SFNext awaits the component's server loader. */
export function fallback(): null {
    return null;
}
export { loadContentfulImage as loader } from "./loaders.server";
