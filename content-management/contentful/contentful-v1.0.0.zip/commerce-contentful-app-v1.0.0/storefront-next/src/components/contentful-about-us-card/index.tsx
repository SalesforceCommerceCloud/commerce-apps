/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
import type { ComponentType } from "@/components/region";
import ContentCard from "@/components/content-card";
import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";

@Component("aboutUsCard", { name: "Contentful About Us content card", group: "Contentful" })
@RegionDefinition([])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulAboutUsCardMetadata {}

/** The preset supplies the original page's presentation without storing CSS in Contentful. */
export default function ContentfulAboutUsCard({
    variant,
    component,
    ...content
}: {
    component?: ComponentType;
    title?: string;
    description?: string;
    imageUrl?: string;
    imageAlt?: string;
    buttonText?: string;
    buttonLink?: string;
    variant?: "default" | "fullWidth" | "mission" | "team";
}) {
    const inspector = useContentfulInspector(component);
    let presentation = {};
    if (variant === "team") {
        presentation = {
            className: "full-width md:flex-row",
            cardFooterClassName: "justify-center flex-auto",
            cardDescriptionClassName: "flex-none",
            buttonClassName: "w-fit",
        };
    } else if (variant === "mission") {
        presentation = {
            className: "full-width",
            cardFooterClassName: "flex-col md:flex-row items-center",
            buttonClassName: "w-fit",
        };
    } else if (variant === "fullWidth") {
        presentation = { className: "full-width" };
    }
    // ContentCard forwards DOM attributes only at its root; inspect the card entry through its title.
    return <ContentCard {...content} {...presentation} {...inspector("title")} />;
}
