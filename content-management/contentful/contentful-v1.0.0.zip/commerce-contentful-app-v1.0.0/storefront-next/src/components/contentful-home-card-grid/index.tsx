/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import { Region, type ComponentType } from "@/components/region";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
@Component("homeCardGrid", { name: "Contentful homepage card-grid", group: "Contentful" })
@RegionDefinition([{ id: "cards", name: "Content cards" }])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulHomeCardGridMetadata {}

export default function ContentfulHomeCardGrid({ component }: { component?: ComponentType }) {
    const inspector = useContentfulInspector(component);
    return (
        <section className="pt-16" {...inspector("internalName")}>
            <div className="section-container">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {component && <Region component={component} regionId="cards" />}
                </div>
            </div>
        </section>
    );
}
