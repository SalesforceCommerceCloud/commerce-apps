/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import type { ComponentType } from "@/components/region";
import ContentCard from "@/components/content-card";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
@Component("homeCard", { name: "Contentful homepage card", group: "Contentful" })
@RegionDefinition([])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulHomeCardMetadata {}

export default function ContentfulHomeCard({
    component,
    ...props
}: {
    component?: ComponentType;
    title?: string;
    description?: string;
    imageUrl?: string;
    imageAlt?: string;
    buttonText?: string;
    buttonLink?: string;
    buttonAriaLabel?: string;
}) {
    const inspector = useContentfulInspector(component);
    return <ContentCard {...props} showBackground={false} showBorder={false} loading="lazy" {...inspector("title")} />;
}
