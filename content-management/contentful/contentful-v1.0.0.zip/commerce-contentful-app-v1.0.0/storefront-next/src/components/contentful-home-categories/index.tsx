/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import { Suspense } from "react";
import { Await } from "react-router";
import type { ComponentType } from "@/components/region";
import PopularCategories from "@/components/home/popular-categories";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";
import {
    useContentfulHomeCommerce,
    type ContentfulHomeCommerceResult,
} from "@/extensions/contentful/lib/home-commerce";
@Component("homeCategories", { name: "Contentful homepage categories", group: "Contentful" })
@RegionDefinition([])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulHomeCategoriesMetadata {}

export default function ContentfulHomeCategories({
    title,
    subtitle,
    failureMessage,
    component,
}: {
    title?: string;
    subtitle?: string;
    parentId?: string;
    failureMessage?: string;
    component?: ComponentType;
}) {
    const inspector = useContentfulInspector(component);
    const pending = useContentfulHomeCommerce(component);
    const unavailable = (
        <p role="status" className="section-container py-8 text-center text-muted-foreground">
            {failureMessage || "This section is temporarily unavailable."}
        </p>
    );
    return (
        <section {...inspector("title")}>
            {pending ? (
                <Suspense
                    fallback={
                        <section className="section-container py-12" aria-busy="true">
                            <h2>{title}</h2>
                            <div className="h-64 bg-muted animate-pulse" />
                        </section>
                    }
                >
                    <Await resolve={pending} errorElement={unavailable}>
                        {(result: ContentfulHomeCommerceResult) =>
                            result.kind === "categories" ? (
                                <PopularCategories data={result.data} title={title} subtitle={subtitle} />
                            ) : (
                                unavailable
                            )
                        }
                    </Await>
                </Suspense>
            ) : (
                unavailable
            )}
        </section>
    );
}
