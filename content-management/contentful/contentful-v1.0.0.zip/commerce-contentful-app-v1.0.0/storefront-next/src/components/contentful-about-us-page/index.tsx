/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Link } from "@/components/link";
import {
    Breadcrumb,
    BreadcrumbList,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbPage,
    BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import Contact from "@/components/contact";
import { Typography } from "@/components/typography";
import { Region, type ComponentType } from "@/components/region";
import { Component } from "@/lib/decorators/component";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import { useContentfulInspector } from "@/extensions/contentful/lib/content-preview";

@Component("aboutUsPage", { name: "Contentful About Us demo page", group: "Contentful" })
@RegionDefinition([
    { id: "headline", name: "Before contact" },
    { id: "additionalinformation", name: "After contact" },
])
// oxlint-disable-next-line react/only-export-components -- Page Designer metadata is co-exported with its React component
export class ContentfulAboutUsPageMetadata {}

/**
 * Mirror the native fallback layout with mapped regions around the existing Contact view.
 * Contact stays code-owned, retaining its translations, validation and submission behavior;
 * neither the Contentful graph nor the provisioning tool configures a new form backend.
 */
export default function ContentfulAboutUsPage({
    title,
    homeLabel,
    breadcrumbLabel,
    component,
}: {
    title?: string;
    homeLabel?: string;
    breadcrumbLabel?: string;
    component?: ComponentType;
}) {
    const inspector = useContentfulInspector(component);
    return (
        <div className="pb-8">
            <div className="max-w-screen-2xl mx-auto px-4 pb-6">
                <Breadcrumb className="mb-2.5">
                    <BreadcrumbList>
                        <BreadcrumbItem>
                            <BreadcrumbLink asChild>
                                <Link to="/" {...inspector("homeLabel")}>
                                    {homeLabel}
                                </Link>
                            </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator />
                        <BreadcrumbItem>
                            <BreadcrumbPage {...inspector("breadcrumbLabel")}>{breadcrumbLabel}</BreadcrumbPage>
                        </BreadcrumbItem>
                    </BreadcrumbList>
                </Breadcrumb>
                <Typography variant="h2" {...inspector("title")}>
                    {title}
                </Typography>
            </div>
            <div className="max-w-screen-2xl mx-auto px-4 py-6 space-y-6">
                {component && <Region component={component} regionId="headline" />}
            </div>
            <div className="md:px-8 px-4 py-12 bg-secondary">
                <div className="max-w-screen-2xl mx-auto">
                    <Contact />
                </div>
            </div>
            <div className="max-w-screen-2xl mx-auto px-4 py-6 space-y-6">
                {component && <Region component={component} regionId="additionalinformation" />}
            </div>
        </div>
    );
}
