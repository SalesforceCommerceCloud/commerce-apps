/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { ContentfulSourceContext } from "@/extensions/contentful/lib/content-preview";
import type { ReactElement } from "react";
import { EmbeddedSubtreeProvider } from "@salesforce/storefront-next-runtime/design/react/core";
import { createContentfulComponentTree } from "@/extensions/contentful/lib/component-tree";
import { Component } from "@/lib/decorators/component";
import { AttributeDefinition } from "@/lib/decorators/attribute-definition";
import { RegionDefinition } from "@/lib/decorators/region-definition";
import type { ContentfulRenderData } from "@/extensions/contentful/lib/props";
import { contentfulRendererRegistry } from "@/extensions/contentful/lib/renderer-registry";

import { createLogger } from "@/lib/logger";

const logger = createLogger();

@Component("contentfulContent", {
    name: "Contentful Content",
    description: "Select Contentful content using the model mappings configured in the storefront.",
    group: "Content",
})
@RegionDefinition([])
export class ContentfulContentMetadata {
    @AttributeDefinition({
        name: "Content item",
        description: "Choose a published entry from the connected Contentful space.",
        type: "custom",
        required: true,
        editorDefinition: { type: "contentful.entryPicker" },
    })
    // Page Designer custom attributes require a plain object, even for a single ID.
    // The server loader unwraps this boundary value; the shared fetch API accepts a string.
    // https://developer.salesforce.com/docs/commerce/sfra/guide/b2c-dev-for-page-designer.html
    contentfulEntry!: { entryId: string };
}

/**
 * Renders server-resolved data from Page Designer or a route loader. An entry ID
 * prop alone cannot trigger loading. Routes call loadContentfulEntry server-side
 * and supply a unique component.id to scope any embedded region identities.
 */
export default function ContentfulContent({
    data,
    component,
    regionId,
    className,
}: {
    data?: ContentfulRenderData | null;
    component?: { id?: string };
    regionId?: string;
    className?: string;
}): ReactElement | null {
    if (!data) {
        return null;
    } // The request-context server loader diagnoses empty data.
    if (data.renderer === "Content.contentfulContent" || !contentfulRendererRegistry.has(data.renderer)) {
        logger.error("contentful.render.suppressed", {
            renderer: data.renderer,
            reason: data.renderer === "Content.contentfulContent" ? "recursive_renderer" : "unregistered",
        });
        return null;
    }
    if (!contentfulRendererRegistry.hasConcreteComponent(data.renderer)) {
        const error = contentfulRendererRegistry.getRegistrationError(data.renderer);
        if (error) {
            logger.error("contentful.render.registration_failed", { renderer: data.renderer });
            throw error;
        }
        logger.debug("contentful.render.registration_pending", { renderer: data.renderer });
        // React Suspense waits for the configured renderer on SSR and in the browser.
        throw contentfulRendererRegistry.loadAndRegister(data.renderer);
    }
    // A concrete registration returns its component synchronously through our identity adapter.
    const Renderer = contentfulRendererRegistry.getComponent(data.renderer)!;
    logger.debug("contentful.render.ready", { renderer: data.renderer });
    const renderedComponent = data.regions
        ? createContentfulComponentTree(data, component?.id ?? "contentful")
        : component;
    const content = (
        <Renderer
            {...data.props}
            component={renderedComponent}
            regionId={regionId}
            className={className ?? data.props.className}
        />
    );
    const rendered = data.regions ? <EmbeddedSubtreeProvider embedded>{content}</EmbeddedSubtreeProvider> : content;
    return data.source ? (
        <ContentfulSourceContext.Provider value={data.source}>{rendered}</ContentfulSourceContext.Provider>
    ) : (
        rendered
    );
}

// SFNext discovers this named export and invokes it while collecting component data.
export { loadContentfulContent as loader } from "./loaders.server";
