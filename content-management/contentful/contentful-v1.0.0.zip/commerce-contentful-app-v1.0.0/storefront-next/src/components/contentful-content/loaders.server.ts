/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { LoaderFunctionArgs } from "react-router";
import { getLogger } from "@/lib/logger.server";
import { loadContentfulEntry } from "@/extensions/contentful/lib/load-entry.server";

/**
 * Page Designer boundary only: custom attributes persist a plain { entryId }
 * object (or null when cleared). Route loaders use loadContentfulEntry with a
 * string ID directly; do not carry this editor storage shape into that API.
 */
export async function loadContentfulContent(args: {
    componentData: unknown;
    context: LoaderFunctionArgs["context"];
    request?: Request;
}) {
    const component = args.componentData as { data?: { contentfulEntry?: unknown } };
    const selection = component?.data?.contentfulEntry;
    if (selection == null) {
        getLogger(args.context).debug("contentful.selection.empty", {});
        return null;
    }
    if (
        typeof selection !== "object" ||
        Array.isArray(selection) ||
        !Object.prototype.hasOwnProperty.call(selection, "entryId") ||
        typeof (selection as { entryId?: unknown }).entryId !== "string"
    ) {
        getLogger(args.context).warn("contentful.selection.invalid", {});
        return null;
    }
    return loadContentfulEntry({
        entryId: (selection as { entryId: string }).entryId,
        context: args.context,
        request: args.request,
    });
}
