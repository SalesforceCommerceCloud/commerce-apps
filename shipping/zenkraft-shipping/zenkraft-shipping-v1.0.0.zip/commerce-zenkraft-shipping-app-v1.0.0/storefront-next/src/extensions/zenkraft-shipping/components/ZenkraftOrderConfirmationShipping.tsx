import { useAsyncValue } from 'react-router';
import { UITarget } from '@/targets/ui-target';
import AddressDisplay from '@/components/address-display';
import { Card, CardContent } from '@/components/ui/card';
import { useTranslation } from 'react-i18next';
import type { ShopperOrders } from '@/scapi';

type OrderData = {
    order: ShopperOrders.schemas['Order'];
};

type ShipmentWithZenkraft = ShopperOrders.schemas['Order']['shipments'] extends Array<infer S> | undefined
    ? S & { c_zenkraftEstimatedArrivalTime?: string }
    : never;

export default function ZenkraftOrderConfirmationShipping() {
    const { t } = useTranslation('checkout');
    const data = useAsyncValue() as OrderData;
    const shipments = (data?.order?.shipments ?? []) as ShipmentWithZenkraft[];

    return (
        <>
            {shipments.map((shipment) => {
                const shippingAddress = shipment.shippingAddress;
                const shippingMethodName =
                    shipment.shippingMethod?.name || t('confirmation.fields.defaultShippingMethod');
                const estimatedDeliveryTime =
                    shipment.c_zenkraftEstimatedArrivalTime ||
                    shipment.shippingMethod?.description ||
                    t('confirmation.summaryLabels.estimatedDatePlaceholder');

                return (
                    <Card key={shipment.shipmentId} className="border border-border/70">
                        <CardContent className="grid gap-6 p-6 md:grid-cols-3">
                            <div>
                                <p className="text-base font-semibold tracking-wide text-foreground">
                                    {t('confirmation.summaryLabels.arriving')}
                                </p>
                                <p className="mt-3 text-sm font-medium text-muted-foreground">
                                    {estimatedDeliveryTime}
                                </p>
                            </div>
                            <div>
                                <p className="text-base font-semibold tracking-wide text-foreground">
                                    {t('confirmation.summaryLabels.shippingAddress')}
                                </p>
                                <div className="mt-3 space-y-2">
                                    {shippingAddress ? (
                                        <AddressDisplay address={shippingAddress} />
                                    ) : (
                                        <p className="text-sm font-medium text-muted-foreground">
                                            {t('confirmation.summaryLabels.noAddress')}
                                        </p>
                                    )}
                                </div>
                            </div>
                            <div>
                                <p className="text-base font-semibold tracking-wide text-foreground">
                                    {t('confirmation.summaryLabels.shippingMethod')}
                                </p>
                                <p className="mt-3 text-sm font-medium text-muted-foreground">
                                    {shippingMethodName}
                                </p>
                            </div>
                            <UITarget targetId="sfcc.orderConfirmation.shipping.tracking" />
                        </CardContent>
                    </Card>
                );
            })}
        </>
    );
}
