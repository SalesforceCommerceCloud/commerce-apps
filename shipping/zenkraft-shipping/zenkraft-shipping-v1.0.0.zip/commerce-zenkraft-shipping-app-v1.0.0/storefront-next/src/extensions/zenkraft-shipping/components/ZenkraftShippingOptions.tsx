import { use, type FormEvent, useEffect, useMemo, useRef } from 'react';
import { useFetcher, useLoaderData } from 'react-router';
import { ToggleCard, ToggleCardEdit, ToggleCardSummary } from '@/components/toggle-card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useBasket, useBasketUpdater } from '@/providers/basket';
import { getDefaultShippingMethod } from '@/lib/customer/profile-utils';
import { useCustomerProfile } from '@/hooks/checkout/use-customer-profile';
import { useCheckoutContext } from '@/hooks/use-checkout';
import { CHECKOUT_ACTION_INTENTS } from '@/components/checkout/utils/checkout-context-types';
import type { CheckoutActionData } from '@/components/checkout/types';
import type { ShopperBasketsV2 } from '@/scapi';
import { getCheckoutDisplayError } from '@/components/checkout/utils/checkout-display-error';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { formatCurrency } from '@/lib/currency';
import { useTranslation } from 'react-i18next';
import ZenkraftShippingMultiOptions from './ZenkraftShippingMultiOptions';


interface ShippingMethod {
    id: string;
    name: string;
    c_estimatedArrivalTime?: string;
    price: number;
}

interface LoaderData {
    shippingMethodsMap: Promise<Record<string, ShopperBasketsV2.schemas['ShippingMethodResult']>>;
}

export default function ZenkraftShippingOptions() {
    const cart = useBasket();
    const updateBasket = useBasketUpdater();
    const customerProfile = useCustomerProfile();
    const { currency } = useSite();
    const { t, i18n } = useTranslation('checkout');
    const { step, editingStep, goToStep, exitEditMode, STEPS, shipmentDistribution } = useCheckoutContext();

    const isEditing = step === STEPS.SHIPPING_OPTIONS || editingStep === STEPS.SHIPPING_OPTIONS;
    const isMultiShip = shipmentDistribution.hasMultipleDeliveryAddresses;

    const shippingOptionsFetcher = useFetcher<CheckoutActionData>({ key: 'shipping-options-form' });
    const shippingAddressFetcher = useFetcher<CheckoutActionData>({ key: 'shipping-address-form' });

    const isLoading = shippingOptionsFetcher.state !== 'idle';
    const actionData = shippingOptionsFetcher.data;

    // Get shipping methods: prefer action response over loader data.
    // The loader returns shippingMethodsMap as a Promise (streaming). use() unwraps it;
    // the component is inside a <Suspense> boundary so suspension is safe.
    const loaderData = useLoaderData() as LoaderData;
    const actionShippingMethodsMap = shippingAddressFetcher.data?.data?.shippingMethodsMap as
        | Record<string, ShopperBasketsV2.schemas['ShippingMethodResult']>
        | undefined;
    const resolvedLoaderShippingMethodsMap = loaderData?.shippingMethodsMap
        ? use(loaderData.shippingMethodsMap)
        : {};
    const shippingMethodsMap =
        actionShippingMethodsMap && Object.keys(actionShippingMethodsMap).length > 0
            ? actionShippingMethodsMap
            : resolvedLoaderShippingMethodsMap;

    const defaultShipmentId = cart?.shipments?.[0]?.shipmentId ?? 'me';
    const shippingMethods = shippingMethodsMap?.[defaultShipmentId];

    const availableShippingMethods: ShippingMethod[] = useMemo(
        () =>
            shippingMethods?.applicableShippingMethods
                ?.filter(
                    (method): method is NonNullable<typeof method> & { id: string; name: string; price: number } =>
                        Boolean(method.id && method.name && typeof method.price === 'number' && !Number.isNaN(method.price))
                )
                .map((method) => ({
                    id: method.id,
                    name: method.name,
                    c_estimatedArrivalTime: method.c_estimatedArrivalTime as string | undefined,
                    price: method.price,
                })) || [],
        [shippingMethods?.applicableShippingMethods]
    );

    const selectedMethod = cart?.shipments?.[0]?.shippingMethod;
    const summaryMethod: ShippingMethod | undefined = useMemo(() => {
        if (!selectedMethod?.id) return undefined;
        return availableShippingMethods.find((m) => m.id === selectedMethod.id);
    }, [selectedMethod, availableShippingMethods]);

    const isGuest = customerProfile !== undefined && !customerProfile?.customer?.customerId;
    const hideChangeForGuest = isGuest && !selectedMethod;
    const isUpcomingStep = !isEditing && !selectedMethod;
    const hasShippingAddress = Boolean(cart?.shipments?.[0]?.shippingAddress?.postalCode);

    const defaultShippingMethodId = getDefaultShippingMethod(
        availableShippingMethods,
        selectedMethod,
        shippingMethods?.defaultShippingMethodId
    );

    const shippingOptionsError = getCheckoutDisplayError(actionData, 'shippingOptions');

    // Lifecycle: update basket and exit edit mode after a successful submit
    const didSubmitRef = useRef(false);

    useEffect(() => {
        if (!didSubmitRef.current) return;
        if (shippingOptionsFetcher.state !== 'idle' || !shippingOptionsFetcher.data?.success || !shippingOptionsFetcher.data.basket) return;
        didSubmitRef.current = false;
        updateBasket(shippingOptionsFetcher.data.basket);
        exitEditMode();
    }, [shippingOptionsFetcher.state, shippingOptionsFetcher.data, updateBasket, exitEditMode]);

    // Auto-select default method when entering editing step without a selection
    const hasAutoSubmitted = useRef(false);
    const fetcherSubmitRef = useRef(shippingOptionsFetcher.submit);
    useEffect(() => {
        fetcherSubmitRef.current = shippingOptionsFetcher.submit;
    });

    useEffect(() => {
        if (isMultiShip) return;
        if (
            isEditing &&
            !selectedMethod?.id &&
            customerProfile &&
            availableShippingMethods.length > 0 &&
            !hasAutoSubmitted.current &&
            !isLoading
        ) {
            hasAutoSubmitted.current = true;
            const isDefaultValid =
                defaultShippingMethodId &&
                availableShippingMethods.some((m) => m.id === defaultShippingMethodId);
            const methodIdToSubmit = isDefaultValid ? defaultShippingMethodId : availableShippingMethods[0]?.id;
            if (methodIdToSubmit) {
                const formData = new FormData();
                formData.append('shippingMethodId', methodIdToSubmit);
                formData.append('intent', CHECKOUT_ACTION_INTENTS.SHIPPING_OPTIONS);
                didSubmitRef.current = true;
                fetcherSubmitRef.current(formData, { method: 'post' });
            }
        }
        if (!isEditing) {
            hasAutoSubmitted.current = false;
        }
    }, [isMultiShip, isEditing, selectedMethod?.id, defaultShippingMethodId, isLoading, customerProfile, availableShippingMethods]);

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        formData.append('intent', CHECKOUT_ACTION_INTENTS.SHIPPING_OPTIONS);
        didSubmitRef.current = true;
        shippingOptionsFetcher.submit(formData, { method: 'post' });
    };

    if (isMultiShip) {
        return (
            <ZenkraftShippingMultiOptions
                onSubmit={(formData) => {
                    didSubmitRef.current = true;
                    shippingOptionsFetcher.submit(formData, { method: 'post' });
                }}
                isLoading={isLoading}
                actionData={actionData}
                shipments={shipmentDistribution.deliveryShipments}
                shippingMethodsMap={shippingMethodsMap}
                isCompleted={step > STEPS.SHIPPING_OPTIONS}
                isEditing={isEditing}
                onEdit={() => goToStep(STEPS.SHIPPING_OPTIONS)}
            />
        );
    }

    const stepTitle = (
        <span className="text-2xl font-bold tracking-tight text-card-foreground">
            {t('shippingOptions.title')}
        </span>
    );

    return (
        <ToggleCard
            id="shipping-options"
            title={stepTitle}
            editing={isEditing}
            disabled={false}
            onEdit={() => goToStep(STEPS.SHIPPING_OPTIONS)}
            editLabel={t('common.edit')}
            disableEdit={hideChangeForGuest || isUpcomingStep}
            showHeaderSeparator
            isLoading={isLoading}>
            <ToggleCardEdit>
                <form method="post" className="flex flex-col gap-4 pt-2 pb-2" onSubmit={handleSubmit}>
                    {shippingOptionsError && (
                        <p className="text-sm text-destructive">{shippingOptionsError}</p>
                    )}
                    <RadioGroup
                        name="shippingMethodId"
                        defaultValue={selectedMethod?.id || defaultShippingMethodId || ''}
                        required
                        aria-label={t('shippingOptions.title')}
                        className="flex flex-col gap-4">
                        {availableShippingMethods.map((method) => (
                            <label
                                key={method.id}
                                htmlFor={method.id}
                                className="group flex cursor-pointer flex-col gap-1 rounded-none border border-border-subtle p-4 transition-all duration-200 has-[[data-state=checked]]:border-foreground">
                                <div className="flex items-center gap-2">
                                    <RadioGroupItem
                                        value={method.id}
                                        id={method.id}
                                        className="shrink-0"
                                        autoFocus={isEditing && availableShippingMethods.indexOf(method) === 0}
                                    />
                                    <span className="flex-1 text-sm font-medium leading-none">
                                        {method.name}
                                    </span>
                                    <span className="shrink-0 text-sm font-semibold leading-none">
                                        {method.price === 0
                                            ? t('shippingOptions.free')
                                            : formatCurrency(method.price, i18n.language, currency)}
                                    </span>
                                </div>
                                {method.c_estimatedArrivalTime && (
                                    <span className="pl-6 text-sm text-muted-foreground">
                                        {t('shippingOptions.arrives', {
                                            estimatedArrivalTime: method.c_estimatedArrivalTime,
                                        })}
                                    </span>
                                )}
                            </label>
                        ))}
                    </RadioGroup>

                    <div
                        data-checkout-mobile-bar
                        className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-background px-6 py-4 lg:static lg:inset-auto lg:z-auto lg:w-full lg:border-0 lg:bg-transparent lg:p-0 lg:pt-2">
                        <Button
                            type="submit"
                            disabled={isLoading || availableShippingMethods.length === 0}
                            className="w-full">
                            {isLoading ? t('shippingOptions.saving') : t('shippingOptions.continue')}
                        </Button>
                    </div>
                </form>
            </ToggleCardEdit>

            <ToggleCardSummary>
                {summaryMethod || selectedMethod ? (
                    <div className="space-y-1.5">
                        {summaryMethod?.c_estimatedArrivalTime && (
                            <p className="text-sm font-normal leading-5 text-foreground">
                                {t('shippingOptions.arrives', {
                                    estimatedArrivalTime: summaryMethod.c_estimatedArrivalTime,
                                })}
                            </p>
                        )}
                        <p className="text-sm font-normal leading-5 text-foreground">
                            {hasShippingAddress
                                ? t('shippingOptions.priceAndMethod', {
                                    price: (() => {
                                        const price = summaryMethod?.price ?? selectedMethod?.price ?? 0;
                                        return price === 0
                                            ? t('shippingOptions.free')
                                            : formatCurrency(price, i18n.language, currency);
                                    })(),
                                    methodName: summaryMethod?.name || selectedMethod?.name || '',
                                  })
                                : summaryMethod?.name || selectedMethod?.name || ''
                            }
                        </p>
                    </div>
                ) : (
                    <p className="text-sm text-muted-foreground">
                        {isGuest ? t('shippingOptions.completePreviousSteps') : t('shippingOptions.enterAddressFirst')}
                    </p>
                )}
            </ToggleCardSummary>
        </ToggleCard>
    );
}
