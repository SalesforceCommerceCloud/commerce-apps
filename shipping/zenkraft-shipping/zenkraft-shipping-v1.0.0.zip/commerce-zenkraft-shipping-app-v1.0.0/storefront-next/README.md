# Zenkraft Shipping — Extension Internals

This README ships inside the storefront-next extension at
`src/extensions/zenkraft-shipping/`. It documents the internal structure for
developers extending or debugging the extension.

For merchant install/configuration docs, see the root `README.md` of the
CAP (one directory up in the unzipped package).

## Layout

```
components/
  ZenkraftShippingOptions.tsx       replaces the checkout shipping options step
  ZenkraftShippingMultiOptions.tsx  multi-shipment variant (rendered by above)
  ZenkraftOrderConfirmationShipping.tsx  per-shipment card on order confirmation
target-config.json                  component → UITarget registration
index.ts                            public exports
```

## Targets

| Target | Component |
|---|---|
| `sfcc.checkout.shippingOptions` | `ZenkraftShippingOptions` |
| `sfcc.orderConfirmation.shipping.details` | `ZenkraftOrderConfirmationShipping` |

## Architecture

**The extension makes no direct Zenkraft API calls.** All communication with the
Zenkraft rate API happens server-side in the `int_zenkraft_sfnext` backend
cartridge. The frontend reads custom attributes written by the cartridge:

- `c_estimatedArrivalTime` — set per shipping method by the `sfcc.app.shipping.quote`
  hook; consumed by `ZenkraftShippingOptions` and `ZenkraftShippingMultiOptions`.
- `c_zenkraftEstimatedArrivalTime` — set on the shipment by the
  `sfcc.app.shipping.calculate` hook; consumed by `ZenkraftOrderConfirmationShipping`
  via the SCAPI order response.

## Component Notes

**`ZenkraftShippingOptions`** replaces (not augments) the shipping options step.
It handles auto-selection of the default method, fetcher-based form submission,
and basket update on success. For multi-shipment baskets it delegates entirely
to `ZenkraftShippingMultiOptions`, which renders a separate method selector per
shipment.

**`ZenkraftOrderConfirmationShipping`** calls `useAsyncValue()` and must be
rendered inside an `Await` boundary in the host route. It renders one card per
shipment; if `c_zenkraftEstimatedArrivalTime` is absent it falls back to
`shippingMethod.description`, then a placeholder translation key.

## Translations

The extension does not bundle its own locale files. It reads from two namespaces
provided by the host storefront:

- `checkout` — used by both shipping options components for shared keys
  (`shippingOptions.title`, `shippingOptions.free`, `shippingOptions.arrives`, etc.)
  and by the order confirmation component (`confirmation.summaryLabels.*`).
- `extMultiship` — used by `ZenkraftShippingMultiOptions` for multi-shipment-specific
  labels (`checkout.shippingMultiOptionsTitle`, `checkout.shipmentNumber`, etc.).
