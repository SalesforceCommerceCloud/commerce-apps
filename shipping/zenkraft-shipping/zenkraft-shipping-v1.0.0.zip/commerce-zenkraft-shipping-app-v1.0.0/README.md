# Zenkraft Shipping

Shipping rate calculation and estimated delivery dates powered by Zenkraft.

## Overview

This commerce app integrates the Zenkraft rate API with Storefront Next storefronts. The backend cartridge (`int_zenkraft_sfnext`) fetches real-time rates and estimated delivery dates at checkout and persists them to session and shipment custom attributes. The Storefront Next extension replaces the standard shipping options step at checkout with a component that displays those enriched shipping methods.

## Architecture

```
GET /shipping-methods (checkout)
  → sfcc.app.shipping.quote hook (int_zenkraft_sfnext/cartridge/scripts/hooks/shippingOptions.js)
      → zenkraftShippingHelper.getShippingData()
          → zenkraftService.call('http.zenkraft.rate') → api.zenkraft.com (zkkey API key header)
      → overrides method.price with Zenkraft rate + markup when API returns a cost
      → if enableZenkraftEstimatedDeliveryDates: enriches each ShippingMethod with c_estimatedArrivalTime, c_estimated_date

dw.order.calculateShipping (basket recalculation)
  → sfcc.app.shipping.calculate hook (int_zenkraft_sfnext/cartridge/scripts/hooks/calculateShipping.js)
      → zenkraftShippingHelper.buildShippingRateRequest()
          → if boxing algorithm enabled: zenkraftService.call('http.zenkraft.pack') for package dimensions
      → zenkraftShippingHelper.callZenkraftAPI() with djb2 request-hash deduplication
          → zenkraftService.call('http.zenkraft.rate') for real-time rates
      → rates stored in session.privacy.zenkraftCosts (keyed by shipment UUID)
      → EDD stored in session.privacy.zenkraftEDD (keyed by shipment UUID)
      → zenkraftShippingHelper.calculateShippingCost() applies rate + markup to shipping line item
      → falls back to ShippingMgr.applyShippingCost() when no Zenkraft rates in session

Storefront Next checkout
  → ZenkraftShippingOptions component at sfcc.checkout.shippingOptions
      → renders shipping method radio group with c_estimatedArrivalTime from hook response
      → handles selection, auto-submit, basket update
      → delegates to ZenkraftShippingMultiOptions for multi-shipment baskets

Storefront Next order confirmation
  → ZenkraftOrderConfirmationShipping component at sfcc.orderConfirmation.shipping.details
      → displays estimated arrival time, shipping address, and shipping method per shipment
      → reads c_zenkraftEstimatedArrivalTime from order shipment custom attributes; falls back to shippingMethod.description, then a placeholder
```

## Features

- Real-time Zenkraft rate API calls via `http.zenkraft.rate` SFCC service
- Request deduplication: skips the API call when the basket state has not changed (djb2 hash)
- Estimated delivery dates (EDD) with configurable cutoff time and company-wide lead time
- Per-product and per-category lead time override
- Rate markup per shipping method (fixed amount or percentage)
- Optional boxing algorithm using package profiles (custom objects)
- Multiple shipping accounts
- Native methods fallback if Zenkraft returns no results
- Production/test mode toggle
- Storefront Next checkout shipping options component

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance
- Zenkraft API key
- Storefront Next storefront

## Installation

1. Download the app from the Commerce App Registry
2. Import the app in Business Manager
3. Add `int_zenkraft_sfnext` to your site's cartridge path under Administration > Site Development > Manage Sites
4. Complete the post-installation checklist below

## Configuration

### Services

The app uses two SFCC services defined in `impex/install/services.xml`:

| Service ID | Purpose |
|---|---|
| `http.zenkraft.rate` | Fetches real-time shipping rates and estimated delivery dates |
| `http.zenkraft.pack` | Calls the Zenkraft boxing algorithm to compute package dimensions (only when `enableZenkraftBoxingAlgorithm` is on and all products have dimension attributes) |

The Zenkraft API endpoint is configured on each service definition. Authentication uses the `zenkraftMasterAPIKey` site preference (passed as the `zkkey` request header) — do not put the API key in Storefront Next `PUBLIC__` environment variables.

### Site Preferences

Import `impex/install/sites/SITEID/preferences.xml` (replacing `SITEID` with your site ID) to create the preference group entries with default values. All preferences are configured in Business Manager under Merchant Tools > Site Preferences > Custom Preferences.

Preferences are grouped into three sections:

**Zenkraft General**

| Preference | Type | Description |
|---|---|---|
| `enableZenkraftShippingRates` | Boolean | Master toggle — enables Zenkraft rate API calls and replaces BM-configured rates |
| `enableZenkraftBoxingAlgorithm` | Boolean | Use package profiles to determine package dimensions |
| `zenkraftNativeMethodsFallback` | Boolean | Fall back to native SFCC methods if Zenkraft returns none |
| `zenkraftProdMode` | Boolean | Production mode — leave off for sandbox |
| `zenkraftDebugLog` | Boolean | Enable debug logs in the Zenkraft API admin |
| `zenkraftMasterAPIKey` | Password | Zenkraft API key (used as `zkkey` header) |
| `zenkraftCarrier` | String | Default carrier ID (e.g. `fedex`, `dhl`) |
| `zenkraftShippingAccount` | String | Shipping account ID (comma-separated for multiple) |
| `useZenkraftMultipleShippingAccounts` | Boolean | Send multiple account IDs in rate requests |
| `zenkraftShippingService` | String | Service type for rate requests (e.g. `fedex_ground`) |
| `zenkraftRateServiceType` | String | Optional single service type filter |
| `zenkraftRateSpecialServices` | String | Comma-separated special service values |
| `zenkraftPackagingType` | String | Packaging type per Zenkraft API docs (default `your_packaging`) |
| `zenkraftCurrencyCode` | String | Currency code for rate requests (default `USD`) |
| `zenkraftDimensionUnits` | Enum | `IN` (default) or `CM` |
| `zenkraftWeightUnits` | Enum | `LB` (default) or `KG` |
| `zenkraftDefaultProductWeight` | String | Fallback weight when a product has no `dimWeight` attribute |
| `zenkraftCustomAuth` | Enum | Authentication mode: `APIKEY` (default) or `OCAPI` |
| `zenkraftSenderStreet` | String | Sender address — street |
| `zenkraftSenderCity` | String | Sender address — city |
| `zenkraftSenderStateCode` | String | Sender address — state code |
| `zenkraftSenderPostalCode` | String | Sender address — postal code |
| `zenkraftSenderCountryCode` | String | Sender address — country code |
| `zenkraftSenderCompany` | String | Sender company |
| `zenkraftSenderName` | String | Sender name |
| `zenkraftSenderPhone` | String | Sender phone |
| `zenkraftSenderEmail` | String | Sender email |

**Zenkraft Estimated Delivery**

| Preference | Type | Description |
|---|---|---|
| `enableZenkraftEstimatedDeliveryDates` | Boolean | Display EDD on checkout shipping options |
| `zenkraftEDDCutoffTime` | Datetime | After this time, one day is added to delivery estimates |
| `zenkraftCompanyWideLeadTime` | Integer | Default lead time in days before delivery calculation starts |
| `zenkraftPackageConfig` | Boolean | Consolidate all items into a single package for rate requests |

**Zenkraft Advanced Configuration**

| Preference | Type | Description |
|---|---|---|
| `zenkraftAdvancedJSON` | Boolean | Use the advanced JSON object for rate request settings |
| `zenkraftAdvancedJSONObject` | Text | Advanced JSON configuration for rate requests |

### Shipping Methods

Each SFCC shipping method that should use Zenkraft requires these custom attributes set under Merchant Tools > Ordering > Shipping Methods:

| Attribute | Description |
|---|---|
| `zenkraftID` | Zenkraft service type identifier that maps the method to a Zenkraft rate (e.g. `FEDEX_GROUND`) |
| `zenkraftCarrier` | Carrier ID for this method, overrides the site-wide Carrier ID preference (e.g. `fedex`, `dhl`) |
| `zenkraftShippingMethodAccountID` | Per-method shipping account ID override |
| `zenkraftRateMarkupType` | `Amount` or `Percent` markup on Zenkraft rate |
| `zenkraftRateMarkup` | Markup value to add to the Zenkraft rate |

### Product and Category Attributes

Optional per-product and per-category attributes used for EDD lead time:

| Object | Attribute | Description |
|---|---|---|
| Product | `zenkraftLeadTime` | Days before delivery calculation starts for this product |
| Category | `zenkraftLeadTime` | Lead time override for all products in this category |

Product dimension attributes are read from **pre-existing** product catalog custom attributes — they are not created by this app's impex. The attributes used depend on the code path:

**Non-boxing rate request** (default, one package per line item or single consolidated package):

| Attribute | Maps to rate API field |
|---|---|
| `dimWeight` | `weight` |
| `length` | `length` |
| `dimWidth` | `width` |
| `dimHeight` | `height` |

**Boxing algorithm** (`enableZenkraftBoxingAlgorithm` on, sent to `http.zenkraft.pack`):

| Attribute | Maps to pack API field |
|---|---|
| `dimDepth` | `depth` |
| `dimHeight` | `length` |
| `dimWidth` | `width` |
| `dimWeight` | `weight` |

Note: `dimHeight` maps to `height` in the rate API but to `length` in the pack API. This convention matches the legacy `int_zenkraft_sfra` cartridge. All four boxing attributes (`dimDepth`, `dimHeight`, `dimWidth`, `dimWeight`) must be set on a product for the boxing algorithm to activate for that product; if any are missing the product falls back to the non-boxing path.

### Package Profile Attributes

Package profiles are custom objects used by the boxing algorithm (`enableZenkraftBoxingAlgorithm`) to compute package dimensions before calling the pack API. Create them in Business Manager under Merchant Tools > Custom Objects > Custom Object Editor > `zenkraftPackageProfile`.

| Attribute | Type | Required | Description |
|---|---|---|---|
| `id` | String | Yes | Unique profile identifier (key) |
| `packageProfileDescription` | String | No | Human-readable description |
| `carrier` | String | No | Carrier ID this profile applies to |
| `packagingType` | String | No | Packaging type per Zenkraft API docs |
| `length` | Double | No | Outer box length |
| `height` | Double | No | Outer box height |
| `width` | Double | No | Outer box width |
| `emptyBoxWeight` | Double | No | Weight of the empty box (added to product weight total) |
| `innerLength` | Double | Yes | Inner usable length for packing |
| `innerHeight` | Double | Yes | Inner usable height for packing |
| `innerWidth` | Double | Yes | Inner usable width for packing |
| `maxWeight` | Double | No | Maximum total weight this box can hold |

Dimension units follow the `zenkraftDimensionUnits` site preference (`IN` or `CM`); weight units follow `zenkraftWeightUnits` (`LB` or `KG`).

### Shipment Custom Attributes

The following Shipment custom attributes are written by the cartridge and available for order management integrations:

| Attribute | Type | Description |
|---|---|---|
| `zenkraftCarrier` | String | Carrier ID from the selected shipping method |
| `zenkraftShippingAccount` | String | Shipping account used for the shipment |
| `zenkraftEstimatedArrivalTime` | String | Estimated arrival time, stored at basket calculate time and carried to the order for display on the confirmation page |

## Storefront Next Extension

The extension provides two components registered in `storefront-next/src/extensions/zenkraft-shipping/target-config.json`:

| Target | Component | Description |
|---|---|---|
| `sfcc.checkout.shippingOptions` | `ZenkraftShippingOptions` | Full shipping options selector at checkout |
| `sfcc.orderConfirmation.shipping.details` | `ZenkraftOrderConfirmationShipping` | Shipping summary on the order confirmation page |

`ZenkraftShippingOptions` renders a radio group of available shipping methods, displays `c_estimatedArrivalTime` under each method when present, auto-selects the default method on step entry, handles form submission via fetcher, and updates the basket on success. For multi-shipment baskets it delegates to `ZenkraftShippingMultiOptions`, which renders a separate method selector per shipment.

`ZenkraftOrderConfirmationShipping` displays one card per shipment showing the estimated arrival time (from `c_zenkraftEstimatedArrivalTime` on the order shipment), shipping address, and shipping method name.

## Testing

```bash
cd cartridges/site_cartridges/int_zenkraft_sfnext
npm install
npm test
```

Unit tests for the helper are in `test/unit/zenkraftShippingHelper.test.js`.

## Post-Installation Checklist

- [ ] Configure your Zenkraft account for calculating shipping rates and estimated delivery dates at https://zenkraft.com/contact
- [ ] Verify Zenkraft service credentials in Administration > Operations > Services
- [ ] Configure site preferences in Merchant Tools > Site Preferences > Custom Preferences > Zenkraft
- [ ] Configure shipping methods: set `zenkraftID` on each Zenkraft-enabled method under Merchant Tools > Ordering > Shipping Methods; optionally set `zenkraftCarrier` to override the site-wide carrier per method
- [ ] If using the boxing algorithm: create package profiles in Merchant Tools > Custom Objects > Custom Object Editor > `zenkraftPackageProfile`
- [ ] Enable `enableZenkraftShippingRates` to activate Zenkraft rate API calls at checkout
- [ ] Test on a sandbox site before enabling `zenkraftProdMode`

## Uninstall Notes

The uninstall IMPEX (`impex/uninstall/services.xml`) removes the two Zenkraft services (`http.zenkraft.rate`, `http.zenkraft.pack`), their credentials, and their service profile.

The following are **not** removed automatically because doing so would irreversibly delete any merchant-configured values:

- **Custom attributes** on `SitePreferences`, `Shipment`, `ShippingMethod`, `Product`, and `Category` — defined in `impex/install/meta/system-objecttype-extensions.xml`
- **`zenkraftPackageProfile` custom object type** — defined in `impex/install/meta/custom-objecttype-definitions.xml`

To remove these manually after uninstalling the app:

1. Delete all `zenkraftPackageProfile` custom object instances in Merchant Tools > Custom Objects > Custom Object Editor > `zenkraftPackageProfile`
2. Remove the `zenkraftPackageProfile` custom object type definition via Administration > Site Development > Import & Export using a metadata XML with `mode="delete"` on the `custom-type` element
3. Remove the Zenkraft custom attribute groups from `SitePreferences`, `Shipment`, `ShippingMethod`, `Product`, and `Category` via Administration > Site Development > Import & Export using a metadata XML with `mode="delete"` on each `attribute-definition` element

## Known Limitations

- **Storefront Next only.** The storefront extension targets `sfcc.checkout.shippingOptions` and `sfcc.orderConfirmation.shipping.details`, which are Storefront Next extension points. SFRA storefronts are not supported by this version.
- **Boxing algorithm requires all four dimension attributes.** The boxing algorithm activates for a product only when `dimDepth`, `dimHeight`, `dimWidth`, and `dimWeight` are all set. Products missing any of these attributes fall back to the non-boxing rate path silently.
- **Product dimension attributes are not created by this app.** `dimWeight`, `dimHeight`, `dimWidth`, `dimDepth`, and `length` are read from pre-existing product catalog custom attributes. They must already be defined in your catalog and populated on each product.
- **Session storage limit.** SFCC caps `session.privacy` string values at 2 000 characters. Baskets with a large number of shipments or shipping methods may cause the rate cache (`zenkraftCosts`) or EDD cache (`zenkraftEDD`) to be truncated, which will result in a fallback to OOTB rates for the affected shipment.
- **Quote hook has no request deduplication.** The `sfcc.app.shipping.quote` hook calls the Zenkraft rate API on every invocation. Unlike the calculate hook, it does not use hash-based deduplication. Repeated refreshes of the checkout shipping step will each trigger an API call.
- **Translation keys must be provided by the host storefront.** The storefront extension reads from the `checkout` and `extMultiship` i18n namespaces. Keys used by the extension must exist in those namespaces in the host storefront; missing keys will render as the key string.

## Support

- Documentation: https://www.zenkraft.com

## Changelog

### v1.0.0
- Initial release
