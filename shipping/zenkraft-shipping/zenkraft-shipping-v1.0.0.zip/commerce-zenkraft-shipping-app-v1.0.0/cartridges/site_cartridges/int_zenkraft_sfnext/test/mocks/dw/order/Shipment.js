'use strict';

function Shipment() {
    this.UUID = '';
    this.shippingMethod = null;
    this.custom = {};
}

module.exports = Shipment;
