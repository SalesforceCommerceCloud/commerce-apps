'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

describe('calculateShipping hook', function () {
    var calculateHook;
    var helperStub;
    var loggerStub;
    var shippingMgrStub;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        global.session = { privacy: {} };

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        helperStub = {
            getConfig: sinon.stub(),
            buildShippingRateRequest: sinon.stub(),
            callZenkraftAPI: sinon.stub(),
            buildRatesMapFromResponse: sinon.stub().returns({}),
            updateSessionShippingRates: sinon.stub(),
            buildEDDMapFromResponse: sinon.stub().returns({}),
            updateSessionEDD: sinon.stub(),
            calculateShippingCost: sinon.stub()
        };

        shippingMgrStub = {
            applyShippingCost: sinon.stub()
        };

        calculateHook = proxyquire(
            '../../../cartridge/scripts/hooks/calculateShipping',
            {
                'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                'dw/order/ShippingMgr': shippingMgrStub,
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/zenkraftShippingHelper': helperStub
            }
        );
    });

    afterEach(function () {
        delete global.empty;
        delete global.session;
        sinon.restore();
    });

    // -------------------------------------------------------------------------
    // Helpers to build test fixtures
    // -------------------------------------------------------------------------
    function createShipment(options) {
        options = options || {};
        var shippingLineItems = options.shippingLineItems || [];
        return {
            UUID: options.uuid || 'shipment-1',
            shippingMethod: options.shippingMethod || null,
            shippingLineItems: {
                iterator: function () {
                    var idx = 0;
                    return {
                        hasNext: function () { return idx < shippingLineItems.length; },
                        next: function () { return shippingLineItems[idx++]; }
                    };
                }
            },
            productLineItems: {
                size: sinon.stub().returns(options.productCount !== undefined ? options.productCount : 1)
            },
            custom: {}
        };
    }

    function createLineItemCtnr(shipments) {
        return {
            getShipments: function () {
                return {
                    length: shipments.length,
                    iterator: function () {
                        var idx = 0;
                        return {
                            hasNext: function () { return idx < shipments.length; },
                            next: function () { return shipments[idx++]; }
                        };
                    }
                };
            }
        };
    }

    // =========================================================================
    // When Zenkraft is disabled
    // =========================================================================
    describe('when Zenkraft shipping rates are disabled', function () {
        beforeEach(function () {
            helperStub.getConfig.returns({ enabled: false });
        });

        it('should call ShippingMgr.applyShippingCost and return Status.OK', function () {
            var ctnr = createLineItemCtnr([]);
            var result = calculateHook.calculate(ctnr);
            assert.equal(result.status, Status.OK);
            assert.isTrue(shippingMgrStub.applyShippingCost.calledOnce);
            assert.isTrue(shippingMgrStub.applyShippingCost.calledWith(ctnr));
        });

        it('should NOT call the Zenkraft API', function () {
            calculateHook.calculate(createLineItemCtnr([]));
            assert.isTrue(helperStub.callZenkraftAPI.notCalled);
        });
    });

    // =========================================================================
    // When Zenkraft is enabled
    // =========================================================================
    describe('when Zenkraft shipping rates are enabled', function () {
        beforeEach(function () {
            helperStub.getConfig.returns({ enabled: true, carrier: 'fedex', nativeMethodsFallback: false });
        });

        // --- Missing required data ---
        it('should return Status.OK when buildShippingRateRequest returns false', function () {
            helperStub.buildShippingRateRequest.returns(false);
            var ctnr = createLineItemCtnr([createShipment()]);
            var result = calculateHook.calculate(ctnr);
            assert.equal(result.status, Status.OK);
            assert.isTrue(helperStub.callZenkraftAPI.notCalled);
        });

        // --- Successful API response ---
        it('should call buildShippingRateRequest for each shipment', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var s1 = createShipment({ uuid: 'ship-1' });
            var s2 = createShipment({ uuid: 'ship-2' });
            calculateHook.calculate(createLineItemCtnr([s1, s2]));

            assert.equal(helperStub.buildShippingRateRequest.callCount, 2);
        });

        it('should update session with rates and EDD on a successful API response', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({
                success: true,
                data: { rates: [{ service_type: 'GROUND', total_cost: 9.99 }] },
                deduplicated: false
            });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.updateSessionShippingRates.calledOnce);
            assert.isTrue(helperStub.updateSessionEDD.calledOnce);
        });

        it('should pass the shipment UUID to updateSessionShippingRates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var shipment = createShipment({ uuid: 'ship-abc' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            var callArgs = helperStub.updateSessionShippingRates.firstCall.args;
            assert.equal(callArgs[1], 'ship-abc');
        });

        // --- Deduplicated API response ---
        it('should NOT update session when API response is deduplicated', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(helperStub.updateSessionShippingRates.notCalled);
            assert.isTrue(helperStub.updateSessionEDD.notCalled);
        });

        // --- API failure ---
        it('should clear session rates and EDD when API call fails', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'Timeout', deduplicated: false });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.updateSessionShippingRates.calledWith(null, 'ship-1'));
            assert.isTrue(helperStub.updateSessionEDD.calledWith(null, 'ship-1'));
        });

        it('should log an error when API call fails', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'Timeout', deduplicated: false });

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(loggerStub.error.called);
        });

        // --- Applying cached session rates ---
        it('should apply cached session rates to shipments when session contains rates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var shipmentRates = { GROUND: '9.99' };
            session.privacy.zenkraftCosts = JSON.stringify({ 'ship-1': shipmentRates });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.calculateShippingCost.calledOnce);
            assert.isTrue(helperStub.calculateShippingCost.calledWith(shipment, shipmentRates));
        });

        it('should fall back to ShippingMgr.applyShippingCost when session has no rates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'err', deduplicated: false });
            session.privacy.zenkraftCosts = null;

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(shippingMgrStub.applyShippingCost.calledOnce);
        });

        it('should return Status.OK on success', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var result = calculateHook.calculate(createLineItemCtnr([createShipment()]));
            assert.equal(result.status, Status.OK);
        });

        // --- EDD application ---
        it('should set zenkraftEstimatedArrivalTime on shipment when method has zenkraftID and EDD exists', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var method = { custom: { zenkraftID: 'GROUND' } };
            session.privacy.zenkraftEDD = JSON.stringify({ 'ship-1': { GROUND: 'Mon 1 Jan' } });

            var shipment = createShipment({ uuid: 'ship-1', shippingMethod: method });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.equal(shipment.custom.zenkraftEstimatedArrivalTime, 'Mon 1 Jan');
        });

        it('should set zenkraftEstimatedArrivalTime to null when method has no zenkraftID', function () {
            helperStub.buildShippingRateRequest.returns(false);

            var shipment = createShipment({ uuid: 'ship-1', shippingMethod: null });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isNull(shipment.custom.zenkraftEstimatedArrivalTime);
        });

        // --- Multi-shipment: skip empty shipments ---
        it('should skip buildShippingRateRequest for empty shipments in multi-shipment mode', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var fullShipment = createShipment({ uuid: 'ship-1', productCount: 2 });
            var emptyShipment = createShipment({ uuid: 'ship-empty', productCount: 0 });
            var ctnr = createLineItemCtnr([fullShipment, emptyShipment]);

            calculateHook.calculate(ctnr);

            assert.equal(helperStub.buildShippingRateRequest.callCount, 1);
            assert.isTrue(helperStub.buildShippingRateRequest.calledWith(fullShipment));
            assert.isFalse(helperStub.buildShippingRateRequest.calledWith(emptyShipment));
        });

        it('should zero out line item prices for empty shipments in multi-shipment mode', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var setPriceStub = sinon.stub();
            var mockLineItem = { setPriceValue: setPriceStub };
            var emptyShipment = createShipment({
                uuid: 'ship-empty',
                productCount: 0,
                shippingLineItems: [mockLineItem]
            });

            var fullShipment = createShipment({ uuid: 'ship-1', productCount: 1 });
            var shipmentRates = { GROUND: '9.99' };
            session.privacy.zenkraftCosts = JSON.stringify({
                'ship-1': shipmentRates,
                'ship-empty': null
            });

            calculateHook.calculate(createLineItemCtnr([fullShipment, emptyShipment]));

            assert.isTrue(setPriceStub.calledWith(0));
        });
    });
});
