'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var dateHelper = proxyquire(
    '../../../cartridge/scripts/helpers/zenkraftDateHelper',
    {}
);

describe('zenkraftDateHelper', function () {

    // =========================================================================
    // getFormattedDateTime
    // =========================================================================
    describe('getFormattedDateTime', function () {
        it('should return a string containing the day abbreviation', function () {
            var date = new Date(2030, 5, 15); // Sat 15 Jun 2030 — well beyond "tomorrow"
            var result = dateHelper.getFormattedDateTime(date);
            var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            assert.include(result, days[date.getDay()]);
        });

        it('should include the day-of-month number in the formatted string', function () {
            var date = new Date(2030, 5, 15);
            var result = dateHelper.getFormattedDateTime(date);
            assert.include(result, '15');
        });

        it('should include the month abbreviation in the formatted string', function () {
            var date = new Date(2030, 5, 15); // June
            var result = dateHelper.getFormattedDateTime(date);
            assert.include(result, 'Jun');
        });

        it('should return "Tomorrow" for tomorrow\'s date', function () {
            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            var result = dateHelper.getFormattedDateTime(tomorrow);
            assert.include(result, 'Tomorrow');
        });

        it('should NOT return "Tomorrow" for a date far in the future', function () {
            var future = new Date(2035, 0, 1);
            var result = dateHelper.getFormattedDateTime(future);
            assert.notInclude(result, 'Tomorrow');
        });
    });

    // =========================================================================
    // getLeadTime — per-product and per-category zenkraftLeadTime overrides
    // =========================================================================
    describe('getLeadTime', function () {
        var calendarStub = function () { this.setTime = function () {}; this.getTime = function () { return new Date(); }; };

        function makeHelper(companyLeadTime, lineItems) {
            return proxyquire(
                '../../../cartridge/scripts/helpers/zenkraftDateHelper',
                {
                    'dw/util/Calendar': calendarStub,
                    'dw/order/BasketMgr': {
                        getCurrentBasket: function () {
                            return {
                                getProductLineItems: function () {
                                    return { toArray: function () { return lineItems || []; } };
                                }
                            };
                        }
                    },
                    'dw/system/Site': {
                        getCurrent: function () {
                            return {
                                getCustomPreferenceValue: function (pref) {
                                    return pref === 'zenkraftCompanyWideLeadTime' ? companyLeadTime : null;
                                }
                            };
                        }
                    }
                }
            );
        }

        function makeLineItem(zenkraftLeadTime, categoryLeadTime) {
            var product = {
                isVariant: function () { return false; },
                getCustom: function () {
                    var c = {};
                    if (zenkraftLeadTime !== undefined) { c.zenkraftLeadTime = zenkraftLeadTime; }
                    return c;
                }
            };
            var category = categoryLeadTime !== undefined ? {
                getCustom: function () { return { zenkraftLeadTime: categoryLeadTime }; }
            } : null;
            return {
                getProduct: function () { return product; },
                getCategory: function () { return category; }
            };
        }

        beforeEach(function () {
            global.empty = function (val) { return val === null || val === undefined || val === ''; };
        });

        afterEach(function () {
            delete global.empty;
        });

        it('should return company-wide lead time when no items override it', function () {
            var helper = makeHelper(2, []);
            assert.equal(helper.getLeadTime(), 2);
        });

        it('should add product zenkraftLeadTime when it exceeds company-wide lead time', function () {
            var helper = makeHelper(2, [makeLineItem(5, undefined)]);
            assert.equal(helper.getLeadTime(), 7); // 2 (company) + 5 (product)
        });

        it('should add category zenkraftLeadTime when it exceeds company-wide lead time', function () {
            var helper = makeHelper(1, [makeLineItem(undefined, 3)]);
            assert.equal(helper.getLeadTime(), 4); // 1 (company) + 3 (category)
        });

        it('should NOT add product lead time when it does not exceed company-wide lead time', function () {
            var helper = makeHelper(5, [makeLineItem(2, undefined)]);
            assert.equal(helper.getLeadTime(), 5); // product 2 < company 5, no override
        });

        it('should NOT add category lead time when it does not exceed company-wide lead time', function () {
            var helper = makeHelper(5, [makeLineItem(undefined, 1)]);
            assert.equal(helper.getLeadTime(), 5); // category 1 < company 5, no override
        });
    });
});
