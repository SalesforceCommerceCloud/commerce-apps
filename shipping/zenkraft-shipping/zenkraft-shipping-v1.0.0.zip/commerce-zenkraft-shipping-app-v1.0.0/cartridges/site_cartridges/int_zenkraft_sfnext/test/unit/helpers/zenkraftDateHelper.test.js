'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

var dateHelper = proxyquire(
    '../../../cartridge/scripts/helpers/zenkraftDateHelper',
    {
        'dw/web/Resource': {
            msg: function () { return ''; }
        },
        'dw/util/Calendar': function () {
            this.setTime = function () {};
            this.getTime = function () { return new Date(); };
        },
        'dw/util/StringUtils': {
            formatCalendar: function () { return ''; }
        }
    }
);

describe('zenkraftDateHelper', function () {

    // =========================================================================
    // convertDate
    // =========================================================================
    describe('convertDate', function () {
        it('should parse a YYYY-MM-DD string into a Date', function () {
            var result = dateHelper.convertDate('2024-03-15');
            assert.instanceOf(result, Date);
            assert.equal(result.getFullYear(), 2024);
            assert.equal(result.getMonth(), 2); // 0-indexed March
            assert.equal(result.getDate(), 15);
        });

        it('should handle single-digit month and day', function () {
            var result = dateHelper.convertDate('2024-01-05');
            assert.equal(result.getMonth(), 0);
            assert.equal(result.getDate(), 5);
        });

        it('should handle December correctly', function () {
            var result = dateHelper.convertDate('2024-12-31');
            assert.equal(result.getMonth(), 11); // 0-indexed December
            assert.equal(result.getDate(), 31);
        });
    });

    // =========================================================================
    // convertTime
    // =========================================================================
    describe('convertTime', function () {
        it('should parse a YYYY-MM-DD HH:MM:SS string into a Date with correct time', function () {
            var result = dateHelper.convertTime('2024-03-15 14:30:45');
            assert.instanceOf(result, Date);
            assert.equal(result.getHours(), 14);
            assert.equal(result.getMinutes(), 30);
            assert.equal(result.getSeconds(), 45);
        });

        it('should set hours minutes and seconds from the time portion', function () {
            var result = dateHelper.convertTime('2024-06-01 00:00:00');
            assert.equal(result.getHours(), 0);
            assert.equal(result.getMinutes(), 0);
            assert.equal(result.getSeconds(), 0);
        });

        it('should set the date portion correctly', function () {
            var result = dateHelper.convertTime('2024-07-20 09:15:30');
            assert.equal(result.getFullYear(), 2024);
            assert.equal(result.getMonth(), 6); // 0-indexed July
            assert.equal(result.getDate(), 20);
        });
    });

    // =========================================================================
    // getFormattedDateTime
    // =========================================================================
    describe('getFormattedDateTime', function () {
        it('should return a string containing the day abbreviation', function () {
            var date = new Date(2030, 5, 15); // Sat 15 Jun 2030 — well beyond "tomorrow"
            var result = dateHelper.getFormattedDateTime(date);
            var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            assert.include(result, days[date.getDay()]);
        });

        it('should include the day-of-month number in the formatted string', function () {
            var date = new Date(2030, 5, 15);
            var result = dateHelper.getFormattedDateTime(date);
            assert.include(result, '15');
        });

        it('should include the month abbreviation in the formatted string', function () {
            var date = new Date(2030, 5, 15); // June
            var result = dateHelper.getFormattedDateTime(date);
            assert.include(result, 'Jun');
        });

        it('should return "Tomorrow" for tomorrow\'s date', function () {
            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            var result = dateHelper.getFormattedDateTime(tomorrow);
            assert.include(result, 'Tomorrow');
        });

        it('should NOT return "Tomorrow" for a date far in the future', function () {
            var future = new Date(2035, 0, 1);
            var result = dateHelper.getFormattedDateTime(future);
            assert.notInclude(result, 'Tomorrow');
        });
    });

    // =========================================================================
    // getFutureDateDeliveryDates
    // =========================================================================
    describe('getFutureDateDeliveryDates', function () {
        // 2024-01-01 = Monday, 2024-01-05 = Friday
        var monday = new Date(2024, 0, 1);  // Mon
        var friday = new Date(2024, 0, 5);  // Fri

        it('should collect the specified number of future dates', function () {
            var result = dateHelper.getFutureDateDeliveryDates([], 3, 0, monday, true);
            assert.equal(result.length, 3);
        });

        it('should return objects with formatedDate and date fields', function () {
            var result = dateHelper.getFutureDateDeliveryDates([], 1, 0, monday, true);
            assert.property(result[0], 'formatedDate');
            assert.property(result[0], 'date');
        });

        it('should store date as a timestamp string', function () {
            var result = dateHelper.getFutureDateDeliveryDates([], 1, 0, monday, true);
            assert.isString(result[0].date);
            assert.isNotNaN(parseInt(result[0].date, 10));
        });

        it('should skip Saturday and Sunday when includeWeekends is false', function () {
            // Starting from Friday: Fri(ok), Sat(skip), Sun(skip), Mon(ok), Tue(ok)
            var result = dateHelper.getFutureDateDeliveryDates([], 3, 0, friday, false);
            assert.equal(result.length, 3);
            result.forEach(function (entry) {
                var day = new Date(parseInt(entry.date, 10)).getDay();
                assert.notEqual(day, 0, 'Sunday should be excluded');
                assert.notEqual(day, 6, 'Saturday should be excluded');
            });
        });

        it('should include Saturday and Sunday when includeWeekends is true', function () {
            // Starting from Friday: Fri(0), Sat(1), Sun(2)
            var result = dateHelper.getFutureDateDeliveryDates([], 3, 0, friday, true);
            var days = result.map(function (e) { return new Date(parseInt(e.date, 10)).getDay(); });
            assert.include(days, 6, 'Saturday should be included');
            assert.include(days, 0, 'Sunday should be included');
        });

        it('should start collecting from offset index i, not always from 0', function () {
            // offset=1 skips the first day (Monday), starts at Tuesday
            var resultFrom0 = dateHelper.getFutureDateDeliveryDates([], 1, 0, monday, true);
            var resultFrom1 = dateHelper.getFutureDateDeliveryDates([], 1, 1, monday, true);
            assert.notEqual(resultFrom0[0].date, resultFrom1[0].date);
        });

        it('should append to a pre-filled array', function () {
            var existing = [{ formatedDate: 'Already here', date: '0' }];
            var result = dateHelper.getFutureDateDeliveryDates(existing, 3, 0, monday, true);
            assert.equal(result.length, 3); // stops when collected === length (existing counts)
        });
    });

    // =========================================================================
    // getLeadTime — per-product and per-category zenkraftLeadTime overrides
    // =========================================================================
    describe('getLeadTime', function () {
        var calendarStub = function () { this.setTime = function () {}; this.getTime = function () { return new Date(); }; };

        function makeHelper(companyLeadTime, lineItems) {
            return proxyquire(
                '../../../cartridge/scripts/helpers/zenkraftDateHelper',
                {
                    'dw/web/Resource': { msg: function () { return ''; } },
                    'dw/util/Calendar': calendarStub,
                    'dw/util/StringUtils': { formatCalendar: function () { return ''; } },
                    'dw/order/BasketMgr': {
                        getCurrentBasket: function () {
                            return {
                                getProductLineItems: function () {
                                    return { toArray: function () { return lineItems || []; } };
                                }
                            };
                        }
                    },
                    'dw/system/Site': {
                        getCurrent: function () {
                            return {
                                getCustomPreferenceValue: function (pref) {
                                    return pref === 'zenkraftCompanyWideLeadTime' ? companyLeadTime : null;
                                }
                            };
                        }
                    }
                }
            );
        }

        function makeLineItem(zenkraftLeadTime, categoryLeadTime) {
            var product = {
                isVariant: function () { return false; },
                getCustom: function () {
                    var c = {};
                    if (zenkraftLeadTime !== undefined) { c.zenkraftLeadTime = zenkraftLeadTime; }
                    return c;
                }
            };
            var category = categoryLeadTime !== undefined ? {
                getCustom: function () { return { zenkraftLeadTime: categoryLeadTime }; }
            } : null;
            return {
                getProduct: function () { return product; },
                getCategory: function () { return category; }
            };
        }

        beforeEach(function () {
            global.empty = function (val) { return val === null || val === undefined || val === ''; };
        });

        afterEach(function () {
            delete global.empty;
        });

        it('should return company-wide lead time when no items override it', function () {
            var helper = makeHelper(2, []);
            assert.equal(helper.getLeadTime(), 2);
        });

        it('should add product zenkraftLeadTime when it exceeds company-wide lead time', function () {
            var helper = makeHelper(2, [makeLineItem(5, undefined)]);
            assert.equal(helper.getLeadTime(), 7); // 2 (company) + 5 (product)
        });

        it('should add category zenkraftLeadTime when it exceeds company-wide lead time', function () {
            var helper = makeHelper(1, [makeLineItem(undefined, 3)]);
            assert.equal(helper.getLeadTime(), 4); // 1 (company) + 3 (category)
        });

        it('should NOT add product lead time when it does not exceed company-wide lead time', function () {
            var helper = makeHelper(5, [makeLineItem(2, undefined)]);
            assert.equal(helper.getLeadTime(), 5); // product 2 < company 5, no override
        });

        it('should NOT add category lead time when it does not exceed company-wide lead time', function () {
            var helper = makeHelper(5, [makeLineItem(undefined, 1)]);
            assert.equal(helper.getLeadTime(), 5); // category 1 < company 5, no override
        });
    });
});
