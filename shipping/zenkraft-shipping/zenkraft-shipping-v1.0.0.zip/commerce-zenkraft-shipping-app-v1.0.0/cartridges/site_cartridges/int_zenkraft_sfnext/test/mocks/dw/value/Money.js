'use strict';

function Money(amount, currencyCode) {
    this.value = parseFloat(amount) || 0;
    this.currencyCode = currencyCode || 'USD';
    this.available = true;
}

Money.prototype.getValue = function () {
    return this.value;
};

Money.prototype.getCurrencyCode = function () {
    return this.currencyCode;
};

Money.prototype.add = function (other) {
    return new Money(this.value + other.value, this.currencyCode);
};

Money.prototype.addPercent = function (pct) {
    return new Money(this.value * (1 + pct / 100), this.currencyCode);
};

Money.prototype.toFormattedString = function () {
    return this.currencyCode + ' ' + this.value.toFixed(2);
};

module.exports = Money;
