'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Money = require('../../mocks/dw/value/Money');
var ShipmentMock = require('../../mocks/dw/order/Shipment');

describe('zenkraftShippingHelper', function () {
    var helper;
    var loggerStub;
    var siteStub;
    var sitePreferences;
    var serviceStub;
    var dateHelperStub;
    var collectionsMock;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        global.session = { privacy: {}, currency: { currencyCode: 'USD' } };

        sitePreferences = {};

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        siteStub = {
            getCurrent: sinon.stub().callsFake(function () {
                return {
                    getCustomPreferenceValue: function (key) {
                        return sitePreferences[key] !== undefined ? sitePreferences[key] : null;
                    },
                    currencyCode: 'USD'
                };
            })
        };

        serviceStub = {
            call: sinon.stub()
        };

        dateHelperStub = {
            getFormattedDateTime: sinon.stub().returns('Mon 1 Jan'),
            getShipDate: sinon.stub().returns('2024-01-15')
        };

        collectionsMock = {
            forEach: function (collection, callback) {
                if (Array.isArray(collection)) {
                    collection.forEach(callback);
                } else if (collection && collection.iterator) {
                    var it = collection.iterator();
                    while (it.hasNext()) { callback(it.next()); }
                }
            },
            some: function (collection, callback) {
                if (Array.isArray(collection)) {
                    return collection.some(callback);
                }
                var it = collection.iterator();
                while (it.hasNext()) {
                    if (callback(it.next())) { return true; }
                }
                return false;
            }
        };

        helper = proxyquire(
            '../../../cartridge/scripts/helpers/zenkraftShippingHelper',
            {
                'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                'dw/system/Site': siteStub,
                'dw/value/Money': Money,
                'dw/order/Shipment': ShipmentMock,
                '../services/zenkraftService': serviceStub,
                '../util/collections': collectionsMock,
                './zenkraftDateHelper': dateHelperStub
            }
        );
    });

    afterEach(function () {
        delete global.empty;
        delete global.session;
        sinon.restore();
    });

    // =========================================================================
    // getConfig
    // =========================================================================
    describe('getConfig', function () {
        it('should return enabled false when preference is not set', function () {
            var config = helper.getConfig();
            assert.isFalse(config.enabled);
        });

        it('should return enabled true when preference is set', function () {
            sitePreferences.enableZenkraftShippingRates = true;
            var config = helper.getConfig();
            assert.isTrue(config.enabled);
        });

        it('should default dimUnits to IN when not configured', function () {
            var config = helper.getConfig();
            assert.equal(config.dimUnits, 'IN');
        });

        it('should default weightUnits to LB when not configured', function () {
            var config = helper.getConfig();
            assert.equal(config.weightUnits, 'LB');
        });

        it('should default weight to 1.0 when not configured', function () {
            var config = helper.getConfig();
            assert.equal(config.defaultWeight, 1.0);
        });

        it('should read carrier from site preference', function () {
            sitePreferences.zenkraftCarrier = 'fedex';
            var config = helper.getConfig();
            assert.equal(config.carrier, 'fedex');
        });

        it('should use the value property for enum preferences like dimUnits', function () {
            sitePreferences.zenkraftDimensionUnits = { value: 'CM' };
            var config = helper.getConfig();
            assert.equal(config.dimUnits, 'CM');
        });
    });

    // =========================================================================
    // getMarkupCost
    // =========================================================================
    describe('getMarkupCost', function () {
        it('should return original cost when markupType and markup are both null', function () {
            var baseCost = new Money(10, 'USD');
            var result = helper.getMarkupCost(null, null, baseCost);
            assert.equal(result.value, 10);
        });

        it('should return original cost when markupType is empty string', function () {
            var baseCost = new Money(10, 'USD');
            var result = helper.getMarkupCost('', 5, baseCost);
            assert.equal(result.value, 10);
        });

        it('should add a fixed amount when markupType is Amount', function () {
            var baseCost = new Money(10, 'USD');
            var result = helper.getMarkupCost('Amount', 5, baseCost);
            assert.equal(result.value, 15);
        });

        it('should add zero when Amount markup is 0', function () {
            var baseCost = new Money(10, 'USD');
            var result = helper.getMarkupCost('Amount', 0, baseCost);
            assert.equal(result.value, 10);
        });

        it('should add percentage when markupType is Percent', function () {
            var baseCost = new Money(100, 'USD');
            var result = helper.getMarkupCost('Percent', 10, baseCost);
            assert.closeTo(result.value, 110, 0.001);
        });

        it('should wrap a raw number in a Money instance', function () {
            var result = helper.getMarkupCost('Amount', 2, 10);
            assert.instanceOf(result, Money);
            assert.equal(result.value, 12);
        });

        it('should return a Money instance regardless of markup type', function () {
            var result = helper.getMarkupCost(null, null, new Money(5, 'USD'));
            assert.instanceOf(result, Money);
        });
    });

    // =========================================================================
    // buildRatesMapFromResponse
    // =========================================================================
    describe('buildRatesMapFromResponse', function () {
        it('should return empty map for null input', function () {
            assert.deepEqual(helper.buildRatesMapFromResponse(null), {});
        });

        it('should return empty map for undefined input', function () {
            assert.deepEqual(helper.buildRatesMapFromResponse(undefined), {});
        });

        it('should handle flat array response', function () {
            var rates = [
                { service_type: 'FEDEX_GROUND', total_cost: 9.99 },
                { service_type: 'FEDEX_OVERNIGHT', total_cost: 29.99 }
            ];
            var result = helper.buildRatesMapFromResponse(rates);
            assert.equal(result['FEDEX_GROUND'], '9.99');
            assert.equal(result['FEDEX_OVERNIGHT'], '29.99');
        });

        it('should handle object with rates array', function () {
            var apiResp = { rates: [{ service_type: 'UPS_GROUND', total_cost: 7.50 }] };
            var result = helper.buildRatesMapFromResponse(apiResp);
            assert.equal(result['UPS_GROUND'], '7.50');
        });

        it('should skip rates without a service_type', function () {
            var result = helper.buildRatesMapFromResponse([{ total_cost: 5 }]);
            assert.deepEqual(result, {});
        });

        it('should map null total_cost to null (not undefined)', function () {
            var result = helper.buildRatesMapFromResponse([{ service_type: 'STANDARD', total_cost: null }]);
            assert.isNull(result['STANDARD']);
        });

        it('should format total_cost to 2 decimal places', function () {
            var result = helper.buildRatesMapFromResponse([{ service_type: 'GROUND', total_cost: 9 }]);
            assert.equal(result['GROUND'], '9.00');
        });
    });

    // =========================================================================
    // buildEDDMapFromResponse
    // =========================================================================
    describe('buildEDDMapFromResponse', function () {
        it('should return empty map for null input', function () {
            assert.deepEqual(helper.buildEDDMapFromResponse(null), {});
        });

        it('should return empty map when response has no rates array', function () {
            assert.deepEqual(helper.buildEDDMapFromResponse({}), {});
        });

        it('should extract estimated_date from an array of rates', function () {
            dateHelperStub.getFormattedDateTime.returns('Wed 3 Jan');
            var rates = [{ service_type: 'GROUND', estimated_date: '2024-01-03' }];
            var result = helper.buildEDDMapFromResponse(rates);
            assert.equal(result['GROUND'], 'Wed 3 Jan');
            assert.isTrue(dateHelperStub.getFormattedDateTime.calledOnce);
        });

        it('should extract date from delivery_slots when estimated_date is absent', function () {
            dateHelperStub.getFormattedDateTime.returns('Thu 4 Jan');
            var rates = [{
                service_type: 'EXPRESS',
                custom: { delivery_slots: [{ start_time: '2024-01-04-10:00:00' }] }
            }];
            var result = helper.buildEDDMapFromResponse(rates);
            assert.equal(result['EXPRESS'], 'Thu 4 Jan');
        });

        it('should skip rates without service_type', function () {
            var rates = [{ estimated_date: '2024-01-03' }];
            assert.deepEqual(helper.buildEDDMapFromResponse(rates), {});
        });

        it('should skip rates with neither estimated_date nor delivery_slots', function () {
            var rates = [{ service_type: 'GROUND' }];
            assert.deepEqual(helper.buildEDDMapFromResponse(rates), {});
        });

        it('should handle object response with a rates array', function () {
            dateHelperStub.getFormattedDateTime.returns('Fri 5 Jan');
            var resp = { rates: [{ service_type: 'OVERNIGHT', estimated_date: '2024-01-05' }] };
            var result = helper.buildEDDMapFromResponse(resp);
            assert.equal(result['OVERNIGHT'], 'Fri 5 Jan');
        });
    });

    // =========================================================================
    // updateSessionShippingRates
    // =========================================================================
    describe('updateSessionShippingRates', function () {
        it('should store rates in session keyed by shipment UUID', function () {
            var ratesMap = { GROUND: '9.99' };
            helper.updateSessionShippingRates(JSON.stringify(ratesMap), 'uuid-1');
            var stored = JSON.parse(session.privacy.zenkraftCosts);
            assert.deepEqual(stored['uuid-1'], ratesMap);
        });

        it('should use "default" key when no UUID is provided', function () {
            helper.updateSessionShippingRates(JSON.stringify({ G: '5.00' }));
            var stored = JSON.parse(session.privacy.zenkraftCosts);
            assert.isDefined(stored['default']);
        });

        it('should merge new rates with existing session data', function () {
            session.privacy.zenkraftCosts = JSON.stringify({ 'uuid-1': { G: '5.00' } });
            helper.updateSessionShippingRates(JSON.stringify({ E: '20.00' }), 'uuid-2');
            var stored = JSON.parse(session.privacy.zenkraftCosts);
            assert.isDefined(stored['uuid-1']);
            assert.isDefined(stored['uuid-2']);
        });

        it('should clear specific shipment rates when null is passed with a UUID', function () {
            session.privacy.zenkraftCosts = JSON.stringify({
                'uuid-1': { GROUND: '9.99' },
                'uuid-2': { EXPRESS: '29.99' }
            });
            helper.updateSessionShippingRates(null, 'uuid-1');
            var stored = JSON.parse(session.privacy.zenkraftCosts);
            assert.isUndefined(stored['uuid-1']);
            assert.isDefined(stored['uuid-2']);
        });

        it('should set zenkraftCosts to null after clearing last shipment', function () {
            session.privacy.zenkraftCosts = JSON.stringify({ 'uuid-1': {} });
            helper.updateSessionShippingRates(null, 'uuid-1');
            assert.isNull(session.privacy.zenkraftCosts);
        });

        it('should clear all rates when null is passed without a UUID', function () {
            session.privacy.zenkraftCosts = JSON.stringify({ 'uuid-1': {}, 'uuid-2': {} });
            helper.updateSessionShippingRates(null);
            assert.isNull(session.privacy.zenkraftCosts);
        });

        it('should log an error when rates payload is not valid JSON', function () {
            helper.updateSessionShippingRates('INVALID_JSON', 'uuid-1');
            assert.isTrue(loggerStub.error.calledOnce);
        });
    });

    // =========================================================================
    // updateSessionEDD
    // =========================================================================
    describe('updateSessionEDD', function () {
        it('should store EDD in session keyed by shipment UUID', function () {
            var eddMap = { GROUND: 'Mon 1 Jan' };
            helper.updateSessionEDD(eddMap, 'uuid-1');
            var stored = JSON.parse(session.privacy.zenkraftEDD);
            assert.deepEqual(stored['uuid-1'], eddMap);
        });

        it('should use "default" key when no UUID is provided', function () {
            helper.updateSessionEDD({ GROUND: 'Tue 2 Jan' });
            var stored = JSON.parse(session.privacy.zenkraftEDD);
            assert.isDefined(stored['default']);
        });

        it('should clear specific EDD entry when null is passed with a UUID', function () {
            session.privacy.zenkraftEDD = JSON.stringify({
                'uuid-1': { G: 'Mon' },
                'uuid-2': { E: 'Tue' }
            });
            helper.updateSessionEDD(null, 'uuid-1');
            var stored = JSON.parse(session.privacy.zenkraftEDD);
            assert.isUndefined(stored['uuid-1']);
            assert.isDefined(stored['uuid-2']);
        });

        it('should set zenkraftEDD to null after clearing last entry', function () {
            session.privacy.zenkraftEDD = JSON.stringify({ 'uuid-1': {} });
            helper.updateSessionEDD(null, 'uuid-1');
            assert.isNull(session.privacy.zenkraftEDD);
        });

        it('should clear all EDD when null is passed without a UUID', function () {
            session.privacy.zenkraftEDD = JSON.stringify({ 'uuid-1': {}, 'uuid-2': {} });
            helper.updateSessionEDD(null);
            assert.isNull(session.privacy.zenkraftEDD);
        });
    });

    // =========================================================================
    // callZenkraftAPI
    // =========================================================================
    describe('callZenkraftAPI', function () {
        var rateRequest;

        beforeEach(function () {
            rateRequest = { shipment: { carrier: 'fedex', test: true } };
        });

        it('should call zenkraft service with "http.zenkraft.rate" and request JSON', function () {
            serviceStub.call.returns({ status: 'OK', object: { rates: [] } });
            helper.callZenkraftAPI(rateRequest, 'uuid-1');
            assert.isTrue(serviceStub.call.calledOnce);
            assert.equal(serviceStub.call.firstCall.args[0], 'http.zenkraft.rate');
            assert.equal(serviceStub.call.firstCall.args[1], JSON.stringify(rateRequest));
        });

        it('should return success result with data when API call succeeds', function () {
            var mockData = { rates: [{ service_type: 'GROUND' }] };
            serviceStub.call.returns({ status: 'OK', object: mockData });
            var result = helper.callZenkraftAPI(rateRequest, 'uuid-1');
            assert.isTrue(result.success);
            assert.deepEqual(result.data, mockData);
            assert.isFalse(result.deduplicated);
        });

        it('should store the request hash in session after a successful call', function () {
            serviceStub.call.returns({ status: 'OK', object: {} });
            helper.callZenkraftAPI(rateRequest, 'uuid-1');
            var hashes = JSON.parse(session.privacy.zenkraftRateHashes);
            assert.isDefined(hashes['uuid-1']);
            assert.isNumber(hashes['uuid-1']);
        });

        it('should return deduplicated true when hash matches and rates exist in session', function () {
            serviceStub.call.returns({ status: 'OK', object: {} });
            // First call stores hash
            helper.callZenkraftAPI(rateRequest, 'uuid-1');
            // Simulate that rates were persisted by updateSessionShippingRates
            session.privacy.zenkraftCosts = JSON.stringify({ 'uuid-1': { GROUND: '9.99' } });
            // Second identical call should deduplicate
            var result = helper.callZenkraftAPI(rateRequest, 'uuid-1');
            assert.isTrue(result.deduplicated);
            assert.equal(serviceStub.call.callCount, 1);
        });

        it('should NOT deduplicate when the request changes between calls', function () {
            serviceStub.call.returns({ status: 'OK', object: {} });
            helper.callZenkraftAPI(rateRequest, 'uuid-1');
            session.privacy.zenkraftCosts = JSON.stringify({ 'uuid-1': {} });

            var modifiedRequest = { shipment: { carrier: 'ups', test: true } };
            var result = helper.callZenkraftAPI(modifiedRequest, 'uuid-1');
            assert.isFalse(result.deduplicated);
            assert.equal(serviceStub.call.callCount, 2);
        });

        it('should make a new API call when hash matches but rates were cleared', function () {
            serviceStub.call.returns({ status: 'OK', object: {} });
            // First call stores hash
            helper.callZenkraftAPI(rateRequest, 'uuid-1');
            // Rates cleared independently (stale hash scenario)
            session.privacy.zenkraftCosts = null;
            // Second call must NOT deduplicate
            var result = helper.callZenkraftAPI(rateRequest, 'uuid-1');
            assert.isFalse(result.deduplicated);
            assert.equal(serviceStub.call.callCount, 2);
        });

        it('should return error details when API call fails', function () {
            serviceStub.call.returns({ status: 'ERROR', errorMessage: 'Connection timeout' });
            var result = helper.callZenkraftAPI(rateRequest, 'uuid-1');
            assert.isFalse(result.success);
            assert.equal(result.error, 'Connection timeout');
            assert.isTrue(loggerStub.error.calledOnce);
        });

        it('should use "default" as hash key when no UUID is provided', function () {
            serviceStub.call.returns({ status: 'OK', object: {} });
            helper.callZenkraftAPI(rateRequest);
            var hashes = JSON.parse(session.privacy.zenkraftRateHashes);
            assert.isDefined(hashes['default']);
        });
    });
});
