'use strict';

var sinon = require('sinon');

var preferences = {};

module.exports = {
    getCurrent: sinon.stub().returns({
        getCustomPreferenceValue: sinon.stub().callsFake(function (key) {
            return preferences[key] !== undefined ? preferences[key] : null;
        }),
        currencyCode: 'USD',
        getCalendar: sinon.stub().returns({
            getTime: sinon.stub().returns(new Date()),
            setTime: sinon.stub()
        }),
        getTimezone: sinon.stub().returns('America/New_York'),
        getTimezoneOffset: sinon.stub().returns(0)
    }),
    _setPreferences: function (prefs) {
        preferences = prefs;
    },
    _reset: function () {
        preferences = {};
    }
};
