'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');

var logger = Logger.getLogger('zenkraft', 'afterPlaceOrder');

/**
 * Hook handler for dw.ocapi.shop.order.afterPOST.
 * Clears Zenkraft estimate cache attributes from each shipment — they served
 * the basket phase and are not needed on the persisted order.
 *
 * @param {dw.order.Order} order - The order about to be placed
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.afterPOST = function(order) {
    try {
        var shipmentsIt = order.getShipments().iterator();
        while (shipmentsIt.hasNext()) {
            var shipment = shipmentsIt.next();
            var cachedKey = shipment.custom.zenkraftEstimateKey;
            var hasSnapshot = !!shipment.custom.zenkraftEstimateSnapshot;
            shipment.custom.zenkraftEstimateKey = null;
            shipment.custom.zenkraftEstimateSnapshot = null;
        }
    } catch (e) {
        logger.error('Zenkraft beforePlaceOrder: failed to clear estimate cache attributes: {0}', e.message);
    }

    return new Status(Status.OK);
}
