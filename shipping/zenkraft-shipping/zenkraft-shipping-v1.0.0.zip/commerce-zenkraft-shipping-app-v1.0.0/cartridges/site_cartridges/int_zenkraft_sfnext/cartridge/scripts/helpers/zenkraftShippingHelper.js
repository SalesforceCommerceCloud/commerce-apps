/* global empty, session */
'use strict';

var Logger = require('dw/system/Logger');
var logger = Logger.getLogger('zenkraft', 'zenkraftHelper');
var Site = require('dw/system/Site');

/**
 * Builds a deterministic SHA-256 key from a shipment's delivery address and product line items.
 * Products are sorted by SKU then quantity so insertion order never affects the result.
 * Returns null when the address lacks the required country or postal code.
 *
 * @param {dw.order.Shipment} shipment
 * @returns {string|null} 64-character hex string, or null if the address is incomplete
 */
function buildEstimateKey(shipment) {
    var Bytes = require('dw/util/Bytes');
    var Encoding = require('dw/crypto/Encoding');
    var MessageDigest = require('dw/crypto/MessageDigest');

    var address = shipment && shipment.shippingAddress;
    if (!address || empty(address.countryCode) || empty(address.postalCode)) {
        return null;
    }

    var products = [];
    var itemsIt = shipment.getProductLineItems().iterator();
    while (itemsIt.hasNext()) {
        var pli = itemsIt.next();
        products.push({ sku: pli.productID, qty: pli.quantityValue });
    }
    products.sort(function (a, b) {
        if (a.sku < b.sku) { return -1; }
        if (a.sku > b.sku) { return 1; }
        return a.qty - b.qty;
    });

    var payload = JSON.stringify({
        address: {
            country: address.countryCode.value.toUpperCase(),
            postalCode: address.postalCode,
            state: !empty(address.stateCode) ? address.stateCode : '',
            city: !empty(address.city) ? address.city : ''
        },
        products: products
    });

    try {
        var md = new MessageDigest(MessageDigest.DIGEST_SHA_256);
        return Encoding.toHex(md.digestBytes(new Bytes(payload, 'UTF-8')));
    } catch (e) {
        logger.error('buildEstimateKey failed: {0}', e.message);
        return null;
    }
}

/**
 * Reads and parses the Zenkraft rate snapshot stored on a shipment's custom attributes.
 *
 * @param {dw.order.Shipment} shipment
 * @returns {Object|null} Parsed snapshot, or null if absent or unparseable
 */
function readSnapshot(shipment) {
    var value = shipment && shipment.custom && shipment.custom.zenkraftEstimateSnapshot;
    if (!value) { return null; }
    try {
        return JSON.parse(String(value));
    } catch (e) {
        return null;
    }
}

/**
 * Persists a Zenkraft rate + EDD snapshot to the shipment's custom attributes.
 * Snapshot format: { methods: { <zenkraftID>: { cost, edd? } }, rates: [...sanitized] }
 * The `rates` array is the full sanitized API response and is used by the quote hook
 * to serve GET /shipping-methods without a repeat API call.
 *
 * @param {dw.order.Shipment} shipment
 * @param {string} estimateKey - Hash produced by buildEstimateKey
 * @param {Object} ratesMap - { zenkraftID: cost } from buildRatesMapFromResponse
 * @param {Object} eddMap - { zenkraftID: formattedEDD } from buildEDDMapFromResponse
 * @param {Array} sanitizedRates - Full sanitized rates array from sanitizeShippingData
 */
function writeSnapshot(shipment, estimateKey, ratesMap, eddMap, sanitizedRates) {
    var methods = {};
    Object.keys(ratesMap || {}).forEach(function (id) {
        methods[id] = { cost: ratesMap[id] };
        if (eddMap && eddMap[id]) {
            methods[id].edd = eddMap[id];
        }
    });
    shipment.custom.zenkraftEstimateKey = estimateKey;
    shipment.custom.zenkraftEstimateSnapshot = JSON.stringify({
        methods: methods,
        rates: sanitizedRates || []
    });
}

/**
 * Computes a djb2 hash of a string for request deduplication.
 * @param {string} str - Input string
 * @returns {number} 32-bit integer hash
 */
function hashString(str) {
    var hash = 5381;
    for (var i = 0; i < str.length; i++) {
        hash = ((hash << 5) + hash) + str.charCodeAt(i);
        hash = hash & hash;
    }
    return hash;
}

/**
 * Reads all Zenkraft-related site preferences into a config object.
 * @returns {Object} Configuration object
 */
function getConfig() {
    var currentSite = Site.getCurrent();
    return {
        enabled: currentSite.getCustomPreferenceValue('enableZenkraftShippingRates') || false,
        isProdMode: currentSite.getCustomPreferenceValue('zenkraftProdMode') || false,
        debugLog: currentSite.getCustomPreferenceValue('zenkraftDebugLog') || false,
        carrier: currentSite.getCustomPreferenceValue('zenkraftCarrier'),
        shippingAccount: currentSite.getCustomPreferenceValue('zenkraftShippingAccount'),
        useMultipleAccounts: currentSite.getCustomPreferenceValue('useZenkraftMultipleShippingAccounts') || false,
        useSinglePackage: currentSite.getCustomPreferenceValue('zenkraftPackageConfig') || false,
        enableBoxingAlgorithm: currentSite.getCustomPreferenceValue('enableZenkraftBoxingAlgorithm') || false,
        nativeMethodsFallback: currentSite.getCustomPreferenceValue('zenkraftNativeMethodsFallback') || false,
        dimUnits: (currentSite.getCustomPreferenceValue('zenkraftDimensionUnits') || {}).value || 'IN',
        weightUnits: (currentSite.getCustomPreferenceValue('zenkraftWeightUnits') || {}).value || 'LB',
        defaultWeight: parseFloat(currentSite.getCustomPreferenceValue('zenkraftDefaultProductWeight')) || 1.0,
        packagingType: currentSite.getCustomPreferenceValue('zenkraftPackagingType') || 'your_packaging',
        currencyCode: currentSite.getCustomPreferenceValue('zenkraftCurrencyCode') || 'USD',
        specialServices: currentSite.getCustomPreferenceValue('zenkraftRateSpecialServices'),
        rateServiceType: currentSite.getCustomPreferenceValue('zenkraftRateServiceType'),
        apiKey: currentSite.getCustomPreferenceValue('zenkraftMasterAPIKey'),
        customAuth: currentSite.getCustomPreferenceValue('zenkraftCustomAuth'),
        senderStreet: currentSite.getCustomPreferenceValue('zenkraftSenderStreet'),
        senderCity: currentSite.getCustomPreferenceValue('zenkraftSenderCity'),
        senderStateCode: currentSite.getCustomPreferenceValue('zenkraftSenderStateCode'),
        senderPostalCode: currentSite.getCustomPreferenceValue('zenkraftSenderPostalCode'),
        senderCountryCode: currentSite.getCustomPreferenceValue('zenkraftSenderCountryCode'),
        enableEstimatedDeliveryDates: currentSite.getCustomPreferenceValue('enableZenkraftEstimatedDeliveryDates') || false,
        cutoffTime: currentSite.getCustomPreferenceValue('zenkraftEDDCutoffTime'),
        leadTime: currentSite.getCustomPreferenceValue('zenkraftCompanyWideLeadTime') || 0,
        advancedJSON: currentSite.getCustomPreferenceValue('zenkraftAdvancedJSON') || false,
        advancedJSONObject: currentSite.getCustomPreferenceValue('zenkraftAdvancedJSONObject'),
    };
}

/**
 * Applies Advanced JSON overrides to a rate request in-place.
 * The JSON object must follow the shape: { "EDD": { "COUNTRY_CODE": { ... } } }
 * where the country code matches the recipient's ISO country code.
 * Supported override keys: CARRIER_ID, SERVICE_TYPE, PACKAGING, DIM_UNITS, WEIGHT_UNITS,
 * CURRENCYCODE, ACCOUNT_ID, SPECIAL_SERVICES, ADDRESS (STREET, CITY, STATECODE, POSTALCODE, COUNTRYCODE).
 *
 * @param {Object} req - Rate request object built by buildRateRequest (mutated in-place)
 * @param {Object} config - Config object from getConfig()
 * @param {string} recipientCountry - Uppercase ISO-2 country code of the destination
 */
function applyAdvancedJSON(req, config, recipientCountry) {
    if (!config.advancedJSON || empty(config.advancedJSONObject) || empty(recipientCountry)) {
        return;
    }
    var advJson;
    try {
        advJson = JSON.parse(config.advancedJSONObject);
    } catch (e) {
        logger.error('Invalid zenkraftAdvancedJSONObject: {0}', e.message);
        return;
    }
    var typeConfig = advJson.EDD || advJson.SHIP;
    if (!typeConfig) {
        return;
    }
    var countrySpec = typeConfig[recipientCountry];
    if (!countrySpec) {
        return;
    }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'CARRIER_ID'))      { req.shipment.carrier = countrySpec.CARRIER_ID; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'SERVICE_TYPE'))    { req.shipment.service_type = countrySpec.SERVICE_TYPE; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'PACKAGING'))       { req.shipment.packaging = countrySpec.PACKAGING; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'DIM_UNITS'))       { req.shipment.dim_units = countrySpec.DIM_UNITS; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'WEIGHT_UNITS'))    { req.shipment.weight_units = countrySpec.WEIGHT_UNITS; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'CURRENCYCODE'))    { req.shipment.currency = countrySpec.CURRENCYCODE; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'ACCOUNT_ID'))      { req.shipment.shipping_account = countrySpec.ACCOUNT_ID; }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'SPECIAL_SERVICES')) {
        req.shipment.special_services = countrySpec.SPECIAL_SERVICES;
    }
    if (Object.prototype.hasOwnProperty.call(countrySpec, 'ADDRESS')) {
        var addr = countrySpec.ADDRESS;
        if (addr.STREET)      { req.shipment.sender.street1 = addr.STREET; }
        if (addr.CITY)        { req.shipment.sender.city = addr.CITY; }
        if (addr.STATECODE)   { req.shipment.sender.state = addr.STATECODE; }
        if (addr.POSTALCODE)  { req.shipment.sender.postal_code = addr.POSTALCODE.replace(/\s+/g, ''); }
        if (addr.COUNTRYCODE) { req.shipment.sender.country = addr.COUNTRYCODE; }
    }
}

/**
 * Applies a markup to a shipping cost based on type and value configured on the shipping method.
 *
 * @param {string} markupType - 'Amount' for fixed add-on, 'Percent' for percentage add-on
 * @param {number} markup - Markup value
 * @param {dw.value.Money} shippingCost - Base shipping cost
 * @returns {dw.value.Money} Shipping cost with markup applied
 */
function getMarkupCost(markupType, markup, shippingCost) {
    var Money = require('dw/value/Money');
    // Fallback uses site default currency to stay consistent with how calculateShippingCost
    // constructs the base Money object. For true multi-currency support, calculateShippingCost
    // should derive the currency from the basket/shipment rather than Site.getCurrent().currencyCode.
    var currencyCode = (shippingCost instanceof Money)
        ? shippingCost.getCurrencyCode()
        : Site.getCurrent().currencyCode;
    var updatedCost = (shippingCost instanceof Money)
        ? shippingCost
        : new Money(parseFloat(shippingCost), currencyCode);

    if (!empty(markupType) && !empty(markup)) {
        if (markupType === 'Amount') {
            var amt = new Money(markup, currencyCode);
            updatedCost = updatedCost.add(amt);
        } else if (markupType === 'Percent') {
            updatedCost = updatedCost.addPercent(markup);
        }
    }

    return updatedCost;
}

/**
 * The function checks if boxing algorithm is enabled for the basket.
 * @param {Array} productLineItems - product line items in basket
 * @param {Boolean} useSinglePackage - whether single package is enabled
 * @returns {Boolean} - boxingAlgorithmEnabled - true if boxing algorithm is enabled
 */
function isZenkraftBoxingAlgorithmEnabled(productLineItems, useSinglePackage, enableBoxingAlgorithm) {
    if (useSinglePackage) {
        return false;
    }
    if (!enableBoxingAlgorithm) {
        return false;
    }

    // Check all items for required dimensions
    var iterator = productLineItems.iterator();
    while (iterator.hasNext()) {
        var item = iterator.next();
        if (!item.product || !item.product.custom.dimDepth || !item.product.custom.dimHeight ||
            !item.product.custom.dimWeight || !item.product.custom.dimWidth) {
            return false;
        }
    }
    return true;
}

/**
 * Retrieves all Zenkraft package profiles from Custom Objects.
 * Each package profile contains box dimensions and weight limits for boxes using for boxing algorithm.
 *
 * @returns {Array<Object>} Array of package profile objects. If none found, returns an empty array.
 *
 */
function getPackagesProfiles() {
    var CustomObjectMgr = require('dw/object/CustomObjectMgr');
    var packages = [];
    var packageProfiles = CustomObjectMgr.getAllCustomObjects('zenkraftPackageProfile');

    if (packageProfiles.getCount() === 0) {
        logger.warn('No Zenkraft package profiles found');
        packageProfiles.close();
        return packages;
    }

    try {
        while (packageProfiles.hasNext()) {
            var packageProfile = packageProfiles.next();
            var profile = {
                empty_weight: packageProfile.custom.emptyBoxWeight || 0,
                inner_depth: packageProfile.custom.innerHeight,
                inner_length: packageProfile.custom.innerLength,
                inner_width: packageProfile.custom.innerWidth,
                max_weight: packageProfile.custom.maxWeight || 1000000,
                outer_depth: packageProfile.custom.height,
                outer_length: packageProfile.custom.length,
                outer_width: packageProfile.custom.width,
                reference: packageProfile.custom.id || '',
            };
            packages.push(profile);
        }
    } finally {
        packageProfiles.close();
    }

    return packages;
}

/**
 * Extracts the first number (integer or decimal) from a string.
 * @param {string} value - The string to extract the number from.
 * @returns {number} - The extracted number, or 0 if not found.
 */
function extractNumber(value) {
    var match = value && value.match(/[\d.]+/);
    return match ? Number(match[0]) : 0;
}

/**
 * Builds a products array for the Zenkraft boxing/pack API from DW product line items.
 * One entry per unit (quantity expanded).
 * @param {dw.util.Collection} productLineItems - Product line items from the shipment
 * @returns {Array} Products array for the pack request
 */
function getProductsForPackaging(productLineItems) {
    var collections = require('../util/collections');
    var products = [];
    collections.forEach(productLineItems, function (pli) {
        var quantity = pli.quantityValue || 1;
        for (var i = 0; i < quantity; i++) {
            products.push({
                id: pli.productID,
                description: pli.productName,
                depth: extractNumber(pli.product && pli.product.custom.dimDepth) || 0,
                length: extractNumber(pli.product && pli.product.custom.dimHeight) || 0,
                weight: extractNumber(pli.product && pli.product.custom.dimWeight) || 0,
                width: extractNumber(pli.product && pli.product.custom.dimWidth) || 0,
                packaged_in_own_box: false
            });
        }
    });
    return products;
}

/**
 * Calls the Zenkraft pack service to compute boxing algorithm packages.
 * Returns an object with an error property on failure, or an array of package objects on success.
 * @param {dw.util.Collection} productLineItems - Product line items to pack
 * @param {Boolean} debug - Zenrkaft defub log enablement
 * @returns {Array|{error: string}} Prepared packages or error object
 */
function getBoxingPackages(productLineItems, debug) {
    var zenkraftShippingService = require('../services/zenkraftService');
    var boxes = getPackagesProfiles();
    var products = getProductsForPackaging(productLineItems);
    var resp = zenkraftShippingService.call('http.zenkraft.pack', JSON.stringify({ boxes: boxes, products: products, debug: debug}));

    if (resp.status === 'ERROR') {
        logger.error('Zenkraft Pack Service Error: {0}', resp.errorMessage || 'Error getting pack information');
        return { error: resp.errorMessage || 'Error getting pack information' };
    }

    if (empty(resp.object)) {
        return { error: 'Error getting pack information' };
    }

    if (!resp.object.success) {
        logger.warn('Zenkraft Pack Service Warning: {0}', resp.object.message || 'Cannot get pack information');
        return { error: resp.object.message || 'Error getting pack information' };
    }

    var packed = resp.object;
    var preparedPackages = [];
    if (packed.packed_shipment_boxes && Array.isArray(packed.packed_shipment_boxes)) {
        packed.packed_shipment_boxes.forEach(function (packageItem) {
            var weight = packageItem.weight || 0;
            packageItem.items.forEach(function (item) {
                weight += item.weight || 0;
            });
            preparedPackages.push({
                height: packageItem.box.outer_depth || 0,
                length: packageItem.box.outer_length || 0,
                width: packageItem.box.outer_width || 0,
                weight: weight
            });
        });
    }
    return preparedPackages;
}

/**
 * Overrides SFCC shipping line item prices with Zenkraft real-time rates from session.
 * Matches the shipment's selected shipping method via its zenkraftID custom attribute,
 * then applies any markup configured on the method.
 * Optionally updates a shipping model object for display purposes.
 *
 * @param {dw.order.LineItemCtnr|dw.order.Shipment} lineItemCtnr - Basket, order, or individual shipment
 * @param {Object} shippingCostMap - Map of zenkraftID to cost value from session
 * @param {Object} [shippingModel] - Optional shipping model to update shippingCost for display
 */
function calculateShippingCost(lineItemCtnr, shippingCostMap, shippingModel) {
    var Money = require('dw/value/Money');
    var Shipment = require('dw/order/Shipment');

    var shipment = lineItemCtnr instanceof Shipment ? lineItemCtnr : lineItemCtnr.defaultShipment;
    var shippingMethod = shipment.shippingMethod;
    var shippingLineItems = shipment.shippingLineItems.iterator();
    var shippingCost;
    var markupType;
    var markup;

    if (shippingMethod != null && shippingCostMap &&
        shippingCostMap[shippingMethod.custom.zenkraftID] != null &&
        shippingCostMap[shippingMethod.custom.zenkraftID] !== 0) {

        while (shippingLineItems.hasNext()) {
            var shippingLineItem = shippingLineItems.next();
            var price = shippingCostMap[shippingMethod.custom.zenkraftID];
            shippingCost = new Money(parseFloat(price), Site.getCurrent().currencyCode);

            markupType = shippingMethod.custom.zenkraftRateMarkupType ? shippingMethod.custom.zenkraftRateMarkupType.value : 'Amount';
            markup = shippingMethod.custom.zenkraftRateMarkup || 0;

            shippingCost = getMarkupCost(markupType, markup, shippingCost);

            shippingLineItem.setPriceValue(shippingCost.value);
        }

        logger.debug('Applied Zenkraft rate {0} for method {1}', shippingCost && shippingCost.value, shippingMethod.custom.zenkraftID);
    }

    if (shippingMethod != null && shippingModel && shippingCostMap && shippingCostMap[shippingModel.zenkraftID]) {
        shippingCost = new Money(parseFloat(shippingCostMap[shippingModel.zenkraftID]), Site.getCurrent().currencyCode);
        markupType = shippingMethod.custom.zenkraftRateMarkupType ? shippingMethod.custom.zenkraftRateMarkupType.value : 'Amount';
        markup = shippingMethod.custom.zenkraftRateMarkup || 0;
        shippingCost = getMarkupCost(markupType, markup, shippingCost);
        shippingModel.shippingCost = shippingCost.toFormattedString();
    }
}

/**
 * Extracts a map of { serviceType: formattedEstimatedArrivalTime } from a raw Zenkraft rate API response.
 * Mirrors the EDD logic in shippingOptions.js so calculateShipping.js can persist it without
 * relying on cross-request session data written by the quote hook.
 *
 * @param {Object|Array} apiResponse - Raw response data from Zenkraft rate API
 * @returns {Object} Map of service type to formatted estimated arrival time string
 */
function buildEDDMapFromResponse(apiResponse) {
    var dateHelper = require('./zenkraftDateHelper');
    var eddMap = {};
    var rates = null;

    if (Array.isArray(apiResponse)) {
        rates = apiResponse;
    } else if (apiResponse && Array.isArray(apiResponse.rates)) {
        rates = apiResponse.rates;
    }

    if (!rates) {
        return eddMap;
    }

    rates.forEach(function (rate) {
        if (!rate.service_type) {
            return;
        }
        var parts;
        var thisDateraw;
        if (rate.estimated_date) {
            parts = rate.estimated_date.split('-');
            thisDateraw = new Date(parts[0], parts[1] - 1, parts[2]);
            eddMap[rate.service_type] = dateHelper.getFormattedDateTime(thisDateraw);
        } else if (rate.custom && rate.custom.delivery_slots && rate.custom.delivery_slots[0]) {
            parts = rate.custom.delivery_slots[0].start_time.split('-');
            thisDateraw = new Date(parts[0], parts[1] - 1, parts[2].slice(0, 2));
            eddMap[rate.service_type] = dateHelper.getFormattedDateTime(thisDateraw);
        }
    });

    return eddMap;
}

/**
 * Stores new Zenkraft EDD data in session, keyed by shipment UUID.
 * Pass null to clear a specific shipment's EDD.
 *
 * @param {Object|null} eddMap - Map of serviceType to estimated arrival time, or null to clear
 * @param {string} [shipmentUUID] - UUID of the shipment these dates belong to
 */
function updateSessionEDD(eddMap, shipmentUUID) {
    var allEDD = {};
    try {
        allEDD = JSON.parse(session.privacy.zenkraftEDD) || {};
    } catch (e) {
        allEDD = {};
    }

    if (!eddMap) {
        if (shipmentUUID) {
            delete allEDD[shipmentUUID];
        } else {
            allEDD = {};
        }
    } else {
        allEDD[shipmentUUID || 'default'] = eddMap;
    }

    session.privacy.zenkraftEDD = Object.keys(allEDD).length > 0 ? JSON.stringify(allEDD) : null;
}

/**
 * Stores new Zenkraft rates in session, keyed by shipment UUID.
 * Pass null/undefined rates to clear a specific shipment's cached rates (or all if no UUID).
 * Clears the corresponding deduplication hash so stale hashes cannot block fresh API calls.
 *
 * @param {string|null} rates - JSON string of new rates keyed by zenkraftID, or null to clear
 * @param {string} [shipmentUUID] - UUID of the shipment these rates belong to
 */
function updateSessionShippingRates(rates, shipmentUUID) {
    var allRates = {};
    try {
        allRates = JSON.parse(session.privacy.zenkraftCosts) || {};
    } catch (e) {
        allRates = {};
    }

    if (!rates) {
        var storedHashes = {};
        try { storedHashes = JSON.parse(session.privacy.zenkraftRateHashes) || {}; } catch (e) { storedHashes = {}; }

        if (shipmentUUID) {
            delete allRates[shipmentUUID];
            delete storedHashes[shipmentUUID];
        } else {
            allRates = {};
            storedHashes = {};
        }
        session.privacy.zenkraftCosts = Object.keys(allRates).length > 0 ? JSON.stringify(allRates) : null;
        session.privacy.zenkraftRateHashes = Object.keys(storedHashes).length > 0 ? JSON.stringify(storedHashes) : null;
        return;
    }

    try {
        allRates[shipmentUUID || 'default'] = JSON.parse(rates);
        session.privacy.zenkraftCosts = JSON.stringify(allRates);
    } catch (e) {
        logger.error('Failed to parse Zenkraft rates payload: {0}', e.message);
    }
}

/**
 * Builds a Zenkraft rate API request from an address and product line items.
 * Single source of truth used by both calculateShipping and getShippingData flows
 * so that deduplication hashes are always comparable.
 *
 * @param {dw.order.OrderAddress} address - Destination address
 * @param {dw.util.Collection} productLineItems - Product line items to ship
 * @param {Object} [options]
 * @param {string} [options.shipDate] - Optional ship date in YYYY-MM-DD format
 * @returns {Object} Rate request body
 */
function buildRateRequest(address, productLineItems, options) {
    var collections = require('../util/collections');
    var config = getConfig();
    var opts = options || {};
    var packages = [];
    var totalWeight = 0;

    var preferenceShippingAccounts = config.shippingAccount ? config.shippingAccount.split(',') : [];
    var shippingAccount;
    if (config.useMultipleAccounts) {
        shippingAccount = preferenceShippingAccounts.length === 1 ? preferenceShippingAccounts[0] : preferenceShippingAccounts;
    } else {
        shippingAccount = preferenceShippingAccounts[0] || config.shippingAccount;
    }

    var req = {
        shipment: {
            test: !config.isProdMode,
            debug: config.debugLog,
            carrier: opts.carrier || config.carrier,
            type: 'outbound',
            dim_units: config.dimUnits,
            weight_units: config.weightUnits,
            currency: config.currencyCode,
            packaging: config.packagingType,
            shipping_account: shippingAccount,
            service_type: config.rateServiceType,
            special_services: !empty(config.specialServices) ? config.specialServices.split(',') : '',
            sender: {
                street1: config.senderStreet,
                city: config.senderCity,
                state: config.senderStateCode,
                postal_code: config.senderPostalCode ? config.senderPostalCode.replace(/\s+/g, '') : '',
                country: config.senderCountryCode
            },
            recipient: {
                street1: !empty(address.address1) ? address.address1 : '',
                city: !empty(address.city) ? address.city : '',
                state: !empty(address.stateCode) && address.stateCode !== 'undefined' ? address.stateCode : '',
                postal_code: !empty(address.postalCode) ? address.postalCode : '',
                country: !empty(address.countryCode) ? address.countryCode.value.toUpperCase() : '',
                company: '',
                email: '',
                name: '',
                phone: ''
            }
        }
    };

    if (!empty(opts.shipDate)) {
        req.shipment.ship_date = opts.shipDate;
    }

    var boxingAlgorithmEnabled = isZenkraftBoxingAlgorithmEnabled(productLineItems, config.useSinglePackage, config.enableBoxingAlgorithm);

    logger.debug('Boxing algorithm enabled: ' + boxingAlgorithmEnabled);

    if (boxingAlgorithmEnabled) {
        packages = getBoxingPackages(productLineItems, config.debugLog);
    }

    if (packages.length === 0 || packages.error) {
        packages = [];
        collections.forEach(productLineItems, function (pli) {
            var dimWeight = config.defaultWeight;
            var length = 1;
            var width = 1;
            var height = 1;
            if (pli.product) {
                try {
                    if (!empty(pli.product.custom.dimWeight)) {
                        dimWeight = extractNumber(pli.product.custom.dimWeight) || dimWeight;
                    }
                    if (!empty(pli.product.custom.dimDepth)) {
                        length = extractNumber(pli.product.custom.dimDepth) || length;
                    }
                    if (!empty(pli.product.custom.dimWidth)) {
                        width = extractNumber(pli.product.custom.dimWidth) || width;
                    }
                    if (!empty(pli.product.custom.dimHeight)) {
                        height = extractNumber(pli.product.custom.dimHeight) || height;
                    }
                } catch (e) { /* product may not have custom dimension attributes */ }
            }

            var itemWeight = dimWeight * pli.quantityValue;
            if (config.useSinglePackage) {
                totalWeight += itemWeight;
            } else {
                packages.push({ weight: itemWeight, value: 1, length: length, width: width, height: height });
            }
        });

        if (config.useSinglePackage) {
            packages.push({ weight: totalWeight, value: 1, length: 5, width: 5, height: 5 });
        }
    }

    req.shipment.packages = packages;
    applyAdvancedJSON(req, config, req.shipment.recipient.country);
    return req;
}

/**
 * Builds a Zenkraft rate API request from the current basket state.
 *
 * @param {dw.order.Shipment} shipment - The shipment to build the request for
 * @returns {Object|null} Rate request object, or null if destination address is incomplete
 */
function buildShippingRateRequest(shipment) {
    if (!shipment) {
        return false;
    }

    var shippingAddress = shipment.shippingAddress;
    if (!shippingAddress || empty(shippingAddress.countryCode)) {
        logger.debug('Missing shipping address for shipment: {0}', shipment.UUID);
        return false;
    }

    var productLineItems = shipment.getProductLineItems();
    if (empty(productLineItems) || productLineItems.length === 0) {
        logger.debug('No product line items in shipment: {0}', shipment.UUID);
        return false;
    }

    var shippingMethod = shipment.shippingMethod;
    var methodCarrier = shippingMethod && !empty(shippingMethod.custom.zenkraftCarrier)
        ? shippingMethod.custom.zenkraftCarrier
        : null;

    var dateHelper = require('./zenkraftDateHelper');
    var shipDate = dateHelper.getShipDate();
    return buildRateRequest(shippingAddress, productLineItems, { shipDate: shipDate, carrier: methodCarrier });
}

/**
 * Calls the Zenkraft rate API with per-shipment request deduplication via session hashing.
 * Hashes are stored in a separate small session key (zenkraftRateHashes) to stay within
 * SFCC's 2000-char api.session.maxStringLength quota. A cache hit is only accepted when
 * the hash matches AND the corresponding rates entry still exists in zenkraftCosts — this
 * prevents false dedup when rates are cleared without the hash being cleared.
 *
 * @param {Object} rateRequest - Rate request object built by buildShippingRateRequest
 * @param {string} [shipmentUUID] - UUID of the shipment being rated, used to key the hash
 * @returns {{success: boolean, data: Object, error: string, deduplicated: boolean}}
 */
function callZenkraftAPI(rateRequest, shipmentUUID) {
    var zenkraftShippingService = require('../services/zenkraftService');
    var requestJSON = JSON.stringify(rateRequest);
    var hash = hashString(requestJSON);
    var hashKey = shipmentUUID || 'default';

    var storedHashes = {};
    try {
        storedHashes = JSON.parse(session.privacy.zenkraftRateHashes) || {};
    } catch (e) {
        storedHashes = {};
    }

    if (storedHashes[hashKey] === hash) {
        // Guard: only skip the API call if the rates are still present in session.
        // If zenkraftCosts was cleared independently the hash would be stale.
        var cachedRates = {};
        try { cachedRates = JSON.parse(session.privacy.zenkraftCosts) || {}; } catch (e) { cachedRates = {}; }

        if (cachedRates[hashKey]) {
            logger.debug('Zenkraft rate request unchanged for shipment: {0}, skipping API call', shipmentUUID);
            return { success: true, deduplicated: true };
        }
        // Rates were cleared; drop the stale hash so the API is called again.
        delete storedHashes[hashKey];
    }

    var result = zenkraftShippingService.call('http.zenkraft.rate', requestJSON);

    if (result.status === 'OK') {
        storedHashes[hashKey] = hash;
        session.privacy.zenkraftRateHashes = JSON.stringify(storedHashes);
        return { success: true, data: result.object, deduplicated: false };
    }

    logger.error('Zenkraft rate API call failed: {0}', result.errorMessage);
    return { success: false, error: result.errorMessage, deduplicated: false };
}

/**
 * Converts a Zenkraft rate API response into a flat map of { zenkraftID: cost }.
 * Handles both array responses and object responses with a `rates` property.
 *
 * @param {Object|Array} apiResponse - Raw response data from Zenkraft rate API
 * @returns {Object} Map of service identifier to shipping cost
 */
function buildRatesMapFromResponse(apiResponse) {
    var ratesMap = {};

    if (!apiResponse) {
        return ratesMap;
    }

    var rates = null;
    if (Array.isArray(apiResponse)) {
        rates = apiResponse;
    } else if (Array.isArray(apiResponse.rates)) {
        rates = apiResponse.rates;
    }

    if (rates) {
        rates.forEach(function (rate) {
            if (rate.service_type) {
                ratesMap[rate.service_type] = rate.total_cost != null ? Number(rate.total_cost).toFixed(2) : null;
            }
        });
    }

    return ratesMap;
}

/**
 * Normalises Zenkraft rate API results into a flat array for EDD processing.
 *
 * @param {Array} data - Raw rate objects from the Zenkraft API
 * @param {boolean} enableRates - Whether Zenkraft rates are enabled (from config.enabled)
 * @returns {Array} Sanitized shipping method objects
 */
function sanitizeShippingData(data, enableRates) {
    var cleanMethods = [];
    data.forEach(function (meth) {
        var cleanmethod = {};
        cleanmethod.carrier = meth.carrier && !empty(meth.carrier) ? meth.carrier : false;
        cleanmethod.cost = !empty(meth.total_cost) && enableRates ? Number(meth.total_cost).toFixed(2) : null;
        cleanmethod.estimated_date = !empty(meth.estimated_date) ? meth.estimated_date : '';
        cleanmethod.estimated_date_time = !empty(meth.estimated_date_time) ? meth.estimated_date_time : '';
        cleanmethod.service_type = meth.service_type;
        cleanmethod.bringg_team_id = meth.custom ? meth.custom.bringg_team_id : null;
        cleanmethod.quote_id = meth.custom ? meth.custom.quote_id : null;
        cleanmethod.delivery_slots = meth.custom && meth.custom.delivery_slots ? meth.custom.delivery_slots : [];
        cleanMethods.push(cleanmethod);
    });
    return cleanMethods;
}

/**
 * Builds a Zenkraft rate request directly from an address and product line items.
 * Used by getShippingData for EDD / shipping-options hook calls.
 * @param {dw.order.OrderAddress} address - Destination address
 * @param {dw.util.Collection} productLineItems - Product line items to ship
 * @param {string} [shipDate] - Ship date in YYYY-MM-DD format
 * @returns {Object} Rate request body
 */
function buildRateRequestFromAddressAndItems(address, productLineItems, shipDate) {
    var collections = require('../util/collections');
    var config = getConfig();
    var packages = [];
    var totalWeight = 0;
    var req = {};

    var preferenceShippingAccounts = config.shippingAccount ? config.shippingAccount.split(',') : [];
    var shippingAccount;
    if (config.useMultipleAccounts) {
        shippingAccount = preferenceShippingAccounts.length === 1 ? preferenceShippingAccounts[0] : preferenceShippingAccounts;
    } else {
        shippingAccount = preferenceShippingAccounts[0] || config.shippingAccount;
    }

    req.shipment = {
        test: !config.isProdMode,
        debug: config.debugLog,
        carrier: config.carrier,
        type: 'outbound',
        dim_units: config.dimUnits,
        weight_units: config.weightUnits,
        currency: config.currencyCode,
        packaging: config.packagingType,
        shipping_account: shippingAccount,
        sender: {
            street1: config.senderStreet,
            city: config.senderCity,
            state: config.senderStateCode,
            postal_code: config.senderPostalCode ? config.senderPostalCode.replace(/\s+/g, '') : '',
            country: config.senderCountryCode
        }
    };

    req.shipment.recipient = {
        city: !empty(address.city) ? address.city : '',
        country: !empty(address.countryCode) ? address.countryCode.value.toUpperCase() : '',
        company: '',
        email: '',
        name: '',
        phone: '',
        postal_code: !empty(address.postalCode) ? address.postalCode : '',
        state: !empty(address.stateCode) && address.stateCode !== 'undefined' ? address.stateCode : '',
        street1: !empty(address.address1) ? address.address1 : ''
    };

    if (!empty(shipDate)) {
        req.shipment.ship_date = shipDate;
    }

    collections.forEach(productLineItems, function (pli) {
        var dimWeight = config.defaultWeight;
        var length = 1;
        var width = 1;
        var height = 1;
        if (pli.product) {
            try {
                if (!empty(pli.product.custom.dimWeight)) {
                    dimWeight = parseFloat(pli.product.custom.dimWeight);
                }
                if (!empty(pli.product.custom.dimDepth)) {
                    length = parseFloat(pli.product.custom.dimDepth);
                }
                if (!empty(pli.product.custom.dimWidth)) {
                    width = parseFloat(pli.product.custom.dimWidth);
                }
                if (!empty(pli.product.custom.dimHeight)) {
                    height = parseFloat(pli.product.custom.dimHeight);
                }
            } catch (e) { /* product may not have custom dimension attributes */ }
        }

        var itemWeight = dimWeight * pli.quantityValue;
        if (config.useSinglePackage) {
            totalWeight += itemWeight;
        } else {
            packages.push({ weight: itemWeight, value: 1, length: length, width: width, height: height });
        }
    });

    if (config.useSinglePackage) {
        packages.push({ weight: totalWeight, value: 1, length: 5, width: 5, height: 5 });
    }

    req.shipment.packages = packages;
    return req;
}

/**
 * Fetches Zenkraft EDD / rate data for the given address and shipping methods.
 * Mirrors the getShippingData function in the legacy int_zenkraft_headless helper.
 *
 * @param {dw.order.OrderAddress} address - Destination shipping address
 * @param {dw.util.Collection} productLineItems - Items being shipped
 * @param {dw.util.Collection} methods - Applicable shipping methods (must expose c_zenkraftID)
 * @param {string} date - Ship date in YYYY-MM-DD format
 * @param {Object} senderAddress - Reserved sender address override (currently unused)
 * @param {string} shipmentUUID - Shipment UUID
 * @returns {Array|undefined} Sanitized rate/EDD objects, or undefined if unavailable
 */
function getShippingData(address, productLineItems, methods, date, senderAddress, shipmentUUID) { // eslint-disable-line no-unused-vars
    var collections = require('../util/collections');
    var zenkraftShippingService = require('../services/zenkraftService');

    if (!empty(address) && !empty(address.postalCode) &&
            !empty(productLineItems) && productLineItems.length > 0) {
        var rateRequest = buildRateRequest(address, productLineItems, { shipDate: date });
        var serviceResponse = zenkraftShippingService.call('http.zenkraft.rate', JSON.stringify(rateRequest));

        if (serviceResponse.status === 'OK' && !empty(serviceResponse.object) && empty(serviceResponse.object.error)) {
            var data = serviceResponse.object;
            var rates = Array.isArray(data) ? data : data.rates;
            if (!Array.isArray(rates)) {
                logger.debug('Zenkraft rate response missing rates array for shipment: {0}', shipmentUUID);
                return [];
            }
            var results = rates.filter(function (rate) {
                return collections.some(methods, function (method) {
                    return rate.service_type === method.c_zenkraftID;
                });
            });
            var enableRates = Site.getCurrent().getCustomPreferenceValue('enableZenkraftShippingRates');
            return sanitizeShippingData(results, enableRates);
        }
        logger.debug('Zenkraft rate service call failed or returned error for shipment: {0}', shipmentUUID);
    }
    return [];
}

module.exports = {
    getConfig: getConfig,
    getMarkupCost: getMarkupCost,
    calculateShippingCost: calculateShippingCost,
    updateSessionShippingRates: updateSessionShippingRates,
    updateSessionEDD: updateSessionEDD,
    buildShippingRateRequest: buildShippingRateRequest,
    callZenkraftAPI: callZenkraftAPI,
    buildRatesMapFromResponse: buildRatesMapFromResponse,
    buildEDDMapFromResponse: buildEDDMapFromResponse,
    getShippingData: getShippingData,
    buildEstimateKey: buildEstimateKey,
    readSnapshot: readSnapshot,
    writeSnapshot: writeSnapshot,
    sanitizeShippingData: sanitizeShippingData,
    applyAdvancedJSON: applyAdvancedJSON,
    extractNumber: extractNumber
};
