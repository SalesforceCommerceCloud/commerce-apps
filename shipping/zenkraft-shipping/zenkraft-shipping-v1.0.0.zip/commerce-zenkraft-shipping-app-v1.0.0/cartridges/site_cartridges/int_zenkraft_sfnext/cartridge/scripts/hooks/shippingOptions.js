var BasketMgr = require('dw/order/BasketMgr');
var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var Status = require('dw/system/Status');

var logger = Logger.getLogger('zenkraft', 'shippingOptions');

exports.quote = function (shipment, shippingMethodResult) {
    try {
    var collections = require('../util/collections');
    var dateHelper = require('../helpers/zenkraftDateHelper.js');
    var zenkraftShippingHelper = require('../helpers/zenkraftShippingHelper');
    var basket = BasketMgr.getCurrentBasket();
    var enableZenkraftEstimatedDeliveryDates = Site.getCurrent().getCustomPreferenceValue('enableZenkraftEstimatedDeliveryDates');

    var config = zenkraftShippingHelper.getConfig();
    if (!config.enabled) {
        logger.debug('Zenkraft Shipping Rates are not enabled');
        return new Status(Status.OK);
    }


    if (basket) {
        var thisItems = shipment.productLineItems;
        var thisDates = [];
        var parts;
        var thisDateraw;
        var leadDateFormated = dateHelper.getShipDate();
        var thisMethods = shippingMethodResult.applicableShippingMethods;

        var thisAddress = shipment.shippingAddress;
        var senderAddress = null;

        var estimateKey = zenkraftShippingHelper.buildEstimateKey(shipment);
        var storedKey = String(shipment.custom.zenkraftEstimateKey || '');
        var snapshot = zenkraftShippingHelper.readSnapshot(shipment);

        logger.info('[Zenkraft] shippingOptions - shipment: {0} | built key: {1} | stored key: {2}', shipment.UUID, estimateKey, storedKey || '(none)');

        if (estimateKey && storedKey === estimateKey && snapshot && snapshot.rates && snapshot.rates.length > 0) {
            logger.info('[Zenkraft] shippingOptions - CACHE HIT for shipment: {0} | {1} rate(s) served from snapshot', shipment.UUID, snapshot.rates.length);
            thisDates = snapshot.rates;
        } else {
            var missReason = !estimateKey ? 'no key (incomplete address)' : !storedKey ? 'no stored key' : storedKey !== estimateKey ? 'key changed' : !snapshot ? 'no snapshot' : 'snapshot has no rates';
            logger.info('[Zenkraft] shippingOptions - CACHE MISS for shipment: {0} | reason: {1} | calling API', shipment.UUID, missReason);
            thisDates = zenkraftShippingHelper.getShippingData(thisAddress, thisItems, thisMethods, leadDateFormated, senderAddress, shipment.UUID);
        }

        if (empty(thisDates) || !thisMethods) {
            logger.debug('No Zenkraft shipping data returned for shipment: {0}', shipment.UUID);
            if (!config.nativeMethodsFallback && estimateKey) {
                shippingMethodResult.applicableShippingMethods = [];
            }
            return new Status(Status.OK);
        }

        collections.forEach(thisMethods, function filterMethods(method) {
            var filteredMethod = thisDates.filter(function filterMethod(thisDate) {
                return thisDate.service_type === method.c_zenkraftID;
            });
            var filteredMethodObj = filteredMethod[0];

            if (filteredMethodObj) {
                method.c_delivery_slots = filteredMethodObj.delivery_slots;

                if (enableZenkraftEstimatedDeliveryDates) {
                    if (filteredMethodObj.estimated_date) {
                        parts = filteredMethodObj.estimated_date.split('-');
                        thisDateraw = new Date(parts[0], parts[1] - 1, parts[2]); // eslint-disable-line vars-on-top
                        method.c_estimated_date = filteredMethodObj.estimated_date;
                        method.c_estimated_date_time = filteredMethodObj.estimated_date_time;
                        method.c_estimatedArrivalTime = dateHelper.getFormattedDateTime(thisDateraw);
                    } else if (filteredMethodObj.delivery_slots[0]) {
                        var deliverySlot = filteredMethodObj.delivery_slots[0];
                        parts = deliverySlot.start_time.split('-'); // eslint-disable-line vars-on-top
                        thisDateraw = new Date(parts[0], parts[1] - 1, parts[2].slice(0, 2)); // eslint-disable-line vars-on-top
                        method.c_estimated_date = filteredMethodObj.delivery_slots[0].start_time;
                        method.c_estimated_date_time = filteredMethodObj.delivery_slots[0].end_time;
                        method.c_estimatedArrivalTime = dateHelper.getFormattedDateTime(thisDateraw);
                    }
                }

                if (!empty(filteredMethodObj) && !empty(filteredMethodObj.cost)) {
                    var markupType = method.c_zenkraftRateMarkupType ? method.c_zenkraftRateMarkupType : 'Amount';
                    var markup = method.c_zenkraftRateMarkup || 0;
                    method.price = zenkraftShippingHelper.getMarkupCost(markupType, markup, filteredMethodObj.cost).value;
                }


            }
        });

    }
    return new Status(Status.OK);
    } catch (e) {
        logger.error('Zenkraft shipping options exception: {0}', e.message);
        return new Status(Status.OK);
    }
};