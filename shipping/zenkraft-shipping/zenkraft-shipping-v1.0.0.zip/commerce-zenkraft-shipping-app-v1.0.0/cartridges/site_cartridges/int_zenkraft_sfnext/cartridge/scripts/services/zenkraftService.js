'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var UUIDUtils = require('dw/util/UUIDUtils');

var API_PATHS = {
    RATE: '/rate',
    PACK: '/pack'
};

// Set in call() and read in createRequest() via module-level scope.
// Safe because SFCC scripts are single-threaded per request.
var apiKey = null;
var path = null;

var SERVICE_CALLBACKS = {
    createRequest: function (svc, request) {
        var credential = svc.getConfiguration().getCredential();
        apiKey = credential.getPassword();
        svc.setURL(credential.getURL() + path);
        svc.addHeader('zkkey', apiKey);
        svc.addHeader('Accept', 'application/json');
        svc.addHeader('Content-Type', 'application/json');
        svc.addHeader('correlation-id', UUIDUtils.createUUID());
        svc.setRequestMethod('POST');
        return request;
    },

    parseResponse: function (svc, client) {
        return JSON.parse(client.text);
    },

    filterLogMessage: function (msg) {
        var filtered = apiKey ? msg.replace(apiKey, '***') : msg;
        return filtered.replace(/"street1"\s*:\s*"[^"]*"/g, '"street1":"***"');
    }
};

var svc = null;

function getService() {
    if (!svc) {
        svc = LocalServiceRegistry.createService('zenkraft.api', SERVICE_CALLBACKS);
    }
    return svc;
}

/**
 * Call the Zenkraft API at the given path
 * @param {string} apiPath - API path, e.g. '/rate' or '/pack'
 * @param {string} serviceRequest - JSON-stringified request payload
 * @returns {Object} Raw DW service call result
 */
function call(apiPath, serviceRequest) {
    path = apiPath;
    return getService().call(serviceRequest);
}

module.exports = {
    call: call,
    API_PATHS: API_PATHS
};
