'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Site = require('dw/system/Site');
var UUIDUtils = require('dw/util/UUIDUtils');

var SERVICE_CALLBACKS = {
    createRequest: function (svc, request) {
        var apiKey = Site.getCurrent().getCustomPreferenceValue('zenkraftMasterAPIKey');
        svc.addHeader('zkkey', apiKey);
        svc.addHeader('Accept', 'application/json');
        svc.addHeader('Content-Type', 'application/json');
        svc.addHeader('correlation-id', UUIDUtils.createUUID());
        svc.setRequestMethod('POST');
        return request;
    },

    parseResponse: function (svc, client) {
        return JSON.parse(client.text);
    },

    filterLogMessage: function (msg) {
        var apiKey = Site.getCurrent().getCustomPreferenceValue('zenkraftMasterAPIKey');
        var filtered = apiKey ? msg.replace(apiKey, '***') : msg;
        return filtered.replace(/"street1"\s*:\s*"[^"]*"/g, '"street1":"***"');
    }
};

var serviceCache = {};

function getService(serviceID) {
    if (!serviceCache[serviceID]) {
        serviceCache[serviceID] = LocalServiceRegistry.createService(serviceID, SERVICE_CALLBACKS);
    }
    return serviceCache[serviceID];
}

/**
 * Call a Zenkraft service by ID
 * @param {string} serviceID - Service ID to use
 * @param {string} serviceRequest - JSON-stringified request payload
 * @returns {Object} Raw DW service call result
 */
function call(serviceID, serviceRequest) {
    return getService(serviceID).call(serviceRequest);
}

module.exports = {
    call: call
};
