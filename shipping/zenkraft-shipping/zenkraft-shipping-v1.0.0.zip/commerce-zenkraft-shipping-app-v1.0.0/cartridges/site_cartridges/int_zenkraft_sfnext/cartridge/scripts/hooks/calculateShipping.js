/* global empty, session */
'use strict';

var Logger = require('dw/system/Logger');
var ShippingMgr = require('dw/order/ShippingMgr');
var Status = require('dw/system/Status');
var zenkraftShippingHelper = require('~/cartridge/scripts/helpers/zenkraftShippingHelper');

var logger = Logger.getLogger('zenkraft', 'calculateShipping');
/**
 * Hook handler for sfcc.app.shipping.calculate.
 * Calls the Zenkraft rate API (with
 * request-hash deduplication) and overrides line-item prices with the returned rates in case zenrkaft shipping rate are enabled.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate shipping for
 * @returns {dw.system.Status} Status indicating success or failure
 */
function calculate(lineItemCtnr) {
    var config = zenkraftShippingHelper.getConfig();
    if (!config.enabled) {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('Zenkraft Shipping Rates are not enabled');
        return new Status(Status.OK);
    }

    var missingRequiredData = false;
    var currentShipments = lineItemCtnr.getShipments();
    var isMultiShipment = currentShipments.length > 1;
    var shipmentsIt = currentShipments.iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();

        // Empty shipments left over from multi-shipment mode have no products to rate —
        // skip the API call so they don't pollute missingRequiredData for other shipments.
        if (isMultiShipment && shipment.productLineItems.size() === 0) {
            logger.debug('Skipping rate request for empty shipment: ' + shipment.UUID);
            continue;
        }

        var shippingMethod = shipment.shippingMethod;
        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            shipment.custom.zenkraftCarrier = shippingMethod.custom.zenkraftCarrier || config.carrier || '';
            shipment.custom.zenkraftShippingAccount = shippingMethod.custom.zenkraftShippingMethodAccountID;
        } else {
            shipment.custom.zenkraftCarrier = null;
            shipment.custom.zenkraftShippingAccount = null;
        }

        try {
            var rateRequest = zenkraftShippingHelper.buildShippingRateRequest(shipment);
            if (!rateRequest) {
                missingRequiredData = true;
            } else {
                var estimateKey = zenkraftShippingHelper.buildEstimateKey(shipment);
                var storedKey = String(shipment.custom.zenkraftEstimateKey || '');
                var snapshot = zenkraftShippingHelper.readSnapshot(shipment);

                logger.info('[Zenkraft] calculateShipping - shipment: {0} | built key: {1} | stored key: {2}', shipment.UUID, estimateKey, storedKey || '(none)');

                if (estimateKey && storedKey === estimateKey && snapshot) {
                    logger.info('[Zenkraft] calculateShipping - CACHE HIT for shipment: {0} | snapshot methods: {1}', shipment.UUID, JSON.stringify(snapshot.methods));
                    var cachedRates = {};
                    var cachedEDD = {};
                    Object.keys(snapshot.methods || {}).forEach(function (id) {
                        var m = snapshot.methods[id];
                        if (m.cost != null) { cachedRates[id] = m.cost; }
                        if (m.edd) { cachedEDD[id] = m.edd; }
                    });
                    zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(cachedRates), shipment.UUID);
                    zenkraftShippingHelper.updateSessionEDD(cachedEDD, shipment.UUID);
                } else {
                    var missReason = !estimateKey ? 'no key (incomplete address)' : !storedKey ? 'no stored key' : storedKey !== estimateKey ? 'key changed' : 'no snapshot';
                    logger.info('[Zenkraft] calculateShipping - CACHE MISS for shipment: {0} | reason: {1} | calling API', shipment.UUID, missReason);
                    var apiResult = zenkraftShippingHelper.callZenkraftAPI(rateRequest, shipment.UUID);
                    if (!apiResult.deduplicated) {
                        if (apiResult.success && apiResult.data) {
                            var ratesMap = zenkraftShippingHelper.buildRatesMapFromResponse(apiResult.data);
                            zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(ratesMap), shipment.UUID);
                            var eddPerMethod = zenkraftShippingHelper.buildEDDMapFromResponse(apiResult.data);
                            zenkraftShippingHelper.updateSessionEDD(eddPerMethod, shipment.UUID);
                            if (estimateKey) {
                                var rawRates = Array.isArray(apiResult.data) ? apiResult.data : (Array.isArray(apiResult.data.rates) ? apiResult.data.rates : []);
                                var sanitizedRates = zenkraftShippingHelper.sanitizeShippingData(rawRates, config.enabled);
                                zenkraftShippingHelper.writeSnapshot(shipment, estimateKey, ratesMap, eddPerMethod, sanitizedRates);
                                logger.info('[Zenkraft] calculateShipping - snapshot written for shipment: {0} | key: {1} | methods: {2}', shipment.UUID, estimateKey, JSON.stringify(ratesMap));
                            }
                        } else if (!apiResult.success) {
                            zenkraftShippingHelper.updateSessionShippingRates(null, shipment.UUID);
                            zenkraftShippingHelper.updateSessionEDD(null, shipment.UUID);
                            logger.error('Zenkraft rate API error: {0}', apiResult.error);
                        }
                    } else {
                        logger.info('[Zenkraft] calculateShipping - API call deduplicated (session hash hit) for shipment: {0}', shipment.UUID);
                    }
                }
            }
        } catch (e) {
            logger.error('Zenkraft shipping calculation exception: {0}', e.message);
        }

        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            try {
                if (config.enableEstimatedDeliveryDates) {
                    var dwSnapshot = zenkraftShippingHelper.readSnapshot(shipment);
                    var zenkraftIDStr = String(shippingMethod.custom.zenkraftID);
                    var dwStart = null;
                    var dwEnd = null;
                    if (dwSnapshot && dwSnapshot.rates) {
                        for (var ri = 0; ri < dwSnapshot.rates.length; ri++) {
                            var snapRate = dwSnapshot.rates[ri];
                            if (snapRate.service_type === zenkraftIDStr) {
                                if (snapRate.estimated_date) {
                                    dwStart = new Date(snapRate.estimated_date + 'T12:00:00.000Z');
                                    dwEnd = new Date(snapRate.estimated_date + 'T12:00:00.000Z');
                                } else if (snapRate.delivery_slots && snapRate.delivery_slots[0]) {
                                    dwStart = new Date(snapRate.delivery_slots[0].start_time);
                                    dwEnd = new Date(snapRate.delivery_slots[0].end_time || snapRate.delivery_slots[0].start_time);
                                }
                                break;
                            }
                        }
                    }
                    shipment.custom.deliveryWindowStartAt = dwStart;
                    shipment.custom.deliveryWindowEndAt = dwEnd;
                }
            } catch (eddErr) {
                logger.error('Failed to apply Zenkraft EDD to shipment: {0}', eddErr.message);
            }
        } else {
            shipment.custom.deliveryWindowStartAt = null;
            shipment.custom.deliveryWindowEndAt = null;
        }
    }

    if (missingRequiredData && !isMultiShipment) {
        logger.debug('Missing required data.');
        return new Status(Status.OK);
    }

    if (!empty(session.privacy.zenkraftCosts)) {
        try {
            var allShipmentRates = JSON.parse(session.privacy.zenkraftCosts);
            var applyIt = currentShipments.iterator();
            while (applyIt.hasNext()) {
                var s = applyIt.next();
                var shipmentRates = allShipmentRates[s.UUID];
                if (shipmentRates) {
                    zenkraftShippingHelper.calculateShippingCost(s, shipmentRates);
                } else if (isMultiShipment && s.productLineItems.size() === 0) {
                    var emptyShipmentLineItems = s.shippingLineItems.iterator();
                    while (emptyShipmentLineItems.hasNext()) {
                        emptyShipmentLineItems.next().setPriceValue(0);
                    }
                    logger.debug('Applied $0 cost for empty shipment: ' + s.UUID + ', shippingTotalPrice: ' + s.shippingTotalPrice);
                } else {
                    logger.warn('No Zenkraft rates and not an empty multi-shipment for UUID: ' + s.UUID + '. Price not updated.');
                }
            }
        } catch (e) {
            logger.error('Failed to apply Zenkraft session rates: {0}', e.message);
        }
    } else {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('OOTB shipping costs are applied.');
    }

    return new Status(Status.OK);
}

exports.calculate = calculate;
