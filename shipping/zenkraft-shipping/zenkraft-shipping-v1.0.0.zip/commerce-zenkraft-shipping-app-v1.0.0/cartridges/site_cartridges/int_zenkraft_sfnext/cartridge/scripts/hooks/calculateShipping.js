/* global empty, session */
'use strict';

var Logger = require('dw/system/Logger');
var ShippingMgr = require('dw/order/ShippingMgr');
var Status = require('dw/system/Status');
var zenkraftShippingHelper = require('~/cartridge/scripts/helpers/zenkraftShippingHelper');

var logger = Logger.getLogger('zenkraft', 'calculateShipping');
/**
 * Hook handler for sfcc.app.shipping.calculate.
 * Calls the Zenkraft rate API (with
 * request-hash deduplication) and overrides line-item prices with the returned rates in case zenrkaft shipping rate are enabled.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate shipping for
 * @returns {dw.system.Status} Status indicating success or failure
 */
function calculate(lineItemCtnr) {
    var config = zenkraftShippingHelper.getConfig();
    if (!config.enabled) {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('Zenkraft Shipping Rates are not enabled');
        return new Status(Status.OK);
    }

    var missingRequiredData = false;
    var currentShipments = lineItemCtnr.getShipments();
    var isMultiShipment = currentShipments.length > 1;
    var shipmentsIt = currentShipments.iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();

        // Empty shipments left over from multi-shipment mode have no products to rate —
        // skip the API call so they don't pollute missingRequiredData for other shipments.
        if (isMultiShipment && shipment.productLineItems.size() === 0) {
            logger.debug('Skipping rate request for empty shipment: ' + shipment.UUID);
            continue;
        }

        var shippingMethod = shipment.shippingMethod;
        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            shipment.custom.zenkraftCarrier = shippingMethod.custom.zenkraftCarrier || config.carrier || '';
            shipment.custom.zenkraftShippingAccount = shippingMethod.custom.zenkraftShippingMethodAccountID;
        } else {
            delete shipment.custom.zenkraftCarrier;
            delete shipment.custom.zenkraftShippingAccount;
        }

        try {
            var rateRequest = zenkraftShippingHelper.buildShippingRateRequest(shipment);
            if (!rateRequest) {
                missingRequiredData = true;
            } else {
                var apiResult = zenkraftShippingHelper.callZenkraftAPI(rateRequest, shipment.UUID);
                if (!apiResult.deduplicated) {
                    if (apiResult.success && apiResult.data) {
                        var ratesMap = zenkraftShippingHelper.buildRatesMapFromResponse(apiResult.data);
                        zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(ratesMap), shipment.UUID);
                        var eddPerMethod = zenkraftShippingHelper.buildEDDMapFromResponse(apiResult.data);
                        zenkraftShippingHelper.updateSessionEDD(eddPerMethod, shipment.UUID);
                    } else if (!apiResult.success) {
                        zenkraftShippingHelper.updateSessionShippingRates(null, shipment.UUID);
                        zenkraftShippingHelper.updateSessionEDD(null, shipment.UUID);
                        logger.error('Zenkraft rate API error: {0}', apiResult.error);
                    }
                }
            }
        } catch (e) {
            logger.error('Zenkraft shipping calculation exception: {0}', e.message);
        }

        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            try {
                var allEDD = {};
                try { allEDD = JSON.parse(session.privacy.zenkraftEDD) || {}; } catch (eddParseErr) { allEDD = {}; }
                var shipmentEDD = allEDD[shipment.UUID] || {};
                shipment.custom.zenkraftEstimatedArrivalTime = shipmentEDD[shippingMethod.custom.zenkraftID] || null;
            } catch (eddErr) {
                logger.error('Failed to apply Zenkraft EDD to shipment: {0}', eddErr.message);
            }
        } else {
            shipment.custom.zenkraftEstimatedArrivalTime = null;
        }
    }

    if (missingRequiredData && !isMultiShipment) {
        logger.debug('Missing required data.');
        return new Status(Status.OK);
    }

    if (!empty(session.privacy.zenkraftCosts)) {
        try {
            var allShipmentRates = JSON.parse(session.privacy.zenkraftCosts);
            var applyIt = currentShipments.iterator();
            while (applyIt.hasNext()) {
                var s = applyIt.next();
                var shipmentRates = allShipmentRates[s.UUID];
                if (shipmentRates) {
                    zenkraftShippingHelper.calculateShippingCost(s, shipmentRates);
                } else if (isMultiShipment && s.productLineItems.size() === 0) {
                    var emptyShipmentLineItems = s.shippingLineItems.iterator();
                    while (emptyShipmentLineItems.hasNext()) {
                        emptyShipmentLineItems.next().setPriceValue(0);
                    }
                    logger.debug('Applied $0 cost for empty shipment: ' + s.UUID + ', shippingTotalPrice: ' + s.shippingTotalPrice);
                } else {
                    logger.warn('No Zenkraft rates and not an empty multi-shipment for UUID: ' + s.UUID + '. Price not updated.');
                }
            }
        } catch (e) {
            logger.error('Failed to apply Zenkraft session rates: {0}', e.message);
        }
    } else {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('OOTB shipping costs are applied.');
    }

    return new Status(Status.OK);
}

exports.calculate = calculate;
