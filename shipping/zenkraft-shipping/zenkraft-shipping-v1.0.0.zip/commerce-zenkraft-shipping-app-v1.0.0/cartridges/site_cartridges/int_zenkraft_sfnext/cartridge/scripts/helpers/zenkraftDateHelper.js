/* global dw, empty */

/**
 * Returns the higher lead time of the current basket
 * @return {number} leadTime
 */
var getLeadTime = function filterleadTime() {
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var Site = require('dw/system/Site');
    var leadTime = Site.getCurrent().getCustomPreferenceValue('zenkraftCompanyWideLeadTime');
    if (!currentBasket) {
        return leadTime;
    }
    var productCategoryTime = 0;
    var productLineItemsArray = currentBasket.getProductLineItems().toArray();
    if (!empty(productLineItemsArray)) {
        productLineItemsArray.forEach(function (productLineItem) {
            var category = productLineItem.getCategory();
            var product = productLineItem.getProduct();
            if (product && product.isVariant()) {
                product = product.getMasterProduct();
            }
            var catCustomData = (category && category.getCustom()) || null;
            var prodCustomData = (product && product.getCustom()) || null;
            if (catCustomData && !empty(catCustomData.zenkraftLeadTime) && catCustomData.zenkraftLeadTime > productCategoryTime) {
                productCategoryTime = catCustomData.zenkraftLeadTime;
            }
            if (prodCustomData && !empty(prodCustomData.zenkraftLeadTime) && prodCustomData.zenkraftLeadTime > productCategoryTime) {
                productCategoryTime = prodCustomData.zenkraftLeadTime;
            }
        });
    }
    if (productCategoryTime > leadTime) {
        leadTime += productCategoryTime;
    }
    return leadTime;
};

/**
 * Returns a date/time string formatted for display on cart and checkout.
 * Returns "Tomorrow D Mon" if the date is tomorrow, otherwise "Day D Mon".
 *
 * @param {Date} date date/time to format
 * @return {string} Formatted date/time
 */
var getFormattedDateTime = function formatDateTime(date) {
    var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var thisTomorrow = new Date();
    var formattedDate = [
        days[date.getDay()],
        date.getDate(),
        months[date.getMonth()]
    ].join(' ');
    thisTomorrow.setDate(thisTomorrow.getDate() + 1);

    // return Tomorrow if date is tomorrow
    if (date.getDate() === thisTomorrow.getDate() &&
        date.getMonth() === thisTomorrow.getMonth() &&
        date.getFullYear() === thisTomorrow.getFullYear()) {
        formattedDate = 'Tomorrow '
        + date.getDate() + ' '
        + months[date.getMonth()];
    }

    return formattedDate;
};

/**
 * Checks to see if current time is after the configured cutoff time.
 *
 * @return {boolean} true if current time is after the zenkraftEDDCutoffTime preference, false otherwise
 */
var isAfterCutoffDate = function isAfterCutoffDate() {
    var Site = require('dw/system/Site');
    var cutoffDatePref = Site.getCurrent().getCustomPreferenceValue('zenkraftEDDCutoffTime');
    var isAfterCutoff = false;
    var today;
    var cutoffDate;

    if (!empty(cutoffDatePref)) {
        today = new Date();
        cutoffDate = new Date(
            today.getFullYear(),
            today.getMonth(),
            today.getDate(),
            cutoffDatePref.getHours(),
            cutoffDatePref.getMinutes(),
            0
        );

        if (today.getTime() > cutoffDate.getTime()) {
            isAfterCutoff = true;
        }
    }

    return isAfterCutoff;
};

/**
 * Returns the ship date as a YYYY-MM-DD string, accounting for cutoff time and lead time.
 * @returns {string} Ship date in YYYY-MM-DD format
 */
function getShipDate() {
    var date = new Date();
    if (isAfterCutoffDate()) {
        date.setDate(date.getDate() + 1);
    }
    var leadDate = getLeadTime();
    if (!empty(leadDate)) {
        date.setDate(date.getDate() + leadDate);
    }
    var day = date.getDate().toString();
    if (day.length === 1) {
        day = '0' + day;
    }
    var month = (date.getMonth() + 1).toString();
    if (month.length === 1) {
        month = '0' + month;
    }
    return date.getFullYear().toString() + '-' + month + '-' + day;
}

exports.getLeadTime = getLeadTime;
exports.isAfterCutoffDate = isAfterCutoffDate;
exports.getFormattedDateTime = getFormattedDateTime;
exports.getShipDate = getShipDate;
