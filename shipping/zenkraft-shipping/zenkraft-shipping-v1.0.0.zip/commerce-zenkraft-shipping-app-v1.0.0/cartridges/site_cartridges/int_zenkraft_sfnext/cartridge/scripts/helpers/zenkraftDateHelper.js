/* global dw, empty */
var Resource = require('dw/web/Resource');
var Calendar = require('dw/util/Calendar');
var StringUtils = require('dw/util/StringUtils');

/**
 * Convert YYYY-MM-DD date string to SFCC date
 * @param {string} dateString - Date string
 * @return {date} - Converted date
 */
function convertDate(dateString) {
    var dateSlice = dateString.match('[0-9]{4}-[0-9]{2}-[0-9]{2}');
    var dateArray = dateSlice[0].split('-');
    return new Date(dateArray[0], parseInt(dateArray[1], 10) - 1, dateArray[2]);
}

/**
 * Convert YYYY-MM-DD HH:MM:SS date string to SFCC date and time
 * @param {string} dateString - Input daet string
 * @return {date} - Converted time
 */
function convertTime(dateString) {
    var date = convertDate(dateString);
    var timeSlice = dateString.match('[0-9]{2}:[0-9]{2}:[0-9]{2}');
    var timeArray = timeSlice[0].split(':');
    date.setHours(timeArray[0]);
    date.setMinutes(timeArray[1]);
    date.setSeconds(timeArray[2]);
    return date;
}

/**
 * Returns the higher lead time of the current basket
 * @return {integer} leadTime
 */
var getLeadTime = function filterleadTime() {
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var Site = require('dw/system/Site');
    var leadTime = Site.getCurrent().getCustomPreferenceValue('zenkraftCompanyWideLeadTime');
    if (!currentBasket) {
        return leadTime;
    }
    var productCategoryTime = 0;
    var productLineItemsArray = currentBasket.getProductLineItems().toArray();
    if (!empty(productLineItemsArray)) {
        productLineItemsArray.forEach(function (productLineItem) {
            var category = productLineItem.getCategory();
            var product = productLineItem.getProduct();
            if (product.isVariant()) {
                product = product.getMasterProduct();
            }
            var catCustomData = (category && category.getCustom()) || null;
            var prodCustomData = (product && product.getCustom()) || null;
            if (catCustomData && !empty(catCustomData.zenkraftLeadTime) && catCustomData.zenkraftLeadTime > leadTime) {
                productCategoryTime = catCustomData.zenkraftLeadTime;
            }
            if (prodCustomData && !empty(prodCustomData.zenkraftLeadTime) && prodCustomData.zenkraftLeadTime > leadTime) {
                productCategoryTime = prodCustomData.zenkraftLeadTime;
            }
        });
    }
    if (productCategoryTime > 0) {
        leadTime += productCategoryTime;
    }
    return leadTime;
};

/**
 * Returns a date/time string formatted for the public tracking page
 *
 * @param {Date} date date/time to format
 * @return {string} Formatted date/time
 */
var getFormattedDateTime = function formatDateTime(date) {
    var thisDate = date;
    var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    // eslint-disable-next-line no-unused-vars, max-len
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var thisTomorrow = new Date();
    var formattedDate = [
        days[thisDate.getDay()],
        thisDate.getDate(),
        months[thisDate.getMonth()]
    ].join(' ');
    thisTomorrow.setDate(thisTomorrow.getDate() + 1);

    // return Tomorrow if date is tomorrow
    if (thisDate.getDate() === thisTomorrow.getDate() &&
        thisDate.getMonth() === thisTomorrow.getMonth() &&
        thisDate.getFullYear() === thisTomorrow.getFullYear()) {
        formattedDate = 'Tomorrow '
        + thisDate.getDate() + ' '
        + months[thisDate.getMonth()];
    }

    return formattedDate;
};

var getCalTime = function getCalTime(h) {
    var Site = require('dw/system/Site');

    var calHours = Site.getCurrent().getCalendar();
    var date = calHours.getTime();
    var hours = h.split(':');
    date.setHours(hours[0]);
    date.setMinutes(hours[1]);
    calHours.setTime(date);

    return calHours;
};

/**
 * Returns a date/time string formatted for the public tracking page
 * from an ISO String
 *
 * @param {string} s ISO String
 *
 * @return {string} Formatted date/time
 */
var parseISOString = function parseISOString(s) {
    var b = s.split(/\D+/);
    var thisdate = new Date(Date.UTC(b[0], --b[1], b[2], b[3], b[4], b[5]));

    var calendar = new Calendar();
    calendar.setTime(thisdate);

    var dateformatting = Resource.msg('datetime.dateformatting', 'tracking', null);
    return StringUtils.formatCalendar(calendar, dateformatting);
};

/**
 * Returns true if the given date falls on a weekend (Saturday or Sunday).
 * Uses the numeric day value from Date.getDay() rather than a formatted
 * display label, which can read "Tomorrow" instead of a weekday name.
 *
 * @param {Date} date - Date to check
 * @returns {boolean} - True if date is Saturday (6) or Sunday (0)
 */
function isWeekend(date) {
    var day = date.getDay();
    return day === 0 || day === 6;
}

/**
 * Get future date from delivery dates
 * Iterates calendar days starting from firstDate and collects `length` allowed
 * delivery dates. When includeWeekends is false, Saturday and Sunday are skipped
 * based on Date.getDay() (0 = Sun, 6 = Sat), NOT on the formatted display label.
 * @param {array} array - Input array
 * @param {*} length - Length of the future dates array
 * @param {*} i - index
 * @param {*} firstDate - First available date
 * @param {boolean} includeWeekends - Whether to include weekends in future delivery dates
 * @returns {array} - Filtered array
 */
function getFutureDateDeliveryDates(array, length, i, firstDate, includeWeekends) {
    var collected = array.length;
    var offset = i;

    while (collected < length) {
        var futureDateDelivery = new Date(firstDate.getTime() + (offset * 86400000));

        if (!includeWeekends && isWeekend(futureDateDelivery)) {
            offset++;
            continue; // eslint-disable-line no-continue
        }

        array.push({
            formatedDate: getFormattedDateTime(futureDateDelivery),
            date: futureDateDelivery.getTime().toString()
        });

        collected++;
        offset++;
    }
    return array;
}

/**
* Checks to see if current time is after the configured
* cutoff time.
*
* @return {boolean} true/false to indicate if current time is after cutoff time
*/
var isAfterCutoffDate = function formatDateTime() {
    var Site = require('dw/system/Site');
    var cutoffDatePref = Site.getCurrent().getCustomPreferenceValue('zenkraftEDDCutoffTime');
    var isAfterCutoff = false;
    var today;
    var todayTime;
    var cutoffTime;
    var timeZone;

    // if the cutoff date is set, check it
    if (!empty(cutoffDatePref)) {
        // get today's date/time
        today = new Date();
        timeZone = Site.getCurrent().getTimezone();
        timeZone = Site.getCurrent().getTimezoneOffset();

        // adjust for configured time zone
        today.setTime(today.getTime() + timeZone);
        todayTime = today.getTime();

        // for cutoff time, set current day, but use hours/minutes from pref
        cutoffDatePref.setDate(today.getDate());
        cutoffDatePref.setMonth(today.getMonth());
        cutoffDatePref.setYear(today.getYear());
        cutoffDatePref.setTime(cutoffDatePref.getTime() + timeZone);
        cutoffTime = cutoffDatePref.getTime();

        // check if current time is after the cutoff
        if (todayTime > cutoffTime) {
            isAfterCutoff = true;
        }
    }

    return isAfterCutoff;
};

/**
 * Returns the ship date as a YYYY-MM-DD string, accounting for cutoff time and lead time.
 * @returns {string} Ship date in YYYY-MM-DD format
 */
function getShipDate() {
    var date = new Date();
    if (isAfterCutoffDate()) {
        date.setDate(date.getDate() + 1);
    }
    var leadDate = getLeadTime();
    if (!empty(leadDate)) {
        date.setDate(date.getDate() + leadDate);
    }
    var day = date.getDate().toString();
    if (day.length === 1) {
        day = '0' + day;
    }
    var month = (date.getMonth() + 1).toString();
    if (month.length === 1) {
        month = '0' + month;
    }
    return date.getFullYear().toString() + '-' + month + '-' + day;
}

exports.parseISOString = parseISOString;
exports.getCalTime = getCalTime;
exports.getLeadTime = getLeadTime;
exports.getFutureDateDeliveryDates = getFutureDateDeliveryDates;
exports.convertDate = convertDate;
exports.convertTime = convertTime;
exports.isAfterCutoffDate = isAfterCutoffDate;
exports.getFormattedDateTime = getFormattedDateTime;
exports.getShipDate = getShipDate;
