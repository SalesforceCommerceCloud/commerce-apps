'use strict';

/* global empty */
var CacheMgr = require('dw/system/CacheMgr');
var Logger = require('dw/system/Logger');
var ProductMgr = require('dw/catalog/ProductMgr');
var Site = require('dw/system/Site');
var ShippingMgr = require('dw/order/ShippingMgr');

var zenkraftHelper = require('./zenkraftShippingHelper');
var dateHelper = require('./zenkraftDateHelper');

var logger = Logger.getLogger('zenkraft', 'zenkraftEstimatePDP');
var CACHE_ID = 'ZenkraftPDPDeliveryEstimate';

// ─── Request Builder ────────────────────────────────────────────────────────

/**
 * Groups product delivery estimates by destination (countryCode|postalCode).
 * One Zenkraft rate API call is made per group.
 *
 * @param {Array} productDeliveryEstimates - ProductDeliveryEstimateWO array from the hook result
 * @returns {Array} Array of { destination, estimates[] }
 */
function groupByDestination(productDeliveryEstimates) {
    var groupMap = {};
    for (var i = 0; i < productDeliveryEstimates.length; i++) {
        var pde = productDeliveryEstimates[i];
        var dest = pde.destination || {};
        if (!dest.countryCode) { continue; } // eslint-disable-line no-continue
        var key = String(dest.countryCode).toUpperCase() + '|' + (dest.postalCode || '');
        if (!groupMap[key]) {
            groupMap[key] = { destination: dest, estimates: [] };
        }
        groupMap[key].estimates.push(pde);
    }
    return Object.keys(groupMap).map(function (k) { return groupMap[k]; });
}

/**
 * Builds a map of SFCC shipping method ID → ShippingMethod object.
 * ShippingMgr has no getShippingMethod(id) — getAllShippingMethods() is the correct API.
 * Called once per mapToResult invocation to avoid repeated iteration.
 *
 * @returns {Object} { [shippingMethodId]: dw.order.ShippingMethod }
 */
function buildMethodsById() {
    var methodsById = {};
    var allMethods = ShippingMgr.getAllShippingMethods();
    var it = allMethods.iterator();
    while (it.hasNext()) {
        var method = it.next();
        methodsById[method.ID] = method;
    }
    return methodsById;
}

/**
 * Returns the c_zenkraftID for a SFCC shipping method, or null if not configured.
 * @param {string} shippingMethodId
 * @param {Object} methodsById - map built by buildMethodsById()
 * @returns {string|null}
 */
function getZenkraftID(shippingMethodId, methodsById) {
    var method = methodsById[shippingMethodId];
    if (!method || !method.custom || empty(method.custom.zenkraftID)) {
        return null;
    }
    return String(method.custom.zenkraftID);
}

/**
 * Returns the markup configuration for a SFCC shipping method.
 * @param {string} shippingMethodId
 * @param {Object} methodsById - map built by buildMethodsById()
 * @returns {{ markupType: string, markup: number }}
 */
function getMethodMarkup(shippingMethodId, methodsById) {
    var method = methodsById[shippingMethodId];
    if (!method) {
        return { markupType: 'Amount', markup: 0 };
    }
    return {
        markupType: method.custom.zenkraftRateMarkupType ? method.custom.zenkraftRateMarkupType.value : 'Amount',
        markup: method.custom.zenkraftRateMarkup || 0
    };
}

/**
 * Builds one package entry per estimate using product custom attributes
 * (dimDepth → length, dimWidth → width, dimHeight → height, dimWeight → weight).
 * Falls back to 1×1×1 + defaultWeight when any dimension attribute is missing.
 *
 * @param {Array} estimates - ProductDeliveryEstimateWO array
 * @param {number} defaultWeight
 * @returns {Array} packages array for the Zenkraft rate request
 */
function buildProductPackages(estimates, defaultWeight) {
    if (!estimates || !estimates.length) {
        return [{ weight: defaultWeight || 1, value: 1, length: 1, width: 1, height: 1 }];
    }

    var packages = [];
    for (var i = 0; i < estimates.length; i++) {
        var pde = estimates[i];
        var product = pde.productId ? ProductMgr.getProduct(String(pde.productId)) : null;
        var weight = defaultWeight || 1;
        var length = 1;
        var width = 1;
        var height = 1;

        if (product) {
            try {
                if (!empty(product.custom.dimWeight)) { weight = zenkraftHelper.extractNumber(product.custom.dimWeight) || weight; }
                if (!empty(product.custom.dimDepth))  { length = zenkraftHelper.extractNumber(product.custom.dimDepth) || length; }
                if (!empty(product.custom.dimWidth))  { width  = zenkraftHelper.extractNumber(product.custom.dimWidth) || width; }
                if (!empty(product.custom.dimHeight)) { height = zenkraftHelper.extractNumber(product.custom.dimHeight) || height; }
            } catch (e) { /* product may not have custom dimension attributes */ }
        } else {
            logger.debug('estimatePDP: product {0} not found, using default package.', pde.productId);
        }

        packages.push({ weight: weight, value: 1, length: length, width: width, height: height });
    }
    return packages;
}

/**
 * Builds a Zenkraft rate API request for a destination group.
 * Uses product dimensions (dimDepth/dimHeight/dimWeight/dimWidth) when available,
 * falling back to 1×1×1 + zenkraftDefaultProductWeight per product.
 * Mirrors buildRateRequest in zenkraftShippingHelper used for checkout.
 *
 * @param {Object} group - { destination: { countryCode, postalCode }, estimates: [...] }
 * @returns {Object} Zenkraft rate request body
 */
function buildRequest(group) {
    var config = zenkraftHelper.getConfig();
    var dest = group.destination;
    var countryCode = dest.countryCode ? String(dest.countryCode).toUpperCase() : '';
    var postalCode = dest.postalCode ? String(dest.postalCode) : '';

    var preferenceAccounts = config.shippingAccount ? config.shippingAccount.split(',') : [];
    var shippingAccount;
    if (config.useMultipleAccounts) {
        shippingAccount = preferenceAccounts.length === 1 ? preferenceAccounts[0] : preferenceAccounts;
    } else {
        shippingAccount = preferenceAccounts[0] || config.shippingAccount;
    }

    var req = {
        shipment: {
            test: !config.isProdMode,
            debug: config.debugLog,
            carrier: config.carrier,
            type: 'outbound',
            dim_units: config.dimUnits,
            weight_units: config.weightUnits,
            currency: config.currencyCode,
            packaging: config.packagingType,
            shipping_account: shippingAccount,
            service_type: config.rateServiceType || null,
            special_services: !empty(config.specialServices) ? config.specialServices.split(',') : '',
            ship_date: dateHelper.getShipDate(),
            sender: {
                street1: config.senderStreet,
                city: config.senderCity,
                state: config.senderStateCode,
                postal_code: config.senderPostalCode ? config.senderPostalCode.replace(/\s+/g, '') : '',
                country: config.senderCountryCode
            },
            recipient: {
                street1: '',
                city: '',
                state: '',
                postal_code: postalCode,
                country: countryCode
            },
            packages: buildProductPackages(group.estimates, config.defaultWeight)
        }
    };
    zenkraftHelper.applyAdvancedJSON(req, config, countryCode);
    return req;
}

// ─── Cache ───────────────────────────────────────────────────────────────────

/**
 * Builds a cache key for a destination group.
 * Format: siteId|countryCode|postalCode|productId1,productId2,...
 *
 * @param {Object} group - { destination: { countryCode, postalCode }, estimates: [...] }
 * @returns {string}
 */
function buildCacheKey(group) {
    var dest = group.destination || {};
    var estimates = group.estimates || [];
    var productIds = {};
    for (var i = 0; i < estimates.length; i++) {
        if (estimates[i] && estimates[i].productId) {
            productIds[String(estimates[i].productId).trim()] = true;
        }
    }
    var productsPart = Object.keys(productIds).sort().join(',');
    return [Site.getCurrent().getID(), dest.countryCode || '', dest.postalCode || '', productsPart].join('|');
}

/**
 * Retrieves a cached Zenkraft rate response.
 * Returns null if the cache region is not configured or the entry does not exist.
 *
 * @param {string} key
 * @returns {Object|null}
 */
function cacheGet(key) {
    try {
        var cache = CacheMgr.getCache(CACHE_ID);
        if (!cache) { return null; }
        var cached = cache.get(key);
        if (!cached) { return null; }
        return typeof cached === 'string' ? JSON.parse(cached) : cached;
    } catch (e) {
        logger.warn('PDP estimate cache get failed for key {0}: {1}', key, e.message);
        return null;
    }
}

/**
 * Stores a Zenkraft rate response in the cache.
 * Silently skips if the cache region is not configured.
 *
 * @param {string} key
 * @param {Object} value
 */
function cachePut(key, value) {
    try {
        var cache = CacheMgr.getCache(CACHE_ID);
        if (!cache) { return; }
        cache.put(key, JSON.stringify(value));
    } catch (e) {
        logger.warn('PDP estimate cache put failed for key {0}: {1}', key, e.message);
    }
}

/**
 * Invalidates the PDP estimate cache.
 * Pass a specific key to remove one entry, or omit to flush the entire region.
 *
 * @param {string} [key] - Cache key built by buildCacheKey(). Omit to invalidate all.
 */
function cacheInvalidate(key) {
    try {
        var cache = CacheMgr.getCache(CACHE_ID);
        if (!cache) {
            logger.warn('PDP estimate cache region {0} not found — nothing to invalidate.', CACHE_ID);
            return;
        }
        if (key) {
            cache.invalidate(key);
            logger.info('Zenkraft PDP estimate cache invalidated for key: {0}', key);
        } else {
            cache.invalidate();
            logger.info('Zenkraft PDP estimate cache fully invalidated.');
        }
    } catch (e) {
        logger.warn('PDP estimate cache invalidate failed: {0}', e.message);
    }
}

// ─── Response Mapper ─────────────────────────────────────────────────────────

/**
 * Builds a lookup map from Zenkraft service_type to the full rate object.
 * @param {Object} apiResponse - Raw Zenkraft rate API response
 * @returns {Object} { [service_type]: rateObject }
 */
function buildRatesByServiceType(apiResponse) {
    var map = {};
    var rates = Array.isArray(apiResponse) ? apiResponse
        : (apiResponse && Array.isArray(apiResponse.rates) ? apiResponse.rates : null);
    if (!rates) { return map; }
    rates.forEach(function (rate) {
        if (rate.service_type) { map[rate.service_type] = rate; }
    });
    return map;
}

/**
 * Maps Zenkraft rate API response to a group's ShippingOptionWO entries.
 * Mutates opt.price, opt.currency, opt.carrier, and opt.deliveryWindow in place.
 * Options left unpopulated are dropped by the platform before serialization.
 *
 * @param {Object} apiResponse - Raw Zenkraft rate API response ({ rates: [...] })
 * @param {Object} group - { destination, estimates: [ProductDeliveryEstimateWO] }
 * @returns {number} Count of populated shipping options
 */
function mapToResult(apiResponse, group, methodsById) {
    if (!methodsById) { methodsById = buildMethodsById(); }
    var ratesByServiceType = buildRatesByServiceType(apiResponse);
    var populated = 0;

    for (var i = 0; i < group.estimates.length; i++) {
        var pde = group.estimates[i];
        var options = pde.shippingOptions;
        if (!options) { continue; }

        for (var j = 0; j < options.length; j++) {
            var opt = options[j];

            var zenkraftID = getZenkraftID(opt.shippingMethodId, methodsById);
            if (!zenkraftID) {
                logger.debug('No c_zenkraftID for method {0}, skipping.', opt.shippingMethodId);
                continue;
            }

            var rate = ratesByServiceType[zenkraftID];
            if (!rate) {
                logger.debug('No Zenkraft rate for service_type {0}, option will be dropped by platform.', zenkraftID);
                continue;
            }

            logger.debug(
                'Zenkraft estimatePDP: matched rate for [{0}][{1}] zenkraftID={2} total_cost={3} carrier={4} estimated_date={5} transit_days={6} delivery_day={7} hasDeliverySlots={8}',
                i, j, zenkraftID,
                rate.total_cost,
                rate.carrier,
                rate.estimated_date || 'MISSING',
                rate.transit_days != null ? rate.transit_days : 'MISSING',
                rate.delivery_day || 'MISSING',
                rate.custom && rate.custom.delivery_slots && rate.custom.delivery_slots.length > 0 ? 'yes' : 'no'
            );

            if (rate.total_cost != null) {
                try {
                    var methodMarkup = getMethodMarkup(opt.shippingMethodId, methodsById);
                    opt.price = zenkraftHelper.getMarkupCost(
                        methodMarkup.markupType,
                        methodMarkup.markup,
                        rate.total_cost
                    ).value;
                } catch (e) {
                    logger.warn('Zenkraft estimatePDP: markup calculation failed for method {0}, using raw carrier cost: {1}', opt.shippingMethodId, e.message);
                    opt.price = Number(rate.total_cost);
                }
            }

            if (rate.currency) { opt.currency = rate.currency; }
            if (rate.carrier) { opt.carrier = rate.carrier; }

            if (rate.estimated_date) {
                var isoDate = rate.estimated_date + 'T12:00:00.000Z';
                opt.deliveryWindow = { startAt: isoDate, endAt: isoDate };
            } else if (rate.custom && rate.custom.delivery_slots && rate.custom.delivery_slots[0]) {
                var slot = rate.custom.delivery_slots[0];
                opt.deliveryWindow = { startAt: slot.start_time, endAt: slot.end_time || slot.start_time };
            }

            logger.debug(
                'Zenkraft estimatePDP: populated [{0}][{1}] method={2} zenkraftID={3} price={4} carrier={5} deliveryEnd={6}',
                i, j, opt.shippingMethodId, zenkraftID, opt.price, opt.carrier,
                rate.estimated_date || 'n/a'
            );

            populated++;
        }
    }

    return populated;
}

module.exports = {
    groupByDestination: groupByDestination,
    buildRequest: buildRequest,
    buildCacheKey: buildCacheKey,
    cacheGet: cacheGet,
    cachePut: cachePut,
    cacheInvalidate: cacheInvalidate,
    buildMethodsById: buildMethodsById,
    mapToResult: mapToResult
};
