'use strict';

/* global empty */
var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var zenkraftService = require('~/cartridge/scripts/services/zenkraftService');
var zenkraftHelper = require('~/cartridge/scripts/helpers/zenkraftShippingHelper');
var estimatePDPHelper = require('~/cartridge/scripts/helpers/zenkraftEstimatePDPHelper');

var logger = Logger.getLogger('zenkraft', 'estimatePDP');

/**
 * sfcc.app.shipping.estimate
 *
 * Populates PDP delivery estimates on the supplied DeliveryEstimatesResultWO skeleton.
 * Calls the Zenkraft rate API once per unique destination (postalCode + countryCode),
 * caches the result, then maps rates to ShippingOptionWO fields:
 * price, currency, carrier, deliveryWindow.
 *
 * @param {Object} result - DeliveryEstimatesResultWO
 * @returns {dw.system.Status}
 */
exports.estimate = function (result) {
    try {
        var config = zenkraftHelper.getConfig();
        if (!config.enabled) {
            return new Status(Status.OK);
        }

        if (!result || !result.productDeliveryEstimates) {
            logger.warn('Zenkraft estimatePDP hook invoked with empty result skeleton.');
            return new Status(Status.OK);
        }

        var estimates = result.productDeliveryEstimates;
        logger.info('Zenkraft estimatePDP: received {0} product estimate(s).', estimates.length);

        var groups = estimatePDPHelper.groupByDestination(estimates);
        var methodsById = estimatePDPHelper.buildMethodsById();
        var populated = 0;

        for (var i = 0; i < groups.length; i++) {
            var group = groups[i];
            var cacheKey = estimatePDPHelper.buildCacheKey(group);
            var apiResponse = estimatePDPHelper.cacheGet(cacheKey);

            if (apiResponse) {
                logger.debug('Zenkraft estimatePDP: cache hit for group {0} key={1}', i, cacheKey);
            } else {
                var rateRequest = estimatePDPHelper.buildRequest(group);
                var rateRequestJSON = JSON.stringify(rateRequest);

                logger.debug('Zenkraft estimatePDP: rate request for group {0}: {1}', i, rateRequestJSON);

                var serviceResult = zenkraftService.call(zenkraftService.API_PATHS.RATE, rateRequestJSON);

                if (serviceResult.status !== 'OK' || empty(serviceResult.object) || serviceResult.object.error) {
                    logger.error(
                        'Zenkraft estimatePDP: rate call failed for group {0}. status={1} error={2}',
                        i,
                        serviceResult.status,
                        serviceResult.object && serviceResult.object.error ? serviceResult.object.error : serviceResult.errorMessage
                    );
                    continue; // eslint-disable-line no-continue
                }

                apiResponse = serviceResult.object;
                estimatePDPHelper.cachePut(cacheKey, apiResponse);

                logger.debug('Zenkraft estimatePDP: API response for group {0}: {1}', i, JSON.stringify(apiResponse));
            }

            var groupPopulated = estimatePDPHelper.mapToResult(apiResponse, group, methodsById);
            logger.info('Zenkraft estimatePDP: populated {0} option(s) for group {1}.', groupPopulated, i);
            populated += groupPopulated;
        }

        logger.info('Zenkraft estimatePDP: total populated {0} shipping option(s).', populated);

        return new Status(Status.OK);
    } catch (e) {
        logger.error('Zenkraft estimatePDP hook failed: {0}\n{1}', e.message, e.stack);
        return new Status(Status.ERROR, 'ZENKRAFT_ESTIMATE_FAILED', 'Zenkraft estimatePDP hook threw: ' + e.message);
    }
};
