# Zenkraft Shipping

Shipping rate calculation, estimated delivery dates, order tracking, and returns powered by Zenkraft.

## Overview

This commerce app integrates Zenkraft with Storefront Next storefronts:

- **Rates and delivery dates.** The site cartridge (`int_zenkraft_sfnext`) fetches real-time carrier rates and estimated delivery dates (EDD) from the Zenkraft API at checkout and on product pages.
- **Collection points.** Shoppers can ship to a carrier drop-off / pick-up location, chosen from a list and a map at checkout.
- **Order tracking.** A tracking bar on the order details page and a standalone tracking page.
- **Returns.** A self-service return flow with return reasons, labels, approval rules, reason photos, and a Return History page.
- **Business Manager setup.** The BM cartridge (`bm_zenkraft`) lets merchants start a Zenkraft trial or connect an existing account, and add carrier accounts, without leaving Business Manager.

The Storefront Next extension replaces the checkout shipping options step, adds the tracking and returns UI, and talks to the cartridge through three custom SCAPI APIs.

## Architecture

```
GET /shipping-methods (checkout)
  → sfcc.app.shipping.quote hook (int_zenkraft_sfnext/cartridge/scripts/hooks/shippingOptions.js)
      → zenkraftShippingHelper.getShippingData()
          → zenkraftService.call(API_PATHS.RATE) → https://api.zenkraft.com (zkkey from credential)
      → overrides method.price with Zenkraft rate + markup when API returns a cost
      → if enableZenkraftEstimatedDeliveryDates: enriches each ShippingMethod with c_estimatedArrivalTime, c_estimated_date, deliveryWindow

dw.order.calculateShipping (basket recalculation)
  → sfcc.app.shipping.calculate hook (int_zenkraft_sfnext/cartridge/scripts/hooks/calculateShipping.js)
      → zenkraftShippingHelper.buildShippingRateRequest()
          → rates against the collection point's address when a drop-off method has one stored
          → if boxing algorithm enabled: zenkraftService.call(API_PATHS.PACK) for package dimensions
      → zenkraftShippingHelper.callZenkraftAPI() with djb2 request-hash deduplication
          → zenkraftService.call(API_PATHS.RATE) for real-time rates
      → rates stored in session.privacy.zenkraftCosts (keyed by shipment UUID)
      → EDD stored in session.privacy.zenkraftEDD (keyed by shipment UUID)
      → zenkraftShippingHelper.calculateShippingCost() applies rate + markup to shipping line item
      → falls back to ShippingMgr.applyShippingCost() when no Zenkraft rates in session
      → syncs or clears the collection-point attributes on each shipment

PDP product page
  → sfcc.app.shipping.estimate hook (int_zenkraft_sfnext/cartridge/scripts/hooks/estimatePDP.js)
      → groups ProductDeliveryEstimateWO entries by destination (countryCode + postalCode)
      → per group: checks ZenkraftPDPDeliveryEstimate cache (key: siteId|countryCode|postalCode|productIds, TTL 1 h)
          → cache miss: zenkraftService.call(API_PATHS.RATE) with default package dimensions (1×1×1, zenkraftDefaultProductWeight)
      → maps matched rates to ShippingOptionWO fields: price (with markup), currency, carrier, deliveryWindow

POST /orders (order placement)
  → dw.ocapi.shop.order.beforePOST hook (beforePlaceOrder.js): copies the collection point's address onto drop-off shipments
  → dw.ocapi.shop.order.afterPOST hook (afterPlaceOrder.js): clears the basket-only rate cache attributes

Custom SCAPI APIs (int_zenkraft_sfnext/cartridge/rest-apis, scope c_zenkraft)
  → zenkraft-dopu     getDropOffLocations
  → zenkraft-track    getZenkraftTracking
  → zenkraft-returns  returns, returnsHistory, getReturnMethods, getShippingLabel,
                      getZenkraftReturnLabel, getCombinedLabel, updateMissingData, uploadReasonImage
  → GET /orders with c_returnFlow → dw.ocapi.shop.order.modifyGETResponse hook (orderForReturn.js):
      adds return reasons, existing returns and missing order data to the order response
```

## Features

**Rates and delivery dates**
- Real-time Zenkraft rate API calls via the `zenkraft.api` SFCC service
- Request deduplication: skips the API call when the basket state has not changed (djb2 hash)
- Estimated delivery dates (EDD) with configurable cutoff time and company-wide lead time
- Per-product and per-category lead time override
- Rate markup per shipping method (fixed amount or percentage)
- Optional boxing algorithm using package profiles (custom objects)
- Multiple shipping accounts, and a per-method shipping account
- PDP delivery estimates: real-time rate lookup per destination, cached for 1 hour
- Native methods fallback if Zenkraft returns no results
- Production/test mode toggle

**Collection points (drop-off / pick-up)**
- Shipping methods flagged as drop-off methods ask the shopper to choose a collection point at checkout
- List of nearby locations with a Google map (list only when no Google Maps key is configured)
- Rates are calculated against the collection point's address; the order ships to it
- Works with multi-shipment checkout: one collection point per shipment

**Order tracking**
- Tracking bar on the order details page
- Standalone tracking page (`/zenkraft-tracking?orderNo=…`), optionally login-only
- Optional proof of delivery details and separate tracking accounts per carrier

**Returns**
- Self-service return wizard (`/zenkraft-create-return?orderNo=…`): items, reasons, return method and label
- Returns stored in the instance (`sfcc` handler: a `zenkraftReturn` custom object per return and a `zenkraftReturnLineItem` custom object per returned item) or in the Zenkraft API (`zkapi` handler)
- Return reasons per product category, with optional photo per reason
- Approval rules, non-returnable categories and a return window
- Form for order details the return label needs but the order is missing
- Return History page in My Account (`/account/zenkraft-returns`), linked from Order History and from each order's returns
- Job that tracks the shipments of returns stored in the instance (`sfcc` handler), with an `app.zenkraft.returns` hook your own cartridge can implement to issue refunds

**Business Manager**
- **Merchant Tools > Zenkraft > Account Setup**: start a Zenkraft trial or connect an existing account
- **Merchant Tools > Zenkraft > Shipping Account Setup**: Zenkraft test UPS / FedEx accounts and your own carrier accounts
- Component visibility toggles in the app settings (see [Component Visibility](#component-visibility))

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance
- Storefront Next storefront
- A Zenkraft account and API key (you can start a trial from Business Manager after installing)
- Optional: a Google Maps API key in the storefront config, for the collection-point map

## Installation

1. Install the app from the Commerce App Registry in Business Manager
2. Add `int_zenkraft_sfnext` to your site's cartridge path under Administration > Sites > Manage Sites > *your site* > Settings
3. Add `bm_zenkraft` to the Business Manager cartridge path under Administration > Sites > Manage Sites > Business Manager > Settings. To run the `Zenkraft-Update-Return-Cases` job, add `int_zenkraft_sfnext` there as well
4. Give your Business Manager role access to the Zenkraft module under Administration > Organization > Roles & Permissions > *role* > Business Manager Modules
5. Add the `c_zenkraft` scope to the SLAS client your storefront uses, so the storefront can call the app's custom APIs
6. Complete the [Post-Installation Checklist](#post-installation-checklist)

## Configuration

### Zenkraft Account

**Merchant Tools > Zenkraft > Account Setup** connects the app to Zenkraft:

- **New to Zenkraft:** fill in the trial form. Zenkraft creates a trial account and emails you a confirmation. Business Manager scripts can't write service credentials, so the API key is written to `IMPEX/src/instance/zenkraft-credentials.zip`; run the `Zenkraft-Import-Credentials` job (Administration > Operations > Jobs) to apply it to the `zenkraft.credentials` service credential. The job deletes the file afterwards.
- **Existing account:** choose the existing-account option. It links to Administration > Operations > Services > Credentials, where you enter your API key in the **Password** field of `zenkraft.credentials`.

Once connected, the page shows the account's contact and email and, for a trial, its expiry date.

**Merchant Tools > Zenkraft > Shipping Account Setup** manages the carrier accounts Zenkraft rates and ships with:

- Enable a Zenkraft test UPS or FedEx account to try rates, labels and tracking before connecting your own.
- Add your own UPS (connected through UPS OAuth) or FedEx account, and remove accounts.

Shipping accounts are stored as `zenkraftShippingAccount` custom objects. Use their IDs in the `zenkraftShippingAccount` site preference or the `zenkraftShippingMethodAccountID` shipping method attribute.

### Services

The app defines one SFCC service in `impex/install/services.xml`:

| Service ID | Purpose |
|---|---|
| `zenkraft.api` | Single service definition used for all Zenkraft API calls (rates, packing, drop-off locations, tracking, returns, account setup). The path is appended in code at call time. |

The Zenkraft API base URL (`https://api.zenkraft.com`) and API key are configured on the `zenkraft.credentials` service credential. The API key is stored in the credential **Password** field and is passed as the `zkkey` request header. The install IMPEX ships the credential without a password, so it never overwrites a key you have already set.

### Jobs

`impex/install/jobs.xml` adds two jobs. Neither has an active schedule; run or schedule them under Administration > Operations > Jobs.

| Job | Scope | What it does |
|---|---|---|
| `Zenkraft-Import-Credentials` | Organization | Imports `zenkraft-credentials.zip` written by Account Setup into the `zenkraft.credentials` service credential, then deletes the file. Run it once after starting a trial. |
| `Zenkraft-Update-Return-Cases` | Site | Tracks the shipments of returns stored in the instance (`sfcc` handler) until they are delivered, and stores each `zenkraftReturnLineItem`'s tracking stage, status and estimated delivery. When it sees a return shipment's stage change to in transit, it calls `refund(returnLineItem)` on the `app.zenkraft.returns` hook, if your own cartridge registers it (see [Refunds](#refunds)). Returns handled by the Zenkraft API aren't stored in the instance, so the job doesn't track them. Schedule it to run regularly. Requires `int_zenkraft_sfnext` on the Business Manager cartridge path. |

### Site Preferences

Import `impex/install/sites/SITEID/preferences.xml` (replacing `SITEID` with your site ID) to create the preference group entries with default values, including a starter `zenkraftReturnReasonsConfig`. All preferences are configured in Business Manager under Merchant Tools > Site Preferences > Custom Preferences.

Preferences are grouped into five sections:

**Zenkraft General**

| Preference | Type | Description |
|---|---|---|
| `enableZenkraftShippingRates` | Boolean | Master toggle — enables Zenkraft rate API calls and replaces BM-configured rates |
| `enableZenkraftBoxingAlgorithm` | Boolean | Use package profiles to determine package dimensions |
| `zenkraftNativeMethodsFallback` | Boolean | Fall back to native SFCC methods if Zenkraft returns none |
| `zenkraftProdMode` | Boolean | Production mode — leave off for sandbox |
| `zenkraftDebugLog` | Boolean | Enable debug logs in the Zenkraft API admin |
| `zenkraftCarrier` | String | Default carrier ID (e.g. `fedex`, `dhl`) |
| `zenkraftShippingAccount` | String | Shipping account ID (comma-separated for multiple) |
| `useZenkraftMultipleShippingAccounts` | Boolean | Send multiple account IDs in rate requests |
| `zenkraftRateServiceType` | String | Optional single service type filter |
| `zenkraftRateSpecialServices` | String | Comma-separated special service values |
| `zenkraftPackagingType` | String | Packaging type per Zenkraft API docs (default `your_packaging`) |
| `zenkraftCurrencyCode` | String | Currency code for rate requests (default `USD`) |
| `zenkraftDimensionUnits` | Enum | `IN` (default) or `CM` |
| `zenkraftWeightUnits` | Enum | `LB` (default) or `KG` |
| `zenkraftDefaultProductWeight` | String | Fallback weight when a product has no `dimWeight` attribute |
| `zenkraftCustomAuth` | Enum | Authentication mode: `APIKEY` (default) or `OCAPI` |
| `zenkraftSenderStreet` | String | Sender address — street |
| `zenkraftSenderCity` | String | Sender address — city |
| `zenkraftSenderStateCode` | String | Sender address — state code |
| `zenkraftSenderPostalCode` | String | Sender address — postal code |
| `zenkraftSenderCountryCode` | String | Sender address — country code |

**Zenkraft Estimated Delivery**

| Preference | Type | Description |
|---|---|---|
| `enableZenkraftEstimatedDeliveryDates` | Boolean | Display EDD on checkout shipping options |
| `zenkraftEDDCutoffTime` | Datetime | After this time of day, estimated delivery dates will have a day added to them. For example, if this time is set as 5pm, then the estimated delivery date will add an extra day. |
| `zenkraftCompanyWideLeadTime` | Integer | Default lead time in days before delivery calculation starts |
| `zenkraftPackageConfig` | Boolean | Consolidate all items into a single package for rate requests |

**Zenkraft Advanced Configuration**

| Preference | Type | Description |
|---|---|---|
| `zenkraftAdvancedJSON` | Boolean | Use the advanced JSON object for rate request settings |
| `zenkraftAdvancedJSONObject` | Text | Advanced JSON configuration for rate requests |

**Zenkraft Tracking Settings**

| Preference | Type | Description |
|---|---|---|
| `enableZenkraftTrackingOnOrderDetailsPage` | Boolean | Show the tracking bar on the order details page |
| `enableZenkraftTrackingPage` | Boolean | Enable the tracking page at `/zenkraft-tracking?orderNo=<orderNo>` |
| `zenkraftTrackingPageRequiresLogin` | Boolean | Only return tracking data to logged-in shoppers |
| `enableZenkraftPOD` | Boolean | Add proof of delivery details to tracking data when Zenkraft returns them |
| `zenkraftTrackingAccountSettingsJSON` | Text | Tracking settings per carrier, e.g. `{"fedex": {"DEBUG": "true", "SHIPPING_ACCOUNT": "1234567890"}}` |

**Zenkraft Returns**

| Preference | Type | Description |
|---|---|---|
| `zenkraftReturnsHandler` | Enum | `sfcc` (default): returns are stored in the instance as `zenkraftReturn` / `zenkraftReturnLineItem` custom objects; `zkapi`: returns are created in the Zenkraft API |
| `zenkraftReturnReasonsConfig` | Text | Return reasons and sub-reasons per product category (see [Return Reasons](#return-reasons)) |
| `zenkraftReturnsShippingAccount` | String | Shipping account ID for return labels |
| `zenkraftReturnsCarrier` | String | Carrier ID for returns (default `fedex`) |
| `zenkraftReturnsShippingService` | String | Zenkraft service ID for returns (default `fedex_ground`) |
| `zenkraftReturnsPackagingType` | String | Packaging type for returns (default `your_packaging`) |
| `zenkraftReturnsDimensionUnits` | Enum | `IN` (default) or `CM` |
| `zenkraftReturnsWeightUnits` | Enum | `LB` (default) or `KG` |
| `zenkraftReturnsDefaultProductWeight` | String | Weight used when a product has none (default `1.0`) |
| `zenkraftReturnsCurrencyCode` | String | Currency code for returns (default `USD`) |
| `zenkraftReturnLabelFileType` | String | Label file type, e.g. `PDF` (default), `GIF`, `JPG` (SFCC handler only) |
| `zenkraftRecipientCompany`, `zenkraftRecipientName`, `zenkraftRecipientPhone`, `zenkraftRecipientEmail` | String | Return-to contact (your warehouse) |
| `zenkraftRecipientStreet`, `zenkraftRecipientCity`, `zenkraftRecipientStateCode`, `zenkraftRecipientPostalCode`, `zenkraftRecipientCountryCode` | String | Return-to address (your warehouse) |
| `zenkraftReturnsRequireLogin` | Boolean | Only logged-in shoppers can return items |
| `zenkraftOrderDaysAvailableForReturn` | Integer | Days after order creation in which a return can be created; `0` (default) means no limit |
| `zenkraftCatalogCategoriesForNonReturnableItems` | String | Comma-separated category IDs (no spaces) whose products can't be returned |
| `zenkraftReturnsApprovalRequire` | Boolean | Every return needs approval before the label can be downloaded |
| `zenkraftReturnApprovalCatalogCategories` | String | Comma-separated category IDs (no spaces) that need approval |
| `zenkraftReturnApprovalCustomerGroups` | String | Comma-separated customer group IDs (no spaces) that need approval |
| `zenkraftReturnRequiredFields` | Text | Order and shipping address fields a return needs: `{"order": [{"attribute": …, "field": …}], "shippingAddress": [ … ]}`. Missing values are asked for in the return wizard |
| `zenkraftReturnReasonPhotoFormats` | Set of strings | File formats accepted for reason photos |
| `zenkraftReturnReasonPhotoMaxSize` | Integer | Maximum reason photo size (KB) |
| `zenkraftReturnReasonPhotoImageScale` | Double | Maximum photo dimension before upload |
| `zenkraftSingleShipmentForMultipleReturnLineItems` | Boolean | Create a single label for multiple items |
| `zenkraftReturnSpecialServices` | String | Comma-separated special services for return labels |
| `zenkraftShippingPreference` | String | Shipping preference sent with return requests |
| `syncReturnWithZenkraft` | Boolean | Also send returns stored in the instance to Zenkraft (`sfcc` handler) |
| `setZenkraftOrderReturnsOneToOneRelation` | Boolean | Relate returns one-to-one with orders (default `true`) |
| `zenkraftNewReturnObjectPerReturn` | Boolean | Create a new Return object for each return (default `true`) |

### Shipping Methods

Each SFCC shipping method that should use Zenkraft requires these custom attributes set under Merchant Tools > Ordering > Shipping Methods:

| Attribute | Description |
|---|---|
| `zenkraftID` | Zenkraft service type identifier that maps the method to a Zenkraft rate (e.g. `FEDEX_GROUND`) |
| `zenkraftCarrier` | Carrier ID for this method, overrides the site-wide Carrier ID preference (e.g. `fedex`, `dhl`) |
| `zenkraftShippingMethodAccountID` | Per-method shipping account ID override, also used to search collection points |
| `zenkraftRateMarkupType` | `Amount` or `Percent` markup on Zenkraft rate |
| `zenkraftRateMarkup` | Markup value to add to the Zenkraft rate |
| `zenkraftDropOffMethod` | Drop-off method: the shopper chooses a collection point when selecting it |

### Product and Category Attributes

Optional per-product and per-category attributes used for EDD lead time:

| Object | Attribute | Description |
|---|---|---|
| Product | `zenkraftLeadTime` | Days before delivery calculation starts for this product |
| Category | `zenkraftLeadTime` | Lead time override for all products in this category |

Product dimension attributes are read from **pre-existing** product catalog custom attributes — they are not created by this app's impex. The attributes used depend on the code path:

**Non-boxing rate request** (default, one package per line item or single consolidated package), and return labels (one package per returned item; a product without `dimDepth` falls back to a `length` attribute if your catalog has one):

| Attribute | Maps to rate API field |
|---|---|
| `dimWeight` | `weight` |
| `dimDepth` | `length` |
| `dimWidth` | `width` |
| `dimHeight` | `height` |

**Boxing algorithm** (`enableZenkraftBoxingAlgorithm` on, sent to the `/pack` endpoint via `zenkraft.api`):

| Attribute | Maps to pack API field |
|---|---|
| `dimDepth` | `depth` |
| `dimHeight` | `length` |
| `dimWidth` | `width` |
| `dimWeight` | `weight` |

Note: `dimHeight` maps to `height` in the rate API but to `length` in the pack API. This convention matches the legacy `int_zenkraft_sfra` cartridge. All four boxing attributes (`dimDepth`, `dimHeight`, `dimWidth`, `dimWeight`) must be set on a product for the boxing algorithm to activate for that product; if any are missing the product falls back to the non-boxing path.

### Package Profile Attributes

Package profiles are custom objects used by the boxing algorithm (`enableZenkraftBoxingAlgorithm`) to compute package dimensions before calling the pack API. Create them in Business Manager under Merchant Tools > Custom Objects > Custom Object Editor > `zenkraftPackageProfile`.

| Attribute | Type | Required | Description |
|---|---|---|---|
| `id` | String | Yes | Unique profile identifier (key) |
| `packageProfileDescription` | String | No | Human-readable description |
| `carrier` | String | No | Carrier ID this profile applies to |
| `packagingType` | String | No | Packaging type per Zenkraft API docs |
| `length` | Double | No | Outer box length |
| `height` | Double | No | Outer box height |
| `width` | Double | No | Outer box width |
| `emptyBoxWeight` | Double | No | Weight of the empty box (added to product weight total) |
| `innerLength` | Double | Yes | Inner usable length for packing |
| `innerHeight` | Double | Yes | Inner usable height for packing |
| `innerWidth` | Double | Yes | Inner usable width for packing |
| `maxWeight` | Double | No | Maximum total weight this box can hold |

Dimension units follow the `zenkraftDimensionUnits` site preference (`IN` or `CM`); weight units follow `zenkraftWeightUnits` (`LB` or `KG`).

### PDP Delivery Estimates

The `sfcc.app.shipping.estimate` hook (`estimatePDP.js`) populates delivery estimates on product detail pages. It is called by the platform with a `DeliveryEstimatesResultWO` skeleton containing one `ProductDeliveryEstimateWO` per product/destination combination.

The hook groups estimates by destination, then calls the `/rate` endpoint via `zenkraft.api` once per unique group. Estimates with no `countryCode` are skipped. Responses are cached in the `ZenkraftPDPDeliveryEstimate` cache region (TTL: 1 hour) under the key `siteId|countryCode|postalCode|productIds`. Matched rates are written back to each `ShippingOptionWO` — `price` (with markup), `currency`, `carrier`, and `deliveryWindow`. Advanced JSON country overrides (`zenkraftAdvancedJSON` / `zenkraftAdvancedJSONObject`) are applied to PDP rate requests in the same way as at checkout.

The rate request builds one package per product using `dimDepth` (length), `dimWidth` (width), `dimHeight` (height), and `dimWeight` (weight) from product custom attributes. If any of the four attributes are missing for a product, that product falls back to a `1×1×1` package using the `zenkraftDefaultProductWeight` site preference. Shipping methods must have `zenkraftID` set (same requirement as at checkout).

### Shipment and Order Address Custom Attributes

The following custom attributes are written by the cartridge and available for order management integrations:

| Object | Attribute | Type | Description |
|---|---|---|---|
| Shipment | `zenkraftCarrier` | String | Carrier ID from the selected shipping method |
| Shipment | `zenkraftShippingAccount` | String | Shipping account used for the shipment |
| Shipment | `deliveryWindowStartAt` | Datetime | Delivery window start, written to the shipment when `enableZenkraftEstimatedDeliveryDates` is on |
| Shipment | `deliveryWindowEndAt` | Datetime | Delivery window end, written to the shipment when `enableZenkraftEstimatedDeliveryDates` is on |
| Shipment | `zenkraftDropOffData` | Text | JSON of the selected collection point (drop-off methods only) |
| Shipment | `zenkraftDOPULocationCode` | String | Selected collection point's location code |
| Shipment | `zenkraftDOPULocationName` | String | Selected collection point's name |
| Shipment | `zenkraftOriginalShippingAddress` | Text | JSON of the shopper's own shipping address, saved before the collection point's address replaces it at order creation. Used to restore a basket whose order wasn't placed; stays on the order |
| OrderAddress | `zenkraftDOPULocationName` | String | Collection point's name on the shipping address |

`zenkraftEstimateKey` and `zenkraftEstimateSnapshot` cache rates on basket shipments and are cleared when the order is placed.

### Component Visibility

The app settings in Business Manager show a **Component Visibility** section (`app-configuration/adminComponents.json`) with one toggle per storefront target. Turning a toggle off opens a pull request against your Storefront Next repository that removes that target from `target-config.json`; the change applies once the pull request is merged and the storefront is deployed.

| Toggle | Target | Turning it off |
|---|---|---|
| Show collection point picker in checkout shipping options | `sfcc.checkout.shippingOptions` | The standard Storefront Next shipping step is shown. Zenkraft rates still apply, but shoppers can't choose a collection point — don't turn this off while drop-off methods are active |
| Show Returns on Order Details | `sfcc.myAccount.orderDetails.returns` | Hides the return button and the returns list on the order details page |
| Show Tracking on Order Details | `sfcc.myAccount.orderDetails.tracking` | Hides the tracking bar on the order details page |
| Show Return History link on Order History | `sfcc.myAccount.orders.tracking` | Hides the Return History link under Order History |

## Collection Points

For a shipping method with `zenkraftDropOffMethod` set, checkout shows a **Choose collection point** link under the method. It opens a dialog listing nearby collection points, searched around the shipment's shipping address with the method's carrier and shipping account (`zenkraftShippingMethodAccountID`, or the first `zenkraftShippingAccount`). Shoppers can't continue with a drop-off method until they choose a point. Picking a point for a method selects that method; switching to another method clears the point.

When the shopper continues, the storefront stores the point (`c_zenkraftDropOffData`) and the shipping method on the shipment in one request, and the calculate hook rates the shipment against the point's address. The shopper's own address stays on the basket during checkout, so they can switch back to home delivery. Just before the order is created, the `beforePOST` hook saves the shopper's address in `zenkraftOriginalShippingAddress`, then copies the point's address onto the shipment's shipping address (street, city, postal code, state, country, and the point's name as company) and clears the address's second line. An order with a drop-off shipment that has no collection point is refused (`ZENKRAFT_COLLECTION_POINT_REQUIRED`).

If the order isn't placed after that, because order creation failed or a payment app failed the order and reopened the basket, the next basket calculation puts the shopper's address back and clears the collection point; the checkout then asks the shopper to choose a point again. A payment that is declined before the order is created leaves the basket untouched, so the chosen point is kept.

In multi-shipment checkout, each shipment has its own collection point.

The map uses the storefront's Google Maps key, `features.googleCloudAPI.apiKey` in the Storefront Next config. Without a key, the dialog shows the list only.

## Order Tracking

The tracking bar on the order details page (`enableZenkraftTrackingOnOrderDetailsPage`) and the tracking page (`enableZenkraftTrackingPage`) show the Zenkraft tracking status of every shipment that has a tracking number and a `zenkraftCarrier`. The tracking number comes from your fulfillment process. The tracking page is at `/zenkraft-tracking?orderNo=<orderNo>`; with `zenkraftTrackingPageRequiresLogin` on, only logged-in shoppers get tracking data. The `getZenkraftTracking` API enforces this itself, so guests calling it directly get no tracking data either, and the page sends them to the login page.

## Returns

Shoppers start a return from the Returns card on the order details page, which opens the return wizard at `/zenkraft-create-return?orderNo=<orderNo>` (login required):

1. Select the items to return. Products in `zenkraftCatalogCategoriesForNonReturnableItems` can't be selected, and, when `zenkraftOrderDaysAvailableForReturn` is set, returns are only offered within that many days of the order.
2. Choose a reason and sub-reason per item, and add a photo where the sub-reason requires one.
3. Choose a return method and download the label. When the return needs approval (`zenkraftReturnsApprovalRequire`, or an item or customer in the approval categories or groups), the shopper submits a return request instead and downloads the label once it is approved.

If the order is missing details the label needs (`zenkraftReturnRequiredFields`), a form asks for them before the wizard starts. Existing returns for the order are listed below the wizard.

**Handlers.** With `zenkraftReturnsHandler` = `sfcc`, each return is stored in the instance as a `zenkraftReturn` custom object with one `zenkraftReturnLineItem` per item (not a platform `ReturnCase`), and the label is created through Zenkraft; `syncReturnWithZenkraft` also sends the return to Zenkraft. With `zkapi`, returns and their methods live in the Zenkraft API and nothing is stored in the instance.

### Return Reasons

`zenkraftReturnReasonsConfig` is a JSON object with a `reasons` array. Each reason applies to the products in its `categories` (catalog category IDs; `zk-default` applies to every product) and has sub-reasons in `values`:

```json
{
  "reasons": [
    {
      "id": "damaged",
      "categories": ["zk-default"],
      "display": "Damaged",
      "values": [
        {"display": "Damaged during shipment", "id": "damaged_during_shipment", "photoRequired": true},
        {"display": "Product was defective", "id": "product_was_defective", "photoRequired": true}
      ]
    }
  ]
}
```

The `SITEID` preferences ship a starter configuration with reasons for all products and an example of category-specific reasons (`mens-clothing-suits`); adjust it to your catalog.

### Refunds

The app doesn't issue refunds itself. For returns stored in the instance (`sfcc` handler), the `Zenkraft-Update-Return-Cases` job calls `refund(returnLineItem)` on the `app.zenkraft.returns` hook when it sees a return shipment's tracking stage change to `IN_TRANSIT`. Nothing in the app registers this hook; register it in your own cartridge's `hooks.json` to refund through your payment provider or order management system:

```json
{
  "hooks": [
    { "name": "app.zenkraft.returns", "script": "./cartridge/scripts/hooks/zenkraftReturnsRefund.js" }
  ]
}
```

The script exports `refund(returnLineItem)`, which receives the `zenkraftReturnLineItem` custom object. Keep in mind:

- The hook is called only when a job run sees the stage change to `IN_TRANSIT`. A return that moves from label created straight to delivered between two runs is never refunded, so schedule the job often enough, or check delivered returns in your own process.
- The app doesn't record that a refund was issued. Make your refund idempotent, for example by storing your own flag on the return line item.
- Returns handled by the Zenkraft API (`zkapi`) aren't stored in the instance, so the job never calls the hook for them.

### Return History Page

The Storefront Next extension adds a Return History page at `/account/zenkraft-returns`, inside the My Account layout. It lists the logged-in customer's returns, newest first, from the `returnsHistory` endpoint of the `zenkraft-returns` custom API, for both return handlers (`zenkraftReturnsHandler`). Each return links to its order; labels of `sfcc`-handler returns are downloaded from the order details page, Zenkraft API return labels from either page.

The page is linked from the bottom of the Order History page (`sfcc.myAccount.orders.tracking` target) and from each order's Returns card. The My Account sidebar has no extension target, so to add the page there, add an item to `navigationItems` in your storefront's `src/routes/_app.account.tsx`:

```tsx
// @sfdc-extension-line SFDC_EXT_ZENKRAFT_SHIPPING
{ path: '/account/zenkraft-returns', icon: Undo2, label: t('navigation.returns') },
```

Import `Undo2` (or another icon) from `lucide-react`, and add `navigation.returns` to the `account` translations of each locale.

### Return Reason Photos

When a return sub-reason in `zenkraftReturnReasonsConfig` has `"photoRequired": true`, the create-return page asks the shopper for a photo. With the `sfcc` returns handler, the photo is stored in the instance and attached to the Zenkraft return sync (`syncReturnWithZenkraft`); with the Zenkraft API handler it is only checked, not stored, as in the SFRA cartridge.

Photos are kept as `zenkraftReturnPhoto` custom objects (base64 JPEG, linked from the return line item's `reasonPhotoUrl`) and deleted automatically after 90 days. They can't be files: SCAPI requests may not write files, and they don't accept multipart uploads. Before upload, the page turns the photo into a JPEG shrunk to `zenkraftReturnReasonPhotoImageScale` and compressed to fit `zenkraftReturnReasonPhotoMaxSize`, capped at 140 KB, since one text attribute holds at most 200,000 characters.

## Testing

Cartridge unit tests (mocha, Node 20 or later):

```bash
cd cartridges/site_cartridges/int_zenkraft_sfnext
npm install
npm test
```

Tests are in `test/unit/hooks/` and `test/unit/helpers/`.

The Storefront Next extension's tests (Vitest) sit next to the code in `storefront-next/src/extensions/zenkraft-shipping/`. Run them from your Storefront Next project after installing the extension:

```bash
pnpm vitest run src/extensions/zenkraft-shipping
```

## Post-Installation Checklist

- [ ] Add `int_zenkraft_sfnext` to the site cartridge path, and `bm_zenkraft` (plus `int_zenkraft_sfnext` for the returns job) to the Business Manager cartridge path
- [ ] Enable the Zenkraft Business Manager module for your role
- [ ] Add the `c_zenkraft` scope to your storefront's SLAS client
- [ ] Connect Zenkraft in Merchant Tools > Zenkraft > Account Setup; for a new trial, run the `Zenkraft-Import-Credentials` job. Or contact Zenkraft support at https://zenkraft.com/contact
- [ ] Verify the Zenkraft service credential in Administration > Operations > Services
- [ ] Add carrier accounts in Merchant Tools > Zenkraft > Shipping Account Setup
- [ ] Configure site preferences in Merchant Tools > Site Preferences > Custom Preferences > Zenkraft
- [ ] Configure shipping methods: set `zenkraftID` on each Zenkraft-enabled method under Merchant Tools > Ordering > Shipping Methods; optionally set `zenkraftCarrier`, `zenkraftShippingMethodAccountID`, and `zenkraftDropOffMethod` for collection-point methods
- [ ] If using collection points: set a Google Maps key (`features.googleCloudAPI.apiKey`) in your Storefront Next config for the map
- [ ] If using the boxing algorithm: create package profiles in Merchant Tools > Custom Objects > Custom Object Editor > `zenkraftPackageProfile`
- [ ] If using tracking: enable `enableZenkraftTrackingOnOrderDetailsPage` and/or `enableZenkraftTrackingPage`
- [ ] If using returns: set `zenkraftReturnsHandler`, `zenkraftReturnsShippingAccount`, the return-to address (`zenkraftRecipient*`), and review `zenkraftReturnReasonsConfig`; schedule the `Zenkraft-Update-Return-Cases` job, and register the `app.zenkraft.returns` refund hook if you want automatic refunds
- [ ] Review the Component Visibility toggles in the app settings
- [ ] Enable `enableZenkraftShippingRates` to activate Zenkraft rate API calls at checkout
- [ ] Test on a sandbox site before enabling `zenkraftProdMode`

## Upgrading from 1.0.0

Upgrades are a manual process: uninstall 1.0.0, then install 1.1.0.

- Uninstalling removes the `zenkraft.credentials` service credential, so your API key is removed too. After installing 1.1.0, enter the key in the `zenkraft.credentials` **Password** field again (Merchant Tools > Zenkraft > Account Setup > existing account links there).
- Site preferences, shipping method attributes and package profiles from 1.0.0 are kept; 1.1.0 adds new attributes and custom object types on import.
- Complete the new steps from the [Installation](#installation) section: the `bm_zenkraft` cartridge, the Business Manager module permission and the `c_zenkraft` SLAS scope.

## Uninstall Notes

The uninstall IMPEX (`impex/uninstall/services.xml`) removes the `zenkraft.api` service, its credential (`zenkraft.credentials`), and its service profile (`zenkraft.profile`).

The following are **not** removed automatically because doing so would irreversibly delete any merchant-configured values:

- **Custom attributes** on `SitePreferences`, `Shipment`, `ShippingMethod`, `Product`, `Category`, and `OrderAddress` — defined in `impex/install/meta/system-objecttype-extensions.xml`
- **`zenkraftPackageProfile` and `zenkraftShippingAccount` custom object types** — defined in `impex/install/meta/custom-objecttype-definitions.xml`
- **`zenkraftReturn`, `zenkraftReturnLineItem` and `zenkraftReturnPhoto` custom object types** — defined in the same file; return photos are also deleted automatically after 90 days
- **Jobs** `Zenkraft-Import-Credentials` and `Zenkraft-Update-Return-Cases` — defined in `impex/install/jobs.xml`

To remove these manually after uninstalling the app:

1. Delete the custom object instances in Merchant Tools > Custom Objects > Custom Object Editor
2. Remove the custom object type definitions via Administration > Site Development > Import & Export using a metadata XML with `mode="delete"` on each `custom-type` element
3. Remove the Zenkraft custom attribute groups via Administration > Site Development > Import & Export using a metadata XML with `mode="delete"` on each `attribute-definition` element
4. Delete the two jobs in Administration > Operations > Jobs

## Known Limitations

- **The returns job requires `int_zenkraft_sfnext` on the BM cartridge path.** The `Zenkraft-Update-Return-Cases` job step uses date and return logic from `int_zenkraft_sfnext`. If you plan to run this job, add `int_zenkraft_sfnext` to the Business Manager cartridge path under Administration > Sites > Manage Sites > Business Manager > Settings, alongside `bm_zenkraft`.
- **Boxing algorithm requires all four dimension attributes.** The boxing algorithm activates for a product only when `dimDepth`, `dimHeight`, `dimWidth`, and `dimWeight` are all set. Products missing any of these attributes fall back to the non-boxing rate path silently.
- **Product dimension attributes are not created by this app.** `dimWeight`, `dimHeight`, `dimWidth`, and `dimDepth` are read from pre-existing product catalog custom attributes. They must already be defined in your catalog and populated on each product.
- **Session storage limit.** SFCC caps `session.privacy` string values at 2 000 characters. Baskets with a large number of shipments or shipping methods may cause the rate cache (`zenkraftCosts`) or EDD cache (`zenkraftEDD`) to be truncated, which will result in a fallback to OOTB rates for the affected shipment.
- **Quote hook falls back to a live API call when no snapshot exists.** The `sfcc.app.shipping.quote` hook checks the shipment snapshot written by the calculate hook and serves rates from it when the basket has not changed. If no snapshot is available (e.g. on the first load before `calculateShipping` has run), it calls the Zenkraft rate API directly.
- **PDP estimates fall back to default dimensions when product attributes are missing.** The `sfcc.app.shipping.estimate` hook reads `dimDepth`, `dimHeight`, `dimWeight`, and `dimWidth` from each product. If any of the four are missing the product uses a `1×1×1` package with `zenkraftDefaultProductWeight`, which may produce rates that differ from checkout.
- **Collection point address is set when the order is created.** During checkout the shipment keeps the shopper's address; the collection point's address replaces it in the `beforePOST` hook. If the order isn't placed, the basket is restored on its next calculation and the shopper chooses the collection point again (see [Collection Points](#collection-points)).
- **No built-in refunds.** The `Zenkraft-Update-Return-Cases` job only calls the `app.zenkraft.returns` refund hook, which your own cartridge has to register. It is called once, when a job run sees an `sfcc`-handler return change to `IN_TRANSIT`; a return that goes straight to delivered between runs isn't refunded, and no refund flag is stored (see [Refunds](#refunds)).
- **Return History covers the customer's 50 most recent orders.** Every order's return cases and products are read on each visit, so older orders are left out to stay within the 10-second limit of shopper custom APIs.
- **Creating a return with many items.** A return creates one custom object per item plus one for the return; the platform allows 10 custom object creations per storefront request, so returns of 10 or more items fail.
- **Translations.** The extension ships its own `extZenkraftShipping` strings in `en-US` and `en-GB`. It also reads keys from the host storefront's `checkout` and `extMultiship` namespaces; missing keys render as the key string. Admin labels and setup tasks are English only.

## Support

- Documentation: https://www.zenkraft.com
- Contact: https://zenkraft.com/contact

## Changelog

### v1.1.0
- Collection points: shoppers choose a carrier drop-off / pick-up location at checkout (list and Google map), rated against the location's address and shipped to it; multi-shipment checkout supported
- Order tracking: tracking bar on the order details page and a tracking page, with optional proof of delivery and per-carrier tracking accounts
- Returns: return wizard with reasons per category, reason photos, approval rules, non-returnable categories, return window, labels, missing-data form, Return History page, return tracking job with a refund hook for your own cartridge; returns stored in the instance or in the Zenkraft API
- Business Manager: Zenkraft menu with Account Setup (trial signup or existing account, credentials import job) and Shipping Account Setup (test UPS / FedEx accounts, your own carrier accounts)
- Component visibility toggles for the storefront targets
- Collection-point locations are searched with the shipping method's own account (`zenkraftShippingMethodAccountID`)

### v1.0.0
- Initial release: real-time Zenkraft rates and estimated delivery dates at checkout and on product pages, rate markups, boxing algorithm, multiple shipping accounts
