/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — fetches the base64 PDF label for an existing Zenkraft return case.
 *
 * GET /resource/zenkraft-return-combined-label?returnId=...
 *
 * Calls the `getCombinedLabel` custom endpoint, which returns the label of a Zenkraft API return
 * case owned by the shopper. Used by the return history's "Download Label(s)" button.
 *
 * Returns: { label: string } | { error: string }
 */

import type { LoaderFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

export function action() {
    return Response.json(null, { status: 405 });
}

export async function loader({ request, context }: LoaderFunctionArgs) {
    const url = new URL(request.url);
    const returnId = url.searchParams.get('returnId')?.trim() ?? '';

    if (!returnId) {
        return Response.json({ error: 'returnId is required' }, { status: 400 });
    }

    const logger = getLogger(context);

    try {
        const { accessToken, customerId } = getAuth(context);
        if (!customerId) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }

        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const params = new URLSearchParams({ siteId, c_returnCaseId: returnId });
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/getCombinedLabel?${params}`;

        const response = await fetch(apiUrl, {
            method: 'GET',
            cache: 'no-store',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json',
            },
        });

        if (!response.ok) {
            logger.error('[zenkraft-shipping] return combined label call failed', { status: response.status });
            return Response.json({ error: 'Failed to fetch return label' }, { status: response.status });
        }

        const data = await response.json();
        const label = data?.label ?? null;

        if (!label) {
            return Response.json({ error: 'Label not available' }, { status: 404 });
        }

        return Response.json({ label }, { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] return combined label resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
