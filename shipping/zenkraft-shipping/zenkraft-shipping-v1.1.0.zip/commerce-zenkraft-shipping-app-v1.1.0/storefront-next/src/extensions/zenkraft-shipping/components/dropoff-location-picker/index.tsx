import { lazy, type ReactElement, Suspense, useCallback, useId, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig } from '@salesforce/storefront-next-runtime/config';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
    getLocationPosition,
    hasOpeningHours,
    WEEKDAYS,
    type ZenkraftDropoffLocation,
    type ZenkraftOpeningInterval,
} from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const ZenkraftDropoffMap = lazy(() => import('./dropoff-map'));

export interface ZenkraftDropoffLocationPickerProps {
    locations: ZenkraftDropoffLocation[];
    /** `location_code` of the marked (highlighted) location. */
    value?: string;
    /** Called when the shopper marks a location, from the list or from a map marker. */
    onValueChange: (locationCode: string) => void;
    /** Called when the shopper confirms the marked location with the "Select" button. */
    onSelect: (location: ZenkraftDropoffLocation) => void;
    /** Override the Google Maps API key from config — useful in tests and Storybook. */
    googleMapsApiKey?: string;
    className?: string;
}

/**
 * Drop-off location list with a companion Google map. Marking a location in the list pans the map to it;
 * clicking a marker marks the location and scrolls it into view. The marked location offers a "Select" button.
 */
export default function ZenkraftDropoffLocationPicker({
    locations,
    value,
    onValueChange,
    onSelect,
    googleMapsApiKey,
    className,
}: ZenkraftDropoffLocationPickerProps): ReactElement {
    const { t } = useTranslation('extZenkraftShipping');
    const config = useConfig();
    const apiKey = googleMapsApiKey ?? config.features.googleCloudAPI.apiKey;
    const showMap = Boolean(apiKey) && locations.some((location) => getLocationPosition(location));
    const optionRefs = useRef(new Map<string, HTMLElement>());

    const handleMarkerClick = useCallback(
        (locationCode: string) => {
            onValueChange(locationCode);
            optionRefs.current.get(locationCode)?.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
        },
        [onValueChange]
    );

    return (
        <div className={cn('grid gap-4 md:gap-6', showMap && 'md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]', className)}>
            {showMap && (
                <div
                    role="region"
                    aria-label={t('dropoff.mapLabel')}
                    className="h-64 overflow-hidden rounded-ui md:order-last md:h-[70vh]">
                    <Suspense fallback={<Skeleton className="size-full" />}>
                        <ZenkraftDropoffMap
                            apiKey={apiKey}
                            locations={locations}
                            value={value}
                            onMarkerClick={handleMarkerClick}
                        />
                    </Suspense>
                </div>
            )}
            <RadioGroup
                value={value ?? ''}
                onValueChange={onValueChange}
                aria-label={t('dropoff.listLabel')}
                className="max-h-[50vh] content-start overflow-y-auto pr-1 md:max-h-[70vh]">
                {locations.map((location) => (
                    <DropoffLocationOption
                        key={location.location_code}
                        ref={(element) => {
                            if (element) optionRefs.current.set(location.location_code, element);
                            else optionRefs.current.delete(location.location_code);
                        }}
                        location={location}
                        isMarked={location.location_code === value}
                        onSelect={onSelect}
                    />
                ))}
            </RadioGroup>
        </div>
    );
}

function DropoffLocationOption({
    ref,
    location,
    isMarked,
    onSelect,
}: {
    ref: (element: HTMLDivElement | null) => void;
    location: ZenkraftDropoffLocation;
    isMarked: boolean;
    onSelect: (location: ZenkraftDropoffLocation) => void;
}): ReactElement {
    const { t } = useTranslation('extZenkraftShipping');
    const id = useId();
    const name = location.display_name ?? location.location_code;
    const hasDistance = Boolean(location.distance && location.distance_units);

    return (
        <div
            ref={ref}
            className="rounded-ui border border-border-subtle p-4 transition-colors has-[[data-state=checked]]:border-foreground">
            <label htmlFor={id} className="flex cursor-pointer items-start gap-3">
                <RadioGroupItem value={location.location_code} id={id} className="mt-1" />
                <span className="flex min-w-0 flex-1 flex-col gap-0.5">
                    {hasDistance && (
                        <span className="text-sm text-muted-foreground">
                            {t('dropoff.distanceAway', {
                                distance: location.distance,
                                unit: location.distance_units,
                            })}
                        </span>
                    )}
                    <span className="font-semibold text-foreground">{name}</span>
                    {location.street1 && <span className="text-sm text-foreground">{location.street1}</span>}
                </span>
            </label>
            {hasOpeningHours(location) && <OpeningHours hours={location.operational_hours} />}
            {isMarked && (
                <Button
                    type="button"
                    className="mt-4 w-full sm:w-auto"
                    aria-label={t('dropoff.selectLocation', { name })}
                    onClick={() => onSelect(location)}>
                    {t('dropoff.select')}
                </Button>
            )}
        </div>
    );
}

function OpeningHours({ hours }: { hours: ZenkraftDropoffLocation['operational_hours'] }): ReactElement {
    const { t } = useTranslation('extZenkraftShipping');

    const formatInterval = (interval?: ZenkraftOpeningInterval) => {
        if (interval?.open && interval.close) {
            return t('dropoff.hoursRange', { open: interval.open, close: interval.close });
        }
        return interval?.open || interval?.close || t('dropoff.closed');
    };

    return (
        // Two columns filled top-to-bottom: Monday–Thursday, then Friday–Sunday.
        <dl
            aria-label={t('dropoff.openingHours')}
            className="mt-3 grid grid-flow-col grid-cols-2 grid-rows-4 gap-x-4 gap-y-0.5 pl-7 text-xs text-muted-foreground">
            {WEEKDAYS.map((day) => (
                <div key={day} className="flex gap-1">
                    <dt className="font-medium">{t(`dropoff.days.${day}`)}</dt>
                    <dd>{formatInterval(hours?.[day])}</dd>
                </div>
            ))}
        </dl>
    );
}
