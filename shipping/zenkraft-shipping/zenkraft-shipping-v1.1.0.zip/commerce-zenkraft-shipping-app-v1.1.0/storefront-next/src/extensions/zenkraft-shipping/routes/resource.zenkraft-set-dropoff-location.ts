/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — stores the selected drop-off location on a basket shipment as
 * c_zenkraftDropOffData together with the chosen shipping method, in a single PATCH.
 * Both must land in the same request: the Zenkraft sfcc.app.shipping.calculate SFCC hook
 * runs on every basket recalculation and clears drop-off data on shipments whose method
 * is not a drop-off method.
 *
 * POST /resource/zenkraft-set-dropoff-location
 *   Body (single shipment): { basketId, shippingMethodId, location, shipmentId? }  — shipmentId defaults to 'me'
 *   Body (multi-shipment):  { basketId, shipments: [{ shipmentId, shippingMethodId, location }] }
 *   location: ZenkraftDropoffLocation to store, or null to clear the stored location
 *   Returns: { success: boolean }
 */

import type { ActionFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const DEFAULT_SHIPMENT_ID = 'me';
const MAX_ID_LENGTH = 256;
// A basket can't hold more shipments than this in practice; caps the PATCHes one request can trigger.
const MAX_SHIPMENTS = 50;

type ShipmentUpdateInput = {
    shipmentId?: unknown;
    shippingMethodId?: unknown;
    location?: unknown;
};

type ShipmentUpdate = {
    shipmentId: string;
    shippingMethodId: string;
    location: ZenkraftDropoffLocation | null;
};

/**
 * Validates one shipment update.
 * @returns The normalized update, or an error message for a 400 response
 */
function parseShipmentUpdate(input: ShipmentUpdateInput, fallbackShipmentId?: string): ShipmentUpdate | string {
    const shipmentId = typeof input.shipmentId === 'string' ? input.shipmentId.trim() : (fallbackShipmentId ?? '');
    if (!shipmentId || shipmentId.length > MAX_ID_LENGTH) {
        return 'shipmentId is required';
    }

    const shippingMethodId = typeof input.shippingMethodId === 'string' ? input.shippingMethodId.trim() : '';
    if (!shippingMethodId || shippingMethodId.length > MAX_ID_LENGTH) {
        return 'shippingMethodId is required';
    }

    // location=null means the shopper changed shipping method — clear the stored drop-off data.
    const location =
        input.location && typeof input.location === 'object' ? (input.location as ZenkraftDropoffLocation) : null;
    if (location && !location.location_code) {
        return 'location.location_code is required when setting a location';
    }

    return { shipmentId, shippingMethodId, location };
}

export function loader() {
    return new Response(null, { status: 405 });
}

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);

    try {
        const { accessToken } = getAuth(context);
        if (!accessToken) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }

        const body = (await request.json().catch(() => null)) as
            | (ShipmentUpdateInput & { basketId?: unknown; shipments?: unknown })
            | null;

        const basketId = typeof body?.basketId === 'string' ? body.basketId.trim() : '';
        if (!basketId) {
            return Response.json({ error: 'basketId is required' }, { status: 400 });
        }

        const inputs: ShipmentUpdateInput[] | null = Array.isArray(body?.shipments)
            ? (body.shipments as ShipmentUpdateInput[])
            : body
              ? [body]
              : null;
        if (!inputs || inputs.length === 0 || inputs.length > MAX_SHIPMENTS) {
            return Response.json({ error: 'At least one shipment update is required' }, { status: 400 });
        }

        // The single-shipment body predates multi-shipment support and always targets the default shipment.
        const fallbackShipmentId = Array.isArray(body?.shipments) ? undefined : DEFAULT_SHIPMENT_ID;
        const updates: ShipmentUpdate[] = [];
        for (const input of inputs) {
            const parsed = parseShipmentUpdate(input ?? {}, fallbackShipmentId);
            if (typeof parsed === 'string') {
                return Response.json({ error: parsed }, { status: 400 });
            }
            updates.push(parsed);
        }

        const clients = createApiClients(context);
        // Sequential on purpose: every PATCH recalculates the basket, so concurrent updates would race.
        for (const { shipmentId, shippingMethodId, location } of updates) {
            await clients.shopperBasketsV2.updateShipmentForBasket({
                params: {
                    path: {
                        basketId,
                        shipmentId,
                    },
                },
                body: {
                    shipmentId,
                    // Set the method in the same request so calculateShipping.js sees the drop-off
                    // method and its location together instead of clearing the data as stale.
                    shippingMethod: { id: shippingMethodId },
                    // null clears the attribute; a JSON string stores the selected collection point
                    // so calculateShipping.js can read and parse it for the drop-off rate request.
                    c_zenkraftDropOffData: location ? JSON.stringify(location) : null,
                },
            });
        }

        return Response.json({ success: true }, { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] set-dropoff-location failed', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ success: false, error: 'Failed to set drop-off location' }, { status: 500 });
    }
}
