/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Zenkraft Tracking Page — /zenkraft-tracking?orderNo=<orderNo>
 *
 * Rendered under the _app layout (full storefront header/footer).
 * Accepts `orderNo` as a required query parameter.
 *
 * Loader logic (server-side):
 *   - `orderNo` absent       → redirect to /
 *   - order not found        → { state: 'not-found' }
 *   - SCAPI/API error        → { state: 'error' }
 *   - order found            → { state: 'success', order, shipmentTracking[] }
 *
 * For each shipment that has a trackingNumber + c_zenkraftCarrier, the loader
 * calls the `/resource/zenkraft-tracking-data` endpoint (which proxies to
 * the `getZenkraftTracking` custom SCAPI endpoint in int_zenkraft_sfnext).
 *
 * Translations namespace: extZenkraftShipping
 */

import { type LoaderFunctionArgs, redirect, useLoaderData } from 'react-router';
import { useTranslation } from 'react-i18next';
import type { ShopperOrders, ShopperProducts } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import AddressDisplay from '@/components/address-display';
import ProductRecommendations from '@/components/product-recommendations';
import { EINSTEIN_RECOMMENDERS } from '@/lib/product/einstein-recommenders';
import ZenkraftTrackBar from '@/extensions/zenkraft-shipping/components/zenkraft-track-bar';
import { ProductItemVariantImage } from '@/components/product-item';
import type { EnrichedProductItem } from '@/lib/product/product-utils';

type Order = ShopperOrders.schemas['Order'];

type ProductItem = NonNullable<Order['productItems']>[number];

type ShipmentWithZenkraft = NonNullable<Order['shipments']>[number] & {
    c_zenkraftCarrier?: string;
    c_deliveryWindowStartAt?: string;
    c_deliveryWindowEndAt?: string;
    trackingNumber?: string;
};

type TrackingCheckpointLocation = {
    city?: string;
    state?: string;
    country?: string;
    postal_code?: string;
    residential?: boolean;
};

type TrackingCheckpoint = {
    time?: string;
    description?: string;
    location?: string | TrackingCheckpointLocation;
};

type ZenkraftTrackingData = {
    status?: string;
    tracking_stage?: string;
    trackingNo?: string;
    checkpoints?: TrackingCheckpoint[];
    error?: string;
};

type ScapiOrderData = {
    orderNo?: string;
    currency?: string;
    products?: Array<{
        id: string;
        name: string;
        quantity: number;
        currentPrice: number;
        pricePerUnit: number;
        image: string | null;
    }>;
};

type ZenkraftApiResponse = {
    redirect?: boolean;
    redirectURL?: string;
    trackingData?: ZenkraftTrackingData;
    requireLogin?: boolean;
    /** Set when zenkraftTrackingPageRequiresLogin is on and the shopper isn't logged in; no tracking data is returned. */
    loginRequired?: boolean;
    order?: ScapiOrderData;
};

/** Sends the shopper to log in and back to this tracking page afterwards. */
function redirectToLogin(url: URL): Response {
    return redirect(`/login?returnTo=${encodeURIComponent(url.pathname + url.search)}`);
}

type ShipmentTracking = {
    shipmentId: string;
    trackingNumber: string;
    carrier: string;
    trackingData: ZenkraftTrackingData | null;
};

type ProductsById = Record<string, ShopperProducts.schemas['Product'] | undefined>;

type LoaderData =
    | { state: 'success'; order: Order; shipmentTracking: ShipmentTracking[]; productsById: ProductsById }
    | { state: 'direct'; trackingNumber: string; carrier: string; trackingData: ZenkraftTrackingData | null; scapiOrder?: ScapiOrderData; productsById: ProductsById }
    | { state: 'not-found' };

async function fetchZenkraftTracking(
    context: LoaderFunctionArgs['context'],
    trackingNumber: string,
    carrier: string,
    orderNo: string
): Promise<ZenkraftApiResponse | null> {
    const logger = getLogger(context);
    const { accessToken } = getAuth(context);
    const config = getConfig(context);
    const { shortCode, organizationId } = config.commerce.api;
    const siteCtx = context.get(siteContext) as SiteContext;
    const siteId = siteCtx.site.id;
    const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

    const params = new URLSearchParams({
        siteId,
        c_trackingNumber: trackingNumber,
        c_carrier: carrier,
        c_order: orderNo,
        c_orderDetailsPage: 'false',
    });

    const apiUrl = `${baseUrl}/custom/zenkraft-track/v1/organizations/${organizationId}/getZenkraftTracking?${params}`;
    logger.info('[zenkraft-shipping] fetchZenkraftTracking calling SCAPI', { apiUrl, trackingNumber, carrier, orderNo });

    const response = await fetch(apiUrl, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json',
        },
    });

    if (!response.ok) {
        const body = await response.text();
        logger.error('[zenkraft-shipping] fetchZenkraftTracking SCAPI call failed', { status: response.status, body });
        return null;
    }

    let data: ZenkraftApiResponse;
    try {
        data = await response.json() as ZenkraftApiResponse;
    } catch {
        logger.error('[zenkraft-shipping] fetchZenkraftTracking non-JSON response body', { status: response.status });
        return null;
    }
    logger.info('[zenkraft-shipping] fetchZenkraftTracking SCAPI response', { data: JSON.stringify(data) });
    return data;
}

export async function loader({ request, context }: LoaderFunctionArgs): Promise<LoaderData | Response> {
    const url = new URL(request.url);
    const trackNumber = url.searchParams.get('trackNumber');
    const carrier = url.searchParams.get('carrier');
    const orderNo = url.searchParams.get('orderNo');

    const logger = getLogger(context);

    if (trackNumber && carrier) {
        try {
            const payload = await fetchZenkraftTracking(context, trackNumber, carrier, orderNo ?? '');

            if (payload?.redirect) {
                return redirect(payload.redirectURL ?? '/');
            }

            // The cartridge decides: guest sessions also have a customerId, so it can't be checked here
            if (payload?.loginRequired) {
                return redirectToLogin(url);
            }

            let directProductsById: ProductsById = {};
            const scapiProductIds = (payload?.order?.products ?? [])
                .map((p) => p.id)
                .filter((id): id is string => typeof id === 'string' && id.length > 0);

            if (scapiProductIds.length > 0) {
                try {
                    const clients = createApiClients(context);
                    const currency = (context.get(siteContext) as SiteContext).currency;
                    const { data: productsData } = await clients.shopperProducts.getProducts({
                        params: { query: { ids: scapiProductIds, expand: ['images', 'variations'], currency } },
                    });
                    (productsData?.data ?? []).forEach((product) => {
                        directProductsById[product.id] = product;
                    });
                } catch {
                    // non-critical — renders without images
                }
            }

            return {
                state: 'direct',
                trackingNumber: trackNumber,
                carrier,
                trackingData: payload?.trackingData ?? null,
                scapiOrder: payload?.order,
                productsById: directProductsById,
            };
        } catch (error) {
            logger.error('[zenkraft-shipping] direct tracking page: failed to load', {
                trackNumber,
                carrier,
                message: error instanceof Error ? error.message : String(error),
            });
            return redirect('/');
        }
    }

    if (!orderNo) {
        return redirect('/');
    }

    try {
        const clients = createApiClients(context);
        const { data: order } = await clients.shopperOrders.getOrder({
            params: {
                path: { orderNo },
            },
        });

        const shipments = (order.shipments ?? []) as ShipmentWithZenkraft[];
        logger.info('[zenkraft-shipping] shipments from getOrder', { shipments: JSON.stringify(shipments.map((s) => ({ shipmentId: s.shipmentId, trackingNumber: s.trackingNumber, c_zenkraftCarrier: s.c_zenkraftCarrier, c_deliveryWindowEndAt: s.c_deliveryWindowEndAt }))) });
        const trackableShipments = shipments.filter((s) => s.trackingNumber && s.c_zenkraftCarrier);

        let shipmentTracking: ShipmentTracking[] = [];

        if (trackableShipments.length > 0) {
            const payloads = await Promise.all(
                trackableShipments.map(async (shipment) => {
                    try {
                        const payload = await fetchZenkraftTracking(
                            context,
                            shipment.trackingNumber!,
                            shipment.c_zenkraftCarrier!,
                            orderNo
                        );
                        return { shipment, payload };
                    } catch (err) {
                        logger.warn('[zenkraft-shipping] tracking fetch failed for shipment', {
                            shipmentId: shipment.shipmentId,
                            trackingNumber: shipment.trackingNumber,
                            message: err instanceof Error ? err.message : String(err),
                        });
                        return { shipment, payload: null };
                    }
                })
            );

            for (const { payload } of payloads) {
                if (payload?.redirect) {
                    return redirect(payload.redirectURL ?? '/');
                }
                if (payload?.loginRequired) {
                    return redirectToLogin(url);
                }
            }

            shipmentTracking = payloads.map(({ shipment, payload }) => ({
                shipmentId: shipment.shipmentId ?? '',
                trackingNumber: shipment.trackingNumber!,
                carrier: shipment.c_zenkraftCarrier!,
                trackingData: payload?.trackingData ?? null,
            }));
        }

        const productIds = Array.from(
            new Set(
                (order.productItems ?? [])
                    .map((item) => item.productId)
                    .filter((id): id is string => typeof id === 'string' && id.length > 0)
            )
        );

        let productsById: ProductsById = {};
        if (productIds.length > 0) {
            try {
                const currency = (context.get(siteContext) as SiteContext).currency;
                const { data: productsData } = await clients.shopperProducts.getProducts({
                    params: { query: { ids: productIds, expand: ['images', 'variations'], currency } },
                });
                (productsData?.data ?? []).forEach((product) => {
                    productsById[product.id] = product;
                });
            } catch {
                // non-critical — page renders without images
            }
        }

        return { state: 'success', order, shipmentTracking, productsById };
    } catch (error) {
        const status = (error as { status?: number })?.status;

        if (status === 404) {
            return { state: 'not-found' };
        }

        logger.error('[zenkraft-shipping] tracking page: failed to load', {
            orderNo,
            message: error instanceof Error ? error.message : String(error),
        });
        return redirect('/');
    }
}

function StatusBadge({ status }: { status?: string }) {
    if (!status) return null;
    return (
        <span className="inline-flex items-center rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
            {status.replace(/_/g, ' ')}
        </span>
    );
}

function formatCheckpointLocation(location: TrackingCheckpoint['location']): string | null {
    if (!location) return null;
    if (typeof location === 'string') return location;
    return [location.city, location.state, location.country].filter(Boolean).join(', ') || null;
}

function CheckpointTimeline({ checkpoints, t }: { checkpoints: TrackingCheckpoint[]; t: (key: string) => string }) {
    if (!checkpoints.length) return null;

    return (
        <div className="mt-6">
            <p className="mb-3 text-sm font-semibold text-foreground">{t('tracking.timeline')}</p>
            <ol className="relative border-l border-border">
                {checkpoints.map((cp, i) => {
                    const locationText = formatCheckpointLocation(cp.location);
                    return (
                        <li key={i} className="mb-4 ml-4">
                            <div className="absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border border-background bg-primary" />
                            {cp.time && (
                                <time className="mb-1 text-xs text-muted-foreground">{cp.time}</time>
                            )}
                            {cp.description && (
                                <p className="text-sm font-medium text-foreground">{cp.description}</p>
                            )}
                            {locationText && (
                                <p className="text-xs text-muted-foreground">{locationText}</p>
                            )}
                        </li>
                    );
                })}
            </ol>
        </div>
    );
}

function ShipmentCard({
    shipment,
    tracking,
    productItems,
    productsById,
    currencyCode,
    t,
}: {
    shipment: ShipmentWithZenkraft;
    tracking: ShipmentTracking | undefined;
    productItems: ProductItem[];
    productsById: ProductsById;
    currencyCode: string;
    t: (key: string) => string;
}) {
    const rawDeliveryDate = shipment.c_deliveryWindowEndAt || shipment.c_deliveryWindowStartAt;
    const estimatedDelivery = rawDeliveryDate
        ? new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(rawDeliveryDate))
        : shipment.shippingMethod?.description || t('tracking.estimatedDeliveryPlaceholder');

    const trackingData = tracking?.trackingData;
    const checkpoints = trackingData?.checkpoints ?? [];

    return (
        <Card className="border border-border/70">
            <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                    <CardTitle className="text-base font-semibold">
                        {tracking?.trackingNumber && (
                            <span className="font-mono text-sm font-normal text-muted-foreground">
                                {tracking.trackingNumber}
                            </span>
                        )}
                    </CardTitle>
                    <StatusBadge status={trackingData?.status} />
                </div>
            </CardHeader>

            <CardContent className="grid gap-6 pt-2 md:grid-cols-3">
                {trackingData && (
                    <div className="md:col-span-3">
                        <ZenkraftTrackBar
                            trackingStatus={trackingData.status}
                            trackingStage={trackingData.tracking_stage}
                        />
                    </div>
                )}

                <div>
                    <p className="text-sm font-semibold text-foreground">{t('tracking.estimatedDelivery')}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{estimatedDelivery}</p>
                </div>

                <div>
                    <p className="text-sm font-semibold text-foreground">{t('tracking.shippingAddress')}</p>
                    <div className="mt-1">
                        {shipment.shippingAddress ? (
                            <AddressDisplay address={shipment.shippingAddress} />
                        ) : (
                            <p className="text-sm text-muted-foreground">{t('tracking.noAddress')}</p>
                        )}
                    </div>
                </div>

                <div>
                    <p className="text-sm font-semibold text-foreground">{t('tracking.shippingMethod')}</p>
                    <p className="mt-1 text-sm text-muted-foreground">
                        {shipment.shippingMethod?.name || t('tracking.estimatedDeliveryPlaceholder')}
                    </p>
                </div>

                {productItems.length > 0 && (
                    <div className="md:col-span-3">
                        <p className="mb-2 text-sm font-semibold text-foreground">{t('tracking.products')}</p>
                        <ul className="divide-y divide-border">
                            {productItems.map((item, i) => {
                                const productData = item.productId ? productsById[item.productId] : undefined;
                                const enrichedItem = { ...productData, ...item } as EnrichedProductItem;
                                return (
                                    <li key={item.itemId ?? i} className="flex items-center gap-3 py-2">
                                        <ProductItemVariantImage productItem={enrichedItem} className="h-12 w-12" />
                                        <span className="flex-1 text-sm text-foreground">
                                            {item.productName || item.itemText || item.productId}
                                        </span>
                                        <span className="shrink-0 text-sm text-muted-foreground">
                                            {t('tracking.qty')}: {item.quantity ?? 1}
                                        </span>
                                        {(item.priceAfterOrderDiscount ?? item.priceAfterItemDiscount ?? item.price) != null && (
                                            <span className="shrink-0 text-sm text-foreground">
                                                {new Intl.NumberFormat('en-US', { style: 'currency', currency: currencyCode }).format(
                                                    item.priceAfterOrderDiscount ?? item.priceAfterItemDiscount ?? item.price!
                                                )}
                                            </span>
                                        )}
                                    </li>
                                );
                            })}
                        </ul>
                    </div>
                )}

                {checkpoints.length > 0 && (
                    <div className="md:col-span-3">
                        <CheckpointTimeline checkpoints={checkpoints} t={t} />
                    </div>
                )}

                {trackingData?.error && (
                    <p className="text-xs text-destructive md:col-span-3">{t('tracking.trackingUnavailable')}</p>
                )}

                {!tracking && (
                    <p className="text-xs text-muted-foreground md:col-span-3">{t('tracking.noTrackingNumber')}</p>
                )}
            </CardContent>
        </Card>
    );
}

export default function ZenkraftTrackingPage() {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extZenkraftShipping' as any);
    const data = useLoaderData<typeof loader>();

    if (data.state === 'not-found') {
        return (
            <div className="container mx-auto px-4 py-12 text-center">
                <p className="text-muted-foreground">{t('tracking.orderNotFound')}</p>
            </div>
        );
    }

    if (data.state === 'direct') {
        const { trackingNumber, trackingData, scapiOrder, productsById } = data;
        const checkpoints = trackingData?.checkpoints ?? [];

        return (
            <div className="container mx-auto px-4 py-8">
                <h1 className="mb-2 text-2xl font-semibold">{t('tracking.title')}</h1>
                <div className="flex gap-8">
                    <div className="w-2/3 space-y-4 border border-border">
                        <Card className="border border-border/70">
                            <CardHeader className="pb-2">
                                <div className="flex items-center justify-between">
                                    <span className="font-mono text-sm text-muted-foreground">{trackingNumber}</span>
                                    {trackingData?.status && <StatusBadge status={trackingData.status} />}
                                </div>
                            </CardHeader>
                            <CardContent className="grid gap-6 pt-2">
                                {trackingData && (
                                    <ZenkraftTrackBar
                                        trackingStatus={trackingData.status}
                                        trackingStage={trackingData.tracking_stage}
                                    />
                                )}

                                {scapiOrder?.products && scapiOrder.products.length > 0 && (
                                    <div>
                                        {scapiOrder.orderNo && (
                                            <p className="mb-2 text-sm text-muted-foreground">
                                                {t('tracking.orderNumber')}:{' '}
                                                <span className="font-medium text-foreground">{scapiOrder.orderNo}</span>
                                            </p>
                                        )}
                                        <p className="mb-2 text-sm font-semibold text-foreground">{t('tracking.products')}</p>
                                        <ul className="divide-y divide-border">
                                            {scapiOrder.products.map((product) => {
                                                const productData = productsById[product.id];
                                                const enrichedItem = { ...productData, productId: product.id, productName: product.name, quantity: product.quantity } as EnrichedProductItem;
                                                return (
                                                    <li key={product.id} className="flex items-center gap-3 py-2">
                                                        <ProductItemVariantImage productItem={enrichedItem} className="h-12 w-12" />
                                                        <span className="flex-1 text-sm text-foreground">{product.name}</span>
                                                        <span className="shrink-0 text-sm text-muted-foreground">
                                                            {t('tracking.qty')}: {product.quantity}
                                                        </span>
                                                        {product.currentPrice != null && scapiOrder.currency && (
                                                            <span className="shrink-0 text-sm text-foreground">
                                                                {new Intl.NumberFormat('en-US', {
                                                                    style: 'currency',
                                                                    currency: scapiOrder.currency,
                                                                }).format(product.currentPrice)}
                                                            </span>
                                                        )}
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                    </div>
                                )}

                                {checkpoints.length > 0 && <CheckpointTimeline checkpoints={checkpoints} t={t} />}

                                {trackingData?.error && (
                                    <p className="text-xs text-destructive">{t('tracking.trackingUnavailable')}</p>
                                )}

                                {!trackingData && (
                                    <p className="text-sm text-muted-foreground">{t('tracking.noTrackingNumber')}</p>
                                )}
                            </CardContent>
                        </Card>
                    </div>
                    <div className="w-1/3 space-y-16 border border-border">
                        <div className="m-6 border-b">Recommended</div>
                        <ProductRecommendations
                            recommenderName={EINSTEIN_RECOMMENDERS.PDP_MIGHT_ALSO_LIKE}
                            recommenderTitle={t('recommendations.youMightAlsoLike')}
                            className="max-w-none px-0"
                        />
                    </div>
                </div>
            </div>
        );
    }

    const { order, shipmentTracking, productsById } = data;
    const shipments = (order.shipments ?? []) as ShipmentWithZenkraft[];
    const allProductItems = (order.productItems ?? []) as ProductItem[];

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="mb-2 text-2xl font-semibold">{t('tracking.title')}</h1>
            <p className="mb-6 text-sm text-muted-foreground">
                {t('tracking.orderNumber')}:{' '}
                <span className="font-medium text-foreground">{order.orderNo}</span>
            </p>
            <div className="flex gap-8">
                <div className=" w-2/3 space-y-4 border border-border">
                    {shipments.length === 0 ? (
                        <p className="text-sm text-muted-foreground">{t('tracking.noShipments')}</p>
                    ) : (
                        shipments.map((shipment) => (
                            <ShipmentCard
                                key={shipment.shipmentId}
                                shipment={shipment}
                                tracking={shipmentTracking.find((t) => t.shipmentId === shipment.shipmentId)}
                                productItems={allProductItems.filter((item) => item.shipmentId === shipment.shipmentId)}
                                productsById={productsById}
                                currencyCode={order.currency ?? 'USD'}
                                t={t}
                            />
                        ))
                    )}
                </div>          
                <div className="w-1/3 space-y-16 border border-border">
                    <div className="m-6 border-b">Recommended</div>
                    <ProductRecommendations
                        recommenderName={EINSTEIN_RECOMMENDERS.PDP_MIGHT_ALSO_LIKE}
                        recommenderTitle={t('recommendations.youMightAlsoLike')}
                        className="max-w-none px-0"
                    />
                </div>
            </div>
        </div>
    );
}
