import { describe, expect, test } from 'vitest';
import { render, screen } from '@testing-library/react';
import ZenkraftTrackBar from './index';

describe('ZenkraftTrackBar', () => {
    test('renders the default shipment steps with the current step marked', () => {
        const { container } = render(<ZenkraftTrackBar trackingStatus="IN_TRANSIT" trackingStage="IN_TRANSIT" />);

        expect(screen.getByText('Picked Up')).toBeInTheDocument();
        expect(screen.getByText('In Transit')).toBeInTheDocument();
        expect(screen.getByText('Out For Delivery')).toBeInTheDocument();
        expect(screen.getByText('Delivered')).toBeInTheDocument();
        expect(screen.getByRole('list')).toHaveAccessibleName('Order tracking progress');
        // The active (second) step is the only one carrying aria-current="step".
        expect(container.querySelectorAll('[aria-current="step"]')).toHaveLength(1);
    });

    test('renders the exception steps and marks the active step with a warning icon', () => {
        const { container } = render(
            <ZenkraftTrackBar trackingStatus="IN_TRANSIT" trackingStage="EXCEPTION" />
        );

        expect(screen.getByText('In Transit')).toBeInTheDocument();
        expect(screen.getByText('Delayed')).toBeInTheDocument();
        // The second step ("Delayed") is active and should carry the exception (warning) styling.
        const activeIndicator = container.querySelectorAll('[aria-current="step"]');
        expect(activeIndicator).toHaveLength(1);
        expect(activeIndicator[0]).toHaveClass('bg-warning');
    });

    test('renders return steps when isReturn is true', () => {
        render(<ZenkraftTrackBar isReturn trackingStatus="returnAwaitingApproval" />);

        expect(screen.getByText('Awaiting')).toBeInTheDocument();
        expect(screen.getByText('Label')).toBeInTheDocument();
        expect(screen.getByText('In Transit')).toBeInTheDocument();
        expect(screen.getByText('Received')).toBeInTheDocument();
    });

    test('renders the missing-status steps when trackingStatus is not provided', () => {
        render(<ZenkraftTrackBar trackingStage={null} />);

        expect(screen.getByText('Pending')).toBeInTheDocument();
        expect(screen.getByText('In Transit')).toBeInTheDocument();
    });
});
