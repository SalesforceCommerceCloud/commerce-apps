/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * ZenkraftReturnCaseList — existing return cases.
 *
 * Shared by the order details page (ZenkraftReturnHistory), the create-return page and the
 * Return History page in My Account.
 * Each return case shows:
 *   - with `showOrder`, a link to the order it belongs to (Return History page)
 *   - product name, colour, size, quantity
 *   - creation date
 *   - return tracking progress bar (Approved → Label → In Transit → Received)
 *   - "Download Label(s)" button — SFCC return cases carry their label, Zenkraft API
 *     return cases fetch it from /resource/zenkraft-return-combined-label
 */

import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Link } from '@/components/link';
import { routes, routeHref } from '@/route-paths';
import ZenkraftTrackBar from '@/extensions/zenkraft-shipping/components/zenkraft-track-bar';
import type { ReturnCaseSummary } from '@/extensions/zenkraft-shipping/lib/return-cases';

function downloadPdf(base64Label: string, fileName: string) {
    const link = document.createElement('a');
    link.href = `data:application/pdf;base64,${base64Label}`;
    link.download = fileName;
    link.click();
}

function ReturnCaseCard({ returnCase, showOrder }: { returnCase: ReturnCaseSummary; showOrder: boolean }) {
    const { t } = useTranslation('extZenkraftShipping');
    const [downloading, setDownloading] = useState(false);
    const [downloadFailed, setDownloadFailed] = useState(false);
    const canDownload = Boolean(returnCase.label) || (returnCase.zkReturnCase && Boolean(returnCase.id));
    const orderNo = showOrder ? returnCase.orderNo : undefined;

    const handleDownloadLabel = async () => {
        const fileName = `return-label-${returnCase.id}.pdf`;
        if (returnCase.label) {
            downloadPdf(returnCase.label, fileName);
            return;
        }
        setDownloading(true);
        setDownloadFailed(false);
        try {
            const res = await fetch(
                `/resource/zenkraft-return-combined-label?returnId=${encodeURIComponent(returnCase.id)}`
            );
            const data = res.ok ? ((await res.json()) as { label?: string }) : null;
            if (data?.label) {
                downloadPdf(data.label, fileName);
            } else {
                setDownloadFailed(true);
            }
        } catch {
            setDownloadFailed(true);
        } finally {
            setDownloading(false);
        }
    };

    const creationDate = returnCase.createdAt ? new Date(returnCase.createdAt).toLocaleDateString() : '';

    return (
        <div className="rounded-lg border border-border p-4 space-y-4">
            {/* Order link and download button */}
            {(orderNo || canDownload) && (
                <div className="flex flex-wrap items-center gap-2">
                    {orderNo && (
                        <Link
                            to={routeHref(routes.accountOrderDetail, { orderNo })}
                            className="text-sm font-medium text-foreground underline-offset-4 hover:underline">
                            {t('returns.history.order', { orderNo })}
                        </Link>
                    )}
                    {canDownload && (
                        <Button
                            variant="default"
                            size="sm"
                            className="ml-auto"
                            disabled={downloading}
                            onClick={() => void handleDownloadLabel()}>
                            {downloading ? t('returns.action.loading') : t('returns.history.downloadLabel')}
                        </Button>
                    )}
                </div>
            )}
            {downloadFailed && (
                <p role="alert" className="text-sm text-destructive text-right">
                    {t('returns.history.downloadError')}
                </p>
            )}

            {/* Line items */}
            {returnCase.returnLineItems.map((item, idx) => (
                <div
                    key={`${item.productId}-${idx}`}
                    className="flex flex-col gap-4 border-t border-border pt-4 first:border-0 first:pt-0 sm:flex-row sm:items-center sm:gap-6">
                    {/* Product image and details */}
                    <div className="flex flex-1 min-w-0 items-start gap-3">
                        {/* Same look as ProductItemVariantImage; the order hook sends a ready image URL */}
                        <div
                            data-slot="product-item-image"
                            className="bg-muted flex h-16 w-16 flex-shrink-0 items-center justify-center overflow-hidden rounded-ui">
                            {item.imageUrl && (
                                <img
                                    src={item.imageUrl}
                                    alt={item.productName}
                                    loading="lazy"
                                    className="h-full w-full object-contain"
                                />
                            )}
                        </div>
                        <div className="flex-1 min-w-0 space-y-1 text-sm">
                            <p className="font-medium text-foreground">{item.productName}</p>
                            {item.color && (
                                <p className="text-muted-foreground">
                                    {t('returns.history.color')}: {item.color}
                                </p>
                            )}
                            {item.size && (
                                <p className="text-muted-foreground">
                                    {t('returns.history.size')}: {item.size}
                                </p>
                            )}
                            <p className="text-muted-foreground">
                                {t('returns.item.qty')}: {item.quantity}
                            </p>
                            {creationDate && (
                                <p className="text-muted-foreground">
                                    {t('returns.history.date')}: {creationDate}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Tracking bar — half the card next to the product details, full width on mobile */}
                    <div className="w-full sm:w-auto sm:flex-1">
                        <ZenkraftTrackBar
                            isReturn
                            trackingStatus={returnCase.trackingStatus ?? undefined}
                            trackingStage={returnCase.trackingStage ?? undefined}
                        />
                    </div>
                </div>
            ))}
        </div>
    );
}

export function ZenkraftReturnCaseList({
    returnCases,
    showOrder = false,
}: {
    returnCases: ReturnCaseSummary[];
    showOrder?: boolean;
}) {
    return (
        <div className="space-y-4">
            {returnCases.map((returnCase, idx) => (
                <ReturnCaseCard key={returnCase.id || idx} returnCase={returnCase} showOrder={showOrder} />
            ))}
        </div>
    );
}
