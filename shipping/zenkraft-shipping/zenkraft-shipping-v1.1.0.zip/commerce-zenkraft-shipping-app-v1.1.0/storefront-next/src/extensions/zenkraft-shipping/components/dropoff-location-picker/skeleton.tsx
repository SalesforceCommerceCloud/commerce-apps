import type { ReactElement } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

const PLACEHOLDER_COUNT = 3;

/** Placeholder matching the picker's list + map layout while locations load. */
export default function ZenkraftDropoffLocationPickerSkeleton(): ReactElement {
    return (
        <div aria-hidden className="grid gap-4 md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)] md:gap-6">
            <Skeleton className="h-64 md:order-last md:h-[70vh]" />
            <div className="grid content-start gap-3">
                {Array.from({ length: PLACEHOLDER_COUNT }, (_, index) => (
                    <div key={index} className="flex flex-col gap-2 rounded-ui border border-border-subtle p-4">
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-5 w-3/4" />
                        <Skeleton className="h-4 w-1/2" />
                        <Skeleton className="mt-2 h-16 w-full" />
                    </div>
                ))}
            </div>
        </div>
    );
}
