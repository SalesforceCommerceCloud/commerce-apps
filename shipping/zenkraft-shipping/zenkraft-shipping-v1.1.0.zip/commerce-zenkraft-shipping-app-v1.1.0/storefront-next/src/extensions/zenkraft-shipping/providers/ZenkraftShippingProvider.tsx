import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { useBasket, useBasketSnapshot } from '@/providers/basket';
import type { ShopperBasketsV2 } from '@/scapi';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

/** Shipment used by the single-address checkout. */
export const DEFAULT_SHIPMENT_ID = 'me';

/** A collection point together with the drop-off shipping method it was picked for. */
export interface ZenkraftDropoffSelection {
    methodId: string;
    location: ZenkraftDropoffLocation;
}

/** The shipment and drop-off method whose collection-point dialog is open. */
export interface ZenkraftDropoffDialogTarget {
    shipmentId: string;
    methodId: string;
}

type SelectedLocations = Record<string, ZenkraftDropoffSelection | undefined>;

const NO_LOCATIONS: SelectedLocations = {};

/** The collection point stored on a basket shipment, with the method it was stored for; undefined if missing or unreadable. */
function readStoredSelection(shipment: ShopperBasketsV2.schemas['Shipment']): ZenkraftDropoffSelection | undefined {
    const raw = (shipment as { c_zenkraftDropOffData?: string | null }).c_zenkraftDropOffData;
    const methodId = shipment.shippingMethod?.id;
    if (!raw || !methodId) return undefined;
    try {
        const location = JSON.parse(raw) as ZenkraftDropoffLocation | null;
        return location?.location_code ? { methodId, location } : undefined;
    } catch {
        return undefined;
    }
}

interface ZenkraftShippingContextValue {
    /**
     * Maps shipment ID → the shopper's chosen collection point and the method it was picked for.
     * Holds at most one entry per shipment: picking a location for a shipment replaces its earlier pick.
     * Scoped to the current basket: empty again once the basket changes (e.g. after an order is placed).
     */
    selectedLocations: SelectedLocations;
    /** The location picked for this shipment and method, or undefined when none was picked for that method. */
    getSelectedLocation: (shipmentId: string, methodId: string) => ZenkraftDropoffLocation | undefined;
    /** The shipment and method whose collection-point dialog is currently open, or null. */
    dialog: ZenkraftDropoffDialogTarget | null;
    openDialog: (shipmentId: string, methodId: string) => void;
    closeDialog: () => void;
    setSelectedLocation: (shipmentId: string, methodId: string, location: ZenkraftDropoffLocation) => void;
    /** Clears the stored selection for a shipment (called when its shipping method changes). */
    clearLocation: (shipmentId: string) => void;
}

const ZenkraftShippingContext = createContext<ZenkraftShippingContextValue | null>(null);

export function ZenkraftShippingProvider({ children }: { children: ReactNode }) {
    // The provider is mounted app-wide, so selections would otherwise outlive the basket they
    // were made for and reappear in the next checkout. Remember which basket they belong to.
    const basketId = useBasketSnapshot()?.basketId ?? '';
    const [selection, setSelection] = useState<{ basketId: string; locations: SelectedLocations }>({
        basketId,
        locations: NO_LOCATIONS,
    });
    const [dialog, setDialog] = useState<ZenkraftDropoffDialogTarget | null>(null);

    const selectedLocations = selection.basketId === basketId ? selection.locations : NO_LOCATIONS;

    const updateShipment = (shipmentId: string, value: ZenkraftDropoffSelection | undefined) => {
        // Functional update so picks for several shipments in one render don't overwrite each other.
        setSelection((prev) => {
            const locations = { ...(prev.basketId === basketId ? prev.locations : NO_LOCATIONS) };
            if (value) {
                locations[shipmentId] = value;
            } else {
                delete locations[shipmentId];
            }
            return { basketId, locations };
        });
    };

    // When the basket loses a shipment's stored collection point (the cartridge restores a basket whose
    // order wasn't placed), drop the selection too, so the shipping step asks for a point again.
    // Only a point the basket had going away counts: during checkout a point only goes from missing to stored.
    const shipments = useBasket()?.shipments;
    const hadStoredPoint = useRef<Record<string, boolean>>({});
    useEffect(() => {
        (shipments ?? []).forEach((shipment) => {
            const shipmentId = shipment.shipmentId;
            if (!shipmentId) return;
            const hasStoredPoint = Boolean((shipment as { c_zenkraftDropOffData?: string | null }).c_zenkraftDropOffData);
            if (hadStoredPoint.current[shipmentId] && !hasStoredPoint) updateShipment(shipmentId, undefined);
            // A point the basket has but this page doesn't (e.g. after a reload): show it again, so the
            // shopper doesn't pick it twice. A point picked on this page is kept.
            else if (!selectedLocations[shipmentId]) {
                const stored = readStoredSelection(shipment);
                if (stored) updateShipment(shipmentId, stored);
            }
            hadStoredPoint.current[shipmentId] = hasStoredPoint;
        });
    }, [shipments]); // eslint-disable-line react-hooks/exhaustive-deps

    return (
        <ZenkraftShippingContext.Provider
            value={{
                selectedLocations,
                getSelectedLocation: (shipmentId, methodId) => {
                    const stored = selectedLocations[shipmentId];
                    return stored?.methodId === methodId ? stored.location : undefined;
                },
                dialog,
                openDialog: (shipmentId, methodId) => setDialog({ shipmentId, methodId }),
                closeDialog: () => setDialog(null),
                // A shipment has one shipping method, so only the collection point for that method is kept.
                setSelectedLocation: (shipmentId, methodId, location) =>
                    updateShipment(shipmentId, { methodId, location }),
                clearLocation: (shipmentId) => updateShipment(shipmentId, undefined),
            }}>
            {children}
        </ZenkraftShippingContext.Provider>
    );
}

export function useZenkraftShipping(): ZenkraftShippingContextValue {
    const ctx = useContext(ZenkraftShippingContext);
    if (!ctx) throw new Error('useZenkraftShipping must be used inside ZenkraftShippingProvider');
    return ctx;
}

const NOOP_ZENKRAFT_CONTEXT: ZenkraftShippingContextValue = {
    selectedLocations: {},
    getSelectedLocation: () => undefined,
    dialog: null,
    openDialog: () => {},
    closeDialog: () => {},
    setSelectedLocation: () => {},
    clearLocation: () => {},
};

/**
 * Like useZenkraftShipping but safe to call outside ZenkraftShippingProvider.
 * Returns a no-op context when the provider is absent so base components don't crash.
 */
export function useOptionalZenkraftShipping(): ZenkraftShippingContextValue {
    return useContext(ZenkraftShippingContext) ?? NOOP_ZENKRAFT_CONTEXT;
}

export default ZenkraftShippingProvider;
