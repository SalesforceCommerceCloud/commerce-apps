/** Opening and closing time for a single weekday. */
export interface ZenkraftOpeningInterval {
    open?: string;
    close?: string;
}

/** A carrier drop-off / pick-up (collection point) location returned by the `zenkraft-dopu` custom API. */
export interface ZenkraftDropoffLocation {
    location_code: string;
    display_name?: string;
    street1?: string;
    city?: string;
    postal_code?: string;
    country?: string;
    state?: string;
    distance?: string | number;
    distance_units?: string;
    lat?: string | number;
    lng?: string | number;
    operational_hours?: Partial<Record<Weekday, ZenkraftOpeningInterval>>;
}

/** Weekday keys used by `operational_hours`, in display order. */
export const WEEKDAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'] as const;

export type Weekday = (typeof WEEKDAYS)[number];

export interface LatLng {
    lat: number;
    lng: number;
}

/**
 * Parse a location's `lat`/`lng` into a map position.
 *
 * Zenkraft returns coordinates as decimal strings; return-method options may carry numbers.
 *
 * @returns The position, or `null` when either coordinate is missing or not a finite number.
 */
export function getLocationPosition(location: Pick<ZenkraftDropoffLocation, 'lat' | 'lng'>): LatLng | null {
    const lat = Number.parseFloat(String(location.lat ?? ''));
    const lng = Number.parseFloat(String(location.lng ?? ''));
    return Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : null;
}

/** Whether a location carries opening hours for at least one weekday. */
export function hasOpeningHours(location: Pick<ZenkraftDropoffLocation, 'operational_hours'>): boolean {
    const hours = location.operational_hours;
    return Boolean(hours && WEEKDAYS.some((day) => hours[day]?.open || hours[day]?.close));
}
