/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */
import { beforeEach, describe, expect, test, vi } from 'vitest';
import { action } from './resource.zenkraft-set-dropoff-location';

const logger = vi.hoisted(() => ({ error: vi.fn() }));
const updateShipmentForBasket = vi.hoisted(() => vi.fn());
const auth = vi.hoisted(() => ({ accessToken: 'test-token' as string | undefined }));

vi.mock('@/lib/logger.server', () => ({ getLogger: () => logger }));
vi.mock('@/middlewares/auth.server', () => ({ getAuth: () => auth }));
vi.mock('@/lib/api-clients.server', () => ({
    createApiClients: () => ({ shopperBasketsV2: { updateShipmentForBasket } }),
}));

const LOCATION = { location_code: 'A1', display_name: 'Corner Shop' };

function invoke(body: unknown, method = 'POST') {
    return action({
        request: new Request('https://example.com/resource/zenkraft-set-dropoff-location', {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: method === 'GET' ? undefined : JSON.stringify(body),
        }),
        context: {},
        params: {},
    } as never);
}

describe('resource.zenkraft-set-dropoff-location', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        auth.accessToken = 'test-token';
        updateShipmentForBasket.mockResolvedValue({ data: {} });
    });

    test('stores the location with its method on the default shipment for a single-shipment body', async () => {
        const response = await invoke({ basketId: 'b1', shippingMethodId: 'zk-dropoff', location: LOCATION });

        expect(response.status).toBe(200);
        expect(await response.json()).toEqual({ success: true });
        expect(updateShipmentForBasket).toHaveBeenCalledOnce();
        expect(updateShipmentForBasket).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', shipmentId: 'me' } },
            body: {
                shipmentId: 'me',
                shippingMethod: { id: 'zk-dropoff' },
                c_zenkraftDropOffData: JSON.stringify(LOCATION),
            },
        });
    });

    test('clears the stored location when location is null', async () => {
        await invoke({ basketId: 'b1', shipmentId: 'me', shippingMethodId: 'standard', location: null });

        expect(updateShipmentForBasket.mock.calls[0][0].body.c_zenkraftDropOffData).toBeNull();
    });

    test('stores each shipment of a multi-shipment body on its own shipment, one after another', async () => {
        const order: string[] = [];
        updateShipmentForBasket.mockImplementation(async ({ params }) => {
            order.push(`start:${params.path.shipmentId}`);
            await Promise.resolve();
            order.push(`end:${params.path.shipmentId}`);
            return { data: {} };
        });

        const response = await invoke({
            basketId: 'b1',
            shipments: [
                { shipmentId: 'me', shippingMethodId: 'zk-dropoff', location: LOCATION },
                { shipmentId: 'shipment-2', shippingMethodId: 'zk-dropoff', location: { location_code: 'B2' } },
            ],
        });

        expect(response.status).toBe(200);
        expect(updateShipmentForBasket).toHaveBeenCalledTimes(2);
        expect(updateShipmentForBasket.mock.calls[1][0]).toEqual({
            params: { path: { basketId: 'b1', shipmentId: 'shipment-2' } },
            body: {
                shipmentId: 'shipment-2',
                shippingMethod: { id: 'zk-dropoff' },
                c_zenkraftDropOffData: JSON.stringify({ location_code: 'B2' }),
            },
        });
        // Each PATCH recalculates the basket, so they must not overlap.
        expect(order).toEqual(['start:me', 'end:me', 'start:shipment-2', 'end:shipment-2']);
    });

    test('rejects a multi-shipment entry without a shipment ID and updates nothing', async () => {
        const response = await invoke({
            basketId: 'b1',
            shipments: [
                { shipmentId: 'me', shippingMethodId: 'zk-dropoff', location: LOCATION },
                { shippingMethodId: 'zk-dropoff', location: LOCATION },
            ],
        });

        expect(response.status).toBe(400);
        expect(updateShipmentForBasket).not.toHaveBeenCalled();
    });

    test.each([
        ['a missing basket', { shippingMethodId: 'zk-dropoff', location: LOCATION }],
        ['a missing shipping method', { basketId: 'b1', location: LOCATION }],
        ['a location without a code', { basketId: 'b1', shippingMethodId: 'zk-dropoff', location: { display_name: 'X' } }],
        ['an empty shipment list', { basketId: 'b1', shipments: [] }],
    ])('rejects %s', async (_label, body) => {
        const response = await invoke(body);

        expect(response.status).toBe(400);
        expect(updateShipmentForBasket).not.toHaveBeenCalled();
    });

    test('requires a shopper token', async () => {
        auth.accessToken = undefined;

        const response = await invoke({ basketId: 'b1', shippingMethodId: 'zk-dropoff', location: LOCATION });

        expect(response.status).toBe(401);
        expect(updateShipmentForBasket).not.toHaveBeenCalled();
    });

    test('reports a failed update with the shipment that failed', async () => {
        updateShipmentForBasket.mockRejectedValueOnce(new Error('boom'));

        const response = await invoke({ basketId: 'b1', shippingMethodId: 'zk-dropoff', location: LOCATION });

        expect(response.status).toBe(500);
        expect(await response.json()).toMatchObject({ success: false, failedShipmentId: 'me' });
        expect(logger.error).toHaveBeenCalled();
    });

    test('names the shipment that failed and stops there, keeping the shipments already saved', async () => {
        updateShipmentForBasket
            .mockResolvedValueOnce({ data: {} })
            .mockRejectedValueOnce(Object.assign(new Error('Invalid shipping method'), { status: 400 }));

        const response = await invoke({
            basketId: 'b1',
            shipments: [
                { shipmentId: 'me', shippingMethodId: 'zk-dropoff', location: LOCATION },
                { shipmentId: 'shipment-2', shippingMethodId: 'gone', location: { location_code: 'B2' } },
                { shipmentId: 'shipment-3', shippingMethodId: 'zk-dropoff', location: { location_code: 'C3' } },
            ],
        });

        expect(response.status).toBe(500);
        expect(await response.json()).toEqual({
            success: false,
            error: 'Failed to set drop-off location',
            failedShipmentId: 'shipment-2',
        });
        // Shipment 3 is not sent once shipment 2 fails
        expect(updateShipmentForBasket).toHaveBeenCalledTimes(2);
        expect(logger.error).toHaveBeenCalledWith(
            expect.any(String),
            expect.objectContaining({ shipmentId: 'shipment-2', status: 400 })
        );
    });
});
