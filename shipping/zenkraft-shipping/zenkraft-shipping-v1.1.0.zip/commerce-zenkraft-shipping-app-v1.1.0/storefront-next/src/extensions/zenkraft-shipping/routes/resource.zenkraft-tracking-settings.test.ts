/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */
import { beforeEach, describe, expect, test, vi } from 'vitest';
import { loader } from './resource.zenkraft-tracking-settings';

const logger = vi.hoisted(() => ({ error: vi.fn() }));

vi.mock('@/lib/logger.server', () => ({ getLogger: () => logger }));
vi.mock('@/middlewares/auth.server', () => ({ getAuth: () => ({ accessToken: 'test-token' }) }));
vi.mock('@salesforce/storefront-next-runtime/config', () => ({
    getConfig: () => ({ commerce: { api: { shortCode: 'test', organizationId: 'f_ecom_test_001' } } }),
}));
vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({ siteContext: 'siteContext' }));
vi.mock('@/lib/utils', () => ({ getScapiBaseUrl: () => 'https://test.api.commercecloud.salesforce.com' }));

const mockFetch = vi.spyOn(globalThis, 'fetch');

async function invoke() {
    const response = await loader({
        request: new Request('https://example.com/resource/zenkraft-tracking-settings'),
        context: { get: () => ({ site: { id: 'TestSite' } }) } as never,
        params: {},
    } as never);
    return (await response.json()) as { enableZenkraftTrackingOnOrderDetailsPage: boolean };
}

function respondWith(body: unknown, ok = true) {
    mockFetch.mockResolvedValueOnce({ ok, json: async () => body } as Response);
}

describe('resource.zenkraft-tracking-settings', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('asks the tracking API for the order details settings only', async () => {
        respondWith({ redirect: false, enableZenkraftTrackingOnOrderDetailsPage: true });

        const result = await invoke();

        const [url] = mockFetch.mock.calls[0] as [string, RequestInit];
        const params = new URL(url).searchParams;
        expect(url).toContain('zenkraft-track');
        expect(params.get('c_orderDetailsPage')).toBe('true');
        expect(params.has('c_trackingNumber')).toBe(false);
        expect(result.enableZenkraftTrackingOnOrderDetailsPage).toBe(true);
    });

    test('hides tracking when the order details preference is off', async () => {
        respondWith({ redirect: false, enableZenkraftTrackingOnOrderDetailsPage: false });

        expect((await invoke()).enableZenkraftTrackingOnOrderDetailsPage).toBe(false);
    });

    test('hides tracking when the tracking page is off', async () => {
        respondWith({ redirect: true, redirectURL: '/' });

        expect((await invoke()).enableZenkraftTrackingOnOrderDetailsPage).toBe(false);
    });

    test('hides tracking when the API returns an error', async () => {
        respondWith({ title: 'Unauthorized' }, false);

        expect((await invoke()).enableZenkraftTrackingOnOrderDetailsPage).toBe(false);
    });

    test('hides tracking and logs when the request fails', async () => {
        mockFetch.mockRejectedValueOnce(new Error('network down'));

        expect((await invoke()).enableZenkraftTrackingOnOrderDetailsPage).toBe(false);
        expect(logger.error).toHaveBeenCalledOnce();
    });
});
