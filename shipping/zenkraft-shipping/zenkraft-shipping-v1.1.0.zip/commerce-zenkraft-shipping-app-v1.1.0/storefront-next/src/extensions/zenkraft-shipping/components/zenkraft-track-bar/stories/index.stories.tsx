import type { Meta, StoryObj } from '@storybook/react-vite';
import { expect } from 'storybook/test';
import { waitForStorybookReady } from '@storybook/test-utils';
import ZenkraftTrackBar from '../index';

const meta: Meta<typeof ZenkraftTrackBar> = {
    title: 'Extensions/Zenkraft Shipping/Track Bar',
    component: ZenkraftTrackBar,
    tags: ['autodocs', 'interaction'],
    parameters: {
        layout: 'padded',
        docs: {
            description: {
                component:
                    'Horizontal step progress bar showing the current stage of a Zenkraft-tracked shipment or return.',
            },
        },
    },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const PickedUp: Story = {
    args: { trackingStatus: 'PICKED_UP', trackingStage: 'PICKED_UP' },
    play: async ({ canvasElement }) => {
        await waitForStorybookReady(canvasElement);
        await expect(canvasElement).toHaveTextContent('Picked Up');
    },
};

export const InTransit: Story = {
    args: { trackingStatus: 'IN_TRANSIT', trackingStage: 'IN_TRANSIT' },
};

export const OutForDelivery: Story = {
    args: { trackingStatus: 'OUT_FOR_DELIVERY', trackingStage: 'OUT_FOR_DELIVERY' },
};

export const Delivered: Story = {
    args: { trackingStatus: 'DELIVERED', trackingStage: 'DELIVERED' },
};

export const Exception: Story = {
    args: { trackingStatus: 'IN_TRANSIT', trackingStage: 'EXCEPTION' },
    parameters: {
        docs: {
            description: {
                story: 'The active step is styled as a warning when Zenkraft reports a shipment exception.',
            },
        },
    },
};

export const ShipmentVoided: Story = {
    args: { trackingStatus: 'SHIPMENT_VOIDED', trackingStage: 'SHIPMENT_VOIDED' },
};

export const MissingStatus: Story = {
    args: { trackingStage: null },
};

export const ReturnAwaitingApproval: Story = {
    args: { isReturn: true, trackingStatus: 'returnAwaitingApproval' },
};

export const ReturnRejected: Story = {
    args: { isReturn: true, trackingStatus: 'returnRejected' },
};

export const ReturnInTransit: Story = {
    args: { isReturn: true, trackingStatus: 'returnApproved', trackingStage: 'IN_TRANSIT' },
};

export const ReturnReceived: Story = {
    args: { isReturn: true, trackingStatus: 'returnApproved', trackingStage: 'DELIVERED' },
};
