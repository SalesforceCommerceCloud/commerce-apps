import { describe, expect, test } from 'vitest';
import { sortReturnCasesNewestFirst, toReturnCaseSummaries, type ReturnCaseSummary } from './return-cases';

const zkReturnCase = {
    id: 'zk-1',
    orderNumber: '00001234',
    combinedLabel: false,
    zkReturnCase: true,
    returnLineItems: [
        {
            returnID: 'zk-1',
            productID: 'SKU-1',
            quantity: 2,
            trackingStage: 'IN_TRANSIT',
            creationDate: '2026-10-01',
            approvedDate: '2026-10-01',
            product: {
                title: 'Linen Shirt',
                imageURL: 'https://example.com/images/small/linen-shirt.jpg',
                selectedVariationAttributes: [
                    { typeID: 'color', value: 'Blue' },
                    { typeID: 'size', value: 'M' },
                ],
            },
        },
    ],
};

describe('toReturnCaseSummaries', () => {
    test('maps a Zenkraft API return case', () => {
        expect(toReturnCaseSummaries([zkReturnCase])).toEqual([
            {
                id: 'zk-1',
                orderNo: '00001234',
                createdAt: '2026-10-01',
                trackingStage: 'IN_TRANSIT',
                trackingStatus: 'returnApproved',
                label: null,
                zkReturnCase: true,
                returnLineItems: [
                    {
                        productId: 'SKU-1',
                        productName: 'Linen Shirt',
                        imageUrl: 'https://example.com/images/small/linen-shirt.jpg',
                        quantity: 2,
                        color: 'Blue',
                        size: 'M',
                        creationDate: '2026-10-01',
                    },
                ],
            },
        ]);
    });

    test('uses the combined label of an SFCC return case', () => {
        const [summary] = toReturnCaseSummaries([
            {
                id: 'sfcc-1',
                combinedLabel: 'COMBINED',
                returnLineItems: [{ productID: 'SKU-1', quantity: 1, label: 'LINE' }],
            },
        ]);
        expect(summary.label).toBe('COMBINED');
        expect(summary.zkReturnCase).toBe(false);
    });

    test('falls back to the line label and the line return ID for an SFCC return case', () => {
        const [summary] = toReturnCaseSummaries([
            {
                combinedLabel: null,
                returnLineItems: [{ productID: 'SKU-1', returnID: 'sfcc-2', quantity: 1, label: 'LINE' }],
            },
        ]);
        expect(summary.id).toBe('sfcc-2');
        expect(summary.label).toBe('LINE');
    });

    test('marks a return case without an approved date as awaiting approval', () => {
        const [summary] = toReturnCaseSummaries([{ id: 'a', returnLineItems: [{ productID: 'SKU-1', quantity: 1 }] }]);
        expect(summary.trackingStatus).toBe('returnAwaitingApproval');
        expect(summary.trackingStage).toBeNull();
        expect(summary.returnLineItems[0].productName).toBe('SKU-1');
        expect(summary.returnLineItems[0].imageUrl).toBeUndefined();
    });

    test('drops return cases without line items and ignores non-array input', () => {
        expect(toReturnCaseSummaries([{ id: 'empty', returnLineItems: [] }, { id: 'none' }])).toEqual([]);
        expect(toReturnCaseSummaries(undefined)).toEqual([]);
        expect(toReturnCaseSummaries({})).toEqual([]);
    });

    test('maps a returnsHistory SFCC return case with its order number and ISO dates', () => {
        const [summary] = toReturnCaseSummaries([
            {
                id: 'sfcc-3',
                orderNumber: '00005678',
                zkReturnCase: false,
                returnLineItems: [
                    {
                        returnID: 'sfcc-3',
                        productID: 'SKU-2',
                        product: null,
                        quantity: 1,
                        trackingStage: null,
                        creationDate: '2026-10-05T09:30:00.000Z',
                        approvedDate: '2026-10-05T09:30:00.000Z',
                    },
                ],
            },
        ]);
        expect(summary.orderNo).toBe('00005678');
        expect(summary.createdAt).toBe('2026-10-05T09:30:00.000Z');
        expect(summary.trackingStatus).toBe('returnApproved');
        expect(summary.label).toBeNull();
        expect(summary.returnLineItems[0].productName).toBe('SKU-2');
    });

    test('leaves the order number out when the source has none', () => {
        const [summary] = toReturnCaseSummaries([{ id: 'a', returnLineItems: [{ productID: 'SKU-1', quantity: 1 }] }]);
        expect(summary.orderNo).toBeUndefined();
    });
});

describe('sortReturnCasesNewestFirst', () => {
    const summary = (id: string, createdAt: string): ReturnCaseSummary => ({
        id,
        createdAt,
        trackingStage: null,
        trackingStatus: null,
        label: null,
        zkReturnCase: false,
        returnLineItems: [],
    });

    test('sorts newest first across date formats and puts unreadable dates last', () => {
        const sorted = sortReturnCasesNewestFirst([
            summary('old', '2026-09-01T10:00:00.000Z'),
            summary('unknown', ''),
            summary('new', '2026-10-10T10:00:00.000Z'),
            summary('mid', 'Thu Oct 01 2026 07:22:43 GMT+0000'),
        ]);
        expect(sorted.map((rc) => rc.id)).toEqual(['new', 'mid', 'old', 'unknown']);
    });

    test('does not change the array it is given', () => {
        const input = [summary('a', '2026-09-01'), summary('b', '2026-10-01')];
        sortReturnCasesNewestFirst(input);
        expect(input.map((rc) => rc.id)).toEqual(['a', 'b']);
    });
});
