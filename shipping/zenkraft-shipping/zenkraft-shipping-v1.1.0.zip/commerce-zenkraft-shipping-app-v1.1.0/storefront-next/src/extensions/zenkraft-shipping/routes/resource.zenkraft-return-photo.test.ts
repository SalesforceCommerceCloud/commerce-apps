/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */
import { beforeEach, describe, expect, test, vi } from 'vitest';
import { action } from './resource.zenkraft-return-photo';

const logger = vi.hoisted(() => ({ error: vi.fn() }));

vi.mock('@/lib/logger.server', () => ({ getLogger: () => logger }));
vi.mock('@/middlewares/auth.server', () => ({ getAuth: () => ({ accessToken: 'test-token', customerId: 'c1' }) }));
vi.mock('@salesforce/storefront-next-runtime/config', () => ({
    getConfig: () => ({ commerce: { api: { shortCode: 'test', organizationId: 'f_ecom_test_001' } } }),
}));
vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({ siteContext: 'siteContext' }));
vi.mock('@/lib/utils', () => ({ getScapiBaseUrl: () => 'https://test.api.commercecloud.salesforce.com' }));

const mockFetch = vi.spyOn(globalThis, 'fetch');

function invoke(body: unknown) {
    return action({
        request: new Request('https://example.com/resource/zenkraft-return-photo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        }),
        context: { get: () => ({ site: { id: 'TestSite' } }) } as never,
        params: {},
    } as never) as Promise<Response>;
}

const photo = { orderId: '00001234', fileName: 'box.png', data: '/9j/4AAQSkZJRg==' };

describe('resource.zenkraft-return-photo', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('forwards only the order, file name and photo data to uploadReasonImage', async () => {
        mockFetch.mockResolvedValueOnce(Response.json({ success: true, photoId: 'abc123', msg: null }));

        const response = await invoke({ ...photo, extra: 'ignored' });

        expect(mockFetch).toHaveBeenCalledOnce();
        const [url, init] = mockFetch.mock.calls[0] as [string, RequestInit];
        expect(url).toContain('/uploadReasonImage?siteId=TestSite');
        expect(new Headers(init.headers).get('Content-Type')).toBe('application/json');
        expect(JSON.parse(init.body as string)).toEqual(photo);
        expect(await response.json()).toEqual({ success: true, photoId: 'abc123', msg: null });
    });

    test('turns down a request without an order number, file name or photo data', async () => {
        for (const body of [{ ...photo, orderId: ' ' }, { ...photo, fileName: '' }, { ...photo, data: undefined }, null]) {
            const response = await invoke(body);
            expect(response.status).toBe(400);
        }
        expect(mockFetch).not.toHaveBeenCalled();
    });

    test('passes on a failed upload as an error with the same status', async () => {
        mockFetch.mockResolvedValueOnce(new Response(null, { status: 400 }));

        const response = await invoke(photo);

        expect(response.status).toBe(400);
        expect(await response.json()).toEqual({ error: 'Failed to upload photo' });
    });
});
