import { describe, expect, test, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { createRoutesStub, type LoaderFunctionArgs } from 'react-router';
import { resourceRoutes } from '@/route-paths';
import { useZenkraftDropoffLocations } from './use-zenkraft-dropoff-locations';

function Probe({ shippingMethodId, shipmentId }: { shippingMethodId?: string; shipmentId?: string }) {
    const { status, locations, reload } = useZenkraftDropoffLocations(shippingMethodId, shipmentId);
    return (
        <>
            <output data-testid="status">{status}</output>
            <output data-testid="codes">{locations.map((location) => location.location_code).join(',')}</output>
            <button type="button" onClick={reload}>
                reload
            </button>
        </>
    );
}

function renderProbe(loader: (args: LoaderFunctionArgs) => unknown, shippingMethodId?: string, shipmentId?: string) {
    const Stub = createRoutesStub([
        {
            path: '/checkout',
            Component: () => <Probe shippingMethodId={shippingMethodId} shipmentId={shipmentId} />,
        },
        { path: resourceRoutes.zenkraftDropoffLocations, loader },
    ]);
    return render(<Stub initialEntries={['/checkout']} />);
}

describe('useZenkraftDropoffLocations', () => {
    test('stays idle without a shipping method', () => {
        const loader = vi.fn();
        renderProbe(loader);

        expect(screen.getByTestId('status')).toHaveTextContent('idle');
        expect(loader).not.toHaveBeenCalled();
    });

    test('loads the locations for the shipping method', async () => {
        const loader = vi.fn(({ request }: LoaderFunctionArgs) => ({
            success: true,
            shippingMethodId: new URL(request.url).searchParams.get('shippingMethodId'),
            locations: [{ location_code: 'A1' }, { location_code: 'B2' }],
        }));
        renderProbe(loader, 'zk-dropoff');

        expect(screen.getByTestId('status')).toHaveTextContent('loading');
        expect(await screen.findByText('A1,B2')).toBeInTheDocument();
        expect(screen.getByTestId('status')).toHaveTextContent('success');
    });

    test('reports an error and loads again on reload', async () => {
        const user = userEvent.setup();
        const loader = vi.fn(() => ({ success: false, shippingMethodId: 'zk-dropoff' }));
        renderProbe(loader, 'zk-dropoff');

        expect(await screen.findByText('error')).toBeInTheDocument();
        expect(screen.getByTestId('codes')).toBeEmptyDOMElement();

        await user.click(screen.getByRole('button', { name: 'reload' }));

        expect(loader).toHaveBeenCalledTimes(2);
    });

    test('loads the locations for a shipment, and only sends the shipment when given', async () => {
        const loader = vi.fn(({ request }: LoaderFunctionArgs) => {
            const params = new URL(request.url).searchParams;
            return {
                success: true,
                shippingMethodId: params.get('shippingMethodId'),
                shipmentId: params.get('shipmentId') ?? undefined,
                locations: [{ location_code: 'S2' }],
            };
        });
        renderProbe(loader, 'zk-dropoff', 'shipment-2');

        expect(await screen.findByText('S2')).toBeInTheDocument();
        const { request } = loader.mock.calls[0][0];
        expect(new URL(request.url).searchParams.get('shipmentId')).toBe('shipment-2');
    });

    test('does not send a shipment for the default shipment lookup', async () => {
        const loader = vi.fn(({ request }: LoaderFunctionArgs) => ({
            success: true,
            shippingMethodId: new URL(request.url).searchParams.get('shippingMethodId'),
            locations: [{ location_code: 'A1' }],
        }));
        renderProbe(loader, 'zk-dropoff');

        expect(await screen.findByText('A1')).toBeInTheDocument();
        const { request } = loader.mock.calls[0][0];
        expect(new URL(request.url).searchParams.has('shipmentId')).toBe(false);
    });

    test('ignores a response for a different shipment', async () => {
        const loader = vi.fn(() => ({
            success: true,
            shippingMethodId: 'zk-dropoff',
            shipmentId: 'shipment-1',
            locations: [{ location_code: 'X' }],
        }));
        renderProbe(loader, 'zk-dropoff', 'shipment-2');

        await vi.waitFor(() => expect(loader).toHaveBeenCalled());
        expect(screen.getByTestId('status')).toHaveTextContent('loading');
        expect(screen.getByTestId('codes')).toBeEmptyDOMElement();
    });

    test('ignores a response for a different shipping method', async () => {
        const loader = vi.fn(() => ({ success: true, shippingMethodId: 'other', locations: [{ location_code: 'X' }] }));
        renderProbe(loader, 'zk-dropoff');

        await vi.waitFor(() => expect(loader).toHaveBeenCalled());
        expect(screen.getByTestId('status')).toHaveTextContent('loading');
        expect(screen.getByTestId('codes')).toBeEmptyDOMElement();
    });
});
