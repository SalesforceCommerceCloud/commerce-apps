
/**
 * @module dropoff-map
 *
 * Only ever imported dynamically (`lazy(() => import('./dropoff-map'))`) so that
 * `@vis.gl/react-google-maps` stays out of the checkout bundle until the picker renders.
 */
import { type ReactElement, useEffect, useMemo } from 'react';
import { APIProvider, Map as GoogleMap, Marker, useMap } from '@vis.gl/react-google-maps';
import {
    getLocationPosition,
    type LatLng,
    type ZenkraftDropoffLocation,
} from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const DEFAULT_ZOOM = 15;
const SELECTED_MARKER_Z_INDEX = 1000;

export interface ZenkraftDropoffMapProps {
    apiKey: string;
    locations: ZenkraftDropoffLocation[];
    /** `location_code` of the marked location; the map pans to it when it changes. */
    value?: string;
    onMarkerClick: (locationCode: string) => void;
}

/** Google map with one marker per drop-off location. */
export default function ZenkraftDropoffMap({
    apiKey,
    locations,
    value,
    onMarkerClick,
}: ZenkraftDropoffMapProps): ReactElement | null {
    const markers = useMemo(
        () =>
            locations.flatMap((location) => {
                const position = getLocationPosition(location);
                return position ? [{ code: location.location_code, title: location.display_name, position }] : [];
            }),
        [locations]
    );

    const selectedPosition = markers.find((marker) => marker.code === value)?.position;
    const defaultCenter = selectedPosition ?? markers[0]?.position;

    if (!defaultCenter) {
        return null;
    }

    return (
        <APIProvider apiKey={apiKey}>
            <GoogleMap
                className="size-full"
                defaultCenter={defaultCenter}
                defaultZoom={DEFAULT_ZOOM}
                gestureHandling="cooperative"
                clickableIcons={false}>
                {markers.map((marker) => (
                    <Marker
                        key={marker.code}
                        position={marker.position}
                        title={marker.title}
                        zIndex={marker.code === value ? SELECTED_MARKER_Z_INDEX : undefined}
                        onClick={() => onMarkerClick(marker.code)}
                    />
                ))}
                <PanToPosition position={selectedPosition} />
            </GoogleMap>
        </APIProvider>
    );
}

/** Pans the surrounding map whenever the marked location changes. */
function PanToPosition({ position }: { position?: LatLng }): null {
    const map = useMap();
    const lat = position?.lat;
    const lng = position?.lng;

    useEffect(() => {
        if (map && lat !== undefined && lng !== undefined) {
            map.panTo({ lat, lng });
        }
    }, [map, lat, lng]);

    return null;
}
