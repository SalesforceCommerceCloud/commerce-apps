/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Return History page — /account/zenkraft-returns
 *
 * Lists the logged-in customer's returns, newest first, inside the My Account layout (the `_app.account.`
 * file name prefix nests the route there). Linked from the Order History page (ZenkraftReturnsLink) and
 * from each order's return history.
 *
 * The returns come from the returnsHistory custom API, which covers the customer's most recent orders.
 * Each return links to its order; SFCC return labels are downloaded there, Zenkraft API return labels here.
 */

import { type ReactElement, Suspense } from 'react';
import { Await, redirect, useLoaderData, type LoaderFunctionArgs } from 'react-router';
import { useTranslation } from 'react-i18next';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { buildUrlFromContext } from '@/lib/url.server';
import { getScapiBaseUrl } from '@/lib/utils';
import { routes } from '@/route-paths';
import { SeoMeta } from '@/components/seo-meta';
import { OrderListHeader } from '@/components/account/order-list';
import { Card, CardContent } from '@/components/ui/card';
import { Typography } from '@/components/typography';
import { ZenkraftReturnCaseList } from '@/extensions/zenkraft-shipping/components/zenkraft-returns/zenkraft-return-case-list';
import {
    sortReturnCasesNewestFirst,
    toReturnCaseSummaries,
    type ReturnCaseSummary,
} from '@/extensions/zenkraft-shipping/lib/return-cases';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

type LoaderData = {
    returnsPromise: Promise<ReturnCaseSummary[]>;
};

async function fetchReturnHistory(context: LoaderFunctionArgs['context']): Promise<ReturnCaseSummary[]> {
    const logger = getLogger(context);
    const { accessToken } = getAuth(context);
    const config = getConfig(context);
    const { shortCode, organizationId } = config.commerce.api;
    const siteCtx = context.get(siteContext) as SiteContext;
    const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

    const params = new URLSearchParams({ siteId: siteCtx.site.id });
    const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/returnsHistory?${params}`;

    const response = await fetch(apiUrl, {
        cache: 'no-store',
        headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json',
        },
    });

    if (!response.ok) {
        logger.error('[zenkraft-shipping] returnsHistory call failed', { status: response.status });
        throw new Error(`returnsHistory failed with status ${response.status}`);
    }

    const data = (await response.json()) as { returns?: unknown; error?: string };
    if (data.error) {
        logger.warn('[zenkraft-shipping] returnsHistory returned an error', { error: data.error });
        throw new Error(data.error);
    }

    return sortReturnCasesNewestFirst(toReturnCaseSummaries(data.returns));
}

export function loader({ context }: LoaderFunctionArgs): LoaderData {
    if (!getAuth(context).customerId) {
        throw redirect(buildUrlFromContext(routes.login, context));
    }

    // Deferred, so the header renders while the returns load
    return { returnsPromise: fetchReturnHistory(context) };
}

function ReturnHistoryMessage({ message }: { message: string }): ReactElement {
    return (
        <Typography variant="p" className="text-muted-foreground">
            {message}
        </Typography>
    );
}

export default function ZenkraftReturnHistoryPage(): ReactElement {
    const { t } = useTranslation('extZenkraftShipping');
    const { returnsPromise } = useLoaderData<typeof loader>();

    return (
        <div className="text-sm space-y-0">
            <SeoMeta title={t('returns.historyPage.title')} noIndex />
            <OrderListHeader title={t('returns.historyPage.title')} subtitle={t('returns.historyPage.subtitle')} />
            <Card className="border-border rounded-t-none">
                <CardContent className="px-5">
                    <Suspense fallback={<ReturnHistoryMessage message={t('returns.historyPage.loading')} />}>
                        <Await
                            resolve={returnsPromise}
                            errorElement={<ReturnHistoryMessage message={t('returns.historyPage.error')} />}>
                            {(returnCases) =>
                                returnCases.length > 0 ? (
                                    <ZenkraftReturnCaseList returnCases={returnCases} showOrder />
                                ) : (
                                    <ReturnHistoryMessage message={t('returns.historyPage.empty')} />
                                )
                            }
                        </Await>
                    </Suspense>
                </CardContent>
            </Card>
        </div>
    );
}
