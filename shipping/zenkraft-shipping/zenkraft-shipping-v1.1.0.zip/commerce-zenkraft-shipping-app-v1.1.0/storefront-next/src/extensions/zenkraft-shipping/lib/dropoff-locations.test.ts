import { describe, expect, test } from 'vitest';
import { getLocationPosition, hasOpeningHours } from './dropoff-locations';

describe('getLocationPosition', () => {
    test('parses decimal-string coordinates', () => {
        expect(getLocationPosition({ lat: '51.5072', lng: '-0.1276' })).toEqual({ lat: 51.5072, lng: -0.1276 });
    });

    test('accepts numeric coordinates', () => {
        expect(getLocationPosition({ lat: 40.7 as unknown as string, lng: -74 as unknown as string })).toEqual({
            lat: 40.7,
            lng: -74,
        });
    });

    test.each([
        { lat: undefined, lng: '-0.1276' },
        { lat: '51.5072', lng: '' },
        { lat: 'n/a', lng: '-0.1276' },
    ])('returns null for missing or invalid coordinates (%o)', (coordinates) => {
        expect(getLocationPosition(coordinates)).toBeNull();
    });
});

describe('hasOpeningHours', () => {
    test('is true when any weekday has an opening or closing time', () => {
        expect(hasOpeningHours({ operational_hours: { SAT: { close: '17:00' } } })).toBe(true);
    });

    test('is false when hours are missing or empty', () => {
        expect(hasOpeningHours({})).toBe(false);
        expect(hasOpeningHours({ operational_hours: { MON: {} } })).toBe(false);
    });
});
