import { describe, expect, test } from 'vitest';
import {
    base64ByteLength,
    getReasonPhotoMaxBytes,
    isReasonPhotoFormatAllowed,
    isReasonPhotoRequired,
    REASON_PHOTO_MAX_BYTES,
} from './reason-photo';

// Same shape as the "damaged" reason in the sample zenkraftReturnReasonsConfig
const damaged = {
    id: 'damaged',
    values: [
        { id: 'damaged_during_shipment', photoRequired: true },
        { id: 'product_was_defective', photoRequired: true },
        { id: 'other' },
    ],
};

describe('isReasonPhotoRequired', () => {
    test('requires a photo for a sub-reason that asks for one', () => {
        expect(isReasonPhotoRequired(damaged, 'damaged_during_shipment')).toBe(true);
        expect(isReasonPhotoRequired(damaged, 'product_was_defective')).toBe(true);
    });

    test('does not require a photo for a sub-reason without the flag, or before one is chosen', () => {
        expect(isReasonPhotoRequired(damaged, 'other')).toBe(false);
        expect(isReasonPhotoRequired(damaged, '')).toBe(false);
        expect(isReasonPhotoRequired(damaged, undefined)).toBe(false);
        expect(isReasonPhotoRequired(damaged, 'unknown')).toBe(false);
    });

    test('requires a photo for every sub-reason of a reason that has the flag itself', () => {
        const reason = { photoRequired: true, values: [{ id: 'a' }] };
        expect(isReasonPhotoRequired(reason, 'a')).toBe(true);
        expect(isReasonPhotoRequired({ photoRequired: true }, undefined)).toBe(true);
    });

    test('does not require a photo without a reason', () => {
        expect(isReasonPhotoRequired(undefined, 'damaged_during_shipment')).toBe(false);
    });
});

describe('isReasonPhotoFormatAllowed', () => {
    test('accepts the configured formats, whatever the case of the extension', () => {
        const limits = { acceptableFileFormats: ['jpg', 'PNG', 'heic'] };
        expect(isReasonPhotoFormatAllowed('box.JPG', limits)).toBe(true);
        expect(isReasonPhotoFormatAllowed('box.png', limits)).toBe(true);
        expect(isReasonPhotoFormatAllowed('box.heic', limits)).toBe(true);
        expect(isReasonPhotoFormatAllowed('box.gif', limits)).toBe(false);
    });

    test('falls back to jpg, jpeg and png when no formats are configured, like the endpoint', () => {
        for (const limits of [undefined, {}, { acceptableFileFormats: null }, { acceptableFileFormats: [] }]) {
            expect(isReasonPhotoFormatAllowed('box.jpeg', limits)).toBe(true);
            expect(isReasonPhotoFormatAllowed('box.webp', limits)).toBe(false);
        }
    });

    test('turns down a file name without a usable extension', () => {
        expect(isReasonPhotoFormatAllowed('box', undefined)).toBe(false);
        expect(isReasonPhotoFormatAllowed('box.', undefined)).toBe(false);
        expect(isReasonPhotoFormatAllowed('box.j-pg', { acceptableFileFormats: ['j-pg'] })).toBe(false);
    });
});

describe('getReasonPhotoMaxBytes', () => {
    test('uses the configured limit in KB while it is below what the endpoint can store', () => {
        expect(getReasonPhotoMaxBytes({ sizeLimit: 100 })).toBe(100 * 1024);
    });

    test('caps the limit at what fits in one custom object attribute', () => {
        expect(getReasonPhotoMaxBytes({ sizeLimit: 2048 })).toBe(REASON_PHOTO_MAX_BYTES);
        expect(getReasonPhotoMaxBytes(undefined)).toBe(REASON_PHOTO_MAX_BYTES);
        expect(getReasonPhotoMaxBytes({ sizeLimit: null })).toBe(REASON_PHOTO_MAX_BYTES);
        expect(getReasonPhotoMaxBytes({ sizeLimit: 0 })).toBe(REASON_PHOTO_MAX_BYTES);
    });

    test('keeps the base64 of a photo at the cap within the 200,000 character attribute limit', () => {
        expect(Math.ceil(REASON_PHOTO_MAX_BYTES / 3) * 4).toBeLessThanOrEqual(200000);
    });
});

describe('base64ByteLength', () => {
    test('counts the decoded bytes, padding included', () => {
        for (const bytes of [1, 2, 3, 1024, 1025]) {
            expect(base64ByteLength(btoa('a'.repeat(bytes)))).toBe(bytes);
        }
    });
});
