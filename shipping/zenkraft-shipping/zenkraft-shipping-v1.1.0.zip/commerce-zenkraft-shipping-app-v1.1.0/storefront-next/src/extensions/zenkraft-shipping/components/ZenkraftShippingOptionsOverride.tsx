import React, { lazy, Suspense, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useFetcher, type SubmitTarget } from 'react-router';
import { resourceRoutes } from '@/route-paths';
import { useTranslation } from 'react-i18next';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { ToggleCard, ToggleCardEdit, ToggleCardSummary } from '@/components/toggle-card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { formatCurrency } from '@/lib/currency';
import { formatDeliveryWindow } from '@/lib/date-utils';
import { useShippingOptions } from '@/components/checkout/components/use-shipping-options';
import { useBasket } from '@/providers/basket';
import type { ShopperBasketsV2 } from '@/scapi';
import type { CheckoutActionData } from '@/components/checkout/types';
import {
    DEFAULT_SHIPMENT_ID,
    useZenkraftShipping,
} from '@/extensions/zenkraft-shipping/providers/ZenkraftShippingProvider';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';


const ZenkraftDropoffDialog = lazy(
    () => import('@/extensions/zenkraft-shipping/components/dropoff-dialog'),
);
// Lazy like the multiship ShippingMultiOptions it replaces — only multi-address checkouts load it.
const ZenkraftMultiShipmentOptions = lazy(
    () => import('@/extensions/zenkraft-shipping/components/ZenkraftMultiShipmentOptions'),
);

type DropoffShippingMethod = ShopperBasketsV2.schemas['ShippingMethod'] & {
    c_zenkraftDropOffMethod?: boolean;
};

interface ShippingOptionsProps {
    onSubmit: (formData: FormData) => void;
    onAutoSubmit?: (formData: FormData) => void;
    isLoading: boolean;
    actionData?: CheckoutActionData;
    shippingMethods?: ShopperBasketsV2.schemas['ShippingMethodResult'];
    validationError?: string | null;
    isCompleted: boolean;
    isEditing: boolean;
    onEdit: () => void;
    justEnteredAddress?: boolean;
}

/**
 * Full override of the shipping options step registered at sfcc.checkout.shippingOptions.
 *
 * The checkout passes one of three elements as children:
 * - `ShippingOptions` (single address) → ZenkraftSingleShipmentOptions
 * - multiship `ShippingMultiOptions` (has `shippingMethodsMap`) → ZenkraftMultiShipmentOptions
 * - the loading skeleton (no `onSubmit`) → rendered unchanged
 *
 * The choice lives in this wrapper so switching modes swaps components rather than changing the hook order.
 */
export default function ZenkraftShippingOptionsOverride({ children }: { children: React.ReactNode }) {
    const props = React.isValidElement(children) ? (children.props as Record<string, unknown>) : {};
    if (!('onSubmit' in props)) {
        return <>{children}</>;
    }
    if ('shippingMethodsMap' in props) {
        return <ZenkraftMultiShipmentOptions>{children}</ZenkraftMultiShipmentOptions>;
    }

    return <ZenkraftSingleShipmentOptions>{children}</ZenkraftSingleShipmentOptions>;
}

/**
 * Single-shipment shipping options with Zenkraft drop-off support.
 * Reads props from the default ShippingOptions element (passed as children by the checkout
 * form) so all native auto-submit and step-advance logic still works. Adds inline
 * "Choose collection point" buttons for methods with c_zenkraftDropOffMethod: true and
 * blocks "Continue" if no location has been picked for a drop-off method.
 */
function ZenkraftSingleShipmentOptions({ children }: { children: React.ReactNode }) {
    const defaultProps = React.isValidElement(children)
        ? (children.props as ShippingOptionsProps)
        : ({} as ShippingOptionsProps);

    const {
        onSubmit,
        onAutoSubmit,
        isLoading,
        actionData,
        shippingMethods,
        isCompleted: _isCompleted,
        isEditing,
        onEdit,
        justEnteredAddress,
    } = defaultProps;

    const { currency } = useSite();
    const { t, i18n } = useTranslation('checkout');
    const { t: tZenkraft } = useTranslation('extZenkraftShipping');

    const {
        openDialog,
        selectedLocations,
        getSelectedLocation,
        dialog,
        closeDialog,
        setSelectedLocation,
        clearLocation,
    } = useZenkraftShipping();

    const basket = useBasket();
    const locationFetcher = useFetcher<{ success: boolean; error?: string }>();
    const [dropoffError, setDropoffError] = useState<string | null>(null);
    const [pendingFormData, setPendingFormData] = useState<FormData | null>(null);
    const locationFetcherStarted = useRef(false);
    const onSubmitRef = useRef(onSubmit);
    onSubmitRef.current = onSubmit;

    // Phase 2: once the basket shipment attribute is set, submit the shipping options
    useEffect(() => {
        if (!pendingFormData) return;
        if (locationFetcher.state !== 'idle') {
            locationFetcherStarted.current = true;
            return;
        }
        if (!locationFetcherStarted.current) return;

        locationFetcherStarted.current = false;
        const formData = pendingFormData;
        setPendingFormData(null);

        if (locationFetcher.data && !locationFetcher.data.success) {
            setDropoffError(tZenkraft('shippingOptions.selectLocationError'));
            return;
        }

        onSubmitRef.current(formData);
    }, [pendingFormData, locationFetcher.state, locationFetcher.data]); // eslint-disable-line react-hooks/exhaustive-deps

    const {
        availableShippingMethods,
        selectedMethod,
        summaryMethod,
        defaultShippingMethodId,
        hideChangeForGuest,
        isUpcomingStep,
        getDiscountedPrice,
    } = useShippingOptions({
        onSubmit,
        onAutoSubmit,
        isLoading,
        actionData,
        shippingMethods,
        isEditing,
        justEnteredAddress,
    });

    // Keep the raw applicable methods to read custom attributes (useShippingOptions strips them).
    const rawMethodsById = useMemo(() => {
        const map = new Map<string, DropoffShippingMethod>();
        shippingMethods?.applicableShippingMethods?.forEach((m) => {
            if (m.id) map.set(m.id, m as DropoffShippingMethod);
        });

        return map;
    }, [shippingMethods?.applicableShippingMethods]);

    // Force the step back into editing mode when the preselected method is a drop-off
    // method and the shopper hasn't picked a collection point yet — they must choose one
    // before the step can be marked complete.
    const selectedRawMethod = selectedMethod?.id ? rawMethodsById.get(selectedMethod.id) : undefined;
    const requiresDropoffSelection =
        !isUpcomingStep &&
        selectedRawMethod?.c_zenkraftDropOffMethod === true &&
        !getSelectedLocation(DEFAULT_SHIPMENT_ID, selectedMethod?.id ?? '');
    const isEditingEffective = isEditing || requiresDropoffSelection;

    // Radio the shopper picked in this edit session. Until they interact it follows the basket's
    // method, and it resets once the basket's method changes (e.g. after Continue).
    const [checkedMethodId, setCheckedMethodId] = useState<string | undefined>(undefined);
    useEffect(() => {
        setCheckedMethodId(undefined);
    }, [selectedMethod?.id]);
    const radioValue = checkedMethodId ?? (selectedMethod?.id || defaultShippingMethodId || '');

    const handleMethodChange = (methodId: string) => {
        setCheckedMethodId(methodId);
        // A collection point belongs to the method it was picked for — drop it when the shopper
        // moves to another method so it isn't shown under a method that is no longer selected.
        const stored = selectedLocations[DEFAULT_SHIPMENT_ID];
        if (stored && stored.methodId !== methodId) clearLocation(DEFAULT_SHIPMENT_ID);
    };

    const handleSelect = (location: ZenkraftDropoffLocation) => {
        if (dialog) {
            setSelectedLocation(DEFAULT_SHIPMENT_ID, dialog.methodId, location);
            // Picking a collection point selects its shipping method.
            setCheckedMethodId(dialog.methodId);
        }
        closeDialog();
    };

    const isSettingLocation = pendingFormData !== null || locationFetcher.state !== 'idle';

    const handleFormSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const chosenMethodId = formData.get('shippingMethodId') as string | null;
        const rawMethod = chosenMethodId ? rawMethodsById.get(chosenMethodId) : undefined;
        const chosenLocation = chosenMethodId ? getSelectedLocation(DEFAULT_SHIPMENT_ID, chosenMethodId) : undefined;

        if (rawMethod?.c_zenkraftDropOffMethod && !chosenLocation) {
            setDropoffError(tZenkraft('shippingOptions.selectLocationError'));
            return;
        }

        setDropoffError(null);

        const hasStaleDropoffData = !!selectedLocations[DEFAULT_SHIPMENT_ID];

        if (rawMethod?.c_zenkraftDropOffMethod && chosenLocation?.location_code && basket?.basketId) {
            // Phase 1: persist c_zenkraftDropOffData and the drop-off shipping method on the
            // basket shipment in one request so calculateShipping.js can read the location and
            // rate against the drop-off address. Phase 2 fires via useEffect once the fetcher
            // returns to idle.
            locationFetcherStarted.current = false;
            setPendingFormData(formData);
            locationFetcher.submit(
                // ZenkraftDropoffLocation is JSON-serializable but its nested Partial<Record<…>>
                // type doesn't satisfy react-router's JsonObject index signature; assert via unknown.
                {
                    basketId: basket.basketId,
                    shippingMethodId: chosenMethodId,
                    location: chosenLocation,
                } as unknown as SubmitTarget,
                { method: 'post', action: resourceRoutes.zenkraftSetDropoffLocation, encType: 'application/json' }
            );
        } else if (basket?.basketId && chosenMethodId && hasStaleDropoffData) {
            // Switching to a non-drop-off method — clear any previously stored location
            // from both React state and the basket shipment attribute.
            clearLocation(DEFAULT_SHIPMENT_ID);
            locationFetcherStarted.current = false;
            setPendingFormData(formData);
            locationFetcher.submit(
                { basketId: basket.basketId, shippingMethodId: chosenMethodId, location: null } as unknown as SubmitTarget,
                { method: 'post', action: resourceRoutes.zenkraftSetDropoffLocation, encType: 'application/json' }
            );
        } else {
            onSubmit(formData);
        }
    };

    const stepTitle = t('shippingOptions.title');

    return (
        <>
            <ToggleCard
                id="shipping-options"
                title={stepTitle}
                titleAs="h2"
                titleClassName="text-2xl font-bold tracking-tight text-card-foreground"
                editing={isEditingEffective}
                disabled={false}
                onEdit={onEdit}
                editLabel={t('common.edit')}
                disableEdit={hideChangeForGuest || isUpcomingStep || availableShippingMethods.length === 0}
                showHeaderSeparator
                isLoading={isLoading}>
                <ToggleCardEdit>
                    <form
                        method="post"
                        className="flex flex-col gap-4 pt-2 pb-2"
                        onSubmit={handleFormSubmit}>

                        {dropoffError && (
                            <p className="text-sm text-destructive" role="alert">
                                {dropoffError}
                            </p>
                        )}

                        <RadioGroup
                            name="shippingMethodId"
                            value={radioValue}
                            onValueChange={handleMethodChange}
                            required
                            aria-label={t('shippingOptions.title')}
                            className="flex flex-col gap-4">
                            {availableShippingMethods.map((method) => {
                                const deliveryWindowFormatted = formatDeliveryWindow(
                                    method.deliveryWindow,
                                    i18n.language,
                                );
                                const rawMethod = rawMethodsById.get(method.id);
                                const isDropoff = rawMethod?.c_zenkraftDropOffMethod === true;
                                const chosenLocation = getSelectedLocation(DEFAULT_SHIPMENT_ID, method.id);

                                return (
                                    <label
                                        key={method.id}
                                        htmlFor={`shipping-${method.id}`}
                                        className="group flex cursor-pointer flex-col gap-1 rounded-ui border border-border-subtle p-4 transition-all duration-200 has-[[data-state=checked]]:border-foreground">
                                        {/* sr-only method name first so screen readers announce: name, window, price */}
                                        <span className="sr-only">{method.name}</span>
                                        <div className="flex items-center gap-2">
                                            <RadioGroupItem
                                                value={method.id}
                                                id={`shipping-${method.id}`}
                                                className="shrink-0"
                                                // oxlint-disable-next-line jsx-a11y/no-autofocus
                                                autoFocus={
                                                    isEditing &&
                                                    availableShippingMethods.indexOf(method) === 0
                                                }
                                            />
                                            <span className="flex flex-1 items-center gap-2">
                                                <span className="flex-1 text-sm font-medium leading-none">
                                                    {deliveryWindowFormatted
                                                        ? t('shippingOptions.deliveryWindow', {
                                                              window: deliveryWindowFormatted,
                                                          })
                                                        : method.description || method.name}
                                                </span>
                                                <span className="flex shrink-0 items-center gap-1.5">
                                                    {method.shippingPromotions?.length &&
                                                    method.price > 0 &&
                                                    getDiscountedPrice(method.price) !==
                                                        method.price ? (
                                                        <>
                                                            <span className="text-sm text-muted-foreground line-through">
                                                                {formatCurrency(
                                                                    method.price,
                                                                    i18n.language,
                                                                    currency,
                                                                )}
                                                            </span>
                                                            <span className="text-sm font-semibold leading-none">
                                                                {getDiscountedPrice(method.price) ===
                                                                0
                                                                    ? t('shippingOptions.free')
                                                                    : formatCurrency(
                                                                          getDiscountedPrice(
                                                                              method.price,
                                                                          ),
                                                                          i18n.language,
                                                                          currency,
                                                                      )}
                                                            </span>
                                                        </>
                                                    ) : (
                                                        <span className="text-sm font-semibold leading-none">
                                                            {method.price === 0
                                                                ? t('shippingOptions.free')
                                                                : formatCurrency(
                                                                      method.price,
                                                                      i18n.language,
                                                                      currency,
                                                                  )}
                                                        </span>
                                                    )}
                                                </span>
                                            </span>
                                        </div>
                                        <span
                                            className="pl-6 text-sm text-foreground"
                                            aria-hidden>
                                            {method.name}
                                        </span>

                                        {/* Zenkraft: choose / change collection point */}
                                        {isDropoff && (
                                            <div className="pl-6 flex flex-col gap-1 mt-1">
                                                <Button
                                                    type="button"
                                                    variant="link"
                                                    size="sm"
                                                    className="h-auto w-fit p-0 text-sm"
                                                    onClick={(e) => {
                                                        e.preventDefault();
                                                        setDropoffError(null);
                                                        openDialog(DEFAULT_SHIPMENT_ID, method.id);
                                                    }}>
                                                    {chosenLocation
                                                        ? tZenkraft('shippingOptions.changeLocation')
                                                        : tZenkraft('shippingOptions.chooseLocation')}
                                                </Button>
                                                {chosenLocation && (
                                                    <span className="text-sm text-muted-foreground">
                                                        {chosenLocation.display_name}
                                                        {chosenLocation.distance != null && (
                                                            <>
                                                                {' · '}
                                                                {tZenkraft('dropoff.distanceAway', {
                                                                    distance: chosenLocation.distance,
                                                                    unit: chosenLocation.distance_units,
                                                                })}
                                                            </>
                                                        )}
                                                    </span>
                                                )}
                                            </div>
                                        )}
                                    </label>
                                );
                            })}
                        </RadioGroup>

                        <div
                            data-checkout-mobile-bar
                            className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-background px-6 py-4 lg:static lg:inset-auto lg:z-auto lg:w-full lg:border-0 lg:bg-transparent lg:p-0 lg:pt-2">
                            <Button
                                type="submit"
                                disabled={isLoading || isSettingLocation || availableShippingMethods.length === 0}
                                className="w-full">
                                {isLoading || isSettingLocation
                                    ? t('shippingOptions.saving')
                                    : t('shippingOptions.continue')}
                            </Button>
                        </div>
                    </form>
                </ToggleCardEdit>

                <ToggleCardSummary>
                    {summaryMethod ? (
                        <div className="space-y-1.5">
                            {(() => {
                                const summaryWindowFormatted = formatDeliveryWindow(
                                    summaryMethod.deliveryWindow,
                                    i18n.language,
                                );
                                return (
                                    <div className="space-y-1.5">
                                        {(summaryWindowFormatted || summaryMethod.description) && (
                                            <p className="text-sm font-normal leading-5 text-muted-foreground">
                                                {summaryWindowFormatted
                                                    ? t('shippingOptions.deliveryWindow', {
                                                          window: summaryWindowFormatted,
                                                      })
                                                    : summaryMethod.description}
                                            </p>
                                        )}
                                        <p className="text-sm font-normal leading-5 text-foreground">
                                            {summaryMethod.shippingPromotions?.length &&
                                            summaryMethod.price > 0 &&
                                            getDiscountedPrice(summaryMethod.price) !==
                                                summaryMethod.price ? (
                                                <>
                                                    <span className="text-foreground line-through">
                                                        {formatCurrency(
                                                            summaryMethod.price,
                                                            i18n.language,
                                                            currency,
                                                        )}
                                                    </span>{' '}
                                                    {getDiscountedPrice(summaryMethod.price) === 0
                                                        ? t('shippingOptions.free')
                                                        : formatCurrency(
                                                              getDiscountedPrice(
                                                                  summaryMethod.price,
                                                              ),
                                                              i18n.language,
                                                              currency,
                                                          )}
                                                    {' | '}
                                                    {summaryMethod.name}
                                                </>
                                            ) : (
                                                t('shippingOptions.priceAndMethod', {
                                                    price:
                                                        summaryMethod.price === 0
                                                            ? t('shippingOptions.free')
                                                            : formatCurrency(
                                                                  summaryMethod.price ?? 0,
                                                                  i18n.language,
                                                                  currency,
                                                              ),
                                                    methodName: summaryMethod.name || '',
                                                })
                                            )}
                                        </p>
                                    </div>
                                );
                            })()}
                        </div>
                    ) : (
                        <p className="text-sm text-muted-foreground">
                            {t('shippingOptions.completePreviousSteps')}
                        </p>
                    )}
                </ToggleCardSummary>
            </ToggleCard>

            {/* Drop-off location picker dialog */}
            {dialog && (
                <Suspense fallback={null}>
                    <ZenkraftDropoffDialog
                        open
                        onOpenChange={(open: boolean) => {
                            if (!open) closeDialog();
                        }}
                        shippingMethodId={dialog.methodId}
                        selectedLocationCode={getSelectedLocation(DEFAULT_SHIPMENT_ID, dialog.methodId)?.location_code}
                        onSelect={handleSelect}
                    />
                </Suspense>
            )}
        </>
    );
}
