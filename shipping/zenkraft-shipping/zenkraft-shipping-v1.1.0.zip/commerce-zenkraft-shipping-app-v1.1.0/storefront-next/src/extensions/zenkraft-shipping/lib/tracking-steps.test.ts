import { describe, expect, test } from 'vitest';
import { getTrackingSteps } from './tracking-steps';

describe('getTrackingSteps', () => {
    describe('shipments (isReturn=false)', () => {
        test('EXCEPTION stage returns the exception variant, active on the second step', () => {
            expect(getTrackingSteps(false, 'IN_TRANSIT', 'EXCEPTION')).toEqual({
                variant: 'exception',
                activeStepIndex: 1,
            });
        });

        test('SHIPMENT_VOIDED stage returns the shipmentVoided variant, active on the first step', () => {
            expect(getTrackingSteps(false, 'VOIDED', 'SHIPMENT_VOIDED')).toEqual({
                variant: 'shipmentVoided',
                activeStepIndex: 0,
            });
        });

        test('a null tracking status returns the missingStatus variant', () => {
            expect(getTrackingSteps(false, null, 'ANYTHING')).toEqual({
                variant: 'missingStatus',
                activeStepIndex: 0,
            });
        });

        test('PICKED_UP stage is active on the first default step', () => {
            expect(getTrackingSteps(false, 'PICKED_UP', 'PICKED_UP')).toEqual({
                variant: 'default',
                activeStepIndex: 0,
            });
        });

        test('an in-progress stage other than PICKED_UP is active on the second default step', () => {
            expect(getTrackingSteps(false, 'IN_TRANSIT', 'IN_TRANSIT')).toEqual({
                variant: 'default',
                activeStepIndex: 1,
            });
        });

        test('OUT_FOR_DELIVERY stage is active on the third default step', () => {
            expect(getTrackingSteps(false, 'OUT_FOR_DELIVERY', 'OUT_FOR_DELIVERY')).toEqual({
                variant: 'default',
                activeStepIndex: 2,
            });
        });

        test('DELIVERED stage is active on the fourth (final) default step', () => {
            expect(getTrackingSteps(false, 'DELIVERED', 'DELIVERED')).toEqual({
                variant: 'default',
                activeStepIndex: 3,
            });
        });
    });

    describe('returns (isReturn=true)', () => {
        test('returnRejected status returns the returnRejected variant, active on the first step', () => {
            expect(getTrackingSteps(true, 'returnRejected', undefined)).toEqual({
                variant: 'returnRejected',
                activeStepIndex: 0,
            });
        });

        test('returnAwaitingApproval status returns the returnAwaitingApproval variant, active on the first step', () => {
            expect(getTrackingSteps(true, 'returnAwaitingApproval', undefined)).toEqual({
                variant: 'returnAwaitingApproval',
                activeStepIndex: 0,
            });
        });

        test('an approved return with no tracking stage yet is active on the second step', () => {
            expect(getTrackingSteps(true, 'returnApproved', 'CREATED')).toEqual({
                variant: 'returnApproved',
                activeStepIndex: 1,
            });
        });

        test('an approved return in transit is active on the third step', () => {
            expect(getTrackingSteps(true, 'returnApproved', 'IN_TRANSIT')).toEqual({
                variant: 'returnApproved',
                activeStepIndex: 2,
            });
        });

        test('an approved, delivered (received) return is active on the fourth (final) step', () => {
            expect(getTrackingSteps(true, 'returnApproved', 'DELIVERED')).toEqual({
                variant: 'returnApproved',
                activeStepIndex: 3,
            });
        });
    });
});
