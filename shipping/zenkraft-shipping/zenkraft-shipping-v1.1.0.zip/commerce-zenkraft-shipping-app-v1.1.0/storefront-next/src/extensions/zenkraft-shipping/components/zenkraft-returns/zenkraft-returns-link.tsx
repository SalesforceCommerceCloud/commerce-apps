/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * ZenkraftReturnsLink — registered at sfcc.myAccount.orders.tracking, which renders once below
 * the Order History list. Links to the Return History page.
 *
 * Shown on every visit; the Return History page says when there are no returns yet, so no
 * request is needed here.
 */

import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Link } from '@/components/link';
import { ACCOUNT_RETURNS_PATH } from '@/extensions/zenkraft-shipping/lib/return-cases';

export default function ZenkraftReturnsLink() {
    const { t } = useTranslation('extZenkraftShipping');

    return (
        <div className="pt-4">
            <Button variant="outline" size="sm" asChild data-testid="zenkraft-returns-link">
                <Link to={ACCOUNT_RETURNS_PATH}>{t('returns.historyPage.link')}</Link>
            </Button>
        </div>
    );
}
