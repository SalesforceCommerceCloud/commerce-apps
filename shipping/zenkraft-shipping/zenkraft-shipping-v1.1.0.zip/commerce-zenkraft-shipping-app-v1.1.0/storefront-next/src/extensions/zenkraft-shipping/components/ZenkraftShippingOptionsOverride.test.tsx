import { beforeEach, describe, expect, test, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { createRoutesStub } from 'react-router';
import { resourceRoutes } from '@/route-paths';
import { mockAltSiteObject } from '@/test-utils/config';
import { AllProvidersWrapper } from '@/test-utils/context-provider';
import { CHECKOUT_STEPS } from '@/components/checkout/utils/checkout-context-types';
import type { ShopperBasketsV2 } from '@/scapi';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';
import { ZenkraftShippingProvider } from '@/extensions/zenkraft-shipping/providers/ZenkraftShippingProvider';
import ZenkraftShippingOptionsOverride from './ZenkraftShippingOptionsOverride';

// The basket and where checkout is (step / step being edited); each test sets them.
const state = vi.hoisted(() => ({
    basket: { basketId: 'basket-1', shipments: [] as unknown[] },
    checkout: { step: 4, editingStep: null as number | null },
}));

vi.mock('@/providers/basket', () => ({
    useBasket: vi.fn(() => state.basket),
    useBasketSnapshot: vi.fn(() => ({ basketId: 'basket-1', totalItemCount: 1, uniqueProductCount: 1, lastModified: '' })),
}));
vi.mock('@/hooks/checkout/use-customer-profile', () => ({
    useCustomerProfile: vi.fn(() => null),
}));
vi.mock('@/hooks/use-checkout', async () => {
    const { CHECKOUT_STEPS: STEPS } = await import('@/components/checkout/utils/checkout-context-types');
    return { useCheckoutContext: () => ({ ...state.checkout, STEPS }) };
});
vi.mock('@salesforce/storefront-next-runtime/site-context', async (importOriginal) => {
    const actual = await importOriginal<object>();
    return {
        ...actual,
        useSite: vi.fn(() => ({
            site: { id: mockAltSiteObject.id, defaultLocale: mockAltSiteObject.defaultLocale },
            language: mockAltSiteObject.defaultLocale,
            currency: mockAltSiteObject.defaultCurrency,
        })),
    };
});
// Stand-in for the map/list dialog: picks a location on click.
vi.mock('@/extensions/zenkraft-shipping/components/dropoff-dialog', () => ({
    default: ({ onSelect }: { onSelect: (location: ZenkraftDropoffLocation) => void }) => (
        <div role="dialog" aria-label="Collection Points">
            <button type="button" onClick={() => onSelect({ location_code: 'LOC-1', display_name: 'Corner Shop' })}>
                pick location
            </button>
        </div>
    ),
}));

/** Placeholder for the checkout's ShippingOptions element — only its props are read. */
function ShippingOptionsElement(_props: Record<string, unknown>) {
    return null;
}

const METHODS: ShopperBasketsV2.schemas['ShippingMethodResult'] = {
    applicableShippingMethods: [
        { id: 'standard', name: 'Standard', price: 5 },
        { id: 'zk-dropoff', name: 'Pickup Point', price: 3, c_zenkraftDropOffMethod: true } as never,
    ],
    defaultShippingMethodId: 'standard',
};

/** The basket shipment on the drop-off method, with or without a collection point saved on it. */
function dropOffShipment(savedPoint?: ZenkraftDropoffLocation) {
    return {
        shipmentId: 'me',
        shippingAddress: {
            firstName: 'Ann',
            lastName: 'Lee',
            address1: '1 Main St',
            city: 'Boston',
            postalCode: '02110',
            countryCode: 'US',
        },
        shippingMethod: { id: 'zk-dropoff', name: 'Pickup Point', price: 3 },
        ...(savedPoint ? { c_zenkraftDropOffData: JSON.stringify(savedPoint) } : {}),
    };
}

function renderOptions(props: Record<string, unknown> = {}, setLocationResult: unknown = { success: true }) {
    const onSubmit = vi.fn();
    const onEdit = vi.fn();
    const Stub = createRoutesStub([
        {
            path: '/checkout',
            Component: () => (
                <ZenkraftShippingProvider>
                    <ZenkraftShippingOptionsOverride>
                        <ShippingOptionsElement
                            onSubmit={onSubmit}
                            isLoading={false}
                            isEditing={false}
                            isCompleted
                            onEdit={onEdit}
                            shippingMethods={METHODS}
                            {...props}
                        />
                    </ZenkraftShippingOptionsOverride>
                </ZenkraftShippingProvider>
            ),
        },
        { path: resourceRoutes.zenkraftSetDropoffLocation, action: vi.fn(async () => setLocationResult) },
    ]);
    render(<Stub initialEntries={['/checkout']} />, { wrapper: AllProvidersWrapper });

    return { onSubmit, onEdit };
}

// The test DOM has no scrollIntoView
const scrollIntoView = vi.fn();

describe('ZenkraftShippingOptionsOverride (single shipment)', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        HTMLElement.prototype.scrollIntoView = scrollIntoView;
        // Checkout moved on to payment, as after the shopper submits a new shipping address
        state.checkout.step = CHECKOUT_STEPS.PAYMENT;
        state.checkout.editingStep = null;
        state.basket = { basketId: 'basket-1', shipments: [dropOffShipment()] };
    });

    test('brings checkout back to this step when the drop-off method has no saved collection point', async () => {
        const { onEdit } = renderOptions();

        await waitFor(() => expect(onEdit).toHaveBeenCalled());
    });

    test('stays open after a collection point is picked, until Continue saves it on the basket', async () => {
        const user = userEvent.setup();
        renderOptions();

        await user.click(await screen.findByRole('button', { name: 'Choose collection point' }));
        await user.click(await screen.findByRole('button', { name: 'pick location' }));

        expect(screen.getByText('Corner Shop')).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Continue to Payment' })).toBeInTheDocument();
    });

    test('says the choice could not be saved, not that no collection point was picked, when the server fails', async () => {
        const user = userEvent.setup();
        const { onSubmit } = renderOptions({}, { success: false, failedShipmentId: 'me' });

        await user.click(await screen.findByRole('button', { name: 'Choose collection point' }));
        await user.click(await screen.findByRole('button', { name: 'pick location' }));
        await user.click(screen.getByRole('button', { name: 'Continue to Payment' }));

        const message = await screen.findByRole('alert');
        expect(message).toHaveTextContent(
            "We couldn't save this shipping choice. Please try again or choose another shipping method."
        );
        expect(onSubmit).not.toHaveBeenCalled();
        await waitFor(() => expect(message).toHaveFocus());
        expect(scrollIntoView.mock.contexts[0]).toBe(message);
    });

    test('brings the missing collection point message into view and focuses it', async () => {
        const user = userEvent.setup();
        const { onSubmit } = renderOptions();

        await user.click(await screen.findByRole('button', { name: 'Continue to Payment' }));

        const message = await screen.findByRole('alert');
        expect(message).toHaveTextContent('Please choose a collection point before continuing.');
        expect(onSubmit).not.toHaveBeenCalled();
        await waitFor(() => expect(message).toHaveFocus());
        expect(scrollIntoView).toHaveBeenCalledWith({ behavior: 'smooth', block: 'center' });
    });

    test('leaves checkout where it is once the basket has the saved collection point', async () => {
        state.basket = {
            basketId: 'basket-1',
            shipments: [dropOffShipment({ location_code: 'LOC-1', display_name: 'Corner Shop' })],
        };
        const { onEdit } = renderOptions();

        expect(await screen.findByText(/\|\s*Pickup Point/)).toBeInTheDocument();
        expect(onEdit).not.toHaveBeenCalled();
    });

    test('does not take over while the shopper edits the shipping address', async () => {
        state.checkout.editingStep = CHECKOUT_STEPS.SHIPPING_ADDRESS;
        const { onEdit } = renderOptions();

        expect(await screen.findByRole('button', { name: 'Continue to Payment' })).toBeInTheDocument();
        expect(onEdit).not.toHaveBeenCalled();
    });
});
