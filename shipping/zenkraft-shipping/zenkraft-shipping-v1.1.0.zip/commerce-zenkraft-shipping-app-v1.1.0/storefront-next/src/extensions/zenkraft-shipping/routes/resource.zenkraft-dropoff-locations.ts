/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */
import { data, type ShouldRevalidateFunction } from 'react-router';
import type { Route } from './+types/resource.zenkraft-dropoff-locations';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const ZENKRAFT_DOPU_API = 'zenkraft-dopu';
const ZENKRAFT_DOPU_VERSION = 'v1';

/**
 * Result of the drop-off locations lookup.
 * @property success - Whether the lookup succeeded
 * @property shippingMethodId - The shipping method the locations belong to (echoed back so stale results can be ignored)
 * @property shipmentId - The shipment the locations were searched for, when one was requested (echoed back likewise)
 * @property locations - Drop-off locations, nearest first
 */
export interface DropoffLocationsResult {
    success: boolean;
    shippingMethodId?: string;
    shipmentId?: string;
    locations?: ZenkraftDropoffLocation[];
}

// Locations are resolved against the shopper's basket shipping address, so they must never be shared-cached.
const NO_STORE_HEADERS = { 'Cache-Control': 'no-store' } as const;

const MAX_ID_LENGTH = 256;

/**
 * Server-side loader returning the Zenkraft drop-off locations for a shipping method.
 * Proxies the `zenkraft-dopu` custom SCAPI endpoint with the shopper's token. Locations are
 * searched around the given shipment's address, or the default shipment's when none is given.
 *
 * @example
 * GET /resource/zenkraft-dropoff-locations?shippingMethodId=zenkraft-ups-access-point&shipmentId=shipment-2
 */
export async function loader({
    request,
    context,
}: Route.LoaderArgs): Promise<ReturnType<typeof data<DropoffLocationsResult>>> {
    const logger = getLogger(context);
    const searchParams = new URL(request.url).searchParams;
    // Echo the IDs exactly as requested so the client can match every response to its request.
    const requestedId = searchParams.get('shippingMethodId') ?? '';
    const shippingMethodId = requestedId.trim();
    const requestedShipmentId = searchParams.get('shipmentId') ?? undefined;
    const shipmentId = requestedShipmentId?.trim();
    const echo = { shippingMethodId: requestedId, shipmentId: requestedShipmentId };

    if (
        !shippingMethodId ||
        shippingMethodId.length > MAX_ID_LENGTH ||
        (requestedShipmentId !== undefined && (!shipmentId || shipmentId.length > MAX_ID_LENGTH))
    ) {
        return data({ success: false, ...echo }, { status: 400, headers: NO_STORE_HEADERS });
    }

    try {
        const { accessToken } = getAuth(context);
        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const params = new URLSearchParams({ siteId, c_shippingMethodId: shippingMethodId });
        // Only sent for multi-shipment checkouts, so single-shipment lookups work against API versions without it.
        if (shipmentId) params.set('c_shipmentId', shipmentId);
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_DOPU_API}/${ZENKRAFT_DOPU_VERSION}/organizations/${organizationId}/getDropOffLocations?${params}`;

        const response = await fetch(apiUrl, {
            cache: 'no-store',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json',
            },
        });

        if (!response.ok) {
            logger.error('ZenkraftDropoffLocations: upstream call failed', {
                status: response.status,
                shippingMethodId,
                shipmentId,
            });
            return data({ success: false, ...echo }, { status: response.status, headers: NO_STORE_HEADERS });
        }

        const result = (await response.json()) as { locations?: ZenkraftDropoffLocation[] };
        return data({ success: true, ...echo, locations: result?.locations ?? [] }, { headers: NO_STORE_HEADERS });
    } catch (error) {
        logger.error('ZenkraftDropoffLocations: lookup failed', {
            message: error instanceof Error ? error.message : String(error),
        });
        return data({ success: false, ...echo }, { status: 500, headers: NO_STORE_HEADERS });
    }
}

export function action() {
    return new Response(null, { status: 405, headers: { Allow: 'GET', ...NO_STORE_HEADERS } });
}

// A basket mutation (e.g. submitting the shipping step) must not re-query the carrier for an open picker.
export const shouldRevalidate: ShouldRevalidateFunction = ({ formAction, defaultShouldRevalidate }) => {
    return formAction ? false : defaultShouldRevalidate;
};
