/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * ZenkraftReturnHistory — registered at sfcc.myAccount.orderDetails.returns.
 *
 * Renders a "Returns" card below the Start Return button on the order details page,
 * listing all existing Zenkraft return cases for the order (see ZenkraftReturnCaseList),
 * with a link to the Return History page for the customer's other returns.
 *
 * Uses `basis-full` to break out of the flex action-bar row and occupy its own row.
 * Renders nothing when there are no return cases for the order.
 */

import { use, Suspense, useEffect } from 'react';
import { useFetcher, useRouteLoaderData } from 'react-router';
import { useTranslation } from 'react-i18next';
import type { ShopperOrders } from '@/scapi';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from '@/components/link';
import { ZenkraftReturnCaseList } from '@/extensions/zenkraft-shipping/components/zenkraft-returns/zenkraft-return-case-list';
import { ACCOUNT_RETURNS_PATH, type ReturnCaseSummary } from '@/extensions/zenkraft-shipping/lib/return-cases';

type RouteLoaderData = {
    orderData: Promise<{ order: ShopperOrders.schemas['Order'] }>;
};

type ReturnHistoryResponse = ReturnCaseSummary[] | { error: string };

function ZenkraftReturnHistoryInner() {
    const { t } = useTranslation('extZenkraftShipping');
    const loaderData = useRouteLoaderData<RouteLoaderData>('routes/_app.account.orders.$orderNo');
    const { order } = use(loaderData!.orderData);
    const orderNo = order.orderNo ?? '';

    const fetcher = useFetcher<ReturnHistoryResponse>();

    useEffect(() => {
        if (!orderNo) return;
        fetcher.load(`/resource/zenkraft-return-history?orderNo=${encodeURIComponent(orderNo)}`);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [orderNo]);

    const returnCases = Array.isArray(fetcher.data) ? fetcher.data : [];

    if (returnCases.length === 0) return null;

    return (
        <div className="basis-full">
            <Card className="rounded-none p-0 bg-card" data-card="zenkraft-return-history">
                <CardHeader className="px-4 pt-4 pb-2">
                    <CardTitle className="text-base">{t('returns.history.title')}</CardTitle>
                </CardHeader>
                <CardContent className="px-4 pb-4 space-y-4">
                    <ZenkraftReturnCaseList returnCases={returnCases} />
                    <Link
                        to={ACCOUNT_RETURNS_PATH}
                        className="inline-block text-sm font-medium text-foreground underline-offset-4 hover:underline"
                        data-testid="zenkraft-view-all-returns">
                        {t('returns.history.viewAll')}
                    </Link>
                </CardContent>
            </Card>
        </div>
    );
}

export default function ZenkraftReturnHistory() {
    return (
        <Suspense fallback={null}>
            <ZenkraftReturnHistoryInner />
        </Suspense>
    );
}
