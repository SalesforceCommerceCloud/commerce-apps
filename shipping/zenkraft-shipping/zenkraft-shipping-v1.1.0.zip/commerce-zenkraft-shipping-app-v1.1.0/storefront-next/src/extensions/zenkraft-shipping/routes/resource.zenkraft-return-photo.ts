/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — proxies POST requests to the Zenkraft uploadReasonImage
 * custom SCAPI endpoint in int_zenkraft_sfnext.
 *
 * POST /resource/zenkraft-return-photo
 *   Body: { orderId, fileName, data }   (data: base64 JPEG, already shrunk and compressed client-side)
 *
 * Used by the create-return page (/zenkraft-create-return) to store the photo a
 * return reason requires. The endpoint keeps it in a zenkraftReturnPhoto custom
 * object (SCAPI requests can't write files or take multipart uploads) and only
 * accepts orders the shopper owns. The returned photoId is sent back with the
 * return as `returnDetails[itemId].reasonPhotoId`.
 *
 * Returns: { success: boolean, photoId: string | null, msg: string | null }
 */

import type { ActionFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

export function loader() {
    return Response.json(null, { status: 405 });
}

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);

    try {
        const { accessToken, customerId } = getAuth(context);
        if (!customerId) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }
        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const body = await request.json();
        if (
            !body ||
            typeof body.orderId !== 'string' ||
            !body.orderId.trim() ||
            typeof body.fileName !== 'string' ||
            !body.fileName ||
            typeof body.data !== 'string' ||
            !body.data
        ) {
            return Response.json({ error: 'Invalid photo upload request' }, { status: 400 });
        }

        const params = new URLSearchParams({ siteId });
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/uploadReasonImage?${params}`;

        const response = await fetch(apiUrl, {
            method: 'POST',
            cache: 'no-store',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify({ orderId: body.orderId, fileName: body.fileName, data: body.data }),
        });

        if (!response.ok) {
            logger.error('[zenkraft-shipping] uploadReasonImage call failed', {
                status: response.status,
            });
            return Response.json({ error: 'Failed to upload photo' }, { status: response.status });
        }

        const data = await response.json();
        return Response.json(data, { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] return photo resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
