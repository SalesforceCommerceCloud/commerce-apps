/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * ZenkraftShipmentTrackBar — per-shipment tracking progress bar for the order details page.
 *
 * Client component: loads tracking data via the `/resource/zenkraft-tracking-data`
 * resource route and renders ZenkraftTrackBar inline. Intended for use inside the
 * order details shipment loop via the SFDC_EXT_ZENKRAFT_SHIPPING extension block.
 *
 * Rendering states:
 *   loading  → animated skeleton placeholder
 *   no data  → null (hides silently on API error or missing tracking)
 *   success  → section header + ZenkraftTrackBar progress bar
 */

import { useEffect, type ReactElement } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import ZenkraftTrackBar from '@/extensions/zenkraft-shipping/components/zenkraft-track-bar';

type TrackingData = {
    status?: string;
    tracking_stage?: string;
    error?: string;
};

type ResourceResponse = {
    trackingData?: TrackingData;
};

export interface ZenkraftShipmentTrackBarProps {
    /** Standard SFCC shipment tracking number. */
    trackingNumber: string;
    /** Zenkraft carrier ID from the shipment's `c_zenkraftCarrier` custom attribute. */
    carrier: string;
    /** Order number, forwarded to the SCAPI tracking endpoint. */
    orderNo: string;
    /** 1-based shipment index. When provided, renders "Tracking Status for Shipment {N}". */
    shipmentNumber?: number;
}

export default function ZenkraftShipmentTrackBar({
    trackingNumber,
    carrier,
    orderNo,
    shipmentNumber,
}: ZenkraftShipmentTrackBarProps): ReactElement | null {
    const { t } = useTranslation('extZenkraftShipping');
    const fetcher = useFetcher<ResourceResponse>();

    useEffect(() => {
        const params = new URLSearchParams({
            c_trackingNumber: trackingNumber,
            c_carrier: carrier,
            c_order: orderNo,
            c_orderDetailsPage: 'true',
        });
        fetcher.load(`/resource/zenkraft-tracking-data?${params}`);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [trackingNumber, carrier, orderNo]);

    if (fetcher.state === 'loading') {
        return <div className="h-10 animate-pulse bg-muted" aria-hidden />;
    }

    const trackingData = fetcher.data?.trackingData;
    if (!trackingData || trackingData.error) {
        return null;
    }

    return (
        <div className="border-t border-border pt-3 space-y-2">
            <p className="text-xs font-semibold text-foreground">
                {shipmentNumber != null
                    ? t('orderDetails.trackingStatusForShipment', { number: shipmentNumber })
                    : t('orderDetails.trackingStatus')}
            </p>
            <ZenkraftTrackBar
                trackingStatus={trackingData.status ?? null}
                trackingStage={trackingData.tracking_stage ?? null}
            />
        </div>
    );
}
