/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */
import { beforeEach, describe, expect, test, vi } from 'vitest';
import { loader } from './resource.zenkraft-dropoff-locations';

const logger = vi.hoisted(() => ({ error: vi.fn() }));

vi.mock('@/lib/logger.server', () => ({ getLogger: () => logger }));
vi.mock('@/middlewares/auth.server', () => ({ getAuth: () => ({ accessToken: 'test-token' }) }));
vi.mock('@salesforce/storefront-next-runtime/config', () => ({
    getConfig: () => ({ commerce: { api: { shortCode: 'test', organizationId: 'f_ecom_test_001' } } }),
}));
vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({ siteContext: 'siteContext' }));
vi.mock('@/lib/utils', () => ({ getScapiBaseUrl: () => 'https://test.api.commercecloud.salesforce.com' }));

const mockFetch = vi.spyOn(globalThis, 'fetch');

function makeContext() {
    return { get: () => ({ site: { id: 'TestSite' } }) } as never;
}

function invoke(query: string) {
    return loader({
        request: new Request(`https://example.com/resource/zenkraft-dropoff-locations${query}`),
        context: makeContext(),
        params: {},
    } as never);
}

describe('resource.zenkraft-dropoff-locations', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('returns the locations for the requested shipping method without allowing caching', async () => {
        const locations = [{ location_code: 'A1', display_name: 'Corner Shop', lat: '51.5', lng: '-0.1' }];
        mockFetch.mockResolvedValueOnce({
            ok: true,
            json: async () => ({ locations }),
        } as Response);

        const result = await invoke('?shippingMethodId=zk-dropoff');

        expect(mockFetch).toHaveBeenCalledOnce();
        const [url] = mockFetch.mock.calls[0] as [string, RequestInit];
        expect(url).toContain('zenkraft-dopu');
        expect(url).toContain('c_shippingMethodId=zk-dropoff');
        expect(result.data).toEqual({ success: true, shippingMethodId: 'zk-dropoff', locations });
        expect(new Headers(result.init?.headers).get('Cache-Control')).toBe('no-store');
    });

    test('searches around the requested shipment and echoes it back', async () => {
        const locations = [{ location_code: 'S2', display_name: 'Station Kiosk' }];
        mockFetch.mockResolvedValueOnce({
            ok: true,
            json: async () => ({ locations }),
        } as Response);

        const result = await invoke('?shippingMethodId=zk-dropoff&shipmentId=shipment-2');

        const [url] = mockFetch.mock.calls[0] as [string, RequestInit];
        expect(new URL(url).searchParams.get('c_shipmentId')).toBe('shipment-2');
        expect(result.data).toEqual({
            success: true,
            shippingMethodId: 'zk-dropoff',
            shipmentId: 'shipment-2',
            locations,
        });
    });

    test('does not send a shipment to the API when none is requested', async () => {
        mockFetch.mockResolvedValueOnce({
            ok: true,
            json: async () => ({ locations: [] }),
        } as Response);

        await invoke('?shippingMethodId=zk-dropoff');

        const [url] = mockFetch.mock.calls[0] as [string, RequestInit];
        expect(new URL(url).searchParams.has('c_shipmentId')).toBe(false);
    });

    test('rejects an empty shipment without calling the API', async () => {
        const result = await invoke('?shippingMethodId=zk-dropoff&shipmentId=');

        expect(result.init?.status).toBe(400);
        expect(result.data).toEqual({ success: false, shippingMethodId: 'zk-dropoff', shipmentId: '' });
        expect(mockFetch).not.toHaveBeenCalled();
    });

    test('returns an empty list when the API returns no locations', async () => {
        mockFetch.mockResolvedValueOnce({
            ok: true,
            json: async () => ({}),
        } as Response);

        const result = await invoke('?shippingMethodId=zk-dropoff');

        expect(result.data).toEqual({ success: true, shippingMethodId: 'zk-dropoff', locations: [] });
    });

    test('rejects a missing shipping method without calling the API', async () => {
        const result = await invoke('');

        expect(result.init?.status).toBe(400);
        expect(result.data).toEqual({ success: false, shippingMethodId: '' });
        expect(mockFetch).not.toHaveBeenCalled();
    });

    test('forwards the upstream status and echoes the shipping method when the API fails', async () => {
        mockFetch.mockResolvedValueOnce({ ok: false, status: 404 } as Response);

        const result = await invoke('?shippingMethodId=unknown');

        expect(result.init?.status).toBe(404);
        expect(result.data).toEqual({ success: false, shippingMethodId: 'unknown' });
        expect(logger.error).toHaveBeenCalled();
    });
});
