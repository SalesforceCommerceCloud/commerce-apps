/**
 * A field the order is missing for a return, as listed by the order_for_return hook in `c_missingData`.
 * `field` comes from the zenkraftReturnRequiredFields preference; `label` is localised server-side.
 */
export type MissingDataField = {
    field: string;
    label: string;
};

export type MissingData = {
    missingData: MissingDataField[];
    missingDataLabel: string;
};

/**
 * Validates a value entered for a missing order field.
 * @returns The translation key of the validation error, or null if the value is valid
 */
export function validateMissingDataField(field: string, value: string): string | null {
    const trimmed = value.trim();
    if (!trimmed) return 'returns.missingData.invalid.required';

    switch (field) {
        case 'email':
            return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(trimmed) ? null : 'returns.missingData.invalid.email';
        case 'phone':
            return /^\+?[\d\s().-]{7,20}$/.test(trimmed) && (trimmed.match(/\d/g) ?? []).length >= 7
                ? null
                : 'returns.missingData.invalid.phone';
        case 'postcode':
            // Not US-specific: the storefront also serves en-GB
            return /^[A-Za-z\d][A-Za-z\d -]{1,9}$/.test(trimmed) ? null : 'returns.missingData.invalid.postcode';
        default:
            return null;
    }
}

/** Input type and autocomplete hint for a missing order field. */
export function getMissingDataInputProps(field: string): { type: string; autoComplete: string } {
    switch (field) {
        case 'email':
            return { type: 'email', autoComplete: 'email' };
        case 'phone':
            return { type: 'tel', autoComplete: 'tel' };
        case 'postcode':
            return { type: 'text', autoComplete: 'postal-code' };
        case 'address':
            return { type: 'text', autoComplete: 'address-line1' };
        default:
            return { type: 'text', autoComplete: 'off' };
    }
}
