import { describe, expect, test, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ConfigWrapper } from '@/test-utils/config';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';
import ZenkraftDropoffLocationPicker from './index';

// Stand-in for the lazily loaded Google map: one button per marker.
vi.mock('./dropoff-map', () => ({
    default: ({
        locations,
        onMarkerClick,
    }: {
        locations: ZenkraftDropoffLocation[];
        onMarkerClick: (code: string) => void;
    }) => (
        <div data-testid="dropoff-map">
            {locations.map((location) => (
                <button
                    key={location.location_code}
                    type="button"
                    onClick={() => onMarkerClick(location.location_code)}>
                    {`marker ${location.location_code}`}
                </button>
            ))}
        </div>
    ),
}));

const LOCATIONS: ZenkraftDropoffLocation[] = [
    {
        location_code: 'A1',
        display_name: 'Corner Shop',
        street1: '1 High Street',
        lat: '51.5072',
        lng: '-0.1276',
        distance: '0.4',
        distance_units: 'mi',
        operational_hours: { MON: { open: '09:00', close: '17:00' }, SAT: { open: '10:00' } },
    },
    { location_code: 'B2', display_name: 'Post Office', street1: '5 Market Square', lat: '51.51', lng: '-0.12' },
];

function renderPicker(props: Partial<Parameters<typeof ZenkraftDropoffLocationPicker>[0]> = {}) {
    const onValueChange = vi.fn();
    const onSelect = vi.fn();
    render(
        <ZenkraftDropoffLocationPicker
            locations={LOCATIONS}
            value="A1"
            onValueChange={onValueChange}
            onSelect={onSelect}
            {...props}
        />,
        { wrapper: ConfigWrapper }
    );
    return { onValueChange, onSelect };
}

describe('ZenkraftDropoffLocationPicker', () => {
    test('lists every location with distance, address and opening hours', () => {
        renderPicker();

        expect(screen.getByRole('radiogroup', { name: 'Collection points' })).toBeInTheDocument();
        expect(screen.getAllByRole('radio')).toHaveLength(2);
        expect(screen.getByText('0.4mi away')).toBeInTheDocument();
        expect(screen.getByText('1 High Street')).toBeInTheDocument();
        expect(screen.getByText('09:00 – 17:00')).toBeInTheDocument();
        expect(screen.getByText('10:00')).toBeInTheDocument();
        expect(screen.getAllByText('Closed')).toHaveLength(5);
    });

    test('offers "Select" only for the marked location and confirms it', async () => {
        const user = userEvent.setup();
        const { onSelect } = renderPicker();

        expect(screen.getAllByRole('button', { name: /^Select/ })).toHaveLength(1);
        await user.click(screen.getByRole('button', { name: 'Select Corner Shop' }));

        expect(onSelect).toHaveBeenCalledWith(LOCATIONS[0]);
    });

    test('marks a location picked from the list', async () => {
        const user = userEvent.setup();
        const { onValueChange } = renderPicker();

        await user.click(screen.getByRole('radio', { name: /Post Office/ }));

        expect(onValueChange).toHaveBeenCalledWith('B2');
    });

    test('omits the map when no Google Maps API key is configured', () => {
        renderPicker();

        expect(screen.queryByRole('region', { name: 'Map of collection points' })).not.toBeInTheDocument();
    });

    test('marks a location picked from the map', async () => {
        const user = userEvent.setup();
        const { onValueChange } = renderPicker({ googleMapsApiKey: 'test-key' });

        expect(screen.getByRole('region', { name: 'Map of collection points' })).toBeInTheDocument();
        await user.click(await screen.findByRole('button', { name: 'marker B2' }));

        expect(onValueChange).toHaveBeenCalledWith('B2');
    });
});
