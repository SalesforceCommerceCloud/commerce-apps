/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — fetches existing Zenkraft return cases for a given order.
 *
 * GET /resource/zenkraft-return-history?orderNo=...
 *
 * Calls the `returns` endpoint of the zenkraft-returns custom SCAPI API (int_zenkraft_sfnext),
 * which lists the order's return cases — stored in the instance (SFCC handler) or in the
 * Zenkraft API — with product details already filled in server-side. The endpoint only
 * answers for orders the shopper owns.
 *
 * Returns: ReturnCaseSummary[] (see lib/return-cases) | { error: string }
 */

import type { LoaderFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';
import { toReturnCaseSummaries } from '@/extensions/zenkraft-shipping/lib/return-cases';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

export function action() {
    return Response.json(null, { status: 405 });
}

export async function loader({ request, context }: LoaderFunctionArgs) {
    const url = new URL(request.url);
    const orderNo = url.searchParams.get('orderNo')?.trim() ?? '';

    if (!orderNo) {
        return Response.json({ error: 'orderNo is required' }, { status: 400 });
    }

    const logger = getLogger(context);

    try {
        const { accessToken, customerId } = getAuth(context);
        if (!customerId) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }

        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const params = new URLSearchParams({ siteId: siteCtx.site.id, c_orderNo: orderNo });
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/returns?${params}`;

        const response = await fetch(apiUrl, {
            cache: 'no-store',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json',
            },
        });

        if (response.status === 401) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }
        if (!response.ok) {
            logger.error('[zenkraft-shipping] returns call failed', { status: response.status });
            return Response.json({ error: 'Internal server error' }, { status: 500 });
        }

        const data = (await response.json()) as { returnCases?: unknown; error?: string };
        // The endpoint answers 'No order found' for an order that doesn't exist or isn't the shopper's
        if (data.error) {
            return Response.json({ error: 'Order not accessible' }, { status: 403 });
        }

        return Response.json(toReturnCaseSummaries(data.returnCases), { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] return history resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
