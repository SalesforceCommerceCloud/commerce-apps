/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — fetches existing Zenkraft return cases for a given order.
 *
 * GET /resource/zenkraft-return-history?orderNo=...
 *
 * Calls SCAPI getOrder with `c_returnFlow=true`, which triggers the
 * `dw.ocapi.shop.order.modifyGETResponse` hook (`hooks/orderForReturn.js` in
 * int_zenkraft_sfnext). That hook populates `c_returnCases` on the
 * order response with existing Zenkraft (or SFCC) return cases — product details
 * already enriched server-side. No separate Zenkraft API call needed.
 *
 * Returns: ReturnCaseSummary[] (see lib/return-cases) | { error: string }
 */

import type { LoaderFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { toReturnCaseSummaries } from '@/extensions/zenkraft-shipping/lib/return-cases';

export function action() {
    return Response.json(null, { status: 405 });
}

export async function loader({ request, context }: LoaderFunctionArgs) {
    const url = new URL(request.url);
    const orderNo = url.searchParams.get('orderNo')?.trim() ?? '';

    if (!orderNo) {
        return Response.json({ error: 'orderNo is required' }, { status: 400 });
    }

    const logger = getLogger(context);

    try {
        const { customerId } = getAuth(context);
        if (!customerId) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }

        const clients = createApiClients(context);

        let order: Record<string, unknown>;
        try {
            const result = await clients.shopperOrders.getOrder({
                params: {
                    path: { orderNo },
                    query: { c_returnFlow: true } as unknown as Record<string, never>,
                },
            });
            order = (result.data ?? result) as Record<string, unknown>;
        } catch (error) {
            const status = (error as { status?: number }).status;
            if (status === 401) return Response.json({ error: 'Authentication required' }, { status: 401 });
            if (status === 403 || status === 404) return Response.json({ error: 'Order not accessible' }, { status: 403 });
            throw error;
        }

        const returnCases = toReturnCaseSummaries(order.c_returnCases);

        return Response.json(returnCases, { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] return history resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
