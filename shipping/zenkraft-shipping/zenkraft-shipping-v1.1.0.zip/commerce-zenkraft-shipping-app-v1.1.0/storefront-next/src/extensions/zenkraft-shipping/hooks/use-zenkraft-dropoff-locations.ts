import { useCallback, useEffect } from 'react';
import { useFetcher } from 'react-router';
import type { loader as dropoffLocationsLoader } from '@/extensions/zenkraft-shipping/routes/resource.zenkraft-dropoff-locations';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';
import { resourceRoutes } from '@/route-paths';

export type DropoffLocationsStatus = 'idle' | 'loading' | 'error' | 'success';

const NO_LOCATIONS: ZenkraftDropoffLocation[] = [];

/**
 * Fetch the Zenkraft drop-off locations for a shipping method on demand.
 *
 * Loads as soon as a `shippingMethodId` is provided — mount the consumer only after the shopper
 * picks a drop-off shipping method (e.g. inside a lazily mounted dialog) so the request stays
 * interaction-driven. Results for a previous shipping method or shipment are ignored while the new one loads.
 *
 * @param shippingMethodId - ID of the drop-off shipping method, or `undefined` to stay idle
 * @param shipmentId - Shipment whose address the locations are searched around; omit for the default shipment
 * @returns The locations, the request status, and a `reload` action for retrying after an error
 *
 * @example
 * const { locations, status, reload } = useZenkraftDropoffLocations(shippingMethodId, shipmentId);
 */
export function useZenkraftDropoffLocations(shippingMethodId: string | undefined, shipmentId?: string) {
    const fetcher = useFetcher<typeof dropoffLocationsLoader>();
    const { load } = fetcher;

    const reload = useCallback(() => {
        if (!shippingMethodId) return;
        const params = new URLSearchParams({ shippingMethodId });
        if (shipmentId) params.set('shipmentId', shipmentId);
        void load(`${resourceRoutes.zenkraftDropoffLocations}?${params.toString()}`);
    }, [shippingMethodId, shipmentId, load]);

    useEffect(() => {
        reload();
    }, [reload]);

    const result =
        fetcher.data?.shippingMethodId === shippingMethodId && fetcher.data?.shipmentId === shipmentId
            ? fetcher.data
            : undefined;

    let status: DropoffLocationsStatus;
    if (!shippingMethodId) {
        status = 'idle';
    } else if (fetcher.state !== 'idle' || !result) {
        status = 'loading';
    } else {
        status = result.success ? 'success' : 'error';
    }

    return {
        locations: (status === 'success' && result?.locations) || NO_LOCATIONS,
        status,
        reload,
    };
}
