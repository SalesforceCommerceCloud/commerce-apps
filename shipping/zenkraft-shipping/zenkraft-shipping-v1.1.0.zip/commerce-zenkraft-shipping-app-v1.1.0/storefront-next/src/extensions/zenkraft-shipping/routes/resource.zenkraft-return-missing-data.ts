/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — proxies POST requests to the Zenkraft updateMissingData
 * custom SCAPI endpoint in int_zenkraft_sfnext.
 *
 * POST /resource/zenkraft-return-missing-data
 *   Body: { orderId, missingData: { [field]: value } }
 *
 * Used by the create-return page (/zenkraft-create-return) when the order is
 * missing details the return label needs (the zenkraftReturnRequiredFields
 * preference). The endpoint writes the values to the order and returns what is
 * still missing. It only accepts orders the shopper owns.
 *
 * Returns: { missingData: MissingData | null, status: 'Success' } | { error: string }
 */

import type { ActionFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

export function loader() {
    return Response.json(null, { status: 405 });
}

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);

    try {
        const { accessToken, customerId } = getAuth(context);
        if (!customerId) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }
        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const body = await request.json();
        const missingData = body?.missingData;
        if (
            !body ||
            typeof body.orderId !== 'string' ||
            !body.orderId.trim() ||
            !missingData ||
            typeof missingData !== 'object' ||
            Array.isArray(missingData) ||
            !Object.values(missingData).every((value) => typeof value === 'string')
        ) {
            return Response.json({ error: 'Invalid missing data request' }, { status: 400 });
        }

        const params = new URLSearchParams({ siteId });
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/updateMissingData?${params}`;

        const response = await fetch(apiUrl, {
            method: 'POST',
            cache: 'no-store',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify({ orderId: body.orderId, missingData }),
        });

        if (!response.ok) {
            logger.error('[zenkraft-shipping] updateMissingData call failed', {
                status: response.status,
            });
            return Response.json({ error: 'Failed to update order' }, { status: response.status });
        }

        const data = await response.json();
        return Response.json(data, { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] return missing data resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
