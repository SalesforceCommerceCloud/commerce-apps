import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const WEEKDAY_HOURS = { open: '08:00', close: '20:00' };

/** Sample Zenkraft drop-off locations for stories. */
export const DROPOFF_LOCATIONS: ZenkraftDropoffLocation[] = [
    {
        location_code: 'UPS-AP-1001',
        display_name: 'Corner Convenience Store',
        street1: '12 High Street',
        lat: '51.5079',
        lng: '-0.1281',
        distance: '0.3',
        distance_units: 'mi',
        operational_hours: {
            MON: WEEKDAY_HOURS,
            TUE: WEEKDAY_HOURS,
            WED: WEEKDAY_HOURS,
            THU: WEEKDAY_HOURS,
            FRI: WEEKDAY_HOURS,
            SAT: { open: '09:00', close: '18:00' },
            SUN: {},
        },
    },
    {
        location_code: 'UPS-AP-1002',
        display_name: 'Market Square Post Office',
        street1: '4 Market Square',
        lat: '51.5114',
        lng: '-0.1198',
        distance: '0.7',
        distance_units: 'mi',
        operational_hours: {
            MON: { open: '09:00', close: '17:30' },
            TUE: { open: '09:00', close: '17:30' },
            WED: { open: '09:00', close: '17:30' },
            THU: { open: '09:00', close: '17:30' },
            FRI: { open: '09:00', close: '17:30' },
            SAT: { open: '09:00', close: '12:30' },
        },
    },
    {
        location_code: 'UPS-AP-1003',
        display_name: 'Station Parcel Locker',
        street1: 'Platform 1, Central Station',
        lat: '51.5031',
        lng: '-0.1132',
        distance: '1.2',
        distance_units: 'mi',
    },
];
