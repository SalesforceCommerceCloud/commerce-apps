/** A returned product, as shown in the return history. */
export type ReturnLineItemSummary = {
    productId: string;
    productName: string;
    /** Absolute URL of the product's small image, when the product has one */
    imageUrl?: string;
    quantity: number;
    color?: string;
    size?: string;
    creationDate: string;
};

/**
 * The Return History page in My Account (routes/_app.account.zenkraft-returns.tsx). Kept in the extension
 * rather than in the template's route-paths.ts, so the page needs no change outside the extension.
 */
export const ACCOUNT_RETURNS_PATH = '/account/zenkraft-returns';

/** An existing return case for an order, as shown in the return history. */
export type ReturnCaseSummary = {
    id: string;
    /** Number of the order the return belongs to, when the source sends it */
    orderNo?: string;
    createdAt: string;
    trackingStage: string | null;
    trackingStatus: string | null;
    /** Base64 PDF label stored with an SFCC return case. Zenkraft API returns fetch theirs on demand instead. */
    label: string | null;
    /** True for returns created through the Zenkraft API, whose label comes from the getCombinedLabel endpoint. */
    zkReturnCase: boolean;
    returnLineItems: ReturnLineItemSummary[];
};

type VariationAttribute = {
    typeID: string;
    value: string;
};

type RawReturnLineItem = {
    productID: string;
    returnID?: string;
    product?: {
        title?: string;
        imageURL?: string;
        selectedVariationAttributes?: VariationAttribute[];
    };
    quantity: number;
    trackingStage?: string;
    creationDate?: string;
    approvedDate?: string;
    label?: string;
};

type RawReturnCase = {
    id?: string;
    orderNumber?: string;
    returnLineItems?: RawReturnLineItem[];
    combinedLabel?: string | false | null;
    zkReturnCase?: boolean;
};

/**
 * Maps return cases into the summaries the return history renders: the `c_returnCases` that the order_for_return
 * hook adds to a `c_returnFlow` order response, or the `returns` of the returnsHistory custom API.
 * Return cases without line items are dropped.
 */
export function toReturnCaseSummaries(rawCases: unknown): ReturnCaseSummary[] {
    if (!Array.isArray(rawCases)) return [];

    return (rawCases as RawReturnCase[])
        .filter((rc) => Array.isArray(rc.returnLineItems) && rc.returnLineItems.length > 0)
        .map((rc) => {
            const lines = rc.returnLineItems as RawReturnLineItem[];
            const firstLine = lines[0];
            const createdAt = firstLine.creationDate ?? '';

            return {
                id: rc.id ?? firstLine.returnID ?? '',
                orderNo: rc.orderNumber || undefined,
                createdAt,
                trackingStage: firstLine.trackingStage ?? null,
                trackingStatus: firstLine.approvedDate ? 'returnApproved' : 'returnAwaitingApproval',
                label: (typeof rc.combinedLabel === 'string' && rc.combinedLabel) || firstLine.label || null,
                zkReturnCase: rc.zkReturnCase === true,
                returnLineItems: lines.map((li) => {
                    const attrs = li.product?.selectedVariationAttributes ?? [];
                    return {
                        productId: li.productID,
                        productName: li.product?.title ?? li.productID,
                        imageUrl: li.product?.imageURL || undefined,
                        quantity: li.quantity,
                        color: attrs.find((a) => a.typeID === 'color')?.value,
                        size: attrs.find((a) => a.typeID === 'size')?.value,
                        creationDate: li.creationDate ?? createdAt,
                    };
                }),
            };
        });
}

/**
 * Sorts return cases newest first. Zenkraft API returns arrive grouped by order rather than by date;
 * a return case whose date can't be read goes last.
 */
export function sortReturnCasesNewestFirst(returnCases: ReturnCaseSummary[]): ReturnCaseSummary[] {
    const time = (rc: ReturnCaseSummary) => Date.parse(rc.createdAt) || 0;
    return [...returnCases].sort((a, b) => time(b) - time(a));
}
