import type { Meta, StoryObj } from '@storybook/react-vite';
import ZenkraftShipmentTrackBar from '../index';

const meta: Meta<typeof ZenkraftShipmentTrackBar> = {
    title: 'Extensions/Zenkraft Shipping/Shipment Track Bar',
    component: ZenkraftShipmentTrackBar,
    tags: ['autodocs'],
    parameters: { layout: 'padded' },
    args: {
        trackingNumber: '1Z999AA10123456784',
        carrier: 'ups',
        orderNo: '00000101',
    },
};

export default meta;
type Story = StoryObj<typeof ZenkraftShipmentTrackBar>;

export const Default: Story = {};

export const FedEx: Story = {
    args: { carrier: 'fedex', trackingNumber: '449044304137821' },
};
