
export type TrackingStepsVariant =
    | 'exception'
    | 'shipmentVoided'
    | 'missingStatus'
    | 'default'
    | 'returnRejected'
    | 'returnApproved'
    | 'returnAwaitingApproval';

export type TrackingStepKey =
    | 'pickedUp'
    | 'inTransit'
    | 'delayed'
    | 'outForDelivery'
    | 'delivered'
    | 'cancelled'
    | 'pending'
    | 'rejected'
    | 'approved'
    | 'awaiting'
    | 'label'
    | 'received';

/** Step sequence (as translation keys) rendered for each tracking variant. */
export const TRACKING_STEP_LABELS: Record<TrackingStepsVariant, TrackingStepKey[]> = {
    exception: ['inTransit', 'delayed', 'outForDelivery', 'delivered'],
    shipmentVoided: ['cancelled', 'delayed', 'outForDelivery', 'delivered'],
    missingStatus: ['pending', 'inTransit', 'outForDelivery', 'delivered'],
    default: ['pickedUp', 'inTransit', 'outForDelivery', 'delivered'],
    returnRejected: ['rejected', 'label', 'inTransit', 'received'],
    returnApproved: ['approved', 'label', 'inTransit', 'received'],
    returnAwaitingApproval: ['awaiting', 'label', 'inTransit', 'received'],
};

export interface TrackingStepsResult {
    variant: TrackingStepsVariant;
    activeStepIndex: number;
}

/**
 * Resolves which step sequence and active step index a shipment or return tracking bar should render,
 * from the tracking stage/status reported by the Zenkraft tracking API.
 */
export function getTrackingSteps(
    isReturn: boolean,
    trackingStatus: string | null | undefined,
    trackingStage: string | null | undefined
): TrackingStepsResult {
    if (isReturn) {
        if (trackingStatus === 'returnRejected') {
            return { variant: 'returnRejected', activeStepIndex: 0 };
        }
        if (trackingStatus === 'returnAwaitingApproval') {
            return { variant: 'returnAwaitingApproval', activeStepIndex: 0 };
        }
        if (trackingStatus !== 'returnApproved') {
            return { variant: 'returnAwaitingApproval', activeStepIndex: 0 };
        }

        let activeStepIndex = 1;
        if (trackingStage === 'DELIVERED') {
            activeStepIndex = 3;
        } else if (trackingStage && trackingStage !== 'CREATED') {
            activeStepIndex = 2;
        }
        return { variant: 'returnApproved', activeStepIndex };
    }

    if (trackingStage === 'EXCEPTION') {
        return { variant: 'exception', activeStepIndex: 1 };
    }
    if (trackingStage === 'SHIPMENT_VOIDED') {
        return { variant: 'shipmentVoided', activeStepIndex: 0 };
    }
    if (trackingStatus == null) {
        return { variant: 'missingStatus', activeStepIndex: 0 };
    }

    let activeStepIndex = trackingStage === 'PICKED_UP' ? 0 : 1;
    if (trackingStage === 'OUT_FOR_DELIVERY' || trackingStage === 'DELIVERED') {
        activeStepIndex = 2;
    }
    if (trackingStage === 'DELIVERED') {
        activeStepIndex = 3;
    }
    return { variant: 'default', activeStepIndex };
}
