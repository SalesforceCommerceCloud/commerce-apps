import { type ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { Check, TriangleAlert } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getTrackingSteps, TRACKING_STEP_LABELS } from '@/extensions/zenkraft-shipping/lib/tracking-steps';

export interface ZenkraftTrackBarProps {
    /** Whether this bar tracks a return shipment rather than an outbound order shipment. */
    isReturn?: boolean;
    /** Zenkraft tracking status (e.g. `returnRejected`), or the return's approval state. */
    trackingStatus?: string | null;
    /** Zenkraft tracking stage (e.g. `IN_TRANSIT`, `DELIVERED`, `EXCEPTION`). */
    trackingStage?: string | null;
}

/** Horizontal step progress bar for Zenkraft order/return shipment tracking. */
export default function ZenkraftTrackBar({
    isReturn = false,
    trackingStatus,
    trackingStage,
}: ZenkraftTrackBarProps): ReactElement {
    const { t } = useTranslation('extZenkraftShipping');
    const { variant, activeStepIndex } = getTrackingSteps(isReturn, trackingStatus, trackingStage);
    const steps = TRACKING_STEP_LABELS[variant];
    const isException = variant === 'exception';

    return (
        <ol className="flex w-full" aria-label={t('trackBar.ariaLabel')}>
            {steps.map((stepKey, index) => (
                <TrackBarStep
                    key={stepKey}
                    label={t(`trackBar.steps.${stepKey}`)}
                    status={index < activeStepIndex ? 'complete' : index === activeStepIndex ? 'active' : 'incomplete'}
                    isException={isException && index === activeStepIndex}
                    showConnector={index < steps.length - 1}
                    connectorComplete={index < activeStepIndex}
                />
            ))}
        </ol>
    );
}

function TrackBarStep({
    label,
    status,
    isException,
    showConnector,
    connectorComplete,
}: {
    label: string;
    status: 'complete' | 'active' | 'incomplete';
    /** Marks the active step as a shipment exception, styled distinctly from normal progress. */
    isException: boolean;
    showConnector: boolean;
    connectorComplete: boolean;
}): ReactElement {
    const isFilled = status !== 'incomplete';

    // Each step is centred in an equal-width column; the connector runs from this step's
    // circle centre to the next one's, underneath the circles.
    return (
        <li className="relative flex min-w-0 flex-1 flex-col items-center text-center">
            {showConnector && (
                <span
                    aria-hidden
                    className={cn(
                        'absolute left-1/2 top-[1.125rem] h-1 w-full -translate-y-1/2 rounded-full',
                        connectorComplete ? 'bg-primary' : 'bg-muted-foreground/25'
                    )}
                />
            )}
            <span
                aria-current={status === 'active' ? 'step' : undefined}
                className={cn(
                    'relative z-10 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2',
                    !isFilled && 'border-muted-foreground/40 bg-background',
                    isFilled && !isException && 'border-primary bg-primary text-primary-foreground',
                    isException && 'border-warning bg-warning text-warning-foreground',
                    status === 'active' && (isException ? 'ring-4 ring-warning/25' : 'ring-4 ring-primary/20')
                )}>
                {isFilled &&
                    (isException ? (
                        <TriangleAlert aria-hidden className="h-5 w-5" />
                    ) : (
                        <Check aria-hidden className="h-5 w-5" />
                    ))}
            </span>
            <span
                className={cn(
                    'mt-2 px-1 text-xs leading-tight sm:text-sm',
                    isFilled ? 'font-medium text-foreground' : 'text-muted-foreground'
                )}>
                {label}
            </span>
        </li>
    );
}
