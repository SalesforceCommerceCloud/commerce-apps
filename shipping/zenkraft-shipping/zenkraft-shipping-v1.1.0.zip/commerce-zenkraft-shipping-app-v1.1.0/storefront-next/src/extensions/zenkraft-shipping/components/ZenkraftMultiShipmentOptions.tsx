import React, { type FormEvent, lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { useFetcher, type SubmitTarget } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { resourceRoutes } from '@/route-paths';
import { ToggleCard, ToggleCardEdit, ToggleCardSummary } from '@/components/toggle-card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Typography } from '@/components/typography';
import { getDefaultShippingMethod } from '@/lib/customer/profile-utils';
import { useCustomerProfile } from '@/hooks/checkout/use-customer-profile';
import { useCheckoutContext } from '@/hooks/use-checkout';
import { formatAddress } from '@/lib/address/address-utils';
import { getShippingArrivalLabel } from '@/lib/checkout/shipping-arrival-label';
import { formatCurrency } from '@/lib/currency';
import { useBasket } from '@/providers/basket';
import type { CheckoutActionData } from '@/components/checkout/types';
import type { ShopperBasketsV2 } from '@/scapi';
import { useZenkraftShipping } from '@/extensions/zenkraft-shipping/providers/ZenkraftShippingProvider';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const ZenkraftDropoffDialog = lazy(() => import('@/extensions/zenkraft-shipping/components/dropoff-dialog'));

type DropoffShippingMethod = ShopperBasketsV2.schemas['ShippingMethod'] & {
    c_zenkraftDropOffMethod?: boolean;
};

interface ShippingMethodOption {
    id: string;
    name: string;
    description?: string;
    price: number;
    estimatedArrivalTime?: string;
    deliveryWindow?: ShopperBasketsV2.schemas['DeliveryWindow'];
    /** Whether the method ships to a collection point the shopper must pick (c_zenkraftDropOffMethod). */
    isDropoff: boolean;
}

/** Props of the multiship `ShippingMultiOptions` element the checkout passes as children. */
interface ShippingMultiOptionsProps {
    onSubmit: (formData: FormData) => void;
    isLoading: boolean;
    actionData?: CheckoutActionData;
    shipments?: ShopperBasketsV2.schemas['Shipment'][];
    shippingMethodsMap?: Record<string, ShopperBasketsV2.schemas['ShippingMethodResult']>;
    isCompleted: boolean;
    isEditing: boolean;
    onEdit: () => void;
}

type DropoffUpdate = {
    shipmentId: string;
    shippingMethodId: string;
    location: ZenkraftDropoffLocation;
};

const NO_SHIPMENTS: ShopperBasketsV2.schemas['Shipment'][] = [];
const NO_METHODS_MAP: Record<string, ShopperBasketsV2.schemas['ShippingMethodResult']> = {};

/**
 * Multi-address shipping options with Zenkraft drop-off support, rendered in place of the multiship
 * `ShippingMultiOptions` by ZenkraftShippingOptionsOverride.
 *
 * Mirrors ShippingMultiOptions (one method per shipment, auto-applied defaults for returning customers,
 * `shippingMethod_<shipmentId>` form fields handled by the multiship action) and adds a "Choose collection
 * point" button for drop-off methods on each shipment. Continue is blocked until every shipment with a
 * drop-off method has a collection point. The locations are stored on their shipments first, then the form
 * is submitted. Stale collection points on shipments that left a drop-off method are cleared by the
 * sfcc.app.shipping.calculate hook on the next basket recalculation.
 */
export default function ZenkraftMultiShipmentOptions({ children }: { children: React.ReactNode }) {
    const {
        onSubmit,
        isLoading,
        shipments = NO_SHIPMENTS,
        shippingMethodsMap = NO_METHODS_MAP,
        isEditing,
        onEdit,
    } = React.isValidElement(children)
        ? (children.props as ShippingMultiOptionsProps)
        : ({} as ShippingMultiOptionsProps);

    const customerProfile = useCustomerProfile();
    const { currency } = useSite();
    const { t, i18n } = useTranslation('checkout');
    const { t: tMultiship } = useTranslation('extMultiship');
    const { t: tZenkraft } = useTranslation('extZenkraftShipping');
    const { selectedLocations, getSelectedLocation, dialog, openDialog, closeDialog, setSelectedLocation, clearLocation } =
        useZenkraftShipping();
    const basket = useBasket();

    const locationFetcher = useFetcher<{ success: boolean; error?: string; failedShipmentId?: string }>();
    const [pendingFormData, setPendingFormData] = useState<FormData | null>(null);
    const [dropoffError, setDropoffError] = useState<string | null>(null);
    const [missingLocationShipmentIds, setMissingLocationShipmentIds] = useState<string[]>([]);
    // The shipment the server couldn't save; the shipments before it were saved
    const [failedShipmentId, setFailedShipmentId] = useState<string | null>(null);
    // Bumped when Continue ends in an error, so the first error is brought into view once, not on every render
    const [errorFocusRequest, setErrorFocusRequest] = useState(0);
    const formRef = useRef<HTMLFormElement>(null);
    const locationFetcherStarted = useRef(false);
    const hasAutoSubmitted = useRef(false);
    const onSubmitRef = useRef(onSubmit);
    onSubmitRef.current = onSubmit;

    const shipmentsData = useMemo(
        () =>
            shipments.map((shipment) => {
                const shipmentId = shipment.shipmentId ?? '';
                const shippingMethods = shipmentId ? shippingMethodsMap[shipmentId] : undefined;
                const availableShippingMethods: ShippingMethodOption[] = (
                    shippingMethods?.applicableShippingMethods ?? []
                )
                    .filter(
                        (method) => method.id && method.name && typeof method.price === 'number' && !isNaN(method.price)
                    )
                    .map((method) => ({
                        id: method.id ?? '',
                        name: method.name ?? '',
                        description: method.description,
                        price: method.price ?? 0,
                        estimatedArrivalTime: (method.estimatedArrivalTime ?? method.c_estimatedArrivalTime) as
                            | string
                            | undefined,
                        deliveryWindow: method.deliveryWindow,
                        isDropoff: (method as DropoffShippingMethod).c_zenkraftDropOffMethod === true,
                    }));
                const selectedMethod = shipment.shippingMethod;
                const defaultShippingMethodId = getDefaultShippingMethod(
                    availableShippingMethods,
                    selectedMethod,
                    shippingMethods?.defaultShippingMethodId
                );

                return { shipment, shipmentId, availableShippingMethods, selectedMethod, defaultShippingMethodId };
            }),
        [shipments, shippingMethodsMap]
    );

    // Radios the shopper picked in this edit session, by shipment. Until they interact each shipment
    // follows its basket method, and the picks reset once the basket's methods change (e.g. after Continue).
    const [checkedMethods, setCheckedMethods] = useState<Record<string, string>>({});
    const basketMethodsKey = shipmentsData.map((data) => `${data.shipmentId}:${data.selectedMethod?.id ?? ''}`).join('|');
    useEffect(() => {
        setCheckedMethods({});
    }, [basketMethodsKey]);

    // Phase 2: once the collection points are stored on their shipments, submit the shipping methods.
    useEffect(() => {
        if (!pendingFormData) return;
        if (locationFetcher.state !== 'idle') {
            locationFetcherStarted.current = true;
            return;
        }
        if (!locationFetcherStarted.current) return;

        locationFetcherStarted.current = false;
        const formData = pendingFormData;
        setPendingFormData(null);

        if (locationFetcher.data && !locationFetcher.data.success) {
            // Show the error on the shipment that failed, or above the shipments when the server didn't name one
            if (locationFetcher.data.failedShipmentId) {
                setFailedShipmentId(locationFetcher.data.failedShipmentId);
            } else {
                setDropoffError(tZenkraft('shippingOptions.saveError'));
            }
            setErrorFocusRequest((count) => count + 1);
            return;
        }

        onSubmitRef.current(formData);
    }, [pendingFormData, locationFetcher.state, locationFetcher.data]); // eslint-disable-line react-hooks/exhaustive-deps

    // The error can be below the fold (e.g. under the second shipment): scroll the first one into view and focus it
    useEffect(() => {
        if (errorFocusRequest === 0) return;
        const firstError = formRef.current?.querySelector<HTMLElement>('[data-zenkraft-error]');
        if (!firstError) return;
        if (typeof firstError.scrollIntoView === 'function') {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        firstError.focus({ preventScroll: true });
    }, [errorFocusRequest]);

    // Auto-apply default shipping methods for returning customers only, as ShippingMultiOptions does.
    // A drop-off default still needs a collection point — requiresDropoffSelection keeps the step open for it.
    useEffect(() => {
        if (isEditing && customerProfile && shipmentsData.length > 0 && !hasAutoSubmitted.current && !isLoading) {
            const shipmentsNeedingMethod = shipmentsData.filter(
                (data) => !data.selectedMethod?.id && data.availableShippingMethods.length > 0
            );

            if (shipmentsNeedingMethod.length > 0) {
                hasAutoSubmitted.current = true;
                const formData = new FormData();

                shipmentsData.forEach((data) => {
                    if (!data.shipmentId) return;

                    if (data.selectedMethod?.id) {
                        formData.append(`shippingMethod_${data.shipmentId}`, data.selectedMethod.id);
                        return;
                    }

                    const isDefaultValid =
                        data.defaultShippingMethodId &&
                        data.availableShippingMethods.some((method) => method.id === data.defaultShippingMethodId);
                    const methodIdToSubmit = isDefaultValid
                        ? data.defaultShippingMethodId
                        : data.availableShippingMethods[0]?.id;

                    if (methodIdToSubmit) {
                        formData.append(`shippingMethod_${data.shipmentId}`, methodIdToSubmit);
                    }
                });

                onSubmit(formData);
            }
        }

        if (!isEditing) {
            hasAutoSubmitted.current = false;
        }
    }, [isEditing, customerProfile, shipmentsData, onSubmit, isLoading]);

    // Keep the step open while any shipment's basket method is a drop-off method without a collection
    // point saved on that shipment (e.g. an auto-applied default, or a point a new address cleared).
    // A point picked in the dialog only counts once Continue saves it on the shipment.
    const requiresDropoffSelection = shipmentsData.some((data) => {
        const methodId = data.selectedMethod?.id;
        const isDropoff = data.availableShippingMethods.some((method) => method.id === methodId && method.isDropoff);
        const hasSavedPoint = Boolean((data.shipment as { c_zenkraftDropOffData?: string | null }).c_zenkraftDropOffData);
        return !!methodId && isDropoff && !hasSavedPoint;
    });
    const isEditingEffective = isEditing || requiresDropoffSelection;

    // When checkout has moved past this step while a point is missing, bring checkout back to it, so
    // Place Order waits until the points are saved. Not while the shopper edits an earlier step.
    const { step: checkoutStep, editingStep, STEPS } = useCheckoutContext();
    useEffect(() => {
        const movedPast =
            checkoutStep > STEPS.SHIPPING_OPTIONS && (editingStep === null || editingStep > STEPS.SHIPPING_OPTIONS);
        if (requiresDropoffSelection && !isEditing && movedPast) onEdit();
    }, [requiresDropoffSelection, isEditing, checkoutStep, editingStep]); // eslint-disable-line react-hooks/exhaustive-deps

    const handleMethodChange = (shipmentId: string, methodId: string) => {
        setCheckedMethods((prev) => ({ ...prev, [shipmentId]: methodId }));
        setMissingLocationShipmentIds((prev) => prev.filter((id) => id !== shipmentId));
        setFailedShipmentId((prev) => (prev === shipmentId ? null : prev));
        // A collection point belongs to the method it was picked for — drop it when the shopper
        // moves this shipment to another method so it isn't shown under a method that is no longer selected.
        const stored = selectedLocations[shipmentId];
        if (stored && stored.methodId !== methodId) clearLocation(shipmentId);
    };

    const handleSelect = (location: ZenkraftDropoffLocation) => {
        if (dialog) {
            const { shipmentId, methodId } = dialog;
            setSelectedLocation(shipmentId, methodId, location);
            // Picking a collection point selects its shipping method for that shipment.
            setCheckedMethods((prev) => ({ ...prev, [shipmentId]: methodId }));
            setMissingLocationShipmentIds((prev) => prev.filter((id) => id !== shipmentId));
            setFailedShipmentId((prev) => (prev === shipmentId ? null : prev));
        }
        closeDialog();
    };

    const isSettingLocation = pendingFormData !== null || locationFetcher.state !== 'idle';

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const updates: DropoffUpdate[] = [];
        const missing: string[] = [];

        for (const data of shipmentsData) {
            const methodId = data.shipmentId ? formData.get(`shippingMethod_${data.shipmentId}`) : null;
            if (typeof methodId !== 'string') continue;
            if (!data.availableShippingMethods.some((method) => method.id === methodId && method.isDropoff)) continue;

            const location = getSelectedLocation(data.shipmentId, methodId);
            if (location) {
                updates.push({ shipmentId: data.shipmentId, shippingMethodId: methodId, location });
            } else {
                missing.push(data.shipmentId);
            }
        }

        setMissingLocationShipmentIds(missing);
        setDropoffError(null);
        setFailedShipmentId(null);
        if (missing.length > 0) {
            setErrorFocusRequest((count) => count + 1);
            return;
        }

        if (updates.length > 0 && basket?.basketId) {
            // Phase 1: store each collection point with its drop-off method on its shipment, so
            // calculateShipping.js rates every shipment against its collection point. Phase 2 submits
            // the shipping methods once the fetcher returns to idle.
            locationFetcherStarted.current = false;
            setPendingFormData(formData);
            locationFetcher.submit(
                // ZenkraftDropoffLocation is JSON-serializable but its nested Partial<Record<…>>
                // type doesn't satisfy react-router's JsonObject index signature; assert via unknown.
                { basketId: basket.basketId, shipments: updates } as unknown as SubmitTarget,
                { method: 'post', action: resourceRoutes.zenkraftSetDropoffLocation, encType: 'application/json' }
            );
        } else {
            onSubmit(formData);
        }
    };

    const formatPrice = (price: number) =>
        price === 0 ? t('shippingOptions.free') : formatCurrency(price, i18n.language, currency);

    const hasNoMethods = shipmentsData.every((data) => data.availableShippingMethods.length === 0);
    const canSubmit = !isLoading && !isSettingLocation && !hasNoMethods && shipmentsData.length > 0;
    const showShipmentLabel = shipments.length > 1;

    const stepTitle = (
        <span className="text-2xl font-bold tracking-tight text-card-foreground">
            {tMultiship('checkout.shippingMultiOptionsTitle')}
        </span>
    );

    return (
        <>
            <ToggleCard
                id="shipping-multi-options"
                title={stepTitle}
                editing={isEditingEffective}
                onEdit={onEdit}
                editLabel={t('common.edit')}
                showHeaderSeparator
                isLoading={isLoading}>
                <ToggleCardEdit>
                    <form ref={formRef} method="post" className="space-y-8" onSubmit={handleSubmit}>
                        {dropoffError && (
                            <p
                                className="text-sm text-destructive focus:outline-none"
                                role="alert"
                                tabIndex={-1}
                                data-zenkraft-error>
                                {dropoffError}
                            </p>
                        )}

                        {shipmentsData.length === 0 ? (
                            <div className="flex items-center justify-center p-8 border-2 border-dashed border-muted">
                                <Typography variant="p" className="text-muted-foreground">
                                    {tMultiship('checkout.noShipmentsAvailable')}
                                </Typography>
                            </div>
                        ) : (
                            shipmentsData.map((data, shipmentIndex) => {
                                const { shipmentId } = data;
                                const shipmentNumber = shipmentIndex + 1;
                                const { nameLine, addressLine } = formatAddress(
                                    data.shipment.shippingAddress,
                                    tMultiship('checkout.noAddress')
                                );
                                const checkedMethodId =
                                    checkedMethods[shipmentId] ??
                                    (data.selectedMethod?.id || data.defaultShippingMethodId || '');
                                const isMissingLocation = missingLocationShipmentIds.includes(shipmentId);
                                const isSaveFailed = failedShipmentId === shipmentId;

                                return (
                                    <div
                                        key={shipmentId || `shipment-${shipmentIndex}`}
                                        className="border border-border p-4 space-y-4">
                                        {showShipmentLabel && (
                                            <div className="-m-4 mb-4">
                                                <div className="bg-muted px-4 py-3">
                                                    <span className="text-base font-semibold text-foreground">
                                                        {nameLine
                                                            ? tMultiship('checkout.shipmentNumberWithRecipient', {
                                                                  number: shipmentNumber,
                                                                  name: nameLine,
                                                              })
                                                            : tMultiship('checkout.shipmentNumber', {
                                                                  number: shipmentNumber,
                                                              })}
                                                    </span>
                                                </div>
                                                <div className="px-4 py-3 border-b border-border">
                                                    <Typography variant="small" className="text-muted-foreground">
                                                        {addressLine}
                                                    </Typography>
                                                </div>
                                            </div>
                                        )}

                                        {isMissingLocation && (
                                            <p
                                                className="text-sm text-destructive focus:outline-none"
                                                role="alert"
                                                tabIndex={-1}
                                                data-zenkraft-error>
                                                {tZenkraft('shippingOptions.selectLocationError')}
                                            </p>
                                        )}

                                        {isSaveFailed && (
                                            <p
                                                className="text-sm text-destructive focus:outline-none"
                                                role="alert"
                                                tabIndex={-1}
                                                data-zenkraft-error>
                                                {tZenkraft('shippingOptions.saveError')}
                                            </p>
                                        )}

                                        {data.availableShippingMethods.length > 0 ? (
                                            <RadioGroup
                                                name={`shippingMethod_${shipmentId}`}
                                                value={checkedMethodId}
                                                onValueChange={(methodId) => handleMethodChange(shipmentId, methodId)}
                                                required
                                                aria-label={tMultiship('checkout.shippingMethodsForShipment', {
                                                    number: shipmentNumber,
                                                })}>
                                                {data.availableShippingMethods.map((method) => {
                                                    const arrivalLabel = getShippingArrivalLabel(
                                                        method,
                                                        t,
                                                        i18n.language
                                                    );
                                                    const radioId = `${shipmentId}-${method.id}`;
                                                    const chosenLocation = method.isDropoff
                                                        ? getSelectedLocation(shipmentId, method.id)
                                                        : undefined;

                                                    return (
                                                        <div
                                                            key={method.id}
                                                            className="group flex items-start space-x-4 p-4 rounded-ui border-2 transition-all duration-200 hover:border-primary/50 hover:bg-accent/30 has-[:checked]:border-primary has-[:checked]:bg-accent has-[:checked]:shadow-md">
                                                            <RadioGroupItem
                                                                value={method.id}
                                                                id={radioId}
                                                                className="w-5 h-5 mt-0.5"
                                                                // oxlint-disable-next-line jsx-a11y/no-autofocus -- focus first radio of first shipment on toggle card edit mode (WCAG 2.4.3 focus order); expanding section is the exception the rule warns about
                                                                autoFocus={
                                                                    isEditing &&
                                                                    shipmentIndex === 0 &&
                                                                    data.availableShippingMethods.indexOf(method) === 0
                                                                }
                                                            />
                                                            <div className="flex-1 space-y-2">
                                                                <Label
                                                                    htmlFor={radioId}
                                                                    className="block cursor-pointer group-has-[:checked]:text-foreground">
                                                                    <div className="space-y-1">
                                                                        {arrivalLabel && (
                                                                            <Typography
                                                                                variant="small"
                                                                                className="text-muted-foreground group-has-[:checked]:text-foreground font-bold text-base">
                                                                                {arrivalLabel}
                                                                            </Typography>
                                                                        )}
                                                                        <Typography
                                                                            variant="small"
                                                                            className="text-muted-foreground group-has-[:checked]:text-foreground text-base">
                                                                            {method.name}
                                                                        </Typography>
                                                                    </div>
                                                                </Label>

                                                                {/* Zenkraft: choose / change this shipment's collection point */}
                                                                {method.isDropoff && (
                                                                    <div className="flex flex-col gap-1">
                                                                        <Button
                                                                            type="button"
                                                                            variant="link"
                                                                            size="sm"
                                                                            className="h-auto w-fit p-0 text-sm"
                                                                            onClick={() => {
                                                                                setDropoffError(null);
                                                                                openDialog(shipmentId, method.id);
                                                                            }}>
                                                                            {chosenLocation
                                                                                ? tZenkraft('shippingOptions.changeLocation')
                                                                                : tZenkraft('shippingOptions.chooseLocation')}
                                                                        </Button>
                                                                        {chosenLocation && (
                                                                            <span className="text-sm text-muted-foreground">
                                                                                {chosenLocation.display_name}
                                                                                {chosenLocation.distance != null && (
                                                                                    <>
                                                                                        {' · '}
                                                                                        {tZenkraft('dropoff.distanceAway', {
                                                                                            distance: chosenLocation.distance,
                                                                                            unit: chosenLocation.distance_units,
                                                                                        })}
                                                                                    </>
                                                                                )}
                                                                            </span>
                                                                        )}
                                                                    </div>
                                                                )}
                                                            </div>
                                                            <Typography
                                                                variant="small"
                                                                className="text-muted-foreground group-has-[:checked]:text-foreground font-bold text-base">
                                                                {formatPrice(method.price)}
                                                            </Typography>
                                                        </div>
                                                    );
                                                })}
                                            </RadioGroup>
                                        ) : (
                                            <div className="flex items-center justify-center p-6 border-2 border-dashed border-muted">
                                                <Typography variant="small" className="text-muted-foreground">
                                                    {t('shippingOptions.noMethodsAvailable')}
                                                </Typography>
                                            </div>
                                        )}
                                    </div>
                                );
                            })
                        )}

                        <div className="w-full pt-2">
                            <Button type="submit" disabled={!canSubmit} className="w-full">
                                {isLoading || isSettingLocation
                                    ? t('shippingOptions.saving')
                                    : hasNoMethods
                                      ? t('shippingOptions.noMethodsAvailable')
                                      : t('shippingOptions.continue')}
                            </Button>
                        </div>
                    </form>
                </ToggleCardEdit>

                <ToggleCardSummary>
                    <div className="space-y-4">
                        {shipmentsData.length === 0 ? (
                            <Typography variant="p" className="text-muted-foreground">
                                {t('shippingOptions.enterAddressFirst')}
                            </Typography>
                        ) : (
                            shipmentsData.map((data, shipmentIndex) => {
                                const { selectedMethod } = data;
                                const selectedAvailableMethod = data.availableShippingMethods.find(
                                    (method) => method.id === selectedMethod?.id
                                );
                                const summaryArrivalLabel = getShippingArrivalLabel(
                                    {
                                        deliveryWindow:
                                            selectedAvailableMethod?.deliveryWindow ?? selectedMethod?.deliveryWindow,
                                        estimatedArrivalTime: (selectedAvailableMethod?.estimatedArrivalTime ??
                                            selectedMethod?.estimatedArrivalTime ??
                                            selectedMethod?.c_estimatedArrivalTime) as string | undefined,
                                    },
                                    t,
                                    i18n.language
                                );
                                const summaryLocation =
                                    selectedMethod?.id && selectedAvailableMethod?.isDropoff
                                        ? getSelectedLocation(data.shipmentId, selectedMethod.id)
                                        : undefined;

                                return (
                                    <div key={data.shipmentId || `shipment-${shipmentIndex}`} className="space-y-2">
                                        {showShipmentLabel && (
                                            <>
                                                <Typography variant="small" className="font-semibold text-foreground">
                                                    {tMultiship('checkout.shipmentNumber', {
                                                        number: shipmentIndex + 1,
                                                    })}
                                                </Typography>
                                                <Typography variant="small" className="text-muted-foreground text-xs">
                                                    {
                                                        formatAddress(
                                                            data.shipment.shippingAddress,
                                                            tMultiship('checkout.noAddress')
                                                        ).fullAddress
                                                    }
                                                </Typography>
                                            </>
                                        )}
                                        {selectedMethod ? (
                                            <div className="space-y-1">
                                                {summaryArrivalLabel && (
                                                    <Typography variant="small" className="text-muted-foreground">
                                                        {summaryArrivalLabel}
                                                    </Typography>
                                                )}
                                                <Typography variant="small" className="text-muted-foreground">
                                                    {t('shippingOptions.priceAndMethod', {
                                                        // The basket shipment's method carries the Business Manager price;
                                                        // the applicable-methods entry carries the Zenkraft rate shown in the list.
                                                        price: formatPrice(
                                                            selectedAvailableMethod?.price ?? selectedMethod.price ?? 0
                                                        ),
                                                        methodName: selectedMethod.name || '',
                                                    })}
                                                </Typography>
                                                {summaryLocation && (
                                                    <Typography variant="small" className="text-muted-foreground">
                                                        {summaryLocation.display_name}
                                                    </Typography>
                                                )}
                                            </div>
                                        ) : (
                                            <Typography variant="small" className="text-muted-foreground">
                                                {tMultiship('checkout.noMethodSelected')}
                                            </Typography>
                                        )}
                                    </div>
                                );
                            })
                        )}
                    </div>
                </ToggleCardSummary>
            </ToggleCard>

            {/* Drop-off location picker dialog, searched around the shipment it was opened for */}
            {dialog && (
                <Suspense fallback={null}>
                    <ZenkraftDropoffDialog
                        open
                        onOpenChange={(open: boolean) => {
                            if (!open) closeDialog();
                        }}
                        shippingMethodId={dialog.methodId}
                        shipmentId={dialog.shipmentId}
                        selectedLocationCode={getSelectedLocation(dialog.shipmentId, dialog.methodId)?.location_code}
                        onSelect={handleSelect}
                    />
                </Suspense>
            )}
        </>
    );
}
