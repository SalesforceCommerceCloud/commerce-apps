import { type ReactElement, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import ZenkraftDropoffLocationPicker from '@/extensions/zenkraft-shipping/components/dropoff-location-picker';
import ZenkraftDropoffLocationPickerSkeleton from '@/extensions/zenkraft-shipping/components/dropoff-location-picker/skeleton';
import { useZenkraftDropoffLocations } from '@/extensions/zenkraft-shipping/hooks/use-zenkraft-dropoff-locations';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

export interface ZenkraftDropoffDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    /** Drop-off shipping method to list collection points for. Locations load when the dialog mounts. */
    shippingMethodId: string;
    /** Shipment whose address the collection points are searched around; omit for the default shipment. */
    shipmentId?: string;
    /** `location_code` of the currently chosen location, marked when the dialog opens. */
    selectedLocationCode?: string;
    /** Called with the confirmed location; the dialog closes afterwards. */
    onSelect: (location: ZenkraftDropoffLocation) => void;
}

/**
 * Collection point dialog for Zenkraft drop-off shipping methods.
 *
 * Lazy-load it and mount it only while open, per the overlay guidelines:
 *
 * @example
 * const ZenkraftDropoffDialog = lazy(() => import('@/extensions/zenkraft-shipping/components/dropoff-dialog'));
 *
 * const [open, setOpen] = useState(false);
 * const mounted = useDeferredUnmount(open);
 * {mounted && (
 *     <Suspense fallback={null}>
 *         <ZenkraftDropoffDialog open={open} onOpenChange={setOpen} shippingMethodId={id} onSelect={setLocation} />
 *     </Suspense>
 * )}
 */
export default function ZenkraftDropoffDialog({
    open,
    onOpenChange,
    shippingMethodId,
    shipmentId,
    selectedLocationCode,
    onSelect,
}: ZenkraftDropoffDialogProps): ReactElement {
    const { t } = useTranslation('extZenkraftShipping');
    const { locations, status, reload } = useZenkraftDropoffLocations(shippingMethodId, shipmentId);
    const [markedCode, setMarkedCode] = useState(selectedLocationCode);

    // Fall back to the nearest location until the shopper marks one.
    const isMarkedAvailable = locations.some((location) => location.location_code === markedCode);
    const value = isMarkedAvailable ? markedCode : locations[0]?.location_code;

    const handleSelect = (location: ZenkraftDropoffLocation) => {
        onSelect(location);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent
                className="max-h-[calc(100dvh-2rem)] overflow-y-auto sm:max-w-6xl"
                // Keep an accidental click outside from discarding the shopper's browsing of the map.
                onInteractOutside={(event) => event.preventDefault()}>
                <DialogHeader>
                    <DialogTitle className="text-2xl font-bold">{t('dropoff.dialog.title')}</DialogTitle>
                    {(status !== 'success' || locations.length > 0) && (
                        <DialogDescription>{t('dropoff.dialog.description')}</DialogDescription>
                    )}
                </DialogHeader>

                {status === 'loading' && <ZenkraftDropoffLocationPickerSkeleton />}

                {status === 'error' && (
                    <Alert variant="destructive">
                        <AlertDescription className="flex flex-col items-start gap-3">
                            {t('dropoff.loadError')}
                            <Button type="button" variant="outline" size="sm" onClick={reload}>
                                {t('dropoff.retry')}
                            </Button>
                        </AlertDescription>
                    </Alert>
                )}

                {status === 'success' && locations.length === 0 && (
                    <p className="text-sm text-muted-foreground">{t('dropoff.empty')}</p>
                )}

                {status === 'success' && locations.length > 0 && (
                    <ZenkraftDropoffLocationPicker
                        locations={locations}
                        value={value}
                        onValueChange={setMarkedCode}
                        onSelect={handleSelect}
                    />
                )}
            </DialogContent>
        </Dialog>
    );
}
