/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Create Return Page — /zenkraft-create-return?orderNo=<orderNo>
 *
 * Multi-step return wizard:
 *   Step 1 – Select items to return
 *   Step 2 – Select return reasons, quantities, and the photo a reason may require
 *   Step 3 – Select return method and download label
 *              (or submit return request if returnsRequireApproval is set)
 *
 * If the order is missing details the return label needs (`missingData`), a form to
 * add them replaces the wizard until they are filled in. Existing returns for the order
 * are listed below the wizard.
 *
 * Loader:
 *   - Requires auth; redirects to /login if unauthenticated
 *   - Fetches order via shopperOrders.getOrder
 *   - Fetches the return settings, existing return cases, missing data and each item's return
 *     options (returnable quantity, reasons) via the zenkraft-returns custom SCAPI `returns` endpoint
 *   - Fetches product images and custom attributes via shopperProducts.getProducts
 *
 * Client-side API calls via resource routes:
 *   - POST /resource/zenkraft-return-missing-data → update the order's missing details
 *   - POST /resource/zenkraft-return-photo        → store a reason photo (SFCC returns handler)
 *   - POST /resource/zenkraft-return-methods      → available return shipping methods
 *   - POST /resource/zenkraft-return-label        → base64 PDF label
 *
 * Translations namespace: extZenkraftShipping
 */

import { useState, useRef, useEffect } from 'react';
import { type LoaderFunctionArgs, redirect, useLoaderData, useRevalidator } from 'react-router';
import { Link } from '@/components/link';
import { resourceRoutes } from '@/route-paths';
import { useTranslation } from 'react-i18next';
import type { ShopperOrders, ShopperProducts } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext, useSite } from '@salesforce/storefront-next-runtime/site-context';
import { formatCurrency } from '@/lib/currency';
import { getScapiBaseUrl } from '@/lib/utils';
import { SeoMeta } from '@/components/seo-meta';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { NativeSelect, NativeSelectOption } from '@/components/ui/native-select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ProductItemVariantImage } from '@/components/product-item';
import type { EnrichedProductItem } from '@/lib/product/product-utils';
import { ChevronLeft, Download, QrCode, Upload, X, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
    ZenkraftReturnMethodsModal,
    type ReturnMethod,
} from '../components/zenkraft-return-methods-modal';
import { ZenkraftReturnCaseList } from '../components/zenkraft-returns/zenkraft-return-case-list';
import {
    toReturnCaseSummaries,
    toReturnQrCode,
    type ReturnCaseSummary,
    type ReturnQrCode,
} from '../lib/return-cases';
import {
    getMissingDataInputProps,
    validateMissingDataField,
    type MissingData,
} from '../lib/missing-data';
import {
    isReasonPhotoFormatAllowed,
    isReasonPhotoRequired,
    getReasonPhotoMaxBytes,
    prepareReasonPhoto,
    type ReasonPhotoLimits,
} from '../lib/reason-photo';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

// ─── Types ────────────────────────────────────────────────────────────────────

type Order = ShopperOrders.schemas['Order'];
type OrderProductItem = NonNullable<Order['productItems']>[number];
type ProductsById = Record<string, ShopperProducts.schemas['Product'] | undefined>;

type ReturnReason = {
    id: string;
    display: string;
    photoRequired?: boolean;
    values?: Array<{ id: string; display: string; photoRequired?: boolean }>;
};

/** Return options of an order item, as the returns endpoint lists them. `itemId` is the order item's ID. */
type ItemReturnOptions = {
    itemId: string;
    applicableForReturn: boolean;
    /** How many are left to return */
    returnableQuantity: number;
    returnReasons: ReturnReason[];
};

type ReturnableItem = OrderProductItem & Omit<ItemReturnOptions, 'itemId'>;

type ReturnConfig = {
    zenkraftReturnsHandler?: string;
    returnsRequireApproval?: boolean;
    reasonPhotoLimits?: ReasonPhotoLimits;
    availableForReturn?: boolean;
};

/** Response of the returns endpoint: the return settings, plus the order's return data. */
type OrderReturnsResponse = ReturnConfig & {
    returnCases?: unknown;
    missingData?: MissingData | null;
    /** Sent while the order can be returned */
    items?: ItemReturnOptions[];
};

type ReturnDetail = {
    reasonId: string;
    subReasonId: string;
    quantity: number;
    photoFile?: File;
    photoUrl?: string;
    /** ID of the uploaded reason photo, returned by /resource/zenkraft-return-photo */
    reasonPhotoId?: string;
};

type LoaderData =
    | {
          state: 'success';
          order: Order;
          /** The order's product items with their return options */
          items: ReturnableItem[];
          returnConfig: ReturnConfig;
          productsById: ProductsById;
          returnCases: ReturnCaseSummary[];
          missingData: MissingData | null;
      }
    | { state: 'not-found' }
    | { state: 'unavailable' };

// ─── Server Helpers ───────────────────────────────────────────────────────────

async function fetchOrderReturns(
    context: LoaderFunctionArgs['context'],
    orderNo: string
): Promise<OrderReturnsResponse | null> {
    const logger = getLogger(context);
    const { accessToken } = getAuth(context);
    const config = getConfig(context);
    const { shortCode, organizationId } = config.commerce.api;
    const siteCtx = context.get(siteContext) as SiteContext;
    const siteId = siteCtx.site.id;
    const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

    const params = new URLSearchParams({ siteId, c_orderNo: orderNo });
    const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/returns?${params}`;

    try {
        const response = await fetch(apiUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json',
            },
        });

        if (!response.ok) {
            logger.warn('[zenkraft-shipping] fetchOrderReturns failed', { status: response.status, orderNo });
            return null;
        }

        return (await response.json()) as OrderReturnsResponse;
    } catch (error) {
        logger.error('[zenkraft-shipping] fetchOrderReturns threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return null;
    }
}

// ─── Loader ───────────────────────────────────────────────────────────────────

export async function loader({ request, context }: LoaderFunctionArgs): Promise<LoaderData | Response> {
    const session = getAuth(context);
    if (!session.customerId) {
        return redirect('/login');
    }

    const url = new URL(request.url);
    const orderNo = url.searchParams.get('orderNo');
    if (!orderNo) {
        return redirect('/account/orders');
    }

    const logger = getLogger(context);

    try {
        const clients = createApiClients(context);
        const currency = (context.get(siteContext) as SiteContext).currency;

        const [orderResult, orderReturns] = await Promise.all([
            clients.shopperOrders.getOrder({ params: { path: { orderNo } } }),
            fetchOrderReturns(context, orderNo),
        ]);

        if (!orderReturns?.availableForReturn) {
            return { state: 'unavailable' };
        }

        // The return data is passed on on its own, so the return cases' labels aren't sent to the page twice
        const { returnCases, missingData, items: itemReturnOptions, ...returnConfig } = orderReturns;
        const order = orderResult.data;

        const returnOptionsById = new Map((itemReturnOptions ?? []).map((options) => [options.itemId, options]));
        // An item the returns endpoint doesn't list can't be returned
        const items: ReturnableItem[] = (order.productItems ?? []).map((item) => {
            const options = returnOptionsById.get(item.itemId ?? '');
            return {
                ...item,
                applicableForReturn: options?.applicableForReturn === true,
                returnableQuantity: options?.returnableQuantity ?? 0,
                returnReasons: options?.returnReasons ?? [],
            };
        });

        const productIds = Array.from(
            new Set(
                (order.productItems ?? [])
                    .map((item) => item.productId)
                    .filter((id): id is string => typeof id === 'string' && id.length > 0)
            )
        );

        const productsById: ProductsById = {};
        if (productIds.length > 0) {
            try {
                const { data: productsData } = await clients.shopperProducts.getProducts({
                    params: {
                        query: {
                            ids: productIds,
                            expand: ['images', 'variations'],
                            currency,
                        },
                    },
                });
                (productsData?.data ?? []).forEach((product) => {
                    productsById[product.id] = product;
                });
            } catch {
                // non-critical — page renders without images
            }
        }

        return {
            state: 'success',
            order,
            items,
            returnConfig,
            productsById,
            returnCases: toReturnCaseSummaries(returnCases),
            missingData: missingData?.missingData?.length ? missingData : null,
        };
    } catch (error) {
        const status = (error as { status?: number })?.status;
        if (status === 404) return { state: 'not-found' };

        logger.error('[zenkraft-shipping] create-return loader failed', {
            orderNo,
            message: error instanceof Error ? error.message : String(error),
        });
        return redirect('/account/orders');
    }
}

// ─── Missing Order Data ───────────────────────────────────────────────────────

type MissingDataResponse = { missingData?: MissingData | null; status?: string; error?: string };

function MissingDataForm({
    orderNo,
    missingData,
    onUpdated,
    t,
}: {
    orderNo: string;
    missingData: MissingData;
    onUpdated: (remaining: MissingData | null) => void;
    t: (key: string) => string;
}) {
    const [values, setValues] = useState<Record<string, string>>({});
    const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const errors: Record<string, string> = {};
        missingData.missingData.forEach(({ field }) => {
            const errorKey = validateMissingDataField(field, values[field] ?? '');
            if (errorKey) errors[field] = t(errorKey);
        });
        setFieldErrors(errors);
        if (Object.keys(errors).length > 0) return;

        setIsSubmitting(true);
        setError(null);
        try {
            const entered: Record<string, string> = {};
            missingData.missingData.forEach(({ field }) => {
                entered[field] = (values[field] ?? '').trim();
            });
            const res = await fetch('/resource/zenkraft-return-missing-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ orderId: orderNo, missingData: entered }),
            });
            if (!res.ok) throw new Error(String(res.status));
            const data = (await res.json()) as MissingDataResponse;
            if (data.error) throw new Error(data.error);
            onUpdated(data.missingData?.missingData?.length ? data.missingData : null);
        } catch {
            setError(t('returns.missingData.error'));
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle className="text-base">{t('returns.missingData.title')}</CardTitle>
                <p className="text-sm text-muted-foreground">{t('returns.missingData.description')}</p>
            </CardHeader>
            <CardContent>
                <form noValidate onSubmit={(e) => void handleSubmit(e)} className="space-y-4">
                    {missingData.missingData.map(({ field, label }) => {
                        const inputId = `missing-${field}`;
                        const fieldError = fieldErrors[field];
                        return (
                            <div key={field} className="space-y-2">
                                <Label htmlFor={inputId}>{label}</Label>
                                <Input
                                    id={inputId}
                                    name={field}
                                    {...getMissingDataInputProps(field)}
                                    value={values[field] ?? ''}
                                    onChange={(e) => {
                                        const value = e.target.value;
                                        setValues((prev) => ({ ...prev, [field]: value }));
                                    }}
                                    aria-invalid={Boolean(fieldError)}
                                    aria-describedby={fieldError ? `${inputId}-error` : undefined}
                                />
                                {fieldError && (
                                    <p id={`${inputId}-error`} className="text-sm text-destructive">
                                        {fieldError}
                                    </p>
                                )}
                            </div>
                        );
                    })}

                    {error && (
                        <p role="alert" className="text-sm text-destructive">{error}</p>
                    )}

                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? t('returns.action.loading') : t('returns.missingData.submit')}
                    </Button>
                </form>
            </CardContent>
        </Card>
    );
}

// ─── Step Indicator ───────────────────────────────────────────────────────────

const STEP_KEYS = ['selectItems', 'selectReasons', 'getLabel'] as const;

function StepIndicator({ currentStep }: { currentStep: number }) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extZenkraftShipping' as any);

    return (
        <ol className="flex items-start gap-0 mb-8" aria-label={t('returns.steps.ariaLabel')}>
            {STEP_KEYS.map((key, index) => {
                const step = index + 1;
                const isCompleted = step < currentStep;
                const isActive = step === currentStep;
                return (
                    <li key={key} className="flex flex-1 flex-col">
                        <div className="flex w-full items-center">
                            <span
                                aria-current={isActive ? 'step' : undefined}
                                className={cn(
                                    'flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-sm font-semibold',
                                    isCompleted &&
                                        'border-primary bg-primary text-primary-foreground',
                                    isActive &&
                                        'border-primary bg-background text-primary',
                                    !isCompleted &&
                                        !isActive &&
                                        'border-muted-foreground/40 bg-background text-muted-foreground'
                                )}
                            >
                                {isCompleted ? (
                                    <Check aria-hidden className="h-4 w-4" />
                                ) : (
                                    step
                                )}
                            </span>
                            {index < STEP_KEYS.length - 1 && (
                                <span
                                    className={cn(
                                        'h-0.5 flex-1',
                                        isCompleted ? 'bg-primary' : 'bg-muted-foreground/20'
                                    )}
                                />
                            )}
                        </div>
                        <span
                            className={cn(
                                'mt-2 text-xs',
                                isActive
                                    ? 'font-medium text-foreground'
                                    : 'text-muted-foreground'
                            )}
                        >
                            {t(`returns.steps.${key}`)}
                        </span>
                    </li>
                );
            })}
        </ol>
    );
}

// ─── Step 1: Select Items ─────────────────────────────────────────────────────

function Step1SelectItems({
    items,
    productsById,
    selectedItemIds,
    onToggleItem,
    onNext,
    currency,
    language,
    t,
}: {
    items: ReturnableItem[];
    productsById: ProductsById;
    selectedItemIds: Set<string>;
    onToggleItem: (itemId: string) => void;
    onNext: () => void;
    currency: string;
    language: string;
    t: (key: string) => string;
}) {
    const returnableItems = items.filter((item) => item.applicableForReturn);
    const nonReturnableItems = items.filter((item) => !item.applicableForReturn);

    return (
        <div className="space-y-4">
            {returnableItems.map((item) => {
                const itemId = item.itemId ?? '';
                const productData = item.productId ? productsById[item.productId] : undefined;
                const enrichedItem = { ...productData, ...item } as EnrichedProductItem;
                const isSelected = selectedItemIds.has(itemId);

                return (
                    <Card
                        key={itemId}
                        className={cn(
                            'cursor-pointer transition-colors',
                            isSelected && 'border-primary bg-primary/5'
                        )}
                        onClick={() => onToggleItem(itemId)}
                    >
                        <CardContent className="flex items-center gap-4 p-4">
                            <Checkbox
                                id={`item-${itemId}`}
                                checked={isSelected}
                                onCheckedChange={() => onToggleItem(itemId)}
                                onClick={(e) => e.stopPropagation()}
                            />
                            <ProductItemVariantImage
                                productItem={enrichedItem}
                                className="h-16 w-16 shrink-0"
                            />
                            <div className="min-w-0 flex-1">
                                <p className="truncate text-sm font-medium text-foreground">
                                    {item.productName || item.itemText || item.productId}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                    {t('returns.item.qty')}: {item.returnableQuantity}
                                </p>
                            </div>
                            {item.price != null && (
                                <div className="shrink-0 text-sm font-medium">
                                    {formatCurrency(item.price, language, currency)}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                );
            })}

            {nonReturnableItems.length > 0 && (
                <div className="space-y-2">
                    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                        {t('returns.item.nonReturnableTitle')}
                    </p>
                    {nonReturnableItems.map((item) => {
                        const itemId = item.itemId ?? '';
                        const productData = item.productId ? productsById[item.productId] : undefined;
                        const enrichedItem = { ...productData, ...item } as EnrichedProductItem;
                        return (
                            <Card key={itemId} className="opacity-50">
                                <CardContent className="flex items-center gap-4 p-4">
                                    <div className="h-5 w-5 shrink-0" />
                                    <ProductItemVariantImage
                                        productItem={enrichedItem}
                                        className="h-16 w-16 shrink-0 grayscale"
                                    />
                                    <div className="min-w-0 flex-1">
                                        <p className="truncate text-sm font-medium text-foreground">
                                            {item.productName || item.itemText || item.productId}
                                        </p>
                                        <p className="text-xs text-muted-foreground">
                                            {t('returns.item.notEligible')}
                                        </p>
                                    </div>
                                    {item.price != null && (
                                        <div className="shrink-0 text-sm text-muted-foreground">
                                            {formatCurrency(item.price, language, currency)}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>
            )}

            <div className="flex justify-end pt-4">
                <Button onClick={onNext} disabled={selectedItemIds.size === 0}>
                    {t('returns.action.continue')}
                </Button>
            </div>
        </div>
    );
}

// ─── Photo Upload ─────────────────────────────────────────────────────────────

function PhotoUpload({
    itemId,
    photoUrl,
    error,
    onFileChange,
    t,
}: {
    itemId: string;
    photoUrl?: string;
    error?: string;
    onFileChange: (file: File | undefined, url: string | undefined) => void;
    t: (key: string) => string;
}) {
    const inputRef = useRef<HTMLInputElement>(null);

    const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        // So the same file can be picked again after it was turned down
        e.target.value = '';
        if (!file) return;
        if (photoUrl) URL.revokeObjectURL(photoUrl);
        onFileChange(file, URL.createObjectURL(file));
    };

    const handleRemove = () => {
        if (inputRef.current) inputRef.current.value = '';
        if (photoUrl) URL.revokeObjectURL(photoUrl);
        onFileChange(undefined, undefined);
    };

    return (
        <div className="space-y-2">
            <Label>{t('returns.photo.label')}</Label>
            {photoUrl ? (
                <div className="flex items-center gap-3">
                    <img
                        src={photoUrl}
                        alt=""
                        className="h-20 w-20 rounded-md border border-border object-cover"
                    />
                    <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleRemove}
                        className="border-destructive text-destructive hover:bg-destructive/10"
                    >
                        <X className="mr-1 h-3 w-3" />
                        {t('returns.photo.remove')}
                    </Button>
                </div>
            ) : (
                <>
                    <input
                        ref={inputRef}
                        id={`photo-${itemId}`}
                        type="file"
                        accept="image/*"
                        className="sr-only"
                        onChange={handleFile}
                    />
                    <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => inputRef.current?.click()}
                    >
                        <Upload className="mr-1 h-3 w-3" />
                        {t('returns.photo.upload')}
                    </Button>
                    <p className="text-xs text-muted-foreground">{t('returns.photo.required')}</p>
                </>
            )}
            {error && (
                <p role="alert" className="text-sm text-destructive">{error}</p>
            )}
        </div>
    );
}

// ─── Step 2: Select Reasons ───────────────────────────────────────────────────

function Step2SelectReasons({
    selectedItems,
    productsById,
    returnDetails,
    photoErrors,
    isUploadingPhotos,
    onUpdateDetail,
    onPhotoChange,
    onBack,
    onNext,
    t,
}: {
    selectedItems: ReturnableItem[];
    productsById: ProductsById;
    returnDetails: Record<string, ReturnDetail>;
    photoErrors: Record<string, string>;
    isUploadingPhotos: boolean;
    onUpdateDetail: (itemId: string, update: Partial<ReturnDetail>) => void;
    onPhotoChange: (itemId: string, file: File | undefined, url: string | undefined) => void;
    onBack: () => void;
    onNext: () => void;
    t: (key: string) => string;
}) {
    const allComplete = selectedItems.every((item) => {
        const detail = returnDetails[item.itemId ?? ''];
        if (!detail?.reasonId) return false;
        const reason = item.returnReasons.find((r) => r.id === detail.reasonId);
        const hasSubReasons = (reason?.values?.length ?? 0) > 0;
        if (hasSubReasons && !detail.subReasonId) return false;
        return isReasonPhotoRequired(reason, detail.subReasonId)
            ? Boolean(detail.photoFile || detail.reasonPhotoId)
            : true;
    });

    return (
        <div className="space-y-6">
            {selectedItems.map((item) => {
                const itemId = item.itemId ?? '';
                const productData = item.productId ? productsById[item.productId] : undefined;
                const enrichedItem = { ...productData, ...item } as EnrichedProductItem;
                const detail = returnDetails[itemId];
                const returnReasons = item.returnReasons;
                const selectedReason = returnReasons.find((r) => r.id === detail?.reasonId);
                const subReasons = selectedReason?.values ?? [];
                const photoRequired = isReasonPhotoRequired(selectedReason, detail?.subReasonId);
                const maxQty = item.returnableQuantity;

                return (
                    <Card key={itemId}>
                        <CardHeader className="pb-3">
                            <div className="flex items-center gap-3">
                                <ProductItemVariantImage
                                    productItem={enrichedItem}
                                    className="h-12 w-12 shrink-0"
                                />
                                <CardTitle className="text-sm font-medium">
                                    {item.productName || item.itemText || item.productId}
                                </CardTitle>
                            </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div className="space-y-2">
                                    <Label htmlFor={`reason-${itemId}`}>
                                        {t('returns.reason.label')}
                                    </Label>
                                    <NativeSelect
                                        id={`reason-${itemId}`}
                                        value={detail?.reasonId ?? ''}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            const reason = returnReasons.find((r) => r.id === value);
                                            onUpdateDetail(itemId, {
                                                reasonId: value,
                                                subReasonId: reason?.values?.[0]?.id ?? '',
                                                photoFile: undefined,
                                                photoUrl: undefined,
                                                reasonPhotoId: undefined,
                                            });
                                        }}
                                    >
                                        <NativeSelectOption value="">
                                            {t('returns.reason.placeholder')}
                                        </NativeSelectOption>
                                        {returnReasons.map((reason) => (
                                            <NativeSelectOption key={reason.id} value={reason.id}>
                                                {reason.display}
                                            </NativeSelectOption>
                                        ))}
                                    </NativeSelect>
                                </div>

                                <div className="space-y-2">
                                    <Label htmlFor={`subreason-${itemId}`}>
                                        {t('returns.reason.subLabel')}
                                    </Label>
                                    <NativeSelect
                                        id={`subreason-${itemId}`}
                                        value={detail?.subReasonId ?? ''}
                                        disabled={!detail?.reasonId || subReasons.length === 0}
                                        onChange={(e) => {
                                            const subReasonId = e.target.value;
                                            onUpdateDetail(itemId, {
                                                subReasonId,
                                                // Keep the photo only while the sub-reason still asks for one
                                                ...(isReasonPhotoRequired(selectedReason, subReasonId)
                                                    ? {}
                                                    : { photoFile: undefined, photoUrl: undefined, reasonPhotoId: undefined }),
                                            });
                                        }}
                                    >
                                        <NativeSelectOption value="">
                                            {t('returns.reason.subPlaceholder')}
                                        </NativeSelectOption>
                                        {subReasons.map((sr) => (
                                            <NativeSelectOption key={sr.id} value={sr.id}>
                                                {sr.display}
                                            </NativeSelectOption>
                                        ))}
                                    </NativeSelect>
                                </div>
                            </div>

                            {maxQty > 1 && (
                                <div className="w-32 space-y-2">
                                    <Label htmlFor={`qty-${itemId}`}>
                                        {t('returns.reason.quantity')}
                                    </Label>
                                    <NativeSelect
                                        id={`qty-${itemId}`}
                                        value={String(detail?.quantity ?? 1)}
                                        onChange={(e) =>
                                            onUpdateDetail(itemId, { quantity: Number(e.target.value) })
                                        }
                                    >
                                        {Array.from({ length: maxQty }, (_, i) => i + 1).map(
                                            (n) => (
                                                <NativeSelectOption key={n} value={String(n)}>
                                                    {n}
                                                </NativeSelectOption>
                                            )
                                        )}
                                    </NativeSelect>
                                </div>
                            )}

                            {photoRequired && (
                                <PhotoUpload
                                    itemId={itemId}
                                    photoUrl={detail?.photoUrl}
                                    error={photoErrors[itemId]}
                                    onFileChange={(file, url) => onPhotoChange(itemId, file, url)}
                                    t={t}
                                />
                            )}
                        </CardContent>
                    </Card>
                );
            })}

            <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={onBack}>
                    <ChevronLeft className="mr-1 h-4 w-4" />
                    {t('returns.action.back')}
                </Button>
                <Button onClick={onNext} disabled={!allComplete || isUploadingPhotos}>
                    {isUploadingPhotos ? t('returns.photo.uploading') : t('returns.action.continue')}
                </Button>
            </div>
        </div>
    );
}

// ─── Step 3: Get Label ────────────────────────────────────────────────────────

type ReturnMethodsResponse = ReturnMethod[] | { error: string };

type ReturnLabelResponse = {
    /** The created SFCC return case; qrCode is set when the carrier sent one for a drop-off without a printed label */
    returnObject?: { combinedLabel?: string; qrCode?: string | null; qrCodeType?: string | null };
    labelData?: { shipment?: { label?: string } };
    error?: string | boolean;
    errorMessage?: string;
};

function buildReturnPayload(
    order: Order,
    selectedItems: ReturnableItem[],
    returnDetails: Record<string, ReturnDetail>
) {
    // Strip browser-only fields that cannot be JSON-serialized.
    // File → {} and blob: URLs are meaningless to the server.
    const serializableDetails: Record<string, Omit<ReturnDetail, 'photoFile' | 'photoUrl'>> = {};
    for (const [key, { photoFile: _f, photoUrl: _u, ...rest }] of Object.entries(returnDetails)) {
        serializableDetails[key] = rest;
    }

    return {
        orderId: order.orderNo,
        items: selectedItems.map((item) => {
            const itemId = item.itemId ?? '';
            const detail = returnDetails[itemId];
            return {
                itemId,
                UUID: item.itemId ?? '',
                productId: item.productId,
                productName: item.productName ?? item.itemText ?? '',
                productPrice: (item as { price?: number }).price ?? 0,
                quantity: detail?.quantity ?? item.returnableQuantity,
                reasonId: detail?.reasonId,
                subReasonId: detail?.subReasonId,
            };
        }),
        returnDetails: serializableDetails,
    };
}

function Step3GetLabel({
    order,
    selectedItems,
    productsById,
    returnDetails,
    requiresApproval,
    usesZenkraftApi,
    onBack,
    onReturnCreated,
    t,
}: {
    order: Order;
    selectedItems: ReturnableItem[];
    productsById: ProductsById;
    returnDetails: Record<string, ReturnDetail>;
    requiresApproval: boolean;
    usesZenkraftApi: boolean;
    onBack: () => void;
    onReturnCreated: () => void;
    t: (key: string) => string;
}) {
    const [methods, setMethods] = useState<ReturnMethod[]>([]);
    const [selectedMethodId, setSelectedMethodId] = useState<string>('');
    const [isMethodsDialogOpen, setIsMethodsDialogOpen] = useState(false);
    const [isLoadingMethods, setIsLoadingMethods] = useState(false);
    const [methodsRequestKey, setMethodsRequestKey] = useState(0);
    const [isLoadingLabel, setIsLoadingLabel] = useState(false);
    // One label or return request at a time: the buttons are only disabled after the next render, so a quick second
    // click would otherwise create a second return
    const labelRequestInFlight = useRef(false);
    const [label, setLabel] = useState<string | null>(null);
    const [qrCode, setQrCode] = useState<ReturnQrCode | null>(null);
    const [returnSubmitted, setReturnSubmitted] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (requiresApproval || !usesZenkraftApi) return;

        const controller = new AbortController();
        let active = true;
        setIsLoadingMethods(true);
        setError(null);
        fetch(resourceRoutes.zenkraftReturnMethods, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(buildReturnPayload(order, selectedItems, returnDetails)),
            signal: controller.signal,
        })
            .then((res) => (res.ok ? (res.json() as Promise<ReturnMethodsResponse>) : Promise.reject(res.status)))
            .then((data) => {
                if (!active) return;
                if (!Array.isArray(data)) throw new Error(data.error);
                const methodList = data
                    .filter(
                        (method) =>
                            method &&
                            typeof method.id === 'string' &&
                            Array.isArray(method.options)
                    )
                    .map((method) => ({
                        ...method,
                        options: method.options.filter(
                            (option) => option && typeof option.id === 'string' && option.id.length > 0
                        ),
                    }))
                    .filter((method) => method.options.length > 0);
                if (methodList.length === 0) throw new Error('No return methods available');
                setMethods(methodList);
                if (methodList.length === 1) {
                    const optionId = methodList[0].options[0].id;
                    setSelectedMethodId(optionId);
                    void handleGetLabel(optionId);
                } else {
                    setIsMethodsDialogOpen(true);
                }
            })
            .catch(() => {
                if (active) setError(t('returns.error.methods'));
            })
            .finally(() => {
                if (active) setIsLoadingMethods(false);
            });
        return () => {
            active = false;
            controller.abort();
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [methodsRequestKey]);

    const handleGetLabel = async (methodId?: string) => {
        if (labelRequestInFlight.current) return;
        labelRequestInFlight.current = true;
        setIsLoadingLabel(true);
        setError(null);
        try {
            const payload = { ...buildReturnPayload(order, selectedItems, returnDetails), methodId };
            const res = await fetch(resourceRoutes.zenkraftReturnLabel, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            if (!res.ok) throw new Error(String(res.status));
            const data = (await res.json()) as ReturnLabelResponse;
            if (data.error || data.errorMessage) {
                setError(
                    data.errorMessage ??
                        (typeof data.error === 'string' ? data.error : t('returns.error.label'))
                );
            } else {
                const returnLabel = methodId
                    ? data.labelData?.shipment?.label
                    : data.returnObject?.combinedLabel;
                if (!returnLabel) throw new Error('Return label missing from response');
                setLabel(returnLabel);
                // Only SFCC return cases store the QR code, as in SFRA
                setQrCode(methodId ? null : toReturnQrCode(data.returnObject?.qrCode, data.returnObject?.qrCodeType));
                onReturnCreated();
            }
        } catch {
            setError(t('returns.error.label'));
        } finally {
            labelRequestInFlight.current = false;
            setIsLoadingLabel(false);
        }
    };

    const handleRequestReturn = async () => {
        if (labelRequestInFlight.current) return;
        labelRequestInFlight.current = true;
        setIsLoadingLabel(true);
        setError(null);
        try {
            const res = await fetch(resourceRoutes.zenkraftReturnLabel, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(buildReturnPayload(order, selectedItems, returnDetails)),
            });
            if (!res.ok) throw new Error(String(res.status));
            const data = (await res.json()) as ReturnLabelResponse;
            if (data.error) {
                setError(
                    data.errorMessage ??
                        (typeof data.error === 'string' ? data.error : t('returns.error.submit'))
                );
            } else {
                setReturnSubmitted(true);
                onReturnCreated();
            }
        } catch {
            setError(t('returns.error.submit'));
        } finally {
            labelRequestInFlight.current = false;
            setIsLoadingLabel(false);
        }
    };

    return (
        <div className="space-y-6">
            {/* Summary */}
            <Card>
                <CardHeader>
                    <CardTitle className="text-base">{t('returns.summary.title')}</CardTitle>
                </CardHeader>
                <CardContent>
                    <ul className="divide-y divide-border">
                        {selectedItems.map((item) => {
                            const itemId = item.itemId ?? '';
                            const detail = returnDetails[itemId];
                            const productData = item.productId ? productsById[item.productId] : undefined;
                            const enrichedItem = { ...productData, ...item } as EnrichedProductItem;
                            return (
                                <li
                                    key={itemId}
                                    className="flex items-center gap-3 py-3"
                                >
                                    <ProductItemVariantImage
                                        productItem={enrichedItem}
                                        className="h-12 w-12 shrink-0"
                                    />
                                    <div>
                                        <p className="text-sm font-medium text-foreground">
                                            {item.productName || item.itemText}
                                        </p>
                                        <p className="text-xs text-muted-foreground">
                                            {t('returns.item.qty')}:{' '}
                                            {detail?.quantity ?? item.returnableQuantity}
                                        </p>
                                    </div>
                                </li>
                            );
                        })}
                    </ul>
                </CardContent>
            </Card>

            {/* Zenkraft API return method selection */}
            {!requiresApproval && usesZenkraftApi && (
                <>
                    {isLoadingMethods && (
                        <p className="text-sm text-muted-foreground">{t('returns.methods.loading')}</p>
                    )}
                    {!selectedMethodId && methods.length > 0 && !isMethodsDialogOpen && (
                        <Button variant="outline" onClick={() => setIsMethodsDialogOpen(true)}>
                            {t('returns.methods.title')}
                        </Button>
                    )}
                    {isMethodsDialogOpen && (
                        <ZenkraftReturnMethodsModal
                            methods={methods}
                            selectedOptionId={selectedMethodId}
                            onClose={() => setIsMethodsDialogOpen(false)}
                            onConfirm={(optionId) => {
                                setSelectedMethodId(optionId);
                                setIsMethodsDialogOpen(false);
                                void handleGetLabel(optionId);
                            }}
                        />
                    )}
                </>
            )}

            {/* Error */}
            {error && (
                <div className="space-y-2">
                    <p role="alert" className="text-sm text-destructive">{error}</p>
                    {!requiresApproval && usesZenkraftApi && !isLoadingMethods && !isLoadingLabel && (
                        <Button
                            variant="outline"
                            onClick={() => {
                                if (selectedMethodId) {
                                    void handleGetLabel(selectedMethodId);
                                } else {
                                    setMethodsRequestKey((key) => key + 1);
                                }
                            }}
                        >
                            {t('returns.action.retry')}
                        </Button>
                    )}
                </div>
            )}

            {/* Label download */}
            {label && (
                <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-3">
                    <p className="text-sm font-medium text-foreground">
                        {t('returns.label.ready')}
                    </p>
                    <div className="flex flex-wrap gap-2">
                        <Button asChild>
                            <a
                                href={`data:application/pdf;base64,${label}`}
                                download="return-label.pdf"
                                target="_blank"
                                rel="noreferrer"
                            >
                                <Download className="mr-2 h-4 w-4" />
                                {t('returns.label.download')}
                            </a>
                        </Button>
                        {qrCode && (
                            <Button asChild variant="outline">
                                <a
                                    href={`data:${qrCode.mimeType};base64,${qrCode.data}`}
                                    download={`return-qr-code.${qrCode.extension}`}
                                >
                                    <QrCode className="mr-2 h-4 w-4" />
                                    {t('returns.label.downloadQrCode')}
                                </a>
                            </Button>
                        )}
                    </div>
                </div>
            )}

            {/* Approval submitted confirmation */}
            {returnSubmitted && (
                <div className="rounded-lg border border-border bg-muted/50 p-4">
                    <p className="text-sm font-medium text-foreground">
                        {t('returns.approval.submitted')}
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">
                        {t('returns.approval.description')}
                    </p>
                </div>
            )}

            <div className="flex justify-between pt-4">
                <Button
                    variant="outline"
                    onClick={onBack}
                    disabled={isLoadingLabel || !!label || returnSubmitted}
                >
                    <ChevronLeft className="mr-1 h-4 w-4" />
                    {t('returns.action.back')}
                </Button>
                {!label && !returnSubmitted && (
                    <>
                        {requiresApproval ? (
                            <Button onClick={handleRequestReturn} disabled={isLoadingLabel}>
                                {isLoadingLabel
                                    ? t('returns.action.loading')
                                    : t('returns.action.requestReturn')}
                            </Button>
                        ) : !usesZenkraftApi ? (
                            <Button
                                onClick={() => void handleGetLabel()}
                                disabled={isLoadingLabel}
                            >
                                {isLoadingLabel
                                    ? t('returns.action.loading')
                                    : t('returns.action.getLabel')}
                            </Button>
                        ) : null}
                    </>
                )}
            </div>
        </div>
    );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function ZenkraftCreateReturnPage() {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t, i18n } = useTranslation('extZenkraftShipping' as any);
    const { currency } = useSite();
    const data = useLoaderData<typeof loader>();
    const revalidator = useRevalidator();

    const [activeStep, setActiveStep] = useState(1);
    const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());
    const [returnDetails, setReturnDetails] = useState<Record<string, ReturnDetail>>({});
    // undefined until the missing-data form is submitted; then whatever the server says is still missing
    const [updatedMissingData, setUpdatedMissingData] = useState<MissingData | null | undefined>(undefined);
    const [photoErrors, setPhotoErrors] = useState<Record<string, string>>({});
    const [isUploadingPhotos, setIsUploadingPhotos] = useState(false);
    // Set once the label is received or the approval request is submitted, so every step shows as done
    const [isReturnComplete, setIsReturnComplete] = useState(false);

    if (data.state === 'not-found') {
        return (
            <div className="container mx-auto px-4 py-12 text-center">
                <p className="text-muted-foreground">{t('returns.error.orderNotFound')}</p>
                <Button asChild className="mt-4" variant="outline">
                    <Link to="/account/orders">{t('returns.action.backToOrders')}</Link>
                </Button>
            </div>
        );
    }

    if (data.state === 'unavailable') {
        return (
            <div className="container mx-auto px-4 py-12 text-center">
                <p className="text-muted-foreground">{t('returns.error.unavailable')}</p>
                <Button asChild className="mt-4" variant="outline">
                    <Link to="/account/orders">{t('returns.action.backToOrders')}</Link>
                </Button>
            </div>
        );
    }

    const { order, items: orderItems, returnConfig, productsById, returnCases } = data;
    const selectedItems = orderItems.filter((item) =>
        selectedItemIds.has(item.itemId ?? '')
    );
    const requiresApproval = returnConfig.returnsRequireApproval ?? false;
    const usesZenkraftApi = returnConfig.zenkraftReturnsHandler === 'zkapi';
    const missingData = updatedMissingData !== undefined ? updatedMissingData : data.missingData;

    const handleToggleItem = (itemId: string) => {
        setSelectedItemIds((prev) => {
            const next = new Set(prev);
            if (next.has(itemId)) {
                next.delete(itemId);
            } else {
                next.add(itemId);
            }
            return next;
        });
        // Initialize return detail for new selections
        setReturnDetails((prev) => {
            if (prev[itemId]) return prev;
            const item = orderItems.find((i) => i.itemId === itemId);
            if (!item) return prev;
            return {
                ...prev,
                [itemId]: {
                    reasonId: '',
                    subReasonId: '',
                    quantity: item.returnableQuantity,
                },
            };
        });
    };

    const handleUpdateDetail = (itemId: string, update: Partial<ReturnDetail>) => {
        setReturnDetails((prev) => ({ ...prev, [itemId]: { ...prev[itemId], ...update } }));
        if ('photoFile' in update) {
            setPhotoErrors((prev) => {
                if (!prev[itemId]) return prev;
                const next = { ...prev };
                delete next[itemId];
                return next;
            });
        }
    };

    // Checks a picked photo against the limits uploadReasonImage enforces, so a wrong format or a photo that can't be
    // made small enough is reported right away, as in the SFRA cartridge, rather than on Continue. Unlike SFRA, the
    // size that counts is the JPEG the photo is turned into for upload, since that is what the endpoint stores.
    const handlePhotoChange = async (itemId: string, file: File | undefined, url: string | undefined) => {
        if (!file) {
            handleUpdateDetail(itemId, { photoFile: undefined, photoUrl: undefined, reasonPhotoId: undefined });
            return;
        }

        const limits = returnConfig.reasonPhotoLimits;
        const wrongFormat = limits?.acceptableFileFormatsWarningMsg || t('returns.photo.wrongFormat');
        let problem: string | null = null;
        if (!isReasonPhotoFormatAllowed(file.name, limits)) {
            problem = wrongFormat;
        } else {
            try {
                const photo = await prepareReasonPhoto(
                    file,
                    limits?.imageScale ?? undefined,
                    getReasonPhotoMaxBytes(limits)
                );
                if (!photo) {
                    problem = limits?.sizeLimitWarningMsg || t('returns.photo.tooLarge');
                }
            } catch {
                // Not an image the browser can read
                problem = wrongFormat;
            }
        }

        if (problem !== null) {
            const message = problem;
            if (url) URL.revokeObjectURL(url);
            setPhotoErrors((prev) => ({ ...prev, [itemId]: message }));
            return;
        }
        handleUpdateDetail(itemId, { photoFile: file, photoUrl: url, reasonPhotoId: undefined });
    };

    // Like the SFRA cartridge, reason photos are stored only for the SFCC returns handler, which attaches them to
    // the Zenkraft return sync. They are kept in SFCC as zenkraftReturnPhoto custom objects.
    const handleReasonsContinue = async () => {
        const pendingItems = usesZenkraftApi
            ? []
            : selectedItems.filter((item) => {
                  const detail = returnDetails[item.itemId ?? ''];
                  return detail?.photoFile && !detail.reasonPhotoId;
              });
        if (pendingItems.length === 0) {
            setActiveStep(3);
            return;
        }

        setIsUploadingPhotos(true);
        const errors: Record<string, string> = {};
        await Promise.all(
            pendingItems.map(async (item) => {
                const itemId = item.itemId ?? '';
                try {
                    const limits = returnConfig.reasonPhotoLimits;
                    const photo = await prepareReasonPhoto(
                        returnDetails[itemId].photoFile as File,
                        limits?.imageScale ?? undefined,
                        getReasonPhotoMaxBytes(limits)
                    );
                    if (!photo) {
                        errors[itemId] = limits?.sizeLimitWarningMsg || t('returns.photo.tooLarge');
                        return;
                    }
                    const res = await fetch('/resource/zenkraft-return-photo', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ orderId: order.orderNo, ...photo }),
                    });
                    const result = res.ok
                        ? ((await res.json()) as { success?: boolean; photoId?: string; msg?: unknown })
                        : null;
                    if (result?.success && result.photoId) {
                        handleUpdateDetail(itemId, { reasonPhotoId: result.photoId });
                    } else {
                        errors[itemId] = typeof result?.msg === 'string' && result.msg
                            ? result.msg
                            : t('returns.error.photoUpload');
                    }
                } catch {
                    errors[itemId] = t('returns.error.photoUpload');
                }
            })
        );
        setIsUploadingPhotos(false);
        setPhotoErrors(errors);
        if (Object.keys(errors).length === 0) {
            setActiveStep(3);
        }
    };

    const pageTitle = requiresApproval
        ? t('returns.title.requestReturn')
        : t('returns.title.createReturn');

    return (
        <div className="container mx-auto max-w-2xl px-4 py-8">
            <SeoMeta title={pageTitle} noIndex />

            <Link
                to="/account/orders"
                className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
            >
                <ChevronLeft className="h-3.5 w-3.5" aria-hidden />
                {t('returns.action.backToOrders')}
            </Link>

            <h1 className="mb-2 text-2xl font-semibold">{pageTitle}</h1>
            <p className="mb-8 text-sm text-muted-foreground">
                {t('returns.orderNumber')}:{' '}
                <span className="font-medium text-foreground">{order.orderNo}</span>
            </p>

            {missingData ? (
                <MissingDataForm
                    orderNo={order.orderNo ?? ''}
                    missingData={missingData}
                    onUpdated={setUpdatedMissingData}
                    t={t}
                />
            ) : (
                <>
                    <StepIndicator currentStep={isReturnComplete ? STEP_KEYS.length + 1 : activeStep} />

                    {activeStep === 1 && (
                        <Step1SelectItems
                            items={orderItems}
                            productsById={productsById}
                            selectedItemIds={selectedItemIds}
                            onToggleItem={handleToggleItem}
                            onNext={() => setActiveStep(2)}
                            currency={currency}
                            language={i18n.language}
                            t={t}
                        />
                    )}

                    {activeStep === 2 && (
                        <Step2SelectReasons
                            selectedItems={selectedItems}
                            productsById={productsById}
                            returnDetails={returnDetails}
                            photoErrors={photoErrors}
                            isUploadingPhotos={isUploadingPhotos}
                            onUpdateDetail={handleUpdateDetail}
                            onPhotoChange={(itemId, file, url) => void handlePhotoChange(itemId, file, url)}
                            onBack={() => setActiveStep(1)}
                            onNext={() => void handleReasonsContinue()}
                            t={t}
                        />
                    )}

                    {activeStep === 3 && (
                        <Step3GetLabel
                            order={order}
                            selectedItems={selectedItems}
                            productsById={productsById}
                            returnDetails={returnDetails}
                            requiresApproval={requiresApproval}
                            usesZenkraftApi={usesZenkraftApi}
                            onBack={() => setActiveStep(2)}
                            onReturnCreated={() => {
                                setIsReturnComplete(true);
                                void revalidator.revalidate();
                            }}
                            t={t}
                        />
                    )}
                </>
            )}

            {returnCases.length > 0 && (
                <section className="mt-10 space-y-4" aria-labelledby="zenkraft-return-history-title">
                    <h2 id="zenkraft-return-history-title" className="text-lg font-semibold">
                        {t('returns.history.title')}
                    </h2>
                    <ZenkraftReturnCaseList returnCases={returnCases} />
                </section>
            )}
        </div>
    );
}
