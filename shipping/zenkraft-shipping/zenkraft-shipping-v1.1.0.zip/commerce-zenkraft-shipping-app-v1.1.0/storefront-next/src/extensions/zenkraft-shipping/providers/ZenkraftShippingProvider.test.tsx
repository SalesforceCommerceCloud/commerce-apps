import { beforeEach, describe, expect, test, vi } from 'vitest';
import { act, renderHook } from '@testing-library/react';
import { useBasket, useBasketSnapshot } from '@/providers/basket';
import type { ShopperBasketsV2 } from '@/scapi';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';
import { ZenkraftShippingProvider, useZenkraftShipping } from './ZenkraftShippingProvider';

vi.mock('@/providers/basket', () => ({
    useBasket: vi.fn(),
    useBasketSnapshot: vi.fn(),
}));

/** Mocks the full basket with one shipment, with or without a stored collection point and shipping method. */
function mockBasketShipment(storedPoint: string | null, shippingMethodId?: string) {
    vi.mocked(useBasket).mockReturnValue({
        basketId: 'basket-1',
        shipments: [
            {
                shipmentId: 'me',
                c_zenkraftDropOffData: storedPoint,
                ...(shippingMethodId ? { shippingMethod: { id: shippingMethodId } } : {}),
            } as ShopperBasketsV2.schemas['Shipment'],
        ],
    });
}

const LOCATION: ZenkraftDropoffLocation = { location_code: 'A1', display_name: 'Corner Shop' };
const OTHER_LOCATION: ZenkraftDropoffLocation = { location_code: 'B2' };

function mockBasketId(basketId: string | undefined) {
    vi.mocked(useBasketSnapshot).mockReturnValue(
        basketId ? { basketId, totalItemCount: 1, uniqueProductCount: 1, lastModified: '' } : null
    );
}

function renderProvider() {
    return renderHook(() => useZenkraftShipping(), { wrapper: ZenkraftShippingProvider });
}

describe('ZenkraftShippingProvider', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        mockBasketId('basket-1');
        vi.mocked(useBasket).mockReturnValue(undefined);
    });

    test('drops the selection when the basket loses the stored collection point (order not placed)', () => {
        mockBasketShipment('{"location_code":"A1"}');
        const { result, rerender } = renderProvider();
        act(() => result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION));

        mockBasketShipment(null);
        rerender();

        expect(result.current.selectedLocations).toEqual({});
    });

    test('keeps a fresh selection while the basket has no stored collection point yet', () => {
        mockBasketShipment(null);
        const { result, rerender } = renderProvider();
        act(() => result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION));

        rerender();
        mockBasketShipment('{"location_code":"A1"}');
        rerender();

        expect(result.current.getSelectedLocation('me', 'zk-dropoff')).toEqual(LOCATION);
    });

    test('shows the collection point the basket already has (e.g. after a page reload) under its method', () => {
        mockBasketShipment(JSON.stringify(LOCATION), 'zk-dropoff');
        const { result } = renderProvider();

        expect(result.current.getSelectedLocation('me', 'zk-dropoff')).toEqual(LOCATION);
        expect(result.current.getSelectedLocation('me', 'standard')).toBeUndefined();
    });

    test('keeps a point picked on the page over the one stored on the basket', () => {
        mockBasketShipment(null);
        const { result, rerender } = renderProvider();
        act(() => result.current.setSelectedLocation('me', 'zk-dropoff-2', OTHER_LOCATION));

        mockBasketShipment(JSON.stringify(LOCATION), 'zk-dropoff');
        rerender();

        expect(result.current.selectedLocations).toEqual({
            me: { methodId: 'zk-dropoff-2', location: OTHER_LOCATION },
        });
    });

    test('ignores a stored collection point it cannot read', () => {
        mockBasketShipment('{not json', 'zk-dropoff');
        const { result, rerender } = renderProvider();

        mockBasketShipment('{"display_name":"No code"}', 'zk-dropoff');
        rerender();

        expect(result.current.selectedLocations).toEqual({});
    });

    test('keeps the selected location for the shipment and method it was picked for', () => {
        const { result } = renderProvider();

        act(() => result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION));

        expect(result.current.getSelectedLocation('me', 'zk-dropoff')).toEqual(LOCATION);
        expect(result.current.getSelectedLocation('me', 'zk-dropoff-2')).toBeUndefined();
        expect(result.current.getSelectedLocation('shipment-2', 'zk-dropoff')).toBeUndefined();
    });

    test('replaces the location picked for another method on the same shipment', () => {
        const { result } = renderProvider();
        act(() => result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION));

        act(() => result.current.setSelectedLocation('me', 'zk-dropoff-2', OTHER_LOCATION));

        expect(result.current.selectedLocations).toEqual({
            me: { methodId: 'zk-dropoff-2', location: OTHER_LOCATION },
        });
    });

    test('keeps a separate location for each shipment, even when they use the same method', () => {
        const { result } = renderProvider();

        act(() => {
            result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION);
            result.current.setSelectedLocation('shipment-2', 'zk-dropoff', OTHER_LOCATION);
        });

        expect(result.current.getSelectedLocation('me', 'zk-dropoff')).toEqual(LOCATION);
        expect(result.current.getSelectedLocation('shipment-2', 'zk-dropoff')).toEqual(OTHER_LOCATION);
    });

    test('clearLocation empties only that shipment', () => {
        const { result } = renderProvider();
        act(() => {
            result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION);
            result.current.setSelectedLocation('shipment-2', 'zk-dropoff', OTHER_LOCATION);
        });

        act(() => result.current.clearLocation('me'));

        expect(result.current.selectedLocations).toEqual({
            'shipment-2': { methodId: 'zk-dropoff', location: OTHER_LOCATION },
        });
    });

    test('drops selections from a previous basket once the basket changes', () => {
        const { result, rerender } = renderProvider();
        act(() => result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION));

        mockBasketId('basket-2');
        rerender();

        expect(result.current.selectedLocations).toEqual({});
    });

    test('does not carry previous-basket selections into a new selection', () => {
        const { result, rerender } = renderProvider();
        act(() => result.current.setSelectedLocation('me', 'zk-dropoff', LOCATION));

        mockBasketId('basket-2');
        rerender();
        act(() => result.current.setSelectedLocation('shipment-2', 'zk-dropoff-2', OTHER_LOCATION));

        expect(result.current.selectedLocations).toEqual({
            'shipment-2': { methodId: 'zk-dropoff-2', location: OTHER_LOCATION },
        });
    });

    test('opens the dialog for a shipment and method, and closes it', () => {
        const { result } = renderProvider();

        act(() => result.current.openDialog('shipment-2', 'zk-dropoff'));
        expect(result.current.dialog).toEqual({ shipmentId: 'shipment-2', methodId: 'zk-dropoff' });

        act(() => result.current.closeDialog());
        expect(result.current.dialog).toBeNull();
    });
});
