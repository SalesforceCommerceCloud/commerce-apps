/** A return reason photo ready for the uploadReasonImage endpoint. */
export type ReasonPhotoUpload = {
    /** The name of the file the shopper picked; the endpoint checks its format against the allowed ones */
    fileName: string;
    /** Base64 JPEG data, without the data URL prefix */
    data: string;
};

/**
 * The most the endpoint can store: a photo is kept as base64 in one custom object text attribute, which holds
 * 200,000 characters (about 146 KB). A little below that, so a photo never ends up right at the limit.
 */
export const REASON_PHOTO_MAX_BYTES = 140 * 1024;

/** The reason photo limits the `returns` custom API sends (zenkraftReturnReasonPhoto* preferences). */
export type ReasonPhotoLimits = {
    /** Maximum file size in KB */
    sizeLimit?: number | null;
    /** Maximum width/height in pixels the photo is shrunk to before upload */
    imageScale?: number | null;
    acceptableFileFormats?: string[] | null;
    sizeLimitWarningMsg?: string;
    acceptableFileFormatsWarningMsg?: string;
};

// What the uploadReasonImage endpoint accepts when zenkraftReturnReasonPhotoFormats is empty
const DEFAULT_REASON_PHOTO_FORMATS = ['jpg', 'jpeg', 'png'];

/**
 * Whether the uploadReasonImage endpoint accepts the photo's file type, which it reads from the file name extension.
 */
export function isReasonPhotoFormatAllowed(fileName: string, limits: ReasonPhotoLimits | undefined): boolean {
    const extension = fileName.includes('.') ? (fileName.split('.').pop() ?? '').toLowerCase() : '';
    if (!/^[a-z0-9]+$/.test(extension)) return false;
    const formats = limits?.acceptableFileFormats;
    const configured = Array.isArray(formats) ? formats.map((format) => String(format).toLowerCase()) : [];
    return (configured.length ? configured : DEFAULT_REASON_PHOTO_FORMATS).includes(extension);
}

/** The largest photo in bytes the endpoint accepts: the configured size limit, capped at what it can store. */
export function getReasonPhotoMaxBytes(limits: ReasonPhotoLimits | undefined): number {
    const sizeLimit = limits?.sizeLimit;
    return sizeLimit && sizeLimit > 0 ? Math.min(sizeLimit * 1024, REASON_PHOTO_MAX_BYTES) : REASON_PHOTO_MAX_BYTES;
}

/** Size in bytes of base64 data, counted the way the uploadReasonImage endpoint counts it. */
export function base64ByteLength(data: string): number {
    const padding = data.endsWith('==') ? 2 : data.endsWith('=') ? 1 : 0;
    return (data.length * 3) / 4 - padding;
}

/** The parts of a zenkraftReturnReasonsConfig reason that decide whether a photo is needed. */
type PhotoReason = {
    photoRequired?: boolean;
    values?: Array<{ id: string; photoRequired?: boolean }>;
};

/**
 * Whether the shopper must add a photo for the reason and sub-reason they selected. The
 * zenkraftReturnReasonsConfig preference sets `photoRequired` on sub-reasons, which is where
 * the SFRA cartridge reads it; a flag on the reason itself counts for all of its sub-reasons.
 */
export function isReasonPhotoRequired(reason: PhotoReason | undefined, subReasonId: string | undefined): boolean {
    if (!reason) return false;
    if (reason.photoRequired) return true;
    return Boolean(subReasonId && reason.values?.find((sr) => sr.id === subReasonId)?.photoRequired);
}

function readAsDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(reader.error ?? new Error('Could not read photo'));
        reader.readAsDataURL(file);
    });
}

function loadImage(src: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('Could not load photo'));
        image.src = src;
    });
}

// JPEG qualities tried at each size, then the photo is made smaller until it fits
const JPEG_QUALITIES = [0.85, 0.75, 0.65, 0.55];
const SHRINK_STEP = 0.75;
const MIN_LONGER_SIDE = 320;
// Enough to go from a 6000 px photo down to MIN_LONGER_SIDE
const MAX_SHRINK_ATTEMPTS = 12;

/**
 * Turns a photo into a JPEG of at most `maxBytes`, ready for upload. Its longer side is first shrunk to `maxDimension`
 * pixels (the zenkraftReturnReasonPhotoImageScale preference), like the SFRA cartridge does; if it is still too large,
 * lower JPEG qualities and then smaller sizes are tried. The photo is always redrawn, which also drops its metadata
 * (such as GPS location). Browser only.
 * @returns The photo, or null if even the smallest version is over `maxBytes`
 */
export async function prepareReasonPhoto(
    file: File,
    maxDimension: number | undefined,
    maxBytes: number
): Promise<ReasonPhotoUpload | null> {
    const image = await loadImage(await readAsDataUrl(file));
    const longerSide = Math.max(image.width, image.height);
    let scale = maxDimension && maxDimension > 0 && longerSide > maxDimension ? maxDimension / longerSide : 1;

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Could not process photo');

    for (let attempt = 0; attempt < MAX_SHRINK_ATTEMPTS; attempt++) {
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        // JPEG has no transparency, so transparent parts of a PNG become white instead of black
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);

        for (const quality of JPEG_QUALITIES) {
            const dataUrl = canvas.toDataURL('image/jpeg', quality);
            const data = dataUrl.slice(dataUrl.indexOf(',') + 1);
            if (base64ByteLength(data) <= maxBytes) {
                return { fileName: file.name, data };
            }
        }

        if (longerSide * scale * SHRINK_STEP < MIN_LONGER_SIDE) break;
        scale *= SHRINK_STEP;
    }
    return null;
}
