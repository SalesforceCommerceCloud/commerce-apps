import { describe, expect, test, vi, beforeEach } from 'vitest';
import { render } from '@testing-library/react';
import ZenkraftShipmentTrackBar from './index';

const mockLoad = vi.fn();
let mockFetcherState: {
    state: 'idle' | 'loading' | 'submitting';
    data: { trackingData?: { status?: string; tracking_stage?: string; error?: string } } | undefined;
} = { state: 'idle', data: undefined };

vi.mock('react-router', () => ({
    useFetcher: () => ({ ...mockFetcherState, load: mockLoad }),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (k: string) => k }),
}));

vi.mock('@/extensions/zenkraft-shipping/components/zenkraft-track-bar', () => ({
    default: () => <div data-testid="zenkraft-track-bar" />,
}));

describe('ZenkraftShipmentTrackBar', () => {
    beforeEach(() => {
        mockLoad.mockClear();
        mockFetcherState = { state: 'idle', data: undefined };
    });

    test('renders nothing when no data yet', () => {
        const { container } = render(
            <ZenkraftShipmentTrackBar trackingNumber="1Z999AA10123456784" carrier="ups" orderNo="00000101" />
        );
        expect(container.firstChild).toBeNull();
    });

    test('renders skeleton while loading', () => {
        mockFetcherState = { state: 'loading', data: undefined };
        const { container } = render(
            <ZenkraftShipmentTrackBar trackingNumber="1Z999AA10123456784" carrier="ups" orderNo="00000101" />
        );
        expect(container.querySelector('[aria-hidden]')).toBeTruthy();
    });

    test('renders track bar when tracking data is available', () => {
        mockFetcherState = {
            state: 'idle',
            data: { trackingData: { status: 'IN_TRANSIT', tracking_stage: 'IN_TRANSIT' } },
        };
        const { getByTestId } = render(
            <ZenkraftShipmentTrackBar trackingNumber="1Z999AA10123456784" carrier="ups" orderNo="00000101" />
        );
        expect(getByTestId('zenkraft-track-bar')).toBeTruthy();
    });

    test('renders nothing when tracking data has an error', () => {
        mockFetcherState = {
            state: 'idle',
            data: { trackingData: { error: 'Tracking not found' } },
        };
        const { container } = render(
            <ZenkraftShipmentTrackBar trackingNumber="UNKNOWN" carrier="ups" orderNo="00000101" />
        );
        expect(container.firstChild).toBeNull();
    });

    test('renders nothing when trackingData is absent', () => {
        mockFetcherState = { state: 'idle', data: {} };
        const { container } = render(
            <ZenkraftShipmentTrackBar trackingNumber="123" carrier="fedex" orderNo="00000102" />
        );
        expect(container.firstChild).toBeNull();
    });

    test('calls fetcher.load with correct resource route params on mount', () => {
        render(
            <ZenkraftShipmentTrackBar trackingNumber="TRACK123" carrier="fedex" orderNo="ORDER99" />
        );
        expect(mockLoad).toHaveBeenCalledWith(
            '/resource/zenkraft-tracking-data?c_trackingNumber=TRACK123&c_carrier=fedex&c_order=ORDER99&c_orderDetailsPage=true'
        );
    });
});
