/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */


/**
 * ZenkraftOrderTracking — registered at sfcc.myAccount.orderDetails.tracking.
 *
 * Renders a "Track Shipment" button (linking to the Zenkraft tracking page) and
 * a ZenkraftShipmentTrackBar for each shipment with a `c_zenkraftCarrier` custom
 * attribute and a tracking number. Renders nothing for orders with no Zenkraft
 * shipments.
 *
 * Zenkraft orders always have OOTB tracking entries so the `hasTracking` gate in
 * the parent is satisfied and this UITarget always mounts. Order data is already
 * resolved by the time OrderDetails renders (it mounts inside an <Await>), so
 * the `use()` call returns synchronously.
 */

import { use, Suspense, useEffect } from 'react';
import { useFetcher, useRouteLoaderData } from 'react-router';
import { useTranslation } from 'react-i18next';
import type { ShopperOrders } from '@/scapi';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from '@/components/link';
import { routes } from '@/route-paths';
import ZenkraftShipmentTrackBar from '@/extensions/zenkraft-shipping/components/zenkraft-shipment-track-bar';

type Shipment = NonNullable<ShopperOrders.schemas['Order']['shipments']>[number] & {
    c_zenkraftCarrier?: string;
};

type OrderDetailsLoaderData = {
    order: ShopperOrders.schemas['Order'];
};

type RouteLoaderData = {
    orderData: Promise<OrderDetailsLoaderData>;
};

type TrackingSettingsResponse = {
    enableZenkraftTrackingOnOrderDetailsPage: boolean;
};

function ZenkraftOrderTrackingInner() {
    const { t } = useTranslation('extZenkraftShipping');
    const settingsFetcher = useFetcher<TrackingSettingsResponse>();
    const loaderData = useRouteLoaderData<RouteLoaderData>('routes/_app.account.orders.$orderNo');
    const { order } = use(loaderData!.orderData);
    const shipments = (order.shipments ?? []) as Shipment[];
    const orderNo = order.orderNo ?? '';

    useEffect(() => {
        settingsFetcher.load('/resource/zenkraft-tracking-settings');
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const zenkraftShipments = shipments
        .map((s, i) => ({ shipment: s, shipmentNumber: i + 1 }))
        .filter(({ shipment: s }) => s.c_zenkraftCarrier && s.trackingNumber);

    if (zenkraftShipments.length === 0) return null;

    if (!settingsFetcher.data) return null;

    if (!settingsFetcher.data.enableZenkraftTrackingOnOrderDetailsPage) return null;

    return (
        <>
            <Card className="rounded-none min-h-[4rem] p-0 bg-card" data-card="zenkraft-track-shipment">
                <CardContent className="p-3 space-y-3">
                    <Button
                        variant="outline"
                        size="sm"
                        asChild
                        data-slot="order-actions-track"
                        data-testid="order-actions-track"
                        className="w-full sm:w-auto">
                        <Link to={`${routes.zenkraftTracking}?orderNo=${orderNo}`}>
                            {t('orderDetails.trackShipmentButton')}
                        </Link>
                    </Button>
                    {zenkraftShipments.map(({ shipment, shipmentNumber }) => (
                        <ZenkraftShipmentTrackBar
                            key={shipment.shipmentId}
                            trackingNumber={shipment.trackingNumber!}
                            carrier={shipment.c_zenkraftCarrier!}
                            orderNo={orderNo}
                            shipmentNumber={shipmentNumber}
                        />
                    ))}
                </CardContent>
            </Card>
        </>
    );
}

export default function ZenkraftOrderTracking() {
    return (
        <Suspense fallback={null}>
            <ZenkraftOrderTrackingInner />
        </Suspense>
    );
}
