/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */


/**
 * ZenkraftReturnButton — registered at sfcc.myAccount.orderDetails.returns.
 *
 * Replaces the default ReturnItemsAction with a button linking to the Zenkraft
 * return wizard. The default children (ReturnItemsAction) are passed in by the
 * UITarget transform but intentionally not rendered.
 *
 * Order data is already resolved by the time OrderDetails renders (it mounts
 * inside an <Await>), so the use() call returns synchronously.
 */

import { use, Suspense } from 'react';
import type { ReactNode } from 'react';
import { useRouteLoaderData } from 'react-router';
import { useTranslation } from 'react-i18next';
import type { ShopperOrders } from '@/scapi';
import { Button } from '@/components/ui/button';
import { Link } from '@/components/link';
import { routes } from '@/route-paths';

type OrderDetailsLoaderData = {
    order: ShopperOrders.schemas['Order'];
};

type RouteLoaderData = {
    orderData: Promise<OrderDetailsLoaderData>;
};

function ZenkraftReturnButtonInner() {
    const { t } = useTranslation('extZenkraftShipping');
    const loaderData = useRouteLoaderData<RouteLoaderData>('routes/_app.account.orders.$orderNo');
    const { order } = use(loaderData!.orderData);
    const orderNo = order.orderNo ?? '';

    if (order.shippingStatus !== 'shipped') {
        return null;
    }

    return (
        <Button
            variant="default"
            size="sm"
            asChild
            data-slot="order-actions-return"
            data-testid="order-actions-return"
            className="w-full sm:w-auto">
            <Link to={`${routes.zenkraftCreateReturn}?orderNo=${orderNo}`}>
                {t('orderDetails.returnButton')}
            </Link>
        </Button>
    );
}

// children is the default ReturnItemsAction injected by the UITarget transform — not rendered
export default function ZenkraftReturnButton({ children: _children }: { children?: ReactNode }) {
    return (
        <Suspense fallback={null}>
            <ZenkraftReturnButtonInner />
        </Suspense>
    );
}
