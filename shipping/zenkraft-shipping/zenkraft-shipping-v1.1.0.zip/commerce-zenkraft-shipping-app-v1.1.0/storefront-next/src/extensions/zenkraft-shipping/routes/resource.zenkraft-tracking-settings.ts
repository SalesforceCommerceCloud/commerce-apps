/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — checks whether the enableZenkraftTrackingOnOrderDetailsPage
 * site preference is enabled, without requiring a tracking number.
 *
 * Calls the getZenkraftTracking SCAPI endpoint with c_orderDetailsPage=true
 * and no tracking params. The backend answers from the site preferences, without
 * a tracking lookup. Tracking is shown only when it answers true: the tracking page
 * being off ({ redirect: true }) or an error response hides it.
 *
 * GET /resource/zenkraft-tracking-settings
 *
 * Returns: { enableZenkraftTrackingOnOrderDetailsPage: boolean }
 */

import type { LoaderFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';

const ZENKRAFT_TRACK_API = 'zenkraft-track';
const ZENKRAFT_TRACK_VERSION = 'v1';

export async function loader({ context }: LoaderFunctionArgs) {
    const logger = getLogger(context);

    try {
        const { accessToken } = getAuth(context);
        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const params = new URLSearchParams({ siteId, c_orderDetailsPage: 'true' });
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_TRACK_API}/${ZENKRAFT_TRACK_VERSION}/organizations/${organizationId}/getZenkraftTracking?${params}`;

        const response = await fetch(apiUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json',
            },
        });

        const data = await response.json();
        const enabled = response.ok && data.enableZenkraftTrackingOnOrderDetailsPage === true;

        return Response.json({ enableZenkraftTrackingOnOrderDetailsPage: enabled });
    } catch (error) {
        logger.error('[zenkraft-shipping] tracking settings resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ enableZenkraftTrackingOnOrderDetailsPage: false });
    }
}
