import { beforeEach, describe, expect, test, vi } from 'vitest';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { createRoutesStub, type ActionFunctionArgs } from 'react-router';
import { resourceRoutes } from '@/route-paths';
import { mockAltSiteObject } from '@/test-utils/config';
import { AllProvidersWrapper } from '@/test-utils/context-provider';
import { CHECKOUT_STEPS } from '@/components/checkout/utils/checkout-context-types';
import type { ShopperBasketsV2 } from '@/scapi';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';
import { ZenkraftShippingProvider } from '@/extensions/zenkraft-shipping/providers/ZenkraftShippingProvider';
import ZenkraftMultiShipmentOptions from './ZenkraftMultiShipmentOptions';

vi.mock('@/providers/basket', () => ({
    useBasket: vi.fn(() => ({ basketId: 'basket-1' })),
    useBasketSnapshot: vi.fn(() => ({ basketId: 'basket-1', totalItemCount: 2, uniqueProductCount: 2, lastModified: '' })),
}));
vi.mock('@/hooks/checkout/use-customer-profile', () => ({
    useCustomerProfile: vi.fn(() => null),
}));
// Where checkout is (step / step being edited); each test sets it.
const checkout = vi.hoisted(() => ({ step: 3, editingStep: null as number | null }));
vi.mock('@/hooks/use-checkout', async () => {
    const { CHECKOUT_STEPS: STEPS } = await import('@/components/checkout/utils/checkout-context-types');
    return { useCheckoutContext: () => ({ ...checkout, STEPS }) };
});
vi.mock('@salesforce/storefront-next-runtime/site-context', async (importOriginal) => {
    const actual = await importOriginal<object>();
    return {
        ...actual,
        useSite: vi.fn(() => ({
            site: { id: mockAltSiteObject.id, defaultLocale: mockAltSiteObject.defaultLocale },
            language: mockAltSiteObject.defaultLocale,
            currency: mockAltSiteObject.defaultCurrency,
        })),
    };
});
// Stand-in for the map/list dialog: reports which shipment it searches for and picks a location on click.
vi.mock('@/extensions/zenkraft-shipping/components/dropoff-dialog', () => ({
    default: ({
        shipmentId,
        shippingMethodId,
        onSelect,
    }: {
        shipmentId?: string;
        shippingMethodId: string;
        onSelect: (location: ZenkraftDropoffLocation) => void;
    }) => (
        <div role="dialog" aria-label="Collection Points">
            <span>{`searching ${shippingMethodId} for ${shipmentId}`}</span>
            <button
                type="button"
                onClick={() => onSelect({ location_code: `LOC-${shipmentId}`, display_name: `Kiosk ${shipmentId}` })}>
                pick location
            </button>
        </div>
    ),
}));

/** Placeholder for the multiship ShippingMultiOptions element — only its props are read. */
function MultiOptionsElement(_props: Record<string, unknown>) {
    return null;
}

const SHIPMENTS: ShopperBasketsV2.schemas['Shipment'][] = [
    {
        shipmentId: 'me',
        shippingAddress: { firstName: 'Ann', lastName: 'Lee', address1: '1 Main St', city: 'Boston', countryCode: 'US' },
        shippingMethod: { id: 'standard', name: 'Standard', price: 5 },
    },
    {
        shipmentId: 'shipment-2',
        shippingAddress: { firstName: 'Bo', lastName: 'Kim', address1: '9 Elm St', city: 'Denver', countryCode: 'US' },
        shippingMethod: { id: 'standard', name: 'Standard', price: 5 },
    },
];

const METHODS: ShopperBasketsV2.schemas['ShippingMethodResult'] = {
    applicableShippingMethods: [
        { id: 'standard', name: 'Standard', price: 5 },
        { id: 'zk-dropoff', name: 'Pickup Point', price: 3, c_zenkraftDropOffMethod: true } as never,
    ],
    defaultShippingMethodId: 'standard',
};

function renderOptions(props: Record<string, unknown> = {}, setLocationResult: unknown = { success: true }) {
    const onSubmit = vi.fn();
    const onEdit = vi.fn();
    const requests: unknown[] = [];
    const setLocationAction = vi.fn(async ({ request }: ActionFunctionArgs) => {
        requests.push(await request.json());
        return setLocationResult;
    });

    const Stub = createRoutesStub([
        {
            path: '/checkout',
            Component: () => (
                <ZenkraftShippingProvider>
                    <ZenkraftMultiShipmentOptions>
                        <MultiOptionsElement
                            onSubmit={onSubmit}
                            isLoading={false}
                            isEditing
                            isCompleted={false}
                            onEdit={onEdit}
                            shipments={SHIPMENTS}
                            shippingMethodsMap={{ me: METHODS, 'shipment-2': METHODS }}
                            {...props}
                        />
                    </ZenkraftMultiShipmentOptions>
                </ZenkraftShippingProvider>
            ),
        },
        { path: resourceRoutes.zenkraftSetDropoffLocation, action: setLocationAction },
    ]);
    render(<Stub initialEntries={['/checkout']} />, { wrapper: AllProvidersWrapper });

    return { onSubmit, onEdit, requests, setLocationAction };
}

function shipmentGroup(index: number) {
    return screen.getByRole('radiogroup', { name: new RegExp(`shipment ${index}`, 'i') });
}

// The test DOM has no scrollIntoView
const scrollIntoView = vi.fn();

describe('ZenkraftMultiShipmentOptions', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        checkout.step = CHECKOUT_STEPS.SHIPPING_OPTIONS;
        checkout.editingStep = null;
        HTMLElement.prototype.scrollIntoView = scrollIntoView;
    });

    test('summarises each shipment with the Zenkraft rate, not the Business Manager price on the basket method', async () => {
        // Basket shipments carry the method's Business Manager price (0 → "Free");
        // the applicable-methods result carries the Zenkraft rate.
        const ratedMethods = {
            ...METHODS,
            applicableShippingMethods: [{ id: 'standard', name: 'Standard', price: 12.5 }],
        };
        renderOptions({
            isEditing: false,
            isCompleted: true,
            shipments: SHIPMENTS.map((shipment) => ({
                ...shipment,
                shippingMethod: { id: 'standard', name: 'Standard', price: 0 },
            })),
            shippingMethodsMap: { me: ratedMethods, 'shipment-2': ratedMethods },
        });

        expect(await screen.findAllByText(/12\.50\s*\|\s*Standard/)).toHaveLength(2);
        expect(screen.queryByText(/Free\s*\|\s*Standard/i)).not.toBeInTheDocument();
    });

    test('offers a collection point choice under the drop-off method of every shipment', async () => {
        renderOptions();

        expect(await screen.findAllByRole('button', { name: 'Choose collection point' })).toHaveLength(2);
    });

    test('searches collection points around the shipment the dialog was opened for', async () => {
        const user = userEvent.setup();
        renderOptions();

        await user.click(within(shipmentGroup(2)).getByRole('button', { name: 'Choose collection point' }));

        expect(await screen.findByText('searching zk-dropoff for shipment-2')).toBeInTheDocument();
    });

    test('blocks Continue for a shipment on a drop-off method without a collection point', async () => {
        const user = userEvent.setup();
        const { onSubmit, setLocationAction } = renderOptions();

        await user.click(within(shipmentGroup(2)).getByRole('radio', { name: /Pickup Point/ }));
        await user.click(screen.getByRole('button', { name: 'Continue to Payment' }));

        expect(await screen.findByRole('alert')).toHaveTextContent('Please choose a collection point before continuing.');
        expect(onSubmit).not.toHaveBeenCalled();
        expect(setLocationAction).not.toHaveBeenCalled();
    });

    test('brings the first shipment missing a collection point into view and focuses its message', async () => {
        const user = userEvent.setup();
        renderOptions();

        await user.click(within(shipmentGroup(1)).getByRole('radio', { name: /Pickup Point/ }));
        await user.click(within(shipmentGroup(2)).getByRole('radio', { name: /Pickup Point/ }));
        await user.click(screen.getByRole('button', { name: 'Continue to Payment' }));

        const firstMessage = await within(shipmentGroup(1).parentElement as HTMLElement).findByRole('alert');
        await waitFor(() => expect(firstMessage).toHaveFocus());
        expect(scrollIntoView).toHaveBeenCalledOnce();
        expect(scrollIntoView).toHaveBeenCalledWith({ behavior: 'smooth', block: 'center' });
        expect(scrollIntoView.mock.contexts[0]).toBe(firstMessage);
    });

    test('stores the chosen collection point on its shipment, then submits every shipment method', async () => {
        const user = userEvent.setup();
        const { onSubmit, requests } = renderOptions();

        await user.click(within(shipmentGroup(2)).getByRole('button', { name: 'Choose collection point' }));
        await user.click(await screen.findByRole('button', { name: 'pick location' }));

        // Picking a location selects its drop-off method and shows the location under it.
        expect(within(shipmentGroup(2)).getByRole('radio', { name: /Pickup Point/ })).toBeChecked();
        expect(within(shipmentGroup(2)).getByText('Kiosk shipment-2')).toBeInTheDocument();

        await user.click(screen.getByRole('button', { name: 'Continue to Payment' }));

        await waitFor(() => expect(onSubmit).toHaveBeenCalledOnce());
        expect(requests).toEqual([
            {
                basketId: 'basket-1',
                shipments: [
                    {
                        shipmentId: 'shipment-2',
                        shippingMethodId: 'zk-dropoff',
                        location: { location_code: 'LOC-shipment-2', display_name: 'Kiosk shipment-2' },
                    },
                ],
            },
        ]);
        const formData = onSubmit.mock.calls[0][0] as FormData;
        expect(formData.get('shippingMethod_me')).toBe('standard');
        expect(formData.get('shippingMethod_shipment-2')).toBe('zk-dropoff');
    });

    test('shows the error on the shipment the server could not save, until the shopper changes it', async () => {
        const user = userEvent.setup();
        const { onSubmit } = renderOptions({}, { success: false, failedShipmentId: 'shipment-2' });

        for (const index of [1, 2]) {
            await user.click(within(shipmentGroup(index)).getByRole('button', { name: 'Choose collection point' }));
            await user.click(await screen.findByRole('button', { name: 'pick location' }));
        }
        await user.click(screen.getByRole('button', { name: 'Continue to Payment' }));

        const shipment2 = shipmentGroup(2).parentElement as HTMLElement;
        const message = await within(shipment2).findByRole('alert');
        expect(message).toHaveTextContent(
            "We couldn't save this shipping choice. Please try again or choose another shipping method."
        );
        // Shipment 2 can be below the fold
        await waitFor(() => expect(message).toHaveFocus());
        expect(scrollIntoView.mock.contexts[0]).toBe(message);
        expect(within(shipmentGroup(1).parentElement as HTMLElement).queryByRole('alert')).not.toBeInTheDocument();
        expect(onSubmit).not.toHaveBeenCalled();

        await user.click(within(shipmentGroup(2)).getByRole('radio', { name: /Standard/ }));

        expect(within(shipment2).queryByRole('alert')).not.toBeInTheDocument();
    });

    test('submits directly when no shipment uses a drop-off method', async () => {
        const user = userEvent.setup();
        const { onSubmit, setLocationAction } = renderOptions();

        await user.click(await screen.findByRole('button', { name: 'Continue to Payment' }));

        expect(onSubmit).toHaveBeenCalledOnce();
        expect(setLocationAction).not.toHaveBeenCalled();
    });

    const DROPOFF_SHIPMENT_2 = { ...SHIPMENTS[1], shippingMethod: { id: 'zk-dropoff', name: 'Pickup Point', price: 3 } };

    test('brings checkout back to this step when a drop-off shipment has no saved collection point', async () => {
        checkout.step = CHECKOUT_STEPS.PAYMENT;
        const { onEdit } = renderOptions({ isEditing: false, isCompleted: true, shipments: [SHIPMENTS[0], DROPOFF_SHIPMENT_2] });

        await waitFor(() => expect(onEdit).toHaveBeenCalled());
    });

    test('leaves checkout where it is once every drop-off shipment has a saved collection point', async () => {
        checkout.step = CHECKOUT_STEPS.PAYMENT;
        const saved = {
            ...DROPOFF_SHIPMENT_2,
            c_zenkraftDropOffData: JSON.stringify({ location_code: 'LOC-shipment-2', display_name: 'Kiosk shipment-2' }),
        } as never;
        const { onEdit } = renderOptions({ isEditing: false, isCompleted: true, shipments: [SHIPMENTS[0], saved] });

        expect((await screen.findAllByText(/\|\s*Pickup Point/)).length).toBeGreaterThan(0);
        expect(onEdit).not.toHaveBeenCalled();
    });

    test('does not take over while the shopper edits the shipping address', async () => {
        checkout.step = CHECKOUT_STEPS.PAYMENT;
        checkout.editingStep = CHECKOUT_STEPS.SHIPPING_ADDRESS;
        const { onEdit } = renderOptions({ isEditing: false, isCompleted: true, shipments: [SHIPMENTS[0], DROPOFF_SHIPMENT_2] });

        expect(await screen.findByRole('button', { name: 'Continue to Payment' })).toBeInTheDocument();
        expect(onEdit).not.toHaveBeenCalled();
    });
});
