import { type ReactElement, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import { expect, screen, userEvent } from 'storybook/test';
import { action } from 'storybook/actions';
import { waitForStorybookReady } from '@storybook/test-utils';
import { Button } from '@/components/ui/button';
import { resourceRoutes } from '@/route-paths';
import { DROPOFF_LOCATIONS } from '@/extensions/zenkraft-shipping/components/dropoff-location-picker/stories/fixtures';
import ZenkraftDropoffDialog, { type ZenkraftDropoffDialogProps } from '../index';

function mockLocationsRoute(loader: () => unknown) {
    return { mockRoutes: [{ path: resourceRoutes.zenkraftDropoffLocations, loader }] };
}

/** Opens the dialog on mount and re-opens it from a button, like the checkout shipping step. */
function DialogHarness(props: Omit<ZenkraftDropoffDialogProps, 'open' | 'onOpenChange'>): ReactElement {
    const [open, setOpen] = useState(true);
    return (
        <>
            <Button onClick={() => setOpen(true)}>Choose collection point</Button>
            <ZenkraftDropoffDialog {...props} open={open} onOpenChange={setOpen} />
        </>
    );
}

const meta: Meta<typeof ZenkraftDropoffDialog> = {
    title: 'Extensions/Zenkraft Shipping/Drop-off Dialog',
    component: ZenkraftDropoffDialog,
    tags: ['autodocs', 'interaction'],
    render: (args) => <DialogHarness {...args} />,
    args: {
        shippingMethodId: 'zenkraft-ups-access-point',
        onSelect: action('onSelect'),
    },
    parameters: {
        layout: 'centered',
        ...mockLocationsRoute(() => ({
            success: true,
            shippingMethodId: 'zenkraft-ups-access-point',
            locations: DROPOFF_LOCATIONS,
        })),
        docs: {
            description: {
                component:
                    'Collection point dialog for Zenkraft drop-off shipping methods. Fetches the locations from ' +
                    '`/resource/zenkraft-dropoff-locations` when mounted; lazy-load it and mount it only while open.',
            },
        },
    },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    play: async ({ canvasElement, args }) => {
        await waitForStorybookReady(canvasElement);

        await userEvent.click(await screen.findByRole('radio', { name: /Market Square Post Office/ }));
        await userEvent.click(screen.getByRole('button', { name: 'Select Market Square Post Office' }));

        await expect(args.onSelect).toHaveBeenCalledWith(DROPOFF_LOCATIONS[1]);
    },
};

export const PreviouslySelected: Story = {
    args: { selectedLocationCode: 'UPS-AP-1002' },
};

export const LoadError: Story = {
    parameters: mockLocationsRoute(() => ({ success: false, shippingMethodId: 'zenkraft-ups-access-point' })),
};

export const NoLocations: Story = {
    parameters: mockLocationsRoute(() => ({
        success: true,
        shippingMethodId: 'zenkraft-ups-access-point',
        locations: [],
    })),
};
