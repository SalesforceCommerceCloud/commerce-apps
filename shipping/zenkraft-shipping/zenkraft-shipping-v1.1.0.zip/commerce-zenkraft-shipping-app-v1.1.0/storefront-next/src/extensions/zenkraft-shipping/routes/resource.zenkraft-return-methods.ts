/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — proxies POST requests to the Zenkraft getReturnMethods
 * custom SCAPI endpoint in int_zenkraft_sfnext.
 *
 * POST /resource/zenkraft-return-methods
 *   Body: { orderId, items, returnDetails }
 *
 * Used by the create-return page (/zenkraft-create-return) to fetch the available
 * return shipping methods for a set of items, with the Zenkraft API returns handler
 * when returns don't require approval. Return requests that need approval go
 * through /resource/zenkraft-return-label instead.
 */

import type { ActionFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';

const ZENKRAFT_RETURNS_API = 'zenkraft-returns';
const ZENKRAFT_RETURNS_VERSION = 'v1';

export function loader() {
    return Response.json(null, { status: 405 });
}

export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);

    try {
        const { accessToken, customerId } = getAuth(context);
        if (!customerId) {
            return Response.json({ error: 'Authentication required' }, { status: 401 });
        }
        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const body = await request.json();
        if (!body || typeof body.orderId !== 'string' || !body.orderId.trim() ||
            !Array.isArray(body.items) || body.items.length === 0) {
            return Response.json({ error: 'Invalid return request' }, { status: 400 });
        }

        try {
            await createApiClients(context).shopperOrders.getOrder({
                params: { path: { orderNo: body.orderId } },
            });
        } catch (error) {
            const status = (error as { status?: number }).status;
            if (status === 401) {
                return Response.json({ error: 'Authentication required' }, { status: 401 });
            }
            if (status === 403 || status === 404) {
                return Response.json({ error: 'Order not accessible' }, { status: 403 });
            }
            throw error;
        }

        const params = new URLSearchParams({ siteId });
        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_RETURNS_API}/${ZENKRAFT_RETURNS_VERSION}/organizations/${organizationId}/getReturnMethods?${params}`;

        const response = await fetch(apiUrl, {
            method: 'POST',
            cache: 'no-store',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            logger.error('[zenkraft-shipping] getReturnMethods call failed', {
                status: response.status,
            });
            return Response.json(
                { error: 'Failed to fetch return methods' },
                { status: response.status }
            );
        }

        const data = await response.json();
        return Response.json(data, { headers: { 'Cache-Control': 'no-store' } });
    } catch (error) {
        logger.error('[zenkraft-shipping] return methods resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
