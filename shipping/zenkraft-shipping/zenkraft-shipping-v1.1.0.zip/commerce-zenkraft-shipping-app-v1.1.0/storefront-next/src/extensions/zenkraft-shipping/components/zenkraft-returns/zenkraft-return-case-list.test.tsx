import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { ZenkraftReturnCaseList } from './zenkraft-return-case-list';
import type { ReturnCaseSummary } from '@/extensions/zenkraft-shipping/lib/return-cases';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({ t: (k: string) => k }),
}));

vi.mock('@/extensions/zenkraft-shipping/components/zenkraft-track-bar', () => ({
    default: () => <div data-testid="zenkraft-track-bar" />,
}));

const zkReturnCase: ReturnCaseSummary = {
    id: 'zk-1',
    createdAt: '2026-10-01T10:00:00.000Z',
    trackingStage: null,
    trackingStatus: 'returnApproved',
    label: null,
    zkReturnCase: true,
    qrCode: null,
    returnLineItems: [{ productId: 'SKU-1', productName: 'Linen Shirt', quantity: 1, creationDate: '2026-10-01' }],
};

const sfccReturnCase: ReturnCaseSummary = {
    id: 'sfcc-1',
    createdAt: '2026-10-01T10:00:00.000Z',
    trackingStage: 'IN_TRANSIT',
    trackingStatus: 'returnApproved',
    label: 'LABEL-BASE64',
    zkReturnCase: false,
    qrCode: { data: 'QR-BASE64', mimeType: 'image/png', extension: 'png' },
    returnLineItems: [
        { productId: 'SKU-1', productName: 'Linen Shirt', quantity: 1, trackingNumber: '1Z999', creationDate: '2026-10-01' },
    ],
};

const clickDownload = () => fireEvent.click(screen.getByRole('button', { name: 'returns.history.downloadLabel' }));

describe('ZenkraftReturnCaseList label download', () => {
    const fetchMock = vi.fn();
    const anchorClick = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {});

    beforeEach(() => {
        vi.stubGlobal('fetch', fetchMock);
        fetchMock.mockReset();
        anchorClick.mockClear();
    });

    afterEach(() => {
        vi.unstubAllGlobals();
    });

    test('downloads the label of a Zenkraft API return', async () => {
        fetchMock.mockResolvedValue({ ok: true, json: () => Promise.resolve({ label: 'BASE64' }) });
        render(<ZenkraftReturnCaseList returnCases={[zkReturnCase]} />);
        clickDownload();

        await waitFor(() => expect(anchorClick).toHaveBeenCalledTimes(1));
        expect(fetchMock).toHaveBeenCalledWith('/resource/zenkraft-return-combined-label?returnId=zk-1');
        expect(screen.queryByRole('alert')).toBeNull();
    });

    test('says the label could not be loaded when the request fails', async () => {
        fetchMock.mockResolvedValue({ ok: false, status: 404, json: () => Promise.resolve({ error: 'Label not available' }) });
        render(<ZenkraftReturnCaseList returnCases={[zkReturnCase]} />);
        clickDownload();

        expect(await screen.findByRole('alert')).toHaveTextContent('returns.history.downloadError');
        expect(anchorClick).not.toHaveBeenCalled();
    });

    test('says the label could not be loaded when the network call throws, and clears it on a retry that works', async () => {
        fetchMock.mockRejectedValueOnce(new Error('offline'));
        render(<ZenkraftReturnCaseList returnCases={[zkReturnCase]} />);
        clickDownload();
        expect(await screen.findByRole('alert')).toHaveTextContent('returns.history.downloadError');

        fetchMock.mockResolvedValueOnce({ ok: true, json: () => Promise.resolve({ label: 'BASE64' }) });
        clickDownload();
        await waitFor(() => expect(anchorClick).toHaveBeenCalledTimes(1));
        expect(screen.queryByRole('alert')).toBeNull();
    });

    test('says the label could not be loaded when the response has no label', async () => {
        fetchMock.mockResolvedValue({ ok: true, json: () => Promise.resolve({}) });
        render(<ZenkraftReturnCaseList returnCases={[zkReturnCase]} />);
        clickDownload();

        expect(await screen.findByRole('alert')).toHaveTextContent('returns.history.downloadError');
    });
});

describe('ZenkraftReturnCaseList QR code and tracking number', () => {
    const anchorClick = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => {});

    beforeEach(() => {
        anchorClick.mockClear();
    });

    test('downloads the QR code of a return case that has one', () => {
        render(<ZenkraftReturnCaseList returnCases={[sfccReturnCase]} />);
        fireEvent.click(screen.getByRole('button', { name: 'returns.history.downloadQrCode' }));

        expect(anchorClick).toHaveBeenCalledTimes(1);
        const link = anchorClick.mock.contexts[0] as HTMLAnchorElement;
        expect(link.href).toBe('data:image/png;base64,QR-BASE64');
        expect(link.download).toBe('return-qr-code-sfcc-1.png');
    });

    test('shows no QR code button for a return case without one', () => {
        render(<ZenkraftReturnCaseList returnCases={[zkReturnCase]} />);

        expect(screen.queryByRole('button', { name: 'returns.history.downloadQrCode' })).toBeNull();
        expect(screen.getByRole('button', { name: 'returns.history.downloadLabel' })).toBeInTheDocument();
    });

    test('shows the tracking number of a line that has one', () => {
        render(<ZenkraftReturnCaseList returnCases={[sfccReturnCase, zkReturnCase]} />);

        expect(screen.getAllByText(/returns\.history\.trackingNumber/)).toHaveLength(1);
        expect(screen.getByText('returns.history.trackingNumber: 1Z999')).toBeInTheDocument();
    });
});
