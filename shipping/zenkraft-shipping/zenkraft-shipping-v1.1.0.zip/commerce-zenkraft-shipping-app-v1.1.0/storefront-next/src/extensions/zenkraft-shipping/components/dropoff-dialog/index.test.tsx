import { beforeEach, describe, expect, test, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ConfigWrapper } from '@/test-utils/config';
import { useZenkraftDropoffLocations } from '@/extensions/zenkraft-shipping/hooks/use-zenkraft-dropoff-locations';
import type { ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';
import ZenkraftDropoffDialog from './index';

vi.mock('@/extensions/zenkraft-shipping/hooks/use-zenkraft-dropoff-locations', () => ({
    useZenkraftDropoffLocations: vi.fn(),
}));

const LOCATIONS: ZenkraftDropoffLocation[] = [
    { location_code: 'A1', display_name: 'Corner Shop', lat: '51.5072', lng: '-0.1276' },
    { location_code: 'B2', display_name: 'Post Office', lat: '51.51', lng: '-0.12' },
];

const reload = vi.fn();

function mockLocations(status: ReturnType<typeof useZenkraftDropoffLocations>['status'], locations = LOCATIONS) {
    vi.mocked(useZenkraftDropoffLocations).mockReturnValue({ status, locations, reload });
}

function renderDialog(props: Partial<Parameters<typeof ZenkraftDropoffDialog>[0]> = {}) {
    const onOpenChange = vi.fn();
    const onSelect = vi.fn();
    render(
        <ZenkraftDropoffDialog
            open
            onOpenChange={onOpenChange}
            shippingMethodId="zk-dropoff"
            onSelect={onSelect}
            {...props}
        />,
        { wrapper: ConfigWrapper }
    );
    return { onOpenChange, onSelect };
}

describe('ZenkraftDropoffDialog', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    test('loads the locations for the shipping method under an accessible title', () => {
        mockLocations('loading', []);
        renderDialog();

        expect(useZenkraftDropoffLocations).toHaveBeenCalledWith('zk-dropoff', undefined);
        expect(screen.getByRole('dialog', { name: 'Collection Points' })).toBeInTheDocument();
        expect(screen.queryByRole('radiogroup')).not.toBeInTheDocument();
    });

    test('loads the locations around the shipment it was opened for', () => {
        mockLocations('loading', []);
        renderDialog({ shipmentId: 'shipment-2' });

        expect(useZenkraftDropoffLocations).toHaveBeenCalledWith('zk-dropoff', 'shipment-2');
    });

    test('marks the nearest location by default, and confirms the selection before closing', async () => {
        const user = userEvent.setup();
        mockLocations('success');
        const { onSelect, onOpenChange } = renderDialog();

        expect(screen.getByRole('radio', { name: /Corner Shop/ })).toBeChecked();
        await user.click(screen.getByRole('radio', { name: /Post Office/ }));
        await user.click(screen.getByRole('button', { name: 'Select Post Office' }));

        expect(onSelect).toHaveBeenCalledWith(LOCATIONS[1]);
        expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    test('marks the previously chosen location when reopened', () => {
        mockLocations('success');
        renderDialog({ selectedLocationCode: 'B2' });

        expect(screen.getByRole('radio', { name: /Post Office/ })).toBeChecked();
    });

    test('shows an error with a retry action when locations fail to load', async () => {
        const user = userEvent.setup();
        mockLocations('error', []);
        renderDialog();

        expect(screen.getByRole('alert')).toHaveTextContent("We couldn't load collection points.");
        await user.click(screen.getByRole('button', { name: 'Try again' }));

        expect(reload).toHaveBeenCalled();
    });

    test('explains when no locations are available', () => {
        mockLocations('success', []);
        renderDialog();

        expect(
            screen.getByText('No collection points are available for this shipping method and this address.')
        ).toBeInTheDocument();
    });
});
