import { describe, expect, test } from 'vitest';
import { getMissingDataInputProps, validateMissingDataField } from './missing-data';

describe('validateMissingDataField', () => {
    test('requires a value for every field', () => {
        expect(validateMissingDataField('address', '   ')).toBe('returns.missingData.invalid.required');
        expect(validateMissingDataField('email', '')).toBe('returns.missingData.invalid.required');
    });

    test('accepts any non-empty address', () => {
        expect(validateMissingDataField('address', '1 Main St')).toBeNull();
    });

    test('validates email addresses', () => {
        expect(validateMissingDataField('email', 'shopper@example.com')).toBeNull();
        expect(validateMissingDataField('email', 'shopper@example')).toBe('returns.missingData.invalid.email');
        expect(validateMissingDataField('email', 'not an email')).toBe('returns.missingData.invalid.email');
    });

    test('validates phone numbers', () => {
        expect(validateMissingDataField('phone', '+1 (555) 123-4567')).toBeNull();
        expect(validateMissingDataField('phone', '020 7946 0958')).toBeNull();
        expect(validateMissingDataField('phone', '12345')).toBe('returns.missingData.invalid.phone');
        expect(validateMissingDataField('phone', 'call me')).toBe('returns.missingData.invalid.phone');
    });

    test('accepts US and UK postal codes', () => {
        expect(validateMissingDataField('postcode', '94105')).toBeNull();
        expect(validateMissingDataField('postcode', '94105-1234')).toBeNull();
        expect(validateMissingDataField('postcode', 'SW1A 1AA')).toBeNull();
        expect(validateMissingDataField('postcode', '#')).toBe('returns.missingData.invalid.postcode');
    });
});

describe('getMissingDataInputProps', () => {
    test('returns input type and autocomplete per field', () => {
        expect(getMissingDataInputProps('email')).toEqual({ type: 'email', autoComplete: 'email' });
        expect(getMissingDataInputProps('phone')).toEqual({ type: 'tel', autoComplete: 'tel' });
        expect(getMissingDataInputProps('address')).toEqual({ type: 'text', autoComplete: 'address-line1' });
        expect(getMissingDataInputProps('custom')).toEqual({ type: 'text', autoComplete: 'off' });
    });
});
