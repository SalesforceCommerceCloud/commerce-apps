/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

import type { LoaderFunctionArgs } from 'react-router';

const CDN_ORIGINS = new Set(['https://test-cdn.zenkraft.com', 'https://cdn.zenkraft.com']);
const CARRIER_IMAGE_PATH = /^\/static\/images\/carriers\/[a-zA-Z0-9_-]+\.(?:png|jpe?g|webp)$/i;
const IMAGE_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);

export async function loader({ request }: LoaderFunctionArgs) {
    const url = new URL(request.url).searchParams.get('url');
    if (!url) return new Response(null, { status: 400 });

    let logoUrl: URL;
    try {
        logoUrl = new URL(url);
    } catch {
        return new Response(null, { status: 400 });
    }

    // Only proxy public carrier images from Zenkraft's known CDN hosts.
    if (
        !CDN_ORIGINS.has(logoUrl.origin) ||
        logoUrl.username ||
        logoUrl.password ||
        !CARRIER_IMAGE_PATH.test(logoUrl.pathname)
    ) {
        return new Response(null, { status: 400 });
    }

    try {
        const image = await fetch(logoUrl, {
            redirect: 'error',
            signal: AbortSignal.timeout(5000),
        });
        if (!image.ok || !image.body) return new Response(null, { status: 502 });

        const contentType = image.headers.get('content-type')?.split(';')[0]?.trim().toLowerCase();
        if (!contentType || !IMAGE_TYPES.has(contentType)) return new Response(null, { status: 502 });

        return new Response(image.body, {
            headers: {
                'Content-Type': contentType,
                'Cache-Control': 'public, max-age=3600',
                'X-Content-Type-Options': 'nosniff',
            },
        });
    } catch {
        return new Response(null, { status: 502 });
    }
}
