/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

/**
 * Resource route — proxies to the Zenkraft custom SCAPI tracking endpoint.
 * Requires the `int_zenkraft_sfnext` cartridge on the site cartridge path and the
 * `c_zenkraft` scope to be allowed on the SLAS client.
 *
 * GET /resource/zenkraft-tracking-data
 *   ?c_trackingNumber=<tracking-number>
 *   &c_carrier=<carrier>
 *   &c_order=<orderNo>              (optional)
 *   &c_orderDetailsPage=<boolean>  (optional, default false)
 *
 * Mirrors the query parameters expected by the `getZenkraftTracking` endpoint
 * defined in int_zenkraft_sfnext/cartridge/rest-apis/zenkraft-track/.
 */

import type { LoaderFunctionArgs } from 'react-router';
import { getAuth } from '@/middlewares/auth.server';
import { getLogger } from '@/lib/logger.server';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { siteContext, type SiteContext } from '@salesforce/storefront-next-runtime/site-context';
import { getScapiBaseUrl } from '@/lib/utils';

const ZENKRAFT_TRACK_API = 'zenkraft-track';
const ZENKRAFT_TRACK_VERSION = 'v1';

export async function loader({ request, context }: LoaderFunctionArgs) {
    const url = new URL(request.url);
    const trackingNumber = url.searchParams.get('c_trackingNumber') ?? '';
    const carrier = url.searchParams.get('c_carrier') ?? '';
    const orderNo = url.searchParams.get('c_order') ?? '';
    const orderDetailsPage = url.searchParams.get('c_orderDetailsPage') ?? 'false';

    const logger = getLogger(context);

    try {
        const { accessToken } = getAuth(context);
        const config = getConfig(context);
        const { shortCode, organizationId } = config.commerce.api;
        const siteCtx = context.get(siteContext) as SiteContext;
        const siteId = siteCtx.site.id;
        const baseUrl = process.env.SCAPI_PROXY_HOST || getScapiBaseUrl(shortCode);

        const params = new URLSearchParams({ siteId, c_orderDetailsPage: orderDetailsPage });
        if (trackingNumber) params.set('c_trackingNumber', trackingNumber);
        if (carrier) params.set('c_carrier', carrier);
        if (orderNo) params.set('c_order', orderNo);

        const apiUrl = `${baseUrl}/custom/${ZENKRAFT_TRACK_API}/${ZENKRAFT_TRACK_VERSION}/organizations/${organizationId}/getZenkraftTracking?${params}`;

        const response = await fetch(apiUrl, {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                Accept: 'application/json',
            },
        });

        if (!response.ok) {
            logger.error('[zenkraft-shipping] getZenkraftTracking call failed', {
                status: response.status,
                trackingNumber,
                carrier,
                orderNo,
            });
            return Response.json({ error: 'Failed to fetch tracking data' }, { status: response.status });
        }

        const data = await response.json();
        return Response.json(data);
    } catch (error) {
        logger.error('[zenkraft-shipping] tracking resource route threw', {
            message: error instanceof Error ? error.message : String(error),
        });
        return Response.json({ error: 'Internal server error' }, { status: 500 });
    }
}
