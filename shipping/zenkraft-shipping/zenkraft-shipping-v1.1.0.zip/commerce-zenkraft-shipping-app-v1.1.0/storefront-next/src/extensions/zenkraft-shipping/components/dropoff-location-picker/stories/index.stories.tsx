import { type ReactElement, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import { expect, userEvent, within } from 'storybook/test';
import { action } from 'storybook/actions';
import { waitForStorybookReady } from '@storybook/test-utils';
import ZenkraftDropoffLocationPicker, { type ZenkraftDropoffLocationPickerProps } from '../index';
import ZenkraftDropoffLocationPickerSkeleton from '../skeleton';
import { DROPOFF_LOCATIONS } from './fixtures';

/** Holds the marked location so the story behaves like the dialog that owns it. */
function StatefulPicker({ value: initialValue, ...props }: ZenkraftDropoffLocationPickerProps): ReactElement {
    const [value, setValue] = useState(initialValue);
    return (
        <ZenkraftDropoffLocationPicker
            {...props}
            value={value}
            onValueChange={(code) => {
                setValue(code);
                props.onValueChange(code);
            }}
        />
    );
}

const meta: Meta<typeof ZenkraftDropoffLocationPicker> = {
    title: 'Extensions/Zenkraft Shipping/Drop-off Location Picker',
    component: ZenkraftDropoffLocationPicker,
    tags: ['autodocs', 'interaction'],
    render: (args) => <StatefulPicker {...args} />,
    args: {
        locations: DROPOFF_LOCATIONS,
        value: DROPOFF_LOCATIONS[0].location_code,
        onValueChange: action('onValueChange'),
        onSelect: action('onSelect'),
    },
    parameters: {
        layout: 'padded',
        docs: {
            description: {
                component:
                    'Zenkraft drop-off (collection point) list with a companion Google map. The map renders when a ' +
                    'Google Maps API key is configured (`PUBLIC__app__features__googleCloudAPI__apiKey`); ' +
                    'these stories show the list only.',
            },
        },
    },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    play: async ({ canvasElement, args }) => {
        await waitForStorybookReady(canvasElement);
        const canvas = within(canvasElement);

        await userEvent.click(canvas.getByRole('radio', { name: /Market Square Post Office/ }));
        await expect(args.onValueChange).toHaveBeenCalledWith('UPS-AP-1002');

        await userEvent.click(canvas.getByRole('button', { name: 'Select Market Square Post Office' }));
        await expect(args.onSelect).toHaveBeenCalledWith(DROPOFF_LOCATIONS[1]);
    },
};

export const WithoutOpeningHours: Story = {
    args: { value: 'UPS-AP-1003' },
    parameters: {
        docs: {
            description: { story: 'Locations without `operational_hours` omit the opening hours grid.' },
        },
    },
};

export const SingleLocation: Story = {
    args: { locations: DROPOFF_LOCATIONS.slice(0, 1) },
};

export const Loading: Story = {
    render: () => <ZenkraftDropoffLocationPickerSkeleton />,
    parameters: {
        docs: {
            description: { story: 'Skeleton shown by the dialog while locations load.' },
        },
    },
};
