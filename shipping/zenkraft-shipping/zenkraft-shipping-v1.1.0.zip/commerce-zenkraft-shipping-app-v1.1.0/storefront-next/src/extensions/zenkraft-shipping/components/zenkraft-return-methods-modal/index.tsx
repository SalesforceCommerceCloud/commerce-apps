/** @sfdc-extension-file SFDC_EXT_ZENKRAFT_SHIPPING */

import { lazy, Suspense, useCallback, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useConfig } from '@salesforce/storefront-next-runtime/config';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { getLocationPosition, type ZenkraftDropoffLocation } from '@/extensions/zenkraft-shipping/lib/dropoff-locations';

const ZenkraftDropoffMap = lazy(() => import('../dropoff-location-picker/dropoff-map'));

export type ReturnOption = {
    id: string;
    display_name?: string;
    company_name?: string;
    street1?: string;
    city?: string;
    postal_code?: string;
    distance?: string | number;
    distance_units?: string;
    location_code?: string;
    lat?: string | number;
    lng?: string | number;
};

export type ReturnMethod = {
    id: string;
    display_name?: string;
    carrier_name?: string;
    carrier_logo?: string;
    options: ReturnOption[];
};

type Props = {
    methods: ReturnMethod[];
    selectedOptionId: string;
    onClose: () => void;
    onConfirm: (optionId: string) => void;
};

export function ZenkraftReturnMethodsModal({ methods, selectedOptionId, onClose, onConfirm }: Props) {
    const { t } = useTranslation('extZenkraftShipping');
    const config = useConfig();
    const apiKey = config.features.googleCloudAPI?.apiKey ?? '';

    const [optionId, setOptionId] = useState(selectedOptionId || methods[0]?.options[0]?.id || '');
    const [expandedMethodId, setExpandedMethodId] = useState<string | null>(
        methods.find((method) => method.options.slice(1).some((option) => option.id === selectedOptionId))?.id ?? null
    );
    const optionRefs = useRef(new Map<string, HTMLElement>());

    const handleMapMarkerClick = useCallback((locationCode: string, options: ReturnOption[]) => {
        const option = options.find((o) => o.location_code === locationCode);
        if (option) {
            setOptionId(option.id);
            optionRefs.current.get(option.id)?.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
        }
    }, []);

    return (
        <Dialog
            open
            onOpenChange={(open) => {
                if (!open) onClose();
            }}
        >
            <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
                <DialogHeader>
                    <DialogTitle>{t('returns.methods.title')}</DialogTitle>
                </DialogHeader>
                <fieldset className="space-y-3">
                    <legend className="sr-only">{t('returns.methods.title')}</legend>
                    {methods.map((method) => {
                        const isExpanded = expandedMethodId === method.id;
                        const firstOption = method.options[0];
                        const hasMoreOptions = method.options.length > 1;
                        const additionalOptions = method.options.slice(1);

                        const mapLocations = method.options
                            .filter((opt) => opt.location_code)
                            .map((opt) => ({
                                location_code: opt.location_code!,
                                display_name: opt.company_name || opt.display_name,
                                lat: opt.lat,
                                lng: opt.lng,
                            }));
                        const showMap =
                            isExpanded &&
                            Boolean(apiKey) &&
                            mapLocations.some((loc) => getLocationPosition(loc));
                        const selectedOption = method.options.find((o) => o.id === optionId);
                        const mapSelectedCode = selectedOption?.location_code;

                        return (
                            <div key={method.id} className="overflow-hidden rounded-lg border border-border">
                                {/* Compact header: first option + "Other locations" link */}
                                <div className="p-4 space-y-2">
                                    {firstOption && (
                                        <label className="flex cursor-pointer items-start gap-3">
                                            <input
                                                type="radio"
                                                name="zenkraftReturnOption"
                                                value={firstOption.id}
                                                checked={optionId === firstOption.id}
                                                onChange={() => setOptionId(firstOption.id)}
                                                className="mt-0.5 shrink-0 accent-primary"
                                            />
                                            {method.carrier_logo && (
                                                <img
                                                    src={`/resource/zenkraft-carrier-logo?url=${encodeURIComponent(method.carrier_logo)}`}
                                                    alt=""
                                                    width={48}
                                                    height={48}
                                                    className="h-12 w-12 shrink-0 object-contain"
                                                    loading="lazy"
                                                />
                                            )}
                                            <span className="min-w-0 flex-1 space-y-1 text-sm">
                                                <span className="block font-medium text-foreground">
                                                    {method.display_name ?? method.carrier_name ?? method.id}
                                                    {firstOption.company_name && ` - ${firstOption.company_name}`}
                                                </span>
                                                {(firstOption.street1 || firstOption.city || firstOption.postal_code) && (
                                                    <span className="block text-muted-foreground">
                                                        {[firstOption.street1, firstOption.city, firstOption.postal_code]
                                                            .filter(Boolean)
                                                            .join(' ')}
                                                    </span>
                                                )}
                                                {firstOption.distance != null && (
                                                    <span className="block text-muted-foreground">
                                                        {firstOption.distance} {firstOption.distance_units}
                                                    </span>
                                                )}
                                            </span>
                                        </label>
                                    )}
                                    {hasMoreOptions && (
                                        <button
                                            type="button"
                                            className="pl-5 text-sm text-primary underline-offset-4 hover:underline"
                                            onClick={() =>
                                                setExpandedMethodId(isExpanded ? null : method.id)
                                            }
                                        >
                                            {isExpanded
                                                ? t('returns.methods.fewerLocations')
                                                : t('returns.methods.otherLocations')}
                                        </button>
                                    )}
                                </div>

                                {/* Expanded: map + additional options list */}
                                {isExpanded && (
                                    <div
                                        className={cn(
                                            'border-t border-border',
                                            showMap &&
                                                'grid md:grid-cols-[minmax(0,1fr)_minmax(0,1.5fr)]'
                                        )}
                                    >
                                        {showMap && (
                                            <div
                                                role="region"
                                                aria-label={t('dropoff.mapLabel')}
                                                className="h-56 overflow-hidden md:order-last md:h-auto md:min-h-[280px]"
                                            >
                                                <Suspense fallback={<Skeleton className="size-full" />}>
                                                    <ZenkraftDropoffMap
                                                        apiKey={apiKey}
                                                        locations={mapLocations as ZenkraftDropoffLocation[]}
                                                        value={mapSelectedCode}
                                                        onMarkerClick={(code: string) =>
                                                            handleMapMarkerClick(code, method.options)
                                                        }
                                                    />
                                                </Suspense>
                                            </div>
                                        )}
                                        <div className="max-h-72 divide-y divide-border overflow-y-auto">
                                            {additionalOptions.map((option) => (
                                                <label
                                                    key={option.id}
                                                    ref={(el) => {
                                                        if (el) optionRefs.current.set(option.id, el);
                                                        else optionRefs.current.delete(option.id);
                                                    }}
                                                    className={cn(
                                                        'flex cursor-pointer items-start gap-3 p-4 transition-colors',
                                                        optionId === option.id
                                                            ? 'bg-primary/5'
                                                            : 'hover:bg-muted/50'
                                                    )}
                                                >
                                                    <input
                                                        type="radio"
                                                        name="zenkraftReturnOption"
                                                        value={option.id}
                                                        checked={optionId === option.id}
                                                        onChange={() => setOptionId(option.id)}
                                                        className="mt-0.5 shrink-0 accent-primary"
                                                    />
                                                    <span className="min-w-0 flex-1 space-y-1 text-sm">
                                                        <span className="block font-medium text-foreground">
                                                            {method.display_name ?? method.carrier_name ?? method.id}
                                                            {option.company_name && ` - ${option.company_name}`}
                                                        </span>
                                                        {(option.street1 || option.city || option.postal_code) && (
                                                            <span className="block text-muted-foreground">
                                                                {[option.street1, option.city, option.postal_code]
                                                                    .filter(Boolean)
                                                                    .join(' ')}
                                                            </span>
                                                        )}
                                                        {option.distance != null && (
                                                            <span className="block text-muted-foreground">
                                                                {option.distance} {option.distance_units}
                                                            </span>
                                                        )}
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </fieldset>
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={onClose}>
                        {t('returns.methods.cancel')}
                    </Button>
                    <Button type="button" disabled={!optionId} onClick={() => onConfirm(optionId)}>
                        {t('returns.methods.confirm')}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
