'use strict';

(function () {
    var page = document.querySelector('.zk-page');
    var toggleUrl = page.getAttribute('data-toggle-url');
    var csrfToken = page.getAttribute('data-csrf-token');
    var enabledText = page.getAttribute('data-text-enabled');
    var notEnabledText = page.getAttribute('data-text-not-enabled');

    // Carrier select — show/hide UPS-specific fields
    var carrierSelect = document.getElementById('carrier');
    var upsOptions = document.getElementById('upsOptions');
    var useBillingCheckbox = document.getElementById('useBillingAsShipper');
    var shippingAddressSection = document.getElementById('shippingAddressSection');

    function toggleUPSOptions() {
        upsOptions.classList.toggle('zk-hidden', carrierSelect.value !== 'ups_rest');
    }

    function toggleShippingAddress() {
        shippingAddressSection.classList.toggle('zk-hidden', useBillingCheckbox.checked);
    }

    carrierSelect.addEventListener('change', toggleUPSOptions);
    useBillingCheckbox.addEventListener('change', toggleShippingAddress);
    toggleUPSOptions();

    // Remove button — enable only when at least one row is checked
    var checkboxes = document.querySelectorAll('.zk-row-check');
    var removeBtn = document.getElementById('removeBtn');
    checkboxes.forEach(function (cb) {
        cb.addEventListener('change', function () {
            var anyChecked = Array.prototype.some.call(checkboxes, function (c) { return c.checked; });
            removeBtn.disabled = !anyChecked;
        });
    });

    // UPS toggle — XHR
    document.querySelectorAll('.zk-toggle-input[data-carrier]').forEach(function (toggle) {
        toggle.addEventListener('change', function () {
            var carrier = toggle.getAttribute('data-carrier');
            var enabled = toggle.checked;
            var statusLabel = toggle.closest('.zk-test-account-status').querySelector('.zk-test-status-label');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', toggleUrl, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                if (xhr.status === 200) {
                    statusLabel.textContent = enabled ? enabledText : notEnabledText;
                    statusLabel.className = 'zk-test-status-label ' + (enabled ? 'zk-test-status-enabled' : 'zk-test-status-not-enabled');
                } else {
                    toggle.checked = !enabled;
                }
            };
            xhr.onerror = function () { toggle.checked = !enabled; };
            xhr.send(
                'csrf_token=' + encodeURIComponent(csrfToken) +
                '&carrier=' + encodeURIComponent(carrier) +
                '&enabled=' + encodeURIComponent(enabled)
            );
        });
    });

    // FedEx toggle — form POST
    var fedexToggle = document.getElementById('zk-fedex-toggle-input');
    if (fedexToggle) {
        fedexToggle.addEventListener('change', function () {
            document.getElementById('zk-fedex-toggle-form').submit();
        });
    }

    // Strip flash params so banners don't reappear on refresh
    if (window.history && window.history.replaceState) {
        var cleanUrl = new URL(window.location.href);
        cleanUrl.searchParams.delete('success');
        cleanUrl.searchParams.delete('error');
        window.history.replaceState(null, '', cleanUrl.toString());
    }
}());
