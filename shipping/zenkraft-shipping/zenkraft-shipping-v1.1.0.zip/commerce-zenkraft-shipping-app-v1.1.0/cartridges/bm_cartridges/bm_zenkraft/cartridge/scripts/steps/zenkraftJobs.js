'use strict';

var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var HookMgr = require('dw/system/HookMgr');
var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var Transaction = require('dw/system/Transaction');
var UUIDUtils = require('dw/util/UUIDUtils');
var dateHelper = require('*/cartridge/scripts/helpers/zenkraftDateHelper');

var logger = Logger.getLogger('zenkraft', 'zenkraftJobs');

/**
 * Calls the Zenkraft track API for a single return line item.
 * Kept here intentionally: return tracking does not use parcel custom objects.
 * @param {string} trackingNumber
 * @param {string} carrier
 * @returns {Object} tracking payload or { error: string } on failure
 */
function fetchTrackingData(trackingNumber, carrier) {
    var isTest = !Site.getCurrent().getCustomPreferenceValue('zenkraftProdMode');
    var isDebug = false;
    var shippingAccount = '';

    try {
        var advJsonRaw = Site.getCurrent().getCustomPreferenceValue('zenkraftTrackingAccountSettingsJSON');
        if (advJsonRaw) {
            var carrierPrefs = JSON.parse(advJsonRaw)[carrier];
            if (carrierPrefs) {
                // The pref's documented example stores booleans as strings ("true"); the track API requires real booleans
                if (Object.prototype.hasOwnProperty.call(carrierPrefs, 'TEST')) { isTest = String(carrierPrefs.TEST) === 'true'; }
                if (Object.prototype.hasOwnProperty.call(carrierPrefs, 'DEBUG')) { isDebug = String(carrierPrefs.DEBUG) === 'true'; }
                if (Object.prototype.hasOwnProperty.call(carrierPrefs, 'SHIPPING_ACCOUNT')) { shippingAccount = carrierPrefs.SHIPPING_ACCOUNT; }
            }
        }
    } catch (e) {
        logger.warn('Could not read zenkraftTrackingAccountSettingsJSON for carrier {0}: {1}', carrier, e.message);
    }

    var req = {
        track: {
            debug: isDebug,
            test: isTest,
            shipping_account: shippingAccount,
            carrier: carrier,
            tracking_number: trackingNumber
        }
    };

    var svc = LocalServiceRegistry.createService('zenkraft.api', {
        createRequest: function (service, body) {
            var cred = service.getConfiguration().getCredential();
            service.setURL(cred.getURL() + '/track');
            service.addHeader('zkkey', cred.getPassword());
            service.addHeader('Accept', 'application/json');
            service.addHeader('Content-Type', 'application/json');
            service.addHeader('correlation-id', UUIDUtils.createUUID());
            service.setRequestMethod('POST');
            return body;
        },
        parseResponse: function (_svc, client) {
            return JSON.parse(client.text);
        },
        filterLogMessage: function (msg) { return msg; }
    });

    var resp = svc.call(JSON.stringify(req));
    if (resp.status === 'ERROR' || empty(resp.object)) {
        return { error: resp.errorMessage || 'Tracking API error' };
    }
    return resp.object;
}

var sendReturnsNotifications = function sendNotify() {
    var iter = CustomObjectMgr.queryCustomObjects(
        'zenkraftReturnLineItem',
        "custom.trackingNumber != NULL AND custom.carrier != NULL AND (custom.trackingStage = NULL OR custom.trackingStage != 'DELIVERED')",
        null
    );

    try {
        while (iter.hasNext()) {
            var returnLineItem = iter.next();
            try {
                var trackInfo = fetchTrackingData(
                    returnLineItem.custom.trackingNumber,
                    returnLineItem.custom.carrier.toLowerCase()
                );

                if (trackInfo.error) {
                    logger.error('Tracking lookup failed for {0}: {1}', returnLineItem.custom.trackingNumber, trackInfo.error);
                } else if (!empty(trackInfo.tracking_stage) && (!returnLineItem.custom.trackingStage || returnLineItem.custom.trackingStage !== trackInfo.tracking_stage)) {
                    Transaction.wrap(function () {
                        /* eslint-disable no-param-reassign */
                        returnLineItem.custom.trackingStage = trackInfo.tracking_stage;
                        returnLineItem.custom.trackingStatus = trackInfo.status;
                        if (trackInfo.checkpoints && trackInfo.checkpoints.length > 0) {
                            returnLineItem.custom.trackingDescription = trackInfo.checkpoints[0].description || null;
                            returnLineItem.custom.trackingLastModifiedDate = trackInfo.checkpoints[0].time
                                ? dateHelper.parseISODate(trackInfo.checkpoints[0].time)
                                : null;
                        }
                        if (trackInfo.estimated_delivery) {
                            // estimatedDeliveryDate is a string attribute: keep the calendar date (YYYY-MM-DD)
                            var estimatedDate = String(trackInfo.estimated_delivery).match(/\d{4}-\d{2}-\d{2}/);
                            returnLineItem.custom.estimatedDeliveryDate = estimatedDate ? estimatedDate[0] : null;
                        }
                        /* eslint-enable no-param-reassign */
                    });
                    // Called after the stage is saved, so a failing refund hook can't roll it back and be retried next run
                    if (trackInfo.tracking_stage === 'IN_TRANSIT' && HookMgr.hasHook('app.zenkraft.returns')) {
                        HookMgr.callHook('app.zenkraft.returns', 'refund', returnLineItem);
                    }
                }
            } catch (itemErr) {
                logger.error('Error processing return line item {0}: {1}', returnLineItem.custom.trackingNumber, itemErr.message);
            }
        }
    } finally {
        iter.close();
    }
};

/**
 * Reads order numbers from a CSV file at IMPEX/src/syncOrders/<args.sourceFileName>.
 * Each line is expected to be a single order number.
 * @param {Object} args - Job step args containing sourceFileName
 * @returns {Array.<string>} valid order numbers found in the file
 */
function getOrderNumbersFromFile(args) {
    var File = require('dw/io/File');
    var FileReader = require('dw/io/FileReader');
    var OrderMgr = require('dw/order/OrderMgr');

    var importPath = [File.IMPEX, 'src', 'syncOrders'].join(File.SEPARATOR);
    var importFolder = new File(importPath);
    if (!importFolder.exists()) {
        importFolder.mkdirs();
    }

    var csvFile = new File([importPath, args.sourceFileName].join(File.SEPARATOR));
    var orderNumbers = [];
    var fileReader;
    try {
        fileReader = new FileReader(csvFile);
        var lines = fileReader.readLines();
        for (var i = 0; i < lines.length; i++) {
            var orderNumber = String(lines[i]).replace(/\r$/, '').trim();
            if (!orderNumber) { continue; }
            if (OrderMgr.getOrder(orderNumber)) {
                orderNumbers.push(orderNumber);
            } else {
                logger.warn('Order {0} not found, skipping', orderNumber);
            }
        }
    } catch (e) {
        logger.error('Error reading sync orders file {0}: {1}', args.sourceFileName, e.message);
    } finally {
        if (fileReader) {
            fileReader.close();
        }
    }
    return orderNumbers;
}

var syncOrdersAndReturns = function (data) {
    var OrderMgr = require('dw/order/OrderMgr');
    var returnHelper = require('*/cartridge/scripts/helpers/zenkraftReturnHelper');
    var orderNumbers = getOrderNumbersFromFile(data);
    if (orderNumbers.length) {
        orderNumbers.forEach(function (orderNumber) {
            try {
                var order = OrderMgr.getOrder(orderNumber);
                if (!order) {
                    logger.warn('Order {0} no longer exists, skipping', orderNumber);
                    return;
                }
                var returnCasesForThisOrder = returnHelper.checkForExistingReturnCases(order);
                var requiresApproval = returnHelper.checkOrderReturnApproval(order);
                if (returnCasesForThisOrder.length) {
                    returnCasesForThisOrder.forEach(function (returnCase) {
                        returnHelper.getSyncReturnRequest(order, returnCase.getCustom().id, requiresApproval);
                    });
                }
            } catch (orderErr) {
                logger.error('Error syncing order {0}: {1}', orderNumber, orderErr.message);
            }
        });
    } else {
        logger.warn('No order numbers provided in {0}', data.sourceFileName);
    }
};

function purgeReturnItems() {
    var iter = CustomObjectMgr.queryCustomObjects('zenkraftReturn', 'custom.markDeletion = true', null);
    try {
        while (iter.hasNext()) {
            var retItem = iter.next();
            var uuid = retItem.UUID;
            try {
                Transaction.wrap(function () {
                    CustomObjectMgr.remove(retItem);
                });
                logger.info('Removed return item {0}', uuid);
            } catch (itemErr) {
                logger.error('Failed to remove return item {0}: {1}', uuid, itemErr.message);
            }
        }
    } finally {
        iter.close();
    }
}

module.exports.sendReturnsNotifications = sendReturnsNotifications;
module.exports.syncOrdersAndReturns = syncOrdersAndReturns;
module.exports.purgeReturnItems = purgeReturnItems;
