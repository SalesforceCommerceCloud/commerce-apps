'use strict';

var File = require('dw/io/File');
var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var zenkraftCredentialHelper = require('*/cartridge/scripts/helpers/zenkraftCredentialHelper');

var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

var CREDENTIALS_ZIP_PATH = zenkraftCredentialHelper.CREDENTIALS_ZIP_PATH;

var MAX_DELETE_ATTEMPTS = 3;

function deleteCredentialsFile() {
    var credentialsZip = new File(CREDENTIALS_ZIP_PATH);
    if (!credentialsZip.exists()) {
        logger.info('Credentials ZIP not found, nothing to delete: {0}', CREDENTIALS_ZIP_PATH);
        return new Status(Status.OK);
    }

    for (var attempt = 1; attempt <= MAX_DELETE_ATTEMPTS; attempt++) {
        if (credentialsZip.remove()) {
            logger.info('Deleted credentials ZIP: {0}', CREDENTIALS_ZIP_PATH);
            return new Status(Status.OK);
        }
    }

    logger.error('Failed to delete credentials ZIP after {0} attempts: {1}', MAX_DELETE_ATTEMPTS, CREDENTIALS_ZIP_PATH);
    return new Status(Status.ERROR, 'DELETE_FAILED', CREDENTIALS_ZIP_PATH);
}

module.exports = { deleteCredentialsFile: deleteCredentialsFile };
