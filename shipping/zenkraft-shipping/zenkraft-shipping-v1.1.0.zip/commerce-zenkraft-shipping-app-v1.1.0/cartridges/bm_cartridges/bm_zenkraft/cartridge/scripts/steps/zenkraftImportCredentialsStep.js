'use strict';

var File = require('dw/io/File');
var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var zenkraftCredentialHelper = require('*/cartridge/scripts/helpers/zenkraftCredentialHelper');

var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

var CREDENTIALS_ZIP_PATH = zenkraftCredentialHelper.CREDENTIALS_ZIP_PATH;

var MAX_DELETE_ATTEMPTS = 3;

function deleteCredentialsFile() {
    var credentialsZip = new File(CREDENTIALS_ZIP_PATH);
    if (credentialsZip.exists()) {
        var deleted = false;
        for (var attempt = 1; attempt <= MAX_DELETE_ATTEMPTS && !deleted; attempt++) {
            deleted = credentialsZip.remove();
        }
        if (!deleted) {
            logger.error('Failed to delete credentials ZIP after {0} attempts: {1}', MAX_DELETE_ATTEMPTS, CREDENTIALS_ZIP_PATH);
            return new Status(Status.ERROR, 'DELETE_FAILED', CREDENTIALS_ZIP_PATH);
        }
        logger.info('Deleted credentials ZIP: {0}', CREDENTIALS_ZIP_PATH);
    } else {
        logger.info('Credentials ZIP not found, nothing to delete: {0}', CREDENTIALS_ZIP_PATH);
    }

    // The job comes here even when the import fails (jobs.xml). Signup is only possible while no key is
    // stored, so no key now means the import failed: fail the job, so the merchant sees it.
    if (!zenkraftCredentialHelper.getStoredApiKey()) {
        logger.error('Zenkraft credentials were not imported. Get the API key from Zenkraft and enter it in the zenkraft.credentials service credential.');
        return new Status(Status.ERROR, 'IMPORT_FAILED', 'Zenkraft credentials were not imported');
    }
    return new Status(Status.OK);
}

module.exports = { deleteCredentialsFile: deleteCredentialsFile };
