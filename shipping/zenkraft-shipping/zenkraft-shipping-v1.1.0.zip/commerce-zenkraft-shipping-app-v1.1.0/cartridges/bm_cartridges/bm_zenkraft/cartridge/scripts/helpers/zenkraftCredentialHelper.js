'use strict';

var File = require('dw/io/File');
var FileWriter = require('dw/io/FileWriter');
var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');

var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

// Single credential that stores the Zenkraft API key and base URL.
var CREDENTIALS = [
    { id: 'zenkraft.credentials', url: 'https://api.zenkraft.com' }
];

var IMPEX_DIR  = 'instance';
var IMPEX_FILE = 'services.xml';
var ZIP_DIR    = 'zenkraft-credentials';
var ZIP_FILE   = 'zenkraft-credentials.zip';

var CREDENTIALS_ZIP_PATH = File.IMPEX + '/src/' + IMPEX_DIR + '/' + ZIP_FILE;

function zenkraftServiceFileGenerated() {
    var instanceDirectory = new File(
        File.IMPEX + File.SEPARATOR + 'src' + File.SEPARATOR + 'instance'
    );
    
    var file = new File(instanceDirectory, ZIP_FILE);

    return instanceDirectory.isDirectory() &&
        file.exists() &&
        !file.isDirectory();   
}

function buildServicesXML(apiKey) {
    var lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<services xmlns="http://www.demandware.com/xml/impex/services/2014-09-26">'
    ];
    for (var i = 0; i < CREDENTIALS.length; i++) {
        var cred = CREDENTIALS[i];
        lines.push('    <service-credential service-credential-id="' + cred.id + '">');
        lines.push('        <url>' + cred.url + '</url>');
        lines.push('        <user-id/>');
        lines.push('        <password>' + apiKey + '</password>');
        lines.push('    </service-credential>');
    }
    lines.push('</services>');
    return lines.join('\n');
}

function writeToImpex(xml) {
    var instanceDir = new File(File.IMPEX + '/src/' + IMPEX_DIR);
    instanceDir.mkdirs();

    var servicesDir = new File(instanceDir, ZIP_DIR);
    servicesDir.mkdirs();

    var xmlFile = new File(servicesDir, IMPEX_FILE);
    var zipFile = new File(instanceDir, ZIP_FILE);
    var zipped = false;
    try {
        var writer = new FileWriter(xmlFile, 'UTF-8');
        try {
            writer.write(xml);
        } finally {
            writer.close();
        }
        servicesDir.zip(zipFile);
        zipped = true;
    } finally {
        // The XML holds the API key in plain text: never leave it, or a ZIP that failed halfway, in IMPEX
        xmlFile.remove();
        servicesDir.remove();
        if (!zipped) {
            zipFile.remove();
        }
    }

    return zipFile.fullPath;
}

/**
 * Writes a services.xml snippet for all Zenkraft credentials to the IMPEX credentials ZIP.
 * @param {string} apiKey - Merchant's Zenkraft API key
 */
function applyApiKey(apiKey) {
    var xml = buildServicesXML(apiKey);
    var filePath = writeToImpex(xml);
    logger.info('Zenkraft credential impex written to: {0}', filePath);
}

/**
 * Reads the stored API key from the rate service credential without making an HTTP call.
 * Returns null if the credential is not yet set.
 * @returns {string|null}
 */
function getStoredApiKey() {
    try {
        var svc = LocalServiceRegistry.createService('zenkraft.api', {
            createRequest: function (s) { return ''; },
            parseResponse: function () { return null; }
        });
        var password = svc.getConfiguration().getCredential().getPassword();
        return password || null;
    } catch (e) {
        logger.warn('Could not read zenkraft credential: {0}', e.message);
        return null;
    }
}

module.exports = {
    CREDENTIALS_ZIP_PATH: CREDENTIALS_ZIP_PATH,
    zenkraftServiceFileGenerated: zenkraftServiceFileGenerated,
    applyApiKey: applyApiKey,
    getStoredApiKey: getStoredApiKey
};
