'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');
var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

/**
 * GET /user — fetches the authenticated user's name and email.
 * @param {string} [apiKey] - explicit API key; falls back to stored service credential when omitted
 * @returns {dw.svc.Result}
 */
function getUser(apiKey) {
    return LocalServiceRegistry.createService('zenkraft.api', {
        createRequest: function (svc) {
            var key = apiKey || svc.getConfiguration().getCredential().getPassword();
            svc.setURL(svc.getConfiguration().getCredential().getURL() + '/user');
            svc.addHeader('zkkey', key);
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('GET');
            return '';
        },
        parseResponse: function (svc, client) {
            try {
                return JSON.parse(client.text);
            } catch (e) {
                logger.error('Failed to parse getUser response: {0}', client.text);
                return null;
            }
        },
        filterLogMessage: function (msg) {
            return msg.replace(/"api_key"\s*:\s*"[^"]*"/g, '"api_key":"***"');
        }
    }).call(null);
}

module.exports = { getUser: getUser };
