'use strict';

(function () {
    var form = document.getElementById('zk-trial-form');
    if (!form) {
        return;
    }

    // Disable submit after the first click so a double click can't create two trial accounts
    form.addEventListener('submit', function () {
        var buttons = form.querySelectorAll('button[type="submit"]');
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].disabled = true;
        }
    });
}());
