'use strict';

var Calendar = require('dw/util/Calendar');
var CSRFProtection = require('dw/web/CSRFProtection');
var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var ISML = require('dw/template/ISML');
var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var StringUtils = require('dw/util/StringUtils');
var Transaction = require('dw/system/Transaction');
var URLUtils = require('dw/web/URLUtils');
var zenkraftAccountService = require('~/cartridge/scripts/services/zenkraftAccountService');
var zenkraftCredentialHelper = require('~/cartridge/scripts/helpers/zenkraftCredentialHelper');
var zenkraftShippingAccountService = require('~/cartridge/scripts/services/zenkraftShippingAccountService');
var zenkraftUserService = require('~/cartridge/scripts/services/zenkraftUserService');

var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');
var CO_TYPE = 'zenkraftShippingAccount';

function loadShippingAccounts() {
    var accounts = [];
    var queryResult = null;
    try {
        queryResult = CustomObjectMgr.queryCustomObjects(CO_TYPE, '', 'creationDate asc');
        while (queryResult.hasNext()) {
            var obj = queryResult.next();
            accounts.push({
                id: obj.custom.id,
                carrier: obj.custom.carrier,
                name: obj.custom.name || null,
                accountNumber: obj.custom.accountNumber,
                authenticated: !!obj.custom.authenticated,
                redirectOAuthUrl: obj.custom.redirectOAuthUrl || null
            });
        }
    } catch (e) {
        logger.error('Error loading shipping accounts: {0}', e.message);
    } finally {
        if (queryResult) {
            queryResult.close();
        }
    }
    return accounts;
}

/**
 * Reads the Zenkraft error from a failed service call. The parsed body is in result.object
 * when parseResponse ran on the error response; otherwise only the raw body in result.errorMessage has it.
 * @param {dw.svc.Result} result
 * @returns {{code: string|null, message: string|null}}
 */
function getApiError(result) {
    var error = result.object && result.object.error;
    if (!(error && error.code) && result.errorMessage) {
        try {
            var body = JSON.parse(result.errorMessage);
            if (body && body.error) {
                error = body.error;
            }
        } catch (e) {
            logger.warn('Could not parse error response body: {0}', result.errorMessage);
        }
    }
    return {
        code: (error && error.code) || null,
        message: (error && error.message) || null
    };
}

/**
 * Parses the trial expiration date returned by Zenkraft.
 * A date-only value ("2026-11-02") counts until the end of that day (UTC), not its start.
 * @param {string} value - expiration_date from GET /user
 * @returns {Date|null} null if the value can't be parsed
 */
function parseExpirationDate(value) {
    var str = String(value);
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
        str += 'T23:59:59.999Z';
    }
    // Rhino only parses strict ISO: max 3 fraction digits and a "+hh:mm" offset (Zenkraft sends "+hhmm")
    str = str.replace(/(\.\d{3})\d+/, '$1').replace(/([+-]\d{2})(\d{2})$/, '$1:$2');
    var date = new Date(str);
    return isNaN(date.getTime()) ? null : date;
}

function AccountSetup() {
    if (request.httpMethod !== 'POST') {
        var zenrkaftAPIKeyGenerated = zenkraftCredentialHelper.zenkraftServiceFileGenerated();
        logger.info('Service ZIP is generated - ' + zenrkaftAPIKeyGenerated);
        var apiKey = zenkraftCredentialHelper.getStoredApiKey();
        if (apiKey) {
            var userResult = zenkraftUserService.getUser();
            var contactName = null;
            var businessEmail = null;
            var emailConfirmed = false;
            var accountCreationDate;
            var accountExpirationDate;
            if (userResult.ok && userResult.object && userResult.object.users && userResult.object.users.length > 0) {
                var userData = userResult.object;
                contactName = userData.users[0].name || null;
                businessEmail = userData.users[0].email || null;
                emailConfirmed = userData.email_confirmed;
                accountCreationDate = userData.created || null;
                accountExpirationDate = userData.expiration_date || null;
            } else {
                if (getApiError(userResult).code === 'account_expired') {
                    ISML.renderTemplate('zenkraft/accountSetup', { trialExpired: true });
                    return;
                }
                // Any other failure (rejected key, service down, no user data): don't report the account as ready
                logger.warn('Could not load Zenkraft account - status: {0}, error: {1}', userResult.status, userResult.error);
                ISML.renderTemplate('zenkraft/accountSetup', { accountUnavailable: true });
                return;
            }

            var expirationDate = null;
            if (accountExpirationDate) {
                expirationDate = parseExpirationDate(accountExpirationDate);
                if (!expirationDate) {
                    // Can't tell whether the trial is active or expired
                    logger.warn('Could not parse Zenkraft expiration_date: {0}', accountExpirationDate);
                    ISML.renderTemplate('zenkraft/accountSetup', { accountUnavailable: true });
                    return;
                }
            }

            if (!accountExpirationDate) {
                // Flow B: existing (non-trial) account — no expiration means a paid account
                ISML.renderTemplate('zenkraft/accountSetup', {
                    existingAccountReady: true,
                    contactName: contactName,
                    businessEmail: businessEmail,
                    credentialsImported: true
                });
            } else if (new Date() > expirationDate) {
                // Step 7: trial expired
                ISML.renderTemplate('zenkraft/accountSetup', {
                    trialExpired: true,
                    contactName: contactName,
                    businessEmail: businessEmail,
                    accountExpirationDate: accountExpirationDate
                });
            } else {
                // Steps 4/6: email pending or trial active
                var formattedExpirationDate = StringUtils.formatCalendar(new Calendar(expirationDate), 'd MMMM yyyy');
                ISML.renderTemplate('zenkraft/accountSetup', {
                    trialActivated: true,
                    contactName: contactName,
                    businessEmail: businessEmail,
                    emailConfirmed: emailConfirmed,
                    accountCreationDate: accountCreationDate,
                    accountExpirationDate: accountExpirationDate,
                    formattedExpirationDate: formattedExpirationDate,
                    credentialsImported: true
                });
            }
        } else if (zenrkaftAPIKeyGenerated) {
            var pendingContactName = session.custom.zenkraftPendingContactName || null;
            var pendingApiKey = session.custom.zenkraftPendingApiKey || null;
            var pendingEmailConfirmed = false;
            if (pendingApiKey) {
                var pendingUserResult = zenkraftUserService.getUser(pendingApiKey);
                if (pendingUserResult.ok && pendingUserResult.object) {
                    pendingEmailConfirmed = !!pendingUserResult.object.email_confirmed;
                } else {
                    if (getApiError(pendingUserResult).code === 'account_expired') {
                        ISML.renderTemplate('zenkraft/accountSetup', { trialExpired: true });
                        return;
                    }
                    logger.warn('Could not load pending Zenkraft account - status: {0}, error: {1}', pendingUserResult.status, pendingUserResult.error);
                    ISML.renderTemplate('zenkraft/accountSetup', { accountUnavailable: true });
                    return;
                }
            }
            var jobUrl = URLUtils.url('ViewApplication-BM', 'SelectedMenuItem', 'jobschedules').toString().replace('__bm_merchant', '__bm_admin') + '#/?job';
            if (!pendingEmailConfirmed) {
                // Step 4: email not yet confirmed — show "Confirm your email"
                ISML.renderTemplate('zenkraft/accountSetup', {
                    trialActivated: true,
                    contactName: pendingContactName,
                    emailConfirmed: false,
                    accountExpirationDate: 'pending',
                    jobUrl: jobUrl
                });
            } else {
                // Step 5: email confirmed, job not run yet — show "Account Almost Ready"
                ISML.renderTemplate('zenkraft/accountSetup', {
                    zenrkaftAPIKeyGenerated: true,
                    jobUrl: jobUrl
                });
            }
        } else if (request.httpParameterMap.existing.stringValue === '1') {
            var credentialsUrl = URLUtils.url('ServiceCredential-DisplayAll').toString();
            ISML.renderTemplate('zenkraft/accountSetup', {
                existingAccount: true,
                credentialsUrl: credentialsUrl
            });
        } else {
            ISML.renderTemplate('zenkraft/accountSetup', {
                csrfToken: CSRFProtection.generateToken()
            });
        }
        return;
    }

    var params = request.httpParameterMap;
    var contactName = params.contactName.stringValue;
    var businessEmail = params.businessEmail.stringValue;
    var companyName = params.companyName.stringValue;
    var companySize = params.companySize.stringValue;

    var useCaseValues = params.useCases.values;
    var useCases = [];
    if (useCaseValues && useCaseValues.length > 0) {
        for (var u = 0; u < useCaseValues.length; u++) {
            useCases.push(String(useCaseValues[u]));
        }
    }

    var formData = {
        contactName: contactName,
        businessEmail: businessEmail,
        companyName: companyName,
        companySize: companySize,
        useCases: useCases
    };

    if (!CSRFProtection.validateRequest()) {
        ISML.renderTemplate('zenkraft/accountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            error: 'shipping.account.setup.error.csrf',
            formData: formData
        });
        return;
    }

    // A key is already stored or a signup is waiting for the import job. Don't create
    // another trial account (double submit, back button, second tab) or replace the key.
    if (zenkraftCredentialHelper.getStoredApiKey() || zenkraftCredentialHelper.zenkraftServiceFileGenerated()) {
        logger.info('Trial signup skipped: API key already stored or credentials import pending');
        response.redirect(URLUtils.https('ZenkraftBMConfig-AccountSetup'));
        return;
    }

    var fieldErrors = {};
    if (!contactName) {
        fieldErrors.contactName = 'account.setup.error.contact.name';
    }
    if (!businessEmail) {
        fieldErrors.businessEmail = 'account.setup.error.business.email.required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(businessEmail)) {
        fieldErrors.businessEmail = 'account.setup.error.business.email.invalid';
    }
    if (!companyName) {
        fieldErrors.companyName = 'account.setup.error.company.name';
    }
    if (!companySize) {
        fieldErrors.companySize = 'account.setup.error.company.size';
    }
    if (useCases.length === 0) {
        fieldErrors.useCases = 'account.setup.error.use.cases';
    }

    if (fieldErrors.contactName || fieldErrors.businessEmail || fieldErrors.companyName || fieldErrors.companySize || fieldErrors.useCases) {
        ISML.renderTemplate('zenkraft/accountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            fieldErrors: fieldErrors,
            formData: formData
        });
        return;
    }

    var result = zenkraftAccountService.activateTrial(contactName, companyName, businessEmail, companySize, useCases);

    logger.info('Account activation result - ok: {0}, error: {1}, api_key: {2}',
        result.ok,
        result.object && result.object.error ? JSON.stringify(result.object.error) : 'none',
        result.object && result.object.account && result.object.account.api_key ? '***' : 'missing'
    );

    if (!result.ok || !result.object || !result.object.account || !result.object.account.api_key) {
        var apiError = getApiError(result);

        if (apiError.code === 'account_expired') {
            ISML.renderTemplate('zenkraft/accountSetup', { trialExpired: true });
            return;
        }

        ISML.renderTemplate('zenkraft/accountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            error: apiError.message ? null : 'account.setup.error.service',
            errorMessage: apiError.message,
            formData: formData
        });
        return;
    }

    var freshApiKey = result.object.account.api_key;
    zenkraftCredentialHelper.applyApiKey(freshApiKey);

    // Store activation data in session for the PRG redirect target (Step 4 GET).
    // The API key isn't in service credentials yet, so getUser() needs the raw key.
    session.custom.zenkraftPendingApiKey = freshApiKey;
    session.custom.zenkraftPendingContactName = contactName;

    response.redirect(URLUtils.https('ZenkraftBMConfig-AccountSetup'));
}
AccountSetup.public = true;

function ShippingAccountSetup() {
    var params = request.httpParameterMap;
    var accounts = loadShippingAccounts();
    var testUPSEnabled = accounts.some(function (a) { return a.carrier === 'ups_rest'; });
    var testFedExEnabled = accounts.some(function (a) { return a.carrier === 'fedex_v2'; });
    ISML.renderTemplate('zenkraft/shippingAccountSetup', {
        csrfToken: CSRFProtection.generateToken(),
        shippingAccounts: accounts,
        success: params.success.stringValue || null,
        error: params.error.stringValue || null,
        testUPSEnabled: testUPSEnabled,
        testFedExEnabled: testFedExEnabled
    });
}
ShippingAccountSetup.public = true;

function ToggleTestAccount() {
    if (request.httpMethod !== 'POST') {
        response.setStatus(405);
        return;
    }

    var params = request.httpParameterMap;
    var carrier = params.carrier.stringValue;
    var enabled = params.enabled.stringValue === 'true';

    logger.info('ToggleTestAccount called: carrier={0}, enabled={1}', carrier, enabled);

    // FedEx uses form POST — all outcomes redirect back to the setup page
    if (carrier === 'fedex') {
        if (!CSRFProtection.validateRequest()) {
            response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'error', 'shipping.account.setup.error.csrf'));
            return;
        }

        if (enabled) {
            logger.info('ToggleTestAccount: creating FedEx test shipping account');
            var fedexResult = zenkraftShippingAccountService.createShippingAccount({
                shipping_account: {
                    carrier: 'fedex_v2',
                    country: 'US',
                    debug: true,
                    name: 'Zenkraft Test FedEx Account',
                    test: true
                }
            });
            logger.info('ToggleTestAccount: createShippingAccount result ok={0}', fedexResult.ok);

            if (!fedexResult.ok || !fedexResult.object || !fedexResult.object.shipping_account) {
                logger.error('Failed to create FedEx test shipping account');
                response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'error', 'shipping.account.setup.error.api'));
                return;
            }

            var fedexAccount = fedexResult.object.shipping_account;
            var fedexAccountId = String(fedexAccount.id);
            var fedexName = fedexAccount.name || null;
            var fedexAuth = fedexAccount.auth || {};
            logger.info('ToggleTestAccount: FedEx account created id={0}', fedexAccountId);

            try {
                Transaction.wrap(function () {
                    var co = CustomObjectMgr.createCustomObject(CO_TYPE, fedexAccountId);
                    co.custom.carrier = 'fedex_v2';
                    co.custom.name = fedexName;
                    co.custom.accountNumber = '';
                    co.custom.authenticated = !!(fedexAuth.access_token && fedexAuth.refresh_token);
                    co.custom.redirectOAuthUrl = fedexAuth.redirect_oauth_url || null;
                });
                logger.info('ToggleTestAccount: FedEx CO saved for id={0}', fedexAccountId);
            } catch (e) {
                logger.error('Error saving FedEx test shipping account {0}: {1}', fedexAccountId, e.message);
                response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'error', 'shipping.account.setup.error.api'));
                return;
            }
        }

        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'success', 'shipping.account.setup.test.fedex.enabled'));
        return;
    }

    // UPS uses XHR — return JSON
    if (!CSRFProtection.validateRequest()) {
        response.setStatus(403);
        response.writer.print(JSON.stringify({ error: 'csrf' }));
        return;
    }

    if (carrier !== 'ups') {
        response.setStatus(400);
        response.writer.print(JSON.stringify({ error: 'invalid carrier' }));
        return;
    }

    response.setContentType('application/json');
    response.writer.print(JSON.stringify({ ok: true, enabled: enabled }));
}
ToggleTestAccount.public = true;

function AddShippingAccount() {
    if (request.httpMethod !== 'POST') {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    if (!CSRFProtection.validateRequest()) {
        ISML.renderTemplate('zenkraft/shippingAccountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            shippingAccounts: loadShippingAccounts(),
            error: 'shipping.account.setup.error.csrf'
        });
        return;
    }

    var params = request.httpParameterMap;
    var carrier = params.carrier.stringValue;
    var accountNumber = params.accountNumber.stringValue;

    if (!carrier) {
        ISML.renderTemplate('zenkraft/shippingAccountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            shippingAccounts: loadShippingAccounts(),
            error: 'shipping.account.setup.error.required'
        });
        return;
    }

    var accountName = params.accountName.stringValue || (accountNumber ? carrier + ' - ' + accountNumber : carrier);
    var billingCountry = params.billingCountry.stringValue;

    var billingAddress = {
        name: params.billingName.stringValue,
        company: params.billingCompany.stringValue,
        email: params.billingEmail.stringValue,
        phone: params.billingPhone.stringValue,
        street1: params.billingStreet1.stringValue,
        city: params.billingCity.stringValue,
        state: params.billingState.stringValue,
        postal_code: params.billingPostalCode.stringValue,
        country: billingCountry
    };
    if (params.billingStreet2.stringValue) {
        billingAddress.street2 = params.billingStreet2.stringValue;
    }

    var useBillingAsShipper = params.useBillingAsShipper.stringValue === 'on';
    var shippingAddress = useBillingAsShipper ? billingAddress : {
        street1: params.shippingStreet1.stringValue,
        city: params.shippingCity.stringValue,
        state: params.shippingState.stringValue,
        postal_code: params.shippingPostalCode.stringValue,
        country: params.shippingCountry.stringValue
    };

    var isProdMode = !!Site.getCurrent().getCustomPreferenceValue('zenkraftProdMode');

    var shippingAccountBody = {
        carrier: carrier,
        name: accountName,
        weight_units: params.weightUnits.stringValue || 'LB',
        dim_units: params.dimUnits.stringValue || 'IN',
        country: billingCountry,
        billing_address: billingAddress,
        shipping_address: shippingAddress
    };

    var parentShippingAccount = params.parentShippingAccount.stringValue || null;
    if (carrier === 'ups_rest' && parentShippingAccount) {
        shippingAccountBody.parent_shipping_account = parentShippingAccount;
    }

    if (!isProdMode) {
        shippingAccountBody.test = true;
    } else {
        var auth = { account_number: accountNumber };
        if (carrier === 'ups_rest') {
            auth.use_billing_address_as_shipper = useBillingAsShipper;
        }
        shippingAccountBody.auth = auth;
    }

    var requestBody = { shipping_account: shippingAccountBody };

    var result = zenkraftShippingAccountService.createShippingAccount(requestBody);

    if (!result.ok || !result.object || !result.object.shipping_account) {
        var apiError = null;
        if (result.object && result.object.error && result.object.error.message) {
            apiError = result.object.error.message;
            if (result.object.error.detail) {
                apiError += ': ' + result.object.error.detail;
            }
        }
        ISML.renderTemplate('zenkraft/shippingAccountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            shippingAccounts: loadShippingAccounts(),
            error: 'shipping.account.setup.error.api',
            errorMessage: apiError
        });
        return;
    }

    var shippingAccount = result.object.shipping_account;
    var accountId = String(shippingAccount.id);
    var responseName = shippingAccount.name || null;
    var responseAuth = shippingAccount.auth || {};
    var isAuthenticated = !!(responseAuth.access_token && responseAuth.refresh_token);
    var redirectOAuthUrl = responseAuth.redirect_oauth_url || null;

    try {
        Transaction.wrap(function () {
            var co = CustomObjectMgr.createCustomObject(CO_TYPE, accountId);
            co.custom.carrier = carrier;
            co.custom.name = responseName;
            co.custom.accountNumber = accountNumber;
            co.custom.authenticated = isAuthenticated;
            co.custom.redirectOAuthUrl = redirectOAuthUrl;
        });
    } catch (e) {
        logger.error('Error saving shipping account {0}: {1}', accountId, e.message);
    }

    var successKey = isAuthenticated
        ? 'shipping.account.setup.success.authenticated'
        : 'shipping.account.setup.success.pending';
    response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'success', successKey));
}
AddShippingAccount.public = true;

/**
 * Called after the merchant completes UPS OAuth.
 * Polls GET /shippingaccount/:id to confirm access_token is now present,
 * then marks the Custom Object as authenticated.
 */
function UPSOAuthCallback() {
    var accountId = request.httpParameterMap.accountId.stringValue;
    if (!accountId) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    var result = zenkraftShippingAccountService.getShippingAccount(accountId);

    if (result.ok && result.object && result.object.shipping_account) {
        var responseAuth = result.object.shipping_account.auth || {};
        var isAuthenticated = !!(responseAuth.access_token && responseAuth.refresh_token);

        if (isAuthenticated) {
            try {
                Transaction.wrap(function () {
                    var co = CustomObjectMgr.getCustomObject(CO_TYPE, accountId);
                    if (co) {
                        co.custom.authenticated = true;
                        co.custom.redirectOAuthUrl = null;
                    }
                });
            } catch (e) {
                logger.error('Error updating shipping account {0}: {1}', accountId, e.message);
            }
            response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
                'success', 'shipping.account.setup.success.authenticated'));
            return;
        }
    }

    response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
        'error', 'shipping.account.setup.error.not.authenticated'));
}
UPSOAuthCallback.public = true;

function RemoveShippingAccount() {
    if (request.httpMethod !== 'POST') {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    if (!CSRFProtection.validateRequest()) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
            'error', 'shipping.account.setup.error.csrf'));
        return;
    }

    var accountIds = request.httpParameterMap.accountId.values;
    var removedIds = [];
    var failed = false;

    if (accountIds && accountIds.length > 0) {
        for (var i = 0; i < accountIds.length; i++) {
            var accountId = String(accountIds[i]);
            // Only remove accounts this BM has a record for
            if (!CustomObjectMgr.getCustomObject(CO_TYPE, accountId)) {
                continue;
            }
            var deleteResult = zenkraftShippingAccountService.deleteShippingAccount(accountId);
            // 404 means the account is already gone in Zenkraft, so the local record is stale and can go too
            if (deleteResult.ok || deleteResult.error === 404) {
                removedIds.push(accountId);
            } else {
                failed = true;
                logger.error('Failed to delete shipping account {0} via API: {1}', accountId, deleteResult.errorMessage);
            }
        }

        try {
            Transaction.wrap(function () {
                for (var j = 0; j < removedIds.length; j++) {
                    var co = CustomObjectMgr.getCustomObject(CO_TYPE, removedIds[j]);
                    if (co) {
                        CustomObjectMgr.remove(co);
                    }
                }
            });
        } catch (e) {
            logger.error('Error removing shipping accounts: {0}', e.message);
            failed = true;
        }
    }

    if (failed) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
            'error', 'shipping.account.setup.error.remove'));
        return;
    }

    response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
        'success', 'shipping.account.setup.success.removed'));
}
RemoveShippingAccount.public = true;

exports.AccountSetup = AccountSetup;
exports.ShippingAccountSetup = ShippingAccountSetup;
exports.AddShippingAccount = AddShippingAccount;
exports.UPSOAuthCallback = UPSOAuthCallback;
exports.RemoveShippingAccount = RemoveShippingAccount;
exports.ToggleTestAccount = ToggleTestAccount;
