'use strict';

var Calendar = require('dw/util/Calendar');
var CSRFProtection = require('dw/web/CSRFProtection');
var ISML = require('dw/template/ISML');
var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var StringUtils = require('dw/util/StringUtils');
var URLUtils = require('dw/web/URLUtils');
var zenkraftAccountService = require('~/cartridge/scripts/services/zenkraftAccountService');
var zenkraftCredentialHelper = require('~/cartridge/scripts/helpers/zenkraftCredentialHelper');
var zenkraftShippingAccountService = require('~/cartridge/scripts/services/zenkraftShippingAccountService');
var zenkraftUserService = require('~/cartridge/scripts/services/zenkraftUserService');

var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

/**
 * Whether a shipping account still needs authorizing: a real UPS account (UPS OAuth) until Zenkraft has its tokens.
 * Test accounts use Zenkraft's sandbox credentials, and other carriers are ready once created.
 * @param {Object} shippingAccount - shipping_account from Zenkraft
 * @returns {boolean}
 */
function isPendingAuthorization(shippingAccount) {
    var auth = shippingAccount.auth || {};
    return shippingAccount.carrier === 'ups_rest' && shippingAccount.test !== true && !(auth.access_token && auth.refresh_token);
}

var ERROR_NOT_CONNECTED = 'shipping.account.setup.error.not.connected';
var ERROR_LOAD = 'shipping.account.setup.error.load';

/**
 * Reads the shipping accounts from Zenkraft (GET /shippingaccount): every active account of the Zenkraft account the
 * API key belongs to, including accounts created outside this page. Only what the page shows is kept, no credentials.
 * @returns {{accounts: Array, error: string|null}} error: message key when the list couldn't be read, so it's empty
 */
function loadShippingAccounts() {
    // Without an API key Zenkraft can't be asked: the Zenkraft account has to be connected in Account Setup first
    if (!zenkraftCredentialHelper.getStoredApiKey()) {
        return { accounts: [], error: ERROR_NOT_CONNECTED };
    }
    var result = zenkraftShippingAccountService.listShippingAccounts();
    var list = result.ok ? result.object : null;
    // A JSON array returned by parseResponse reaches the script as a dw.util.Collection, not a JS array
    if (list && !Array.isArray(list) && typeof list.toArray === 'function') {
        list = list.toArray();
    }
    if (!Array.isArray(list)) {
        logger.error('Could not load the shipping accounts from Zenkraft: {0}', result.errorMessage);
        return { accounts: [], error: ERROR_LOAD };
    }
    var accounts = list
        .map(function (item) { return item && item.shipping_account; })
        .filter(Boolean)
        .map(function (shippingAccount) {
            var pending = isPendingAuthorization(shippingAccount);
            return {
                id: String(shippingAccount.id),
                carrier: shippingAccount.carrier,
                name: shippingAccount.name || null,
                test: shippingAccount.test === true,
                authenticated: !pending,
                redirectOAuthUrl: pending ? ((shippingAccount.auth || {}).redirect_oauth_url || null) : null
            };
        });
    return { accounts: accounts, error: null };
}

/**
 * Renders Shipping Account Setup with the accounts read from Zenkraft
 * @param {Object} [messages] - success, error and errorMessage for the banners
 */
function renderShippingAccountSetup(messages) {
    var loaded = loadShippingAccounts();
    var hasTestAccount = function (carrier) {
        return loaded.accounts.some(function (a) { return a.test && a.carrier === carrier; });
    };
    var pdict = {
        csrfToken: CSRFProtection.generateToken(),
        shippingAccounts: loaded.accounts,
        accountsError: loaded.error,
        // Only a test account switches its toggle on: a merchant's own account of that carrier doesn't
        testUPSEnabled: hasTestAccount('ups_rest'),
        testFedExEnabled: hasTestAccount('fedex_v2')
    };
    Object.keys(messages || {}).forEach(function (key) {
        pdict[key] = messages[key];
    });
    // An action that couldn't read the list redirects with the same error the page shows: show it once
    if (pdict.error && pdict.error === loaded.error) {
        pdict.error = null;
    }
    ISML.renderTemplate('zenkraft/shippingAccountSetup', pdict);
}

/**
 * Reads the Zenkraft error from a failed service call. The parsed body is in result.object
 * when parseResponse ran on the error response; otherwise only the raw body in result.errorMessage has it.
 * @param {dw.svc.Result} result
 * @returns {{code: string|null, message: string|null}}
 */
function getApiError(result) {
    var error = result.object && result.object.error;
    if (!(error && error.code) && result.errorMessage) {
        try {
            var body = JSON.parse(result.errorMessage);
            if (body && body.error) {
                error = body.error;
            }
        } catch (e) {
            logger.warn('Could not parse error response body: {0}', result.errorMessage);
        }
    }
    return {
        code: (error && error.code) || null,
        message: (error && error.message) || null
    };
}

/**
 * Parses the trial expiration date returned by Zenkraft.
 * A date-only value ("2026-11-02") counts until the end of that day (UTC), not its start.
 * @param {string} value - expiration_date from GET /user
 * @returns {Date|null} null if the value can't be parsed
 */
function parseExpirationDate(value) {
    var str = String(value);
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
        str += 'T23:59:59.999Z';
    }
    // Rhino only parses strict ISO: max 3 fraction digits and a "+hh:mm" offset (Zenkraft sends "+hhmm")
    str = str.replace(/(\.\d{3})\d+/, '$1').replace(/([+-]\d{2})(\d{2})$/, '$1:$2');
    var date = new Date(str);
    return isNaN(date.getTime()) ? null : date;
}

function AccountSetup() {
    if (request.httpMethod !== 'POST') {
        var zenrkaftAPIKeyGenerated = zenkraftCredentialHelper.zenkraftServiceFileGenerated();
        logger.info('Service ZIP is generated - ' + zenrkaftAPIKeyGenerated);
        var apiKey = zenkraftCredentialHelper.getStoredApiKey();
        if (apiKey) {
            var userResult = zenkraftUserService.getUser();
            var contactName = null;
            var businessEmail = null;
            var emailConfirmed = false;
            var accountCreationDate;
            var accountExpirationDate;
            if (userResult.ok && userResult.object && userResult.object.users && userResult.object.users.length > 0) {
                var userData = userResult.object;
                contactName = userData.users[0].name || null;
                businessEmail = userData.users[0].email || null;
                emailConfirmed = userData.email_confirmed;
                accountCreationDate = userData.created || null;
                accountExpirationDate = userData.expiration_date || null;
            } else {
                if (getApiError(userResult).code === 'account_expired') {
                    ISML.renderTemplate('zenkraft/accountSetup', { trialExpired: true });
                    return;
                }
                // Any other failure (rejected key, service down, no user data): don't report the account as ready
                logger.warn('Could not load Zenkraft account - status: {0}, error: {1}', userResult.status, userResult.error);
                ISML.renderTemplate('zenkraft/accountSetup', { accountUnavailable: true });
                return;
            }

            var expirationDate = null;
            if (accountExpirationDate) {
                expirationDate = parseExpirationDate(accountExpirationDate);
                if (!expirationDate) {
                    // Can't tell whether the trial is active or expired
                    logger.warn('Could not parse Zenkraft expiration_date: {0}', accountExpirationDate);
                    ISML.renderTemplate('zenkraft/accountSetup', { accountUnavailable: true });
                    return;
                }
            }

            if (!accountExpirationDate) {
                // Flow B: existing (non-trial) account — no expiration means a paid account
                ISML.renderTemplate('zenkraft/accountSetup', {
                    existingAccountReady: true,
                    contactName: contactName,
                    businessEmail: businessEmail,
                    credentialsImported: true
                });
            } else if (new Date() > expirationDate) {
                // Step 7: trial expired
                ISML.renderTemplate('zenkraft/accountSetup', {
                    trialExpired: true,
                    contactName: contactName,
                    businessEmail: businessEmail,
                    accountExpirationDate: accountExpirationDate
                });
            } else {
                // Steps 4/6: email pending or trial active
                var formattedExpirationDate = StringUtils.formatCalendar(new Calendar(expirationDate), 'd MMMM yyyy');
                ISML.renderTemplate('zenkraft/accountSetup', {
                    trialActivated: true,
                    contactName: contactName,
                    businessEmail: businessEmail,
                    emailConfirmed: emailConfirmed,
                    accountCreationDate: accountCreationDate,
                    accountExpirationDate: accountExpirationDate,
                    formattedExpirationDate: formattedExpirationDate,
                    credentialsImported: true
                });
            }
        } else if (zenrkaftAPIKeyGenerated) {
            var pendingContactName = session.custom.zenkraftPendingContactName || null;
            var pendingApiKey = session.custom.zenkraftPendingApiKey || null;
            var pendingEmailConfirmed = false;
            if (pendingApiKey) {
                var pendingUserResult = zenkraftUserService.getUser(pendingApiKey);
                if (pendingUserResult.ok && pendingUserResult.object) {
                    pendingEmailConfirmed = !!pendingUserResult.object.email_confirmed;
                } else {
                    if (getApiError(pendingUserResult).code === 'account_expired') {
                        ISML.renderTemplate('zenkraft/accountSetup', { trialExpired: true });
                        return;
                    }
                    logger.warn('Could not load pending Zenkraft account - status: {0}, error: {1}', pendingUserResult.status, pendingUserResult.error);
                    ISML.renderTemplate('zenkraft/accountSetup', { accountUnavailable: true });
                    return;
                }
            }
            var jobUrl = URLUtils.url('ViewApplication-BM', 'SelectedMenuItem', 'jobschedules').toString().replace('__bm_merchant', '__bm_admin') + '#/?job';
            if (!pendingEmailConfirmed) {
                // Step 4: email not yet confirmed — show "Confirm your email"
                ISML.renderTemplate('zenkraft/accountSetup', {
                    trialActivated: true,
                    contactName: pendingContactName,
                    emailConfirmed: false,
                    accountExpirationDate: 'pending',
                    jobUrl: jobUrl
                });
            } else {
                // Step 5: email confirmed, job not run yet — show "Account Almost Ready"
                ISML.renderTemplate('zenkraft/accountSetup', {
                    zenrkaftAPIKeyGenerated: true,
                    jobUrl: jobUrl
                });
            }
        } else if (request.httpParameterMap.existing.stringValue === '1') {
            var credentialsUrl = URLUtils.url('ServiceCredential-DisplayAll').toString();
            ISML.renderTemplate('zenkraft/accountSetup', {
                existingAccount: true,
                credentialsUrl: credentialsUrl
            });
        } else {
            ISML.renderTemplate('zenkraft/accountSetup', {
                csrfToken: CSRFProtection.generateToken()
            });
        }
        return;
    }

    var params = request.httpParameterMap;
    var contactName = params.contactName.stringValue;
    var businessEmail = params.businessEmail.stringValue;
    var companyName = params.companyName.stringValue;
    var companySize = params.companySize.stringValue;

    var useCaseValues = params.useCases.values;
    var useCases = [];
    if (useCaseValues && useCaseValues.length > 0) {
        for (var u = 0; u < useCaseValues.length; u++) {
            useCases.push(String(useCaseValues[u]));
        }
    }

    var formData = {
        contactName: contactName,
        businessEmail: businessEmail,
        companyName: companyName,
        companySize: companySize,
        useCases: useCases
    };

    if (!CSRFProtection.validateRequest()) {
        ISML.renderTemplate('zenkraft/accountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            error: 'shipping.account.setup.error.csrf',
            formData: formData
        });
        return;
    }

    // A key is already stored or a signup is waiting for the import job. Don't create
    // another trial account (double submit, back button, second tab) or replace the key.
    if (zenkraftCredentialHelper.getStoredApiKey() || zenkraftCredentialHelper.zenkraftServiceFileGenerated()) {
        logger.info('Trial signup skipped: API key already stored or credentials import pending');
        response.redirect(URLUtils.https('ZenkraftBMConfig-AccountSetup'));
        return;
    }

    var fieldErrors = {};
    if (!contactName) {
        fieldErrors.contactName = 'account.setup.error.contact.name';
    }
    if (!businessEmail) {
        fieldErrors.businessEmail = 'account.setup.error.business.email.required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(businessEmail)) {
        fieldErrors.businessEmail = 'account.setup.error.business.email.invalid';
    }
    if (!companyName) {
        fieldErrors.companyName = 'account.setup.error.company.name';
    }
    if (!companySize) {
        fieldErrors.companySize = 'account.setup.error.company.size';
    }
    if (useCases.length === 0) {
        fieldErrors.useCases = 'account.setup.error.use.cases';
    }

    if (fieldErrors.contactName || fieldErrors.businessEmail || fieldErrors.companyName || fieldErrors.companySize || fieldErrors.useCases) {
        ISML.renderTemplate('zenkraft/accountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            fieldErrors: fieldErrors,
            formData: formData
        });
        return;
    }

    var result = zenkraftAccountService.activateTrial(contactName, companyName, businessEmail, companySize, useCases);

    logger.info('Account activation result - ok: {0}, error: {1}, api_key: {2}',
        result.ok,
        result.object && result.object.error ? JSON.stringify(result.object.error) : 'none',
        result.object && result.object.account && result.object.account.api_key ? '***' : 'missing'
    );

    if (!result.ok || !result.object || !result.object.account || !result.object.account.api_key) {
        var apiError = getApiError(result);

        if (apiError.code === 'account_expired') {
            ISML.renderTemplate('zenkraft/accountSetup', { trialExpired: true });
            return;
        }

        ISML.renderTemplate('zenkraft/accountSetup', {
            csrfToken: CSRFProtection.generateToken(),
            error: apiError.message ? null : 'account.setup.error.service',
            errorMessage: apiError.message,
            formData: formData
        });
        return;
    }

    var freshApiKey = result.object.account.api_key;
    zenkraftCredentialHelper.applyApiKey(freshApiKey);

    // Store activation data in session for the PRG redirect target (Step 4 GET).
    // The API key isn't in service credentials yet, so getUser() needs the raw key.
    session.custom.zenkraftPendingApiKey = freshApiKey;
    session.custom.zenkraftPendingContactName = contactName;

    response.redirect(URLUtils.https('ZenkraftBMConfig-AccountSetup'));
}
AccountSetup.public = true;

function ShippingAccountSetup() {
    var params = request.httpParameterMap;
    renderShippingAccountSetup({
        success: params.success.stringValue || null,
        error: params.error.stringValue || null
    });
}
ShippingAccountSetup.public = true;

// Zenkraft test accounts, created from the Shipping Account Setup toggles and removed from the accounts table
var TEST_ACCOUNTS = {
    fedex: { carrier: 'fedex_v2', name: 'Zenkraft Test FedEx Account', successKey: 'shipping.account.setup.test.fedex.enabled' },
    ups: { carrier: 'ups_rest', name: 'Zenkraft Test UPS Account', successKey: 'shipping.account.setup.test.ups.enabled' }
};

function ToggleTestAccount() {
    if (request.httpMethod !== 'POST') {
        response.setStatus(405);
        return;
    }

    if (!CSRFProtection.validateRequest()) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'error', 'shipping.account.setup.error.csrf'));
        return;
    }

    var params = request.httpParameterMap;
    var carrierParam = params.carrier.stringValue;
    var testAccount = Object.prototype.hasOwnProperty.call(TEST_ACCOUNTS, carrierParam) ? TEST_ACCOUNTS[carrierParam] : null;
    // The toggles only switch on: a test account is removed from the accounts table
    if (!testAccount || params.enabled.stringValue !== 'true') {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    // The toggle is locked once the account exists, but a stale page or second tab could still post.
    // If Zenkraft's list can't be read, don't create: the test account may already exist.
    var loaded = loadShippingAccounts();
    if (loaded.error) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'error', loaded.error));
        return;
    }
    var exists = loaded.accounts.some(function (a) { return a.test && a.carrier === testAccount.carrier; });
    if (exists) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    logger.info('ToggleTestAccount: creating {0} test shipping account', testAccount.carrier);
    var result = zenkraftShippingAccountService.createShippingAccount({
        shipping_account: {
            carrier: testAccount.carrier,
            country: 'US',
            debug: true,
            name: testAccount.name,
            test: true
        }
    });

    if (!result.ok || !result.object || !result.object.shipping_account) {
        logger.error('Failed to create {0} test shipping account', testAccount.carrier);
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'error', 'shipping.account.setup.error.api'));
        return;
    }

    // Nothing to store: the page reads the accounts from Zenkraft
    response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'success', testAccount.successKey));
}
ToggleTestAccount.public = true;

function AddShippingAccount() {
    if (request.httpMethod !== 'POST') {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    if (!CSRFProtection.validateRequest()) {
        renderShippingAccountSetup({ error: 'shipping.account.setup.error.csrf' });
        return;
    }

    if (!zenkraftCredentialHelper.getStoredApiKey()) {
        renderShippingAccountSetup({ error: ERROR_NOT_CONNECTED });
        return;
    }

    var params = request.httpParameterMap;
    var carrier = params.carrier.stringValue;
    var accountNumber = params.accountNumber.stringValue;

    if (!carrier) {
        renderShippingAccountSetup({ error: 'shipping.account.setup.error.required' });
        return;
    }

    var accountName = params.accountName.stringValue || (accountNumber ? carrier + ' - ' + accountNumber : carrier);
    var billingCountry = params.billingCountry.stringValue;

    var billingAddress = {
        name: params.billingName.stringValue,
        company: params.billingCompany.stringValue,
        email: params.billingEmail.stringValue,
        phone: params.billingPhone.stringValue,
        street1: params.billingStreet1.stringValue,
        city: params.billingCity.stringValue,
        state: params.billingState.stringValue,
        postal_code: params.billingPostalCode.stringValue,
        country: billingCountry
    };
    if (params.billingStreet2.stringValue) {
        billingAddress.street2 = params.billingStreet2.stringValue;
    }

    var useBillingAsShipper = params.useBillingAsShipper.stringValue === 'on';
    var shippingAddress = useBillingAsShipper ? billingAddress : {
        street1: params.shippingStreet1.stringValue,
        city: params.shippingCity.stringValue,
        state: params.shippingState.stringValue,
        postal_code: params.shippingPostalCode.stringValue,
        country: params.shippingCountry.stringValue
    };

    var isProdMode = !!Site.getCurrent().getCustomPreferenceValue('zenkraftProdMode');

    var shippingAccountBody = {
        carrier: carrier,
        name: accountName,
        weight_units: params.weightUnits.stringValue || 'LB',
        dim_units: params.dimUnits.stringValue || 'IN',
        country: billingCountry,
        billing_address: billingAddress,
        shipping_address: shippingAddress
    };

    var parentShippingAccount = params.parentShippingAccount.stringValue || null;
    if (carrier === 'ups_rest' && parentShippingAccount) {
        shippingAccountBody.parent_shipping_account = parentShippingAccount;
    }

    if (!isProdMode) {
        shippingAccountBody.test = true;
    } else {
        var auth = { account_number: accountNumber };
        if (carrier === 'ups_rest') {
            auth.use_billing_address_as_shipper = useBillingAsShipper;
        }
        shippingAccountBody.auth = auth;
    }

    var requestBody = { shipping_account: shippingAccountBody };

    var result = zenkraftShippingAccountService.createShippingAccount(requestBody);

    if (!result.ok || !result.object || !result.object.shipping_account) {
        var apiError = null;
        if (result.object && result.object.error && result.object.error.message) {
            apiError = result.object.error.message;
            if (result.object.error.detail) {
                apiError += ': ' + result.object.error.detail;
            }
        }
        renderShippingAccountSetup({ error: 'shipping.account.setup.error.api', errorMessage: apiError });
        return;
    }

    // Nothing to store: the page reads the accounts from Zenkraft
    var successKey = isPendingAuthorization(result.object.shipping_account)
        ? 'shipping.account.setup.success.pending'
        : 'shipping.account.setup.success.authenticated';
    response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup', 'success', successKey));
}
AddShippingAccount.public = true;

function RemoveShippingAccount() {
    if (request.httpMethod !== 'POST') {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup'));
        return;
    }

    if (!CSRFProtection.validateRequest()) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
            'error', 'shipping.account.setup.error.csrf'));
        return;
    }

    var accountIds = request.httpParameterMap.accountId.values;
    var failed = false;

    if (accountIds && accountIds.length > 0) {
        // Any listed account can be removed. It's deleted in Zenkraft, which only deletes accounts of the Zenkraft
        // account the API key belongs to.
        for (var i = 0; i < accountIds.length; i++) {
            var accountId = String(accountIds[i]);
            var deleteResult = zenkraftShippingAccountService.deleteShippingAccount(accountId);
            // 404 means the account is already gone in Zenkraft
            if (!deleteResult.ok && deleteResult.error !== 404) {
                failed = true;
                logger.error('Failed to delete shipping account {0} via API: {1}', accountId, deleteResult.errorMessage);
            }
        }
    }

    if (failed) {
        response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
            'error', 'shipping.account.setup.error.remove'));
        return;
    }

    response.redirect(URLUtils.https('ZenkraftBMConfig-ShippingAccountSetup',
        'success', 'shipping.account.setup.success.removed'));
}
RemoveShippingAccount.public = true;

exports.AccountSetup = AccountSetup;
exports.ShippingAccountSetup = ShippingAccountSetup;
exports.AddShippingAccount = AddShippingAccount;
exports.RemoveShippingAccount = RemoveShippingAccount;
exports.ToggleTestAccount = ToggleTestAccount;
