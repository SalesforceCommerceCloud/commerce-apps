'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');
var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

var SHIPPING_ACCOUNT_PATH = '/shippingaccount';

var SERVICE_ID = 'zenkraft.api';

// Zenkraft sends a shipping account's auth decrypted: carrier credentials, account numbers and UPS tokens. The whole
// auth object is masked; client_id and client_secret are also masked wherever else they appear.
var CREDENTIAL_KEYS = ['auth', 'newstore_token', 'client_id', 'client_secret'];
var CREDENTIAL_KEY_PATTERN = new RegExp('"(' + CREDENTIAL_KEYS.join('|') + ')"');

/**
 * @param {*} value - Parsed request or response body
 * @returns {*} - A copy with the credential keys masked, at any depth
 */
function maskCredentials(value) {
    if (Array.isArray(value)) {
        return value.map(maskCredentials);
    }
    if (value && typeof value === 'object') {
        var masked = {};
        Object.keys(value).forEach(function (key) {
            masked[key] = CREDENTIAL_KEYS.indexOf(key) !== -1 ? '***' : maskCredentials(value[key]);
        });
        return masked;
    }
    return value;
}

/**
 * Service communication log filter for every shipping account call: no credentials in the log
 * @param {string} msg - Request or response body
 * @returns {string} - The body with the credentials masked
 */
function filterLogMessage(msg) {
    if (!msg || !CREDENTIAL_KEY_PATTERN.test(msg)) {
        return msg;
    }
    try {
        return JSON.stringify(maskCredentials(JSON.parse(msg)));
    } catch (e) {
        // Can't be masked reliably
        return '[shipping account message with credentials, not logged]';
    }
}

/**
 * GET /shippingaccount — lists the active shipping accounts of the Zenkraft account the API key belongs to,
 * including accounts created outside Business Manager.
 * @returns {dw.svc.Result} object: [{ shipping_account: {...} }]
 */
function listShippingAccounts() {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc) {
            svc.setURL(svc.getConfiguration().getCredential().getURL() + SHIPPING_ACCOUNT_PATH);
            svc.addHeader('zkkey', svc.getConfiguration().getCredential().getPassword());
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('GET');
            return '';
        },
        parseResponse: function (svc, client) {
            try {
                return JSON.parse(client.text);
            } catch (e) {
                logger.error('Failed to parse listShippingAccounts response');
                return null;
            }
        },
        filterLogMessage: filterLogMessage
    }).call();
}

/**
 * POST /shippingaccount — creates a new shipping account.
 * @param {Object} requestBody  Full request body as a plain JS object
 * @returns {dw.svc.Result}
 */
function createShippingAccount(requestBody) {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc, body) {
            svc.setURL(svc.getConfiguration().getCredential().getURL() + SHIPPING_ACCOUNT_PATH);
            svc.addHeader('zkkey', svc.getConfiguration().getCredential().getPassword());
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('Content-Type', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('POST');
            return body;
        },
        parseResponse: function (svc, client) {
            try {
                return JSON.parse(client.text);
            } catch (e) {
                logger.error('Failed to parse createShippingAccount response');
                return null;
            }
        },
        filterLogMessage: filterLogMessage
    }).call(JSON.stringify(requestBody));
}

/**
 * DELETE /shippingaccount/:id — removes a shipping account from Zenkraft.
 * @param {string} accountId  Zenkraft shipping account ID
 * @returns {dw.svc.Result}
 */
function deleteShippingAccount(accountId) {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc, id) {
            svc.setURL(svc.getConfiguration().getCredential().getURL() + SHIPPING_ACCOUNT_PATH + '/' + encodeURIComponent(id));
            svc.addHeader('zkkey', svc.getConfiguration().getCredential().getPassword());
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('DELETE');
            return '';
        },
        parseResponse: function (svc, client) {
            try {
                return client.text ? JSON.parse(client.text) : {};
            } catch (e) {
                logger.error('Failed to parse deleteShippingAccount response: {0}', client.text);
                return null;
            }
        },
        filterLogMessage: filterLogMessage
    }).call(accountId);
}

module.exports = {
    listShippingAccounts: listShippingAccounts,
    createShippingAccount: createShippingAccount,
    deleteShippingAccount: deleteShippingAccount,
    filterLogMessage: filterLogMessage
};
