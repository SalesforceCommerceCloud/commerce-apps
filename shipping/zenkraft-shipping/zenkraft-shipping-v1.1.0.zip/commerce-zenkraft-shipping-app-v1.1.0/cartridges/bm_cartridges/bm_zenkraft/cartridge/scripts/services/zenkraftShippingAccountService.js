'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');
var logger = Logger.getLogger('zenkraft', 'zenkraftBMModule');

var SHIPPING_ACCOUNT_PATH = '/shippingaccount';

var SERVICE_ID = 'zenkraft.api';

/**
 * POST /shippingaccount — creates a new shipping account.
 * @param {Object} requestBody  Full request body as a plain JS object
 * @returns {dw.svc.Result}
 */
function createShippingAccount(requestBody) {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc, body) {
            svc.setURL(svc.getConfiguration().getCredential().getURL() + SHIPPING_ACCOUNT_PATH);
            svc.addHeader('zkkey', svc.getConfiguration().getCredential().getPassword());
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('Content-Type', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('POST');
            return body;
        },
        parseResponse: function (svc, client) {
            try {
                return JSON.parse(client.text);
            } catch (e) {
                logger.error('Failed to parse createShippingAccount response: {0}', client.text);
                return null;
            }
        },
        filterLogMessage: function (msg) { return msg; }
    }).call(JSON.stringify(requestBody));
}

/**
 * DELETE /shippingaccount/:id — removes a shipping account from Zenkraft.
 * @param {string} accountId  Zenkraft shipping account ID
 * @returns {dw.svc.Result}
 */
function deleteShippingAccount(accountId) {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc, id) {
            svc.setURL(svc.getConfiguration().getCredential().getURL() + SHIPPING_ACCOUNT_PATH + '/' + id);
            svc.addHeader('zkkey', svc.getConfiguration().getCredential().getPassword());
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('DELETE');
            return '';
        },
        parseResponse: function (svc, client) {
            try {
                return client.text ? JSON.parse(client.text) : {};
            } catch (e) {
                logger.error('Failed to parse deleteShippingAccount response: {0}', client.text);
                return null;
            }
        },
        filterLogMessage: function (msg) { return msg; }
    }).call(accountId);
}

/**
 * GET /shippingaccount/:id — fetches a shipping account and its current auth state.
 * Used after UPS OAuth to check if access_token / refresh_token are present.
 * @param {string} accountId  Zenkraft shipping account ID
 * @returns {dw.svc.Result}
 */
function getShippingAccount(accountId) {
    return LocalServiceRegistry.createService(SERVICE_ID, {
        createRequest: function (svc, id) {
            svc.setURL(svc.getConfiguration().getCredential().getURL() + SHIPPING_ACCOUNT_PATH + '/' + id);
            svc.addHeader('zkkey', svc.getConfiguration().getCredential().getPassword());
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
            svc.setRequestMethod('GET');
            return '';
        },
        parseResponse: function (svc, client) {
            try {
                return JSON.parse(client.text);
            } catch (e) {
                logger.error('Failed to parse getShippingAccount response: {0}', client.text);
                return null;
            }
        }
    }).call(accountId);
}

module.exports = {
    createShippingAccount: createShippingAccount,
    deleteShippingAccount: deleteShippingAccount,
    getShippingAccount: getShippingAccount
};
