'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var UUIDUtils = require('dw/util/UUIDUtils');

var callbacks = {
    createRequest: function (svc, request) {
        svc.setURL(svc.getConfiguration().getCredential().getURL() + '/account/signup');
        svc.addHeader('Accept', 'application/json');
        svc.addHeader('Content-Type', 'application/json');
        svc.addHeader('User-Agent', 'Storefront Next 1.1.0');
        svc.addHeader('correlation-id', UUIDUtils.createUUID());
        svc.setRequestMethod('POST');
        return request;
    },
    parseResponse: function (svc, client) {
        return JSON.parse(client.text);
    },
    filterLogMessage: function (msg) {
        return msg.replace(/"api_key"\s*:\s*"[^"]*"/g, '"api_key":"***"');
    }
};

var COMPANY_SIZE_MAP = {
    '1-10': '1_10',
    '11-50': '11_50',
    '51-200': '51_200',
    '201-1000': '201_1000',
    '1001-5000': '1001_5000',
    '5000+': '5001_'
};

var USE_CASE_MAP = {
    'dynamic_rates': 'rates',
    'delivery_dates': 'edd',
    'returns_portal': 'returns',
    'order_tracking': 'tracking'
};

/**
 * Calls zenkraft.api to create a trial account.
 * @param {string} contactName
 * @param {string} companyName
 * @param {string} email
 * @param {string} companySize - form value (e.g. "1-10")
 * @param {Array} useCases - form values (e.g. ["dynamic_rates", "delivery_dates"])
 * @returns {dw.svc.Result}
 */
function activateTrial(contactName, companyName, email, companySize, useCases) {
    var svc = LocalServiceRegistry.createService('zenkraft.api', callbacks);
    var mappedUseCases = (useCases || []).map(function (uc) { return USE_CASE_MAP[uc] || uc; });
    var body = JSON.stringify({
        account: {
            company: companyName,
            email: email,
            name: contactName,
            source: 'Storefront Next',
            debug: true,
            company_size: COMPANY_SIZE_MAP[companySize] || companySize,
            use_cases: mappedUseCases
        }
    });
    return svc.call(body);
}

module.exports = { activateTrial: activateTrial };
