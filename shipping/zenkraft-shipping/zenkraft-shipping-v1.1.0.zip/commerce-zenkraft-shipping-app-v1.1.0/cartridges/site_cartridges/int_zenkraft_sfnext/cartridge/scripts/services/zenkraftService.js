'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var UUIDUtils = require('dw/util/UUIDUtils');

var API_PATHS = {
    ACCOUNT: '/account/signup',
    DOPU: '/dopu',
    LABEL: '/merge',
    PACK: '/pack',
    RATE: '/rate',
    RETURN: '/return',
    RETURNS: '/returns',
    SHIP: '/ship',
    SHIPPING_ACCOUNT: '/shippingaccount',
    TRACK: '/track',
    USER: '/user'
};

var SERVICE_CALLBACKS = {
    createRequest: function (svc, args) {
        var credential = svc.getConfiguration().getCredential();
        var apiKey = credential.getPassword();
        // The install impex ships the credential without a password; addHeader() with a null value throws an opaque NPE
        if (!apiKey) {
            throw new Error('Zenkraft API key is not configured: set the password on service credential zenkraft.credentials');
        }
        svc.setURL(credential.getURL() + args.path);
        svc.addHeader('zkkey', apiKey);
        svc.addHeader('Accept', 'application/json');
        svc.addHeader('Content-Type', 'application/json');
        svc.addHeader('correlation-id', UUIDUtils.createUUID());

        if (args.path === API_PATHS.RETURNS && args.type) {
            var svcUrl = svc.getURL();
            if (args.type === 'create') {
                svc.setURL(svcUrl + '/confirm');
            } else if (args.type === 'details') {
                var returnId = JSON.parse(args.body).id;
                svc.setURL(svcUrl + '/' + returnId);
            } else if (args.type === 'returns') {
                var customerId = JSON.parse(args.body).customerNo;
                svc.setURL(svcUrl + '/?customer_id=' + customerId);
            }
        }

        svc.setRequestMethod(args.method);
        return args.method === 'GET' ? null : args.body;
    },

    parseResponse: function (svc, client) {
        return JSON.parse(client.text);
    },

    filterLogMessage: function (msg) {
        return msg
            .replace(/"street1"\s*:\s*"[^"]*"/g, '"street1":"***"')
            // Base64 labels, documents and photos make a single label call log ~700K characters
            .replace(/"(label|document|pdf|file)"\s*:\s*"[^"]{1000,}"/g, '"$1":"<base64 omitted>"');
    }
};

var svc = null;

function getService() {
    if (!svc) {
        svc = LocalServiceRegistry.createService('zenkraft.api', SERVICE_CALLBACKS);
    }
    return svc;
}

/**
 * Call the Zenkraft API at the given path
 * @param {string} apiPath - API path, e.g. '/rate' or '/pack'
 * @param {string} serviceRequest - JSON-stringified request payload (ignored for GET)
 * @param {string} [method] - HTTP method: 'POST' (default) or 'GET'
 * @param {string} [type] - Sub-type for RETURNS path: 'create' | 'details' | 'returns'
 * @returns {Object} Raw DW service call result
 */
function call(apiPath, serviceRequest, method, type) {
    return getService().call({
        path: apiPath,
        method: (method || 'POST').toUpperCase(),
        type: type || null,
        body: serviceRequest
    });
}

module.exports = {
    call: call,
    API_PATHS: API_PATHS
};
