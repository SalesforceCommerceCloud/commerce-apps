'use strict';

var Calendar = require('dw/util/Calendar');
var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var Logger = require('dw/system/Logger');
var OrderMgr = require('dw/order/OrderMgr');
var ProductMgr = require('dw/catalog/ProductMgr');
var Resource = require('dw/web/Resource');
var Site = require('dw/system/Site');
var StringUtils = require('dw/util/StringUtils');
var Transaction = require('dw/system/Transaction');
var UUIDUtils = require('dw/util/UUIDUtils');

var zenkraftService = require('../services/zenkraftService');
var dateHelper = require('./zenkraftDateHelper');
var shippingHelper = require('./zenkraftShippingHelper');

var logger = Logger.getLogger('zenkraft', 'zenkraftReturns');

/**
 * Find a product-specific return configuration in Advanced JSON.
 * @param {Object} configurations - RETURN section of Advanced JSON
 * @param {Object} products - Product IDs selected for the return
 * @returns {Object|null} Matching configuration, if any
 */
function getReturnConfig(configurations, products) {
    if (!products || !configurations) { return null; }

    var productIDs = Object.keys(products);
    var configKeys = Object.keys(configurations);
    for (var i = 0; i < productIDs.length; i++) {
        var product = ProductMgr.getProduct(productIDs[i]);
        if (!product) { continue; }

        for (var j = 0; j < configKeys.length; j++) {
            var config = configurations[configKeys[j]];
            if (!config || !config.advanced || !config.rules) { continue; }

            var ruleKeys = Object.keys(config.rules);
            if (ruleKeys.length && ruleKeys.every(function (ruleKey) {
                var value = ruleKey.indexOf('custom.') === 0
                    ? product.custom[ruleKey.slice(7)] : product[ruleKey];
                return value === config.rules[ruleKey];
            })) {
                return config;
            }
        }
    }
    return null;
}

/**
 * Resolve label and return settings from the app's site preferences and Advanced JSON.
 * @param {string} type - SHIP or RETURN
 * @param {string} key - Destination country code
 * @param {Object} products - Selected return products, keyed by product ID
 * @returns {Object} Zenkraft request settings
 */
function prepareZenkraftDataConfiguration(type, key, products) {
    var site = Site.getCurrent();
    var preference = function (id) { return site.getCustomPreferenceValue(id); };
    var specification = {};
    if (preference('zenkraftAdvancedJSON') && key && type) {
        try {
            var configurations = JSON.parse(preference('zenkraftAdvancedJSONObject') || '{}');
            var typeConfig = configurations[type] || {};
            specification = (type === 'RETURN' && getReturnConfig(typeConfig, products)) || typeConfig[key] || {};
        } catch (e) {
            logger.error('Invalid Zenkraft Advanced JSON object: {0}', e.message);
        }
    }

    var has = function (keyName) { return Object.prototype.hasOwnProperty.call(specification, keyName); };
    var setting = function (keyName, fallback) { return has(keyName) ? specification[keyName] : fallback; };
    var isReturn = type === 'RETURN';
    var address = specification.ADDRESS || {};
    var sender = isReturn ? 'zenkraftRecipient' : 'zenkraftSender';
    var unitValue = function (id, fallback) {
        var value = preference(id);
        return value && value.value ? value.value : fallback;
    };
    var postalCode = address.POSTALCODE !== undefined
        ? address.POSTALCODE : preference(sender + 'PostalCode');

    return {
        IS_TEST: !preference('zenkraftProdMode'),
        IS_DEBUG: preference('zenkraftDebugLog'),
        CARRIER: setting('CARRIER_ID', preference(isReturn ? 'zenkraftReturnsCarrier' : 'zenkraftCarrier')),
        SHIPPING_SERVICE: setting('SERVICE_TYPE', preference(isReturn ? 'zenkraftReturnsShippingService' : 'zenkraftRateServiceType')),
        PACKAGING: setting('PACKAGING', preference(isReturn ? 'zenkraftReturnsPackagingType' : 'zenkraftPackagingType')),
        DIM_UNITS: setting('DIM_UNITS', unitValue(isReturn ? 'zenkraftReturnsDimensionUnits' : 'zenkraftDimensionUnits', 'IN')),
        WEIGHT_UNITS: setting('WEIGHT_UNITS', unitValue(isReturn ? 'zenkraftReturnsWeightUnits' : 'zenkraftWeightUnits', 'LB')),
        DEFAULT_WEIGHT: preference(isReturn ? 'zenkraftReturnsDefaultProductWeight' : 'zenkraftDefaultProductWeight'),
        CURRENCY: setting('CURRENCYCODE', preference(isReturn ? 'zenkraftReturnsCurrencyCode' : 'zenkraftCurrencyCode')),
        SHIPPING_ACCOUNT: setting('ACCOUNT_ID', preference(isReturn ? 'zenkraftReturnsShippingAccount' : 'zenkraftShippingAccount')),
        SENDER_EMAIL: address.EMAIL !== undefined ? address.EMAIL : preference(sender + 'Email'),
        SENDER_NAME: address.NAME !== undefined ? address.NAME : preference(sender + 'Name'),
        SENDER_COMPANY: address.COMPANY !== undefined ? address.COMPANY : preference(sender + 'Company'),
        SENDER_STREET: address.STREET !== undefined ? address.STREET : preference(sender + 'Street'),
        SENDER_CITY: address.CITY !== undefined ? address.CITY : preference(sender + 'City'),
        SENDER_STATE: address.STATECODE !== undefined ? address.STATECODE : preference(sender + 'StateCode'),
        SENDER_POSTAL: postalCode ? String(postalCode).replace(/\s+/g, '') : '',
        SENDER_COUNTRY: address.COUNTRYCODE !== undefined ? address.COUNTRYCODE : preference(sender + 'CountryCode'),
        SENDER_PHONE: address.PHONE !== undefined ? address.PHONE : preference(sender + 'Phone'),
        LABEL_TYPE: setting('FILETYPE', isReturn ? preference('zenkraftReturnLabelFileType') : 'PDF'),
        SHIPPING_PREF: setting('SHIPPING_PREFERENCE', isReturn ? preference('zenkraftShippingPreference') : null)
    };
}

/**
 * Get order
 * @param {string|dw.order.Order} order - Order
 * @returns {dw.order.Order} - SFCC Order
 */
function getOrder(order) {
    var thisOrder;
    if (typeof order === 'string') {
        thisOrder = OrderMgr.getOrder(order);
    } else {
        thisOrder = order;
    }
    return thisOrder;
}

/**
 * Get maximum file size for reason photo and acceptable formats of its file
 * @returns {Object} - Returns file size limit and acceptable formats
 */
function getReasonPhotoLimits() {
    var sizeLimit = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnReasonPhotoMaxSize');
    var imageScale = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnReasonPhotoImageScale');
    var acceptableFileFormats = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnReasonPhotoFormats');
    var sizeLimitWarningMsg = Resource.msgf('error.upload.reasonphoto.filesize', 'zenkraft', null, Number(sizeLimit / 1024));
    var acceptableFileFormatsWarningMsg = acceptableFileFormats
        ? Resource.msgf('error.upload.reasonphoto.fileformat', 'zenkraft', null, acceptableFileFormats.join(', '))
        : '';
    return {
        sizeLimit: sizeLimit,
        imageScale: imageScale,
        acceptableFileFormats: acceptableFileFormats,
        sizeLimitWarningMsg: sizeLimitWarningMsg,
        acceptableFileFormatsWarningMsg: acceptableFileFormatsWarningMsg
    };
}

/**
 * Check available days for return of the order
 * @param {Date} orderCreationDate - Input order creation date
 * @returns {boolean} - Can be returned
 */
function checkOrderDaysAvailableForReturn(orderCreationDate) {
    var daysAvailable = Site.getCurrent().getCustomPreferenceValue('zenkraftOrderDaysAvailableForReturn');
    if (daysAvailable === 0) {
        return true;
    }

    var dateNow = new Date();

    return orderCreationDate.getTime() + (daysAvailable * 86400000) > dateNow.getTime();
}

/**
 * Check order for return approval
 * @param {string|dw.order.Order} order - Order ID or object
 * @returns {boolean} - Is order approval required
 */
function checkOrderReturnApproval(order) {
    var customerGroups = order.getCustomer().getCustomerGroups().toArray();
    var productLineItems = order.getProductLineItems().toArray();
    var isReturnApprovalRequired = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsApprovalRequire');
    var zenkraftReturnApprovalCatalogCategories = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnApprovalCatalogCategories');
    var zenkraftReturnApprovalCustomerGroups = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnApprovalCustomerGroups');

    if (isReturnApprovalRequired) {
        return isReturnApprovalRequired;
    }
    if (customerGroups.length > 0 && zenkraftReturnApprovalCustomerGroups) {
        zenkraftReturnApprovalCustomerGroups = zenkraftReturnApprovalCustomerGroups.split(',');
        customerGroups.forEach(function (customerGroup) {
            var customerGroupID = customerGroup.getID();
            zenkraftReturnApprovalCustomerGroups.forEach(function (preferenceCustomerGroup) {
                if (customerGroupID.toLowerCase() === preferenceCustomerGroup.toLowerCase()) {
                    isReturnApprovalRequired = true;
                }
            });
        });
    }
    if (productLineItems.length > 0 && zenkraftReturnApprovalCatalogCategories !== null && !isReturnApprovalRequired) {
        zenkraftReturnApprovalCatalogCategories = zenkraftReturnApprovalCatalogCategories.split(',');
        productLineItems.forEach(function (productLineItem) {
            var product = productLineItem.getProduct();
            if (!product) { return; }
            if (product.isVariant()) {
                product = product.getMasterProduct();
            }
            var catalogCategories = product.getCategories().toArray();
            catalogCategories.forEach(function (catalogCategorie) {
                zenkraftReturnApprovalCatalogCategories.forEach(function (preferenceCatalogCategorie) {
                    if (catalogCategorie.getID().toLowerCase() === preferenceCatalogCategorie.toLowerCase()) {
                        isReturnApprovalRequired = true;
                    }
                });
            });
        });
    }
    return isReturnApprovalRequired;
}

/**
 * Query for return cases
 * @param {string} query - Query string
 * @returns {array} - Array of return cases
 */
function queryReturnCases(query) {
    var zenkraftReturns = CustomObjectMgr.queryCustomObjects('zenkraftReturn', query, 'creationDate desc', null).asList().toArray();
    var returnObjects = [];
    zenkraftReturns.forEach(function (zenkraftReturn) {
        returnObjects.push(zenkraftReturn);
    });
    return returnObjects;
}

/**
 * Parse return object
 * @param {*} returnCase - Return case ID
 * @returns {Object} - Parsed object
 */
function getReturnObject(returnCase) {
    var thisReturnCase;
    if (typeof returnCase === 'string') {
        thisReturnCase = CustomObjectMgr.getCustomObject('zenkraftReturn', returnCase);
    } else {
        thisReturnCase = returnCase;
    }
    return thisReturnCase;
}

/**
 * Extract object
 * @param {*} object - Input object
 * @returns {Object} - Parsed object
 */
function extractObject(object) {
    var returnObject = {};
    returnObject.UUID = object.UUID;
    returnObject.creationDate = object.creationDate ? object.creationDate : '';

    var returnCaseKeys = Object.keys(object.custom);
    returnCaseKeys.forEach(function (key) {
        returnObject[key] = object.custom[key];
    });
    // Read from the copy: only return line items have approvedDate, and reading an attribute a custom
    // object type doesn't define (here zenkraftReturn) throws "Unknown dynamic property"
    if (returnObject.approvedDate) {
        returnObject.approvedDate = StringUtils.formatCalendar(new Calendar(returnObject.approvedDate), 'MM/dd/yy');
    }
    delete returnObject.class;
    delete returnObject.constructor;
    return returnObject;
}

/**
 * Extract object
 * @param {*} object - Input object
 * @returns {Object} - Parsed object
 */
function extractObjectForHistoryPage(object) {
    var returnObject = {};
    returnObject.UUID = object.UUID;
    returnObject.creationDate = object.creationDate ? object.creationDate : '';

    var applicableKeys = ['approvedDate', 'id', 'orderNumber', 'quantity', 'productID', 'returnLineItems', 'trackingNumber', 'trackingStage', 'trackingStatus'];
    var returnCaseKeys = Object.keys(object.custom)
        .filter(function (key) {
            return applicableKeys.indexOf(key) !== -1;
        });
    returnCaseKeys.forEach(function (key) {
        returnObject[key] = object.custom[key];
    });
    delete returnObject.class;
    delete returnObject.constructor;
    return returnObject;
}

/**
 * Get return line items
 * @param {string} returnLineItemsString - Return line items
 * @returns {array} - Parsed return line items
 */
function getReturnLineItems(returnLineItemsString) {
    var returnLineItemsIds = returnLineItemsString.split(',');
    var returnLineItemsArray = [];
    returnLineItemsIds.forEach(function (returnLineItemId) {
        var returnLineItem = CustomObjectMgr.getCustomObject('zenkraftReturnLineItem', returnLineItemId);
        if (returnLineItem) {
            returnLineItemsArray.push(returnLineItem);
        }
    });
    returnLineItemsArray.sort(function (a, b) {
        return b.creationDate.getTime() - a.creationDate.getTime();
    });

    return returnLineItemsArray;
}

/**
 * Get product image URL
 * @param {dw.catalog.Product} product - Input product
 * @returns {string} - Image url
 */
function getProductImageURL(product) {
    var types = ['small', 'medium', 'large'];
    for (var i = 0; i < types.length; i++) {
        var image = product.getImage(types[i], 0);
        if (image) {
            return image.absURL.toString();
        }
    }
    return '';
}

/**
 * Get product details
 * @param {dw.catalog.Product} product - Input product
 * @returns {Object} - Parsed product
 */
function getProductDetails(product) {
    var thisProduct;
    var extractedProduct = {};
    if (typeof product === 'string') {
        thisProduct = ProductMgr.getProduct(product);
    } else {
        thisProduct = product;
    }
    if (!thisProduct) { return extractedProduct; }
    var variationModel = thisProduct.getVariationModel();
    var productVariationAttributes = variationModel.getProductVariationAttributes().toArray();
    extractedProduct.selectedVariationAttributes = [];
    productVariationAttributes.forEach(function (productVariationAttribute) {
        var selectedValue = variationModel.getSelectedValue(productVariationAttribute);
        if (selectedValue) {
            extractedProduct.selectedVariationAttributes.push({
                id: selectedValue.ID,
                value: selectedValue.displayValue,
                typeID: productVariationAttribute.ID,
                typeValue: productVariationAttribute.displayName
            });
        }
    });
    extractedProduct.title = thisProduct.getPageTitle();
    extractedProduct.description = thisProduct.getPageDescription();
    extractedProduct.imageURL = getProductImageURL(thisProduct);
    return extractedProduct;
}

/**
 * Get return case object
 * @param {string} returnCase - Return case id
 * @returns {Object} - Return case object
 */
function getReturnCaseForHistoryPage(returnCase) {
    try {
        var thisReturnCase = getReturnObject(returnCase);
        var returnObject = extractObjectForHistoryPage(thisReturnCase);
        var totalItems = 0;
        var currentReturnLineItems = [];
        if (!empty(returnObject) && returnObject.returnLineItems && returnObject.returnLineItems.length > 0) {
            var returnLineItems = getReturnLineItems(returnObject.returnLineItems);
            if (returnLineItems.length > 0) {
                for (var i = 0; i < returnLineItems.length; i++) {
                    returnLineItems[i] = extractObjectForHistoryPage(returnLineItems[i]);
                    returnLineItems[i].product = getProductDetails(returnLineItems[i].productID);
                    // A line item saved before quantity became an int attribute may have none
                    returnLineItems[i].quantity = parseInt(returnLineItems[i].quantity, 10) || 0;
                    totalItems += returnLineItems[i].quantity;
                    currentReturnLineItems.push(returnLineItems[i].id);
                }
                returnObject.returnLineItems = returnLineItems;
            }
        }

        returnObject.totalItems = totalItems;
        return returnObject;
    } catch (e) {
        logger.error('Cannot read return case for history: {0}', e.message);
        return null;
    }
}

/**
 * Get return cases from Zenkraft API
 * @param {Array} orderNumbers - order number
 * @param {string} customerNo - customer number
 * @returns {Array} returnCases - returns for this order
 */
function getZKReturnCases(orderNumbers, customerNo) {
    var collections = require('*/cartridge/scripts/util/collections');
    var returnCases = [];
    var returnsResp = zenkraftService.call(zenkraftService.API_PATHS.RETURNS, JSON.stringify({customerNo: customerNo}), 'GET', 'returns');

    // var enableZenkraftReturnTracking = Site.getCurrent().getCustomPreferenceValue('enableZenkraftReturnTracking');
    // var returnShippingAccount = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsShippingAccount');

    var allReturnCases = returnsResp.ok ? returnsResp.object : null;
    if (allReturnCases && allReturnCases.length) {
        orderNumbers.forEach(function (orderNo) {
            var returnCasesForOrder = [];
            collections.forEach(allReturnCases, function (returnCase) {
                if (returnCase.shipment.reference_number === orderNo) {
                    returnCasesForOrder.push(returnCase);
                }
            });
            if (returnCasesForOrder && returnCasesForOrder.length) {
                returnCasesForOrder.forEach(function (returnCase) {
                    var returnLines = [];
                    var trackingStage = returnCase.shipment.status;
                    // An ISO instant, like the creation date of returns stored in the instance, so the storefront
                    // shows the shopper's local date. A date without a time becomes noon UTC: the same day everywhere.
                    var createdDate = dateHelper.parseISODate(returnCase.created);
                    var createdDay = !createdDate && returnCase.created ? String(returnCase.created).match(/\d{4}-\d{2}-\d{2}/) : null;
                    var creationDate = createdDate ? createdDate.toISOString() : (createdDay ? createdDay[0] + 'T12:00:00.000Z' : '');

                    if (returnCase.return_lines) {
                        // create new custom api for return tracking stage
                        // if (enableZenkraftReturnTracking && trackingStage !== 'DELIVERED') {
                        //     trackingStage = zenkraftReturnHelper.getReturnTrackingStatus(returnCase.shipment.tracking_number, returnCase.return_method.carrier, returnShippingAccount);
                        // }
                        returnCase.return_lines.forEach(function (returnItem) {
                            var returnProduct = getProductDetails(returnItem.sku);
                            returnLines.push({
                                returnID: returnCase.id,
                                creationDate: creationDate,
                                productID: returnItem.sku,
                                product: returnProduct,
                                quantity: returnItem.quantity,
                                trackingStage: trackingStage,
                                approvedDate: creationDate
                            });
                        });
                    }
                    var rcase = {
                        id: returnCase.id,
                        orderNumber: orderNo,
                        returnLineItems: returnLines,
                        combinedLabel: false,
                        zkReturnCase: true,
                        totalItems: returnCase.return_lines ? returnCase.return_lines.length : 0
                    };
                    returnCases.push(rcase);
                });
            }
        });
    }
    return returnCases;
}

/**
 * Get customer returns
 * @param {string} customerNo - Customer number
 * @param {array} orderNumbers - Numbers of the customer's orders to include
 * @returns {array} - Array of customer returns, newest first for SFCC return cases
 */
function getCustomerReturns(customerNo, orderNumbers) {
    var returnsHandlerId = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsHandler');
    if (!returnsHandlerId) {
        logger.error('zenkraftReturnsHandler site preference is not configured');
        return [];
    }
    if (!orderNumbers.length) {
        return [];
    }

    if (returnsHandlerId.value === 'sfcc') {
        // One query per order, as in SFRA: OR-ing several orders into one query runs into the
        // api.query.attrExpr and api.query.customAttrExpr quotas. The order numbers come from the
        // customer's own orders, not from the request, so they can go into the query as they are.
        var returnCases = [];
        orderNumbers.forEach(function (orderNo) {
            returnCases = returnCases.concat(queryReturnCases('custom.orderNumber = \'' + orderNo + '\''));
        });
        // Each query is sorted on its own
        returnCases.sort(function (a, b) {
            return b.creationDate.getTime() - a.creationDate.getTime();
        });

        return returnCases.map(function (returnCase) {
            return getReturnCaseForHistoryPage(returnCase);
        }).filter(Boolean);
    }

    return getZKReturnCases(orderNumbers, customerNo);
}

/**
 * Whether a product may be returned: it isn't assigned to a category listed in
 * zenkraftCatalogCategoriesForNonReturnableItems (comma-separated IDs, matched exactly).
 * A variant is checked by its master's categories, where category assignments live.
 * A product that no longer exists can't be checked and counts as returnable.
 * @param {dw.catalog.Product|null} product - Product to check
 * @returns {boolean} - true when the product may be returned
 */
function isProductReturnable(product) {
    var setting = Site.getCurrent().getCustomPreferenceValue('zenkraftCatalogCategoriesForNonReturnableItems');
    if (!setting || !product) {
        return true;
    }
    var nonReturnable = String(setting).split(',').map(function (id) { return id.trim(); }).filter(Boolean);
    var categoryProduct = product.variant ? product.getMasterProduct() : product;
    var categories = categoryProduct ? categoryProduct.getCategories().toArray() : [];
    return !categories.some(function (category) {
        return nonReturnable.indexOf(category.ID) > -1;
    });
}

/**
 * Quantities of an order already returned or requested for return, per product, from the return cases
 * stored in the instance (sfcc handler returns, and return requests that need approval) and, with the
 * zkapi handler, the order's return shipments in the Zenkraft API, as listed on the order page.
 * Matched by product ID, as on the order page. If Zenkraft can't be reached, its returns are not counted,
 * so an outage doesn't block returns.
 * @param {dw.order.Order} order - Order being returned
 * @returns {Object} - Returned quantity keyed by product ID
 */
function getReturnedQuantities(order) {
    var returned = {};
    var addReturned = function (productID, quantity) {
        if (productID) {
            returned[productID] = (returned[productID] || 0) + (parseInt(quantity, 10) || 0);
        }
    };

    checkForExistingReturnCases(order).forEach(function (returnCase) {
        if (!returnCase.custom.returnLineItems) {
            return;
        }
        getReturnLineItems(String(returnCase.custom.returnLineItems)).forEach(function (lineItem) {
            addReturned(lineItem.custom.productID, lineItem.custom.quantity);
        });
    });

    var returnsHandlerId = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsHandler');
    if (!returnsHandlerId || returnsHandlerId.value !== 'sfcc') {
        // The customer ID the return was created with (getZenkraftReturnMethods)
        getZKReturnCases([order.orderNo], order.customerNo || order.customerEmail).forEach(function (returnCase) {
            returnCase.returnLineItems.forEach(function (lineItem) {
                addReturned(lineItem.productID, lineItem.quantity);
            });
        });
    }
    return returned;
}

/**
 * Rebuild the shopper's return selection from the order, so a request can't return items the order doesn't hold
 * or more of them than were bought. Each item must name one of the order's product line items (itemId is its UUID)
 * at most once, with return details whose quantity is a whole number from 1 to the quantity ordered.
 * The rules the order page shows are enforced here too, so a direct API call can't skip them: the product must be
 * returnable (isProductReturnable), and together with earlier returns stored in the instance, no more of a product
 * may be returned than was ordered.
 * Product ID, name, unit price and weight are read from the line item; only the reasons and photo come from the request.
 * @param {dw.order.Order} order - Order being returned
 * @param {Array} items - Items sent by the storefront
 * @param {Object} returnDetails - Return details sent by the storefront, keyed by itemId
 * @returns {Object|null} - { items, returnDetails } built from the order, or null if any item is invalid
 */
function getValidatedReturnItems(order, items, returnDetails) {
    if (!Array.isArray(items) || !items.length || !returnDetails || typeof returnDetails !== 'object') {
        return null;
    }

    var orderItems = {};
    var orderedQuantities = {};
    order.getProductLineItems().toArray().forEach(function (pli) {
        orderItems[pli.UUID] = pli;
        orderedQuantities[pli.productID] = (orderedQuantities[pli.productID] || 0) + pli.quantityValue;
    });
    var returnedQuantities = getReturnedQuantities(order);
    var requestedQuantities = {};

    var validItems = [];
    var validDetails = {};
    for (var i = 0; i < items.length; i++) {
        var itemId = items[i] ? items[i].itemId : null;
        var pli = typeof itemId === 'string' && Object.prototype.hasOwnProperty.call(orderItems, itemId) ? orderItems[itemId] : null;
        var detail = pli ? returnDetails[itemId] : null;
        // Number() rather than parseInt, so '2abc' or 1.5 is rejected instead of read as 2 or 1
        var quantity = detail ? Number(detail.quantity) : NaN;
        if (!pli || validDetails[itemId] || quantity % 1 !== 0 || quantity < 1 || quantity > pli.quantityValue) {
            logger.warn('Return request for order {0} has an invalid item {1}', order.orderNo, itemId);
            return null;
        }

        var product = pli.product;
        if (!isProductReturnable(product)) {
            logger.warn('Return request for order {0} includes non-returnable product {1}', order.orderNo, pli.productID);
            return null;
        }
        requestedQuantities[pli.productID] = (requestedQuantities[pli.productID] || 0) + quantity;
        if (requestedQuantities[pli.productID] + (returnedQuantities[pli.productID] || 0) > orderedQuantities[pli.productID]) {
            logger.warn('Return request for order {0} returns more of product {1} than is left to return', order.orderNo, pli.productID);
            return null;
        }
        validItems.push({
            itemId: itemId,
            UUID: itemId,
            productId: pli.productID,
            productName: pli.productName,
            // What the shopper paid per unit, after item and order discounts
            productPrice: Math.round((pli.proratedPrice.value / pli.quantityValue) * 100) / 100,
            productWeight: product ? shippingHelper.extractNumber(product.custom.dimWeight) : 0,
            quantity: quantity
        });
        validDetails[itemId] = {
            quantity: quantity,
            reasonId: detail.reasonId,
            subReasonId: detail.subReasonId,
            reasonPhotoId: detail.reasonPhotoId
        };
    }

    return { items: validItems, returnDetails: validDetails };
}

/**
 * Get Return methods data for ZKAPI for order
 * @param {dw.order.Order} order - Order containing return lines
 * @param {Array} items - Return items
 * @param {Object} returnDetails - Return details
 * @returns {Object} - service response object
 */
function getZenkraftReturnMethods(order, items, returnDetails) {
    var returnLines = [];
    var defShipment = order.getDefaultShipment();
    var address = defShipment.shippingAddress;
    items.forEach(function (item) {
        returnLines.push({
            product_name: item.productName,
            line_id: item.UUID,
            sku: String(item.productId),
            quantity: parseFloat(returnDetails[item.itemId].quantity),
            value: item.productPrice || 1,
            weight: item.productWeight || 1,
            reasons: [{
                name: returnDetails[item.itemId].reasonId,
                value: returnDetails[item.itemId].reasonId,
                reasons: {
                    name: returnDetails[item.itemId].subReasonId,
                    value: returnDetails[item.itemId].subReasonId
                }
            }]
        });
    });
    var req = {
        return_methods: {
            test: !(Site.getCurrent().getCustomPreferenceValue('zenkraftProdMode')),
            debug: Site.getCurrent().getCustomPreferenceValue('zenkraftDebugLog'),
            customer_id: order.customerNo ? order.customerNo : order.customerEmail,
            order_id: order.orderNo,
            location: {
                email: order.customerEmail,
                street1: address.address1 || '',
                phone: getCustomerPhone(order),
                city: address.city || '',
                state: address.stateCode || '',
                postal_code: address.postalCode || '',
                country: address.countryCode.value || '',
                name: address.fullName || ''
            },
            return_lines: returnLines,
            references: [
                {
                    type: 'reference',
                    value: order.orderNo
                }
            ]
        }
    };

    var resp = zenkraftService.call(zenkraftService.API_PATHS.RETURNS, JSON.stringify(req));

    var returnMethods = resp.ok && resp.object && resp.object.length ? resp.object[0].return_methods : null;
    return returnMethods;
}

/**
 * Get the shopper's phone for return shipments.
 * Storefront Next collects the phone with the billing address, so the shipping address often has none.
 * @param {dw.order.Order} order - Order being returned
 * @returns {string} - Shipping address phone, else billing address phone, else an empty string
 */
function getCustomerPhone(order) {
    var defaultShipment = order.getDefaultShipment();
    var shippingAddress = defaultShipment ? defaultShipment.getShippingAddress() : null;
    var billingAddress = order.getBillingAddress();
    return (shippingAddress && shippingAddress.phone) || (billingAddress && billingAddress.phone) || '';
}

// Order attributes as named in the SFRA order model, which the preference was written for, mapped to dw.order.Order
var ORDER_ATTRIBUTE_ALIASES = { orderEmail: 'customerEmail' };

/**
 * Read the zenkraftReturnRequiredFields preference: the order and shipping address attributes a return needs
 * @returns {Array} - Required fields as { target: 'order'|'shippingAddress', attribute, field }
 */
function getReturnRequiredFields() {
    var requiredFields = [];
    try {
        var requiredFieldsJSON = JSON.parse(Site.getCurrent().getCustomPreferenceValue('zenkraftReturnRequiredFields') || '{}');
        ['order', 'shippingAddress'].forEach(function (target) {
            (requiredFieldsJSON[target] || []).forEach(function (reqItem) {
                var attribute = target === 'order' && ORDER_ATTRIBUTE_ALIASES[reqItem.attribute]
                    ? ORDER_ATTRIBUTE_ALIASES[reqItem.attribute] : reqItem.attribute;
                requiredFields.push({ target: target, attribute: attribute, field: reqItem.field });
            });
        });
    } catch (e) {
        logger.error('Cannot parse required fields. Error:' + e.message + e.stack);
    }
    return requiredFields;
}

/**
 * Get the objects that required fields are read from and written to
 * @param {dw.order.Order} order - Order being returned
 * @returns {Object} - Order and its shipping address, keyed by required field target
 */
function getRequiredFieldTargets(order) {
    var defaultShipment = order.getDefaultShipment();
    return {
        order: order,
        shippingAddress: defaultShipment ? defaultShipment.getShippingAddress() : null
    };
}

/**
 * Whether a required field has no value yet, so the shopper may fill it in.
 * A shipping address phone counts as present when the order has a phone elsewhere (getCustomerPhone).
 * @param {dw.order.Order} order - Order being returned
 * @param {Object} targets - Objects required fields are read from, from getRequiredFieldTargets
 * @param {Object} reqField - Required field as { target, attribute, field }
 * @returns {boolean} - true when the field is empty; false when it has a value or the attribute doesn't exist
 */
function isRequiredFieldMissing(order, targets, reqField) {
    var target = targets[reqField.target];
    var value = target ? target[reqField.attribute] : undefined;
    if (!value && reqField.target === 'shippingAddress' && reqField.attribute === 'phone') {
        value = getCustomerPhone(order) || value;
    }
    // undefined means the attribute doesn't exist (e.g. a typo in the preference), so the shopper couldn't fill it in
    return value !== undefined && !value;
}

/**
 * Find if order shipment is missing data for email , address or phone number
 * @param {Object} order - current return order
 * @returns {Object|null} result - Return missing data
 */
function checkForMissingImportantData(order) {
    var missingData = [];
    var targets = getRequiredFieldTargets(order);

    getReturnRequiredFields().forEach(function (reqField) {
        if (isRequiredFieldMissing(order, targets, reqField)) {
            missingData.push({
                field: reqField.field,
                label: Resource.msg('label.' + reqField.field, 'zenkraft', 'Missing information')
            });
        }
    });

    return missingData.length ? {
        missingData: missingData,
        missingDataLabel: Resource.msg('warning.shipment.missing.details', 'zenkraft', null)
    } : null;
}

/**
 * Fill in missing order data entered by the shopper, for the fields the zenkraftReturnRequiredFields preference lists.
 * Only fields that are still empty are written, so the endpoint can't change data the order already has
 * (e.g. the shipping address of a placed order after fraud and tax checks).
 * Must be called inside a transaction.
 * @param {dw.order.Order} order - Order being returned
 * @param {Object} values - Entered values keyed by the preference's field names, e.g. { email: '...', phone: '...' }
 */
function updateMissingData(order, values) {
    var targets = getRequiredFieldTargets(order);

    getReturnRequiredFields().forEach(function (reqField) {
        var target = targets[reqField.target];
        var value = values[reqField.field];
        if (!target || typeof value !== 'string' || !value.trim()) { return; }
        if (!isRequiredFieldMissing(order, targets, reqField)) {
            logger.warn('Ignored {0}.{1} for order {2}: the order already has a value', reqField.target, reqField.attribute, order.orderNo);
            return;
        }

        var setter = 'set' + reqField.attribute.charAt(0).toUpperCase() + reqField.attribute.slice(1);
        try {
            if (typeof target[setter] === 'function') {
                target[setter](value.trim().slice(0, 256));
            } else {
                target[reqField.attribute] = value.trim().slice(0, 256);
            }
        } catch (e) {
            logger.error('Cannot update {0}.{1} for order {2}: {3}', reqField.target, reqField.attribute, order.orderNo, e.message);
        }
    });
}

/**
 * Check if return case exists for order
 * @param {string} order - Input order number
 * @returns {Array} existingReturnCases - array of existing return cases
 */
function checkForExistingReturnCases(order) {
    var thisOrder = getOrder(order);
    var query = 'custom.orderNumber =\'' + thisOrder.orderNo + '\'';
    var existingReturnCases = queryReturnCases(query);

    return existingReturnCases;
}

/**
 * Update return case linte item ids
 * @param {Object} existingReturnCase - Existing return case
 * @param {array} returnLineItemIds - Return line item IDs
 */
function updateReturnCaselineItemIds(existingReturnCase, returnLineItemIds) {
    var thisReturnCase = existingReturnCase;
    Transaction.wrap(function () {
        if (existingReturnCase.custom.returnLineItems && existingReturnCase.custom.returnLineItems.length > 0) {
            thisReturnCase.custom.returnLineItems = thisReturnCase.custom.returnLineItems + ',' + returnLineItemIds.toString();
        } else {
            thisReturnCase.custom.returnLineItems = returnLineItemIds.toString();
        }
    });
}

/**
* Create the object that will be passed in the /ship API call
* @param {Object} order sfcc order
* @param {string} type type of request, ex: outbound
* @param {Object} products products being shipped
* @return {Object} JSON Object of Request Data
*/
function getShippingLabelRequest(order, type, products) {
    var req = {};
    var packages = [];
    var customsItems = [];
    var references = [];
    var prefs;
    var shipservice;
    var defShipment = order.getDefaultShipment();
    var address = defShipment.shippingAddress;
    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth() + 1;
    var y = date.getFullYear();
    var productLineItems;
    var pli;
    var pliItem;
    var quantity;
    var reference;
    var i;

    var dateString = y + '-' + (m <= 9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
    var SystemObjectMgr = require('dw/object/SystemObjectMgr');
    // Get appropriate preferences and shipping service for the situation
    if (type === 'outbound') {
        // eslint-disable-next-line max-len
        prefs = prepareZenkraftDataConfiguration('SHIP', address.countryCode.value.toUpperCase());
        shipservice = defShipment.shippingMethod.custom.zenkraftID;
    } else {
        // eslint-disable-next-line max-len=
        prefs = prepareZenkraftDataConfiguration('RETURN', address.countryCode.value.toUpperCase(), products);
        shipservice = prefs.SHIPPING_SERVICE;
    }
    var warehouseAddress = {
        email: prefs.SENDER_EMAIL,
        street1: prefs.SENDER_STREET,
        company: !empty(prefs.SENDER_COMPANY) ? prefs.SENDER_COMPANY : '',
        phone: !empty(prefs.SENDER_PHONE) ? prefs.SENDER_PHONE : '1234567890',
        city: prefs.SENDER_CITY,
        state: prefs.SENDER_STATE,
        postal_code: prefs.SENDER_POSTAL,
        country: !empty(prefs.SENDER_COUNTRY) ? prefs.SENDER_COUNTRY.toUpperCase() : 'US',
        name: !empty(prefs.SENDER_NAME) ? prefs.SENDER_NAME : ''
    };

    var isBringgOrder = !empty(defShipment.custom.bringgLocationID);
    if (isBringgOrder) {
        var store = SystemObjectMgr.querySystemObject('Store', 'custom.zenkraftBringgTeamID = {0}', String(defShipment.custom.bringgLocationID));
        if (store && !empty(store.postalCode) && !empty(store.address1) && !empty(store.city)) {
            warehouseAddress = {
                email: store.email,
                street1: store.address1,
                company: store.custom.companyName || '',
                phone: store.phone || '1234567890',
                city: store.city,
                state: store.stateCode,
                postal_code: store.postalCode,
                country: !empty(store.countryCode) ? store.countryCode.value.toUpperCase() : 'US',
                name: store.name || ''
            };
        }
    }
    // build shipment
    req.shipment = {
        test: prefs.IS_TEST,
        debug: prefs.IS_DEBUG,
        carrier: prefs.CARRIER,
        service: shipservice,
        ship_date: dateString,
        type: !empty(type) ? type : 'return',
        packaging: prefs.PACKAGING,
        dim_units: prefs.DIM_UNITS,
        weight_units: prefs.WEIGHT_UNITS,
        currency: prefs.CURRENCY,
        shipping_account: prefs.SHIPPING_ACCOUNT,
        label_type: prefs.LABEL_TYPE,
        include_base64_label: true
    };


    // build sender data from order address
    var customerAddress = {
        street1: !empty(address.address1) ? address.address1 : '',
        city: !empty(address.city) ? address.city : '',
        state: !empty(address.stateCode) ? address.stateCode : '',
        postal_code: !empty(address.postalCode) ? address.postalCode.replace(/\s+/g, '') : '',
        country: !empty(address.countryCode) ? address.countryCode.value.toUpperCase() : '',
        company: address.companyName || address.fullName,
        name: !empty(address.fullName) ? address.fullName : '',
        phone: getCustomerPhone(order) || '1234567890',
        email: !empty(order.customerEmail) ? order.customerEmail : ''
    };

    req.shipment.recipient = customerAddress;
    req.shipment.sender = warehouseAddress;

    // build packages using current cart
    productLineItems = order.getAllProductLineItems().iterator();

    // If the type of request is a return, then use specific products.
    // If it's an outbound request, use all of the products on the order
    if (type === 'return') {
        while (productLineItems.hasNext()) {
            pli = productLineItems.next();
            pliItem = pli.product;

            // only use the products that the user selected for return
            if (empty(pliItem)) continue;

            if (products.hasOwnProperty(pliItem.ID)) {
                quantity = products[pliItem.ID];

                for (i = 0; i < quantity; i++) {
                    packages.push({
                        weight: !empty(pliItem.custom.dimWeight) ? shippingHelper.extractNumber(pliItem.custom.dimWeight) : 1,
                        value: 1,
                        // dimDepth is the product length, as in checkout rates; custom.length is kept for SFRA-era catalogs
                        length: !empty(pliItem.custom.dimDepth) ? shippingHelper.extractNumber(pliItem.custom.dimDepth)
                            : (!empty(pliItem.custom.length) ? shippingHelper.extractNumber(String(pliItem.custom.length)) : 1),
                        width: !empty(pliItem.custom.dimWidth) ? shippingHelper.extractNumber(pliItem.custom.dimWidth) : 1,
                        height: !empty(pliItem.custom.dimHeight) ? shippingHelper.extractNumber(pliItem.custom.dimHeight) : 1,
                        references: [{
                            type: 'reference_1',
                            value: UUIDUtils.createUUID()
                        }]
                    });
                }
                if (customerAddress.country !== warehouseAddress.country) {
                    customsItems.push({
                        harmonized_code: pliItem.getCustom().harmonized_code ? pliItem.getCustom().harmonized_code : '',
                        description: pliItem.getName(),
                        manufacture_country_code: pliItem.getCustom().manufacture_country_code ? pliItem.getCustom().manufacture_country_code : '',
                        quantity: quantity,
                        quantity_unit: 'ea',
                        value: pliItem.getPriceModel().getPrice().getValue(),
                        currency: pliItem.getPriceModel().getPrice().getCurrencyCode(),
                        weight: pliItem.getCustom().dimWeight ? pliItem.getCustom().dimWeight : 1,
                        weight_unit: prefs.WEIGHT_UNITS || 'KG'
                    });
                }
            }
        }
        if (customerAddress.country !== warehouseAddress.country) {
            req.shipment.customs_items = customsItems;
        }

        var singleShipingForMultipleItems = Site.getCurrent().getCustomPreferenceValue('zenkraftSingleShipmentForMultipleReturnLineItems');
        if (!singleShipingForMultipleItems) {
            req.shipment.packages = packages;
        } else {
            // Reduce packages
            var firstPackage = packages.slice(0, 1);
            var totalWeight = packages.reduce(function (previousValue, currentValue) {
                return previousValue + currentValue.weight;
            }, 0);
            firstPackage[0].weight = totalWeight;
            req.shipment.packages = firstPackage;
        }

        var syncReturns = Site.getCurrent().getCustomPreferenceValue('syncReturnWithZenkraft');
        if (syncReturns) {
            req.shipment.save_for_returns = syncReturns;
        }

        var shippingPreference = prefs.SHIPPING_PREF;
        if (shippingPreference) {
            req.shipment.custom = [
                {
                    name: 'zkmulti__Shipmate_Preference__c',
                    value: shippingPreference
                }
            ];
        }
    } else {
        while (productLineItems.hasNext()) {
            pli = productLineItems.next();
            pliItem = pli.product;
            quantity = pli.quantityValue;

            for (i = 0; i < quantity; i++) {
                packages.push({
                    weight: !empty(pliItem.custom.dimWeight) ? shippingHelper.extractNumber(pliItem.custom.dimWeight) : 1,
                    value: 1,
                    // dimDepth is the product length, as in checkout rates; custom.length is kept for SFRA-era catalogs
                    length: !empty(pliItem.custom.dimDepth) ? shippingHelper.extractNumber(pliItem.custom.dimDepth)
                        : (!empty(pliItem.custom.length) ? shippingHelper.extractNumber(String(pliItem.custom.length)) : 1),
                    width: !empty(pliItem.custom.dimWidth) ? shippingHelper.extractNumber(pliItem.custom.dimWidth) : 1,
                    height: !empty(pliItem.custom.dimHeight) ? shippingHelper.extractNumber(pliItem.custom.dimHeight) : 1
                });
            }
        }

        req.shipment.packages = packages;
    }

    reference = {
        type: 'reference_1',
        value: order.orderNo
    };

    references.push(reference);

    req.shipment.references = references;

    var zenkraftReturnSpecialServices = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnSpecialServices');
    if (!empty(zenkraftReturnSpecialServices)) {
        zenkraftReturnSpecialServices = zenkraftReturnSpecialServices.split(',');
        req.shipment.special_services = zenkraftReturnSpecialServices;
    }

    return req;
}

/**
* Get Shipping Label From Zenkraft Web Service
*
* @param {Object} order sfcc order object
* @param {Object} products products in shipment
* @param {string} emailaddress optional; email address to send label to
* @param {Object} options label options
* @return {HashMap} JSON Object of Available Shipping Method Data
*/
function getShippingLabel(order, products, emailaddress, options) {
    var resp = {
        object: {}
    };
    var mergedResponse;
    var req = {};
    var address = order.shipments[0].shippingAddress;
    var pickupOption = options && options.type === 'pickup';

    if (options && options.address) {
        address = options.address;
    }
    req = getShippingLabelRequest(order, 'return', products);

    if (pickupOption) {
        var prefs = prepareZenkraftDataConfiguration('RETURN', address.countryCode.value.toUpperCase(), products);
        var shipservice = prefs.SHIPPING_SERVICE;

        var req2 = {
            pickup: {
                carrier: prefs.CARRIER,
                debug: prefs.IS_TEST,
                dim_units: prefs.DIM_UNITS,
                location: {
                    city: address.city,
                    company: address.companyName || 'Zenkraft',
                    country: address.countryCode.value,
                    email: 'test@example.com',
                    location_type: 'front',
                    name: address.fullName,
                    phone: address.phone,
                    postal_code: address.postalCode,
                    state: address.stateCode,
                    street1: address.address1
                },
                shipments: [
                    {
                        packages: [
                            {
                                items: [{
                                    quantity: 1,
                                    weight: 1
                                }]
                            }
                        ],
                        recipient: {
                            country: !empty(prefs.SENDER_COUNTRY) ? prefs.SENDER_COUNTRY.toUpperCase() : 'US'
                        },
                        service: shipservice,
                        package_type: 'package'
                    }
                ],
                shipping_account: prefs.SHIPPING_ACCOUNT,
                test: prefs.IS_TEST,
                time: {
                    ready_time: options.from || '09:45',
                    close_time: options.to || '16:45',
                    date: options.date
                },
                weight_units: prefs.WEIGHT_UNITS
            }
        };
        resp = zenkraftService.call('/pickup', JSON.stringify(req2));
        var resp2 = zenkraftService.call(zenkraftService.API_PATHS.SHIP, JSON.stringify(req));
        mergedResponse = {
            object: Object.assign({}, resp.object, resp2.object)
        };
        return mergedResponse.object;
    }

    resp = zenkraftService.call(zenkraftService.API_PATHS.SHIP, JSON.stringify(req));

    return resp.object;
}

/**
 * Create return line items for return case
 * @param {string|dw.order.Order} order - Input order
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 * @param {boolean} existingReturnCase - Is Existing return case
 * @param {boolean} isReturnApprovalRequired - Is Return Approval required
 * @returns {boolean} - Successful creation
 */
function createReturnLineItemsForReturnCaseWithoutLabel(order, items, returnDetails, existingReturnCase, isReturnApprovalRequired) {
    var dateNow = new Date();
    var returnLineItemIds = [];
    var returnLineItems = [];
    var returnLineItem;
    var returnLineItemNumber = existingReturnCase.custom.returnLineItems && existingReturnCase.custom.returnLineItems.length > 0 ? existingReturnCase.custom.returnLineItems.split(',') : [];
    var returnCreated = true;
    if (returnLineItemNumber[0] && returnLineItemNumber[0].length > 0) {
        returnLineItemNumber = parseInt(returnLineItemNumber.length, 10);
    } else {
        returnLineItemNumber = 0;
    }
    try {
        Transaction.wrap(function () {
            var products = {};
            items.forEach(function (item) {
                returnLineItemNumber++;
                returnLineItem = CustomObjectMgr.createCustomObject('zenkraftReturnLineItem', existingReturnCase.custom.id + '-' + returnLineItemNumber);
                returnLineItem.custom.productID = item.productId.toString();
                returnLineItem.custom.returnID = existingReturnCase.custom.id;
                returnLineItem.custom.reasonCode = JSON.stringify(item.reason);
                returnLineItem.custom.reasonPhotoUrl = item.reason.reasonPhotoFilePath;
                returnLineItem.custom.subReasonCode = JSON.stringify(item.subReason);
                returnLineItem.custom.quantity = parseInt(item.quantity, 10);
                if (!isReturnApprovalRequired) {
                    products[item.productId] = item.quantity;
                    returnLineItem.custom.pliUUID = item.UUID;
                }
                if (!isReturnApprovalRequired && (!returnLineItem.custom.approvedDate || returnLineItem.custom.approvedDate === null)) {
                    returnLineItem.custom.approvedDate = dateNow;
                }
                returnLineItemIds.push(returnLineItem.custom.id);
                returnLineItems.push(returnLineItem);
            });
        });
        updateReturnCaselineItemIds(existingReturnCase, returnLineItemIds);
    } catch (error) {
        logger.error('Error while updating ' + error.message + error.stack);
        return error;
    }
    return returnCreated ? returnLineItems : null;
}

/**
 * Create return line items for return case
 * @param {string|dw.order.Order} order - Input order
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 * @param {boolean} existingReturnCase - Is Existing return case
 * @param {boolean} isReturnApprovalRequired - Is return approval required
 * @returns {boolean} - Successful creation
 */
function createReturnLineItemsForReturnCase(order, items, returnDetails, existingReturnCase, isReturnApprovalRequired) {
    var dateNow = new Date();
    var thisOrder = getOrder(order);
    var returnLineItemIds = [];
    var returnLineItems = [];
    var labels = [];
    var labelType;
    var returnLineItem;
    var returnLineItemNumber = existingReturnCase.custom.returnLineItems && existingReturnCase.custom.returnLineItems.length > 0 ? existingReturnCase.custom.returnLineItems.split(',') : [];
    var returnCreated = true;
    if (returnLineItemNumber[0] && returnLineItemNumber[0].length > 0) {
        returnLineItemNumber = parseInt(returnLineItemNumber.length, 10);
    } else {
        returnLineItemNumber = 0;
    }
    var singleShipingForMultipleItems = Site.getCurrent().getCustomPreferenceValue('zenkraftSingleShipmentForMultipleReturnLineItems');
    try {
        Transaction.wrap(function () {
            var products = {};
            items.forEach(function (item) {
                if (!returnCreated) { return; }
                returnLineItemNumber++;
                returnLineItem = CustomObjectMgr.createCustomObject('zenkraftReturnLineItem', existingReturnCase.custom.id + '-' + returnLineItemNumber);
                returnLineItem.custom.productID = item.productId;
                returnLineItem.custom.returnID = existingReturnCase.custom.id;
                returnLineItem.custom.reasonCode = JSON.stringify({ id: returnDetails[item.itemId].reasonId });
                // reasonPhotoUrl holds the ID of the zenkraftReturnPhoto custom object
                var reasonPhoto = getReasonPhoto(returnDetails[item.itemId].reasonPhotoId, thisOrder.orderNo);
                returnLineItem.custom.reasonPhotoUrl = reasonPhoto ? reasonPhoto.custom.id : null;
                returnLineItem.custom.subReasonCode = JSON.stringify({ id: returnDetails[item.itemId].subReasonId });
                returnLineItem.custom.quantity = parseInt(returnDetails[item.itemId].quantity, 10);
                if (!isReturnApprovalRequired) {
                    var itemQuantity = parseInt(returnDetails[item.itemId].quantity, 10);
                    // All items: the single-label mode below ships them together
                    products[item.productId] = itemQuantity;
                    if (!singleShipingForMultipleItems) {
                        // One label per item: ship only this item, not the ones processed before it
                        var itemProducts = {};
                        itemProducts[item.productId] = itemQuantity;
                        var thisLabel = getShippingLabel(thisOrder, itemProducts);
                        if (thisLabel) {
                            returnLineItem.custom.label = thisLabel.shipment.packages ? thisLabel.shipment.packages[0].label : null;
                            returnLineItem.custom.returnShipmentID = thisLabel.shipment.id;
                            returnLineItem.custom.labelType = thisLabel.shipment.label_type || null;
                            returnLineItem.custom.carrier = thisLabel.shipment.carrier;
                            returnLineItem.custom.trackingNumber = thisLabel.shipment.tracking_number;
                            returnLineItem.custom.returnAddress = JSON.stringify(thisLabel.shipment.recipient);
                            labels.push(thisLabel.shipment.label);
                            labelType = thisLabel.shipment.label_type;

                            // update existingReturnCase with shipping document date - qr code
                            if (thisLabel.shipment.shipping_documents) {
                                var shippingDocuments = thisLabel.shipment.shipping_documents;
                                shippingDocuments.forEach(function (shippingDoc) {
                                    if (shippingDoc.description.indexOf('qr_code') > -1) {
                                        existingReturnCase.custom.qrCode = shippingDoc.document;
                                        existingReturnCase.custom.qrCodeType = shippingDoc.document_type;
                                    }
                                });
                            }
                        } else {
                            returnCreated = false;
                            return;
                        }
                    }
                    // The storefront sends the order product item's itemId, which is the product line item UUID
                    returnLineItem.custom.pliUUID = item.UUID;
                }
                if (!isReturnApprovalRequired && (!returnLineItem.custom.approvedDate || returnLineItem.custom.approvedDate === null)) {
                    returnLineItem.custom.approvedDate = dateNow;
                }
                returnLineItemIds.push(returnLineItem.custom.id);
                returnLineItems.push(returnLineItem);
            });
            if (singleShipingForMultipleItems && Object.keys(products).length > 0) {
                var thisLabel = getShippingLabel(thisOrder, products);
                if (!thisLabel) {
                    returnCreated = false;
                } else {
                    for (returnLineItemNumber = 0; returnLineItemNumber < returnLineItems.length; returnLineItemNumber++) {
                        returnLineItems[returnLineItemNumber].custom.label = thisLabel.shipment.packages ? thisLabel.shipment.packages[0].label : null;
                        returnLineItems[returnLineItemNumber].custom.labelType = thisLabel.shipment.label_type || null;
                        returnLineItems[returnLineItemNumber].custom.carrier = thisLabel.shipment.carrier;
                        returnLineItems[returnLineItemNumber].custom.trackingNumber = thisLabel.shipment.tracking_number;
                        returnLineItems[returnLineItemNumber].custom.returnAddress = JSON.stringify(thisLabel.shipment.recipient);
                        returnLineItems[returnLineItemNumber].custom.returnShipmentID = thisLabel.shipment.id;
                        labels.push(thisLabel.shipment.label);
                        labelType = thisLabel.shipment.label_type;
                    }
                    // update existingReturnCase with shipping document date - qr code
                    if (thisLabel.shipment.shipping_documents) {
                        var shippingDocuments = thisLabel.shipment.shipping_documents;
                        shippingDocuments.forEach(function (shippingDoc) {
                            if (shippingDoc.description.indexOf('qr_code') > -1) {
                                existingReturnCase.custom.qrCode = shippingDoc.document;
                                existingReturnCase.custom.qrCodeType = shippingDoc.document_type;
                            }
                        });
                    }
                }
            }
            if (!isReturnApprovalRequired) {
                // eslint-disable-next-line no-param-reassign
                existingReturnCase.custom.labelType = labelType;
            }
        });
        updateReturnCaselineItemIds(existingReturnCase, returnLineItemIds);
    } catch (error) {
        Logger.error('Error while updating ' + error.message + error.stack);
        return error;
    }
    return returnCreated ? returnLineItems : null;
}

/**
 * Create unapproved return case
 * @param {string|dw.order.Order} order - Input order
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 * @param {string} returnID - Return case ID
 * @param {boolean} restrictLabel - Is label restricted
 * @returns {string|boolean} - Return case ID or false
 */
function createUnapprovedReturnCase(order, items, returnDetails, returnID, restrictLabel) {
    var thisOrder = getOrder(order);
    var zenkraftReturn;
    var returnObject;
    try {
        Transaction.wrap(function () {
            zenkraftReturn = CustomObjectMgr.createCustomObject('zenkraftReturn', returnID);
            zenkraftReturn.custom.orderNumber = thisOrder.orderNo;
        });
        if (restrictLabel) {
            returnObject = createReturnLineItemsForReturnCaseWithoutLabel(thisOrder, items, returnDetails, zenkraftReturn, true);
        } else {
            returnObject = createReturnLineItemsForReturnCase(thisOrder, items, returnDetails, zenkraftReturn, true);
        }
    } catch (error) {
        Logger.error('Error while creating return case. ' + error.message + error.stack);
        return false;
    }
    return {
        returnID: returnID,
        returnLines: returnObject
    };
}

/**
 * Create approved return case
 * @param {string|dw.order.Order} order - Input order
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 * @param {string} returnID - Return case ID
 * @param {boolean} restrictLabel - Is label restricted
 * @returns {string|boolean} - Return case ID or false
 */
function createApprovedReturnCase(order, items, returnDetails, returnID, restrictLabel) {
    var thisOrder = getOrder(order);
    var zenkraftReturn;
    var returnObject;
    try {
        Transaction.wrap(function () {
            zenkraftReturn = CustomObjectMgr.createCustomObject('zenkraftReturn', returnID);
            zenkraftReturn.custom.orderNumber = thisOrder.orderNo;
        });
        if (restrictLabel) {
            returnObject = createReturnLineItemsForReturnCaseWithoutLabel(thisOrder, items, returnDetails, zenkraftReturn, false);
        } else {
            returnObject = createReturnLineItemsForReturnCase(thisOrder, items, returnDetails, zenkraftReturn, false);
        }
    } catch (error) {
        Logger.error('Error while creating return case. ' + error.message + error.stack);
        return false;
    }
    return {
        returnID: returnID,
        returnLines: returnObject
    };
}

/**
 * Create new return case
 * @param {string|dw.order.Order} order - Input order
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 * @param {boolean} isReturnApprovalRequired - Is approval required
 * @param {boolean} restrictLabel - Is label restricted
 * @returns {string} - Return case ID
 */
function createNewReturnCase(order, items, returnDetails, isReturnApprovalRequired, restrictLabel) {
    var thisOrder = getOrder(order);
    var date = new Date();
    var returnID = date.getTime().toString();
    if (isReturnApprovalRequired) {
        returnID = createUnapprovedReturnCase(thisOrder, items, returnDetails, returnID, restrictLabel);
    } else {
        returnID = createApprovedReturnCase(thisOrder, items, returnDetails, returnID, restrictLabel);
    }
    return returnID;
}

/**
 * Sets Combined Label custom attribute for existing return case
 * @param {Object} returnObject - Return object
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 */
function updateReturnCaseCombineLabel(returnObject, items, returnDetails) {
    // eslint-disable-next-line no-param-reassign
    var returnCaseObj = getReturnObject(returnObject.returnID);
    var returnCase = getReturnCase(returnObject.returnID);
    Transaction.wrap(function () {
        if (returnObject && returnCase && returnCase.returnLineItems) {
            returnCaseObj.custom.combinedLabel = getCombineLabel(returnCase, items, returnDetails).combinedLabel;
        }
    });
}

/**
 * Create return case
 * @param {string|dw.order.Order} order - Input order
 * @param {array} items - Array of items
 * @param {Object} returnDetails - Return details
 * @param {boolean} restrictLabel - Is label restricted
 * @returns {string} - Return case ID
 */
function createReturnCase(order, items, returnDetails, restrictLabel) {
    var isReturnApprovalRequired = checkOrderReturnApproval(order);
    var returnID = null;
    var creation;
    var result;
    var newReturnObjectPerReturn = Site.getCurrent().getCustomPreferenceValue('zenkraftNewReturnObjectPerReturn');
    var existingReturnCase = checkForExistingReturnCases(order);
    if (existingReturnCase.length && !newReturnObjectPerReturn) {
        if (restrictLabel) {
            creation = createReturnLineItemsForReturnCaseWithoutLabel(order, items, returnDetails, existingReturnCase[0], isReturnApprovalRequired, false);
        } else {
            creation = createReturnLineItemsForReturnCase(order, items, returnDetails, existingReturnCase[0], isReturnApprovalRequired, false);
        }

        if (creation) {
            returnID = existingReturnCase[0].custom.id;
        }
    } else {
        var newCase = createNewReturnCase(order, items, returnDetails, isReturnApprovalRequired, restrictLabel);
        returnID = newCase.returnID;
        creation = newCase.returnLines;
    }

    result = {
        returnID: returnID,
        returnLines: creation
    };
    if (!restrictLabel) {
        updateReturnCaseCombineLabel(result, items, returnDetails);
    }

    return result;
}

/**
* Filter categories
*
* @param {Product} product class
* @return {string} comma separated categories of product
*/
function getProductCategories(product) {
    var thisProduct = null;
    if (product.isCategorized()) {
        thisProduct = product;
    } else {
        thisProduct = product.getMasterProduct();
    }
    var categories = thisProduct.getAllCategories().toArray();
    var categoryIDs = [];
    categories.forEach(function (category) {
        categoryIDs.push(category.ID);
    });
    var uniqueCategories = categoryIDs.filter(function (value, index, self) {
        return self.indexOf(value) === index;
    });
    return uniqueCategories.join(', ');
}


/**
* Prepare return lines for Zenkraft Return Sync
* @param {dw.order.Order} order Order object
* @param {string} returnID return ID
* @param {boolean} returnsRequireApproval returns Require Approval
* @return {Array} objects
*/
function getReturnLines(order, returnID, returnsRequireApproval) {
    var orderLineItems = order.getProductLineItems().toArray();
    var returnLines = [];
    var zenkraftReturn = CustomObjectMgr.getCustomObject('zenkraftReturn', returnID);
    var zenkraftReturnLineItems = zenkraftReturn.custom.returnLineItems;
    if (!zenkraftReturnLineItems) {
        return returnLines;
    }
    zenkraftReturnLineItems = zenkraftReturnLineItems.split(',');
    for (var i = 0; i < zenkraftReturnLineItems.length; i++) {
        zenkraftReturnLineItems[i] = CustomObjectMgr.getCustomObject('zenkraftReturnLineItem', zenkraftReturnLineItems[i]);
    }
    orderLineItems.forEach(function (lineItem) {
        zenkraftReturnLineItems.forEach(function (zenkraftReturnLineItem) {
            if (lineItem.product.getID() === zenkraftReturnLineItem.custom.productID) {
                var product = lineItem.getProduct();
                if (!product) { return; }
                if (product.isVariant()) {
                    product = product.getMasterProduct();
                }
                var imageURL = product.getImage('medium') ? product.getImage('medium').getURL().abs().toString() : '';
                var reasonObject = JSON.parse(zenkraftReturnLineItem.custom.reasonCode);
                var subReasonObject = JSON.parse(zenkraftReturnLineItem.custom.subReasonCode);
                var attachments = [];
                var reasonPhoto = getReasonPhoto(zenkraftReturnLineItem.custom.reasonPhotoUrl, order.orderNo);
                if (reasonPhoto) {
                    attachments.push({
                        name: reasonPhoto.custom.fileName,
                        filetype: 'JPG',
                        // Stored as base64 already
                        file: reasonPhoto.custom.data,
                        type: 'upload'
                    });
                }

                returnLines.push({
                    shipment_id: zenkraftReturnLineItem.custom.returnShipmentID,
                    line_id: zenkraftReturnLineItem.custom.id,
                    quantity: parseInt(zenkraftReturnLineItem.custom.quantity, 10),
                    unit_price: lineItem.getPriceValue(),
                    currency: lineItem.getPrice().getCurrencyCode(),
                    reason: {
                        level1_code: reasonObject.id,
                        level1_text: reasonObject.id,
                        level2_code: subReasonObject.id,
                        level2_text: subReasonObject.id
                    },
                    product: {
                        product_id: product.getID(),
                        product_name: product.getName(),
                        product_category: getProductCategories(product),
                        description: product.getPageDescription(),
                        variant_id: product.getID(),
                        variant_name: product.getName(),
                        image_url: imageURL.indexOf('http') !== -1 ? imageURL : ''
                    },
                    approval_required: returnsRequireApproval,
                    attachments: attachments
                });
            }
        });
    });
    return returnLines;
}

/**
* Send request to Zenraft Return Sync service
*
* @param {Object} req Zenkraft sync object request
* @return {Object} resp Zenkraft sync object response
*/
function sendSyncReturnWithZenkraft(req) {
    var resp = {};

    resp = zenkraftService.call(zenkraftService.API_PATHS.RETURN, JSON.stringify(req));
    if (!empty(resp.object) && empty(resp.object.error)) {
        return resp;
    }

    logger.error('Zenkraft Error: Response: ');
    return null;
}

/**
* Prepare Zenraft Return Sync request
* @param {dw.order.Order} order - Order object
* @param {string} returnID - Return ID
* @param {boolean} returnsRequireApproval - Does return require approval
* @return {void}
*/
function getSyncReturnRequest(order, returnID, returnsRequireApproval) {
    var sender = order.getShipments().toArray()[0].getShippingAddress();
    var zenkraftSender = {
        city: sender.city ? sender.city : '',
        company: sender.companyName ? sender.companyName : '',
        country: sender.countryCode.value,
        email: order.getCustomerEmail(),
        name: sender.fullName ? sender.fullName : '',
        phone: getCustomerPhone(order),
        postal_code: sender.postalCode ? sender.postalCode : '',
        state: sender.stateCode ? sender.stateCode : '',
        street1: sender.address1 ? sender.address1 : '',
        street2: sender.address2 ? sender.address2 : ''
    };
    var iszenkraftAdvancedJSONOn = Site.getCurrent().getCustomPreferenceValue('zenkraftAdvancedJSON');
    var isSetUp = (iszenkraftAdvancedJSONOn);
    var advJsonSpec = {
        IS_DEBUG: Site.getCurrent().getCustomPreferenceValue('zenkraftDebugLog')
    };
    var advJson;
    if (isSetUp) {
        try {
            advJson = JSON.parse(Site.getCurrent().getCustomPreferenceValue('zenkraftAdvancedJSONObject'));
            advJsonSpec = advJson.RETURN[sender.countryCode.value.toUpperCase()] || advJsonSpec;
        } catch (e) {
            logger.error('Invalid Zenkraft Advanced JSON object');
            return {};
        }
    }
    var recipient = {
        email: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.EMAIL : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientEmail'),
        name: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.NAME : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientName'),
        company: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.COMPANY : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientCompany'),
        street1: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.STREET : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientStreet'),
        city: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.CITY : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientCity'),
        state: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.STATECODE : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientStateCode'),
        // eslint-disable-next-line max-len
        postal_code: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.POSTALCODE.replace(/\s+/g, '') : (Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientPostalCode') || '').replace(/\s+/g, ''),
        country: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.COUNTRYCODE : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientCountryCode'),
        phone: Object.prototype.hasOwnProperty.call(advJsonSpec, 'ADDRESS') ? advJsonSpec.ADDRESS.PHONE : Site.getCurrent().getCustomPreferenceValue('zenkraftRecipientPhone')
    };
    var req = {
        return: {
            return_id: returnID,
            order: {
                order_id: order.getOrderNo()
            },
            customer: {
                customer_id: order.getCustomerNo() ? order.getCustomerNo() : order.getCustomer().getID()
            },
            return_lines: getReturnLines(order, returnID, returnsRequireApproval),
            return_from: zenkraftSender,
            return_to: recipient,
            debug: advJsonSpec.IS_DEBUG || false
        }
    };
    return sendSyncReturnWithZenkraft(req);
}

/**
 * Get return case object
 * @param {string} returnCase - Return case id
 * @returns {Object} - Return case object
 */
function getReturnCase(returnCase) {
    try {
        var thisReturnCase = getReturnObject(returnCase);
        var returnObject = extractObject(thisReturnCase);
        var totalItems = 0;
        var currentReturnLineItems = [];
        // eslint-disable-next-line no-undef
        if (!empty(returnObject) && returnObject.returnLineItems && returnObject.returnLineItems.length > 0) {
            var returnLineItems = getReturnLineItems(returnObject.returnLineItems);
            if (returnLineItems.length > 0) {
                for (var i = 0; i < returnLineItems.length; i++) {
                    returnLineItems[i] = extractObject(returnLineItems[i]);
                    returnLineItems[i].product = getProductDetails(returnLineItems[i].productID);
                    // A line item saved before quantity became an int attribute may have none
                    returnLineItems[i].quantity = parseInt(returnLineItems[i].quantity, 10) || 0;
                    totalItems += returnLineItems[i].quantity;
                    currentReturnLineItems.push(returnLineItems[i].id);
                }
                returnObject.returnLineItems = returnLineItems;
            }
        }

        returnObject.totalItems = totalItems;
        return returnObject;
    } catch (e) {
        logger.error('Cannot read return case: {0}', e.message);
        return null;
    }
}

/**
 * Get address hashes from return lines
 * @param {Array} returnLines - Array of return lines
 * @returns {Object} - Address hashes
 */
function getAddressHashes(returnLines) {
    var addressHashes = {};

    var newReturnLines = returnLines.map(function (item) {
        var product = ProductMgr.getProduct(item.custom.productID);
        var productImage = product && product.getImage('medium') ? product.getImage('medium').getURL().abs().toString() : '';

        return {
            returnID: item.custom.returnID,
            productID: item.custom.productID,
            productName: product ? product.name : item.custom.productID,
            productImage: productImage,
            quantity: item.custom.quantity,
            reasonCode: item.custom.reasonCode,
            subReasonCode: item.custom.subReasonCode,
            trackingNumber: item.custom.trackingNumber,
            label: item.custom.label,
            labelType: item.custom.labelType,
            address: item.custom.returnAddress,
            addressHash: StringUtils.encodeBase64(JSON.stringify(item.custom.returnAddress), 'UTF-8'),
            creationDate: item.creationDate
        };
    });
    newReturnLines.forEach(function (returnLine) {
        if (!Object.hasOwnProperty.call(addressHashes, returnLine.addressHash)) {
            addressHashes[returnLine.addressHash] = [returnLine];
        } else {
            var values = addressHashes[returnLine.addressHash];
            values.push(returnLine);
            addressHashes[returnLine.addressHash] = values;
        }
    });

    return addressHashes;
}

/**
 * Get combined label
 * @param {Object} returnObject - Return case object
 * @param {array} items - List of items
 * @param {Object} returnDetails - Return details
 * @returns {Object} - Updated object
 **/
function getCombineLabel(returnObject, items, returnDetails) {
    var date = new Date();
    var dateInMiliseconds = date.getTime();
    var fileType;
    var combinedLabel = [];
    returnObject.returnLineItems.forEach(function (returnLineItem) {
        var reasonCode = returnLineItem.reasonCode ? JSON.parse(returnLineItem.reasonCode) : null;
        var subReasonCode = returnLineItem.subReasonCode ? JSON.parse(returnLineItem.subReasonCode) : null;
        items.forEach(function (item) {
            if (returnLineItem.productID === String(item.productId) &&
                returnDetails[item.itemId] &&
                reasonCode && subReasonCode &&
                parseInt(returnLineItem.quantity, 10) === parseInt(returnDetails[item.itemId].quantity, 10) &&
                reasonCode.id === returnDetails[item.itemId].reasonId &&
                subReasonCode.id === returnDetails[item.itemId].subReasonId
                && returnLineItem.creationDate.getTime() + 90000 > dateInMiliseconds
            ) {
                fileType = returnLineItem.labelType;
                var filterCombinedLabel = combinedLabel.filter(function (e) {
                    return e === returnLineItem.label;
                });
                if (!filterCombinedLabel.length) {
                    combinedLabel.push(returnLineItem.label);
                }
            }
        });
    });
    if (combinedLabel.length === 1) {
        returnObject.combinedLabel = combinedLabel[0];
        returnObject.labelType = fileType;
        return returnObject;
    }
    var serviceResponse = zenkraftService.call(zenkraftService.API_PATHS.LABEL, JSON.stringify({
        file_type: fileType,
        files: combinedLabel,
        debug: Site.getCurrent().getCustomPreferenceValue('zenkraftDebugLog')
    }));

    if (serviceResponse.object) {
        if (!serviceResponse.object.error) {
            returnObject.combinedLabel = serviceResponse.object.pdf;
            returnObject.labelType = 'pdf';
            return returnObject;
        }
    }
    returnObject.combinedLabel = combinedLabel[0];
    returnObject.labelType = fileType;
    return returnObject;
}

/**
 * Create return case in zkapi
 * @param {string} returnMethodId - return method id
 * @returns {string} - Label
 */
function createZKReturnCase(returnMethodId) {
    var req = {
        return_methods: [returnMethodId]
    };
    var resp = zenkraftService.call(zenkraftService.API_PATHS.RETURNS, JSON.stringify(req), 'POST', 'create');
    var result = resp.ok ? resp.object[0] : null;
    return result;
}

/**
 * Get return details from ZKAPI service
 * @param {string} returnId - ID of existing return in ZKAPI
 * @returns {Object} - return details object
 */
function getZKReturnDetails(returnId) {
    var returnCaseDetails = zenkraftService.call(zenkraftService.API_PATHS.RETURNS, JSON.stringify({
        id: returnId
    }), 'GET', 'details');
    return returnCaseDetails.ok ? returnCaseDetails.object : null;
}

// Reason photos live in zenkraftReturnPhoto custom objects, which delete them after 90 days. They can't be files:
// SCAPI requests may not write files (the dw.io.FileWriter quotas are 0) and processMultipart rejects them
// (scapi-wrong-content-type), so the SFRA way of storing an upload doesn't work here.
var REASON_PHOTO_TYPE = 'zenkraftReturnPhoto';
var REASON_PHOTO_ID_PATTERN = /^[A-Za-z0-9]{10,64}$/;
var DEFAULT_REASON_PHOTO_FORMATS = ['jpg', 'jpeg', 'png'];
// A text attribute holds at most 200,000 characters (api.object.stringAttributeLength)
var REASON_PHOTO_MAX_BASE64_LENGTH = 200000;

/**
 * Get a reason photo saved by saveReasonPhoto for an order.
 * Only IDs in the format saveReasonPhoto creates are looked up, and only a photo uploaded for that order is returned.
 * @param {string} photoId - Photo ID, as sent by the storefront or stored on a return line item
 * @param {string} orderNo - Number of the order being returned
 * @returns {dw.object.CustomObject|null} - zenkraftReturnPhoto custom object, or null
 */
function getReasonPhoto(photoId, orderNo) {
    if (typeof photoId !== 'string' || !REASON_PHOTO_ID_PATTERN.test(photoId)) {
        return null;
    }
    var photo = CustomObjectMgr.getCustomObject(REASON_PHOTO_TYPE, photoId);
    return photo && photo.custom.orderNumber === orderNo ? photo : null;
}

/**
 * Save a return reason photo sent by the storefront as base64 JPEG (the storefront converts every photo to JPEG
 * and compresses it to fit one text attribute) in a zenkraftReturnPhoto custom object.
 * @param {dw.order.Order} order - Order the photo is for, already checked to be the shopper's
 * @param {Object} photo - { fileName: string, data: string } where fileName is the name the shopper picked and data is
 *   base64 JPEG, optionally as a data URL
 * @returns {Object} - { success, photoId, serverErrors }
 */
function saveReasonPhoto(order, photo) {
    var response = {
        success: false,
        photoId: null,
        serverErrors: Resource.msg('error.upload.reasonphoto.invalid.file', 'zenkraft', null)
    };
    var fileName = photo && typeof photo.fileName === 'string' ? photo.fileName.split(/[\\/]/).pop() : '';
    var data = photo && typeof photo.data === 'string' ? photo.data.replace(/^data:[^,]*,/, '').replace(/\s/g, '') : '';
    var fileType = fileName.indexOf('.') > -1 ? fileName.split('.').pop().toLowerCase() : '';
    // '/9j/' is how every JPEG (bytes FF D8 FF) starts in base64
    if (!data || data.indexOf('/9j/') !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data) || !/^[a-z0-9]+$/.test(fileType)) {
        return response;
    }

    // The configured formats are the ones the shopper may pick, so they are checked against the picked file's name
    var configuredFormats = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnReasonPhotoFormats');
    var allowedFormats = [];
    for (var i = 0; configuredFormats && i < configuredFormats.length; i++) {
        allowedFormats.push(String(configuredFormats[i]).toLowerCase());
    }
    if (!allowedFormats.length) {
        allowedFormats = DEFAULT_REASON_PHOTO_FORMATS;
    }
    if (allowedFormats.indexOf(fileType) === -1) {
        response.serverErrors = Resource.msgf('error.upload.reasonphoto.fileformat', 'zenkraft', null, allowedFormats.join(', '));
        return response;
    }

    var fileSizeLimit = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnReasonPhotoMaxSize'); // KB
    var maxStoredKB = Math.floor(((REASON_PHOTO_MAX_BASE64_LENGTH * 3) / 4) / 1024);
    var limitKB = fileSizeLimit ? Math.min(fileSizeLimit, maxStoredKB) : maxStoredKB;
    var padding = data.charAt(data.length - 2) === '=' ? 2 : (data.charAt(data.length - 1) === '=' ? 1 : 0);
    var fileSizeKB = ((data.length * 3) / 4 - padding) / 1024;
    if (data.length > REASON_PHOTO_MAX_BASE64_LENGTH || fileSizeKB > limitKB) {
        response.serverErrors = Resource.msgf('error.upload.reasonphoto.filesize', 'zenkraft', null, limitKB / 1024);
        return response;
    }

    var photoId = UUIDUtils.createUUID().replace(/[^A-Za-z0-9]/g, '');
    Transaction.wrap(function () {
        var reasonPhoto = CustomObjectMgr.createCustomObject(REASON_PHOTO_TYPE, photoId);
        reasonPhoto.custom.orderNumber = order.orderNo;
        // Stored as JPEG whatever the picked format was
        reasonPhoto.custom.fileName = fileName.slice(0, fileName.lastIndexOf('.')).slice(0, 200) + '.jpg';
        reasonPhoto.custom.data = data;
    });

    response.success = true;
    response.photoId = photoId;
    response.serverErrors = [];
    return response;
}

/**
 * Get return items price
 * @param {array} items - List of items
 * @returns {array} items - List of items - Return sum of items price
 */
function getReturnItemsPrice(items) {
    var returnItemPrice = 0;
    items.forEach(function (item) {
        returnItemPrice += item.productPrice * item.quantity;
    });

    return returnItemPrice;
}

exports.checkOrderDaysAvailableForReturn = checkOrderDaysAvailableForReturn;
exports.getReasonPhotoLimits = getReasonPhotoLimits;
exports.checkOrderReturnApproval = checkOrderReturnApproval;
exports.getZKReturnCases = getZKReturnCases;
exports.getCustomerReturns = getCustomerReturns;
exports.getValidatedReturnItems = getValidatedReturnItems;
exports.isProductReturnable = isProductReturnable;
exports.getZenkraftReturnMethods = getZenkraftReturnMethods;
exports.checkForMissingImportantData = checkForMissingImportantData;
exports.updateMissingData = updateMissingData;
exports.checkForExistingReturnCases = checkForExistingReturnCases;
exports.createReturnCase = createReturnCase;
exports.getSyncReturnRequest = getSyncReturnRequest;
exports.getReturnCase = getReturnCase;
exports.getAddressHashes = getAddressHashes;
exports.getCombineLabel = getCombineLabel;
exports.createZKReturnCase = createZKReturnCase;
exports.getZKReturnDetails = getZKReturnDetails;
exports.saveReasonPhoto = saveReasonPhoto;
