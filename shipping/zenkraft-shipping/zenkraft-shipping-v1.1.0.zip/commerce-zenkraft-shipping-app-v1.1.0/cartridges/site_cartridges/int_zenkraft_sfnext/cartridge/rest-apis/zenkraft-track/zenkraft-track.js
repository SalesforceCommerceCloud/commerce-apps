'use strict';

var Logger = require('dw/system/Logger');
var RESTResponseMgr = require('dw/system/RESTResponseMgr');
var trackingHelper = require('*/cartridge/scripts/helpers/zenkraftTrackingHelper.js');

/**
 * SCAPI custom endpoint — returns Zenkraft tracking data for a given shipment.
 * @returns {void}
 */
exports.getZenkraftTracking = function () {
    try {
        var params = request.getHttpParameterMap();

        var trackingNumber = params.get('c_trackingNumber').getStringValue();
        var carrier = params.get('c_carrier').getStringValue();
        var order = params.get('c_order').getStringValue();
        var orderDetailsPage = params.get('c_orderDetailsPage').getBooleanValue();

        if (!orderDetailsPage && (!trackingNumber || !carrier)) {
            // The second argument is the RFC 9457 problem type, which must be a URI; the title is the message
            return RESTResponseMgr.createError(400, 'missing-parameters', 'c_trackingNumber and c_carrier are required').render();
        }

        var payload = trackingHelper.getZenkraftTrackingData(trackingNumber, carrier, order, orderDetailsPage);

        return RESTResponseMgr.createSuccess(payload).render();
    } catch (e) {
        Logger.getLogger('zenkraft', 'zenkraftTracking').error('Unhandled error in getZenkraftTracking: {0}', e.message);
        return RESTResponseMgr.createError(500, 'internal-server-error', 'Internal server error').render();
    }
};

exports.getZenkraftTracking.public = true;
