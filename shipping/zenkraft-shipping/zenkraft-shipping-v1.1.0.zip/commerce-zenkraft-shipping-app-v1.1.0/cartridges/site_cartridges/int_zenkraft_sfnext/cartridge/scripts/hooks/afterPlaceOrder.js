'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');

var logger = Logger.getLogger('zenkraft', 'afterPlaceOrder');

/**
 * Hook handler for dw.ocapi.shop.order.afterPOST.
 *
 * Clears Zenkraft estimate cache attributes — they served the basket phase and are
 * not needed on the persisted order. The collection-point address for drop-off
 * shipments is stamped before the order is created, in beforePlaceOrder.js.
 *
 * @param {dw.order.Order} order - The placed order
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.afterPOST = function (order) {
    try {
        var shipmentsIt = order.getShipments().iterator();
        while (shipmentsIt.hasNext()) {
            var shipment = shipmentsIt.next();

            Transaction.wrap(function () {
                shipment.custom.zenkraftEstimateKey = null;
                shipment.custom.zenkraftEstimateSnapshot = null;
            });
        }
    } catch (e) {
        logger.error('Zenkraft afterPlaceOrder: {0}', e.message);
    }

    return new Status(Status.OK);
};
