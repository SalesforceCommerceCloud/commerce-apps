'use strict';

var Logger = require('dw/system/Logger');
var Order = require('dw/order/Order');
var OrderMgr = require('dw/order/OrderMgr');
var Resource = require('dw/web/Resource');
var RESTResponseMgr = require('dw/system/RESTResponseMgr');
var Site = require('dw/system/Site');

var zenkraftReturnHelper = require('*/cartridge/scripts/helpers/zenkraftReturnHelper.js');

var logger = Logger.getLogger('zenkraft', 'zenkraftReturns');

/**
 * Looks up an order and returns it only if it belongs to the shopper making the request.
 * Mirrors the rule shopperOrders.getOrder applies, so a shopper token cannot act on someone
 * else's order by passing its number. An order the shopper doesn't own is treated as not found.
 * When the merchant requires login for returns (zenkraftReturnsRequireLogin), a guest gets no order either.
 * @param {string} orderNo - Order number from the request
 * @returns {dw.order.Order|null} The order, or null if it doesn't exist or isn't the shopper's
 */
function getOwnedOrder(orderNo) {
    var order = orderNo ? OrderMgr.getOrder(orderNo) : null;
    var customer = request.session.customer;
    if (!order || !customer) {
        return null;
    }

    // With SLAS, a request only has a registered customer once the shopper has logged in; guest tokens never do
    if (Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsRequireLogin') && !customer.registered) {
        logger.warn('Order {0} was requested by a guest, but returns require login', orderNo);
        return null;
    }

    var orderCustomer = order.getCustomer();
    var isSameCustomer = !!orderCustomer && orderCustomer.getID() === customer.getID();
    var isSameCustomerNo = !empty(order.customerNo) && !!customer.profile && order.customerNo === customer.profile.customerNo;
    if (!isSameCustomer && !isSameCustomerNo) {
        logger.warn('Order {0} was requested by a shopper who does not own it', orderNo);
        return null;
    }
    return order;
}

/**
 * Wraps an endpoint so an unexpected error is logged and answered with a 500, instead of escaping to SCAPI unlogged.
 * @param {string} name - Endpoint name for the log
 * @param {Function} endpoint - Endpoint implementation
 * @returns {Function} The wrapped endpoint
 */
function handleErrors(name, endpoint) {
    return function () {
        try {
            return endpoint();
        } catch (e) {
            logger.error('Unhandled error in {0}: {1}\n{2}', name, e.message, e.stack);
            // The second argument is the RFC 9457 problem type, which must be a URI; the title is the message
            return RESTResponseMgr.createError(500, 'internal-server-error', 'Internal server error').render();
        }
    };
}

/**
 * This SCAPI CUSTOM API endpoint is used to get required data for returns page
 * @returns {void}
 */
exports.returns = handleErrors('returns', function () {
    var orderNo = request
    .getHttpParameterMap()
    .get('c_orderNo')
    .getStringValue();
    var requireLogin = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsRequireLogin');
    var reasonPhotoLimits = zenkraftReturnHelper.getReasonPhotoLimits();

    var order = getOwnedOrder(orderNo);
    var payload = {};

    if (empty(order)) {
        payload.error = 'No order found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    payload.availableForReturn = zenkraftReturnHelper.checkOrderDaysAvailableForReturn(order.creationDate);

    if (payload.availableForReturn) {
        var returnsHandler = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsHandler');
        payload.requireLogin = requireLogin;
        payload.returnsRequireApproval = zenkraftReturnHelper.checkOrderReturnApproval(order);
        payload.reasonPhotoLimits = reasonPhotoLimits;
        payload.zenkraftReturnsHandler = returnsHandler ? returnsHandler.value : null;
    }

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.returns.public = true;

// Every order's return cases and products are read per request, so the history covers the most recent orders only
// to stay within the 10s shopper custom API limit
var RETURN_HISTORY_ORDER_LIMIT = 50;

/**
 * Gets the numbers of the customer's most recent orders, newest first. Orders that were never placed are left out.
 * @param {string} customerNo - Customer number
 * @returns {Array} - Up to RETURN_HISTORY_ORDER_LIMIT order numbers
 */
function getRecentOrderNumbers(customerNo) {
    var orders = OrderMgr.searchOrders('customerNo = {0} AND status != {1} AND status != {2}', 'creationDate desc',
        customerNo, Order.ORDER_STATUS_CREATED, Order.ORDER_STATUS_FAILED);
    var orderNumbers = [];
    try {
        while (orders.hasNext() && orderNumbers.length < RETURN_HISTORY_ORDER_LIMIT) {
            orderNumbers.push(orders.next().orderNo);
        }
    } finally {
        orders.close();
    }
    return orderNumbers;
}

/**
 * Converts a date for the response to an ISO string, the format the order_for_return hook sends return dates in
 * @param {Date|string} value - Date value
 * @returns {string|null} - ISO date string, or the value unchanged if it is already a string
 */
function toResponseDate(value) {
    return value && typeof value.toISOString === 'function' ? value.toISOString() : (value || null);
}

/**
 * Reads a return case for the returnsHistory response: plain values, dates as ISO strings and the order it belongs to.
 * Labels are left out (~175K characters each); the storefront links each return to its order, whose page has them.
 * @param {Object} returnCase - Return case from zenkraftReturnHelper.getCustomerReturns
 * @returns {Object} - Return case for the response
 */
function readReturnCaseForHistory(returnCase) {
    return {
        id: returnCase.id,
        orderNumber: returnCase.orderNumber,
        zkReturnCase: returnCase.zkReturnCase === true,
        returnLineItems: returnCase.returnLineItems.map(function (lineItem) {
            return {
                returnID: lineItem.returnID || returnCase.id,
                productID: lineItem.productID,
                product: lineItem.product || null,
                quantity: lineItem.quantity,
                trackingStage: lineItem.trackingStage || null,
                creationDate: toResponseDate(lineItem.creationDate),
                approvedDate: toResponseDate(lineItem.approvedDate)
            };
        })
    };
}

/**
 * This SCAPI CUSTOM API endpoint is used to get returns details for current customer
 * @returns {void}
 */
exports.returnsHistory = handleErrors('returnsHistory', function () {
    var payload = {};
    var customer = request.session.customer;

    if (!customer || !customer.profile || !customer.profile.customerNo) {
        payload.error = 'No customer session found.';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var customerNo = customer.profile.customerNo;
    var returns = zenkraftReturnHelper.getCustomerReturns(customerNo, getRecentOrderNumbers(customerNo));

    payload.returns = returns
        // Remove empty returns
        .filter(function (returnCase) {
            return returnCase.returnLineItems && returnCase.returnLineItems.length > 0;
        })
        .map(readReturnCaseForHistory);

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.returnsHistory.public = true;

/**
 * This SCAPI CUSTOM API endpoint is used to get applicable return methods for zkapi
 * @returns {void}
 */
exports.getReturnMethods = handleErrors('getReturnMethods', function () {
    var requestBody = request
        .getHttpParameterMap().requestBodyAsString;

    var data;
    var payload = {};
    try {
        data = JSON.parse(requestBody);
    } catch (e) {
        logger.error('Can not parse getReturnMethods requestBody');
    }

    if (empty(data) || empty(data.orderId) || empty(data.items)) {
        payload.error = 'Missing data for getting the return methods';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var order = getOwnedOrder(data.orderId);

    if (empty(order)) {
        payload.error = 'No order found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    if (!zenkraftReturnHelper.checkOrderDaysAvailableForReturn(order.creationDate)) {
        payload.error = 'Order is no longer available for return';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var returnItems =zenkraftReturnHelper.getValidatedReturnItems(order, data.items, data.returnDetails);

    if (!returnItems) {
        payload.error = 'Invalid return items';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    payload = zenkraftReturnHelper.getZenkraftReturnMethods(order, returnItems.items, returnItems.returnDetails);

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.getReturnMethods.public = true;

/**
 * This SCAPI CUSTOM API endpoint is used to get shipping label for sfcc return cases
 * @returns {void}
 */
exports.getShippingLabel = handleErrors('getShippingLabel', function () {
    var syncReturnWithZenkraft = Site.getCurrent().getCustomPreferenceValue('syncReturnWithZenkraft');
    var requestBody = request
    .getHttpParameterMap().requestBodyAsString;

    var payload = {};

    var data;
    try {
        data = JSON.parse(requestBody);
    } catch (e) {
        logger.error('Can not parse getShippingLabel requestBody');
    }

    if (empty(data) || empty(data.orderId) || empty(data.items)) {
        payload.error = 'Missing data for getting the shipping label';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var order = getOwnedOrder(data.orderId);

    if (empty(order)) {
        payload.error = 'No order found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    if (!zenkraftReturnHelper.checkOrderDaysAvailableForReturn(order.creationDate)) {
        payload.error = 'Order is no longer available for return';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var returnItems =zenkraftReturnHelper.getValidatedReturnItems(order, data.items, data.returnDetails);

    if (!returnItems) {
        payload.error = 'Invalid return items';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var returnsRequireApproval = zenkraftReturnHelper.checkOrderReturnApproval(order);

    // { returnID, returnLines }; returnLines is not an array when creating the line items failed
    var createdReturn = zenkraftReturnHelper.createReturnCase(order, returnItems.items, returnItems.returnDetails, false);

    if (!createdReturn || !Array.isArray(createdReturn.returnLines)) {
        payload.error = true;
        payload.errorMessage = Resource.msg('error.msg.return.label', 'zenkraft', null);
        return RESTResponseMgr.createSuccess(payload).render();
    }

    if (syncReturnWithZenkraft) {
        // send zenkraft return sync
        zenkraftReturnHelper.getSyncReturnRequest(order, createdReturn.returnID, returnsRequireApproval);
    }
    var returnObject = zenkraftReturnHelper.getReturnCase(createdReturn.returnID);
    if (!returnObject) {
        payload.error = true;
        payload.errorMessage = Resource.msg('error.msg.return.label', 'zenkraft', null);
        return RESTResponseMgr.createSuccess(payload).render();
    }
    if (returnsRequireApproval) {
        payload.returnsRequireApproval = returnsRequireApproval;
        payload.returnObject = returnObject;
        return RESTResponseMgr.createSuccess(payload).render();
    }
    // The storefront downloads returnObject.combinedLabel (already merged by createReturnCase). The line items
    // carry their own copy of each label, and shopper custom APIs time out after 10s, so nothing else is
    // added here: no per-address label groups and no second /merge call.
    delete returnObject.returnLineItems;
    payload.returnObject = returnObject;
    return RESTResponseMgr.createSuccess(payload).render();
});

exports.getShippingLabel.public = true;

/**
 * This SCAPI CUSTOM API endpoint is used to get label for zkapi return cases
 * @returns {void}
 */
exports.getZenkraftReturnLabel = handleErrors('getZenkraftReturnLabel', function () {
    var params = request.getHttpParameterMap();
    var returnMethodId = params.get('c_returnMethodId').getStringValue();
    var orderNo = params.get('c_orderNo').getStringValue();

    var payload = {};

    var order = getOwnedOrder(orderNo);

    if (empty(order)) {
        payload.error = 'No order found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    if (!zenkraftReturnHelper.checkOrderDaysAvailableForReturn(order.creationDate)) {
        payload.error = 'Order is no longer available for return';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var result = zenkraftReturnHelper.createZKReturnCase(returnMethodId);

    if (!result) {
        payload.error = true;
        payload.errorMessage = Resource.msg('error.msg.return.zkapi.label', 'zenkraft', null);
        return RESTResponseMgr.createSuccess(payload).render();
    }

    // Zenkraft can't check a return method before confirming it, so check the confirmed return instead: getReturnMethods
    // sets the order number as its reference, so a method drafted for another order must not hand over that order's label
    if (!result.shipment || result.shipment.reference_number !== order.orderNo) {
        logger.warn('Return method {0} confirmed a return that does not belong to order {1}', returnMethodId, order.orderNo);
        payload.error = true;
        payload.errorMessage = Resource.msg('error.msg.return.label', 'zenkraft', null);
        return RESTResponseMgr.createSuccess(payload).render();
    }
    payload.labelData = result;

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.getZenkraftReturnLabel.public = true;

/**
 * This SCAPI CUSTOM API endpoint is used to get combined label
 * @returns {void}
 */
exports.getCombinedLabel = handleErrors('getCombinedLabel', function () {
    var returnId = request
    .getHttpParameterMap()
    .get('c_returnCaseId')
    .getStringValue();

    var payload = {};
    var returnDetails = returnId ? zenkraftReturnHelper.getZKReturnDetails(returnId) : null;

    // A Zenkraft return's reference number is its order number; only that order's shopper may download the label
    if (!returnDetails || !returnDetails.shipment || !getOwnedOrder(returnDetails.shipment.reference_number)) {
        logger.info('No return details found');
        payload.error = 'No return details found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    payload.label = returnDetails.shipment.label;

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.getCombinedLabel.public = true;

/**
 * This SCAPI CUSTOM API endpoint is used to update order missing data
 * @returns {void}
 */
exports.updateMissingData = handleErrors('updateMissingData', function () {
    var Transaction = require('dw/system/Transaction');
    var requestBody = request
        .getHttpParameterMap().requestBodyAsString;

    var data;
    var payload = {};
    var updatedMissingData = {};

    try {
        data = JSON.parse(requestBody);
    } catch (e) {
        logger.error('Can not parse updateMissingData requestBody');
    }

    if (empty(data) || empty(data.orderId) || empty(data.missingData) || typeof data.missingData !== 'object') {
        payload.error = 'Missing data for updating order';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var order = getOwnedOrder(data.orderId);

    if (empty(order)) {
        payload.error = 'No order found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    // Writes each value to the attribute zenkraftReturnRequiredFields maps its field to
    Transaction.wrap(function () {
        zenkraftReturnHelper.updateMissingData(order, data.missingData);
    });

    updatedMissingData = zenkraftReturnHelper.checkForMissingImportantData(order);

    payload.missingData = updatedMissingData;
    payload.status = 'Success';

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.updateMissingData.public = true;

/**
 * This SCAPI CUSTOM API endpoint is used to upload return reason image
 * @returns {void}
 */
exports.uploadReasonImage = handleErrors('uploadReasonImage', function () {
    var payload = {
        success: false,
        msg: null,
        photoId: null
    };

    var requestBody = request
        .getHttpParameterMap().requestBodyAsString;

    var data;
    try {
        data = JSON.parse(requestBody);
    } catch (e) {
        logger.error('Can not parse uploadReasonImage requestBody');
    }

    if (empty(data) || empty(data.orderId) || empty(data.fileName) || empty(data.data)) {
        payload.msg = 'Missing data for uploading the photo';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    // Only a shopper returning their own order may store photos
    var order = getOwnedOrder(data.orderId);
    if (empty(order)) {
        payload.msg = 'No order found';
        return RESTResponseMgr.createSuccess(payload).render();
    }

    var upload = zenkraftReturnHelper.saveReasonPhoto(order, { fileName: data.fileName, data: data.data });

    if (upload.success) {
        payload.success = true;
        payload.photoId = upload.photoId;
    } else {
        payload.msg = upload.serverErrors;
    }

    return RESTResponseMgr.createSuccess(payload).render();
});

exports.uploadReasonImage.public = true;
