'use strict';

var RESTResponseMgr = require('dw/system/RESTResponseMgr');
var zenkraftHelper = require('*/cartridge/scripts/helpers/zenkraftDopuHelper.js');

/**
 * This SCAPI CUSTOM API endpoint is used to get drop off location by shipping method
 * @returns {void}
 */
exports.getDropOffLocations = function () {
    var shippingMethodId = request
    .getHttpParameterMap()
    .get('c_shippingMethodId')
    .getStringValue();
    // Optional: set by multi-shipment checkouts so locations are searched around that shipment's address
    var shipmentId = request
    .getHttpParameterMap()
    .get('c_shipmentId')
    .getStringValue();

    var dopuPayload = {};

    dopuPayload = zenkraftHelper.getZenkraftDopuData(shippingMethodId, shipmentId);

    if (dopuPayload.error) {
        var errorMsg = typeof dopuPayload.error === 'object'
            ? (dopuPayload.error.message || 'Service error')
            : dopuPayload.error;
        var statusCode = errorMsg === 'Shipping method not found' ? 400 : 502;
        return RESTResponseMgr.createError(statusCode).render();
    }

    if (dopuPayload.locations) {
        for (var i = 0; i < dopuPayload.locations.length; i++) {
            var currentLocation = dopuPayload.locations[i];

            currentLocation.display_name = '';
            if (currentLocation.location_name) {
                currentLocation.display_name = currentLocation.location_name;
            } else if (currentLocation.location_company) {
                currentLocation.display_name = currentLocation.location_company;
            } else if (currentLocation.location_type) {
                currentLocation.display_name = currentLocation.location_type;
            }
        }
    }

    return RESTResponseMgr.createSuccess(dopuPayload).render();
};

exports.getDropOffLocations.public = true;
