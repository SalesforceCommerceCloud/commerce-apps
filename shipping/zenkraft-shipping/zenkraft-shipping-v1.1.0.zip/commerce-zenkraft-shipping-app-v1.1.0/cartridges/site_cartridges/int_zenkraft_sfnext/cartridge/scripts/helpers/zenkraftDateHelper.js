/* global empty */

/**
 * Returns a Calendar for the given date in the current site's time zone.
 * SFCC script Dates run in GMT, so "today", "tomorrow" and the time of day must be read through this.
 * @param {Date} [date] - Date to wrap; defaults to now
 * @return {dw.util.Calendar} Calendar in the site time zone
 */
function getSiteCalendar(date) {
    var Calendar = require('dw/util/Calendar');
    var Site = require('dw/system/Site');
    var calendar = new Calendar(date || new Date());
    calendar.setTimeZone(Site.getCurrent().getTimezone());
    return calendar;
}

/**
 * Returns the Zenkraft lead time configured for a basket line item, most specific first:
 * the product (variant, then its master), then the line item's category.
 * @param {dw.order.ProductLineItem} productLineItem - Basket line item
 * @return {number|null} Configured lead time in days, or null if none is configured
 */
function getLineItemLeadTime(productLineItem) {
    var product = productLineItem.getProduct();
    var sources = [product];
    if (product && product.isVariant()) {
        sources.push(product.getMasterProduct());
    }
    sources.push(productLineItem.getCategory());

    var leadTime = null;
    sources.some(function (source) {
        var custom = source && source.getCustom();
        if (custom && !empty(custom.zenkraftLeadTime)) {
            leadTime = custom.zenkraftLeadTime;
            return true;
        }
        return false;
    });
    return leadTime;
}

/**
 * Returns the lead time of the current basket: the longest lead time of its line items, where an item
 * without its own lead time uses the company-wide lead time.
 * @return {number} leadTime in days
 */
function getLeadTime() {
    var BasketMgr = require('dw/order/BasketMgr');
    var Site = require('dw/system/Site');
    var companyLeadTime = Site.getCurrent().getCustomPreferenceValue('zenkraftCompanyWideLeadTime') || 0;
    var currentBasket = BasketMgr.getCurrentBasket();
    var productLineItems = currentBasket ? currentBasket.getProductLineItems().toArray() : [];

    if (!productLineItems.length) {
        return companyLeadTime;
    }

    return productLineItems.reduce(function (leadTime, productLineItem) {
        var itemLeadTime = getLineItemLeadTime(productLineItem);
        return Math.max(leadTime, itemLeadTime !== null ? itemLeadTime : companyLeadTime);
    }, 0);
}

/**
 * Returns a date string formatted for display on cart and checkout.
 * Returns "Tomorrow D Mon" if the date is tomorrow in the site time zone, otherwise "Day D Mon".
 *
 * @param {Date} date calendar date to format (as built from a YYYY-MM-DD value, e.g. new Date(y, m, d))
 * @return {string} Formatted date
 */
function getFormattedDateTime(date) {
    var Calendar = require('dw/util/Calendar');
    var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var tomorrow = getSiteCalendar();
    tomorrow.add(Calendar.DATE, 1);

    var isTomorrow = date.getDate() === tomorrow.get(Calendar.DAY_OF_MONTH) &&
        date.getMonth() === tomorrow.get(Calendar.MONTH) &&
        date.getFullYear() === tomorrow.get(Calendar.YEAR);

    return [
        isTomorrow ? 'Tomorrow' : days[date.getDay()],
        date.getDate(),
        months[date.getMonth()]
    ].join(' ');
}

/**
 * Checks to see if the current time of day in the site time zone is at or after the configured cutoff time.
 *
 * @return {boolean} true if current time is after the zenkraftEDDCutoffTime preference, false otherwise
 */
function isAfterCutoffDate() {
    var Calendar = require('dw/util/Calendar');
    var Site = require('dw/system/Site');
    var System = require('dw/system/System');
    var cutoffDatePref = Site.getCurrent().getCustomPreferenceValue('zenkraftEDDCutoffTime');

    if (empty(cutoffDatePref)) {
        return false;
    }

    var now = getSiteCalendar();
    // Business Manager interprets the entered time in the instance time zone, so read it back in that zone
    var cutoff = new Calendar(cutoffDatePref);
    cutoff.setTimeZone(System.getInstanceTimeZone());

    var nowMinutes = (now.get(Calendar.HOUR_OF_DAY) * 60) + now.get(Calendar.MINUTE);
    var cutoffMinutes = (cutoff.get(Calendar.HOUR_OF_DAY) * 60) + cutoff.get(Calendar.MINUTE);
    return nowMinutes >= cutoffMinutes;
}

/**
 * Returns the ship date in the site time zone as a YYYY-MM-DD string, accounting for cutoff time and lead time.
 * @returns {string} Ship date in YYYY-MM-DD format
 */
function getShipDate() {
    var Calendar = require('dw/util/Calendar');
    var StringUtils = require('dw/util/StringUtils');
    var shipDate = getSiteCalendar();
    if (isAfterCutoffDate()) {
        shipDate.add(Calendar.DATE, 1);
    }
    var leadTime = getLeadTime();
    if (!empty(leadTime)) {
        shipDate.add(Calendar.DATE, leadTime);
    }
    return StringUtils.formatCalendar(shipDate, 'yyyy-MM-dd');
}

var ISO_DATETIME_REGEX = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$/;

/**
 * Matches an ISO 8601 datetime string and returns its wall-clock time as UTC milliseconds,
 * together with the zone offset in minutes.
 * @param {string} s - ISO 8601 datetime string (e.g. "2020-10-23T15:39:00.000-0400")
 * @returns {{wallClock: number, offsetMinutes: number}|null} Parsed parts, or null if s is empty or invalid
 */
function parseISOParts(s) {
    var match = s ? ISO_DATETIME_REGEX.exec(String(s).trim()) : null;
    if (!match) {
        return null;
    }
    var offsetMinutes = 0;
    var zone = match[7];
    if (zone && zone !== 'Z') {
        var digits = zone.slice(1).replace(':', '');
        offsetMinutes = ((parseInt(digits.slice(0, 2), 10) * 60) + parseInt(digits.slice(2), 10)) * (zone.charAt(0) === '-' ? -1 : 1);
    }
    return {
        wallClock: Date.UTC(+match[1], match[2] - 1, +match[3], +match[4], +match[5], +(match[6] || 0)),
        offsetMinutes: offsetMinutes
    };
}

/**
 * Parses an ISO 8601 datetime string into the exact instant it represents (zone offset applied).
 * Use this when storing to a datetime-typed attribute; use parseISOString for display.
 * @param {string} s - ISO 8601 datetime string (e.g. "2020-10-23T15:39:00.000-0400")
 * @returns {Date|null} Parsed date, or null if s is empty or invalid
 */
function parseISODate(s) {
    var parts = parseISOParts(s);
    return parts ? new Date(parts.wallClock - (parts.offsetMinutes * 60000)) : null;
}

/**
 * Formats an ISO 8601 datetime string for display, using the local date at the checkpoint
 * (zone offset ignored) so evening scans are not shifted to the next day.
 * @param {string} s - ISO 8601 datetime string (e.g. "2020-10-23T15:39:00.000-0400")
 * @returns {string} Formatted date via getFormattedDateTime, or the original value if it cannot be parsed
 */
function parseISOString(s) {
    var parts = parseISOParts(s);
    return parts ? getFormattedDateTime(new Date(parts.wallClock)) : s;
}

/**
 * Convert the YYYY-MM-DD date in a string (e.g. "2020-10-23" or "2020-10-23T15:39:00.000-0400") to SFCC date
 * @param {string} dateString - Date string
 * @return {Date|null} - Converted date, or null if dateString is empty or contains no YYYY-MM-DD date
 */
function convertDate(dateString) {
    var dateSlice = dateString ? String(dateString).match(/\d{4}-\d{2}-\d{2}/) : null;
    if (!dateSlice) {
        return null;
    }
    var dateArray = dateSlice[0].split('-');
    return new Date(parseInt(dateArray[0], 10), parseInt(dateArray[1], 10) - 1, parseInt(dateArray[2], 10));
}

exports.getLeadTime = getLeadTime;
exports.isAfterCutoffDate = isAfterCutoffDate;
exports.getFormattedDateTime = getFormattedDateTime;
exports.getShipDate = getShipDate;
exports.parseISOString = parseISOString;
exports.parseISODate = parseISODate;
exports.convertDate = convertDate;
