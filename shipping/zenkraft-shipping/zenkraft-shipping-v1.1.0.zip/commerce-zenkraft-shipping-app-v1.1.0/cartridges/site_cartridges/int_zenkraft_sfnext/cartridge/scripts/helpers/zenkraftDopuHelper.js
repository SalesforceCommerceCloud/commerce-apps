var BasketMgr = require('dw/order/BasketMgr');

var zenkraftService = require('../services/zenkraftService');
var zenkraftHelper = require('./zenkraftShippingHelper');

/**
* Get Drop Off Locations using the Zenkraft Web Service
*
* @param {Object} shippingAddress shipping address
* @param {Object} accountID - Account ID
* @return {HashMap} JSON Object with the location information
*/
function getDropOffLocations(shippingAddress, accountID) {
    var type = accountID ? 'EDD' : 'RETURN';
    var configs = zenkraftHelper.getConfig();
    var resp;
    var req;
    var thisaddress = shippingAddress;

    if (!empty(thisaddress) && !empty(thisaddress.postalCode)) {
        var street1 = '';
        if (!empty(thisaddress.address1)) {
            street1 = thisaddress.address1;
        } else if (!empty(thisaddress.street1)) {
            street1 = thisaddress.street1;
        }

        req = {
            dopu:
            {
                carrier: (accountID && accountID.carrier) || configs.carrier,
                location: {
                    city: !empty(thisaddress.city) ? thisaddress.city : '',
                    country: !empty(thisaddress.countryCode) ? thisaddress.countryCode.value.toUpperCase() : '',
                    postal_code: !empty(thisaddress.postalCode) ? thisaddress.postalCode.toString() : '',
                    state: !empty(thisaddress.stateCode) && thisaddress.stateCode !== 'undefined' ? thisaddress.stateCode : '',
                    street1: street1
                },
                packaging: configs.packagingType,
                shipping_account: (accountID && accountID.shippingMethodAccountID) || (type === 'RETURN'
                    ? (configs.returnsShippingAccount || '')
                    : (configs.shippingAccount ? configs.shippingAccount.split(',')[0] : '')),
                test: !configs.isProdMode,
                debug: configs.debugLog
            }
        };

        resp = zenkraftService.call(zenkraftService.API_PATHS.DOPU, JSON.stringify(req));

        if (!empty(resp.object)) {
            if (empty(resp.object.error)) {
                return resp.object;
            }
            return { error: resp.object.error };
        }
        return {
            error: 'No Locations Available'
        };
    }

    return {};
}

/**
 * Get applicalbe shipping method by ID
 * @param {string} methodId - shipping method id
 * @returns {Object} - shipping method
 */
function getShippingMethodById(methodId) {
    var ShippingMgr = require('dw/order/ShippingMgr');
    var collections = require('*/cartridge/scripts/util/collections');
    var shippingMethods = ShippingMgr.getAllShippingMethods();
    var shippingMethod = collections.find(shippingMethods, function (method) {
        return method.ID === methodId;
    });
    if (!shippingMethod) {
        return null;
    }
    return {
        carrier: shippingMethod.custom.zenkraftCarrier,
        shippingMethodAccountID: shippingMethod.custom.zenkraftShippingMethodAccountID
    };
}


/**
 * Get zenkraft dopu data by shipping method
 * @param {string} shippingMethodId - shipping method id
 * @param {string} [shipmentId] - shipment whose address the locations are searched around; the default shipment when omitted or unknown
 * @returns {Object} - shipping method
 */
function getZenkraftDopuData(shippingMethodId, shipmentId) {
    var currentBasket = BasketMgr.getCurrentBasket();

    if (!currentBasket) {
        return {};
    }

    var shippingMethod = getShippingMethodById(shippingMethodId);
    if (!shippingMethod) {
        return { error: 'Shipping method not found' };
    }

    var shipment = (shipmentId && currentBasket.getShipment(shipmentId)) || currentBasket.getDefaultShipment();
    if (!shipment) {
        return {};
    }

    return getDropOffLocations(shipment.shippingAddress, shippingMethod);
}

exports.getZenkraftDopuData = getZenkraftDopuData;