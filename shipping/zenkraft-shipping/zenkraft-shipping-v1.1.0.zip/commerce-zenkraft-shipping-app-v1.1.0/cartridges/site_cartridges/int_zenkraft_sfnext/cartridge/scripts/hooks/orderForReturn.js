/* eslint-disable no-param-reassign */
/* eslint-disable no-undef */
var Logger = require('dw/system/Logger');
var ProductMgr = require('dw/catalog/ProductMgr');
var Site = require('dw/system/Site');
var Status = require('dw/system/Status');
var zenkraftReturnHelper = require('*/cartridge/scripts/helpers/zenkraftReturnHelper');

var logger = Logger.getLogger('zenkraft', 'zenkraftReturns');


/**
 * Check for non returnable items
 * @param {Object} orderResponse - Order response
 * @returns {Object} - Updated order response
 */
function checkForNonReturnableProducts(orderResponse) {
    // Same rule the returns API enforces when a return is created
    for (var i = 0; i < orderResponse.productItems.length; i++) {
        var pli = orderResponse.productItems[i];
        pli.c_applicableForReturn = zenkraftReturnHelper.isProductReturnable(ProductMgr.getProduct(pli.productId));
    }
    return orderResponse;
}

/**
 * Filter orders with return line items
 * @param {Object} orderResponse - Order response
 * @param {string} returnCase - Return case ID
 * @returns {Object} - Updated order response
 */
function filterOrderItemsWithReturnLineItems(orderResponse, returnCase) {
    for (var i = 0; i < orderResponse.productItems.length; i++) {
        for (var j = 0; j < returnCase.returnLineItems.length; j++) {
            if (orderResponse.productItems[i].productId === returnCase.returnLineItems[j].productID) {
                if (orderResponse.productItems[i].quantity > returnCase.returnLineItems[j].quantity) {
                    var newQuantity = orderResponse.productItems[i].quantity - returnCase.returnLineItems[j].quantity;
                        // eslint-disable-next-line no-param-reassign
                    orderResponse.productItems[i].quantity = newQuantity;
                    orderResponse.c_returnLineItems.push(returnCase.returnLineItems.splice(j, 1)[0]);
                    return filterOrderItemsWithReturnLineItems(orderResponse, returnCase);
                }
                orderResponse.productItems[i].c_applicableForReturn = false;
                orderResponse.c_returnLineItems.push(returnCase.returnLineItems.splice(j, 1)[0]);
                return filterOrderItemsWithReturnLineItems(orderResponse, returnCase);
            }
        }
    }
    return orderResponse;
}

/**
 * Convert a date for an order response custom property. SCAPI can only encode booleans, numbers and
 * strings there; a Date fails the whole response with an EncodingException.
 * @param {Date|string} value - Date value
 * @returns {string|null} - ISO date string, or the value unchanged if it is already a string
 */
function toResponseDate(value) {
    return value && typeof value.toISOString === 'function' ? value.toISOString() : (value || null);
}

/**
 * Read a SFCC return case for the order response
 * @param {dw.object.CustomObject} rcase - zenkraftReturn custom object
 * @returns {Object|null} - { returnLineItems, label }, or null if the return case can't be read (already logged)
 */
function readReturnCaseForResponse(rcase) {
    var returnCase = zenkraftReturnHelper.getReturnCase(rcase);
    if (!returnCase) {
        return null;
    }
    var lineItems = Array.isArray(returnCase.returnLineItems) ? returnCase.returnLineItems : [];
    return {
        // A return case saved before combined labels were stored falls back to its first line's label
        label: rcase.custom.combinedLabel || (lineItems[0] && lineItems[0].label) || null,
        // Only plain values, and no per-line labels (~175K characters each)
        returnLineItems: lineItems.map(function (lineItem) {
            return {
                id: lineItem.id,
                returnID: lineItem.returnID,
                productID: lineItem.productID,
                product: lineItem.product,
                quantity: lineItem.quantity,
                trackingNumber: lineItem.trackingNumber || null,
                trackingStage: lineItem.trackingStage || null,
                trackingStatus: lineItem.trackingStatus || null,
                creationDate: toResponseDate(lineItem.creationDate),
                approvedDate: toResponseDate(lineItem.approvedDate)
            };
        })
    };
}

/**
 * Filters order for ZKAPI return handler
 * @param {Object} orderResponse - current order response
 * @param {string} customerNo - customer Number
 * @returns {Object} - Updated order response
 */
function filterOrderForZKReturnCases(orderResponse, customerNo) {
    var oneToOneRelation = Site.getCurrent().getCustomPreferenceValue('setZenkraftOrderReturnsOneToOneRelation');
    var returnCasesForOrder = zenkraftReturnHelper.getZKReturnCases([orderResponse.orderNo], customerNo);
    var returnCases = [];
    orderResponse.c_returnLineItems = [];
    returnCasesForOrder.forEach(function (rcase) {
        if (oneToOneRelation && rcase.returnLineItems) {
            orderResponse = filterOrderItemsWithReturnLineItems(orderResponse, rcase);
            orderResponse.c_returnLineItems.forEach(function (returnLineItem) {
                if (returnLineItem.returnID === rcase.id) {
                    rcase.returnLineItems.push(returnLineItem);
                }
            });
        }
        returnCases.push(rcase);
    });
    orderResponse.c_returnCases = returnCases;
    return orderResponse;
}

/**
 * Get product return reasons
 * @param {Object} orderResponse - Order response
 * @returns {Object} orderResponse - Updated order response
 */
function getProductReasons(orderResponse) {
    var reasonsObject = JSON.parse(Site.getCurrent().getCustomPreferenceValue('zenkraftReturnReasonsConfig'));
    var reasons = reasonsObject.reasons;
    for (var i = 0; i < orderResponse.productItems.length; i++) {
            // eslint-disable-next-line no-param-reassign
        orderResponse.productItems[i].c_returnReasons = [];
        var product = ProductMgr.getProduct(orderResponse.productItems[i].productId);
        var productCategories = product.variant ? product.getMasterProduct().getCategories().toArray() : product.getCategories().toArray();
        if (productCategories.length > 0) {
                // eslint-disable-next-line no-loop-func
            productCategories.forEach(function (productCategory) {
                reasons.forEach(function (reason) {
                    if ((reason.categories.indexOf(productCategory.getID()) !== -1 || reason.categories.indexOf('zk-default') !== -1) && orderResponse.productItems[i].c_returnReasons.indexOf(reason) === -1) {
                        orderResponse.productItems[i].c_returnReasons.push(reason);
                    }
                });
            });
        }
    }
    return orderResponse;
}

/**
 * Creates unique UUID for each product line item
 * @param {Object} orderResponse - Order response
 * @returns {Object} orderResponse - Updated order response
 */
function setReturnLineItemsUniqueIds(orderResponse) {
    for (var i = 0; i < orderResponse.productItems.length; i++) {
        var pli = orderResponse.productItems[i];
        pli.c_uniqueID = require('dw/util/UUIDUtils').createUUID();
    }

    return orderResponse;
}

/**
 * Add to orderResponse data for returns
 * @param {Object} order - Order
 * @param {Object} orderResponse - Order response
 * @returns {void}
 */
function prepareOrderforReturns(order, orderResponse) {
    var session = request.getSession();
    var customer = session.customer;
    var oneToOneRelation = Site.getCurrent().getCustomPreferenceValue('setZenkraftOrderReturnsOneToOneRelation');
    var newReturnObjectPerReturn = Site.getCurrent().getCustomPreferenceValue('zenkraftNewReturnObjectPerReturn');
    var returnsHandlerId = Site.getCurrent().getCustomPreferenceValue('zenkraftReturnsHandler');

    var returnCasesArr = [];

    var missingData = zenkraftReturnHelper.checkForMissingImportantData(order);

    if (missingData) {
        orderResponse.c_missingData = missingData;
    }

    if (returnsHandlerId && returnsHandlerId.value === 'sfcc') {
        var existingReturnCases = zenkraftReturnHelper.checkForExistingReturnCases(orderResponse.orderNo);
        var returnCase;
        var returnLineItems;
        orderResponse = checkForNonReturnableProducts(orderResponse);
        if (existingReturnCases && existingReturnCases.length) {
            if (newReturnObjectPerReturn) {
                orderResponse.c_returnLineItems = [];
                existingReturnCases.forEach(function (rcase) {
                    returnLineItems = [];
                    returnCase = readReturnCaseForResponse(rcase);
                    if (!returnCase) { return; }
                    var qrCode = rcase.custom.qrCode ? rcase.custom.qrCode : null;
                    var qrCodeType = rcase.custom.qrCodeType ? rcase.custom.qrCodeType : null;
                    if (oneToOneRelation) {
                        orderResponse = filterOrderItemsWithReturnLineItems(orderResponse, returnCase);
                        orderResponse.c_returnLineItems.forEach(function (returnLineItem) {
                            if (returnLineItem.returnID === rcase.custom.id) {
                                returnLineItems.push(returnLineItem);
                            }
                        });
                    } else {
                        returnLineItems = returnCase.returnLineItems;
                    }
                    returnCasesArr.push({
                        id: rcase.custom.id,
                        returnLineItems: returnLineItems,
                        combinedLabel: returnCase.label,
                        qrCode: qrCode,
                        qrCodeType: qrCodeType
                    });
                });
            } else {
                // An unreadable return case (already logged) is treated as having no line items
                returnCase = readReturnCaseForResponse(existingReturnCases[0]) || { returnLineItems: [], label: null };
                var qrCode = existingReturnCases[0].custom.qrCode ? existingReturnCases[0].custom.qrCode : null;
                var qrCodeType = existingReturnCases[0].custom.qrCodeType ? existingReturnCases[0].custom.qrCodeType : 'png';
                if (oneToOneRelation) {
                    orderResponse.c_returnLineItems = [];
                    returnLineItems = [];
                    orderResponse = filterOrderItemsWithReturnLineItems(orderResponse, returnCase);
                    orderResponse.c_returnLineItems.forEach(function (returnLineItem) {
                        returnLineItems.push(returnLineItem);
                    });
                    returnCasesArr.push({
                        id: existingReturnCases[0].custom.id,
                        returnLineItems: returnLineItems,
                        combinedLabel: returnCase.label,
                        qrCode: qrCode,
                        qrCodeType: qrCodeType
                    });
                } else {
                    returnCasesArr.push({
                        id: existingReturnCases[0].custom.id,
                        returnLineItems: returnCase.returnLineItems,
                        combinedLabel: returnCase.label,
                        qrCodeType: qrCodeType
                    });
                }
            }
        }
        orderResponse.c_returnCases = returnCasesArr;
    } else {
        orderResponse = checkForNonReturnableProducts(orderResponse);
        orderResponse = filterOrderForZKReturnCases(orderResponse, customer.profile ? customer.profile.customerNo : null);
    }
    orderResponse = getProductReasons(orderResponse);
    orderResponse = setReturnLineItemsUniqueIds(orderResponse);
}

exports.modifyGETResponse = function (order, orderResponse) {
    try {
        var returnFlow = request
        .getHttpParameterMap()
        .get('c_returnFlow')
        .getStringValue();

        if (returnFlow) {
            prepareOrderforReturns(order, orderResponse);
        }

        return new Status(Status.OK);
    } catch (e) {
        logger.error('orderForReturn modifyGETResponse failed: {0}', e.message);
        return new Status(Status.ERROR, 'ZENKRAFT_RETURN_ERROR', e.message);
    }
};
