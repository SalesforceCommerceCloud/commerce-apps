'use strict';

var Logger = require('dw/system/Logger');
var OrderMgr = require('dw/order/OrderMgr');
var Site = require('dw/system/Site');

var logger = Logger.getLogger('zenkraft', 'zenkraftTracking');

/**
 * Reads carrier-specific tracking preferences from zenkraftTrackingAccountSettingsJSON.
 * @param {string} carrier - Carrier identifier
 * @returns {Object} Tracking preferences for the carrier
 */
function getTrackingJSONPreferences(carrier) {
    var currentSite = Site.getCurrent();
    var advJsonRaw = currentSite.getCustomPreferenceValue('zenkraftTrackingAccountSettingsJSON');
    var returnObj = {};

    try {
        var advJson = JSON.parse(advJsonRaw);
        var advJsonSpec = advJson[carrier];

        if (!advJsonSpec) {
            logger.warn('No tracking JSON preference entry for carrier: {0}', carrier);
            returnObj.IS_TEST = !(currentSite.getCustomPreferenceValue('zenkraftProdMode'));
            returnObj.IS_DEBUG = currentSite.getCustomPreferenceValue('zenkraftDebugLog');
            returnObj.SHIPPING_ACCOUNT = '';
            return returnObj;
        }

        returnObj.IS_TEST = Object.prototype.hasOwnProperty.call(advJsonSpec, 'TEST')
            ? advJsonSpec.TEST
            : !(currentSite.getCustomPreferenceValue('zenkraftProdMode'));
        returnObj.IS_DEBUG = Object.prototype.hasOwnProperty.call(advJsonSpec, 'DEBUG')
            ? advJsonSpec.DEBUG
            : currentSite.getCustomPreferenceValue('zenkraftDebugLog');
        returnObj.SHIPPING_ACCOUNT = Object.prototype.hasOwnProperty.call(advJsonSpec, 'SHIPPING_ACCOUNT')
            ? advJsonSpec.SHIPPING_ACCOUNT
            : '';
    } catch (e) {
        logger.error('Invalid Zenkraft tracking JSON preferences: {0}', e.message);
        returnObj.IS_TEST = !(currentSite.getCustomPreferenceValue('zenkraftProdMode'));
        returnObj.IS_DEBUG = currentSite.getCustomPreferenceValue('zenkraftDebugLog');
        returnObj.SHIPPING_ACCOUNT = '';
        return returnObj;
    }

    return returnObj;
}

/**
 * Calls the Zenkraft track API for a given tracking number and carrier.
 * @param {string} trackingNumber - Shipment tracking number
 * @param {string} carrier - Carrier identifier
 * @returns {Object} Tracking data or error object
 */
function getTrackingData(trackingNumber, carrier) {
    var zenkraftService = require('../services/zenkraftService');
    var dateHelper = require('./zenkraftDateHelper');
    var prefs = getTrackingJSONPreferences(carrier);

    var req = {
        track: {
            debug: String(prefs.IS_DEBUG) === 'true',
            test: String(prefs.IS_TEST) === 'true',
            shipping_account: prefs.SHIPPING_ACCOUNT,
            carrier: carrier,
            tracking_number: trackingNumber
        }
    };

    var resp = zenkraftService.call(zenkraftService.API_PATHS.TRACK, JSON.stringify(req));

    if (resp.status === 'ERROR' || empty(resp.object)) {
        logger.error('Zenkraft track service error for tracking number {0}: {1}', trackingNumber, resp.errorMessage);
        return { error: 'Error Getting Tracking Information' };
    }

    var retObject = resp.object;

    if (empty(retObject.error)) {
        if (retObject.checkpoints && retObject.checkpoints.length > 0) {
            retObject.checkpoints.forEach(function (checkpoint) {
                if (checkpoint.time) {
                    checkpoint.time = dateHelper.parseISOString(checkpoint.time);
                }
            });
        }
    }

    return retObject;
}

/**
 * Retrieves product details from an order for display on the tracking page.
 * @param {dw.order.Order} order - SFCC order object
 * @returns {Array} Array of product detail objects
 */
function getOrderProducts(order) {
    var ProductMgr = require('dw/catalog/ProductMgr');
    var products = [];

    var productLineItems = order.getAllProductLineItems().iterator();
    while (productLineItems.hasNext()) {
        var productLineItem = productLineItems.next();
        var productObj = ProductMgr.getProduct(productLineItem.productID);
        var smallImage = productObj && productObj.getImage('small');
        products.push({
            id: productLineItem.productID,
            name: productLineItem.productName,
            quantity: productLineItem.quantityValue,
            currentPrice: productLineItem.adjustedPrice ? productLineItem.adjustedPrice.value : null,
            pricePerUnit: productLineItem.basePrice ? productLineItem.basePrice.value : null,
            image: smallImage ? smallImage.getURL().toString() : null
        });
    }

    return products;
}

/**
 * Main entry point for the tracking SCAPI endpoint.
 * Reads site preferences for feature flags and returns formatted tracking data.
 *
 * @param {string} trackingNumber - Shipment tracking number
 * @param {string} carrier - Carrier identifier
 * @param {string} orderNo - Order number (optional)
 * @param {boolean} orderDetailsPage - Whether the request comes from an order detail view
 * @returns {Object} Tracking response payload
 */
function getZenkraftTrackingData(trackingNumber, carrier, orderNo, orderDetailsPage) {
    var currentSite = Site.getCurrent();
    var enableZenkraftTrackingPage = currentSite.getCustomPreferenceValue('enableZenkraftTrackingPage');
    var enableZenkraftTrackingOnOrderDetailsPage = currentSite.getCustomPreferenceValue('enableZenkraftTrackingOnOrderDetailsPage');
    var enablePOD = currentSite.getCustomPreferenceValue('enableZenkraftPOD');

    if (!enableZenkraftTrackingPage) {
        return { redirect: true, redirectURL: '/' };
    }

    if (orderDetailsPage && !enableZenkraftTrackingOnOrderDetailsPage) {
        return { redirect: false, enableZenkraftTrackingOnOrderDetailsPage: false };
    }

    // Order details settings check (no tracking number): answered from the preferences, without calling Zenkraft
    if (orderDetailsPage && !trackingNumber) {
        return { redirect: false, enableZenkraftTrackingOnOrderDetailsPage: true };
    }

    var isAuthenticated = typeof customer !== 'undefined' && customer.authenticated;

    // "Tracking page requires login": guests and anonymous callers get no tracking data, only a request to log in.
    // Enforced here so direct API calls are covered too. The order details page has its own ownership check.
    if (!orderDetailsPage && currentSite.getCustomPreferenceValue('zenkraftTrackingPageRequiresLogin') && !isAuthenticated) {
        return { redirect: false, loginRequired: true, requireLogin: true };
    }

    var orderData = {};
    var trackingData = {};
    var trackingDetails;
    var order = null;

    if (orderNo) {
        order = OrderMgr.getOrder(orderNo);
        if (!order) {
            return { redirect: true, redirectURL: '/page-not-found' };
        }

        var profileCustomerNo = isAuthenticated && customer.profile ? customer.profile.customerNo : null;
        var ownsOrder = isAuthenticated && order.customerNo && order.customerNo === profileCustomerNo;

        if (!ownsOrder) {
            if (orderDetailsPage) {
                return { redirect: true, redirectURL: '/page-not-found' };
            }
            // On the public tracking page, omit order data but still return tracking
        } else {
            orderData.orderNo = order.orderNo;
            orderData.currency = order.currencyCode;
            orderData.products = getOrderProducts(order);
        }
    }

    trackingDetails = getTrackingData(trackingNumber, carrier);

    if (!trackingDetails || trackingDetails.error) {
        logger.warn('No tracking data available for {0}/{1}: {2}', trackingNumber, carrier, trackingDetails ? trackingDetails.error : 'no response');
        return {
            order: orderData,
            trackingData: null,
            enableZenkraftTrackingOnOrderDetailsPage: enableZenkraftTrackingOnOrderDetailsPage,
            requireLogin: currentSite.getCustomPreferenceValue('zenkraftTrackingPageRequiresLogin'),
            redirect: false
        };
    }

    if (orderDetailsPage) {
        trackingData.status = trackingDetails.status;
        trackingData.tracking_stage = trackingDetails.tracking_stage;
    } else {
        trackingData = trackingDetails;

        if (Object.keys(trackingData).length === 0) {
            return { redirect: true, redirectURL: '/page-not-found' };
        }
    }

    if (!enablePOD) {
        trackingData.pod = null;
    }

    return {
        order: orderData,
        trackingData: trackingData,
        enableZenkraftTrackingOnOrderDetailsPage: enableZenkraftTrackingOnOrderDetailsPage,
        requireLogin: currentSite.getCustomPreferenceValue('zenkraftTrackingPageRequiresLogin'),
        redirect: false
    };
}

module.exports = {
    getZenkraftTrackingData: getZenkraftTrackingData
};
