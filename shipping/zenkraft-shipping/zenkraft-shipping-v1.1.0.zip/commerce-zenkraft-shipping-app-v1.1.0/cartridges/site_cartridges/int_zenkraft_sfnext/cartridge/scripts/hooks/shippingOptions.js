var BasketMgr = require('dw/order/BasketMgr');
var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var Status = require('dw/system/Status');

var logger = Logger.getLogger('zenkraft', 'shippingOptions');

exports.quote = function (shipment, shippingMethodResult) {
    try {
    var collections = require('../util/collections');
    var dateHelper = require('../helpers/zenkraftDateHelper.js');
    var zenkraftShippingHelper = require('../helpers/zenkraftShippingHelper');
    var basket = BasketMgr.getCurrentBasket();
    var enableZenkraftEstimatedDeliveryDates = Site.getCurrent().getCustomPreferenceValue('enableZenkraftEstimatedDeliveryDates');

    var config = zenkraftShippingHelper.getConfig();
    if (!config.enabled) {
        logger.debug('Zenkraft Shipping Rates are not enabled');
        return new Status(Status.OK);
    }


    if (basket) {
        var thisItems = shipment.productLineItems;
        var thisDates = [];
        var parts;
        var thisDateraw;
        var leadDateFormated = dateHelper.getShipDate();
        var thisMethods = shippingMethodResult.applicableShippingMethods;

        var thisAddress = shipment.shippingAddress;
        var senderAddress = null;

        var estimateKey = zenkraftShippingHelper.buildEstimateKey(shipment);
        var storedKey = String(shipment.custom.zenkraftEstimateKey || '');
        var snapshot = zenkraftShippingHelper.readSnapshot(shipment);

        if (estimateKey && storedKey === estimateKey && snapshot && snapshot.rates && snapshot.rates.length > 0) {
            thisDates = snapshot.rates;
        } else {
            thisDates = zenkraftShippingHelper.getShippingData(thisAddress, thisItems, thisMethods, leadDateFormated, senderAddress, shipment.UUID);
        }

        if (empty(thisDates) || !thisMethods) {
            logger.debug('No Zenkraft shipping data returned for shipment: {0}', shipment.UUID);
            if (!config.nativeMethodsFallback && estimateKey) {
                shippingMethodResult.applicableShippingMethods = [];
            }
            return new Status(Status.OK);
        }

        collections.forEach(thisMethods, function filterMethods(method) {
            var filteredMethod = thisDates.filter(function filterMethod(thisDate) {
                return thisDate.service_type === method.c_zenkraftID;
            });
            var filteredMethodObj = filteredMethod[0];

            if (filteredMethodObj) {
                method.c_delivery_slots = filteredMethodObj.delivery_slots;

                if (enableZenkraftEstimatedDeliveryDates) {
                    if (filteredMethodObj.estimated_date) {
                        parts = filteredMethodObj.estimated_date.split('-');
                        thisDateraw = new Date(parts[0], parts[1] - 1, parts[2]); // eslint-disable-line vars-on-top
                        method.c_estimated_date = filteredMethodObj.estimated_date;
                        method.c_estimated_date_time = filteredMethodObj.estimated_date_time;
                        method.c_estimatedArrivalTime = dateHelper.getFormattedDateTime(thisDateraw);
                        var isoDate = filteredMethodObj.estimated_date + 'T12:00:00.000Z'; // eslint-disable-line vars-on-top
                        method.deliveryWindow = { startAt: new Date(isoDate), endAt: new Date(isoDate) };
                    } else if (filteredMethodObj.delivery_slots[0]) {
                        var deliverySlot = filteredMethodObj.delivery_slots[0]; // eslint-disable-line vars-on-top
                        parts = deliverySlot.start_time.split('-'); // eslint-disable-line vars-on-top
                        thisDateraw = new Date(parts[0], parts[1] - 1, parts[2].slice(0, 2)); // eslint-disable-line vars-on-top
                        method.c_estimated_date = filteredMethodObj.delivery_slots[0].start_time;
                        method.c_estimated_date_time = filteredMethodObj.delivery_slots[0].end_time;
                        method.c_estimatedArrivalTime = dateHelper.getFormattedDateTime(thisDateraw);
                        method.deliveryWindow = { startAt: new Date(deliverySlot.start_time), endAt: new Date(deliverySlot.end_time || deliverySlot.start_time) };
                    }
                }

                if (!empty(filteredMethodObj) && !empty(filteredMethodObj.cost)) {
                    var markupType = method.c_zenkraftRateMarkupType ? method.c_zenkraftRateMarkupType : 'Amount';
                    var markup = method.c_zenkraftRateMarkup || 0;
                    method.price = zenkraftShippingHelper.getMarkupCost(markupType, markup, filteredMethodObj.cost).value;
                }


            }
        });

    }
    return new Status(Status.OK);
    } catch (e) {
        logger.error('Zenkraft shipping options exception: {0}', e.message);
        return new Status(Status.OK);
    }
};