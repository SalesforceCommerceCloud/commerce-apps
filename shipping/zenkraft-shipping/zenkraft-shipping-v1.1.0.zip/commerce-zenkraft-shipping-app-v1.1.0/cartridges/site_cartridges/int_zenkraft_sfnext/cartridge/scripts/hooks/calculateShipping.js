/* global empty, session */
'use strict';

var Basket = require('dw/order/Basket');
var Logger = require('dw/system/Logger');
var ShippingMgr = require('dw/order/ShippingMgr');
var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');
var zenkraftShippingHelper = require('~/cartridge/scripts/helpers/zenkraftShippingHelper');

var logger = Logger.getLogger('zenkraft', 'calculateShipping');

/**
 * Whether any drop-off (collection point) attribute is still set on a shipment or its shipping
 * address. The storefront clears zenkraftDropOffData itself when the shopper switches away from a
 * drop-off method, so the derived attributes must be checked on their own.
 *
 * @param {dw.order.Shipment} shipment - The shipment to check
 * @returns {boolean} true when at least one drop-off attribute has a value
 */
function hasDropOffData(shipment) {
    return !empty(shipment.custom.zenkraftDropOffData)
        || !empty(shipment.custom.zenkraftDOPULocationCode)
        || !empty(shipment.custom.zenkraftDOPULocationName)
        || !!(shipment.shippingAddress && !empty(shipment.shippingAddress.custom.zenkraftDOPULocationName));
}

/**
 * Clears the stored drop-off (collection point) data from a shipment and its shipping address.
 *
 * @param {dw.order.Shipment} shipment - The shipment to clear
 */
function clearDropOffData(shipment) {
    Transaction.wrap(function () {
        shipment.custom.zenkraftDropOffData = null;
        shipment.custom.zenkraftDOPULocationCode = null;
        shipment.custom.zenkraftDOPULocationName = null;
        if (shipment.shippingAddress) {
            shipment.shippingAddress.custom.zenkraftDOPULocationName = null;
        }
    });
}

/**
 * Reads the collection point the storefront stored on a shipment (zenkraftDropOffData).
 *
 * @param {dw.order.Shipment} shipment - The shipment to read
 * @returns {Object|null} The collection point, or null when there is none or it can't be read
 */
function readDropOff(shipment) {
    if (empty(shipment.custom.zenkraftDropOffData)) {
        return null;
    }
    try {
        var dropOff = JSON.parse(String(shipment.custom.zenkraftDropOffData));
        return dropOff && dropOff.location_code ? dropOff : null;
    } catch (e) {
        logger.warn('[Zenkraft] calculateShipping: failed to parse zenkraftDropOffData for shipment {0}: {1}', shipment.UUID, e.message);
        return null;
    }
}

/**
 * Reads the shopper's own address, saved in zenkraftOriginalShippingAddress while the shipping
 * address holds a collection point's address.
 *
 * @param {dw.order.Shipment} shipment - The shipment to read
 * @returns {Object|null} The saved address, or null when there is none or it can't be used
 */
function readSavedAddress(shipment) {
    if (empty(shipment.custom.zenkraftOriginalShippingAddress)) {
        return null;
    }
    try {
        var saved = JSON.parse(String(shipment.custom.zenkraftOriginalShippingAddress));
        // Without the copied fields a shopper's edit can't be told apart from the copy
        return saved && saved.copied ? saved : null;
    } catch (e) {
        logger.warn('[Zenkraft] calculateShipping: failed to parse zenkraftOriginalShippingAddress for shipment {0}: {1}', shipment.UUID, e.message);
        return null;
    }
}

/**
 * The collection point's name, shown as the company of the shipping address.
 *
 * @param {Object} dropOff - The collection point
 * @returns {string|null} The name, or null when the point has none
 */
function getLocationName(dropOff) {
    return dropOff.location_name || dropOff.company_name || dropOff.display_name || null;
}

/**
 * The shipping address fields a collection point replaces, as comparable strings.
 *
 * @param {dw.order.OrderAddress} addr - The shipping address
 * @returns {Object} address1, city, postalCode, stateCode and countryCode
 */
function getCopiedFields(addr) {
    return {
        address1: addr.address1 || '',
        city: addr.city || '',
        postalCode: addr.postalCode || '',
        stateCode: addr.stateCode || '',
        countryCode: addr.countryCode && addr.countryCode.value ? String(addr.countryCode.value).toUpperCase() : ''
    };
}

/**
 * Whether the shipping address still holds the collection point's address copied onto it.
 *
 * @param {dw.order.OrderAddress} addr - The shipping address
 * @param {Object} copied - The fields saved with the copy
 * @returns {boolean} true when none of the fields changed since the copy
 */
function holdsCopy(addr, copied) {
    var current = getCopiedFields(addr);
    return Object.keys(current).every(function (field) {
        return current[field].toLowerCase() === String(copied[field] || '').toLowerCase();
    });
}

/**
 * Copies a collection point's address onto the shipment's shipping address, keeping the shopper's
 * name and phone. The shopper's own address is saved by the first copy; a later copy (another
 * point) keeps it.
 *
 * @param {dw.order.Shipment} shipment - The drop-off shipment
 * @param {Object} dropOff - The collection point
 * @param {Object|null} saved - The address saved by an earlier copy, if any
 */
function copyCollectionPoint(shipment, dropOff, saved) {
    var addr = shipment.shippingAddress;
    var toSave = saved || {
        address1: addr.address1,
        address2: addr.address2,
        city: addr.city,
        postalCode: addr.postalCode,
        stateCode: addr.stateCode,
        countryCode: addr.countryCode ? addr.countryCode.value : null,
        companyName: addr.companyName
    };
    Transaction.wrap(function () {
        if (dropOff.street1) {
            addr.setAddress1(dropOff.street1);
            // The shopper's apartment / unit line does not belong to the collection point.
            addr.setAddress2(null);
        }
        if (dropOff.city) { addr.setCity(dropOff.city); }
        if (dropOff.postal_code) { addr.setPostalCode(dropOff.postal_code); }
        if (dropOff.state) { addr.setStateCode(dropOff.state); }
        if (dropOff.country) { addr.setCountryCode(String(dropOff.country).toUpperCase()); }
        var locationName = getLocationName(dropOff);
        if (locationName) { addr.setCompanyName(locationName); }
        toSave.locationCode = dropOff.location_code;
        toSave.copied = getCopiedFields(addr);
        shipment.custom.zenkraftOriginalShippingAddress = JSON.stringify(toSave);
    });
}

/**
 * Writes the shopper's saved address fields onto an address, keeping its name and phone.
 *
 * @param {dw.order.OrderAddress} addr - The shipping or billing address
 * @param {Object} saved - The saved address
 */
function writeShopperAddress(addr, saved) {
    addr.setAddress1(saved.address1 || null);
    addr.setAddress2(saved.address2 || null);
    addr.setCity(saved.city || null);
    addr.setPostalCode(saved.postalCode || null);
    addr.setStateCode(saved.stateCode || null);
    if (saved.countryCode) { addr.setCountryCode(saved.countryCode); }
    addr.setCompanyName(saved.companyName || null);
}

/**
 * Puts the shopper's saved address back on the shipment and clears the saved copy.
 *
 * @param {dw.order.Shipment} shipment - The shipment
 * @param {Object} saved - The saved address
 */
function restoreShopperAddress(shipment, saved) {
    Transaction.wrap(function () {
        writeShopperAddress(shipment.shippingAddress, saved);
        shipment.custom.zenkraftOriginalShippingAddress = null;
    });
}

/**
 * Gives the billing address the shopper's own address when it holds a collection point's address.
 * Storefront Next copies the first shipment's shipping address to billing while "use a different
 * billing address" is off, and when it applies a saved card as the order is placed; a carrier
 * location must not become the billing address.
 *
 * @param {dw.order.Basket} basket - The basket being calculated
 */
function restoreShopperBilling(basket) {
    var billing = basket.billingAddress;
    if (!billing) {
        return;
    }
    var shipmentsIt = basket.getShipments().iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();
        var saved = readSavedAddress(shipment);
        if (saved && holdsCopy(billing, saved.copied)) {
            Transaction.wrap(function () {
                writeShopperAddress(billing, saved);
            });
            logger.info('[Zenkraft] calculateShipping: billing address held the collection point of shipment {0}; replaced it with the shopper address', shipment.UUID);
            return;
        }
    }
}

/**
 * Keeps each basket shipment's shipping address in line with its collection point, so the order
 * carries the collection point's address (as in SFRA). Runs on every basket calculation, including
 * the requests that select a shipping method or a collection point.
 *
 * - Drop-off method with a collection point: the shipping address becomes the collection point's.
 * - Any other method, or no collection point: the shopper's saved address is put back.
 * - Shipping address changed after the copy (the shopper entered an address): that address is kept
 *   and the collection point is cleared, so the shopper chooses one again.
 * - Billing address holding a collection point's address (copied by the storefront): it gets the
 *   shopper's address.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order being calculated
 */
function syncCollectionPointAddresses(lineItemCtnr) {
    // An order keeps the address it was placed with
    if (!(lineItemCtnr instanceof Basket)) {
        return;
    }
    // Before the shipments: a shipment switched away from its collection point below loses its saved address
    restoreShopperBilling(lineItemCtnr);

    var shipmentsIt = lineItemCtnr.getShipments().iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();
        var addr = shipment.shippingAddress;
        if (!addr) {
            continue;
        }

        var saved = readSavedAddress(shipment);
        if (!saved && !empty(shipment.custom.zenkraftOriginalShippingAddress)) {
            // Unreadable, or saved by an earlier build without the copied fields: can't be used
            Transaction.wrap(function () {
                shipment.custom.zenkraftOriginalShippingAddress = null;
            });
        }

        if (saved && !holdsCopy(addr, saved.copied)) {
            Transaction.wrap(function () {
                shipment.custom.zenkraftOriginalShippingAddress = null;
            });
            if (hasDropOffData(shipment)) {
                clearDropOffData(shipment);
            }
            logger.info('[Zenkraft] calculateShipping: shipping address changed after the collection point was copied; kept it and cleared the collection point for shipment {0}', shipment.UUID);
            continue;
        }

        var shippingMethod = shipment.shippingMethod;
        var isDropOffMethod = !!(shippingMethod && shippingMethod.custom.zenkraftID && shippingMethod.custom.zenkraftDropOffMethod);
        var dropOff = isDropOffMethod ? readDropOff(shipment) : null;

        if (dropOff) {
            var locationName = getLocationName(dropOff);
            // Copy when nothing is copied yet, another point was chosen, or the address lost the
            // point's name (the storefront's address form doesn't send the company)
            if (!saved || saved.locationCode !== dropOff.location_code || (locationName && addr.companyName !== locationName)) {
                copyCollectionPoint(shipment, dropOff, saved);
                logger.info('[Zenkraft] calculateShipping: copied collection point {0} onto the shipping address of shipment {1}', dropOff.location_code, shipment.UUID);
            }
        } else if (saved) {
            restoreShopperAddress(shipment, saved);
            if (hasDropOffData(shipment)) {
                clearDropOffData(shipment);
            }
            logger.info('[Zenkraft] calculateShipping: no collection point selected; restored the shopper address for shipment {0}', shipment.UUID);
        }
    }
}

/**
 * Hook handler for sfcc.app.shipping.calculate.
 * Keeps the shipping address of drop-off shipments in line with the selected collection point, then
 * calls the Zenkraft rate API (with request-hash deduplication) and overrides line-item prices with
 * the returned rates in case zenrkaft shipping rate are enabled.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate shipping for
 * @returns {dw.system.Status} Status indicating success or failure
 */
function calculate(lineItemCtnr) {
    try {
        syncCollectionPointAddresses(lineItemCtnr);
    } catch (e) {
        logger.error('[Zenkraft] calculateShipping: failed to sync the collection point address: {0}', e.message);
    }

    var config = zenkraftShippingHelper.getConfig();
    if (!config.enabled) {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('Zenkraft Shipping Rates are not enabled');
        return new Status(Status.OK);
    }

    var missingRequiredData = false;
    var currentShipments = lineItemCtnr.getShipments();
    var isMultiShipment = currentShipments.length > 1;
    var shipmentsIt = currentShipments.iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();

        // Empty shipments left over from multi-shipment mode have no products to rate —
        // skip the API call so they don't pollute missingRequiredData for other shipments.
        if (isMultiShipment && shipment.productLineItems.size() === 0) {
            logger.debug('Skipping rate request for empty shipment: ' + shipment.UUID);
            continue;
        }

        var shippingMethod = shipment.shippingMethod;
        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            shipment.custom.zenkraftCarrier = shippingMethod.custom.zenkraftCarrier || config.carrier || '';
            shipment.custom.zenkraftShippingAccount = shippingMethod.custom.zenkraftShippingMethodAccountID;

            if (shippingMethod.custom.zenkraftDropOffMethod) {
                // Drop-off method — sync or clear the stored collection-point data.
                try {
                    if (!empty(shipment.custom.zenkraftDropOffData)) {
                        // Drop-off location was stored on the shipment together with the shipping
                        // method via the set-dropoff-location SCAPI call. Sync derived attributes so
                        // the rate request targets the collection point correctly.
                        var storedDropOff = JSON.parse(String(shipment.custom.zenkraftDropOffData));
                        // Raw Zenkraft locations only carry display_name; location_name wins when present.
                        var dropOffLocationName = storedDropOff.location_name || storedDropOff.display_name;
                        Transaction.wrap(function () {
                            if (storedDropOff.location_code) {
                                shipment.custom.zenkraftDOPULocationCode = storedDropOff.location_code;
                            }
                            if (dropOffLocationName) {
                                shipment.custom.zenkraftDOPULocationName = dropOffLocationName;
                                if (shipment.shippingAddress) {
                                    shipment.shippingAddress.custom.zenkraftDOPULocationName = dropOffLocationName;
                                }
                            }
                        });
                    } else {
                        clearDropOffData(shipment);
                    }
                } catch (e) {
                    logger.warn('[Zenkraft] calculateShipping: failed to process dropOff data: {0}', e.message);
                }
            } else if (hasDropOffData(shipment)) {
                // Zenkraft non-drop-off method — clear any stale collection-point data left
                // from a previous drop-off selection on this shipment.
                clearDropOffData(shipment);
            }
        } else {
            shipment.custom.zenkraftCarrier = null;
            shipment.custom.zenkraftShippingAccount = null;
            if (hasDropOffData(shipment)) {
                // Non-Zenkraft method — clear any stale collection-point data.
                clearDropOffData(shipment);
            }
        }

        try {
            var rateRequest = zenkraftShippingHelper.buildShippingRateRequest(shipment);
            if (!rateRequest) {
                missingRequiredData = true;
            } else {
                var estimateKey = zenkraftShippingHelper.buildEstimateKey(shipment);
                var storedKey = String(shipment.custom.zenkraftEstimateKey || '');
                var snapshot = zenkraftShippingHelper.readSnapshot(shipment);

                if (estimateKey && storedKey === estimateKey && snapshot) {
                    var cachedRates = {};
                    var cachedEDD = {};
                    Object.keys(snapshot.methods || {}).forEach(function (id) {
                        var m = snapshot.methods[id];
                        if (m.cost != null) { cachedRates[id] = m.cost; }
                        if (m.edd) { cachedEDD[id] = m.edd; }
                    });
                    zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(cachedRates), shipment.UUID);
                    zenkraftShippingHelper.updateSessionEDD(cachedEDD, shipment.UUID);
                } else {
                    var apiResult = zenkraftShippingHelper.callZenkraftAPI(rateRequest, shipment.UUID);
                    if (!apiResult.deduplicated) {
                        if (apiResult.success && apiResult.data) {
                            var ratesMap = zenkraftShippingHelper.buildRatesMapFromResponse(apiResult.data);
                            zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(ratesMap), shipment.UUID);
                            var eddPerMethod = zenkraftShippingHelper.buildEDDMapFromResponse(apiResult.data);
                            zenkraftShippingHelper.updateSessionEDD(eddPerMethod, shipment.UUID);
                            if (estimateKey) {
                                var rawRates = Array.isArray(apiResult.data) ? apiResult.data : (Array.isArray(apiResult.data.rates) ? apiResult.data.rates : []);
                                var sanitizedRates = zenkraftShippingHelper.sanitizeShippingData(rawRates, config.enabled);
                                zenkraftShippingHelper.writeSnapshot(shipment, estimateKey, ratesMap, eddPerMethod, sanitizedRates);
                            }
                        } else if (!apiResult.success) {
                            zenkraftShippingHelper.updateSessionShippingRates(null, shipment.UUID);
                            zenkraftShippingHelper.updateSessionEDD(null, shipment.UUID);
                            logger.error('Zenkraft rate API error: {0}', apiResult.error);
                        }
                    }
                }
            }
        } catch (e) {
            logger.error('Zenkraft shipping calculation exception: {0}', e.message);
        }

        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            try {
                if (config.enableEstimatedDeliveryDates) {
                    var dwSnapshot = zenkraftShippingHelper.readSnapshot(shipment);
                    var zenkraftIDStr = String(shippingMethod.custom.zenkraftID);
                    var dwStart = null;
                    var dwEnd = null;
                    if (dwSnapshot && dwSnapshot.rates) {
                        for (var ri = 0; ri < dwSnapshot.rates.length; ri++) {
                            var snapRate = dwSnapshot.rates[ri];
                            if (snapRate.service_type === zenkraftIDStr) {
                                if (snapRate.estimated_date) {
                                    dwStart = new Date(snapRate.estimated_date + 'T12:00:00.000Z');
                                    dwEnd = new Date(snapRate.estimated_date + 'T12:00:00.000Z');
                                } else if (snapRate.delivery_slots && snapRate.delivery_slots[0]) {
                                    dwStart = new Date(snapRate.delivery_slots[0].start_time);
                                    dwEnd = new Date(snapRate.delivery_slots[0].end_time || snapRate.delivery_slots[0].start_time);
                                }
                                break;
                            }
                        }
                    }
                    shipment.custom.deliveryWindowStartAt = dwStart;
                    shipment.custom.deliveryWindowEndAt = dwEnd;
                }
            } catch (eddErr) {
                logger.error('Failed to apply Zenkraft EDD to shipment: {0}', eddErr.message);
            }
        } else {
            shipment.custom.deliveryWindowStartAt = null;
            shipment.custom.deliveryWindowEndAt = null;
        }
    }

    if (missingRequiredData && !isMultiShipment) {
        logger.debug('Missing required data.');
        return new Status(Status.OK);
    }

    if (!empty(session.privacy.zenkraftCosts)) {
        try {
            var allShipmentRates = JSON.parse(session.privacy.zenkraftCosts);
            var applyIt = currentShipments.iterator();
            while (applyIt.hasNext()) {
                var s = applyIt.next();
                var shipmentRates = allShipmentRates[s.UUID];
                if (shipmentRates) {
                    zenkraftShippingHelper.calculateShippingCost(s, shipmentRates);
                } else if (isMultiShipment && s.productLineItems.size() === 0) {
                    var emptyShipmentLineItems = s.shippingLineItems.iterator();
                    while (emptyShipmentLineItems.hasNext()) {
                        emptyShipmentLineItems.next().setPriceValue(0);
                    }
                    logger.debug('Applied $0 cost for empty shipment: ' + s.UUID + ', shippingTotalPrice: ' + s.shippingTotalPrice);
                } else {
                    logger.warn('No Zenkraft rates and not an empty multi-shipment for UUID: ' + s.UUID + '. Price not updated.');
                }
            }
        } catch (e) {
            logger.error('Failed to apply Zenkraft session rates: {0}', e.message);
        }
    } else {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('OOTB shipping costs are applied.');
    }

    return new Status(Status.OK);
}

exports.calculate = calculate;
