/* global empty, session, request */
'use strict';

var Basket = require('dw/order/Basket');
var Logger = require('dw/system/Logger');
var ShippingMgr = require('dw/order/ShippingMgr');
var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');
var zenkraftShippingHelper = require('~/cartridge/scripts/helpers/zenkraftShippingHelper');

var logger = Logger.getLogger('zenkraft', 'calculateShipping');

/**
 * Whether any drop-off (collection point) attribute is still set on a shipment or its shipping
 * address. The storefront clears zenkraftDropOffData itself when the shopper switches away from a
 * drop-off method, so the derived attributes must be checked on their own.
 *
 * @param {dw.order.Shipment} shipment - The shipment to check
 * @returns {boolean} true when at least one drop-off attribute has a value
 */
function hasDropOffData(shipment) {
    return !empty(shipment.custom.zenkraftDropOffData)
        || !empty(shipment.custom.zenkraftDOPULocationCode)
        || !empty(shipment.custom.zenkraftDOPULocationName)
        || !!(shipment.shippingAddress && !empty(shipment.shippingAddress.custom.zenkraftDOPULocationName));
}

/**
 * Clears the stored drop-off (collection point) data from a shipment and its shipping address.
 *
 * @param {dw.order.Shipment} shipment - The shipment to clear
 */
function clearDropOffData(shipment) {
    Transaction.wrap(function () {
        shipment.custom.zenkraftDropOffData = null;
        shipment.custom.zenkraftDOPULocationCode = null;
        shipment.custom.zenkraftDOPULocationName = null;
        if (shipment.shippingAddress) {
            shipment.shippingAddress.custom.zenkraftDOPULocationName = null;
        }
    });
}

/**
 * Restores a basket whose order wasn't placed. beforePlaceOrder.js saves the shopper's shipping
 * address in zenkraftOriginalShippingAddress before replacing it with the collection point; a basket
 * that still has it in a later request didn't become an order (order creation failed without rolling
 * back, or a payment app failed the order and reopened the basket from it). The shopper's address is
 * put back and the collection point cleared, so the shopper chooses it again.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order being calculated
 */
function restoreAfterFailedOrder(lineItemCtnr) {
    if (!(lineItemCtnr instanceof Basket)) {
        return;
    }
    var shipmentsIt = lineItemCtnr.getShipments().iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();
        if (!empty(shipment.custom.zenkraftOriginalShippingAddress)) {
            var original = null;
            try {
                original = JSON.parse(String(shipment.custom.zenkraftOriginalShippingAddress));
            } catch (e) {
                logger.warn('[Zenkraft] calculateShipping: failed to parse zenkraftOriginalShippingAddress for shipment {0}: {1}', shipment.UUID, e.message);
            }
            // Saved in this very request: the order is still being created, so leave it alone
            if (original && original.requestID && original.requestID === request.requestID) {
                continue;
            }
            Transaction.wrap(function () {
                var addr = shipment.shippingAddress;
                if (original && addr) {
                    addr.setAddress1(original.address1 || null);
                    addr.setAddress2(original.address2 || null);
                    addr.setCity(original.city || null);
                    addr.setPostalCode(original.postalCode || null);
                    addr.setStateCode(original.stateCode || null);
                    if (original.countryCode) { addr.setCountryCode(original.countryCode); }
                    addr.setCompanyName(original.companyName || null);
                }
                shipment.custom.zenkraftOriginalShippingAddress = null;
            });
            clearDropOffData(shipment);
            logger.info('[Zenkraft] calculateShipping: order not placed; restored the shopper address and cleared the collection point for shipment {0}', shipment.UUID);
        }
    }
}

/**
 * Hook handler for sfcc.app.shipping.calculate.
 * Calls the Zenkraft rate API (with
 * request-hash deduplication) and overrides line-item prices with the returned rates in case zenrkaft shipping rate are enabled.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate shipping for
 * @returns {dw.system.Status} Status indicating success or failure
 */
function calculate(lineItemCtnr) {
    restoreAfterFailedOrder(lineItemCtnr);

    var config = zenkraftShippingHelper.getConfig();
    if (!config.enabled) {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('Zenkraft Shipping Rates are not enabled');
        return new Status(Status.OK);
    }

    var missingRequiredData = false;
    var currentShipments = lineItemCtnr.getShipments();
    var isMultiShipment = currentShipments.length > 1;
    var shipmentsIt = currentShipments.iterator();
    while (shipmentsIt.hasNext()) {
        var shipment = shipmentsIt.next();

        // Empty shipments left over from multi-shipment mode have no products to rate —
        // skip the API call so they don't pollute missingRequiredData for other shipments.
        if (isMultiShipment && shipment.productLineItems.size() === 0) {
            logger.debug('Skipping rate request for empty shipment: ' + shipment.UUID);
            continue;
        }

        var shippingMethod = shipment.shippingMethod;
        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            shipment.custom.zenkraftCarrier = shippingMethod.custom.zenkraftCarrier || config.carrier || '';
            shipment.custom.zenkraftShippingAccount = shippingMethod.custom.zenkraftShippingMethodAccountID;

            if (shippingMethod.custom.zenkraftDropOffMethod) {
                // Drop-off method — sync or clear the stored collection-point data.
                try {
                    if (!empty(shipment.custom.zenkraftDropOffData)) {
                        // Drop-off location was stored on the shipment together with the shipping
                        // method via the set-dropoff-location SCAPI call. Sync derived attributes so
                        // the rate request targets the collection point correctly.
                        var storedDropOff = JSON.parse(String(shipment.custom.zenkraftDropOffData));
                        // Raw Zenkraft locations only carry display_name; location_name wins when present.
                        var dropOffLocationName = storedDropOff.location_name || storedDropOff.display_name;
                        Transaction.wrap(function () {
                            if (storedDropOff.location_code) {
                                shipment.custom.zenkraftDOPULocationCode = storedDropOff.location_code;
                            }
                            if (dropOffLocationName) {
                                shipment.custom.zenkraftDOPULocationName = dropOffLocationName;
                                if (shipment.shippingAddress) {
                                    shipment.shippingAddress.custom.zenkraftDOPULocationName = dropOffLocationName;
                                }
                            }
                        });
                    } else {
                        clearDropOffData(shipment);
                    }
                } catch (e) {
                    logger.warn('[Zenkraft] calculateShipping: failed to process dropOff data: {0}', e.message);
                }
            } else if (hasDropOffData(shipment)) {
                // Zenkraft non-drop-off method — clear any stale collection-point data left
                // from a previous drop-off selection on this shipment.
                clearDropOffData(shipment);
            }
        } else {
            shipment.custom.zenkraftCarrier = null;
            shipment.custom.zenkraftShippingAccount = null;
            if (hasDropOffData(shipment)) {
                // Non-Zenkraft method — clear any stale collection-point data.
                clearDropOffData(shipment);
            }
        }

        try {
            var rateRequest = zenkraftShippingHelper.buildShippingRateRequest(shipment);
            if (!rateRequest) {
                missingRequiredData = true;
            } else {
                var estimateKey = zenkraftShippingHelper.buildEstimateKey(shipment);
                var storedKey = String(shipment.custom.zenkraftEstimateKey || '');
                var snapshot = zenkraftShippingHelper.readSnapshot(shipment);

                if (estimateKey && storedKey === estimateKey && snapshot) {
                    var cachedRates = {};
                    var cachedEDD = {};
                    Object.keys(snapshot.methods || {}).forEach(function (id) {
                        var m = snapshot.methods[id];
                        if (m.cost != null) { cachedRates[id] = m.cost; }
                        if (m.edd) { cachedEDD[id] = m.edd; }
                    });
                    zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(cachedRates), shipment.UUID);
                    zenkraftShippingHelper.updateSessionEDD(cachedEDD, shipment.UUID);
                } else {
                    var apiResult = zenkraftShippingHelper.callZenkraftAPI(rateRequest, shipment.UUID);
                    if (!apiResult.deduplicated) {
                        if (apiResult.success && apiResult.data) {
                            var ratesMap = zenkraftShippingHelper.buildRatesMapFromResponse(apiResult.data);
                            zenkraftShippingHelper.updateSessionShippingRates(JSON.stringify(ratesMap), shipment.UUID);
                            var eddPerMethod = zenkraftShippingHelper.buildEDDMapFromResponse(apiResult.data);
                            zenkraftShippingHelper.updateSessionEDD(eddPerMethod, shipment.UUID);
                            if (estimateKey) {
                                var rawRates = Array.isArray(apiResult.data) ? apiResult.data : (Array.isArray(apiResult.data.rates) ? apiResult.data.rates : []);
                                var sanitizedRates = zenkraftShippingHelper.sanitizeShippingData(rawRates, config.enabled);
                                zenkraftShippingHelper.writeSnapshot(shipment, estimateKey, ratesMap, eddPerMethod, sanitizedRates);
                            }
                        } else if (!apiResult.success) {
                            zenkraftShippingHelper.updateSessionShippingRates(null, shipment.UUID);
                            zenkraftShippingHelper.updateSessionEDD(null, shipment.UUID);
                            logger.error('Zenkraft rate API error: {0}', apiResult.error);
                        }
                    }
                }
            }
        } catch (e) {
            logger.error('Zenkraft shipping calculation exception: {0}', e.message);
        }

        if (shippingMethod && shippingMethod.custom.zenkraftID) {
            try {
                if (config.enableEstimatedDeliveryDates) {
                    var dwSnapshot = zenkraftShippingHelper.readSnapshot(shipment);
                    var zenkraftIDStr = String(shippingMethod.custom.zenkraftID);
                    var dwStart = null;
                    var dwEnd = null;
                    if (dwSnapshot && dwSnapshot.rates) {
                        for (var ri = 0; ri < dwSnapshot.rates.length; ri++) {
                            var snapRate = dwSnapshot.rates[ri];
                            if (snapRate.service_type === zenkraftIDStr) {
                                if (snapRate.estimated_date) {
                                    dwStart = new Date(snapRate.estimated_date + 'T12:00:00.000Z');
                                    dwEnd = new Date(snapRate.estimated_date + 'T12:00:00.000Z');
                                } else if (snapRate.delivery_slots && snapRate.delivery_slots[0]) {
                                    dwStart = new Date(snapRate.delivery_slots[0].start_time);
                                    dwEnd = new Date(snapRate.delivery_slots[0].end_time || snapRate.delivery_slots[0].start_time);
                                }
                                break;
                            }
                        }
                    }
                    shipment.custom.deliveryWindowStartAt = dwStart;
                    shipment.custom.deliveryWindowEndAt = dwEnd;
                }
            } catch (eddErr) {
                logger.error('Failed to apply Zenkraft EDD to shipment: {0}', eddErr.message);
            }
        } else {
            shipment.custom.deliveryWindowStartAt = null;
            shipment.custom.deliveryWindowEndAt = null;
        }
    }

    if (missingRequiredData && !isMultiShipment) {
        logger.debug('Missing required data.');
        return new Status(Status.OK);
    }

    if (!empty(session.privacy.zenkraftCosts)) {
        try {
            var allShipmentRates = JSON.parse(session.privacy.zenkraftCosts);
            var applyIt = currentShipments.iterator();
            while (applyIt.hasNext()) {
                var s = applyIt.next();
                var shipmentRates = allShipmentRates[s.UUID];
                if (shipmentRates) {
                    zenkraftShippingHelper.calculateShippingCost(s, shipmentRates);
                } else if (isMultiShipment && s.productLineItems.size() === 0) {
                    var emptyShipmentLineItems = s.shippingLineItems.iterator();
                    while (emptyShipmentLineItems.hasNext()) {
                        emptyShipmentLineItems.next().setPriceValue(0);
                    }
                    logger.debug('Applied $0 cost for empty shipment: ' + s.UUID + ', shippingTotalPrice: ' + s.shippingTotalPrice);
                } else {
                    logger.warn('No Zenkraft rates and not an empty multi-shipment for UUID: ' + s.UUID + '. Price not updated.');
                }
            }
        } catch (e) {
            logger.error('Failed to apply Zenkraft session rates: {0}', e.message);
        }
    } else {
        ShippingMgr.applyShippingCost(lineItemCtnr);
        logger.debug('OOTB shipping costs are applied.');
    }

    return new Status(Status.OK);
}

exports.calculate = calculate;
