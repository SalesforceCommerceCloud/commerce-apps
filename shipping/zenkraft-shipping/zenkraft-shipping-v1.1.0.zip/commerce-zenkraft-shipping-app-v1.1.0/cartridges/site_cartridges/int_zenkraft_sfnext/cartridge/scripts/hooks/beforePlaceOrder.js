/* global empty, request */
'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');

var logger = Logger.getLogger('zenkraft', 'beforePlaceOrder');

/**
 * Hook handler for dw.ocapi.shop.order.beforePOST.
 *
 * Stamps the selected collection-point address onto each drop-off shipment's
 * shippingAddress right before the order is created, so the order and every hook or
 * integration that reads it on creation (payment, fraud, export, confirmation emails)
 * carry the collection-point address. The address is intentionally left as the shopper's
 * home address during checkout, so switching back to a home-delivery method still works.
 *
 * The shopper's address is saved in zenkraftOriginalShippingAddress first: if the basket
 * doesn't become an order, calculateShipping.js restores it in a later request and clears
 * the collection point. A drop-off shipment without a collection point is refused, so the
 * shopper chooses the point again.
 *
 * @param {dw.order.Basket} basket - The basket the order is created from
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.beforePOST = function (basket) {
    try {
        var shipmentsIt = basket.getShipments().iterator();
        while (shipmentsIt.hasNext()) {
            var shipment = shipmentsIt.next();
            var shippingMethod = shipment.shippingMethod;
            if (!shippingMethod || !shippingMethod.custom.zenkraftDropOffMethod) {
                continue;
            }

            var dropOff = null;
            if (!empty(shipment.custom.zenkraftDropOffData)) {
                try {
                    dropOff = JSON.parse(String(shipment.custom.zenkraftDropOffData));
                } catch (parseErr) {
                    logger.warn('[Zenkraft] beforePlaceOrder: failed to parse zenkraftDropOffData for shipment {0}: {1}', shipment.UUID, parseErr.message);
                }
            }

            // A drop-off shipment must have a collection point, e.g. after a failed order cleared it
            if (!dropOff || !dropOff.location_code) {
                logger.warn('[Zenkraft] beforePlaceOrder: no collection point for drop-off shipment {0}', shipment.UUID);
                return new Status(Status.ERROR, 'ZENKRAFT_COLLECTION_POINT_REQUIRED', 'Choose a collection point for shipment ' + shipment.ID);
            }

            if (shipment.shippingAddress) {
                Transaction.wrap(function () {
                    var addr = shipment.shippingAddress;
                    // Keep the shopper's address so a basket that doesn't become an order can be restored.
                    // The address is saved once: on a retry the shipment may already hold the collection point's.
                    // The request ID is refreshed on every attempt, so calculateShipping.js never restores
                    // within the order request that is running now.
                    var saved = null;
                    if (!empty(shipment.custom.zenkraftOriginalShippingAddress)) {
                        try {
                            saved = JSON.parse(String(shipment.custom.zenkraftOriginalShippingAddress));
                        } catch (e) {
                            saved = null;
                        }
                    }
                    if (!saved) {
                        saved = {
                            address1: addr.address1,
                            address2: addr.address2,
                            city: addr.city,
                            postalCode: addr.postalCode,
                            stateCode: addr.stateCode,
                            countryCode: addr.countryCode ? addr.countryCode.value : null,
                            companyName: addr.companyName
                        };
                    }
                    saved.requestID = request.requestID;
                    shipment.custom.zenkraftOriginalShippingAddress = JSON.stringify(saved);
                    if (dropOff.street1) {
                        addr.setAddress1(dropOff.street1);
                        // The shopper's apartment / unit line does not belong to the collection point.
                        addr.setAddress2(null);
                    }
                    if (dropOff.city) { addr.setCity(dropOff.city); }
                    if (dropOff.postal_code) { addr.setPostalCode(dropOff.postal_code); }
                    if (dropOff.state) { addr.setStateCode(dropOff.state); }
                    if (dropOff.country) { addr.setCountryCode(String(dropOff.country).toUpperCase()); }
                    var locationName = dropOff.location_name || dropOff.company_name || dropOff.display_name;
                    if (locationName) { addr.setCompanyName(locationName); }
                });
                logger.info('[Zenkraft] beforePlaceOrder: stamped collection-point address for shipment {0}: {1}', shipment.UUID, dropOff.location_code);
            }
        }
    } catch (e) {
        logger.error('Zenkraft beforePlaceOrder: {0}', e.message);
    }

    return new Status(Status.OK);
};
