'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

/** Stand-in for dw.order.Basket: line item containers built from it count as baskets. */
function BasketStub() {}

describe('calculateShipping hook', function () {
    var calculateHook;
    var helperStub;
    var loggerStub;
    var shippingMgrStub;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        global.session = { privacy: {} };

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        helperStub = {
            getConfig: sinon.stub(),
            buildShippingRateRequest: sinon.stub(),
            callZenkraftAPI: sinon.stub(),
            buildRatesMapFromResponse: sinon.stub().returns({}),
            updateSessionShippingRates: sinon.stub(),
            buildEDDMapFromResponse: sinon.stub().returns({}),
            updateSessionEDD: sinon.stub(),
            calculateShippingCost: sinon.stub(),
            buildEstimateKey: sinon.stub().returns(null),
            readSnapshot: sinon.stub().returns(null),
            writeSnapshot: sinon.stub(),
            sanitizeShippingData: sinon.stub().returns([])
        };

        shippingMgrStub = {
            applyShippingCost: sinon.stub()
        };

        calculateHook = proxyquire(
            '../../../cartridge/scripts/hooks/calculateShipping',
            {
                'dw/order/Basket': BasketStub,
                'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                'dw/order/ShippingMgr': shippingMgrStub,
                'dw/system/Status': Status,
                'dw/system/Transaction': { wrap: function (fn) { return fn(); } },
                '~/cartridge/scripts/helpers/zenkraftShippingHelper': helperStub
            }
        );
    });

    afterEach(function () {
        delete global.empty;
        delete global.session;
        sinon.restore();
    });

    // -------------------------------------------------------------------------
    // Helpers to build test fixtures
    // -------------------------------------------------------------------------
    function createShipment(options) {
        options = options || {};
        var shippingLineItems = options.shippingLineItems || [];
        return {
            UUID: options.uuid || 'shipment-1',
            shippingMethod: options.shippingMethod || null,
            shippingLineItems: {
                iterator: function () {
                    var idx = 0;
                    return {
                        hasNext: function () { return idx < shippingLineItems.length; },
                        next: function () { return shippingLineItems[idx++]; }
                    };
                }
            },
            productLineItems: {
                size: sinon.stub().returns(options.productCount !== undefined ? options.productCount : 1)
            },
            custom: {}
        };
    }

    function createLineItemCtnr(shipments) {
        return {
            getShipments: function () {
                return {
                    length: shipments.length,
                    iterator: function () {
                        var idx = 0;
                        return {
                            hasNext: function () { return idx < shipments.length; },
                            next: function () { return shipments[idx++]; }
                        };
                    }
                };
            }
        };
    }

    // =========================================================================
    // When Zenkraft is disabled
    // =========================================================================
    describe('when Zenkraft shipping rates are disabled', function () {
        beforeEach(function () {
            helperStub.getConfig.returns({ enabled: false });
        });

        it('should call ShippingMgr.applyShippingCost and return Status.OK', function () {
            var ctnr = createLineItemCtnr([]);
            var result = calculateHook.calculate(ctnr);
            assert.equal(result.status, Status.OK);
            assert.isTrue(shippingMgrStub.applyShippingCost.calledOnce);
            assert.isTrue(shippingMgrStub.applyShippingCost.calledWith(ctnr));
        });

        it('should NOT call the Zenkraft API', function () {
            calculateHook.calculate(createLineItemCtnr([]));
            assert.isTrue(helperStub.callZenkraftAPI.notCalled);
        });
    });

    // =========================================================================
    // When Zenkraft is enabled
    // =========================================================================
    describe('when Zenkraft shipping rates are enabled', function () {
        beforeEach(function () {
            helperStub.getConfig.returns({ enabled: true, carrier: 'fedex', nativeMethodsFallback: false });
        });

        // --- Missing required data ---
        it('should return Status.OK when buildShippingRateRequest returns false', function () {
            helperStub.buildShippingRateRequest.returns(false);
            var ctnr = createLineItemCtnr([createShipment()]);
            var result = calculateHook.calculate(ctnr);
            assert.equal(result.status, Status.OK);
            assert.isTrue(helperStub.callZenkraftAPI.notCalled);
        });

        // --- Successful API response ---
        it('should call buildShippingRateRequest for each shipment', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var s1 = createShipment({ uuid: 'ship-1' });
            var s2 = createShipment({ uuid: 'ship-2' });
            calculateHook.calculate(createLineItemCtnr([s1, s2]));

            assert.equal(helperStub.buildShippingRateRequest.callCount, 2);
        });

        it('should update session with rates and EDD on a successful API response', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({
                success: true,
                data: { rates: [{ service_type: 'GROUND', total_cost: 9.99 }] },
                deduplicated: false
            });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.updateSessionShippingRates.calledOnce);
            assert.isTrue(helperStub.updateSessionEDD.calledOnce);
        });

        it('should pass the shipment UUID to updateSessionShippingRates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var shipment = createShipment({ uuid: 'ship-abc' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            var callArgs = helperStub.updateSessionShippingRates.firstCall.args;
            assert.equal(callArgs[1], 'ship-abc');
        });

        // --- Deduplicated API response ---
        it('should NOT update session when API response is deduplicated', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(helperStub.updateSessionShippingRates.notCalled);
            assert.isTrue(helperStub.updateSessionEDD.notCalled);
        });

        // --- API failure ---
        it('should clear session rates and EDD when API call fails', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'Timeout', deduplicated: false });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.updateSessionShippingRates.calledWith(null, 'ship-1'));
            assert.isTrue(helperStub.updateSessionEDD.calledWith(null, 'ship-1'));
        });

        it('should log an error when API call fails', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'Timeout', deduplicated: false });

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(loggerStub.error.called);
        });

        // --- Applying cached session rates ---
        it('should apply cached session rates to shipments when session contains rates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var shipmentRates = { GROUND: '9.99' };
            session.privacy.zenkraftCosts = JSON.stringify({ 'ship-1': shipmentRates });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.calculateShippingCost.calledOnce);
            assert.isTrue(helperStub.calculateShippingCost.calledWith(shipment, shipmentRates));
        });

        it('should fall back to ShippingMgr.applyShippingCost when session has no rates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'err', deduplicated: false });
            session.privacy.zenkraftCosts = null;

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(shippingMgrStub.applyShippingCost.calledOnce);
        });

        it('should return Status.OK on success', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var result = calculateHook.calculate(createLineItemCtnr([createShipment()]));
            assert.equal(result.status, Status.OK);
        });

        // --- EDD application ---
        it('should set deliveryWindowStartAt and deliveryWindowEndAt on shipment when EDD is enabled and snapshot has the selected rate', function () {
            helperStub.getConfig.returns({ enabled: true, carrier: 'fedex', nativeMethodsFallback: false, enableEstimatedDeliveryDates: true });
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });
            helperStub.readSnapshot = sinon.stub().returns({
                methods: { GROUND: { cost: 9.99 } },
                rates: [{ service_type: 'GROUND', estimated_date: '2025-01-01' }]
            });

            var method = { custom: { zenkraftID: 'GROUND' } };
            var shipment = createShipment({ uuid: 'ship-1', shippingMethod: method });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.instanceOf(shipment.custom.deliveryWindowStartAt, Date);
            assert.instanceOf(shipment.custom.deliveryWindowEndAt, Date);
        });

        it('should set deliveryWindowStartAt and deliveryWindowEndAt to null when method has no zenkraftID', function () {
            helperStub.buildShippingRateRequest.returns(false);

            var shipment = createShipment({ uuid: 'ship-1', shippingMethod: null });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isNull(shipment.custom.deliveryWindowStartAt);
            assert.isNull(shipment.custom.deliveryWindowEndAt);
        });

        // --- Multi-shipment: skip empty shipments ---
        it('should skip buildShippingRateRequest for empty shipments in multi-shipment mode', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var fullShipment = createShipment({ uuid: 'ship-1', productCount: 2 });
            var emptyShipment = createShipment({ uuid: 'ship-empty', productCount: 0 });
            var ctnr = createLineItemCtnr([fullShipment, emptyShipment]);

            calculateHook.calculate(ctnr);

            assert.equal(helperStub.buildShippingRateRequest.callCount, 1);
            assert.isTrue(helperStub.buildShippingRateRequest.calledWith(fullShipment));
            assert.isFalse(helperStub.buildShippingRateRequest.calledWith(emptyShipment));
        });

        it('should zero out line item prices for empty shipments in multi-shipment mode', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var setPriceStub = sinon.stub();
            var mockLineItem = { setPriceValue: setPriceStub };
            var emptyShipment = createShipment({
                uuid: 'ship-empty',
                productCount: 0,
                shippingLineItems: [mockLineItem]
            });

            var fullShipment = createShipment({ uuid: 'ship-1', productCount: 1 });
            var shipmentRates = { GROUND: '9.99' };
            session.privacy.zenkraftCosts = JSON.stringify({
                'ship-1': shipmentRates,
                'ship-empty': null
            });

            calculateHook.calculate(createLineItemCtnr([fullShipment, emptyShipment]));

            assert.isTrue(setPriceStub.calledWith(0));
        });

        // --- Drop-off (collection point) data ---
        describe('drop-off data', function () {
            var dropOffMethod = { custom: { zenkraftID: 'UPS_ACCESS_POINT', zenkraftDropOffMethod: true } };
            var standardMethod = { custom: { zenkraftID: 'GROUND' } };
            var nativeMethod = { custom: {} };

            function createDropOffShipment(shippingMethod, dropOffData) {
                var shipment = createShipment({ uuid: 'ship-1', shippingMethod: shippingMethod });
                shipment.shippingAddress = { custom: {} };
                shipment.custom.zenkraftDropOffData = dropOffData ? JSON.stringify(dropOffData) : null;
                return shipment;
            }

            beforeEach(function () {
                helperStub.buildShippingRateRequest.returns(false);
            });

            it('should sync location code and display_name onto the shipment and shipping address for a drop-off method', function () {
                var shipment = createDropOffShipment(dropOffMethod, { location_code: 'LOC-1', display_name: 'Corner Shop' });
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.equal(shipment.custom.zenkraftDOPULocationCode, 'LOC-1');
                assert.equal(shipment.custom.zenkraftDOPULocationName, 'Corner Shop');
                assert.equal(shipment.shippingAddress.custom.zenkraftDOPULocationName, 'Corner Shop');
                assert.isNotNull(shipment.custom.zenkraftDropOffData);
            });

            it('should prefer location_name over display_name when both are present', function () {
                var shipment = createDropOffShipment(dropOffMethod, { location_code: 'LOC-1', display_name: 'Corner Shop', location_name: 'Corner Shop Ltd' });
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.equal(shipment.custom.zenkraftDOPULocationName, 'Corner Shop Ltd');
                assert.equal(shipment.shippingAddress.custom.zenkraftDOPULocationName, 'Corner Shop Ltd');
            });

            it('should clear drop-off data when a non-drop-off Zenkraft method is selected', function () {
                var shipment = createDropOffShipment(standardMethod, { location_code: 'LOC-1', display_name: 'Corner Shop' });
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDropOffData);
                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.custom.zenkraftDOPULocationName);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });

            it('should clear drop-off data when a non-Zenkraft method is selected', function () {
                var shipment = createDropOffShipment(nativeMethod, { location_code: 'LOC-1', display_name: 'Corner Shop' });
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDropOffData);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });

            it('should clear derived attributes left behind when the storefront already cleared zenkraftDropOffData (Zenkraft method)', function () {
                var shipment = createDropOffShipment(standardMethod, null);
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.custom.zenkraftDOPULocationName = 'Corner Shop';
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.custom.zenkraftDOPULocationName);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });

            it('should clear derived attributes left behind when the storefront already cleared zenkraftDropOffData (non-Zenkraft method)', function () {
                var shipment = createDropOffShipment(nativeMethod, null);
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.custom.zenkraftDOPULocationName);
            });

            it('should not write drop-off attributes for a non-drop-off shipment that never had any', function () {
                var shipment = createDropOffShipment(standardMethod, null);
                delete shipment.custom.zenkraftDropOffData;
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.notProperty(shipment.custom, 'zenkraftDOPULocationCode');
                assert.notProperty(shipment.shippingAddress.custom, 'zenkraftDOPULocationName');
            });

            it('should clear derived attributes when a drop-off method has no stored location', function () {
                var shipment = createDropOffShipment(dropOffMethod, null);
                shipment.custom.zenkraftDOPULocationCode = 'OLD';
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Old Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });
        });

        // --- Collection point address copied onto the shipping address ---
        describe('collection point address', function () {
            var dropOffMethod = { custom: { zenkraftID: 'UPS_ACCESS_POINT', zenkraftDropOffMethod: true } };
            var standardMethod = { custom: { zenkraftID: 'GROUND' } };
            var home = {
                address1: '5 Home Road', address2: 'Flat 2', city: 'Leeds', postalCode: 'LS1 1AA',
                stateCode: null, countryCode: 'GB', companyName: null
            };
            var point = {
                location_code: 'LOC-1', location_name: 'Corner Shop', street1: '1 High Street',
                city: 'York', postal_code: 'YO1 7HH', country: 'gb'
            };

            /** Shipping address stub whose setters update its fields, like dw.order.OrderAddress. */
            function createAddress(fields) {
                var addr = { custom: {} };
                ['address1', 'address2', 'city', 'postalCode', 'stateCode', 'companyName'].forEach(function (field) {
                    addr[field] = fields[field];
                    addr['set' + field.charAt(0).toUpperCase() + field.slice(1)] = sinon.spy(function (value) {
                        addr[field] = value;
                    });
                });
                addr.countryCode = fields.countryCode ? { value: fields.countryCode } : null;
                addr.setCountryCode = sinon.spy(function (value) {
                    addr.countryCode = value ? { value: value } : null;
                });
                return addr;
            }

            function createBasketShipment(shippingMethod, dropOff, uuid) {
                var shipment = createShipment({ uuid: uuid || 'ship-1', shippingMethod: shippingMethod });
                shipment.shippingAddress = createAddress(home);
                shipment.custom.zenkraftDropOffData = dropOff ? JSON.stringify(dropOff) : null;
                return shipment;
            }

            function calculateBasket(shipments, billingAddress) {
                var ctnr = createLineItemCtnr([].concat(shipments));
                ctnr.billingAddress = billingAddress || null;
                Object.setPrototypeOf(ctnr, BasketStub.prototype);
                return calculateHook.calculate(ctnr);
            }

            beforeEach(function () {
                helperStub.buildShippingRateRequest.returns(false);
            });

            it('should copy the collection point onto the shipping address and save the shopper address', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);

                var addr = shipment.shippingAddress;
                assert.equal(addr.address1, '1 High Street');
                assert.isNull(addr.address2);
                assert.equal(addr.city, 'York');
                assert.equal(addr.postalCode, 'YO1 7HH');
                assert.equal(addr.countryCode.value, 'GB');
                assert.equal(addr.companyName, 'Corner Shop');
                assert.deepEqual(JSON.parse(shipment.custom.zenkraftOriginalShippingAddress), Object.assign({}, home, {
                    locationCode: 'LOC-1',
                    copied: { address1: '1 High Street', city: 'York', postalCode: 'YO1 7HH', stateCode: '', countryCode: 'GB' }
                }));
            });

            it('should copy the collection point before the shipment is rated', function () {
                var addressAtRating = null;
                helperStub.buildShippingRateRequest.callsFake(function (s) {
                    addressAtRating = s.shippingAddress.address1;
                    return false;
                });
                calculateBasket(createBasketShipment(dropOffMethod, point));

                assert.equal(addressAtRating, '1 High Street');
            });

            it('should copy the collection point when Zenkraft rates are disabled', function () {
                helperStub.getConfig.returns({ enabled: false });
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);

                assert.equal(shipment.shippingAddress.address1, '1 High Street');
            });

            it('should leave a copied shipment alone on the next calculation', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                var savedAfterCopy = shipment.custom.zenkraftOriginalShippingAddress;
                shipment.shippingAddress.setAddress1.resetHistory();
                calculateBasket(shipment);

                assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
                assert.equal(shipment.custom.zenkraftOriginalShippingAddress, savedAfterCopy);
            });

            it('should copy another collection point and keep the saved shopper address', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                shipment.custom.zenkraftDropOffData = JSON.stringify({
                    location_code: 'LOC-2', location_name: 'Station Kiosk', street1: '2 Station Road',
                    city: 'York', postal_code: 'YO24 1AB', country: 'GB'
                });
                calculateBasket(shipment);

                assert.equal(shipment.shippingAddress.address1, '2 Station Road');
                assert.equal(shipment.shippingAddress.companyName, 'Station Kiosk');
                var saved = JSON.parse(shipment.custom.zenkraftOriginalShippingAddress);
                assert.equal(saved.address1, '5 Home Road');
                assert.equal(saved.locationCode, 'LOC-2');
            });

            it('should copy the point name back when the address form dropped the company', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                shipment.shippingAddress.companyName = null;
                calculateBasket(shipment);

                assert.equal(shipment.shippingAddress.companyName, 'Corner Shop');
                assert.equal(JSON.parse(shipment.custom.zenkraftOriginalShippingAddress).address1, '5 Home Road');
            });

            it('should put the shopper address back when another method is selected', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                shipment.shippingMethod = standardMethod;
                shipment.custom.zenkraftDropOffData = null;
                calculateBasket(shipment);

                var addr = shipment.shippingAddress;
                assert.equal(addr.address1, '5 Home Road');
                assert.equal(addr.address2, 'Flat 2');
                assert.equal(addr.city, 'Leeds');
                assert.equal(addr.postalCode, 'LS1 1AA');
                assert.equal(addr.countryCode.value, 'GB');
                assert.isNull(addr.companyName);
                assert.isNull(shipment.custom.zenkraftOriginalShippingAddress);
                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
            });

            it('should put the shopper address back when the drop-off method has no collection point', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                shipment.custom.zenkraftDropOffData = null;
                calculateBasket(shipment);

                assert.equal(shipment.shippingAddress.address1, '5 Home Road');
                assert.isNull(shipment.custom.zenkraftOriginalShippingAddress);
            });

            it('should keep an address the shopper entered after the copy and clear the collection point', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                shipment.shippingAddress.address1 = '9 New Street';
                shipment.shippingAddress.city = 'Hull';
                shipment.shippingAddress.setAddress1.resetHistory();
                calculateBasket(shipment);

                assert.equal(shipment.shippingAddress.address1, '9 New Street');
                assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
                assert.isNull(shipment.custom.zenkraftOriginalShippingAddress);
                assert.isNull(shipment.custom.zenkraftDropOffData);
                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
            });

            it('should only change drop-off shipments', function () {
                var homeShipment = createBasketShipment(standardMethod, null, 'ship-home');
                var dropOffShipment = createBasketShipment(dropOffMethod, point);
                calculateBasket([homeShipment, dropOffShipment]);

                assert.isTrue(homeShipment.shippingAddress.setAddress1.notCalled);
                assert.notProperty(homeShipment.custom, 'zenkraftOriginalShippingAddress');
                assert.equal(dropOffShipment.shippingAddress.address1, '1 High Street');
            });

            it('should replace a saved address it can\'t use', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                // Saved by an earlier build, without the copied fields
                shipment.custom.zenkraftOriginalShippingAddress = JSON.stringify({ requestID: 'req-1', address1: 'Old Road' });
                calculateBasket(shipment);

                var saved = JSON.parse(shipment.custom.zenkraftOriginalShippingAddress);
                assert.equal(saved.address1, '5 Home Road');
                assert.equal(saved.locationCode, 'LOC-1');
            });

            it('should clear an unreadable saved address without changing the shipping address', function () {
                var shipment = createBasketShipment(standardMethod, null);
                shipment.custom.zenkraftOriginalShippingAddress = '{not json';
                calculateBasket(shipment);

                assert.isNull(shipment.custom.zenkraftOriginalShippingAddress);
                assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
            });

            it('should not change the address of an order', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
                assert.notProperty(shipment.custom, 'zenkraftOriginalShippingAddress');
            });

            it('should give the billing address the shopper address when the storefront copied the collection point to it', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                // The payment step copies the shipping address, now the collection point, to billing
                var billing = createAddress({
                    address1: '1 High Street', address2: null, city: 'York', postalCode: 'YO1 7HH',
                    stateCode: null, countryCode: 'GB', companyName: 'Corner Shop'
                });
                billing.firstName = 'Ann';
                calculateBasket(shipment, billing);

                assert.equal(billing.address1, '5 Home Road');
                assert.equal(billing.address2, 'Flat 2');
                assert.equal(billing.city, 'Leeds');
                assert.equal(billing.postalCode, 'LS1 1AA');
                assert.equal(billing.countryCode.value, 'GB');
                assert.isNull(billing.companyName);
                assert.equal(billing.firstName, 'Ann');
                assert.equal(shipment.shippingAddress.address1, '1 High Street');
            });

            it('should leave a billing address that is not the collection point alone', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                var billing = createAddress({ address1: '7 Office Park', city: 'Leeds', postalCode: 'LS2 9JT', countryCode: 'GB' });
                calculateBasket(shipment, billing);

                assert.isTrue(billing.setAddress1.notCalled);
                assert.equal(billing.address1, '7 Office Park');
            });

            it('should give the billing address the shopper address when the shopper switches back to home delivery in the same request', function () {
                var shipment = createBasketShipment(dropOffMethod, point);
                calculateBasket(shipment);
                var billing = createAddress({ address1: '1 High Street', city: 'York', postalCode: 'YO1 7HH', countryCode: 'GB', companyName: 'Corner Shop' });
                shipment.shippingMethod = standardMethod;
                shipment.custom.zenkraftDropOffData = null;
                calculateBasket(shipment, billing);

                assert.equal(billing.address1, '5 Home Road');
                assert.equal(shipment.shippingAddress.address1, '5 Home Road');
                assert.isNull(shipment.custom.zenkraftOriginalShippingAddress);
            });
        });
    });
});
