'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

/** Stand-in for dw.order.Basket: line item containers built from it count as baskets. */
function BasketStub() {}

describe('calculateShipping hook', function () {
    var calculateHook;
    var helperStub;
    var loggerStub;
    var shippingMgrStub;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        global.session = { privacy: {} };
        global.request = { requestID: 'req-later' };

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        helperStub = {
            getConfig: sinon.stub(),
            buildShippingRateRequest: sinon.stub(),
            callZenkraftAPI: sinon.stub(),
            buildRatesMapFromResponse: sinon.stub().returns({}),
            updateSessionShippingRates: sinon.stub(),
            buildEDDMapFromResponse: sinon.stub().returns({}),
            updateSessionEDD: sinon.stub(),
            calculateShippingCost: sinon.stub(),
            buildEstimateKey: sinon.stub().returns(null),
            readSnapshot: sinon.stub().returns(null),
            writeSnapshot: sinon.stub(),
            sanitizeShippingData: sinon.stub().returns([])
        };

        shippingMgrStub = {
            applyShippingCost: sinon.stub()
        };

        calculateHook = proxyquire(
            '../../../cartridge/scripts/hooks/calculateShipping',
            {
                'dw/order/Basket': BasketStub,
                'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                'dw/order/ShippingMgr': shippingMgrStub,
                'dw/system/Status': Status,
                'dw/system/Transaction': { wrap: function (fn) { return fn(); } },
                '~/cartridge/scripts/helpers/zenkraftShippingHelper': helperStub
            }
        );
    });

    afterEach(function () {
        delete global.empty;
        delete global.session;
        delete global.request;
        sinon.restore();
    });

    // -------------------------------------------------------------------------
    // Helpers to build test fixtures
    // -------------------------------------------------------------------------
    function createShipment(options) {
        options = options || {};
        var shippingLineItems = options.shippingLineItems || [];
        return {
            UUID: options.uuid || 'shipment-1',
            shippingMethod: options.shippingMethod || null,
            shippingLineItems: {
                iterator: function () {
                    var idx = 0;
                    return {
                        hasNext: function () { return idx < shippingLineItems.length; },
                        next: function () { return shippingLineItems[idx++]; }
                    };
                }
            },
            productLineItems: {
                size: sinon.stub().returns(options.productCount !== undefined ? options.productCount : 1)
            },
            custom: {}
        };
    }

    function createLineItemCtnr(shipments) {
        return {
            getShipments: function () {
                return {
                    length: shipments.length,
                    iterator: function () {
                        var idx = 0;
                        return {
                            hasNext: function () { return idx < shipments.length; },
                            next: function () { return shipments[idx++]; }
                        };
                    }
                };
            }
        };
    }

    // =========================================================================
    // When Zenkraft is disabled
    // =========================================================================
    describe('when Zenkraft shipping rates are disabled', function () {
        beforeEach(function () {
            helperStub.getConfig.returns({ enabled: false });
        });

        it('should call ShippingMgr.applyShippingCost and return Status.OK', function () {
            var ctnr = createLineItemCtnr([]);
            var result = calculateHook.calculate(ctnr);
            assert.equal(result.status, Status.OK);
            assert.isTrue(shippingMgrStub.applyShippingCost.calledOnce);
            assert.isTrue(shippingMgrStub.applyShippingCost.calledWith(ctnr));
        });

        it('should NOT call the Zenkraft API', function () {
            calculateHook.calculate(createLineItemCtnr([]));
            assert.isTrue(helperStub.callZenkraftAPI.notCalled);
        });
    });

    // =========================================================================
    // When Zenkraft is enabled
    // =========================================================================
    describe('when Zenkraft shipping rates are enabled', function () {
        beforeEach(function () {
            helperStub.getConfig.returns({ enabled: true, carrier: 'fedex', nativeMethodsFallback: false });
        });

        // --- Missing required data ---
        it('should return Status.OK when buildShippingRateRequest returns false', function () {
            helperStub.buildShippingRateRequest.returns(false);
            var ctnr = createLineItemCtnr([createShipment()]);
            var result = calculateHook.calculate(ctnr);
            assert.equal(result.status, Status.OK);
            assert.isTrue(helperStub.callZenkraftAPI.notCalled);
        });

        // --- Successful API response ---
        it('should call buildShippingRateRequest for each shipment', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var s1 = createShipment({ uuid: 'ship-1' });
            var s2 = createShipment({ uuid: 'ship-2' });
            calculateHook.calculate(createLineItemCtnr([s1, s2]));

            assert.equal(helperStub.buildShippingRateRequest.callCount, 2);
        });

        it('should update session with rates and EDD on a successful API response', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({
                success: true,
                data: { rates: [{ service_type: 'GROUND', total_cost: 9.99 }] },
                deduplicated: false
            });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.updateSessionShippingRates.calledOnce);
            assert.isTrue(helperStub.updateSessionEDD.calledOnce);
        });

        it('should pass the shipment UUID to updateSessionShippingRates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var shipment = createShipment({ uuid: 'ship-abc' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            var callArgs = helperStub.updateSessionShippingRates.firstCall.args;
            assert.equal(callArgs[1], 'ship-abc');
        });

        // --- Deduplicated API response ---
        it('should NOT update session when API response is deduplicated', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(helperStub.updateSessionShippingRates.notCalled);
            assert.isTrue(helperStub.updateSessionEDD.notCalled);
        });

        // --- API failure ---
        it('should clear session rates and EDD when API call fails', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'Timeout', deduplicated: false });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.updateSessionShippingRates.calledWith(null, 'ship-1'));
            assert.isTrue(helperStub.updateSessionEDD.calledWith(null, 'ship-1'));
        });

        it('should log an error when API call fails', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'Timeout', deduplicated: false });

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(loggerStub.error.called);
        });

        // --- Applying cached session rates ---
        it('should apply cached session rates to shipments when session contains rates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var shipmentRates = { GROUND: '9.99' };
            session.privacy.zenkraftCosts = JSON.stringify({ 'ship-1': shipmentRates });

            var shipment = createShipment({ uuid: 'ship-1' });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isTrue(helperStub.calculateShippingCost.calledOnce);
            assert.isTrue(helperStub.calculateShippingCost.calledWith(shipment, shipmentRates));
        });

        it('should fall back to ShippingMgr.applyShippingCost when session has no rates', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: false, error: 'err', deduplicated: false });
            session.privacy.zenkraftCosts = null;

            calculateHook.calculate(createLineItemCtnr([createShipment()]));

            assert.isTrue(shippingMgrStub.applyShippingCost.calledOnce);
        });

        it('should return Status.OK on success', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var result = calculateHook.calculate(createLineItemCtnr([createShipment()]));
            assert.equal(result.status, Status.OK);
        });

        // --- EDD application ---
        it('should set deliveryWindowStartAt and deliveryWindowEndAt on shipment when EDD is enabled and snapshot has the selected rate', function () {
            helperStub.getConfig.returns({ enabled: true, carrier: 'fedex', nativeMethodsFallback: false, enableEstimatedDeliveryDates: true });
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });
            helperStub.readSnapshot = sinon.stub().returns({
                methods: { GROUND: { cost: 9.99 } },
                rates: [{ service_type: 'GROUND', estimated_date: '2025-01-01' }]
            });

            var method = { custom: { zenkraftID: 'GROUND' } };
            var shipment = createShipment({ uuid: 'ship-1', shippingMethod: method });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.instanceOf(shipment.custom.deliveryWindowStartAt, Date);
            assert.instanceOf(shipment.custom.deliveryWindowEndAt, Date);
        });

        it('should set deliveryWindowStartAt and deliveryWindowEndAt to null when method has no zenkraftID', function () {
            helperStub.buildShippingRateRequest.returns(false);

            var shipment = createShipment({ uuid: 'ship-1', shippingMethod: null });
            calculateHook.calculate(createLineItemCtnr([shipment]));

            assert.isNull(shipment.custom.deliveryWindowStartAt);
            assert.isNull(shipment.custom.deliveryWindowEndAt);
        });

        // --- Multi-shipment: skip empty shipments ---
        it('should skip buildShippingRateRequest for empty shipments in multi-shipment mode', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, data: {}, deduplicated: false });

            var fullShipment = createShipment({ uuid: 'ship-1', productCount: 2 });
            var emptyShipment = createShipment({ uuid: 'ship-empty', productCount: 0 });
            var ctnr = createLineItemCtnr([fullShipment, emptyShipment]);

            calculateHook.calculate(ctnr);

            assert.equal(helperStub.buildShippingRateRequest.callCount, 1);
            assert.isTrue(helperStub.buildShippingRateRequest.calledWith(fullShipment));
            assert.isFalse(helperStub.buildShippingRateRequest.calledWith(emptyShipment));
        });

        it('should zero out line item prices for empty shipments in multi-shipment mode', function () {
            helperStub.buildShippingRateRequest.returns({ shipment: {} });
            helperStub.callZenkraftAPI.returns({ success: true, deduplicated: true });

            var setPriceStub = sinon.stub();
            var mockLineItem = { setPriceValue: setPriceStub };
            var emptyShipment = createShipment({
                uuid: 'ship-empty',
                productCount: 0,
                shippingLineItems: [mockLineItem]
            });

            var fullShipment = createShipment({ uuid: 'ship-1', productCount: 1 });
            var shipmentRates = { GROUND: '9.99' };
            session.privacy.zenkraftCosts = JSON.stringify({
                'ship-1': shipmentRates,
                'ship-empty': null
            });

            calculateHook.calculate(createLineItemCtnr([fullShipment, emptyShipment]));

            assert.isTrue(setPriceStub.calledWith(0));
        });

        // --- Drop-off (collection point) data ---
        describe('drop-off data', function () {
            var dropOffMethod = { custom: { zenkraftID: 'UPS_ACCESS_POINT', zenkraftDropOffMethod: true } };
            var standardMethod = { custom: { zenkraftID: 'GROUND' } };
            var nativeMethod = { custom: {} };

            function createDropOffShipment(shippingMethod, dropOffData) {
                var shipment = createShipment({ uuid: 'ship-1', shippingMethod: shippingMethod });
                shipment.shippingAddress = { custom: {} };
                shipment.custom.zenkraftDropOffData = dropOffData ? JSON.stringify(dropOffData) : null;
                return shipment;
            }

            beforeEach(function () {
                helperStub.buildShippingRateRequest.returns(false);
            });

            it('should sync location code and display_name onto the shipment and shipping address for a drop-off method', function () {
                var shipment = createDropOffShipment(dropOffMethod, { location_code: 'LOC-1', display_name: 'Corner Shop' });
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.equal(shipment.custom.zenkraftDOPULocationCode, 'LOC-1');
                assert.equal(shipment.custom.zenkraftDOPULocationName, 'Corner Shop');
                assert.equal(shipment.shippingAddress.custom.zenkraftDOPULocationName, 'Corner Shop');
                assert.isNotNull(shipment.custom.zenkraftDropOffData);
            });

            it('should prefer location_name over display_name when both are present', function () {
                var shipment = createDropOffShipment(dropOffMethod, { location_code: 'LOC-1', display_name: 'Corner Shop', location_name: 'Corner Shop Ltd' });
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.equal(shipment.custom.zenkraftDOPULocationName, 'Corner Shop Ltd');
                assert.equal(shipment.shippingAddress.custom.zenkraftDOPULocationName, 'Corner Shop Ltd');
            });

            it('should clear drop-off data when a non-drop-off Zenkraft method is selected', function () {
                var shipment = createDropOffShipment(standardMethod, { location_code: 'LOC-1', display_name: 'Corner Shop' });
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDropOffData);
                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.custom.zenkraftDOPULocationName);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });

            it('should clear drop-off data when a non-Zenkraft method is selected', function () {
                var shipment = createDropOffShipment(nativeMethod, { location_code: 'LOC-1', display_name: 'Corner Shop' });
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDropOffData);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });

            it('should clear derived attributes left behind when the storefront already cleared zenkraftDropOffData (Zenkraft method)', function () {
                var shipment = createDropOffShipment(standardMethod, null);
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.custom.zenkraftDOPULocationName = 'Corner Shop';
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.custom.zenkraftDOPULocationName);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });

            it('should clear derived attributes left behind when the storefront already cleared zenkraftDropOffData (non-Zenkraft method)', function () {
                var shipment = createDropOffShipment(nativeMethod, null);
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.custom.zenkraftDOPULocationName = 'Corner Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.custom.zenkraftDOPULocationName);
            });

            it('should not write drop-off attributes for a non-drop-off shipment that never had any', function () {
                var shipment = createDropOffShipment(standardMethod, null);
                delete shipment.custom.zenkraftDropOffData;
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.notProperty(shipment.custom, 'zenkraftDOPULocationCode');
                assert.notProperty(shipment.shippingAddress.custom, 'zenkraftDOPULocationName');
            });

            it('should clear derived attributes when a drop-off method has no stored location', function () {
                var shipment = createDropOffShipment(dropOffMethod, null);
                shipment.custom.zenkraftDOPULocationCode = 'OLD';
                shipment.shippingAddress.custom.zenkraftDOPULocationName = 'Old Shop';
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(shipment.shippingAddress.custom.zenkraftDOPULocationName);
            });
        });

        // --- Basket whose order wasn't placed ---
        describe('restoring a basket after a failed order', function () {
            var dropOffMethod = { custom: { zenkraftID: 'UPS_ACCESS_POINT', zenkraftDropOffMethod: true } };
            var original = {
                address1: '5 Home Road', address2: 'Flat 2', city: 'Leeds', postalCode: 'LS1 1AA',
                stateCode: null, countryCode: 'GB', companyName: null
            };

            function createStampedShipment(savedInRequest) {
                var shipment = createShipment({ uuid: 'ship-1', shippingMethod: dropOffMethod });
                shipment.shippingAddress = {
                    custom: { zenkraftDOPULocationName: 'Corner Shop' },
                    setAddress1: sinon.stub(),
                    setAddress2: sinon.stub(),
                    setCity: sinon.stub(),
                    setPostalCode: sinon.stub(),
                    setStateCode: sinon.stub(),
                    setCountryCode: sinon.stub(),
                    setCompanyName: sinon.stub()
                };
                shipment.custom.zenkraftDropOffData = JSON.stringify({ location_code: 'LOC-1', display_name: 'Corner Shop' });
                shipment.custom.zenkraftDOPULocationCode = 'LOC-1';
                shipment.custom.zenkraftOriginalShippingAddress = JSON.stringify(Object.assign({ requestID: savedInRequest }, original));
                return shipment;
            }

            function asBasket(ctnr) {
                Object.setPrototypeOf(ctnr, BasketStub.prototype);
                return ctnr;
            }

            beforeEach(function () {
                helperStub.buildShippingRateRequest.returns(false);
            });

            it('should restore the shopper address and clear the collection point when the address was saved in an earlier request', function () {
                var shipment = createStampedShipment('req-order');
                calculateHook.calculate(asBasket(createLineItemCtnr([shipment])));

                var addr = shipment.shippingAddress;
                assert.isTrue(addr.setAddress1.calledWith('5 Home Road'));
                assert.isTrue(addr.setAddress2.calledWith('Flat 2'));
                assert.isTrue(addr.setCity.calledWith('Leeds'));
                assert.isTrue(addr.setPostalCode.calledWith('LS1 1AA'));
                assert.isTrue(addr.setCountryCode.calledWith('GB'));
                assert.isTrue(addr.setCompanyName.calledWith(null));
                assert.isNull(shipment.custom.zenkraftOriginalShippingAddress);
                assert.isNull(shipment.custom.zenkraftDropOffData);
                assert.isNull(shipment.custom.zenkraftDOPULocationCode);
                assert.isNull(addr.custom.zenkraftDOPULocationName);
            });

            it('should leave the shipment alone while the order is still being created in the same request', function () {
                var shipment = createStampedShipment('req-later');
                calculateHook.calculate(asBasket(createLineItemCtnr([shipment])));

                assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
                assert.isNotNull(shipment.custom.zenkraftOriginalShippingAddress);
                assert.isNotNull(shipment.custom.zenkraftDropOffData);
            });

            it('should not restore anything on an order', function () {
                var shipment = createStampedShipment('req-order');
                calculateHook.calculate(createLineItemCtnr([shipment]));

                assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
                assert.isNotNull(shipment.custom.zenkraftOriginalShippingAddress);
            });
        });
    });
});
