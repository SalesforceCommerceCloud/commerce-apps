'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

describe('beforePlaceOrder hook', function () {
    var beforePlaceOrder;
    var loggerStub;

    var dropOffMethod = { custom: { zenkraftDropOffMethod: true } };
    var standardMethod = { custom: { zenkraftID: 'GROUND' } };
    var dropOffData = {
        location_code: 'LOC-1',
        display_name: 'Corner Shop',
        street1: '1 High Street',
        city: 'London',
        postal_code: 'SW1A 1AA',
        country: 'gb'
    };

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        global.request = { requestID: 'req-order' };

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        beforePlaceOrder = proxyquire(
            '../../../cartridge/scripts/hooks/beforePlaceOrder',
            {
                'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                'dw/system/Status': Status,
                'dw/system/Transaction': { wrap: function (fn) { return fn(); } }
            }
        );
    });

    afterEach(function () {
        delete global.empty;
        delete global.request;
        sinon.restore();
    });

    // -------------------------------------------------------------------------
    // Helpers to build test fixtures
    // -------------------------------------------------------------------------
    function createAddress() {
        return {
            address1: '5 Home Road',
            address2: 'Flat 2',
            city: 'Leeds',
            postalCode: 'LS1 1AA',
            stateCode: null,
            countryCode: { value: 'GB' },
            companyName: null,
            setAddress1: sinon.stub(),
            setAddress2: sinon.stub(),
            setCity: sinon.stub(),
            setPostalCode: sinon.stub(),
            setStateCode: sinon.stub(),
            setCountryCode: sinon.stub(),
            setCompanyName: sinon.stub()
        };
    }

    function createShipment(shippingMethod, storedDropOff) {
        return {
            UUID: 'ship-1',
            shippingMethod: shippingMethod,
            shippingAddress: createAddress(),
            custom: {
                zenkraftDropOffData: storedDropOff ? JSON.stringify(storedDropOff) : null
            }
        };
    }

    function createBasket(shipments) {
        return {
            getShipments: function () {
                return {
                    iterator: function () {
                        var idx = 0;
                        return {
                            hasNext: function () { return idx < shipments.length; },
                            next: function () { return shipments[idx++]; }
                        };
                    }
                };
            }
        };
    }

    it('should stamp the collection-point address onto a drop-off shipment', function () {
        var shipment = createShipment(dropOffMethod, dropOffData);
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        var addr = shipment.shippingAddress;
        assert.isTrue(addr.setAddress1.calledWith('1 High Street'));
        assert.isTrue(addr.setAddress2.calledWith(null));
        assert.isTrue(addr.setCity.calledWith('London'));
        assert.isTrue(addr.setPostalCode.calledWith('SW1A 1AA'));
        assert.isTrue(addr.setCountryCode.calledWith('GB'));
        assert.isTrue(addr.setCompanyName.calledWith('Corner Shop'));
        assert.isTrue(addr.setStateCode.notCalled);
    });

    it('should prefer location_name for the company name', function () {
        var shipment = createShipment(dropOffMethod, Object.assign({}, dropOffData, { location_name: 'Corner Shop Ltd' }));
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.isTrue(shipment.shippingAddress.setCompanyName.calledWith('Corner Shop Ltd'));
    });

    it('should not touch the address when the shipping method is not a drop-off method', function () {
        var shipment = createShipment(standardMethod, dropOffData);
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
        assert.isTrue(shipment.shippingAddress.setAddress2.notCalled);
    });

    it('should refuse the order when a drop-off shipment has no collection point', function () {
        var shipment = createShipment(dropOffMethod, null);
        var result = beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.equal(result.status, Status.ERROR);
        assert.equal(result.code, 'ZENKRAFT_COLLECTION_POINT_REQUIRED');
        assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
    });

    it('should save the shopper address with the request ID before stamping the collection point', function () {
        var shipment = createShipment(dropOffMethod, dropOffData);
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.deepEqual(JSON.parse(shipment.custom.zenkraftOriginalShippingAddress), {
            requestID: 'req-order',
            address1: '5 Home Road',
            address2: 'Flat 2',
            city: 'Leeds',
            postalCode: 'LS1 1AA',
            stateCode: null,
            countryCode: 'GB',
            companyName: null
        });
    });

    it('should keep an address saved by an earlier attempt but refresh its request ID', function () {
        var shipment = createShipment(dropOffMethod, dropOffData);
        shipment.custom.zenkraftOriginalShippingAddress = JSON.stringify({ requestID: 'req-failed', address1: 'saved earlier', city: 'York' });
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.deepEqual(JSON.parse(shipment.custom.zenkraftOriginalShippingAddress), {
            requestID: 'req-order',
            address1: 'saved earlier',
            city: 'York'
        });
    });

    it('should save the current address when the earlier saved value is unreadable', function () {
        var shipment = createShipment(dropOffMethod, dropOffData);
        shipment.custom.zenkraftOriginalShippingAddress = '{not json';
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        var saved = JSON.parse(shipment.custom.zenkraftOriginalShippingAddress);
        assert.equal(saved.requestID, 'req-order');
        assert.equal(saved.address1, '5 Home Road');
    });

    it('should keep address2 when the location has no street', function () {
        var shipment = createShipment(dropOffMethod, { location_code: 'LOC-1', city: 'London' });
        beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.isTrue(shipment.shippingAddress.setAddress2.notCalled);
        assert.isTrue(shipment.shippingAddress.setCity.calledWith('London'));
    });

    it('should log a warning and refuse the order when the stored data is not valid JSON', function () {
        var shipment = createShipment(dropOffMethod, null);
        shipment.custom.zenkraftDropOffData = '{not json';
        var result = beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.equal(result.status, Status.ERROR);
        assert.isTrue(loggerStub.warn.called);
        assert.isTrue(shipment.shippingAddress.setAddress1.notCalled);
    });

    it('should return OK for a basket without drop-off shipments', function () {
        var shipment = createShipment(standardMethod, null);
        var result = beforePlaceOrder.beforePOST(createBasket([shipment]));

        assert.equal(result.status, Status.OK);
        assert.notProperty(shipment.custom, 'zenkraftOriginalShippingAddress');
    });

    it('should stamp only drop-off shipments in a multi-shipment basket', function () {
        var dropOffShipment = createShipment(dropOffMethod, dropOffData);
        var homeShipment = createShipment(standardMethod, null);
        beforePlaceOrder.beforePOST(createBasket([homeShipment, dropOffShipment]));

        assert.isTrue(dropOffShipment.shippingAddress.setAddress1.calledOnce);
        assert.isTrue(homeShipment.shippingAddress.setAddress1.notCalled);
    });
});
