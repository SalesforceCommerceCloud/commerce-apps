'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();
var Calendar = require('../../mocks/dw/util/Calendar');
var StringUtils = require('../../mocks/dw/util/StringUtils');

/**
 * Loads the date helper for a site in the given time zone, with an empty basket.
 * @param {Object} [options] - siteTimeZone, instanceTimeZone (defaults to siteTimeZone) and site preferences
 * @returns {Object} date helper
 */
function makeDateHelper(options) {
    var opts = options || {};
    var preferences = opts.preferences || {};
    return proxyquire(
        '../../../cartridge/scripts/helpers/zenkraftDateHelper',
        {
            'dw/util/Calendar': Calendar,
            'dw/util/StringUtils': StringUtils,
            'dw/order/BasketMgr': { getCurrentBasket: function () { return null; } },
            'dw/system/Site': {
                getCurrent: function () {
                    return {
                        getTimezone: function () { return opts.siteTimeZone || 'UTC'; },
                        getCustomPreferenceValue: function (key) {
                            return preferences[key] !== undefined ? preferences[key] : null;
                        }
                    };
                }
            },
            'dw/system/System': {
                getInstanceTimeZone: function () { return opts.instanceTimeZone || opts.siteTimeZone || 'UTC'; }
            }
        }
    );
}

var dateHelper = makeDateHelper();

describe('zenkraftDateHelper', function () {

    // =========================================================================
    // getFormattedDateTime
    // =========================================================================
    describe('getFormattedDateTime', function () {
        it('should return a string containing the day abbreviation', function () {
            var date = new Date(2030, 5, 15); // Sat 15 Jun 2030 — well beyond "tomorrow"
            var result = dateHelper.getFormattedDateTime(date);
            var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            assert.include(result, days[date.getDay()]);
        });

        it('should include the day-of-month number in the formatted string', function () {
            var date = new Date(2030, 5, 15);
            var result = dateHelper.getFormattedDateTime(date);
            assert.include(result, '15');
        });

        it('should include the month abbreviation in the formatted string', function () {
            var date = new Date(2030, 5, 15); // June
            var result = dateHelper.getFormattedDateTime(date);
            assert.include(result, 'Jun');
        });

        it('should NOT return "Tomorrow" for a date far in the future', function () {
            var future = new Date(2035, 0, 1);
            var result = dateHelper.getFormattedDateTime(future);
            assert.notInclude(result, 'Tomorrow');
        });

        describe('"Tomorrow" in the site time zone', function () {
            var clock;

            afterEach(function () {
                clock.restore();
            });

            it('should return "Tomorrow" for tomorrow\'s date', function () {
                clock = sinon.useFakeTimers({ now: Date.parse('2026-10-16T12:00:00+01:00'), toFake: ['Date'] });
                var helper = makeDateHelper({ siteTimeZone: 'Europe/London' });
                assert.equal(helper.getFormattedDateTime(new Date(2026, 9, 17)), 'Tomorrow 17 Oct');
            });

            it('should use the site date, not GMT, on a US site in the evening', function () {
                // 18:00 PDT on Fri 16 Oct is already Sat 17 Oct in GMT
                clock = sinon.useFakeTimers({ now: Date.parse('2026-10-16T18:00:00-07:00'), toFake: ['Date'] });
                var helper = makeDateHelper({ siteTimeZone: 'America/Los_Angeles' });
                assert.equal(helper.getFormattedDateTime(new Date(2026, 9, 17)), 'Tomorrow 17 Oct');
                assert.equal(helper.getFormattedDateTime(new Date(2026, 9, 18)), 'Sun 18 Oct');
            });

            it('should use the site date, not GMT, on an Australian site in the morning', function () {
                // 08:00 AEDT on Fri 16 Oct is still Thu 15 Oct in GMT
                clock = sinon.useFakeTimers({ now: Date.parse('2026-10-16T08:00:00+11:00'), toFake: ['Date'] });
                var helper = makeDateHelper({ siteTimeZone: 'Australia/Sydney' });
                assert.equal(helper.getFormattedDateTime(new Date(2026, 9, 16)), 'Fri 16 Oct');
                assert.equal(helper.getFormattedDateTime(new Date(2026, 9, 17)), 'Tomorrow 17 Oct');
            });
        });
    });

    // =========================================================================
    // isAfterCutoffDate / getShipDate — cutoff and ship date in the site time zone
    // =========================================================================
    describe('isAfterCutoffDate and getShipDate', function () {
        var clock;

        function at(isoDateTime) {
            clock = sinon.useFakeTimers({ now: Date.parse(isoDateTime), toFake: ['Date'] });
        }

        function helperFor(siteTimeZone, cutoff, leadTime) {
            return makeDateHelper({
                siteTimeZone: siteTimeZone,
                preferences: {
                    zenkraftEDDCutoffTime: cutoff ? new Date(cutoff) : null,
                    zenkraftCompanyWideLeadTime: leadTime || 0
                }
            });
        }

        beforeEach(function () {
            global.empty = function (val) { return val === null || val === undefined || val === ''; };
        });

        afterEach(function () {
            delete global.empty;
            clock.restore();
        });

        it('should not be after cutoff when no cutoff is configured', function () {
            at('2026-10-16T23:00:00Z');
            var helper = helperFor('UTC', null);
            assert.isFalse(helper.isAfterCutoffDate());
            assert.equal(helper.getShipDate(), '2026-10-16');
        });

        it('should ship the same day before a 17:00 cutoff on a US West site', function () {
            at('2026-10-16T09:00:00-07:00');
            var helper = helperFor('America/Los_Angeles', '2026-10-01T17:00:00-07:00');
            assert.isFalse(helper.isAfterCutoffDate());
            assert.equal(helper.getShipDate(), '2026-10-16');
        });

        it('should ship the next day after a 17:00 cutoff on a US West site', function () {
            at('2026-10-16T18:00:00-07:00');
            var helper = helperFor('America/Los_Angeles', '2026-10-01T17:00:00-07:00');
            assert.isTrue(helper.isAfterCutoffDate());
            assert.equal(helper.getShipDate(), '2026-10-17');
        });

        it('should not send a past ship date before a 10:00 cutoff on an Australian site', function () {
            at('2026-10-16T08:00:00+11:00');
            var helper = helperFor('Australia/Sydney', '2026-10-01T10:00:00+11:00');
            assert.isFalse(helper.isAfterCutoffDate());
            assert.equal(helper.getShipDate(), '2026-10-16');
        });

        it('should ship the next day after a 10:00 cutoff on an Australian site', function () {
            at('2026-10-16T12:00:00+11:00');
            var helper = helperFor('Australia/Sydney', '2026-10-01T10:00:00+11:00');
            assert.isTrue(helper.isAfterCutoffDate());
            assert.equal(helper.getShipDate(), '2026-10-17');
        });

        it('should treat the cutoff minute itself as after cutoff', function () {
            at('2026-10-16T17:00:00+01:00');
            var helper = helperFor('Europe/London', '2026-10-01T17:00:00+01:00');
            assert.isTrue(helper.isAfterCutoffDate());
        });

        it('should read the cutoff as entered in the instance time zone and compare it with site time', function () {
            // Instance in UTC, site in New York: 17:00 entered in BM is stored as 17:00 UTC and means 17:00 site time
            var helperOptions = {
                siteTimeZone: 'America/New_York',
                instanceTimeZone: 'UTC',
                preferences: { zenkraftEDDCutoffTime: new Date('2026-10-01T17:00:00Z') }
            };
            at('2026-10-16T14:00:00-04:00');
            assert.isFalse(makeDateHelper(helperOptions).isAfterCutoffDate());
            clock.restore();
            at('2026-10-16T17:30:00-04:00');
            assert.isTrue(makeDateHelper(helperOptions).isAfterCutoffDate());
        });

        it('should add the lead time to the ship date', function () {
            at('2026-10-16T09:00:00-07:00');
            var helper = helperFor('America/Los_Angeles', '2026-10-01T17:00:00-07:00', 3);
            assert.equal(helper.getShipDate(), '2026-10-19');
        });

        it('should add both the cutoff day and the lead time', function () {
            at('2026-10-16T18:00:00-07:00');
            var helper = helperFor('America/Los_Angeles', '2026-10-01T17:00:00-07:00', 3);
            assert.equal(helper.getShipDate(), '2026-10-20');
        });
    });

    // =========================================================================
    // parseISODate — exact instant, zone offset applied
    // =========================================================================
    describe('parseISODate', function () {
        it('should apply a negative zone offset without a colon', function () {
            var result = dateHelper.parseISODate('2020-10-23T15:39:00.000-0400');
            assert.equal(result.toISOString(), '2020-10-23T19:39:00.000Z');
        });

        it('should move the instant to the next UTC day when the offset requires it', function () {
            var result = dateHelper.parseISODate('2020-10-22T21:00:00.000-0500');
            assert.equal(result.toISOString(), '2020-10-23T02:00:00.000Z');
        });

        it('should apply a positive zone offset with a colon', function () {
            var result = dateHelper.parseISODate('2026-09-15T12:34:56+02:00');
            assert.equal(result.toISOString(), '2026-09-15T10:34:56.000Z');
        });

        it('should parse a UTC "Z" value', function () {
            var result = dateHelper.parseISODate('2026-09-15T12:34:56.000Z');
            assert.equal(result.toISOString(), '2026-09-15T12:34:56.000Z');
        });

        it('should treat a value without a zone as UTC', function () {
            var result = dateHelper.parseISODate('2026-09-15T12:34:56');
            assert.equal(result.toISOString(), '2026-09-15T12:34:56.000Z');
        });

        it('should default missing seconds to zero', function () {
            var result = dateHelper.parseISODate('2026-09-15T12:34');
            assert.equal(result.toISOString(), '2026-09-15T12:34:00.000Z');
        });

        it('should return null for empty or invalid values', function () {
            [null, undefined, '', '2020-10-23', 'garbage'].forEach(function (value) {
                assert.isNull(dateHelper.parseISODate(value));
            });
        });
    });

    // =========================================================================
    // parseISOString — display string using the local date at the checkpoint
    // =========================================================================
    describe('parseISOString', function () {
        it('should format the local wall-clock date, ignoring the zone offset', function () {
            var result = dateHelper.parseISOString('2020-10-22T21:00:00.000-0500');
            var expected = dateHelper.getFormattedDateTime(new Date(Date.UTC(2020, 9, 22, 21, 0, 0)));
            assert.equal(result, expected);
        });

        it('should return the original value when it cannot be parsed', function () {
            assert.equal(dateHelper.parseISOString('garbage'), 'garbage');
            assert.equal(dateHelper.parseISOString(''), '');
            assert.isNull(dateHelper.parseISOString(null));
        });
    });

    // =========================================================================
    // convertDate — YYYY-MM-DD to a date at local midnight
    // =========================================================================
    describe('convertDate', function () {
        it('should convert a YYYY-MM-DD string', function () {
            var result = dateHelper.convertDate('2020-10-23');
            assert.equal(result.getTime(), new Date(2020, 9, 23).getTime());
        });

        it('should use the date part of a datetime string', function () {
            var result = dateHelper.convertDate('2020-10-23T15:39:00.000-0400');
            assert.equal(result.getTime(), new Date(2020, 9, 23).getTime());
        });

        it('should return null for empty values or values without a YYYY-MM-DD date', function () {
            [null, undefined, '', '23/10/2020', 'garbage'].forEach(function (value) {
                assert.isNull(dateHelper.convertDate(value));
            });
        });
    });

    // =========================================================================
    // getLeadTime — product/category lead time replaces the company-wide one; longest item wins
    // =========================================================================
    describe('getLeadTime', function () {
        function makeHelper(companyLeadTime, lineItems) {
            return proxyquire(
                '../../../cartridge/scripts/helpers/zenkraftDateHelper',
                {
                    'dw/order/BasketMgr': {
                        getCurrentBasket: function () {
                            return lineItems === null ? null : {
                                getProductLineItems: function () {
                                    return { toArray: function () { return lineItems || []; } };
                                }
                            };
                        }
                    },
                    'dw/system/Site': {
                        getCurrent: function () {
                            return {
                                getCustomPreferenceValue: function (pref) {
                                    return pref === 'zenkraftCompanyWideLeadTime' ? companyLeadTime : null;
                                }
                            };
                        }
                    }
                }
            );
        }

        function withLeadTime(zenkraftLeadTime, extra) {
            var object = {
                getCustom: function () {
                    return zenkraftLeadTime !== undefined ? { zenkraftLeadTime: zenkraftLeadTime } : {};
                }
            };
            Object.keys(extra || {}).forEach(function (key) { object[key] = extra[key]; });
            return object;
        }

        /**
         * @param {number} [productLeadTime] - lead time on the product (the variant, if masterLeadTime is given)
         * @param {number} [categoryLeadTime] - lead time on the line item's category
         * @param {number|null} [masterLeadTime] - when given, the product is a variant of a master with this lead time
         * @returns {Object} product line item stub
         */
        function makeLineItem(productLeadTime, categoryLeadTime, masterLeadTime) {
            var isVariant = masterLeadTime !== undefined;
            var master = isVariant ? withLeadTime(masterLeadTime === null ? undefined : masterLeadTime) : null;
            var product = withLeadTime(productLeadTime, {
                isVariant: function () { return isVariant; },
                getMasterProduct: function () { return master; }
            });
            var category = categoryLeadTime !== undefined ? withLeadTime(categoryLeadTime) : null;
            return {
                getProduct: function () { return product; },
                getCategory: function () { return category; }
            };
        }

        beforeEach(function () {
            global.empty = function (val) { return val === null || val === undefined || val === ''; };
        });

        afterEach(function () {
            delete global.empty;
        });

        it('should return the company-wide lead time when there is no basket', function () {
            assert.equal(makeHelper(2, null).getLeadTime(), 2);
        });

        it('should return the company-wide lead time when the basket is empty', function () {
            assert.equal(makeHelper(2, []).getLeadTime(), 2);
        });

        it('should return 0 when no company-wide lead time is configured', function () {
            assert.equal(makeHelper(null, []).getLeadTime(), 0);
        });

        it('should use the company-wide lead time for a product without its own lead time', function () {
            assert.equal(makeHelper(2, [makeLineItem()]).getLeadTime(), 2);
        });

        it('should use the product lead time instead of a shorter company-wide lead time', function () {
            assert.equal(makeHelper(2, [makeLineItem(5)]).getLeadTime(), 5);
        });

        it('should use the product lead time instead of a longer company-wide lead time', function () {
            assert.equal(makeHelper(5, [makeLineItem(2)]).getLeadTime(), 2);
        });

        it('should use a product lead time of 0 when it is explicitly configured', function () {
            assert.equal(makeHelper(5, [makeLineItem(0)]).getLeadTime(), 0);
        });

        it('should use the category lead time when the product has none', function () {
            assert.equal(makeHelper(1, [makeLineItem(undefined, 3)]).getLeadTime(), 3);
        });

        it('should prefer the product lead time over the category lead time', function () {
            assert.equal(makeHelper(1, [makeLineItem(2, 6)]).getLeadTime(), 2);
        });

        it('should prefer the variant lead time over the master lead time', function () {
            assert.equal(makeHelper(1, [makeLineItem(2, undefined, 6)]).getLeadTime(), 2);
        });

        it('should fall back to the master lead time when the variant has none', function () {
            assert.equal(makeHelper(1, [makeLineItem(undefined, undefined, 4)]).getLeadTime(), 4);
        });

        it('should return the longest lead time across line items', function () {
            assert.equal(makeHelper(1, [makeLineItem(2), makeLineItem(4)]).getLeadTime(), 4);
        });

        it('should let an item without its own lead time apply the company-wide lead time to the basket', function () {
            assert.equal(makeHelper(5, [makeLineItem(2), makeLineItem()]).getLeadTime(), 5);
        });
    });
});
