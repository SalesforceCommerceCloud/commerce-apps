'use strict';

var assert = require('chai').assert;
var proxyquire = require('proxyquire').noCallThru();

describe('zenkraftService', function () {
    var zenkraftService;
    var requestedUrl;

    beforeEach(function () {
        requestedUrl = null;
        var credential = {
            getURL: function () { return 'https://api.zenkraft.com'; },
            getPassword: function () { return 'KEY'; }
        };
        var svc = {
            getConfiguration: function () { return { getCredential: function () { return credential; } }; },
            setURL: function (url) { requestedUrl = url; },
            getURL: function () { return requestedUrl; },
            addHeader: function () {},
            setRequestMethod: function () {}
        };
        zenkraftService = proxyquire('../../../cartridge/scripts/services/zenkraftService', {
            'dw/svc/LocalServiceRegistry': {
                createService: function (id, callbacks) {
                    return { call: function (args) { callbacks.createRequest(svc, args); return { ok: true }; } };
                }
            },
            'dw/util/UUIDUtils': { createUUID: function () { return 'uuid'; } }
        });
    });

    function returnsUrl(type, body) {
        zenkraftService.call(zenkraftService.API_PATHS.RETURNS, JSON.stringify(body), 'GET', type);
        return requestedUrl;
    }

    it('should send a guest email customer ID as one value, with + and & encoded', function () {
        assert.equal(returnsUrl('returns', { customerNo: 'ann+shop@example.com' }),
            'https://api.zenkraft.com/returns/?customer_id=ann%2Bshop%40example.com');
        assert.equal(returnsUrl('returns', { customerNo: 'a&b@example.com' }),
            'https://api.zenkraft.com/returns/?customer_id=a%26b%40example.com');
    });

    it('should leave a customer number as it is', function () {
        assert.equal(returnsUrl('returns', { customerNo: '00012345' }), 'https://api.zenkraft.com/returns/?customer_id=00012345');
    });

    it('should ask for one order\'s returns, as many as Zenkraft lists on a page', function () {
        assert.equal(returnsUrl('returns', { customerNo: '00012345', orderNo: 'O 1&x' }),
            'https://api.zenkraft.com/returns/?customer_id=00012345&order_id=O%201%26x&page_size=20');
    });

    it('should keep a return ID inside the return path', function () {
        assert.equal(returnsUrl('details', { id: '2ff7047526e64a10a3e952680aca7e81' }),
            'https://api.zenkraft.com/returns/2ff7047526e64a10a3e952680aca7e81');
        assert.equal(returnsUrl('details', { id: '../shippingaccount?x=1' }),
            'https://api.zenkraft.com/returns/..%2Fshippingaccount%3Fx%3D1');
    });
});
