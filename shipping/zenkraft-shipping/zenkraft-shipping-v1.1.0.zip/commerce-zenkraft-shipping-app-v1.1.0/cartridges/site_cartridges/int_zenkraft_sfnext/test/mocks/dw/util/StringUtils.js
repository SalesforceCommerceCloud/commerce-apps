'use strict';

var Calendar = require('./Calendar');

/**
 * Minimal stand-in for dw.util.StringUtils.
 * formatCalendar supports only the yyyy, MM and dd tokens, read in the calendar's time zone.
 */
module.exports = {
    formatCalendar: function (calendar, pattern) {
        var pad = function (n) { return (n < 10 ? '0' : '') + n; };
        return pattern
            .replace('yyyy', String(calendar.get(Calendar.YEAR)))
            .replace('MM', pad(calendar.get(Calendar.MONTH) + 1))
            .replace('dd', pad(calendar.get(Calendar.DATE)));
    }
};
