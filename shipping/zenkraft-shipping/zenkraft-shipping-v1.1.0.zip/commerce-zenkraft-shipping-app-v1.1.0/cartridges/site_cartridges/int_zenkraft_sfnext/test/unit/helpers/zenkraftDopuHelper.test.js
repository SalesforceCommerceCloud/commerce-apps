'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

describe('zenkraftDopuHelper', function () {
    var dopuHelper;
    var serviceStub;
    var configStub;
    var shippingMethods;
    var basket;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };

        shippingMethods = [];
        basket = {
            getDefaultShipment: function () {
                return {
                    shippingAddress: {
                        address1: '5 Main Street',
                        city: 'New York',
                        postalCode: '10001',
                        stateCode: 'NY',
                        countryCode: { value: 'us' }
                    },
                    custom: {}
                };
            }
        };

        configStub = {
            carrier: 'ups',
            shippingAccount: '892685048,874246518',
            returnsShippingAccount: 'returns-account',
            packagingType: 'YOUR_PACKAGING',
            isProdMode: false,
            debugLog: false
        };

        serviceStub = {
            API_PATHS: { DOPU: '/dopu' },
            call: sinon.stub().returns({ object: { locations: [] } })
        };

        dopuHelper = proxyquire('../../../cartridge/scripts/helpers/zenkraftDopuHelper', {
            'dw/order/BasketMgr': { getCurrentBasket: function () { return basket; } },
            'dw/order/ShippingMgr': { getAllShippingMethods: function () { return shippingMethods; } },
            '*/cartridge/scripts/util/collections': {
                find: function (list, predicate) { return list.filter(predicate)[0] || null; }
            },
            '../services/zenkraftService': serviceStub,
            './zenkraftShippingHelper': { getConfig: sinon.stub().returns(configStub) }
        });
    });

    afterEach(function () {
        delete global.empty;
        sinon.restore();
    });

    function sentRequest() {
        return JSON.parse(serviceStub.call.firstCall.args[1]).dopu;
    }

    describe('getZenkraftDopuData', function () {
        it('should send the shipping method\'s zenkraftShippingMethodAccountID and carrier', function () {
            shippingMethods.push({ ID: 'fedex-dropoff', custom: { zenkraftCarrier: 'fedex', zenkraftShippingMethodAccountID: '874246518' } });

            dopuHelper.getZenkraftDopuData('fedex-dropoff');

            assert.isTrue(serviceStub.call.calledWith('/dopu'));
            assert.equal(sentRequest().shipping_account, '874246518');
            assert.equal(sentRequest().carrier, 'fedex');
        });

        it('should fall back to the first site preference account when the method has no account', function () {
            shippingMethods.push({ ID: 'ups-dropoff', custom: { zenkraftCarrier: 'ups' } });

            dopuHelper.getZenkraftDopuData('ups-dropoff');

            assert.equal(sentRequest().shipping_account, '892685048');
        });

        it('should build the location from the basket shipping address', function () {
            shippingMethods.push({ ID: 'ups-dropoff', custom: { zenkraftCarrier: 'ups' } });

            dopuHelper.getZenkraftDopuData('ups-dropoff');

            assert.deepEqual(sentRequest().location, {
                city: 'New York',
                country: 'US',
                postal_code: '10001',
                state: 'NY',
                street1: '5 Main Street'
            });
        });

        it('should search around the shopper\'s saved address while the shipment holds a collection point', function () {
            shippingMethods.push({ ID: 'ups-dropoff', custom: { zenkraftCarrier: 'ups' } });
            basket.getDefaultShipment = function () {
                return {
                    shippingAddress: {
                        address1: '1 High Street', city: 'Brooklyn', postalCode: '11201', stateCode: 'NY', countryCode: { value: 'US' }
                    },
                    custom: {
                        zenkraftOriginalShippingAddress: JSON.stringify({
                            address1: '5 Main Street', city: 'New York', postalCode: '10001', stateCode: 'NY', countryCode: 'US',
                            locationCode: 'LOC-1',
                            copied: { address1: '1 High Street', city: 'Brooklyn', postalCode: '11201', stateCode: 'NY', countryCode: 'US' }
                        })
                    }
                };
            };

            dopuHelper.getZenkraftDopuData('ups-dropoff');

            assert.deepEqual(sentRequest().location, {
                city: 'New York',
                country: 'US',
                postal_code: '10001',
                state: 'NY',
                street1: '5 Main Street'
            });
        });

        it('should return an error without calling the service when the shipping method does not exist', function () {
            var result = dopuHelper.getZenkraftDopuData('unknown');

            assert.deepEqual(result, { error: 'Shipping method not found' });
            assert.isTrue(serviceStub.call.notCalled);
        });

        it('should return an empty object when there is no basket', function () {
            basket = null;

            assert.deepEqual(dopuHelper.getZenkraftDopuData('ups-dropoff'), {});
            assert.isTrue(serviceStub.call.notCalled);
        });
    });
});
