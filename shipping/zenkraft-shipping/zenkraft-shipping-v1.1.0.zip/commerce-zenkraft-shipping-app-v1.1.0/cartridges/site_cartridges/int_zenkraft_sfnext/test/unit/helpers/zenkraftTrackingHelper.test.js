'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

describe('zenkraftTrackingHelper', function () {
    var trackingHelper;
    var serviceStub;
    var prefs;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        global.customer = { authenticated: false, profile: null };

        prefs = {
            enableZenkraftTrackingPage: true,
            enableZenkraftTrackingOnOrderDetailsPage: true,
            enableZenkraftPOD: true,
            zenkraftTrackingPageRequiresLogin: false
        };

        serviceStub = {
            API_PATHS: { TRACK: '/track' },
            call: sinon.stub().returns({ status: 'OK', object: { status: 'In transit', tracking_stage: 'IN_TRANSIT', checkpoints: [], pod: { signed_by: 'A. Shopper' } } })
        };

        trackingHelper = proxyquire('../../../cartridge/scripts/helpers/zenkraftTrackingHelper', {
            'dw/system/Logger': { getLogger: sinon.stub().returns({ warn: sinon.stub(), error: sinon.stub(), info: sinon.stub(), debug: sinon.stub() }) },
            'dw/order/OrderMgr': { getOrder: sinon.stub().returns(null) },
            'dw/system/Site': { getCurrent: function () { return { getCustomPreferenceValue: function (id) { return prefs[id]; } }; } },
            '../services/zenkraftService': serviceStub,
            './zenkraftDateHelper': { parseISOString: function (s) { return s; } }
        });
    });

    afterEach(function () {
        delete global.empty;
        delete global.customer;
        sinon.restore();
    });

    describe('getZenkraftTrackingData with "Tracking page requires login" on', function () {
        beforeEach(function () {
            prefs.zenkraftTrackingPageRequiresLogin = true;
        });

        it('should ask a guest to log in and not call Zenkraft', function () {
            var result = trackingHelper.getZenkraftTrackingData('1Z999', 'ups', '', false);

            assert.isTrue(result.loginRequired);
            assert.notProperty(result, 'trackingData');
            assert.isTrue(serviceStub.call.notCalled);
        });

        it('should return tracking data to a logged-in shopper', function () {
            global.customer = { authenticated: true, profile: { customerNo: 'C1' } };
            var result = trackingHelper.getZenkraftTrackingData('1Z999', 'ups', '', false);

            assert.notProperty(result, 'loginRequired');
            assert.equal(result.trackingData.tracking_stage, 'IN_TRANSIT');
        });

        it('should not apply to the order details page, which checks order ownership itself', function () {
            var result = trackingHelper.getZenkraftTrackingData('1Z999', 'ups', '', true);

            assert.notProperty(result, 'loginRequired');
            assert.equal(result.trackingData.tracking_stage, 'IN_TRANSIT');
        });
    });

    describe('getZenkraftTrackingData order details settings check (no tracking number)', function () {
        it('should answer enabled from the preferences without calling Zenkraft', function () {
            var result = trackingHelper.getZenkraftTrackingData(null, null, null, true);

            assert.deepEqual(result, { redirect: false, enableZenkraftTrackingOnOrderDetailsPage: true });
            assert.isTrue(serviceStub.call.notCalled);
        });

        it('should answer disabled when the order details preference is off', function () {
            prefs.enableZenkraftTrackingOnOrderDetailsPage = false;
            var result = trackingHelper.getZenkraftTrackingData(null, null, null, true);

            assert.isFalse(result.enableZenkraftTrackingOnOrderDetailsPage);
            assert.isTrue(serviceStub.call.notCalled);
        });

        it('should not answer enabled when the tracking page is off', function () {
            prefs.enableZenkraftTrackingPage = false;
            var result = trackingHelper.getZenkraftTrackingData(null, null, null, true);

            assert.notEqual(result.enableZenkraftTrackingOnOrderDetailsPage, true);
            assert.isTrue(serviceStub.call.notCalled);
        });
    });

    describe('getZenkraftTrackingData with "Tracking page requires login" off', function () {
        it('should return tracking data, including proof of delivery, to a guest', function () {
            var result = trackingHelper.getZenkraftTrackingData('1Z999', 'ups', '', false);

            assert.notProperty(result, 'loginRequired');
            assert.equal(result.trackingData.pod.signed_by, 'A. Shopper');
        });

        it('should drop proof of delivery when enableZenkraftPOD is off', function () {
            prefs.enableZenkraftPOD = false;
            var result = trackingHelper.getZenkraftTrackingData('1Z999', 'ups', '', false);

            assert.isNull(result.trackingData.pod);
        });
    });
});
