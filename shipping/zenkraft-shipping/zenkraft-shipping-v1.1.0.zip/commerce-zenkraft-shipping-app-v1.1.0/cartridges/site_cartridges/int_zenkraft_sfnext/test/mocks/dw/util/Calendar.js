'use strict';

/**
 * Minimal time-zone-aware stand-in for dw.util.Calendar, backed by Intl.
 * Supports only the fields and methods used by the cartridge scripts.
 * add() moves by whole 24h days, so tests should avoid DST transitions.
 * @param {Date} [date] - Date to wrap; defaults to now
 */
function Calendar(date) {
    this.time = date ? date.getTime() : Date.now();
    this.timeZone = 'UTC';
}

Calendar.YEAR = 1;
Calendar.MONTH = 2;
Calendar.DATE = 5;
Calendar.DAY_OF_MONTH = 5;
Calendar.HOUR_OF_DAY = 11;
Calendar.MINUTE = 12;

Calendar.prototype.setTimeZone = function (timeZone) {
    this.timeZone = timeZone;
};

Calendar.prototype.getTimeZone = function () {
    return this.timeZone;
};

Calendar.prototype.getTime = function () {
    return new Date(this.time);
};

Calendar.prototype.setTime = function (date) {
    this.time = date.getTime();
};

Calendar.prototype.get = function (field) {
    var parts = {};
    new Intl.DateTimeFormat('en-US', {
        timeZone: this.timeZone,
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        hourCycle: 'h23'
    }).formatToParts(new Date(this.time)).forEach(function (part) {
        parts[part.type] = parseInt(part.value, 10);
    });

    switch (field) {
        case Calendar.YEAR: return parts.year;
        case Calendar.MONTH: return parts.month - 1;
        case Calendar.DATE: return parts.day;
        case Calendar.HOUR_OF_DAY: return parts.hour;
        case Calendar.MINUTE: return parts.minute;
        default: throw new Error('Calendar mock: unsupported field ' + field);
    }
};

Calendar.prototype.add = function (field, amount) {
    if (field !== Calendar.DATE) {
        throw new Error('Calendar mock: add() supports only Calendar.DATE');
    }
    this.time += amount * 24 * 60 * 60 * 1000;
};

module.exports = Calendar;
