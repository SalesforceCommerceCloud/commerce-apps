'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

describe('zenkraftReturnHelper', function () {
    var returnHelper;
    var loggerStub;
    var prefs;
    var order;
    var shippingAddress;
    var billingAddress;
    var existingReturnCases;
    var existingLineItems;
    var serviceStub;

    var REQUIRED_FIELDS = JSON.stringify({
        order: [{ attribute: 'orderEmail', field: 'email' }],
        shippingAddress: [
            { attribute: 'phone', field: 'phone' },
            { attribute: 'address1', field: 'address' }
        ]
    });

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };

        loggerStub = { warn: sinon.stub(), error: sinon.stub(), info: sinon.stub(), debug: sinon.stub() };
        prefs = { zenkraftReturnRequiredFields: REQUIRED_FIELDS, zenkraftReturnsHandler: { value: 'sfcc' } };
        serviceStub = { API_PATHS: { RETURNS: '/returns' }, call: sinon.stub().returns({ ok: true, object: [] }) };

        shippingAddress = { phone: '', address1: '1 Main St', setPhone: sinon.stub(), setAddress1: sinon.stub() };
        billingAddress = { phone: '' };
        order = {
            orderNo: 'O-1',
            customerEmail: '',
            setCustomerEmail: sinon.stub(),
            getDefaultShipment: function () { return { getShippingAddress: function () { return shippingAddress; } }; },
            getBillingAddress: function () { return billingAddress; }
        };

        existingReturnCases = [];
        existingLineItems = {};

        returnHelper = proxyquire('../../../cartridge/scripts/helpers/zenkraftReturnHelper', {
            'dw/util/Calendar': function () {},
            'dw/object/CustomObjectMgr': {
                queryCustomObjects: function () {
                    return { asList: function () { return { toArray: function () { return existingReturnCases; } }; } };
                },
                getCustomObject: function (type, id) { return existingLineItems[id] || null; }
            },
            'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub), error: sinon.stub() },
            'dw/order/OrderMgr': {},
            'dw/catalog/ProductMgr': { getProduct: function () { return null; } },
            'dw/web/Resource': { msg: function (key, bundle, fallback) { return fallback || key; } },
            'dw/system/Site': { getCurrent: function () { return { getCustomPreferenceValue: function (id) { return prefs[id]; } }; } },
            'dw/util/StringUtils': {},
            'dw/system/Transaction': { wrap: function (fn) { return fn(); } },
            'dw/util/UUIDUtils': {},
            '../services/zenkraftService': serviceStub,
            './zenkraftDateHelper': { parseISODate: function (s) { return new Date(s); } },
            '*/cartridge/scripts/util/collections': { forEach: function (list, fn) { list.forEach(fn); } },
            './zenkraftShippingHelper': { extractNumber: function (v) { return Number(v) || 0; } }
        });
    });

    // -------------------------------------------------------------------------
    // Return rules enforced when a return is created
    // -------------------------------------------------------------------------
    function createProduct(categoryIds, options) {
        options = options || {};
        var categories = categoryIds.map(function (id) { return { ID: id }; });
        var product = {
            variant: !!options.master,
            custom: { dimWeight: '1' },
            getCategories: function () { return { toArray: function () { return options.master ? [] : categories; } }; },
            getMasterProduct: function () { return options.master; }
        };
        return product;
    }

    function createOrderWithLines(lines) {
        return {
            orderNo: 'O-1',
            getProductLineItems: function () {
                return {
                    toArray: function () {
                        return lines.map(function (line) {
                            return {
                                UUID: line.uuid,
                                productID: line.productID,
                                productName: line.productID,
                                quantityValue: line.quantity,
                                proratedPrice: { value: 10 * line.quantity },
                                product: line.product
                            };
                        });
                    }
                };
            }
        };
    }

    function returnRequest(uuid, quantity) {
        var details = {};
        details[uuid] = { quantity: quantity, reasonId: 'damaged', subReasonId: 'product_was_defective' };
        return { items: [{ itemId: uuid }], returnDetails: details };
    }

    describe('isProductReturnable', function () {
        it('should match category IDs exactly, not as substrings', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'mens-clothing-suits';

            assert.isTrue(returnHelper.isProductReturnable(createProduct(['suits'])));
            assert.isFalse(returnHelper.isProductReturnable(createProduct(['mens-clothing-suits'])));
        });

        it('should read a list with spaces and check a variant by its master', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'gift-cards, final-sale';
            var variant = createProduct([], { master: createProduct(['final-sale']) });

            assert.isFalse(returnHelper.isProductReturnable(variant));
        });

        it('should treat a missing product, or no setting, as returnable', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'final-sale';
            assert.isTrue(returnHelper.isProductReturnable(null));

            prefs.zenkraftCatalogCategoriesForNonReturnableItems = null;
            assert.isTrue(returnHelper.isProductReturnable(createProduct(['final-sale'])));
        });
    });

    describe('getValidatedReturnItems', function () {
        it('should accept a valid return', function () {
            var request = returnRequest('pli-1', 1);
            var result = returnHelper.getValidatedReturnItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }]), request.items, request.returnDetails);

            assert.equal(result.items[0].productId, 'P1');
            assert.equal(result.returnDetails['pli-1'].quantity, 1);
        });

        it('should refuse a product in a non-returnable category', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'final-sale';
            var request = returnRequest('pli-1', 1);
            var result = returnHelper.getValidatedReturnItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct(['final-sale']) }]), request.items, request.returnDetails);

            assert.isNull(result);
            assert.isTrue(loggerStub.warn.calledOnce);
        });

        it('should refuse returning more than is left after earlier returns', function () {
            existingReturnCases = [{ custom: { returnLineItems: 'R1-1' } }];
            existingLineItems['R1-1'] = { creationDate: new Date(), custom: { productID: 'P1', quantity: 1 } };
            var lines = [{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }];

            var tooMany = returnRequest('pli-1', 2);
            assert.isNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), tooMany.items, tooMany.returnDetails));

            var remaining = returnRequest('pli-1', 1);
            assert.isNotNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), remaining.items, remaining.returnDetails));
        });

        describe('with returns handled by the Zenkraft API (zkapi)', function () {
            var lines;

            function zenkraftReturn(orderNo, sku, quantity) {
                return { id: 'zk-1', created: '2026-10-20T10:00:00Z', shipment: { reference_number: orderNo, status: 'IN_TRANSIT' }, return_lines: [{ sku: sku, quantity: quantity }] };
            }

            beforeEach(function () {
                prefs.zenkraftReturnsHandler = { value: 'zkapi' };
                lines = [{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }];
            });

            it('should refuse returning more than is left after earlier Zenkraft returns of the order', function () {
                serviceStub.call.returns({ ok: true, object: [zenkraftReturn('O-1', 'P1', 1), zenkraftReturn('O-2', 'P1', 2)] });

                var tooMany = returnRequest('pli-1', 2);
                assert.isNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), tooMany.items, tooMany.returnDetails));

                // The return of the other order (O-2) is not counted
                var remaining = returnRequest('pli-1', 1);
                assert.isNotNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), remaining.items, remaining.returnDetails));
            });

            it('should also count return requests waiting for approval, which are stored in the instance', function () {
                existingReturnCases = [{ custom: { returnLineItems: 'R1-1' } }];
                existingLineItems['R1-1'] = { creationDate: new Date(), custom: { productID: 'P1', quantity: 1 } };
                serviceStub.call.returns({ ok: true, object: [zenkraftReturn('O-1', 'P1', 1)] });

                var request = returnRequest('pli-1', 1);
                assert.isNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), request.items, request.returnDetails));
            });

            it('should look the returns up with the customer ID they were created with', function () {
                var order = createOrderWithLines(lines);
                order.customerNo = 'C-100';
                var request = returnRequest('pli-1', 1);
                returnHelper.getValidatedReturnItems(order, request.items, request.returnDetails);

                assert.equal(JSON.parse(serviceStub.call.firstCall.args[1]).customerNo, 'C-100');
            });

            it('should not block returns when Zenkraft cannot be reached', function () {
                serviceStub.call.returns({ ok: false, object: null });

                var request = returnRequest('pli-1', 2);
                assert.isNotNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), request.items, request.returnDetails));
            });
        });

        it('should not call Zenkraft with the sfcc handler', function () {
            var request = returnRequest('pli-1', 1);
            returnHelper.getValidatedReturnItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct(['shirts']) }]), request.items, request.returnDetails);

            assert.isTrue(serviceStub.call.notCalled);
        });
    });

    afterEach(function () {
        delete global.empty;
        sinon.restore();
    });

    describe('updateMissingData', function () {
        it('should fill in fields the order is missing', function () {
            returnHelper.updateMissingData(order, { email: ' shopper@example.com ', phone: '555 0100' });

            assert.isTrue(order.setCustomerEmail.calledWith('shopper@example.com'));
            assert.isTrue(shippingAddress.setPhone.calledWith('555 0100'));
        });

        it('should not change a field the order already has, and log a warning', function () {
            returnHelper.updateMissingData(order, { address: '9 Other Street' });

            assert.isTrue(shippingAddress.setAddress1.notCalled);
            assert.isTrue(loggerStub.warn.calledOnce);
        });

        it('should not write the shipping phone when the order has a phone on the billing address', function () {
            billingAddress.phone = '555 0199';
            returnHelper.updateMissingData(order, { phone: '555 0100' });

            assert.isTrue(shippingAddress.setPhone.notCalled);
        });

        it('should ignore fields the preference does not list', function () {
            returnHelper.updateMissingData(order, { postalCode: '99999' });

            assert.isTrue(shippingAddress.setAddress1.notCalled);
            assert.isTrue(shippingAddress.setPhone.notCalled);
            assert.isTrue(order.setCustomerEmail.notCalled);
        });
    });

    describe('checkForMissingImportantData', function () {
        it('should report exactly the empty required fields', function () {
            var result = returnHelper.checkForMissingImportantData(order);

            assert.deepEqual(result.missingData.map(function (m) { return m.field; }), ['email', 'phone']);
        });

        it('should report nothing when every required field has a value', function () {
            order.customerEmail = 'shopper@example.com';
            shippingAddress.phone = '555 0100';

            assert.isNull(returnHelper.checkForMissingImportantData(order));
        });
    });
});
