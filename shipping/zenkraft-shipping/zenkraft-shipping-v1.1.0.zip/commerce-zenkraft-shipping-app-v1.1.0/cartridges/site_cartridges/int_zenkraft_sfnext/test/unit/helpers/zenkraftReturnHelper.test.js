'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

describe('zenkraftReturnHelper', function () {
    var returnHelper;
    var loggerStub;
    var prefs;
    var order;
    var shippingAddress;
    var billingAddress;
    var existingReturnCases;
    var existingLineItems;
    var storedReturns;
    var returnDrafts;
    var customObjectMgr;
    var inTransaction;
    var serviceStub;

    var REQUIRED_FIELDS = JSON.stringify({
        order: [{ attribute: 'orderEmail', field: 'email' }],
        shippingAddress: [
            { attribute: 'phone', field: 'phone' },
            { attribute: 'address1', field: 'address' }
        ]
    });

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };

        loggerStub = { warn: sinon.stub(), error: sinon.stub(), info: sinon.stub(), debug: sinon.stub() };
        prefs = { zenkraftReturnRequiredFields: REQUIRED_FIELDS, zenkraftReturnsHandler: { value: 'sfcc' } };
        serviceStub = { API_PATHS: { RETURNS: '/returns', SHIP: '/ship', LABEL: '/label' }, call: sinon.stub().returns({ ok: true, object: [] }) };

        shippingAddress = { phone: '', address1: '1 Main St', setPhone: sinon.stub(), setAddress1: sinon.stub() };
        billingAddress = { phone: '' };
        order = {
            orderNo: 'O-1',
            customerEmail: '',
            setCustomerEmail: sinon.stub(),
            getDefaultShipment: function () { return { getShippingAddress: function () { return shippingAddress; } }; },
            getBillingAddress: function () { return billingAddress; }
        };

        existingReturnCases = [];
        existingLineItems = {};
        storedReturns = {};
        returnDrafts = {};
        inTransaction = false;
        var storeFor = function (type) {
            return { zenkraftReturn: storedReturns, zenkraftReturnDraft: returnDrafts }[type] || existingLineItems;
        };
        customObjectMgr = {
            queryCustomObjects: function () {
                return { asList: function () { return { toArray: function () { return existingReturnCases; } }; } };
            },
            getCustomObject: function (type, id) {
                return storeFor(type)[id] || null;
            },
            // Like the platform: a key can only be used once, and objects can only be created and removed in a transaction
            createCustomObject: sinon.spy(function (type, id) {
                var store = storeFor(type);
                if (!inTransaction || store[id]) {
                    throw new Error(!inTransaction ? 'Not in a transaction' : 'Duplicate key ' + id);
                }
                store[id] = { UUID: 'uuid-' + id, creationDate: new Date(), custom: { id: id } };
                return store[id];
            }),
            remove: function (object) {
                if (!inTransaction) {
                    throw new Error('Not in a transaction');
                }
                [storedReturns, returnDrafts, existingLineItems].forEach(function (store) {
                    if (store[object.custom.id] === object) {
                        delete store[object.custom.id];
                    }
                });
            }
        };

        returnHelper = proxyquire('../../../cartridge/scripts/helpers/zenkraftReturnHelper', {
            'dw/util/Calendar': function () {},
            'dw/object/CustomObjectMgr': customObjectMgr,
            'dw/object/SystemObjectMgr': { querySystemObject: function () { return null; } },
            'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub), error: sinon.stub() },
            'dw/order/OrderMgr': {},
            'dw/catalog/ProductMgr': { getProduct: function () { return null; } },
            'dw/web/Resource': { msg: function (key, bundle, fallback) { return fallback || key; } },
            'dw/system/Site': { getCurrent: function () { return { getCustomPreferenceValue: function (id) { return prefs[id]; } }; } },
            'dw/util/StringUtils': { formatCalendar: function () { return '11/03/26'; } },
            // Like the platform: an error rolls back what the transaction created and changed
            'dw/system/Transaction': {
                wrap: function (fn) {
                    var before = {
                        lineItems: Object.assign({}, existingLineItems),
                        returns: Object.assign({}, storedReturns),
                        drafts: Object.assign({}, returnDrafts),
                        cases: existingReturnCases.map(function (returnCase) { return Object.assign({}, returnCase.custom); })
                    };
                    inTransaction = true;
                    try {
                        return fn();
                    } catch (e) {
                        [[existingLineItems, before.lineItems], [storedReturns, before.returns], [returnDrafts, before.drafts]].forEach(function (pair) {
                            Object.keys(pair[0]).forEach(function (id) {
                                if (!pair[1][id]) { delete pair[0][id]; }
                            });
                            // Removed in the failed transaction: back again
                            Object.keys(pair[1]).forEach(function (id) {
                                pair[0][id] = pair[1][id];
                            });
                        });
                        existingReturnCases.forEach(function (returnCase, i) { returnCase.custom = before.cases[i]; });
                        throw e;
                    } finally {
                        inTransaction = false;
                    }
                }
            },
            'dw/util/UUIDUtils': { createUUID: function () { return 'uuid'; } },
            '../services/zenkraftService': serviceStub,
            './zenkraftDateHelper': { parseISODate: function (s) { return new Date(s); } },
            '*/cartridge/scripts/util/collections': { forEach: function (list, fn) { list.forEach(fn); } },
            './zenkraftShippingHelper': { extractNumber: function (v) { return Number(v) || 0; } }
        });
    });

    // -------------------------------------------------------------------------
    // Return rules enforced when a return is created
    // -------------------------------------------------------------------------
    function createProduct(categoryIds, options) {
        options = options || {};
        var categories = categoryIds.map(function (id) { return { ID: id }; });
        var product = {
            variant: !!options.master,
            custom: { dimWeight: '1' },
            getCategories: function () { return { toArray: function () { return options.master ? [] : categories; } }; },
            getMasterProduct: function () { return options.master; }
        };
        return product;
    }

    function createOrderWithLines(lines) {
        return {
            orderNo: 'O-1',
            getProductLineItems: function () {
                return {
                    toArray: function () {
                        return lines.map(function (line) {
                            return {
                                UUID: line.uuid,
                                productID: line.productID,
                                productName: line.productID,
                                quantityValue: line.quantity,
                                proratedPrice: { value: 10 * line.quantity },
                                product: line.product
                            };
                        });
                    }
                };
            }
        };
    }

    function returnRequest(uuid, quantity) {
        var details = {};
        details[uuid] = { quantity: quantity, reasonId: 'damaged', subReasonId: 'product_was_defective' };
        return { items: [{ itemId: uuid }], returnDetails: details };
    }

    describe('isProductReturnable', function () {
        it('should match category IDs exactly, not as substrings', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'mens-clothing-suits';

            assert.isTrue(returnHelper.isProductReturnable(createProduct(['suits'])));
            assert.isFalse(returnHelper.isProductReturnable(createProduct(['mens-clothing-suits'])));
        });

        it('should read a list with spaces and check a variant by its master', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'gift-cards, final-sale';
            var variant = createProduct([], { master: createProduct(['final-sale']) });

            assert.isFalse(returnHelper.isProductReturnable(variant));
        });

        it('should treat a missing product, or no setting, as returnable', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'final-sale';
            assert.isTrue(returnHelper.isProductReturnable(null));

            prefs.zenkraftCatalogCategoriesForNonReturnableItems = null;
            assert.isTrue(returnHelper.isProductReturnable(createProduct(['final-sale'])));
        });
    });

    describe('getValidatedReturnItems', function () {
        it('should accept a valid return', function () {
            var request = returnRequest('pli-1', 1);
            var result = returnHelper.getValidatedReturnItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }]), request.items, request.returnDetails);

            assert.equal(result.items[0].productId, 'P1');
            assert.equal(result.returnDetails['pli-1'].quantity, 1);
        });

        it('should refuse a product in a non-returnable category', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'final-sale';
            var request = returnRequest('pli-1', 1);
            var result = returnHelper.getValidatedReturnItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct(['final-sale']) }]), request.items, request.returnDetails);

            assert.isNull(result);
            assert.isTrue(loggerStub.warn.calledOnce);
        });

        it('should refuse returning more than is left after earlier returns', function () {
            existingReturnCases = [{ custom: { returnLineItems: 'R1-1' } }];
            existingLineItems['R1-1'] = { creationDate: new Date(), custom: { productID: 'P1', quantity: 1 } };
            var lines = [{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }];

            var tooMany = returnRequest('pli-1', 2);
            assert.isNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), tooMany.items, tooMany.returnDetails));

            var remaining = returnRequest('pli-1', 1);
            assert.isNotNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), remaining.items, remaining.returnDetails));
        });

        describe('with returns handled by the Zenkraft API (zkapi)', function () {
            var lines;

            function zenkraftReturn(orderNo, sku, quantity) {
                return { id: 'zk-1', created: '2026-10-20T10:00:00Z', shipment: { reference_number: orderNo, status: 'IN_TRANSIT' }, return_lines: [{ sku: sku, quantity: quantity }] };
            }

            beforeEach(function () {
                prefs.zenkraftReturnsHandler = { value: 'zkapi' };
                lines = [{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }];
            });

            it('should refuse returning more than is left after earlier Zenkraft returns of the order', function () {
                serviceStub.call.returns({ ok: true, object: [zenkraftReturn('O-1', 'P1', 1), zenkraftReturn('O-2', 'P1', 2)] });

                var tooMany = returnRequest('pli-1', 2);
                assert.isNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), tooMany.items, tooMany.returnDetails));

                // The return of the other order (O-2) is not counted
                var remaining = returnRequest('pli-1', 1);
                assert.isNotNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), remaining.items, remaining.returnDetails));
            });

            it('should also count return requests waiting for approval, which are stored in the instance', function () {
                existingReturnCases = [{ custom: { returnLineItems: 'R1-1' } }];
                existingLineItems['R1-1'] = { creationDate: new Date(), custom: { productID: 'P1', quantity: 1 } };
                serviceStub.call.returns({ ok: true, object: [zenkraftReturn('O-1', 'P1', 1)] });

                var request = returnRequest('pli-1', 1);
                assert.isNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), request.items, request.returnDetails));
            });

            it('should look the returns up with the customer ID they were created with', function () {
                var order = createOrderWithLines(lines);
                order.customerNo = 'C-100';
                var request = returnRequest('pli-1', 1);
                returnHelper.getValidatedReturnItems(order, request.items, request.returnDetails);

                assert.equal(JSON.parse(serviceStub.call.firstCall.args[1]).customerNo, 'C-100');
            });

            it('should not block returns when Zenkraft cannot be reached', function () {
                serviceStub.call.returns({ ok: false, object: null });

                var request = returnRequest('pli-1', 2);
                assert.isNotNull(returnHelper.getValidatedReturnItems(createOrderWithLines(lines), request.items, request.returnDetails));
            });
        });

        it('should not call Zenkraft with the sfcc handler', function () {
            var request = returnRequest('pli-1', 1);
            returnHelper.getValidatedReturnItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct(['shirts']) }]), request.items, request.returnDetails);

            assert.isTrue(serviceStub.call.notCalled);
        });
    });

    describe('getCombineLabel', function () {
        var items = [{ productId: 'P1', itemId: 'pli-1' }];
        var details = { 'pli-1': { quantity: 1, reasonId: 'damaged', subReasonId: 'product_was_defective' } };

        function lineItem(label) {
            return {
                productID: 'P1',
                quantity: 1,
                reasonCode: JSON.stringify({ id: 'damaged' }),
                subReasonCode: JSON.stringify({ id: 'product_was_defective' }),
                creationDate: new Date(),
                label: label,
                labelType: 'PDF'
            };
        }

        it('should store no label, and not call Zenkraft, for a return waiting for approval', function () {
            var result = returnHelper.getCombineLabel({ returnLineItems: [lineItem(undefined)] }, items, details);

            assert.isNull(result.combinedLabel);
            assert.isTrue(serviceStub.call.notCalled);
        });

        it('should use the label of a return with one label as it is', function () {
            var result = returnHelper.getCombineLabel({ returnLineItems: [lineItem('LABEL-BASE64')] }, items, details);

            assert.equal(result.combinedLabel, 'LABEL-BASE64');
            assert.isTrue(serviceStub.call.notCalled);
        });
    });

    describe('createReturnCase', function () {
        var shipCalls;
        var mergeCalls;
        var refuseShipCall;

        function createReturnOrder(lines) {
            var address = { address1: '1 Main St', city: 'Boston', stateCode: 'MA', postalCode: '02110', countryCode: { value: 'US' }, fullName: 'Ann Shopper', phone: '555' };
            var plis = lines.map(function (line) {
                var product = {
                    ID: line.productID,
                    custom: {},
                    isVariant: function () { return false; },
                    getCategories: function () { return { toArray: function () { return []; } }; }
                };
                return { UUID: line.uuid, productID: line.productID, quantityValue: line.quantity, product: product, getProduct: function () { return product; } };
            });
            return {
                orderNo: 'O-1',
                customerEmail: 'ann@example.com',
                shipments: [{ shippingAddress: address }],
                getCustomer: function () { return { getCustomerGroups: function () { return { toArray: function () { return []; } }; } }; },
                getProductLineItems: function () { return { toArray: function () { return plis; } }; },
                getAllProductLineItems: function () {
                    return { iterator: function () { var i = 0; return { hasNext: function () { return i < plis.length; }, next: function () { return plis[i++]; } }; } };
                },
                getDefaultShipment: function () { return { shippingAddress: address, getShippingAddress: function () { return address; }, custom: {} }; },
                getBillingAddress: function () { return { phone: '' }; }
            };
        }

        // As getValidatedReturnItems builds them
        function returnItems(lines) {
            var returnDetails = {};
            var items = lines.map(function (line) {
                returnDetails[line.uuid] = { quantity: line.quantity, reasonId: 'damaged', subReasonId: 'torn' };
                return { itemId: line.uuid, UUID: line.uuid, productId: line.productID, productName: line.productID, productPrice: 10, productWeight: 1, quantity: line.quantity };
            });
            return { items: items, returnDetails: returnDetails };
        }

        function lines(count) {
            var result = [];
            for (var i = 1; i <= count; i++) {
                result.push({ uuid: 'pli-' + i, productID: 'P' + i, quantity: 1 });
            }
            return result;
        }

        function create(orderLines) {
            var request = returnItems(orderLines);
            return returnHelper.createReturnCase(createReturnOrder(orderLines), request.items, request.returnDetails);
        }

        beforeEach(function () {
            prefs.zenkraftNewReturnObjectPerReturn = true;
            prefs.zenkraftReturnApprovalCatalogCategories = null;
            prefs.zenkraftRecipientCountryCode = 'US';
            shipCalls = [];
            mergeCalls = [];
            refuseShipCall = null;
            var labelNo = 0;
            // Zenkraft: /ship makes a label (or refuses the call numbered refuseShipCall), /label merges labels
            serviceStub.call.callsFake(function (path) {
                if (path === '/ship') {
                    shipCalls.push({ inTransaction: inTransaction });
                    if (shipCalls.length === refuseShipCall) {
                        return { ok: false, object: null };
                    }
                    labelNo++;
                    return {
                        ok: true,
                        object: {
                            shipment: {
                                id: 'S' + labelNo,
                                tracking_number: '1Z00' + labelNo,
                                carrier: 'ups',
                                label_type: 'PDF',
                                packages: [{ label: 'LABEL-' + labelNo }],
                                recipient: { name: 'Warehouse' },
                                shipping_documents: [{ description: 'qr_code', document: 'QR-' + labelNo, document_type: 'png' }]
                            }
                        }
                    };
                }
                if (path === '/label') {
                    mergeCalls.push({ inTransaction: inTransaction });
                    return { ok: true, object: { pdf: 'MERGED' } };
                }
                return { ok: true, object: [] };
            });
        });

        it('should get every label first, then store the return and its line items with them', function () {
            var result = create(lines(2));

            assert.lengthOf(result.returnLines, 2);
            // No call to Zenkraft while a transaction is open
            assert.deepEqual(shipCalls.concat(mergeCalls).map(function (call) { return call.inTransaction; }), [false, false, false]);
            var returnCase = storedReturns[result.returnID];
            assert.equal(returnCase.custom.orderNumber, 'O-1');
            assert.equal(returnCase.custom.returnLineItems, result.returnID + '-1,' + result.returnID + '-2');
            assert.equal(returnCase.custom.combinedLabel, 'MERGED');
            var first = existingLineItems[result.returnID + '-1'].custom;
            assert.equal(first.label, 'LABEL-1');
            assert.equal(first.trackingNumber, '1Z001');
            assert.equal(first.pliUUID, 'pli-1');
            assert.instanceOf(first.approvedDate, Date);
            assert.equal(existingLineItems[result.returnID + '-2'].custom.label, 'LABEL-2');
        });

        it('should store nothing when a label can\'t be created, so the shopper can try again', function () {
            refuseShipCall = 2;

            var result = create(lines(2));

            assert.isNull(result.returnLines);
            assert.isEmpty(Object.keys(storedReturns));
            assert.isEmpty(Object.keys(existingLineItems));

            refuseShipCall = null;
            assert.lengthOf(create(lines(2)).returnLines, 2);
        });

        it('should make one label for all items with a single shipment, and store nothing when it fails', function () {
            prefs.zenkraftSingleShipmentForMultipleReturnLineItems = true;
            refuseShipCall = 1;

            assert.isNull(create(lines(2)).returnLines);
            assert.isEmpty(Object.keys(existingLineItems));

            refuseShipCall = null;
            var result = create(lines(2));
            assert.lengthOf(shipCalls, 2);
            assert.deepEqual(result.returnLines.map(function (returnLine) { return returnLine.custom.label; }), ['LABEL-1', 'LABEL-1']);
            assert.equal(storedReturns[result.returnID].custom.combinedLabel, 'LABEL-1');
        });

        it('should add to the order\'s return case when a new one isn\'t created per return, numbering after its line items', function () {
            prefs.zenkraftNewReturnObjectPerReturn = false;
            var existingCase = { UUID: 'uuid-R0', creationDate: new Date(), custom: { id: 'R0', orderNumber: 'O-1', returnLineItems: 'R0-1' } };
            existingReturnCases = [existingCase];
            storedReturns.R0 = existingCase;
            existingLineItems['R0-1'] = { UUID: 'uuid-R0-1', creationDate: new Date(), custom: { id: 'R0-1', productID: 'P9', quantity: 1 } };

            var result = create(lines(1));

            assert.equal(result.returnID, 'R0');
            assert.equal(existingCase.custom.returnLineItems, 'R0-1,R0-2');
            assert.equal(existingLineItems['R0-2'].custom.label, 'LABEL-1');
        });

        it('should store nothing when storing fails part-way', function () {
            var createCustomObject = customObjectMgr.createCustomObject;
            customObjectMgr.createCustomObject = function (type, id) {
                if (/-2$/.test(id)) {
                    throw new Error('Quota exceeded');
                }
                return createCustomObject(type, id);
            };

            var result = create(lines(2));

            assert.isNull(result.returnLines);
            assert.isEmpty(Object.keys(storedReturns));
            assert.isEmpty(Object.keys(existingLineItems));
        });

        it('should refuse a return with more items than one request can store, before any label is created', function () {
            assert.isNull(create(lines(10)).returnLines);
            assert.isEmpty(shipCalls);
            assert.isEmpty(Object.keys(storedReturns));

            assert.lengthOf(create(lines(9)).returnLines, 9);
        });

        it('should store a return request without labels, and not call Zenkraft, when the return needs approval', function () {
            prefs.zenkraftReturnsApprovalRequire = true;

            var result = create(lines(1));

            assert.lengthOf(result.returnLines, 1);
            assert.isEmpty(shipCalls);
            var lineItem = existingLineItems[result.returnID + '-1'].custom;
            assert.isUndefined(lineItem.label);
            assert.isUndefined(lineItem.pliUUID);
            assert.isUndefined(lineItem.approvedDate);
            assert.isNull(storedReturns[result.returnID].custom.combinedLabel);
        });
    });

    describe('getZKReturnDetails', function () {
        it('should look up a Zenkraft return ID', function () {
            serviceStub.call.returns({ ok: true, object: { id: '2ff7047526e64a10a3e952680aca7e81' } });

            assert.deepEqual(returnHelper.getZKReturnDetails('2ff7047526e64a10a3e952680aca7e81'), { id: '2ff7047526e64a10a3e952680aca7e81' });
            assert.deepEqual(JSON.parse(serviceStub.call.firstCall.args[1]), { id: '2ff7047526e64a10a3e952680aca7e81' });
            assert.equal(serviceStub.call.firstCall.args[3], 'details');
        });

        it('should not call Zenkraft for an ID that could change the request URL', function () {
            ['../shippingaccount', 'abc?customer_id=x', 'a/b', 'a%2Fb', 'a#b', 'a&b', '', 'x'.repeat(65), null].forEach(function (returnId) {
                assert.isNull(returnHelper.getZKReturnDetails(returnId), String(returnId));
            });
            assert.isTrue(serviceStub.call.notCalled);
            assert.isTrue(loggerStub.warn.called);
        });
    });

    describe('getReturnableItems', function () {
        beforeEach(function () {
            prefs.zenkraftReturnReasonsConfig = JSON.stringify({
                reasons: [
                    { id: 'wrong_size', categories: ['suits'], display: 'Wrong Size' },
                    { id: 'damaged', categories: ['zk-default'], display: 'Damaged' },
                    { id: 'faded', categories: ['shirts', 'suits'], display: 'Faded' }
                ]
            });
            prefs.setZenkraftOrderReturnsOneToOneRelation = true;
        });

        function reasonIds(item) {
            return item.returnReasons.map(function (reason) { return reason.id; });
        }

        it('should list the reasons for the product\'s categories and every product, in the configured order', function () {
            var variant = createProduct([], { master: createProduct(['suits']) });
            var items = returnHelper.getReturnableItems(createOrderWithLines([
                { uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct(['shirts']) },
                { uuid: 'pli-2', productID: 'P2', quantity: 1, product: variant }
            ]));

            assert.deepEqual(reasonIds(items[0]), ['damaged', 'faded']);
            assert.deepEqual(reasonIds(items[1]), ['wrong_size', 'damaged', 'faded']);
        });

        it('should give a product without categories, or that no longer exists, the reasons for every product', function () {
            var items = returnHelper.getReturnableItems(createOrderWithLines([
                { uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct([]) },
                { uuid: 'pli-2', productID: 'P2', quantity: 1, product: null }
            ]));

            assert.deepEqual(reasonIds(items[0]), ['damaged']);
            assert.deepEqual(reasonIds(items[1]), ['damaged']);
            assert.isTrue(items[1].applicableForReturn);
        });

        it('should give no reasons, and log an error, when the reasons preference is not valid JSON', function () {
            prefs.zenkraftReturnReasonsConfig = '{ reasons: ';
            var items = returnHelper.getReturnableItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 1, product: createProduct(['shirts']) }]));

            assert.deepEqual(items[0].returnReasons, []);
            assert.isTrue(loggerStub.error.calledOnce);
        });

        it('should mark a product in a non-returnable category as not returnable', function () {
            prefs.zenkraftCatalogCategoriesForNonReturnableItems = 'final-sale';
            var items = returnHelper.getReturnableItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['final-sale']) }]));

            assert.deepEqual(items[0], { itemId: 'pli-1', applicableForReturn: false, returnableQuantity: 2, returnReasons: items[0].returnReasons });
        });

        it('should take returned quantities off, from a product\'s first line items first', function () {
            existingReturnCases = [{ custom: { returnLineItems: 'R1-1' } }];
            existingLineItems['R1-1'] = { creationDate: new Date(), custom: { productID: 'P1', quantity: 3 } };
            var items = returnHelper.getReturnableItems(createOrderWithLines([
                { uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) },
                { uuid: 'pli-2', productID: 'P1', quantity: 2, product: createProduct(['shirts']) },
                { uuid: 'pli-3', productID: 'P2', quantity: 1, product: createProduct(['shirts']) }
            ]));

            assert.deepEqual(items.map(function (item) { return [item.itemId, item.applicableForReturn, item.returnableQuantity]; }), [
                ['pli-1', false, 0],
                ['pli-2', true, 1],
                ['pli-3', true, 1]
            ]);
        });

        it('should offer the ordered quantity when returns are not related one-to-one with the order', function () {
            prefs.setZenkraftOrderReturnsOneToOneRelation = false;
            existingReturnCases = [{ custom: { returnLineItems: 'R1-1' } }];
            existingLineItems['R1-1'] = { creationDate: new Date(), custom: { productID: 'P1', quantity: 2 } };
            var items = returnHelper.getReturnableItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }]));

            assert.isTrue(items[0].applicableForReturn);
            assert.equal(items[0].returnableQuantity, 2);
        });

        it('should count Zenkraft API returns it is given without calling Zenkraft again (zkapi)', function () {
            prefs.zenkraftReturnsHandler = { value: 'zkapi' };
            var zkReturnCases = [{ id: 'zk-1', returnLineItems: [{ productID: 'P1', quantity: 1 }] }];
            var items = returnHelper.getReturnableItems(createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: 2, product: createProduct(['shirts']) }]), zkReturnCases);

            assert.equal(items[0].returnableQuantity, 1);
            assert.isTrue(serviceStub.call.notCalled);
        });
    });

    describe('getOrderZKReturnCases', function () {
        it('should list the order\'s returns with the customer ID they were created with', function () {
            var order = createOrderWithLines([]);
            order.customerEmail = 'shopper@example.com';
            serviceStub.call.returns({
                ok: true,
                object: [
                    { id: 'zk-1', created: '2026-10-20T10:00:00Z', shipment: { reference_number: 'O-1', status: 'IN_TRANSIT', tracking_number: '1Z999' }, return_lines: [{ sku: 'P1', quantity: 1 }] },
                    { id: 'zk-2', created: '2026-10-20T10:00:00Z', shipment: { reference_number: 'O-2', status: 'IN_TRANSIT' }, return_lines: [{ sku: 'P1', quantity: 1 }] }
                ]
            });

            var returnCases = returnHelper.getOrderZKReturnCases(order);

            // Asked for the order's returns, so returns of the customer's other orders can't crowd them out
            assert.deepEqual(JSON.parse(serviceStub.call.firstCall.args[1]), { customerNo: 'shopper@example.com', orderNo: 'O-1' });
            assert.deepEqual(returnCases.map(function (returnCase) { return returnCase.id; }), ['zk-1']);
            assert.equal(returnCases[0].returnLineItems[0].productID, 'P1');
            assert.equal(returnCases[0].returnLineItems[0].trackingNumber, '1Z999');
        });
    });

    describe('Zenkraft API return drafts (getZenkraftReturnMethods, getZKReturnDraft)', function () {
        var DRAFT = '2ff7047526e64a10a3e952680aca7e81';
        var OTHER_DRAFT = '9b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e';
        var THIRD_DRAFT = '0a1b2c3d4e5f60718293a4b5c6d7e8f9';
        var confirmedReturns;

        function draftRecord(orderNo, uuid, quantity) {
            return { creationDate: new Date(), custom: { orderNumber: orderNo, items: JSON.stringify([{ itemId: uuid, quantity: quantity }]) } };
        }

        function zkOrder(boughtQuantity) {
            var address = { address1: '1 Main St', city: 'Boston', stateCode: 'MA', postalCode: '02110', countryCode: { value: 'US' }, fullName: 'Ann Shopper', phone: '555' };
            var result = createOrderWithLines([{ uuid: 'pli-1', productID: 'P1', quantity: boughtQuantity, product: createProduct(['shirts']) }]);
            result.customerNo = 'C-1';
            result.getDefaultShipment = function () { return { shippingAddress: address, getShippingAddress: function () { return address; } }; };
            result.getBillingAddress = function () { return { phone: '' }; };
            return result;
        }

        beforeEach(function () {
            prefs.zenkraftReturnsHandler = { value: 'zkapi' };
            // Zenkraft: lists the confirmed returns (GET /returns), confirms any option, as often as it's asked
            confirmedReturns = [];
            serviceStub.call.callsFake(function (path, body, method, type) {
                if (type === 'returns') {
                    return { ok: true, object: confirmedReturns };
                }
                if (type === 'create') {
                    var confirmed = { id: 'zk-' + (confirmedReturns.length + 1), created: '2026-11-04T10:00:00Z', shipment: { reference_number: 'O-1', status: 'LABEL_CREATED' }, return_lines: [{ sku: 'P1', quantity: 1 }] };
                    confirmedReturns.push(confirmed);
                    return { ok: true, object: [confirmed] };
                }
                return { ok: true, object: [] };
            });
        });

        it('should record one draft per drafted return, whatever number of options it has', function () {
            serviceStub.call.callsFake(function () {
                return {
                    ok: true,
                    object: [{
                        return_methods: [
                            { id: 'drop-off', options: [{ id: DRAFT + '_1' }, { id: DRAFT + '_2' }, { id: DRAFT + '_3' }] },
                            { id: 'pickup', options: [{ id: DRAFT + '_4' }] }
                        ]
                    }]
                };
            });
            var items = [{ itemId: 'pli-1', UUID: 'pli-1', productId: 'P1', productName: 'P1', productPrice: 10, productWeight: 1, quantity: 1 }];

            var methods = returnHelper.getZenkraftReturnMethods(zkOrder(1), items, { 'pli-1': { quantity: 1, reasonId: 'damaged' } });

            assert.lengthOf(methods, 2);
            assert.isTrue(customObjectMgr.createCustomObject.calledOnceWithExactly('zenkraftReturnDraft', DRAFT));
            assert.equal(returnDrafts[DRAFT].custom.orderNumber, 'O-1');
            assert.deepEqual(JSON.parse(returnDrafts[DRAFT].custom.items), [{ itemId: 'pli-1', quantity: 1 }]);
        });

        it('should record nothing when Zenkraft drafts no return method', function () {
            serviceStub.call.callsFake(function () { return { ok: true, object: [{ return_methods: [] }] }; });

            returnHelper.getZenkraftReturnMethods(zkOrder(1), [], {});

            assert.isTrue(customObjectMgr.createCustomObject.notCalled);
        });

        it('should let an option of a draft for the order be confirmed while its items are left to return', function () {
            returnDrafts[DRAFT] = draftRecord('O-1', 'pli-1', 1);

            assert.strictEqual(returnHelper.getZKReturnDraft(zkOrder(1), DRAFT + '_2'), returnDrafts[DRAFT]);
        });

        it('should refuse an option drafted for another order, not drafted here, or in another format', function () {
            returnDrafts[DRAFT] = draftRecord('O-2', 'pli-1', 1);
            returnDrafts['lock-O-1'] = { creationDate: new Date(), custom: { orderNumber: 'O-1' } };

            [DRAFT + '_1', OTHER_DRAFT + '_1', DRAFT, '../returns_1', DRAFT + '_1?x=1', 'lock-O-1', 'lock-O-1_1', null].forEach(function (optionId) {
                assert.isNull(returnHelper.getZKReturnDraft(zkOrder(1), optionId), String(optionId));
            });
            assert.isTrue(serviceStub.call.notCalled);
        });

        it('should refuse confirming an option again once its items are returned, or another option of the same draft', function () {
            returnDrafts[DRAFT] = draftRecord('O-1', 'pli-1', 1);

            assert.isNotNull(returnHelper.getZKReturnDraft(zkOrder(1), DRAFT + '_1'));
            returnHelper.createZKReturnCase(DRAFT + '_1');

            assert.isNull(returnHelper.getZKReturnDraft(zkOrder(1), DRAFT + '_1'));
            assert.isNull(returnHelper.getZKReturnDraft(zkOrder(1), DRAFT + '_2'));
        });

        it('should refuse a second draft for the only unit bought once the first is confirmed', function () {
            returnDrafts[DRAFT] = draftRecord('O-1', 'pli-1', 1);
            returnDrafts[OTHER_DRAFT] = draftRecord('O-1', 'pli-1', 1);

            returnHelper.createZKReturnCase(DRAFT + '_1');

            assert.isNull(returnHelper.getZKReturnDraft(zkOrder(1), OTHER_DRAFT + '_1'));
        });

        it('should let a shopper return each unit bought, one return at a time, but no more', function () {
            [DRAFT, OTHER_DRAFT, THIRD_DRAFT].forEach(function (draftId) {
                returnDrafts[draftId] = draftRecord('O-1', 'pli-1', 1);
            });

            assert.isNotNull(returnHelper.getZKReturnDraft(zkOrder(2), DRAFT + '_1'));
            returnHelper.createZKReturnCase(DRAFT + '_1');
            assert.isNotNull(returnHelper.getZKReturnDraft(zkOrder(2), OTHER_DRAFT + '_1'));
            returnHelper.createZKReturnCase(OTHER_DRAFT + '_1');

            assert.isNull(returnHelper.getZKReturnDraft(zkOrder(2), THIRD_DRAFT + '_1'));
        });
    });

    describe('lockOrderReturns', function () {
        var orderOne = { orderNo: 'O-1' };

        it('should let one request hold the order\'s lock, and refuse another until it\'s removed', function () {
            assert.isTrue(returnHelper.lockOrderReturns(orderOne));
            assert.isFalse(returnHelper.lockOrderReturns(orderOne));

            returnHelper.unlockOrderReturns(orderOne);
            assert.isTrue(returnHelper.lockOrderReturns(orderOne));
        });

        it('should lock each order on its own', function () {
            assert.isTrue(returnHelper.lockOrderReturns(orderOne));
            assert.isTrue(returnHelper.lockOrderReturns({ orderNo: 'O-2' }));
        });

        it('should replace a lock left by a request that stopped, after 30 seconds', function () {
            returnDrafts['lock-O-1'] = { creationDate: new Date(Date.now() - 31000), custom: { id: 'lock-O-1', orderNumber: 'O-1' } };
            assert.isTrue(returnHelper.lockOrderReturns(orderOne));

            returnDrafts['lock-O-1'].creationDate = new Date(Date.now() - 10000);
            assert.isFalse(returnHelper.lockOrderReturns(orderOne));
        });

        it('should refuse when another request creates the lock at the same moment', function () {
            var createCustomObject = customObjectMgr.createCustomObject;
            // The other request's lock isn't visible yet, but its key is taken when this one is stored
            customObjectMgr.createCustomObject = function () { throw new Error('Duplicate key lock-O-1'); };

            assert.isFalse(returnHelper.lockOrderReturns(orderOne));
            customObjectMgr.createCustomObject = createCustomObject;
        });
    });

    describe('getCustomerReturns', function () {
        it('should send a stored return case\'s QR code and its lines\' tracking numbers, but no labels (sfcc)', function () {
            existingReturnCases = [{
                UUID: 'uuid-R1',
                creationDate: new Date('2026-10-20T10:00:00Z'),
                custom: { id: 'R1', orderNumber: 'O-1', returnLineItems: 'R1-1', combinedLabel: 'combined-label', qrCode: 'QR-BASE64', qrCodeType: 'PNG' }
            }];
            existingLineItems['R1-1'] = {
                UUID: 'uuid-R1-1',
                creationDate: new Date('2026-10-20T10:00:00Z'),
                custom: { id: 'R1-1', productID: 'P1', quantity: 1, label: 'line-label', trackingNumber: '1Z999' }
            };

            var returnCase = returnHelper.getCustomerReturns('C-1', ['O-1'])[0];

            assert.equal(returnCase.qrCode, 'QR-BASE64');
            assert.equal(returnCase.qrCodeType, 'PNG');
            assert.notProperty(returnCase, 'combinedLabel');
            assert.equal(returnCase.returnLineItems[0].trackingNumber, '1Z999');
            assert.notProperty(returnCase.returnLineItems[0], 'label');
        });
    });

    afterEach(function () {
        delete global.empty;
        sinon.restore();
    });

    describe('updateMissingData', function () {
        it('should fill in fields the order is missing', function () {
            returnHelper.updateMissingData(order, { email: ' shopper@example.com ', phone: '555 0100' });

            assert.isTrue(order.setCustomerEmail.calledWith('shopper@example.com'));
            assert.isTrue(shippingAddress.setPhone.calledWith('555 0100'));
        });

        it('should not change a field the order already has, and log a warning', function () {
            returnHelper.updateMissingData(order, { address: '9 Other Street' });

            assert.isTrue(shippingAddress.setAddress1.notCalled);
            assert.isTrue(loggerStub.warn.calledOnce);
        });

        it('should not write the shipping phone when the order has a phone on the billing address', function () {
            billingAddress.phone = '555 0199';
            returnHelper.updateMissingData(order, { phone: '555 0100' });

            assert.isTrue(shippingAddress.setPhone.notCalled);
        });

        it('should ignore fields the preference does not list', function () {
            returnHelper.updateMissingData(order, { postalCode: '99999' });

            assert.isTrue(shippingAddress.setAddress1.notCalled);
            assert.isTrue(shippingAddress.setPhone.notCalled);
            assert.isTrue(order.setCustomerEmail.notCalled);
        });
    });

    describe('checkForMissingImportantData', function () {
        it('should report exactly the empty required fields', function () {
            var result = returnHelper.checkForMissingImportantData(order);

            assert.deepEqual(result.missingData.map(function (m) { return m.field; }), ['email', 'phone']);
        });

        it('should report nothing when every required field has a value', function () {
            order.customerEmail = 'shopper@example.com';
            shippingAddress.phone = '555 0100';

            assert.isNull(returnHelper.checkForMissingImportantData(order));
        });
    });

    describe('checkOrderReturnApproval', function () {
        beforeEach(function () {
            prefs.zenkraftReturnsApprovalRequire = true;
            order.getCustomer = function () {
                return { getCustomerGroups: function () { return { toArray: function () { return []; } }; } };
            };
            order.getProductLineItems = function () { return { toArray: function () { return []; } }; };
        });

        it('should require approval with the sfcc handler when every return needs approval', function () {
            assert.isTrue(returnHelper.checkOrderReturnApproval(order));
        });

        it('should never require approval with the zkapi handler, since Zenkraft API returns have no approval step', function () {
            prefs.zenkraftReturnsHandler = { value: 'zkapi' };

            assert.isFalse(returnHelper.checkOrderReturnApproval(order));
        });
    });
});
