'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

describe('zenkraft-returns custom API: returns', function () {
    var zenkraftReturns;
    var helperStub;
    var prefs;
    var order;
    var rendered;

    function returnCaseObject(id, combinedLabel) {
        return { custom: { id: id, combinedLabel: combinedLabel } };
    }

    function callReturns() {
        zenkraftReturns.returns();
        return rendered;
    }

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        var customer = { getID: function () { return 'cust-1'; }, registered: true, profile: { customerNo: 'C-1' } };
        global.request = {
            session: { customer: customer },
            getHttpParameterMap: function () {
                return { get: function () { return { getStringValue: function () { return 'O-1'; } }; } };
            }
        };

        prefs = { zenkraftReturnsHandler: { value: 'sfcc' }, zenkraftReturnsRequireLogin: true };
        order = { orderNo: 'O-1', creationDate: new Date(), customerNo: 'C-1', getCustomer: function () { return customer; } };
        rendered = null;

        helperStub = {
            checkOrderDaysAvailableForReturn: sinon.stub().returns(true),
            checkOrderReturnApproval: sinon.stub().returns(false),
            getReasonPhotoLimits: sinon.stub().returns({}),
            checkForMissingImportantData: sinon.stub().returns(null),
            getReturnableItems: sinon.stub().returns([{ itemId: 'pli-1', applicableForReturn: true, returnableQuantity: 1, returnReasons: [] }]),
            checkForExistingReturnCases: sinon.stub().returns([]),
            getReturnCase: sinon.stub(),
            getOrderZKReturnCases: sinon.stub().returns([])
        };

        zenkraftReturns = proxyquire('../../../cartridge/rest-apis/zenkraft-returns/zenkraft-returns', {
            'dw/system/Logger': { getLogger: sinon.stub().returns({ warn: sinon.stub(), error: sinon.stub(), info: sinon.stub() }) },
            'dw/order/Order': {},
            'dw/order/OrderMgr': { getOrder: function (orderNo) { return orderNo === order.orderNo ? order : null; } },
            'dw/web/Resource': {},
            'dw/system/RESTResponseMgr': {
                createSuccess: function (payload) { return { render: function () { rendered = payload; } }; },
                createError: function () { return { render: function () { rendered = { status: 500 }; } }; }
            },
            'dw/system/Site': { getCurrent: function () { return { getCustomPreferenceValue: function (id) { return prefs[id]; } }; } },
            '*/cartridge/scripts/helpers/zenkraftReturnHelper.js': helperStub
        });
    });

    afterEach(function () {
        delete global.empty;
        delete global.request;
        sinon.restore();
    });

    it('should send the return settings, missing data and item return options while the order can be returned', function () {
        var missingData = { missingData: [{ field: 'phone', label: 'Phone' }], missingDataLabel: 'Missing' };
        helperStub.checkForMissingImportantData.returns(missingData);

        var payload = callReturns();

        assert.isTrue(payload.availableForReturn);
        assert.equal(payload.zenkraftReturnsHandler, 'sfcc');
        assert.deepEqual(payload.missingData, missingData);
        assert.equal(payload.items[0].itemId, 'pli-1');
        assert.deepEqual(payload.returnCases, []);
    });

    it('should list stored return cases with their label and ISO dates, leaving out empty and unreadable ones (sfcc)', function () {
        var created = new Date('2026-10-20T10:00:00Z');
        var cases = [returnCaseObject('R1', 'combined-label'), returnCaseObject('R2', null), returnCaseObject('R3', null), returnCaseObject('R4', null)];
        helperStub.checkForExistingReturnCases.returns(cases);
        helperStub.getReturnCase.withArgs(cases[0]).returns({ id: 'R1', combinedLabel: 'combined-label', qrCode: 'QR-BASE64', qrCodeType: 'PNG', returnLineItems: [{ productID: 'P1', quantity: 1, label: 'line-label', trackingNumber: '1Z999', creationDate: created, approvedDate: '10/20/26' }] });
        // Saved before combined labels were stored: its first line's label
        helperStub.getReturnCase.withArgs(cases[1]).returns({ id: 'R2', combinedLabel: null, returnLineItems: [{ returnID: 'R2', productID: 'P2', quantity: 2, label: 'old-label', creationDate: created, approvedDate: '10/20/26' }] });
        // None of its line items could be found: the stored ID list is kept
        helperStub.getReturnCase.withArgs(cases[2]).returns({ id: 'R3', returnLineItems: 'R3-1' });
        // Can't be read
        helperStub.getReturnCase.withArgs(cases[3]).returns(null);

        var payload = callReturns();

        assert.deepEqual(payload.returnCases, [
            {
                id: 'R1',
                orderNumber: 'O-1',
                zkReturnCase: false,
                combinedLabel: 'combined-label',
                qrCode: 'QR-BASE64',
                qrCodeType: 'PNG',
                returnLineItems: [{ returnID: 'R1', productID: 'P1', product: null, quantity: 1, trackingNumber: '1Z999', trackingStage: null, creationDate: '2026-10-20T10:00:00.000Z', approvedDate: '10/20/26' }]
            },
            {
                id: 'R2',
                orderNumber: 'O-1',
                zkReturnCase: false,
                combinedLabel: 'old-label',
                qrCode: null,
                qrCodeType: null,
                returnLineItems: [{ returnID: 'R2', productID: 'P2', product: null, quantity: 2, trackingNumber: null, trackingStage: null, creationDate: '2026-10-20T10:00:00.000Z', approvedDate: '10/20/26' }]
            }
        ]);
        assert.isTrue(helperStub.getOrderZKReturnCases.notCalled);
        assert.isNull(helperStub.getReturnableItems.firstCall.args[1]);
    });

    it('should not offer a label for a return waiting for approval, even one saved with "undefined" as its label (sfcc)', function () {
        var cases = [returnCaseObject('R1', 'undefined')];
        helperStub.checkForExistingReturnCases.returns(cases);
        helperStub.getReturnCase.withArgs(cases[0]).returns({ id: 'R1', combinedLabel: 'undefined', returnLineItems: [{ productID: 'P1', quantity: 1, creationDate: new Date() }] });

        var returnCase = callReturns().returnCases[0];

        assert.equal(returnCase.id, 'R1');
        assert.isNull(returnCase.combinedLabel);
        assert.isNull(returnCase.returnLineItems[0].approvedDate);
    });

    it('should read the order\'s Zenkraft API returns once, for the return cases and the quantities left (zkapi)', function () {
        prefs.zenkraftReturnsHandler = { value: 'zkapi' };
        var zkReturnCases = [{ id: 'zk-1', orderNumber: 'O-1', zkReturnCase: true, combinedLabel: false, returnLineItems: [{ returnID: 'zk-1', productID: 'P1', quantity: 1, trackingStage: 'IN_TRANSIT', creationDate: '2026-10-20T10:00:00.000Z', approvedDate: '2026-10-20T10:00:00.000Z' }] }];
        helperStub.getOrderZKReturnCases.returns(zkReturnCases);

        var payload = callReturns();

        assert.isTrue(helperStub.getOrderZKReturnCases.calledOnce);
        assert.strictEqual(helperStub.getReturnableItems.firstCall.args[1], zkReturnCases);
        assert.isTrue(helperStub.checkForExistingReturnCases.notCalled);
        assert.equal(payload.returnCases[0].id, 'zk-1');
        assert.isTrue(payload.returnCases[0].zkReturnCase);
        assert.isNull(payload.returnCases[0].combinedLabel);
        assert.isNull(payload.returnCases[0].qrCode);
    });

    it('should still list return cases after the return window has closed, without the return options', function () {
        helperStub.checkOrderDaysAvailableForReturn.returns(false);
        var stored = returnCaseObject('R1', 'label');
        helperStub.checkForExistingReturnCases.returns([stored]);
        helperStub.getReturnCase.returns({ id: 'R1', combinedLabel: 'label', returnLineItems: [{ productID: 'P1', quantity: 1 }] });

        var payload = callReturns();

        assert.isFalse(payload.availableForReturn);
        assert.lengthOf(payload.returnCases, 1);
        assert.notProperty(payload, 'items');
        assert.notProperty(payload, 'missingData');
        assert.isTrue(helperStub.getReturnableItems.notCalled);
    });

    it('should answer with an error, and no return data, for an order the shopper does not own', function () {
        order.getCustomer = function () { return { getID: function () { return 'someone-else'; } }; };
        order.customerNo = 'C-2';

        var payload = callReturns();

        assert.deepEqual(payload, { error: 'No order found' });
    });
});

describe('zenkraft-returns custom API: returnsHistory', function () {
    var zenkraftReturns;
    var getCustomerReturns;
    var rendered;

    beforeEach(function () {
        global.request = { session: { customer: { profile: { customerNo: 'C-1' } } } };
        rendered = null;
        getCustomerReturns = sinon.stub().returns([]);
        var placedOrders = [{ orderNo: 'O-1' }];

        zenkraftReturns = proxyquire('../../../cartridge/rest-apis/zenkraft-returns/zenkraft-returns', {
            'dw/system/Logger': { getLogger: sinon.stub().returns({ warn: sinon.stub(), error: sinon.stub(), info: sinon.stub() }) },
            'dw/order/Order': { ORDER_STATUS_CREATED: 0, ORDER_STATUS_FAILED: 8 },
            'dw/order/OrderMgr': {
                searchOrders: function () {
                    var i = 0;
                    return {
                        hasNext: function () { return i < placedOrders.length; },
                        next: function () { return placedOrders[i++]; },
                        close: function () {}
                    };
                }
            },
            'dw/web/Resource': {},
            'dw/system/RESTResponseMgr': {
                createSuccess: function (payload) { return { render: function () { rendered = payload; } }; },
                createError: function () { return { render: function () { rendered = { status: 500 }; } }; }
            },
            'dw/system/Site': { getCurrent: function () { return { getCustomPreferenceValue: function () { return null; } }; } },
            '*/cartridge/scripts/helpers/zenkraftReturnHelper.js': { getCustomerReturns: getCustomerReturns }
        });
    });

    afterEach(function () {
        delete global.request;
        sinon.restore();
    });

    it('should send each return\'s QR code and its lines\' tracking numbers, but no labels', function () {
        getCustomerReturns.returns([{
            id: 'R1',
            orderNumber: 'O-1',
            qrCode: 'QR-BASE64',
            qrCodeType: 'PNG',
            returnLineItems: [{ productID: 'P1', quantity: 1, trackingNumber: '1Z999', label: 'line-label' }]
        }]);

        zenkraftReturns.returnsHistory();

        assert.isTrue(getCustomerReturns.calledWith('C-1', ['O-1']));
        var returnCase = rendered.returns[0];
        assert.equal(returnCase.qrCode, 'QR-BASE64');
        assert.equal(returnCase.qrCodeType, 'PNG');
        assert.equal(returnCase.returnLineItems[0].trackingNumber, '1Z999');
        assert.notProperty(returnCase.returnLineItems[0], 'label');
    });

    it('should leave out returns whose line items are gone instead of failing the whole page', function () {
        getCustomerReturns.returns([
            // Line items deleted: the helper keeps the stored ID list
            { id: 'R-GONE', orderNumber: 'O-1', returnLineItems: 'LI-1,LI-2' },
            // Creating the return failed before any line item was saved
            { id: 'R-EMPTY', orderNumber: 'O-1', returnLineItems: null },
            { id: 'R-OK', orderNumber: 'O-1', returnLineItems: [{ productID: 'P1', quantity: 1 }] }
        ]);

        zenkraftReturns.returnsHistory();

        assert.deepEqual(rendered.returns.map(function (returnCase) { return returnCase.id; }), ['R-OK']);
    });
});

describe('zenkraft-returns custom API: returns handler guards', function () {
    var zenkraftReturns;
    var helperStub;
    var prefs;
    var order;
    var rendered;
    var requestBody;

    beforeEach(function () {
        global.empty = function (val) { return val === null || val === undefined || val === ''; };
        var customer = { getID: function () { return 'cust-1'; }, registered: true, profile: { customerNo: 'C-1' } };
        requestBody = { orderId: 'O-1', methodId: 'method-1', items: [{ itemId: 'pli-1' }], returnDetails: { 'pli-1': { quantity: 1 } } };
        global.request = {
            session: { customer: customer },
            getHttpParameterMap: function () {
                return { requestBodyAsString: JSON.stringify(requestBody) };
            }
        };

        prefs = { zenkraftReturnsRequireLogin: true };
        order = { orderNo: 'O-1', creationDate: new Date(), customerNo: 'C-1', getCustomer: function () { return customer; } };
        rendered = null;

        helperStub = {
            usesZenkraftApi: sinon.stub(),
            checkOrderDaysAvailableForReturn: sinon.stub().returns(true),
            checkOrderReturnApproval: sinon.stub().returns(false),
            getValidatedReturnItems: sinon.stub().returns({ items: [{ itemId: 'pli-1' }], returnDetails: { 'pli-1': { quantity: 1 } } }),
            getZenkraftReturnMethods: sinon.stub().returns({ returnMethods: [] }),
            createReturnCase: sinon.stub().returns(null),
            getSyncReturnRequest: sinon.stub(),
            getReturnCase: sinon.stub().returns({ id: 'R1', returnLineItems: [], combinedLabel: 'LABEL' }),
            lockOrderReturns: sinon.stub().returns(true),
            unlockOrderReturns: sinon.stub(),
            getZKReturnDraft: sinon.stub().returns(null),
            createZKReturnCase: sinon.stub().returns(null)
        };

        zenkraftReturns = proxyquire('../../../cartridge/rest-apis/zenkraft-returns/zenkraft-returns', {
            'dw/system/Logger': { getLogger: sinon.stub().returns({ warn: sinon.stub(), error: sinon.stub(), info: sinon.stub() }) },
            'dw/order/Order': {},
            'dw/order/OrderMgr': { getOrder: function (orderNo) { return orderNo === order.orderNo ? order : null; } },
            'dw/web/Resource': { msg: function (key) { return key; } },
            'dw/system/RESTResponseMgr': {
                createSuccess: function (payload) { return { render: function () { rendered = payload; } }; },
                createError: function () { return { render: function () { rendered = { status: 500 }; } }; }
            },
            'dw/system/Site': { getCurrent: function () { return { getCustomPreferenceValue: function (id) { return prefs[id]; } }; } },
            '*/cartridge/scripts/helpers/zenkraftReturnHelper.js': helperStub
        });
    });

    afterEach(function () {
        delete global.empty;
        delete global.request;
        sinon.restore();
    });

    it('should not create a return in the instance with the zkapi handler (getShippingLabel)', function () {
        helperStub.usesZenkraftApi.returns(true);

        zenkraftReturns.getShippingLabel();

        assert.equal(rendered.error, 'Returns are handled by the Zenkraft API');
        assert.isTrue(helperStub.createReturnCase.notCalled);
    });

    it('should check and store a return in the instance while holding the order\'s lock (getShippingLabel)', function () {
        helperStub.usesZenkraftApi.returns(false);
        helperStub.createReturnCase.returns({ returnID: 'R1', returnLines: [{}] });

        zenkraftReturns.getShippingLabel();

        assert.equal(rendered.returnObject.combinedLabel, 'LABEL');
        sinon.assert.callOrder(helperStub.lockOrderReturns, helperStub.getValidatedReturnItems, helperStub.createReturnCase, helperStub.unlockOrderReturns);
        assert.isTrue(helperStub.unlockOrderReturns.calledOnceWithExactly(order));
    });

    it('should ask to try again, without checking or storing, while another return for the order is being created (getShippingLabel)', function () {
        helperStub.usesZenkraftApi.returns(false);
        helperStub.lockOrderReturns.returns(false);

        zenkraftReturns.getShippingLabel();

        assert.equal(rendered.errorMessage, 'error.msg.return.inprogress');
        assert.isTrue(helperStub.getValidatedReturnItems.notCalled);
        assert.isTrue(helperStub.createReturnCase.notCalled);
        // The lock belongs to the other request
        assert.isTrue(helperStub.unlockOrderReturns.notCalled);
    });

    it('should unlock when the items are invalid or storing the return fails (getShippingLabel)', function () {
        helperStub.usesZenkraftApi.returns(false);
        helperStub.getValidatedReturnItems.returns(null);

        zenkraftReturns.getShippingLabel();

        assert.equal(rendered.error, 'Invalid return items');
        assert.isTrue(helperStub.unlockOrderReturns.calledOnce);

        helperStub.getValidatedReturnItems.returns({ items: [{ itemId: 'pli-1' }], returnDetails: { 'pli-1': { quantity: 1 } } });
        helperStub.createReturnCase.throws(new Error('Quota exceeded'));

        zenkraftReturns.getShippingLabel();

        assert.isTrue(helperStub.unlockOrderReturns.calledTwice);
    });

    it('should not draft Zenkraft return methods with the sfcc handler (getReturnMethods)', function () {
        helperStub.usesZenkraftApi.returns(false);

        zenkraftReturns.getReturnMethods();

        assert.equal(rendered.error, 'Returns are stored in the instance');
        assert.isTrue(helperStub.getZenkraftReturnMethods.notCalled);
    });

    it('should not confirm a Zenkraft return method with the sfcc handler (getZenkraftReturnLabel)', function () {
        helperStub.usesZenkraftApi.returns(false);

        zenkraftReturns.getZenkraftReturnLabel();

        assert.equal(rendered.error, 'Returns are stored in the instance');
        assert.isTrue(helperStub.createZKReturnCase.notCalled);
    });

    it('should draft Zenkraft return methods with the zkapi handler', function () {
        helperStub.usesZenkraftApi.returns(true);

        zenkraftReturns.getReturnMethods();

        assert.isTrue(helperStub.getZenkraftReturnMethods.calledOnce);
        assert.deepEqual(rendered, { returnMethods: [] });
    });

    it('should not confirm a Zenkraft return option the order may not confirm (getZenkraftReturnLabel)', function () {
        helperStub.usesZenkraftApi.returns(true);

        zenkraftReturns.getZenkraftReturnLabel();

        assert.isTrue(helperStub.getZKReturnDraft.calledOnceWithExactly(order, 'method-1'));
        assert.isTrue(helperStub.createZKReturnCase.notCalled);
        assert.equal(rendered.errorMessage, 'error.msg.return.label');
        assert.isTrue(helperStub.unlockOrderReturns.calledOnceWithExactly(order));
    });

    it('should confirm a checked Zenkraft return option, holding the order\'s lock, and hand over its label', function () {
        helperStub.usesZenkraftApi.returns(true);
        helperStub.getZKReturnDraft.returns({ custom: { orderNumber: 'O-1' } });
        helperStub.createZKReturnCase.returns({ id: 'zk-1', shipment: { label: 'LABEL' } });

        zenkraftReturns.getZenkraftReturnLabel();

        assert.isTrue(helperStub.createZKReturnCase.calledOnceWithExactly('method-1'));
        assert.equal(rendered.labelData.shipment.label, 'LABEL');
        // Checked and confirmed while holding the lock, then unlocked
        sinon.assert.callOrder(helperStub.lockOrderReturns, helperStub.getZKReturnDraft, helperStub.createZKReturnCase, helperStub.unlockOrderReturns);
    });

    it('should answer with the return address message when Zenkraft does not confirm the option', function () {
        helperStub.usesZenkraftApi.returns(true);
        helperStub.getZKReturnDraft.returns({ custom: { orderNumber: 'O-1' } });

        zenkraftReturns.getZenkraftReturnLabel();

        assert.equal(rendered.errorMessage, 'error.msg.return.zkapi.label');
        assert.isTrue(helperStub.unlockOrderReturns.calledOnce);
    });

    it('should ask to try again, without checking or confirming, while another confirm for the order is running', function () {
        helperStub.usesZenkraftApi.returns(true);
        helperStub.lockOrderReturns.returns(false);

        zenkraftReturns.getZenkraftReturnLabel();

        assert.equal(rendered.errorMessage, 'error.msg.return.inprogress');
        assert.isTrue(helperStub.getZKReturnDraft.notCalled);
        assert.isTrue(helperStub.createZKReturnCase.notCalled);
        // The lock belongs to the other request
        assert.isTrue(helperStub.unlockOrderReturns.notCalled);
    });

    it('should still unlock when checking the option fails', function () {
        helperStub.usesZenkraftApi.returns(true);
        helperStub.getZKReturnDraft.throws(new Error('Zenkraft unreachable'));

        zenkraftReturns.getZenkraftReturnLabel();

        assert.isTrue(helperStub.unlockOrderReturns.calledOnce);
    });

    it('should refuse a request without the order or the return option', function () {
        helperStub.usesZenkraftApi.returns(true);
        delete requestBody.methodId;

        zenkraftReturns.getZenkraftReturnLabel();

        assert.equal(rendered.error, 'Missing data for getting the return label');
        assert.isTrue(helperStub.lockOrderReturns.notCalled);
    });
});
