'use strict';

(function () {
    // Remove button — enable only when at least one row is checked
    var checkboxes = document.querySelectorAll('.zk-row-check');
    var removeBtn = document.getElementById('removeBtn');
    checkboxes.forEach(function (cb) {
        cb.addEventListener('change', function () {
            var anyChecked = Array.prototype.some.call(checkboxes, function (c) { return c.checked; });
            removeBtn.disabled = !anyChecked;
        });
    });

    // Test account toggles — form POST; disabled once submitted so a second click can't create a second account
    document.querySelectorAll('.zk-test-toggle-form').forEach(function (form) {
        var toggle = form.querySelector('.zk-toggle-input');
        toggle.addEventListener('change', function () {
            toggle.disabled = true;
            form.submit();
        });
    });

    // Strip flash params so banners don't reappear on refresh
    if (window.history && window.history.replaceState) {
        var cleanUrl = new URL(window.location.href);
        cleanUrl.searchParams.delete('success');
        cleanUrl.searchParams.delete('error');
        window.history.replaceState(null, '', cleanUrl.toString());
    }
}());
