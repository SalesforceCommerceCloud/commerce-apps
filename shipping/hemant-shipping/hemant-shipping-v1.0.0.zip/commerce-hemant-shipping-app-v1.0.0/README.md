# Hemant Shipping

Shipping rate calculation and quotes for checkout and basket.

## Overview

Backend cartridge (`int_hemant_shipping`) registers the required `sfcc.app.shipping.calculate` and
`sfcc.app.shipping.quote` hooks so checkout and basket prices agree. A Storefront Next extension
renders shipping information below the shipping options.

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance
- API access to the shipping provider

## Installation

1. Install the app from the Commerce App Registry
2. Add `int_hemant_shipping` to the site cartridge path
3. Configure the service credentials

## Configuration

### Service Credentials

1. Navigate to Administration > Operations > Services
2. Find the `hemant.shipping.api` service
3. Configure the endpoint URL and credentials

## Post-Installation Checklist

- [ ] Configure service credentials
- [ ] Verify shipping rates in checkout
- [ ] Verify the shipping component on the storefront

## Testing

```bash
cd cartridges/site_cartridges/int_hemant_shipping
npm install
npm test
```

## Changelog

### v1.0.0
- Initial release
