import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import ShippingCalculatedBy from '../components/ShippingCalculatedBy';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { changeLanguage: () => Promise.resolve() },
    }),
}));

describe('ShippingCalculatedBy', () => {
    it('renders the translated attribution', () => {
        render(<ShippingCalculatedBy />);
        expect(screen.getByTestId('hemant-shipping-calculated-by')).toHaveTextContent(
            'hemantShipping.calculatedBy'
        );
    });

    it('applies custom className', () => {
        render(<ShippingCalculatedBy className="custom-class" />);
        expect(screen.getByTestId('hemant-shipping-calculated-by')).toHaveClass('custom-class');
    });
});
