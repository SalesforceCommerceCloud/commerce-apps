import { type ReactElement } from 'react';
import { useTranslation } from 'react-i18next';

export interface ShippingCalculatedByProps {
    /**
     * Optional className for styling
     */
    className?: string;
}

/**
 * Order summary note stating that shipping was calculated by Hemant Shipping
 *
 * @param props - Component props
 * @returns React element
 */
export default function ShippingCalculatedBy({ className }: ShippingCalculatedByProps): ReactElement {
    const { t } = useTranslation('extHemantShipping');

    return (
        <p className={className} data-testid="hemant-shipping-calculated-by">
            {t('hemantShipping.calculatedBy')}
        </p>
    );
}
