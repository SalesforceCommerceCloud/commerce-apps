import { type ReactElement } from 'react';
import { useTranslation } from 'react-i18next';

export interface ShippingInfoProps {
    /**
     * Optional className for styling
     */
    className?: string;
}

/**
 * ShippingInfo component for Hemant Shipping
 *
 * @param props - Component props
 * @returns React element
 */
export default function ShippingInfo({ className }: ShippingInfoProps): ReactElement {
    const { t } = useTranslation('extHemantShipping');

    return (
        <div className={className} data-testid="hemant-shipping-shipping-info">
            <h3>{t('hemantShipping.title')}</h3>
            <p>{t('hemantShipping.description')}</p>
        </div>
    );
}
