import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import ShippingInfo from '../components/ShippingInfo';

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { changeLanguage: () => Promise.resolve() },
    }),
}));

describe('ShippingInfo', () => {
    it('renders without crashing', () => {
        render(<ShippingInfo />);
        expect(screen.getByTestId('hemant-shipping-shipping-info')).toBeInTheDocument();
    });

    it('displays translated content', () => {
        render(<ShippingInfo />);
        expect(screen.getByText('hemantShipping.title')).toBeInTheDocument();
    });

    it('applies custom className', () => {
        render(<ShippingInfo className="custom-class" />);
        expect(screen.getByTestId('hemant-shipping-shipping-info')).toHaveClass('custom-class');
    });
});
