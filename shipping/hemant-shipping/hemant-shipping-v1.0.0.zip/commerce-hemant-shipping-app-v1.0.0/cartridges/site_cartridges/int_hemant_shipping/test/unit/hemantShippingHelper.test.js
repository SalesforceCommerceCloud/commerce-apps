'use strict';

jest.mock('dw/system/Logger', () => ({
    getLogger: () => ({ info: jest.fn(), error: jest.fn() })
}), { virtual: true });

const helper = require('../../cartridge/scripts/helpers/hemantShippingHelper');

describe('hemantShippingHelper', () => {
    describe('processRequest', () => {
        it('should process request successfully', () => {
            const result = helper.processRequest({});
            expect(result.success).toBe(true);
        });
    });
});
