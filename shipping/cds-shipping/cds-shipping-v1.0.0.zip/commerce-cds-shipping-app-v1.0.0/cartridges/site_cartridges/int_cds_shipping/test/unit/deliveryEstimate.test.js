'use strict';

var crypto = require('crypto');
var expect = require('chai').expect;
var proxyquire = require('proxyquire').noCallThru();

function toArray(value) {
    if (!value) {
        return [];
    }
    if (Array.isArray(value)) {
        return value;
    }
    return [];
}

function Bytes(value) {
    this.value = value;
}

function MessageDigest() {}
MessageDigest.DIGEST_SHA_256 = 'SHA-256';
MessageDigest.prototype.digestBytes = function (bytes) {
    return crypto.createHash('sha256').update(String(bytes.value), 'utf8').digest();
};

var Encoding = {
    toHex: function (bytes) {
        return Buffer.from(bytes).toString('hex');
    }
};

function hashEstimatePayload(payload) {
    return crypto.createHash('sha256').update(JSON.stringify(payload), 'utf8').digest('hex');
}

describe('CDS delivery estimate integration', function () {
    describe('config defaults', function () {
        function loadConfig(preferences, siteId) {
            return proxyquire('../../cartridge/scripts/config/cdsShippingConfig', {
                'dw/system/Site': {
                    current: {
                        getCustomPreferenceValue: function (id) {
                            return preferences[id] || '';
                        }
                    },
                    getCurrent: function () {
                        return { ID: siteId || 'RefArch' };
                    }
                }
            });
        }

        it('uses BM site preference values with app-provided token config', function () {
            var config = loadConfig({
                realmInstanceId: 'realm-from-bm',
                salesforceRegion: 'us-west-2',
                deliveryEstimationSetupName: 'setup-from-bm'
            });

            expect(config.getCommerceDeliveryConfig().realmInstanceId).to.equal('realm-from-bm');
            expect(config.getCommerceDeliveryConfig().accountManagerUrl).to.equal('https://account.demandware.com');
            expect(config.getCommerceDeliveryConfig().scope).to.equal('SALESFORCE_COMMERCE_API');
            expect(config.getCommerceDeliveryConfig().commercedeliverybindingid).to.equal('sfcc.commercedeliveryservice.shopper');
            expect(config.getCommerceDeliveryConfig().commerceinventorybindingid).to.equal('sfcc.inventory.availability');
            expect(config.getSalesforceRegion()).to.equal('us-west-2');
            expect(config.getDeliveryEstimationSetupName()).to.equal('setup-from-bm');
        });

        it('uses only safe app defaults when BM site preference values are empty', function () {
            var config = loadConfig({});

            var prefs = config.getCommerceDeliveryConfig();

            expect(prefs.realmInstanceId).to.equal('');
            expect(prefs.accountManagerUrl).to.equal('https://account.demandware.com');
            expect(config.getSalesforceRegion()).to.equal('us-east-2');
            expect(config.getDeliveryEstimationSetupName()).to.equal('RefArch');
        });
    });

    describe('request builder', function () {
        var requestBuilder = proxyquire('../../cartridge/scripts/helpers/deliveryEstimateRequestBuilder', {
            '~/cartridge/scripts/config/cdsShippingConfig': {
                getDeliveryEstimationSetupName: function () {
                    return 'RefArch';
                }
            },
            'dw/order/ShippingMgr': {
                getAllShippingMethods: function () {
                    return [
                        {
                            ID: 'GroundShipping',
                            custom: {
                                cdsShippingCarrier: 'UPSManage',
                                cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                            }
                        },
                        {
                            ID: 'TwoDayShipping',
                            custom: {
                                cdsShippingCarrier: 'UPSManage',
                                cdsMethodName: 'NON_PICKUP_DAYS_2DAY'
                            }
                        },
                        {
                            ID: 'OvernightShipping',
                            custom: {
                                cdsShippingCarrier: 'FedEx',
                                cdsMethodName: 'PRIORITY_OVERNIGHT'
                            }
                        }
                    ];
                }
            }
        });

        it('builds a CDS delivery-date request from the SCAPI skeleton', function () {
            var request = requestBuilder.buildRequest([
                {
                    productId: 'sku-1',
                    destination: { countryCode: 'US', postalCode: '10001' },
                    shippingOptions: [
                        { shippingMethodId: 'GroundShipping' },
                        { shippingMethodId: 'TwoDayShipping' }
                    ]
                }
            ]);

            expect(request).to.deep.equal({
                deliveryEstimationSetupName: 'RefArch',
                shippingCarriers: [
                    {
                        name: 'UPSManage',
                        methods: [
                            { name: 'NON_PICKUP_DAYS_UPS' },
                            { name: 'NON_PICKUP_DAYS_2DAY' }
                        ]
                    }
                ],
                products: [
                    { stockKeepingUnit: 'sku-1', quantity: 1 }
                ],
                deliveryAddress: {
                    country: 'US',
                    postalCode: '10001'
                }
            });
        });

        it('builds one CDS estimate request with multiple carriers', function () {
            var request = requestBuilder.buildRequests([
                {
                    productId: 'sku-1',
                    destination: { countryCode: 'US', postalCode: '10001' },
                    shippingOptions: [
                        { shippingMethodId: 'GroundShipping' },
                        { shippingMethodId: 'OvernightShipping' }
                    ]
                }
            ]);

            expect(request.shippingCarriers).to.deep.equal([
                {
                    name: 'UPSManage',
                    methods: [
                        { name: 'NON_PICKUP_DAYS_UPS' }
                    ]
                },
                {
                    name: 'FedEx',
                    methods: [
                        { name: 'PRIORITY_OVERNIGHT' }
                    ]
                }
            ]);
        });

        it('filters out methods without CDS custom mapping', function () {
            var fallbackBuilder = proxyquire('../../cartridge/scripts/helpers/deliveryEstimateRequestBuilder', {
                '~/cartridge/scripts/config/cdsShippingConfig': {
                    getDeliveryEstimationSetupName: function () {
                        return 'RefArch';
                    }
                },
                'dw/order/ShippingMgr': {
                    getAllShippingMethods: function () {
                        return [
                            {
                                ID: 'DefaultShipping',
                                custom: {}
                            }
                        ];
                    }
                }
            });

            var request = fallbackBuilder.buildRequest([
                {
                    productId: 'sku-2',
                    destination: { countryCode: 'US', postalCode: '94105' },
                    shippingOptions: [
                        { shippingMethodId: 'DefaultShipping' }
                    ]
                }
            ]);

            expect(request).to.equal(null);
        });

        it('keeps mapped methods and filters unmapped methods from the same skeleton', function () {
            var mixedBuilder = proxyquire('../../cartridge/scripts/helpers/deliveryEstimateRequestBuilder', {
                '~/cartridge/scripts/config/cdsShippingConfig': {
                    getDeliveryEstimationSetupName: function () {
                        return 'RefArch';
                    }
                },
                'dw/order/ShippingMgr': {
                    getAllShippingMethods: function () {
                        return [
                            {
                                ID: 'MappedShipping',
                                custom: {
                                    cdsShippingCarrier: 'UPSManage',
                                    cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                                }
                            },
                            {
                                ID: 'UnmappedShipping',
                                custom: {}
                            }
                        ];
                    }
                }
            });

            var request = mixedBuilder.buildRequest([
                {
                    productId: 'sku-3',
                    destination: { countryCode: 'US', postalCode: '30301' },
                    shippingOptions: [
                        { shippingMethodId: 'MappedShipping' },
                        { shippingMethodId: 'UnmappedShipping' }
                    ]
                }
            ]);

            expect(request.shippingCarriers).to.deep.equal([
                {
                    name: 'UPSManage',
                    methods: [
                        { name: 'NON_PICKUP_DAYS_UPS' }
                    ]
                }
            ]);
        });

        it('groups estimates by destination before service calls', function () {
            var groups = requestBuilder.groupEstimatesByDestination([
                { productId: 'sku-1', destination: { countryCode: 'US', postalCode: '10001' } },
                { productId: 'sku-2', destination: { countryCode: 'US', postalCode: '10001' } },
                { productId: 'sku-3', destination: { countryCode: 'US', postalCode: '94105' } }
            ]);

            expect(groups).to.have.length(2);
            expect(groups[0]).to.have.length(2);
            expect(groups[1]).to.have.length(1);
        });
    });

    describe('response mapper', function () {
        var responseMapper = proxyquire('../../cartridge/scripts/helpers/deliveryEstimateResponseMapper', {
            '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': {
                toArray: toArray,
                buildShippingMethodsById: function () {
                    return {
                        GroundShipping: {
                            custom: {
                                cdsShippingCarrier: 'UPS',
                                cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                            }
                        },
                        TwoDayShipping: {
                            custom: {
                                cdsShippingCarrier: 'UPS',
                                cdsMethodName: 'NON_PICKUP_DAYS_2DAY'
                            }
                        },
                        DefaultShippingMethod: {
                            custom: {
                                cdsShippingCarrier: 'UPSManage',
                                cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                            }
                        }
                    };
                },
                resolveMethod: function (option, shippingMethodsById) {
                    var method = shippingMethodsById[option.shippingMethodId];
                    if (!method || !method.custom.cdsMethodName || !method.custom.cdsShippingCarrier) {
                        return null;
                    }
                    return {
                        carrier: method.custom.cdsShippingCarrier,
                        methodName: method.custom.cdsMethodName
                    };
                }
            }
        });

        it('maps CDS estimatedDeliveryDate to SCAPI deliveryWindow', function () {
            var scapiEstimates = [
                {
                    productId: 'sku-1',
                    shippingOptions: [
                        { shippingMethodId: 'GroundShipping' },
                        { shippingMethodId: 'TwoDayShipping' }
                    ]
                }
            ];
            var cdsResponse = {
                deliveryEstimates: [
                    {
                        deliveryEstimateGroup: [
                            {
                                productDeliveryEstimations: [
                                    { stockKeepingUnit: 'sku-1', quantity: 1 }
                                ],
                                shippingMethods: [
                                    {
                                        shippingCarrier: 'UPS',
                                        shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                        orderCutoffTime: '2026-04-29T18:00:00Z',
                                        estimatedDeliveryDate: {
                                            min: '2026-04-30T14:00:00Z',
                                            max: '2026-04-30T18:00:00Z'
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };

            var populated = responseMapper.mapToResult(cdsResponse, scapiEstimates);

            expect(populated).to.equal(1);
            expect(scapiEstimates[0].shippingOptions[0].deliveryWindow).to.deep.equal({
                startAt: '2026-04-30T14:00:00Z',
                endAt: '2026-04-30T18:00:00Z'
            });
            expect(scapiEstimates[0].shippingOptions[0].carrier).to.equal('UPS');
            expect(scapiEstimates[0].shippingOptions[0].orderCutoffAt).to.equal('2026-04-29T18:00:00Z');
            expect(scapiEstimates[0].shippingOptions[1].deliveryWindow).to.equal(undefined);
        });

        it('does not fall back when product id does not match CDS response', function () {
            var scapiEstimates = [
                {
                    productId: 'storefront-product',
                    shippingOptions: [
                        { shippingMethodId: 'DefaultShippingMethod' }
                    ]
                }
            ];
            var cdsResponse = {
                estimatedDeliveryReference: '40cd7427-749a-11f1-b0c2-a7ef770cff63',
                deliveryEstimates: [
                    {
                        deliveryGroupId: 1,
                        deliveryEstimateGroup: [
                            {
                                location: 'NON_PICKUP_DAYS',
                                productDeliveryEstimations: [
                                    {
                                        stockKeepingUnit: '750518703299M',
                                        quantity: 1
                                    }
                                ],
                                shippingMethods: [
                                    {
                                        shippingCarrier: 'UPSManage',
                                        shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                        routingCalculationType: 'STANDARD',
                                        estimatedShipDate: {
                                            type: 'Default',
                                            min: '2026-06-30T19:00:00',
                                            max: '2026-06-30T19:00:00'
                                        },
                                        estimatedDeliveryDate: {
                                            type: 'Calculated',
                                            min: '2026-07-01T10:30:00',
                                            max: '2026-07-01T10:30:00'
                                        },
                                        orderCutoffTime: '2026-06-30T16:00:00'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };

            var populated = responseMapper.mapToResult(cdsResponse, scapiEstimates);

            expect(populated).to.equal(0);
            expect(scapiEstimates[0].shippingOptions[0].deliveryWindow).to.equal(undefined);
        });

        it('does not fall back to estimatedShipDate when estimatedDeliveryDate is empty', function () {
            var scapiEstimates = [
                {
                    productId: '750518703299M',
                    shippingOptions: [
                        { shippingMethodId: 'DefaultShippingMethod' }
                    ]
                }
            ];
            var cdsResponse = {
                deliveryEstimates: [
                    {
                        deliveryEstimateGroup: [
                            {
                                productDeliveryEstimations: [
                                    { stockKeepingUnit: '750518703299M', quantity: 1 }
                                ],
                                shippingMethods: [
                                    {
                                        shippingCarrier: 'UPSManage',
                                        shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                        estimatedShipDate: {
                                            type: 'Default',
                                            min: '2026-07-01T19:00:00',
                                            max: '2026-07-01T19:00:00'
                                        },
                                        estimatedDeliveryDate: {
                                            type: 'Calculated'
                                        },
                                        orderCutoffTime: '2026-07-01T16:00:00'
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };

            var populated = responseMapper.mapToResult(cdsResponse, scapiEstimates);

            expect(populated).to.equal(0);
            expect(scapiEstimates[0].shippingOptions[0].deliveryWindow).to.equal(undefined);
        });

        it('leaves options unpopulated when CDS does not return a valid window', function () {
            var scapiEstimates = [
                {
                    productId: 'sku-1',
                    shippingOptions: [{ shippingMethodId: 'GroundShipping' }]
                }
            ];

            var populated = responseMapper.mapToResult({
                deliveryEstimates: [
                    {
                        deliveryEstimateGroup: [
                            {
                                productDeliveryEstimations: [{ stockKeepingUnit: 'sku-1' }],
                                shippingMethods: [{ shippingCarrierMethod: 'GroundShipping' }]
                            }
                        ]
                    }
                ]
            }, scapiEstimates);

            expect(populated).to.equal(0);
            expect(scapiEstimates[0].shippingOptions[0].deliveryWindow).to.equal(undefined);
        });
    });

    describe('shipment delivery estimate helper', function () {
        var shipmentHelper = proxyquire('../../cartridge/scripts/helpers/shipmentDeliveryEstimateHelper', {
            '~/cartridge/scripts/config/cdsShippingConfig': {
                getDeliveryEstimationSetupName: function () {
                    return 'RefArch';
                }
            },
            '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': {
                toArray: toArray
            },
            'dw/util/Bytes': Bytes,
            'dw/crypto/Encoding': Encoding,
            'dw/crypto/MessageDigest': MessageDigest
        });

        function responseWithMethod(method) {
            return {
                deliveryEstimates: [
                    {
                        deliveryEstimateGroup: [
                            {
                                productDeliveryEstimations: [{ stockKeepingUnit: 'sku-1', quantity: 1 }],
                                shippingMethods: [method]
                            }
                        ]
                    }
                ]
            };
        }

        it('builds a window from estimatedDeliveryDate', function () {
            var window = shipmentHelper.getWindowForMethod(responseWithMethod({
                shippingCarrier: 'UPSManage',
                shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                estimatedDeliveryDate: {
                    type: 'Calculated',
                    min: '2026-07-02T10:30:00',
                    max: '2026-07-02T10:30:00'
                },
                orderCutoffTime: '2026-07-01T16:00:00'
            }), 'NON_PICKUP_DAYS_UPS');

            expect(window).to.not.equal(null);
            expect(window.startAt.toISOString()).to.equal(new Date('2026-07-02T10:30:00').toISOString());
            expect(window.endAt.toISOString()).to.equal(new Date('2026-07-02T10:30:00').toISOString());
        });

        it('does not fall back to estimatedShipDate when estimatedDeliveryDate is empty', function () {
            var window = shipmentHelper.getWindowForMethod(responseWithMethod({
                shippingCarrier: 'UPSManage',
                shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                estimatedShipDate: {
                    type: 'Default',
                    min: '2026-07-01T19:00:00',
                    max: '2026-07-01T19:00:00'
                },
                estimatedDeliveryDate: {
                    type: 'Calculated'
                },
                orderCutoffTime: '2026-07-01T16:00:00'
            }), 'NON_PICKUP_DAYS_UPS');

            expect(window).to.equal(null);
        });
    });

    describe('PDP estimate cache', function () {
        it('builds cache key from site, destination, and product ids', function () {
            var cache = proxyquire('../../cartridge/scripts/helpers/pdpEstimateCache', {
                'dw/system/CacheMgr': {
                    getCache: function () {
                        return {};
                    }
                },
                'dw/system/Logger': { getLogger: function () { return { debug: function () {}, warn: function () {} }; } },
                'dw/system/Site': {
                    getCurrent: function () {
                        return { ID: 'RefArch' };
                    }
                },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': {
                    toArray: toArray
                }
            });

            expect(cache.buildKey([
                {
                    productId: 'sku-2',
                    destination: { countryCode: 'US', postalCode: '10001' }
                },
                {
                    productId: 'sku-1',
                    destination: { countryCode: 'US', postalCode: '10001' }
                }
            ])).to.equal('RefArch|US|10001|sku-1%2Csku-2');
        });
    });

    describe('estimate hook', function () {
        function Status(status, code, message) {
            this.status = status;
            this.code = code;
            this.message = message;
        }
        Status.OK = 'OK';
        Status.ERROR = 'ERROR';

        function logger() {
            return {
                debug: function () {},
                isDebugEnabled: function () { return true; },
                warn: function () {},
                info: function () {},
                error: function () {}
            };
        }

        it('returns ERROR when CDS service fails or returns an invalid response', function () {
            var option = { shippingMethodId: 'GroundShipping' };
            var serviceResult = { ok: false };
            var hook = proxyquire('../../cartridge/scripts/hooks/estimate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': {
                    groupEstimatesByDestination: function (estimates) {
                        return [estimates];
                    },
                    buildRequest: function () {
                        return { products: [{ stockKeepingUnit: 'sku-1', quantity: 1 }] };
                    }
                },
                '~/cartridge/scripts/helpers/pdpEstimateCache': {
                    buildKey: function () {
                        return 'cache-key';
                    },
                    get: function () {
                        return null;
                    },
                    put: function () {}
                },
                '~/cartridge/scripts/helpers/deliveryEstimateResponseMapper': {
                    mapToResult: function () {
                        throw new Error('mapper should not run');
                    }
                },
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        return serviceResult;
                    }
                }
            });

            var status = hook.estimate({
                productDeliveryEstimates: [
                    {
                        productId: 'sku-1',
                        destination: { countryCode: 'US', postalCode: '10001' },
                        shippingOptions: [option]
                    }
                ]
            });

            expect(status.status).to.equal(Status.ERROR);
            expect(status.code).to.equal('CDS_ESTIMATE_UNAVAILABLE');
            expect(option.deliveryWindow).to.equal(undefined);
            expect(option.price).to.equal(undefined);

            serviceResult = { ok: true, object: {} };
            status = hook.estimate({
                productDeliveryEstimates: [
                    {
                        productId: 'sku-1',
                        destination: { countryCode: 'US', postalCode: '10001' },
                        shippingOptions: [option]
                    }
                ]
            });

            expect(status.status).to.equal(Status.ERROR);
            expect(status.code).to.equal('CDS_ESTIMATE_UNAVAILABLE');
        });

        it('accepts and caches a valid empty CDS response', function () {
            var response = { deliveryEstimates: [] };
            var cachedResponse;
            var mapperCalls = 0;
            var hook = proxyquire('../../cartridge/scripts/hooks/estimate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': {
                    groupEstimatesByDestination: function (estimates) {
                        return [estimates];
                    },
                    buildRequest: function () {
                        return { products: [{ stockKeepingUnit: 'sku-1', quantity: 1 }] };
                    }
                },
                '~/cartridge/scripts/helpers/pdpEstimateCache': {
                    buildKey: function () {
                        return 'cache-key';
                    },
                    get: function () {
                        return null;
                    },
                    put: function (key, value) {
                        cachedResponse = value;
                    }
                },
                '~/cartridge/scripts/helpers/deliveryEstimateResponseMapper': {
                    mapToResult: function (value) {
                        expect(value).to.equal(response);
                        mapperCalls++;
                        return 0;
                    }
                },
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        return { ok: true, object: response };
                    }
                }
            });

            var status = hook.estimate({
                productDeliveryEstimates: [
                    {
                        productId: 'sku-1',
                        destination: { countryCode: 'US', postalCode: '10001' },
                        shippingOptions: [{ shippingMethodId: 'GroundShipping' }]
                    }
                ]
            });

            expect(status.status).to.equal(Status.OK);
            expect(cachedResponse).to.equal(response);
            expect(mapperCalls).to.equal(1);
        });

        it('uses cached PDP estimate response before calling CDS', function () {
            var option = { shippingMethodId: 'GroundShipping' };
            var serviceCalls = 0;
            var hook = proxyquire('../../cartridge/scripts/hooks/estimate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': {
                    groupEstimatesByDestination: function (estimates) {
                        return [estimates];
                    },
                    buildRequest: function () {
                        return { products: [{ stockKeepingUnit: 'sku-1', quantity: 1 }] };
                    }
                },
                '~/cartridge/scripts/helpers/pdpEstimateCache': {
                    buildKey: function () {
                        return 'cache-key';
                    },
                    get: function () {
                        return { deliveryEstimates: [] };
                    },
                    put: function () {
                        throw new Error('should not update cache on hit');
                    }
                },
                '~/cartridge/scripts/helpers/deliveryEstimateResponseMapper': {
                    mapToResult: function (response, estimates) {
                        estimates[0].shippingOptions[0].deliveryWindow = {
                            startAt: 'cached',
                            endAt: 'cached'
                        };
                        return 1;
                    }
                },
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        serviceCalls++;
                        return { ok: false };
                    }
                }
            });

            var status = hook.estimate({
                productDeliveryEstimates: [
                    {
                        productId: 'sku-1',
                        destination: { countryCode: 'US', postalCode: '10001' },
                        shippingOptions: [option]
                    }
                ]
            });

            expect(status.status).to.equal(Status.OK);
            expect(serviceCalls).to.equal(0);
            expect(option.deliveryWindow).to.deep.equal({
                startAt: 'cached',
                endAt: 'cached'
            });
        });
    });

    describe('quote hook', function () {
        function Status(status, code, message) {
            this.status = status;
            this.code = code;
            this.message = message;
        }
        Status.OK = 'OK';
        Status.ERROR = 'ERROR';

        function logger() {
            return {
                debug: function () {},
                isDebugEnabled: function () { return true; },
                warn: function () {},
                info: function () {},
                error: function () {}
            };
        }

        function loadQuoteHook(serviceResult, onServiceCall) {
            var requestBuilderMock = {
                toArray: function (value) {
                    if (!value) return [];
                    return Array.isArray(value) ? value : value.toArray();
                },
                buildShippingMethodsById: function () {
                    return {
                        MappedShipping: {
                            custom: {
                                cdsShippingCarrier: 'UPSManage',
                                cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                            }
                        },
                        UnmappedShipping: {
                            custom: {}
                        }
                    };
                },
                resolveMethod: function (option, shippingMethodsById) {
                    var method = shippingMethodsById[option.shippingMethodId];
                    if (!method || !method.custom.cdsShippingCarrier || !method.custom.cdsMethodName) {
                        return null;
                    }
                    return {
                        carrier: method.custom.cdsShippingCarrier,
                        methodName: method.custom.cdsMethodName
                    };
                }
            };
            var shipmentHelper = proxyquire('../../cartridge/scripts/helpers/shipmentDeliveryEstimateHelper', {
                '~/cartridge/scripts/config/cdsShippingConfig': {
                    getDeliveryEstimationSetupName: function () {
                        return 'RefArch';
                    }
                },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                'dw/util/Bytes': Bytes,
                'dw/crypto/Encoding': Encoding,
                'dw/crypto/MessageDigest': MessageDigest
            });

            return proxyquire('../../cartridge/scripts/hooks/quote', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                '~/cartridge/scripts/helpers/shipmentDeliveryEstimateHelper': shipmentHelper,
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        if (onServiceCall) {
                            onServiceCall();
                        }
                        return serviceResult;
                    }
                }
            });
        }

        function shipment() {
            return {
                getShipmentNo: function () {
                    return 'shipment-1';
                },
                getShippingAddress: function () {
                    return {
                        countryCode: {
                            getValue: function () {
                                return 'US';
                            }
                        },
                        postalCode: '10001',
                        stateCode: 'NY',
                        city: 'New York'
                    };
                },
                productLineItems: [
                    {
                        productID: 'sku-1',
                        quantityValue: 2
                    }
                ]
            };
        }

        it('batches CDS-mapped methods into one request and skips unmapped methods', function () {
            var calls = 0;
            var lastRequest = null;
            var hook = loadQuoteHook({ ok: false }, function (requestBody) {
                calls++;
                lastRequest = requestBody;
            });
            var request = hook._private.buildSnapshotRequest(shipment(), {
                MappedShipping: {
                    custom: {
                        cdsShippingCarrier: 'UPSManage',
                        cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                    }
                },
                UnmappedShipping: {
                    custom: {}
                }
            });

            expect(request.requestBody).to.deep.equal({
                deliveryEstimationSetupName: 'RefArch',
                shippingCarriers: [
                    {
                        name: 'UPSManage',
                        methods: [
                            { name: 'NON_PICKUP_DAYS_UPS' }
                        ]
                    }
                ],
                products: [
                    { stockKeepingUnit: 'sku-1', quantity: 2 }
                ],
                deliveryAddress: {
                    country: 'US',
                    postalCode: '10001',
                    state: 'NY',
                    city: 'New York'
                }
            });
            expect(request.methodIdByCdsName).to.deep.equal({ NON_PICKUP_DAYS_UPS: 'MappedShipping' });
            expect(calls).to.equal(0);
            expect(lastRequest).to.equal(null);
        });

        it('maps CDS quote response to applicable shipping method delivery fields', function () {
            var mapped = { id: 'MappedShipping' };
            var unmapped = { id: 'UnmappedShipping' };
            var calls = 0;
            var hook = loadQuoteHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    shippingMethods: [
                                        {
                                            shippingCarrier: 'UPSManage',
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-01T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            }, function () {
                calls++;
            });

            var status = hook.quote(shipment(), {
                applicableShippingMethods: [mapped, unmapped]
            });

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(1);
            expect(mapped.deliveryWindow.startAt).to.be.an.instanceof(Date);
            expect(mapped.deliveryWindow.endAt).to.be.an.instanceof(Date);
            expect(mapped.deliveryWindow.startAt.getTime()).to.equal(new Date('2026-07-01T10:30:00').getTime());
            expect(mapped.deliveryWindow.endAt.getTime()).to.equal(new Date('2026-07-01T10:30:00').getTime());
            expect(mapped.orderCutoffAt).to.be.an.instanceof(Date);
            expect(mapped.orderCutoffAt.getTime()).to.equal(new Date('2099-06-30T16:00:00').getTime());
            expect(unmapped.deliveryWindow).to.equal(undefined);
        });

        it('reuses a fresh snapshot without calling CDS', function () {
            var mapped = { id: 'MappedShipping' };
            var calls = 0;
            var hook = loadQuoteHook({ ok: false }, function () {
                calls++;
            });
            var shp = shipment();
            shp.custom = {};
            var estimateKey = hook._private.buildEstimateKey(shp);
            shp.custom.deliveryEstimateKey = estimateKey;
            shp.custom.deliveryEstimateSnapshot = JSON.stringify({
                methods: {
                    MappedShipping: {
                        startAt: '2026-07-01T10:30:00.000Z',
                        endAt: '2026-07-02T10:30:00.000Z',
                        orderCutoffAt: '2099-06-30T16:00:00.000Z'
                    }
                }
            });

            var status = hook.quote(shp, { applicableShippingMethods: [mapped] });

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(0);
            expect(mapped.deliveryWindow.startAt.getTime()).to.equal(new Date('2026-07-01T10:30:00.000Z').getTime());
            expect(mapped.deliveryWindow.endAt.getTime()).to.equal(new Date('2026-07-02T10:30:00.000Z').getTime());
        });

        it('keeps the earliest-delivering plan when the same method spans divergent plans', function () {
            var mapped = { id: 'MappedShipping' };
            var hook = loadQuoteHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryGroupId: 1,
                            deliveryEstimateGroup: [
                                {
                                    location: 'FAR_WAREHOUSE',
                                    productDeliveryEstimations: [{ stockKeepingUnit: 'sku-1', quantity: 2 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-18T10:30:00', max: '2026-07-20T10:30:00' }, orderCutoffTime: '2099-07-15T16:00:00' }
                                    ]
                                }
                            ]
                        },
                        {
                            deliveryGroupId: 2,
                            deliveryEstimateGroup: [
                                {
                                    location: 'NEAR_WAREHOUSE',
                                    productDeliveryEstimations: [{ stockKeepingUnit: 'sku-1', quantity: 2 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-14T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });

            var status = hook.quote(shipment(), { applicableShippingMethods: [mapped] });

            expect(status.status).to.equal(Status.OK);
            // Best alternative: nearer warehouse's earlier window, not a widened span across plans.
            expect(mapped.deliveryWindow.startAt.getTime()).to.equal(new Date('2026-07-13T10:30:00').getTime());
            expect(mapped.deliveryWindow.endAt.getTime()).to.equal(new Date('2026-07-14T10:30:00').getTime());
        });

    });

    describe('calculate hook', function () {
        function Status(status, code, message) {
            this.status = status;
            this.code = code;
            this.message = message;
        }
        Status.OK = 'OK';
        Status.ERROR = 'ERROR';

        function logger() {
            return {
                debug: function () {},
                isDebugEnabled: function () { return true; },
                warn: function () {},
                info: function () {},
                error: function () {}
            };
        }

        function loadCalculateHook(serviceResult, onServiceCall) {
            var requestBuilderMock = {
                toArray: function (value) {
                    if (!value) return [];
                    return Array.isArray(value) ? value : value.toArray();
                },
                buildShippingMethodsById: function () {
                    return {
                        MappedShipping: {
                            custom: {
                                cdsShippingCarrier: 'UPSManage',
                                cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                            }
                        }
                    };
                },
                resolveMethod: function (option, shippingMethodsById) {
                    var method = shippingMethodsById[option.shippingMethodId];
                    if (!method) return null;
                    return {
                        carrier: method.custom.cdsShippingCarrier,
                        methodName: method.custom.cdsMethodName
                    };
                }
            };
            var shipmentHelper = proxyquire('../../cartridge/scripts/helpers/shipmentDeliveryEstimateHelper', {
                '~/cartridge/scripts/config/cdsShippingConfig': {
                    getDeliveryEstimationSetupName: function () {
                        return 'RefArch';
                    }
                },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                'dw/util/Bytes': Bytes,
                'dw/crypto/Encoding': Encoding,
                'dw/crypto/MessageDigest': MessageDigest
            });

            return proxyquire('../../cartridge/scripts/hooks/calculate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                'dw/order/ShippingMgr': {
                    applyShippingCost: function () {}
                },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                '~/cartridge/scripts/helpers/shipmentDeliveryEstimateHelper': shipmentHelper,
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        if (onServiceCall) {
                            onServiceCall();
                        }
                        return serviceResult;
                    }
                }
            });
        }

        function calculateShipment() {
            return {
                custom: {},
                getShippingMethod: function () {
                    return { ID: 'MappedShipping' };
                },
                getShippingAddress: function () {
                    return {
                        countryCode: {
                            getValue: function () {
                                return 'US';
                            }
                        },
                        postalCode: '10001',
                        stateCode: 'NY',
                        city: 'New York'
                    };
                },
                productLineItems: [
                    {
                        productID: 'sku-1',
                        quantityValue: 2
                    }
                ]
            };
        }

        function loadMultiCarrierHook(serviceResult, onServiceCall) {
            var requestBuilderMock = {
                toArray: function (value) {
                    if (!value) return [];
                    return Array.isArray(value) ? value : value.toArray();
                },
                buildShippingMethodsById: function () {
                    return {
                        MappedShipping: {
                            custom: {
                                cdsShippingCarrier: 'UPSManage',
                                cdsMethodName: 'NON_PICKUP_DAYS_UPS'
                            }
                        },
                        OvernightShipping: {
                            custom: {
                                cdsShippingCarrier: 'FedEx',
                                cdsMethodName: 'PRIORITY_OVERNIGHT'
                            }
                        }
                    };
                },
                resolveMethod: function (option, shippingMethodsById) {
                    var method = shippingMethodsById[option.shippingMethodId];
                    if (!method || !method.custom.cdsShippingCarrier || !method.custom.cdsMethodName) {
                        return null;
                    }
                    return {
                        carrier: method.custom.cdsShippingCarrier,
                        methodName: method.custom.cdsMethodName
                    };
                }
            };
            var shipmentHelper = proxyquire('../../cartridge/scripts/helpers/shipmentDeliveryEstimateHelper', {
                '~/cartridge/scripts/config/cdsShippingConfig': {
                    getDeliveryEstimationSetupName: function () {
                        return 'RefArch';
                    }
                },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                'dw/util/Bytes': Bytes,
                'dw/crypto/Encoding': Encoding,
                'dw/crypto/MessageDigest': MessageDigest
            });

            return proxyquire('../../cartridge/scripts/hooks/calculate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                'dw/order/ShippingMgr': {
                    applyShippingCost: function () {}
                },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                '~/cartridge/scripts/helpers/shipmentDeliveryEstimateHelper': shipmentHelper,
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function (requestBody) {
                        if (onServiceCall) {
                            onServiceCall(requestBody);
                        }
                        return serviceResult;
                    }
                }
            });
        }

        it('batches multiple carriers into a single CDS request on refresh', function () {
            var shipment = calculateShipment();
            var calls = 0;
            var lastRequest = null;
            var hook = loadMultiCarrierHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-02T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        },
                                        {
                                            shippingCarrierMethod: 'PRIORITY_OVERNIGHT',
                                            estimatedDeliveryDate: {
                                                min: '2026-06-30T10:30:00',
                                                max: '2026-06-30T18:00:00'
                                            },
                                            orderCutoffTime: '2099-06-29T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            }, function (requestBody) {
                calls++;
                lastRequest = requestBody;
            });

            global.request = {
                httpMethod: 'PATCH',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(1);
            expect(lastRequest.shippingCarriers).to.deep.equal([
                {
                    name: 'UPSManage',
                    methods: [{ name: 'NON_PICKUP_DAYS_UPS' }]
                },
                {
                    name: 'FedEx',
                    methods: [{ name: 'PRIORITY_OVERNIGHT' }]
                }
            ]);

            var snapshotMethods = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods;
            expect(snapshotMethods.MappedShipping).to.exist;
            expect(snapshotMethods.OvernightShipping).to.exist;
        });

        it('keeps every carrier when the response splits across fulfillment groups', function () {
            var shipment = calculateShipment();
            var hook = loadMultiCarrierHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    locationId: 'east',
                                    productDeliveryEstimations: [{ stockKeepingUnit: 'sku-1', quantity: 1 }],
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: { min: '2026-07-01T10:30:00', max: '2026-07-02T10:30:00' },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        },
                                        {
                                            shippingCarrierMethod: 'PRIORITY_OVERNIGHT',
                                            estimatedDeliveryDate: { min: '2026-06-30T10:30:00', max: '2026-06-30T18:00:00' },
                                            orderCutoffTime: '2099-06-29T16:00:00'
                                        }
                                    ]
                                },
                                {
                                    locationId: 'west',
                                    productDeliveryEstimations: [{ stockKeepingUnit: 'sku-2', quantity: 1 }],
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: { min: '2026-07-03T10:30:00', max: '2026-07-05T10:30:00' },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        },
                                        {
                                            shippingCarrierMethod: 'PRIORITY_OVERNIGHT',
                                            estimatedDeliveryDate: { min: '2026-07-02T10:30:00', max: '2026-07-02T18:00:00' },
                                            orderCutoffTime: '2099-06-29T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });

            global.request = {
                httpMethod: 'PATCH',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var methods = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods;
            expect(status.status).to.equal(Status.OK);
            // Both carriers serve both split groups → both kept with conservative (widest) windows.
            expect(methods.MappedShipping.startAt).to.equal(new Date('2026-07-01T10:30:00').toISOString());
            expect(methods.MappedShipping.endAt).to.equal(new Date('2026-07-05T10:30:00').toISOString());
            expect(methods.OvernightShipping.startAt).to.equal(new Date('2026-06-30T10:30:00').toISOString());
            expect(methods.OvernightShipping.endAt).to.equal(new Date('2026-07-02T18:00:00').toISOString());
        });

        it('handles real CDS payload: per-carrier deliveryEstimates entries with split groups', function () {
            var requestBuilderMock = {
                toArray: function (value) {
                    if (!value) return [];
                    return Array.isArray(value) ? value : value.toArray();
                },
                buildShippingMethodsById: function () {
                    return {
                        UpsGround: { custom: { cdsShippingCarrier: 'UPSManage', cdsMethodName: 'NON_PICKUP_DAYS_UPS' } },
                        UpsNextDay: { custom: { cdsShippingCarrier: 'UPSManage', cdsMethodName: 'NON_PICKUP_DAYS_UPS_NEXT_DAY_AIR' } },
                        FedexGround: { custom: { cdsShippingCarrier: 'FEDEX_DEMO', cdsMethodName: 'FEDEX_GROUND_ECONOMY' } }
                    };
                },
                resolveMethod: function (option, byId) {
                    var m = byId[option.shippingMethodId];
                    if (!m || !m.custom.cdsShippingCarrier || !m.custom.cdsMethodName) return null;
                    return { carrier: m.custom.cdsShippingCarrier, methodName: m.custom.cdsMethodName };
                }
            };
            var shipmentHelper = proxyquire('../../cartridge/scripts/helpers/shipmentDeliveryEstimateHelper', {
                '~/cartridge/scripts/config/cdsShippingConfig': { getDeliveryEstimationSetupName: function () { return 'NON_PICKUP_DAYS_DEMO'; } },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                'dw/util/Bytes': Bytes,
                'dw/crypto/Encoding': Encoding,
                'dw/crypto/MessageDigest': MessageDigest
            });
            var upsGroup = function () {
                return {
                    location: 'NON_PICKUP_DAYS',
                    productDeliveryEstimations: [{ stockKeepingUnit: '682875090845M', quantity: 1 }],
                    shippingMethods: [
                        { shippingCarrier: 'UPSManage', shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-13T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' },
                        { shippingCarrier: 'UPSManage', shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS_NEXT_DAY_AIR', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-13T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                    ]
                };
            };
            var fedexGroup = function () {
                return {
                    location: 'NON_PICKUP_DAYS',
                    productDeliveryEstimations: [{ stockKeepingUnit: '682875090845M', quantity: 1 }],
                    shippingMethods: [
                        { shippingCarrier: 'FEDEX_DEMO', shippingCarrierMethod: 'FEDEX_GROUND_ECONOMY', estimatedDeliveryDate: { min: '2026-07-15T22:00:00', max: '2026-07-17T22:00:00' }, orderCutoffTime: '2099-07-10T19:00:00' }
                    ]
                };
            };
            var hook = proxyquire('../../cartridge/scripts/hooks/calculate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                'dw/order/ShippingMgr': { applyShippingCost: function () {} },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                '~/cartridge/scripts/helpers/shipmentDeliveryEstimateHelper': shipmentHelper,
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        return {
                            ok: true,
                            object: {
                                deliveryEstimates: [
                                    { deliveryGroupId: 1, deliveryEstimateGroup: [upsGroup(), upsGroup()] },
                                    { deliveryGroupId: 2, deliveryEstimateGroup: [fedexGroup(), fedexGroup()] }
                                ]
                            }
                        };
                    }
                }
            });
            var shipment = calculateShipment();
            shipment.getShippingMethod = function () { return { ID: 'UpsGround' }; };

            global.request = { httpMethod: 'PATCH', httpPath: '/s/-/dw/shop/v23_2/baskets/b1' };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var methods = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods;
            expect(status.status).to.equal(Status.OK);
            expect(methods.UpsGround, 'UPS ground should be stored').to.exist;
            expect(methods.UpsNextDay, 'UPS next day should be stored').to.exist;
            expect(methods.FedexGround, 'FedEx ground should be stored').to.exist;
            // FedEx window comes from its own plan, not conflated with UPS dates.
            expect(methods.FedexGround.startAt).to.equal(new Date('2026-07-15T22:00:00').toISOString());
            expect(methods.FedexGround.endAt).to.equal(new Date('2026-07-17T22:00:00').toISOString());
            // Selected method (UpsGround) window is applied to the shipment.
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-13T10:30:00').getTime());
            expect(shipment.custom.deliveryWindowEndAt.getTime()).to.equal(new Date('2026-07-13T10:30:00').getTime());
        });

        it('handles single-product multi-carrier: one unsplit group per carrier plan', function () {
            var requestBuilderMock = {
                toArray: function (value) {
                    if (!value) return [];
                    return Array.isArray(value) ? value : value.toArray();
                },
                buildShippingMethodsById: function () {
                    return {
                        UpsGround: { custom: { cdsShippingCarrier: 'UPSManage', cdsMethodName: 'NON_PICKUP_DAYS_UPS' } },
                        FedexGround: { custom: { cdsShippingCarrier: 'FEDEX_DEMO', cdsMethodName: 'FEDEX_GROUND_ECONOMY' } }
                    };
                },
                resolveMethod: function (option, byId) {
                    var m = byId[option.shippingMethodId];
                    if (!m || !m.custom.cdsShippingCarrier || !m.custom.cdsMethodName) return null;
                    return { carrier: m.custom.cdsShippingCarrier, methodName: m.custom.cdsMethodName };
                }
            };
            var shipmentHelper = proxyquire('../../cartridge/scripts/helpers/shipmentDeliveryEstimateHelper', {
                '~/cartridge/scripts/config/cdsShippingConfig': { getDeliveryEstimationSetupName: function () { return 'NON_PICKUP_DAYS_DEMO'; } },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                'dw/util/Bytes': Bytes,
                'dw/crypto/Encoding': Encoding,
                'dw/crypto/MessageDigest': MessageDigest
            });
            var hook = proxyquire('../../cartridge/scripts/hooks/calculate', {
                'dw/system/Logger': { getLogger: logger },
                'dw/system/Status': Status,
                'dw/order/ShippingMgr': { applyShippingCost: function () {} },
                '~/cartridge/scripts/helpers/deliveryEstimateRequestBuilder': requestBuilderMock,
                '~/cartridge/scripts/helpers/shipmentDeliveryEstimateHelper': shipmentHelper,
                '~/cartridge/scripts/services/cdsShippingService': {
                    callDeliveryEstimation: function () {
                        return {
                            ok: true,
                            object: {
                                deliveryEstimates: [
                                    {
                                        deliveryGroupId: 1,
                                        deliveryEstimateGroup: [
                                            {
                                                location: 'NON_PICKUP_DAYS',
                                                productDeliveryEstimations: [{ stockKeepingUnit: '682875090845M', quantity: 1 }],
                                                shippingMethods: [
                                                    { shippingCarrier: 'UPSManage', shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-13T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        deliveryGroupId: 2,
                                        deliveryEstimateGroup: [
                                            {
                                                location: 'NON_PICKUP_DAYS',
                                                productDeliveryEstimations: [{ stockKeepingUnit: '682875090845M', quantity: 1 }],
                                                shippingMethods: [
                                                    { shippingCarrier: 'FEDEX_DEMO', shippingCarrierMethod: 'FEDEX_GROUND_ECONOMY', estimatedDeliveryDate: { min: '2026-07-15T22:00:00', max: '2026-07-17T22:00:00' }, orderCutoffTime: '2099-07-10T19:00:00' }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        };
                    }
                }
            });
            var shipment = calculateShipment();
            shipment.getShippingMethod = function () { return { ID: 'FedexGround' }; };

            global.request = { httpMethod: 'PATCH', httpPath: '/s/-/dw/shop/v23_2/baskets/b1' };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var methods = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods;
            expect(status.status).to.equal(Status.OK);
            expect(methods.UpsGround).to.exist;
            expect(methods.UpsGround.startAt).to.equal(new Date('2026-07-13T10:30:00').toISOString());
            expect(methods.UpsGround.endAt).to.equal(new Date('2026-07-13T10:30:00').toISOString());
            expect(methods.UpsGround.orderCutoffAt).to.equal(new Date('2099-07-10T16:00:00').toISOString());
            expect(methods.FedexGround).to.exist;
            expect(methods.FedexGround.startAt).to.equal(new Date('2026-07-15T22:00:00').toISOString());
            expect(methods.FedexGround.endAt).to.equal(new Date('2026-07-17T22:00:00').toISOString());
            // Single unsplit group per plan → no per-group breakdown stored.
            expect(methods.UpsGround.groups).to.equal(undefined);
            expect(methods.FedexGround.groups).to.equal(undefined);
            // Selected method (FedEx) window applied to shipment.
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-15T22:00:00').getTime());
            expect(shipment.custom.deliveryWindowEndAt.getTime()).to.equal(new Date('2026-07-17T22:00:00').getTime());
        });

        it('handles same method across two identical-date deliveryGroupId plans', function () {
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryGroupId: 1,
                            deliveryEstimateGroup: [
                                {
                                    location: 'NON_PICKUP_DAYS_2',
                                    productDeliveryEstimations: [{ stockKeepingUnit: '750518703299M', quantity: 1 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-13T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                                    ]
                                }
                            ]
                        },
                        {
                            deliveryGroupId: 2,
                            deliveryEstimateGroup: [
                                {
                                    location: 'NON_PICKUP_DAYS',
                                    productDeliveryEstimations: [{ stockKeepingUnit: '750518703299M', quantity: 1 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-13T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });
            var shipment = calculateShipment();

            global.request = { httpMethod: 'PATCH', httpPath: '/s/-/dw/shop/v23_2/baskets/b1' };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var stored = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping;
            expect(status.status).to.equal(Status.OK);
            expect(stored).to.exist;
            expect(stored.startAt).to.equal(new Date('2026-07-13T10:30:00').toISOString());
            expect(stored.endAt).to.equal(new Date('2026-07-13T10:30:00').toISOString());
            expect(stored.orderCutoffAt).to.equal(new Date('2099-07-10T16:00:00').toISOString());
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-13T10:30:00').getTime());
            expect(stored.groups).to.equal(undefined);
        });

        it('picks the earliest-delivering plan when the same method spans divergent plans', function () {
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryGroupId: 1,
                            deliveryEstimateGroup: [
                                {
                                    location: 'FAR_WAREHOUSE',
                                    productDeliveryEstimations: [{ stockKeepingUnit: '750518703299M', quantity: 1 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-18T10:30:00', max: '2026-07-20T10:30:00' }, orderCutoffTime: '2099-07-15T16:00:00' }
                                    ]
                                }
                            ]
                        },
                        {
                            deliveryGroupId: 2,
                            deliveryEstimateGroup: [
                                {
                                    location: 'NEAR_WAREHOUSE',
                                    productDeliveryEstimations: [{ stockKeepingUnit: '750518703299M', quantity: 1 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-14T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });
            var shipment = calculateShipment();

            global.request = { httpMethod: 'PATCH', httpPath: '/s/-/dw/shop/v23_2/baskets/b1' };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var stored = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping;
            expect(status.status).to.equal(Status.OK);
            // Best alternative wins: the nearer warehouse's earlier window, NOT a widened 07-13 -> 07-20 span.
            expect(stored.startAt).to.equal(new Date('2026-07-13T10:30:00').toISOString());
            expect(stored.endAt).to.equal(new Date('2026-07-14T10:30:00').toISOString());
            expect(stored.orderCutoffAt).to.equal(new Date('2099-07-10T16:00:00').toISOString());
            expect(shipment.custom.deliveryWindowEndAt.getTime()).to.equal(new Date('2026-07-14T10:30:00').getTime());
        });

        it('picks the earliest-delivering plan regardless of plan ordering in the response', function () {
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryGroupId: 1,
                            deliveryEstimateGroup: [
                                {
                                    location: 'NEAR_WAREHOUSE',
                                    productDeliveryEstimations: [{ stockKeepingUnit: '750518703299M', quantity: 1 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-13T10:30:00', max: '2026-07-14T10:30:00' }, orderCutoffTime: '2099-07-10T16:00:00' }
                                    ]
                                }
                            ]
                        },
                        {
                            deliveryGroupId: 2,
                            deliveryEstimateGroup: [
                                {
                                    location: 'FAR_WAREHOUSE',
                                    productDeliveryEstimations: [{ stockKeepingUnit: '750518703299M', quantity: 1 }],
                                    shippingMethods: [
                                        { shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS', estimatedDeliveryDate: { min: '2026-07-18T10:30:00', max: '2026-07-20T10:30:00' }, orderCutoffTime: '2099-07-15T16:00:00' }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });
            var shipment = calculateShipment();

            global.request = { httpMethod: 'PATCH', httpPath: '/s/-/dw/shop/v23_2/baskets/b1' };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var stored = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping;
            expect(status.status).to.equal(Status.OK);
            // Earlier plan is first here; must keep it and not let the later far-warehouse plan overwrite.
            expect(stored.startAt).to.equal(new Date('2026-07-13T10:30:00').toISOString());
            expect(stored.endAt).to.equal(new Date('2026-07-14T10:30:00').toISOString());
        });

        it('builds calculate request for selected CDS-mapped shipping method', function () {
            var hook = loadCalculateHook({ ok: false });
            var request = hook._private.buildCalculateRequest(calculateShipment());

            expect(request.resolvedMethodName).to.equal('NON_PICKUP_DAYS_UPS');
            expect(request.requestBody).to.deep.equal({
                deliveryEstimationSetupName: 'RefArch',
                shippingCarriers: [
                    {
                        name: 'UPSManage',
                        methods: [
                            { name: 'NON_PICKUP_DAYS_UPS' }
                        ]
                    }
                ],
                products: [
                    { stockKeepingUnit: 'sku-1', quantity: 2 }
                ],
                deliveryAddress: {
                    country: 'US',
                    postalCode: '10001',
                    state: 'NY',
                    city: 'New York'
                }
            });
        });

        it('builds a stable estimate key from address and sorted products', function () {
            var hook = loadCalculateHook({ ok: false });
            var shipment = calculateShipment();
            shipment.productLineItems = [
                { productID: 'sku-2', quantityValue: 1 },
                { productID: 'sku-1', quantityValue: 2 }
            ];

            var payload = {
                address: {
                    country: 'US',
                    postalCode: '10001',
                    state: 'NY',
                    city: 'New York'
                },
                products: [
                    { stockKeepingUnit: 'sku-1', quantity: 2 },
                    { stockKeepingUnit: 'sku-2', quantity: 1 }
                ]
            };

            expect(hook._private.buildEstimateKey(shipment)).to.equal(hashEstimatePayload(payload));
            expect(hook._private.buildEstimateKey(shipment)).to.match(/^[a-f0-9]{64}$/);
        });

        it('does not call CDS for non-basket PATCH calculations', function () {
            var shipment = calculateShipment();
            var calls = 0;
            var hook = loadCalculateHook({ ok: true, object: {} }, function () {
                calls++;
            });
            var estimateKey = hook._private.buildEstimateKey(shipment);
            shipment.custom.deliveryEstimateKey = estimateKey;
            shipment.custom.deliveryEstimateSnapshot = JSON.stringify({
                methods: {
                    MappedShipping: {
                        startAt: '2026-07-01T10:30:00.000Z',
                        endAt: '2026-07-02T10:30:00.000Z',
                        orderCutoffAt: '2099-06-30T16:00:00.000Z'
                    }
                }
            });

            global.request = {
                httpMethod: 'PATCH',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1/items/item1'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(0);
            expect(shipment.custom.deliveryEstimateKey).to.equal(estimateKey);
            expect(shipment.custom.deliveryWindowStartAt).to.equal(undefined);
        });

        it('reuses a fresh snapshot when the selected shipping method changes', function () {
            var shipment = calculateShipment();
            var hook = loadCalculateHook({ ok: false });
            var estimateKey = hook._private.buildEstimateKey(shipment);
            shipment.custom.deliveryEstimateKey = estimateKey;
            shipment.custom.deliveryEstimateSnapshot = JSON.stringify({
                methods: {
                    MappedShipping: {
                        startAt: '2026-07-01T10:30:00.000Z',
                        endAt: '2026-07-02T10:30:00.000Z',
                        orderCutoffAt: '2099-06-30T16:00:00.000Z'
                    }
                }
            });

            global.request = {
                httpMethod: 'PUT',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1/shipments/me/shipping-method'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-01T10:30:00.000Z').getTime());
            expect(shipment.custom.deliveryWindowEndAt.getTime()).to.equal(new Date('2026-07-02T10:30:00.000Z').getTime());
        });

        it('refreshes stale estimates on set shipping address', function () {
            var shipment = calculateShipment();
            var calls = 0;
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-02T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            }, function () {
                calls++;
            });

            global.request = {
                httpMethod: 'PUT',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1/shipments/me/shipping-address'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(1);
            expect(shipment.custom.deliveryEstimateKey).to.equal(hook._private.buildEstimateKey(shipment));
        });

        it('refreshes when selected method is missing from a fresh snapshot on set shipping method', function () {
            var shipment = calculateShipment();
            var calls = 0;
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-02T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            }, function () {
                calls++;
            });
            var estimateKey = hook._private.buildEstimateKey(shipment);
            shipment.custom.deliveryEstimateKey = estimateKey;
            shipment.custom.deliveryEstimateSnapshot = JSON.stringify({
                methods: {}
            });

            global.request = {
                httpMethod: 'PUT',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1/shipments/me/shipping-method'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(1);
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-01T10:30:00').getTime());
        });

        it('aggregates split fulfillment groups into one conservative method window', function () {
            var shipment = calculateShipment();
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    locationId: 'fulfillment-east',
                                    productDeliveryEstimations: [
                                        { stockKeepingUnit: 'sku-1', quantity: 1 }
                                    ],
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-02T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-29T16:00:00'
                                        }
                                    ]
                                },
                                {
                                    locationId: 'fulfillment-west',
                                    productDeliveryEstimations: [
                                        { stockKeepingUnit: 'sku-2', quantity: 1 }
                                    ],
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-03T10:30:00',
                                                max: '2026-07-05T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });

            global.request = {
                httpMethod: 'PATCH',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            var methodSnapshot = JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping;
            expect(status.status).to.equal(Status.OK);
            expect(methodSnapshot.startAt).to.equal(new Date('2026-07-01T10:30:00').toISOString());
            expect(methodSnapshot.endAt).to.equal(new Date('2026-07-05T10:30:00').toISOString());
            expect(methodSnapshot.orderCutoffAt).to.equal(new Date('2099-06-29T16:00:00').toISOString());
            expect(methodSnapshot.groups).to.deep.equal([
                {
                    products: ['sku-1'],
                    startAt: new Date('2026-07-01T10:30:00').toISOString(),
                    endAt: new Date('2026-07-02T10:30:00').toISOString(),
                    orderCutoffAt: new Date('2099-06-29T16:00:00').toISOString(),
                    location: 'fulfillment-east'
                },
                {
                    products: ['sku-2'],
                    startAt: new Date('2026-07-03T10:30:00').toISOString(),
                    endAt: new Date('2026-07-05T10:30:00').toISOString(),
                    orderCutoffAt: new Date('2099-06-30T16:00:00').toISOString(),
                    location: 'fulfillment-west'
                }
            ]);
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-01T10:30:00').getTime());
            expect(shipment.custom.deliveryWindowEndAt.getTime()).to.equal(new Date('2026-07-05T10:30:00').getTime());
            expect(shipment.custom.orderCutoffAt.getTime()).to.equal(new Date('2099-06-29T16:00:00').getTime());
        });

        it('does not store a method window when split fulfillment group coverage is incomplete', function () {
            var shipment = calculateShipment();
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    productDeliveryEstimations: [
                                        { stockKeepingUnit: 'sku-1', quantity: 1 }
                                    ],
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-02T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-29T16:00:00'
                                        }
                                    ]
                                },
                                {
                                    productDeliveryEstimations: [
                                        { stockKeepingUnit: 'sku-2', quantity: 1 }
                                    ],
                                    shippingMethods: []
                                }
                            ]
                        }
                    ]
                }
            });

            global.request = {
                httpMethod: 'PATCH',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping).to.equal(undefined);
            expect(shipment.custom.deliveryWindowStartAt).to.equal(undefined);
        });

        it('stores CDS delivery metadata on shipment custom fields', function () {
            var shipment = calculateShipment();
            var calls = 0;
            var hook = loadCalculateHook({
                ok: true,
                object: {
                    deliveryEstimates: [
                        {
                            deliveryEstimateGroup: [
                                {
                                    shippingMethods: [
                                        {
                                            shippingCarrierMethod: 'NON_PICKUP_DAYS_UPS',
                                            estimatedDeliveryDate: {
                                                min: '2026-07-01T10:30:00',
                                                max: '2026-07-02T10:30:00'
                                            },
                                            orderCutoffTime: '2099-06-30T16:00:00'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            }, function () {
                calls++;
            });

            global.request = {
                httpMethod: 'PATCH',
                httpPath: '/s/-/dw/shop/v23_2/baskets/b1'
            };
            var status = hook.calculate({ shipments: [shipment] });
            delete global.request;

            expect(status.status).to.equal(Status.OK);
            expect(calls).to.equal(1);
            expect(shipment.custom.deliveryEstimateKey).to.equal(hook._private.buildEstimateKey(shipment));
            expect(JSON.parse(shipment.custom.deliveryEstimateSnapshot).estimateHash).to.equal(undefined);
            expect(JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping).to.exist;
            expect(JSON.parse(shipment.custom.deliveryEstimateSnapshot).methods.MappedShipping.groups).to.equal(undefined);
            expect(shipment.custom.deliveryWindowStartAt).to.be.an.instanceof(Date);
            expect(shipment.custom.deliveryWindowEndAt).to.be.an.instanceof(Date);
            expect(shipment.custom.orderCutoffAt).to.be.an.instanceof(Date);
            expect(shipment.custom.deliveryWindowStartAt.getTime()).to.equal(new Date('2026-07-01T10:30:00').getTime());
            expect(shipment.custom.deliveryWindowEndAt.getTime()).to.equal(new Date('2026-07-02T10:30:00').getTime());
            expect(shipment.custom.orderCutoffAt.getTime()).to.equal(new Date('2099-06-30T16:00:00').getTime());
        });
    });
});
