# Commerce Delivery Service

Show shoppers estimated delivery dates for products and during checkout.

## Overview

The Commerce Delivery Service app connects B2C Commerce to Salesforce Commerce Delivery Service so shoppers can see estimated delivery dates on the product detail page and at checkout. It registers shipping hooks that call CDS for mapped shipping methods, then returns carrier and delivery-window data to Shopper Delivery Estimates and basket shipping-method quotes.

## Features

- Delivery estimates on the product detail page via `sfcc.app.shipping.estimate`
- Checkout shipping-method delivery windows via `sfcc.app.shipping.quote`
- Persists the selected method's CDS delivery metadata on the shipment during  
basket calculation via `sfcc.app.shipping.calculate`
- Caches PDP estimates to avoid repeat CDS calls for the same product and destination

## Prerequisites

- Salesforce Commerce Cloud B2C Commerce instance
- Commerce Delivery Service configured in Salesforce Order Management
- An Account Manager client with the `sfcc.commercedeliveryservice.shopper` and `sfcc.inventory.availability` scopes
- Shipping methods with fallback estimates in the description field, with CDS carrier and method names available to map

## Post-Installation Checklist

- [ ] Connect CDS with B2C Commerce in Salesforce Order Management
- [ ] Set the `cds.shipping.api` credential URL
- [ ] Grant Account Manager scopes `sfcc.commercedeliveryservice.shopper` and `sfcc.inventory.availability`
- [ ] Set the Account Manager client ID and secret on `cds.accountmanager.oauth`
- [ ] Set `realmInstanceId`, `salesforceRegion`, and `deliveryEstimationSetupName`
- [ ] Map shipping methods with `cdsShippingCarrier` and `cdsMethodName`
- [ ] Verify PDP delivery estimates and checkout shipping-method delivery windows

## Support

- Salesforce Help: [https://help.salesforce.com/](https://help.salesforce.com/)
- Delivery Estimation overview:  
[https://help.salesforce.com/s/articleView?id=commerce.om_del_est_overview.htm&type=5](https://help.salesforce.com/s/articleView?id=commerce.om_del_est_overview.htm&type=5)

## License

Copyright 2026 Salesforce, Inc. All rights reserved.