'use strict';

var expect = require('chai').expect;
var proxyquire = require('proxyquire').noCallThru();

function logger() {
    return {
        warn: function () {},
        error: function () {},
        debug: function () {}
    };
}

function memoryCache() {
    var store = {};
    // Mirrors dw.system.Cache: the loader runs on a miss and undefined is not stored.
    return {
        get: function (key, loader) {
            if (!Object.prototype.hasOwnProperty.call(store, key) && loader) {
                var value = loader();
                if (value !== undefined) {
                    store[key] = value;
                }
            }
            return store[key];
        },
        invalidate: function (key) {
            delete store[key];
        },
        keys: function () {
            return Object.keys(store);
        }
    };
}

var deliveryConfig = {
    accountManagerUrl: 'https://account.demandware.com',
    scope: 'SALESFORCE_COMMERCE_API',
    realmInstanceId: 'zzrf-001',
    commercedeliverybindingid: 'sfcc.commercedeliveryservice.shopper',
    commerceinventorybindingid: 'sfcc.inventory.availability'
};

function configForRealm(realmInstanceId) {
    return Object.assign({}, deliveryConfig, { realmInstanceId: realmInstanceId });
}

function loadTokenService(options) {
    var calls = [];
    var config = options.config || deliveryConfig;
    var results = [].concat(options.serviceResult);
    var service = proxyquire('../../cartridge/scripts/services/accountManagerTokenService', {
        'dw/svc/LocalServiceRegistry': {
            createService: function () {
                return {
                    call: function () {
                        var result = results[Math.min(calls.length, results.length - 1)];
                        calls.push(true);
                        return result;
                    }
                };
            }
        },
        'dw/system/Logger': { getLogger: logger },
        'dw/system/CacheMgr': {
            getCache: function (id) {
                if (options.cacheThrows) {
                    throw new Error('cache down');
                }
                expect(id).to.equal('CDSShippingAccountManagerToken');
                return options.cache;
            }
        },
        '~/cartridge/scripts/config/cdsShippingConfig': {
            getCommerceDeliveryConfig: function () {
                return config;
            },
            getRealmInstanceId: function () {
                return config.realmInstanceId;
            }
        }
    });

    return {
        service: service,
        calls: calls
    };
}

describe('CDS Account Manager token cache', function () {
    it('fetches once, stores the token under the realm key, and reuses it', function () {
        var cache = memoryCache();
        var loaded = loadTokenService({
            cache: cache,
            serviceResult: { ok: true, object: { access_token: 'fresh-token' } }
        });

        expect(loaded.service.getAccountManagerToken()).to.equal('fresh-token');
        expect(loaded.service.getAccountManagerToken()).to.equal('fresh-token');
        expect(loaded.calls).to.have.length(1);
        expect(cache.keys()).to.deep.equal(['accountManagerToken_zzrf-001']);
    });

    it('shares a token between sites on the same realm', function () {
        var cache = memoryCache();
        var siteA = loadTokenService({
            cache: cache,
            serviceResult: { ok: true, object: { access_token: 'realm-token' } }
        });
        var siteB = loadTokenService({
            cache: cache,
            serviceResult: { ok: true, object: { access_token: 'unused-token' } }
        });

        expect(siteA.service.getAccountManagerToken()).to.equal('realm-token');
        expect(siteB.service.getAccountManagerToken()).to.equal('realm-token');
        expect(siteB.calls).to.have.length(0);
    });

    it('keeps separate tokens for sites on different realms', function () {
        var cache = memoryCache();
        var siteA = loadTokenService({
            cache: cache,
            config: configForRealm('zzrf-001'),
            serviceResult: { ok: true, object: { access_token: 'token-001' } }
        });
        var siteB = loadTokenService({
            cache: cache,
            config: configForRealm('zzrf-002'),
            serviceResult: { ok: true, object: { access_token: 'token-002' } }
        });

        expect(siteA.service.getAccountManagerToken()).to.equal('token-001');
        expect(siteB.service.getAccountManagerToken()).to.equal('token-002');
        expect(siteA.service.getAccountManagerToken()).to.equal('token-001');
        expect(cache.keys()).to.have.members(['accountManagerToken_zzrf-001', 'accountManagerToken_zzrf-002']);
    });

    it('does not cache a failed token fetch', function () {
        var cache = memoryCache();
        var loaded = loadTokenService({
            cache: cache,
            serviceResult: { ok: false, status: 'ERROR', error: 500, msg: 'down' }
        });

        expect(loaded.service.getAccountManagerToken()).to.not.exist;
        expect(loaded.service.getAccountManagerToken()).to.not.exist;
        expect(loaded.calls).to.have.length(2);
        expect(cache.keys()).to.have.length(0);
    });

    it('does not cache when Account Manager returns no access token', function () {
        var cache = memoryCache();
        var loaded = loadTokenService({
            cache: cache,
            serviceResult: { ok: true, object: {} }
        });

        expect(loaded.service.getAccountManagerToken()).to.not.exist;
        expect(cache.keys()).to.have.length(0);
    });

    it('does not call Account Manager when configuration is missing', function () {
        var cache = memoryCache();
        var loaded = loadTokenService({
            cache: cache,
            config: configForRealm(''),
            serviceResult: { ok: true, object: { access_token: 'unused' } }
        });

        expect(loaded.service.getAccountManagerToken()).to.equal(null);
        expect(loaded.calls).to.have.length(0);
        expect(cache.keys()).to.have.length(0);
    });

    it('fetches a token when the cache is unavailable', function () {
        var loaded = loadTokenService({
            cacheThrows: true,
            serviceResult: { ok: true, object: { access_token: 'token' } }
        });

        expect(loaded.service.getAccountManagerToken()).to.equal('token');
        expect(loaded.calls).to.have.length(1);
    });

    it('drops only the current realm token on invalidate', function () {
        var cache = memoryCache();
        var other = loadTokenService({
            cache: cache,
            config: configForRealm('zzrf-002'),
            serviceResult: { ok: true, object: { access_token: 'other-token' } }
        });
        var loaded = loadTokenService({
            cache: cache,
            serviceResult: [
                { ok: true, object: { access_token: 'first' } },
                { ok: true, object: { access_token: 'second' } }
            ]
        });

        other.service.getAccountManagerToken();
        expect(loaded.service.getAccountManagerToken()).to.equal('first');
        loaded.service.invalidateAccountManagerToken();
        expect(cache.keys()).to.deep.equal(['accountManagerToken_zzrf-002']);

        expect(loaded.service.getAccountManagerToken()).to.equal('second');
        expect(loaded.calls).to.have.length(2);
    });
});

describe('CDS delivery estimate Account Manager retry', function () {
    function loadShippingService(results, tokenState) {
        var callCount = 0;
        var headers = [];
        var service = proxyquire('../../cartridge/scripts/services/cdsShippingService', {
            'dw/svc/LocalServiceRegistry': {
                createService: function (id, callbacks) {
                    return {
                        call: function (body) {
                            var result = results[callCount] || results[results.length - 1];
                            callCount += 1;
                            callbacks.createRequest({
                                getURL: function () {
                                    return 'https://cds.example';
                                },
                                setURL: function () {},
                                setRequestMethod: function () {},
                                addHeader: function (name, value) {
                                    headers.push(name + ': ' + value);
                                }
                            }, body);
                            return result;
                        }
                    };
                }
            },
            'dw/system/Logger': { getLogger: logger },
            'dw/util/UUIDUtils': {
                createUUID: function () {
                    return 'correlation-id';
                }
            },
            '~/cartridge/scripts/config/cdsShippingConfig': {
                getRealmInstanceId: function () {
                    return 'zzrf-001';
                },
                getSalesforceRegion: function () {
                    return 'us-east-2';
                }
            },
            '~/cartridge/scripts/services/accountManagerTokenService': {
                getAccountManagerToken: function () {
                    tokenState.gets += 1;
                    return tokenState.token;
                },
                invalidateAccountManagerToken: function () {
                    tokenState.invalidated += 1;
                    tokenState.token = tokenState.refreshFails ? null : 'fresh-token';
                }
            }
        });

        return {
            service: service,
            headers: headers,
            callCount: function () {
                return callCount;
            }
        };
    }

    it('retries once with a new token when the delivery API returns 401', function () {
        var tokenState = { token: 'cached-token', gets: 0, invalidated: 0 };
        var loaded = loadShippingService([
            { ok: false, error: 401, status: 'ERROR' },
            { ok: true, object: { deliveryEstimates: [] } }
        ], tokenState);

        var result = loaded.service.callDeliveryEstimation({ products: [] });

        expect(result.ok).to.equal(true);
        expect(loaded.callCount()).to.equal(2);
        expect(tokenState.invalidated).to.equal(1);
        expect(tokenState.gets).to.equal(2);
        expect(loaded.headers).to.include('Authorization: Bearer cached-token');
        expect(loaded.headers).to.include('Authorization: Bearer fresh-token');
    });

    it('does not retry a second time when the new token is also rejected', function () {
        var tokenState = { token: 'cached-token', gets: 0, invalidated: 0 };
        var loaded = loadShippingService([
            { ok: false, error: '401', status: 'ERROR' },
            { ok: false, error: 401, status: 'ERROR' }
        ], tokenState);

        var result = loaded.service.callDeliveryEstimation({ products: [] });

        expect(result.ok).to.equal(false);
        expect(loaded.callCount()).to.equal(2);
        expect(tokenState.invalidated).to.equal(1);
    });

    it('does not call CDS when no token is available', function () {
        var tokenState = { token: null, gets: 0, invalidated: 0 };
        var loaded = loadShippingService([
            { ok: true, object: { deliveryEstimates: [] } }
        ], tokenState);

        expect(loaded.service.callDeliveryEstimation({ products: [] })).to.equal(null);
        expect(loaded.callCount()).to.equal(0);
        expect(tokenState.invalidated).to.equal(0);
    });

    it('returns null without retrying when a new token cannot be fetched', function () {
        var tokenState = { token: 'cached-token', gets: 0, invalidated: 0, refreshFails: true };
        var loaded = loadShippingService([
            { ok: false, error: 401, status: 'ERROR' }
        ], tokenState);

        expect(loaded.service.callDeliveryEstimation({ products: [] })).to.equal(null);
        expect(loaded.callCount()).to.equal(1);
        expect(tokenState.invalidated).to.equal(1);
    });

    it('does not refresh the token when the delivery API succeeds', function () {
        var tokenState = { token: 'cached-token', gets: 0, invalidated: 0 };
        var loaded = loadShippingService([
            { ok: true, object: { deliveryEstimates: [] } }
        ], tokenState);

        var result = loaded.service.callDeliveryEstimation({ products: [] });

        expect(result.ok).to.equal(true);
        expect(loaded.callCount()).to.equal(1);
        expect(tokenState.invalidated).to.equal(0);
        expect(tokenState.gets).to.equal(1);
    });
});
