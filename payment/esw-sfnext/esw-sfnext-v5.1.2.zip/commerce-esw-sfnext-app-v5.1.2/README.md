# ESW Commerce App Package (test build)

Branch: `AB#441451_sfNextPrToSf`. This is a working test CAP assembled from the existing
`link_eshopworld` cartridges/metadata for installation against a **vanilla Storefront Next**
sandbox site, alongside the retailer cartridge path:

```
int_eshopworld_headless:int_eshopworld_core:app_storefrontnext_base:app_storefront_base:modules
```

Reference SFNext deployment this CAP is derived from:
https://runtime.commercecloud.com/eshopworld/esw-storefront-next/zyfl-002

## What's in this package

- `cartridges/site_cartridges/int_eshopworld_headless` — OCAPI/SCAPI hook implementations (copied as-is from `link_eshopworld/cartridges/int_eshopworld_headless`).
- `cartridges/site_cartridges/int_eshopworld_core` — shared helpers bundled as a dependency (copied as-is; added a `package.json` since the source cartridge didn't have one).
- `impex/install/jobs.xml` — copied from `link_eshopworld/Metadata/jobs.xml` with all hardcoded `site-id="RefArch"`/`"Sites"` contexts replaced by the platform's documented `SITEID` placeholder, the deprecated `eswRetailerOrderStatus` job removed, the demo `test@gmail.com` mail rule removed, and one stray enabled `run-once` (stale 2022 date) disabled.
- `impex/install/services.xml` — copied from `Metadata/services.xml`, excluding services not needed for the
   basic setup (multi-origin inventory sync, OCAPI dispatch/data-auth, package ASN/JWKS, and embedded-checkout
   OCAPI services) and their now-unreferenced credentials.
- `impex/install/meta/custom-objecttype-definitions.xml` — copied as-is from `Metadata/meta/customobjects.xml` (`ESW_PA_DATA`, `ESW_COUNTRIES`).
- `impex/install/meta/system-objecttype-extensions.xml` — merged from `Metadata/meta/systemobjects.xml` + `systemobjects_headless.xml`, with PWA-Kit-only attributes (`eswIsPwaKitMappingEnabled`, `eswPwaUrlExpansionPairs`, the `PWA` enum value) stripped since this targets SFNext only. `systemobjects_spark.xml` (Page Designer/SFRA) was excluded entirely.
- `impex/install/sites/SITEID/preferences.xml` — newly authored (not lifted from `Metadata/sites/RefArch`, which was a full SFRA demo-site export); sets `eswHeadlessResponseMapping=SfNext` and the headless config preferences. Uses the standard `SITEID` placeholder, auto-bound to the target site at install time.
- `impex/uninstall/**` — generated from `link_eshopworld/Metadata/` alongside install: `services.xml`
   deletes all installed service definitions. Credential and profile deletion entries are not
   included because the target CAP importer rejects those entries during uninstall validation.
   Metadata deletion is intentionally not included because `mode="delete"` is rejected for
   system-object attributes and custom object types by some sandbox releases; remove those
   definitions separately in Business Manager when required.
- `storefront-next/src/extensions/eshopworld/` — copied from `esw-sfnext-app/src/extensions/esw/` (routes, content, target-config.json) plus `esw-sfnext-app/esw-overrides/` under `overrides/`. `target-config.json` path updated for the renamed folder.

## Licensing and support

The original CAP submission did not declare an open-source license for ESW app code.
The manifest records this as `UNLICENSED`; this packaging update grants no new license.
Bundled third-party components retain their existing licenses and notices.
Source: https://github.com/eswcore/salesforce-plugin
Support: https://www.esw.com/

## Registry submission fixes

This CAP includes hook error handling and the registered `beforePOST_v2` and item
`afterPOST` exports required by registry validation. All service profiles enable
rate limiting and circuit breakers. Service credentials remain blank encrypted
fields, and secret site preferences use the password type.
These submission fixes are maintained in the registry working copy only; the
`salesforce-plugin` repository remains the source of truth and is unchanged.

## Known gaps / manual steps before a real install

1. **`it-IT` locale is an untranslated placeholder** (copied from `en-US`) — replace with real
   Italian strings before any non-test distribution.
2. **Credentials are blank by design** — enter real values via the `tasksList.json` wizard
   step during install, never commit them here.
3. `storefront-next/src/extensions/eshopworld/overrides/` was copied wholesale from
   `esw-overrides/`; review it against the base vanilla SFNext template you're installing
   into and trim anything that assumes `esw-sfnext-app`'s specific base app structure.

Note: `impex/install/jobs.xml` and `impex/install/sites/SITEID/preferences.xml` already use the
platform's documented `SITEID` placeholder — the install job replaces it automatically in file
paths and content, so no manual site-ID substitution is needed before packaging.

## Packaging (once gaps above are addressed)

```
cd /home/uhamid/projects/salesforce-plugin
source "$NVM_DIR/nvm.sh"
nvm use 24
node link_eshopworld/scripts/build-sfnext-cap.js
sha256sum link_eshopworld/esw-sfnext-v5.1.2.zip
```

The builder synchronizes cartridge code and regenerates the SFNext-compatible install
and uninstall IMPEX from `link_eshopworld/Metadata/`. It preserves the curated site
preference defaults, `app-configuration/`, `storefront-next/`, and `icons/` files.
This keeps jobs, services, custom/system objects, task definitions, and storefront
configuration synchronized on every build.

Validate the generated archive with `b2c cap validate link_eshopworld/esw-sfnext-v5.1.2.zip`.

## Installing on a sandbox (BM or CLI)

**Business Manager (no-code):**
1. In BM on your target sandbox, go to the **Cart & Checkout Hub**.
2. Select **Install App** (or **Upload App**, if this test build isn't in the public registry
   yet) and upload `esw-sfnext-v5.1.2.zip`.
3. Choose the target site (a vanilla SFNext site, not `RefArch`) — the platform binds all
   `SITEID`-templated IMPEX to that site automatically.
4. The install job unpacks the archive, deploys the two cartridges to the active code version,
   runs the `impex/install/**` data import, and opens a PR against the site's Storefront Next
   GitHub repo with the `storefront-next/src/extensions/eshopworld/` content.
5. You're redirected to the configuration task list (from `tasksList.json`) — complete each
   step (service credentials, headless mapping, optional features).
6. Merge the generated PR into your SFNext repo, then `git pull`/`pnpm install`/`pnpm dev`
   locally to see the ESW component render.

**B2C CLI (pro-code):**
```
b2c cap validate esw-sfnext-v5.1.2.zip
b2c cap install --site-id <your-sandbox-site-id>
b2c cap list --site-id <your-sandbox-site-id>      # confirm it shows as installed
b2c cap tasks eshopworld --site-id <your-sandbox-site-id>   # check config task status
```

## Testing steps

1. Confirm in Business Manager: cartridges (`int_eshopworld_headless`, `int_eshopworld_core`)
   appear in the site's cartridge path, jobs/services/custom objects/site preferences are
   present under the target site.
2. Approve/merge the generated PR against your vanilla SFNext app repo, `git pull` it locally,
   run `pnpm dev`, and confirm the ESW component renders at `sfcc.cart.payments.expressCheckout`.
3. Smoke test: add to cart → basket ESW price fields populate → checkout → order placed →
   confirm ESW order attributes (`eswOrderNo`, `eswFxrate`, etc.) are populated.
4. Test uninstall: `b2c cap uninstall` (or via BM), confirm the app, cartridges, services,
   and jobs are removed. Remove ESW system attributes and custom object types separately in
   Business Manager because CAP metadata delete entries are not supported reliably.
5. If testing multi-site, install on a second site and confirm uninstalling from one site
   doesn't affect the other (instance-scoped resources like cartridges/services only get
   removed when the *last* site uninstalls the app).

