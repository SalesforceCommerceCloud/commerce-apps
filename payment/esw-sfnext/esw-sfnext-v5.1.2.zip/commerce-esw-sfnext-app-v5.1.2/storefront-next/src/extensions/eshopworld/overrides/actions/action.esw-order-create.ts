/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { data, type ActionFunctionArgs } from 'react-router';
import { createApiClients } from '@/lib/api-clients.server';
import { createActionError } from '@/lib/action-error-helpers.server';
import { ErrorCode } from '@/lib/error-codes';
import { getLogger } from '@/lib/logger.server';
import type { ShopperOrders } from '@/scapi';

interface EswOrderCreateResponse {
    success: boolean;
    orderNo?: string;
    order?: ShopperOrders.schemas['Order'];
    error?: ReturnType<typeof createActionError>;
}

function errorResponse(status: number, error: ReturnType<typeof createActionError>) {
    return data<EswOrderCreateResponse>({ success: false, error }, { status });
}

export async function action({ request, context }: ActionFunctionArgs) {
    const logger = getLogger(context);

    if (request.method !== 'POST') {
        return errorResponse(
            405,
            createActionError({ code: ErrorCode.METHOD_NOT_ALLOWED, message: 'Method not allowed' })
        );
    }

    try {
        const formData = await request.formData();
        const basketIdRaw = formData.get('basketId');
        const basketId = typeof basketIdRaw === 'string' ? basketIdRaw.trim() : '';

        if (!basketId) {
            return errorResponse(
                400,
                createActionError({ code: ErrorCode.REQUIRED_FIELD, message: 'basketId is required' })
            );
        }

        const apiClients = createApiClients(context);
        const { data: order } = await apiClients.shopperOrders.createOrder({
            params: {},
            body: { basketId },
        });

        logger.info('EswOrderCreate: succeeded', { basketId, orderNo: order?.orderNo });

        return data<EswOrderCreateResponse>({ success: true, orderNo: order?.orderNo, order });
    } catch (error) {
        logger.error('EswOrderCreate: failed', { error });
        return errorResponse(500, createActionError({ error }));
    }
}
