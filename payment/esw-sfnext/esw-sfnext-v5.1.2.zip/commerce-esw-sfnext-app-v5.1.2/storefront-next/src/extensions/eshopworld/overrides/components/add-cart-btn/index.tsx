import type { ReactElement } from 'react';
import { Button } from '@/components/ui/button';
import type { ShopperProducts } from '@/scapi';

interface EswProduct extends ShopperProducts.schemas['Product'] {
    c_eswRestrictedProduct?: boolean;
    c_eswRestrictedProductMsg?: string;
}

interface EswAddToCartButtonProps {
    product: EswProduct;
    isEditMode: boolean;
    isAddingToOrUpdatingCart: boolean;
    canAddToCart: boolean;
    onClick: () => void;
    addToCartText: string;
    addingToCartText: string;
    updateCartText: string;
}

export function EswAddToCartButton({
    product,
    isEditMode,
    isAddingToOrUpdatingCart,
    canAddToCart,
    onClick,
    addToCartText,
    addingToCartText,
    updateCartText,
}: EswAddToCartButtonProps): ReactElement {
    const isRestricted = product.c_eswRestrictedProduct === true;

    return (
        <>
            <Button
                data-testid="add-to-cart"
                onClick={onClick}
                disabled={
                    isRestricted ||
                    !canAddToCart ||
                    isAddingToOrUpdatingCart
                }
                className="w-full text-base font-semibold leading-6"
                size="lg">
                {isEditMode
                    ? updateCartText
                    : isAddingToOrUpdatingCart
                      ? addingToCartText
                      : addToCartText}
            </Button>

            {isRestricted && product.c_eswRestrictedProductMsg && (
                <div
                    role="alert"
                    className="mt-3 rounded-md border border-destructive/30 bg-destructive/10 p-4 text-destructive">
                    {product.c_eswRestrictedProductMsg}
                </div>
            )}
        </>
    );
}
