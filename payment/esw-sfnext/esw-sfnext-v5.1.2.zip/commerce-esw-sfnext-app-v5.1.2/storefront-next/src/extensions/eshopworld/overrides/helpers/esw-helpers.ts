export function saveToLocalStorage(storageKey: string, value: unknown): void {
    if (typeof window === 'undefined') {
        return;
    }

    try {
        window.localStorage.setItem(storageKey, JSON.stringify(value));
    } catch {
        // Ignore localStorage write failures.
    }
}

/**
 * Get shopper currency config from local storage
 * @param {string} configKey - config property key
 * @returns {*} - config value
 */
export const getEswConfigByKey = (configKey: string) => {
    if (typeof window === 'undefined') {
        return undefined;
    }

    const response = localStorage.getItem('eswCustom.getBmConfigs.response');

    if (!response) {
        return undefined;
    }

    try {
        const parsed = JSON.parse(response);
        return parsed?.eswBmConfigs?.[configKey];
    } catch (error) {
        console.error('Unable to parse ESW BM configs', error);
        return undefined;
    }
};

export const getEswShopperCurrencyConfigByKey = (configKey: string) => {
    if (typeof window === 'undefined') {
        return undefined;
    }

    const response = localStorage.getItem('eswCustom.getBmConfigs.response');

    if (!response) {
        return undefined;
    }

    try {
        const parsed = JSON.parse(response);

        return (
            parsed?.eswBmConfigs?.[configKey] ??
            parsed?.shopperPricingConfigs?.[configKey]
        );
    } catch (error) {
        console.error('Unable to parse ESW BM configs', error);
        return undefined;
    }
};
