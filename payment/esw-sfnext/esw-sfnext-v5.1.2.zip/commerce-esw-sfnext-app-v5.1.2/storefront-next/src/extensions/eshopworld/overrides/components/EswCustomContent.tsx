/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { useEffect, useRef } from 'react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useScapiFetcher } from '@/hooks/use-scapi-fetcher';
import { convertPrice } from '../helpers/esw-calculation-helper';
import { appendSanitizedHtml } from '../helpers/sanitize-content';
import EswPageLoadInit from './esw/EswPageLoadInit';

export default function EswCustomContent() {
    const { site } = useSite();
    const contentRef = useRef<HTMLDivElement>(null);
    const hasRenderedContent = useRef(false);

    const fetcher = useScapiFetcher('eswCustom', 'getEswTestContent', {
        params: {
            query: {
                siteId: site.id,
            },
        },
    });
    const contentBody = (fetcher.data as { body?: string } | undefined)?.body;

    useEffect(() => {
        if (site.id) {
            void fetcher.load();
        }
    }, [site.id]);

    useEffect(() => {
        if (
            contentBody &&
            contentRef.current &&
            !hasRenderedContent.current
        ) {
            hasRenderedContent.current = true;

            appendSanitizedHtml(contentRef.current, contentBody);

            let animationFrameId: number | undefined;
            let observer: MutationObserver | undefined;
            const interval = setInterval(() => {
                if (localStorage.getItem('eswCustom.getBmConfigs.response')) {
                    clearInterval(interval);

                    animationFrameId = requestAnimationFrame(() => {
                        convertPrice();
                    });
                    observer = new MutationObserver(() => {
                        if (animationFrameId !== undefined) {
                            cancelAnimationFrame(animationFrameId);
                        }
                        animationFrameId = requestAnimationFrame(() => {
                            convertPrice();
                        });
                    });

                    observer.observe(document.body, { childList: true, subtree: true });

                }
            }, 100);

            return () => {
                clearInterval(interval);
                if (animationFrameId !== undefined) {
                    cancelAnimationFrame(animationFrameId);
                }
                observer?.disconnect();
            };
        }
    }, [contentBody]);

    return (
        <>
            <EswPageLoadInit />
            <div className="esw-custom-content">
                <div ref={contentRef} />
            </div>
        </>
    );
}