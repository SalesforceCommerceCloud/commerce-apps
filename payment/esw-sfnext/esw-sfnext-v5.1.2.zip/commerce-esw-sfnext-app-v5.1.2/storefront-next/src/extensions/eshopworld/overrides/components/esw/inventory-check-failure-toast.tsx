/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router';
import { useToast } from '@/components/toast';

const INVENTORY_ERROR = 'inventoryCheckFailure';
const INVENTORY_ERROR_MESSAGE = 'The remaining items are currently not available. Please adjust the quantity';

export default function InventoryCheckFailureToast() {
    const { addToast } = useToast();
    const [searchParams, setSearchParams] = useSearchParams();
    const hasShownToastRef = useRef(false);

    useEffect(() => {
        if (searchParams.get('error') !== INVENTORY_ERROR) {
            hasShownToastRef.current = false;
            return;
        }

        if (hasShownToastRef.current) {
            return;
        }

        let cleanupTimeoutId: number | undefined;
        const toastTimeoutId = window.setTimeout(() => {
            hasShownToastRef.current = true;
            addToast(INVENTORY_ERROR_MESSAGE, 'error');
            // Schedule cleanup of the error query parameter after showing the toast
            cleanupTimeoutId = window.setTimeout(() => {
                const nextParams = new URLSearchParams(searchParams);
                nextParams.delete('error');
                setSearchParams(nextParams, { replace: true });
            }, 100);
        }, 0);

        return () => {
            window.clearTimeout(toastTimeoutId);
            if (cleanupTimeoutId !== undefined) {
                window.clearTimeout(cleanupTimeoutId);
            }
        };
    }, [addToast, searchParams, setSearchParams]);

    return null;
}
