/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { act, renderHook } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
    ESW_CLIENT_LAST_ORDER_ID_KEY,
    ESW_CLIENT_LAST_ORDER_TOKEN,
    useAbandonmentCartOnPageLoad,
} from './use-abandonment-cart-on-page-load';

const { mockScapiFetcher, mockCartFetcher, mockCouponFetcher, mockSite, mockUseScapiFetcher } = vi.hoisted(() => ({
    mockScapiFetcher: {
        data: undefined as unknown,
        errors: [] as string[],
        state: 'idle',
        load: vi.fn(),
    },
    mockUseScapiFetcher: vi.fn(),
    mockCartFetcher: {
        state: 'idle',
        data: undefined as unknown,
        submit: vi.fn(),
    },
    mockCouponFetcher: {
        state: 'idle',
        data: undefined as unknown,
        submit: vi.fn(),
    },
    mockSite: { site: { id: 'test-site' } },
}));

vi.mock('@salesforce/storefront-next-runtime/site-context', () => ({
    useSite: () => mockSite,
}));

vi.mock('@/hooks/use-scapi-fetcher', () => ({
    useScapiFetcher: mockUseScapiFetcher,
}));

vi.mock('react-router', () => ({
    useFetcher: (() => {
        let index = 0;
        return () => [mockCartFetcher, mockCouponFetcher][index++ % 2];
    })(),
}));

describe('useAbandonmentCartOnPageLoad', () => {
    beforeEach(() => {
        localStorage.setItem(ESW_CLIENT_LAST_ORDER_ID_KEY, 'order-123');
        localStorage.setItem(ESW_CLIENT_LAST_ORDER_TOKEN, 'token-123');
        mockScapiFetcher.data = undefined;
        mockScapiFetcher.errors = [];
        mockScapiFetcher.load.mockClear();
        mockUseScapiFetcher.mockReset().mockReturnValue(mockScapiFetcher);
        mockCartFetcher.state = 'idle';
        mockCartFetcher.data = undefined;
        mockCartFetcher.submit.mockClear();
        mockCouponFetcher.submit.mockClear();
    });

    afterEach(() => {
        localStorage.clear();
    });

    it('loads the stored order ID and token for cart recovery', () => {
        renderHook(() => useAbandonmentCartOnPageLoad());

        expect(mockScapiFetcher.load).toHaveBeenCalledOnce();
        expect(
            mockUseScapiFetcher.mock.calls.some(([, , options]) => options.params.query.c_eswOrderToken === 'token-123')
        ).toBe(true);
    });

    it('clears the stored token after a successful recovery response', () => {
        const { rerender } = renderHook(() => useAbandonmentCartOnPageLoad());

        act(() => {
            mockScapiFetcher.data = {
                orderLineItems: { products: [] },
                basketItems: { products: [] },
                couponCodes: [],
                removeLineItems: true,
            };
            rerender();
        });

        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_ID_KEY)).toBeNull();
        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_TOKEN)).toBeNull();
    });

    it('removes stored order credentials when recovery returns an error', () => {
        const { rerender } = renderHook(() => useAbandonmentCartOnPageLoad());

        act(() => {
            mockScapiFetcher.errors = ['Order recovery failed'];
            rerender();
        });

        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_ID_KEY)).toBeNull();
        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_TOKEN)).toBeNull();
    });

    it('removes stored order credentials when recovery returns no data', () => {
        const { rerender } = renderHook(() => useAbandonmentCartOnPageLoad());

        act(() => {
            mockScapiFetcher.data = null;
            rerender();
        });

        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_ID_KEY)).toBeNull();
        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_TOKEN)).toBeNull();
    });
});
