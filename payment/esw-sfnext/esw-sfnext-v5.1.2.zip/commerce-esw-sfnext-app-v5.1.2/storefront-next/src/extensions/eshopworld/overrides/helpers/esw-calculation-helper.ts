/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { getEswShopperCurrencyConfigByKey } from './esw-helpers';

type Price = number | string;

type RoundingModel = {
    direction: string;
    model: string;
    currencyExponent: number;
};

type CountryAdjustment = {
    retailerAdjustments: { priceUpliftPercentage: number };
    estimatedRates: {
        dutyPercentage: number;
        taxPercentage: number;
        feePercentage?: number;
    };
};

function applyRoundingMethod(
    price: number,
    model: string,
    roundingModel: RoundingModel,
    isFractionalPart: boolean
): number {
    if (!model) {
        return price;
    }

    const roundingMethod = model.split(/(\d+)/)[0];

    if (roundingMethod.toLowerCase() === 'none') {
        return isFractionalPart ? (price / 100) % 1 : price;
    }

    let roundingTarget = model.split(/(\d+)/)[1];
    if (!roundingTarget) {
        return price;
    }
    let roundingTargetLength = roundingTarget.length;

    if (isFractionalPart) {
        roundingTarget = roundingTargetLength === 1 ? `${roundingTarget}0` : roundingTarget.substring(0, 2);
        roundingTargetLength = roundingTarget.length;
    }

    const numericRoundingTarget = Number(roundingTarget);
    let roundedPrice = price;

    if (roundingMethod.toLowerCase() === 'fixed') {
        const otherPart = price % Math.pow(10, roundingTargetLength);
        const priceWithoutOtherPart = price - otherPart;
        const roundedUp =
            (numericRoundingTarget < otherPart
                ? priceWithoutOtherPart + Math.pow(10, roundingTargetLength)
                : priceWithoutOtherPart) + numericRoundingTarget;
        let roundedDown =
            (numericRoundingTarget > otherPart
                ? priceWithoutOtherPart - Math.pow(10, roundingTargetLength)
                : priceWithoutOtherPart) + numericRoundingTarget;
        roundedDown = roundedDown < 0 && !isFractionalPart ? price : roundedDown;

        if (roundingModel.direction.toLowerCase() === 'up') {
            roundedPrice = roundedUp;
        } else if (roundingModel.direction.toLowerCase() === 'down') {
            roundedPrice = roundedDown;
        } else if (roundingModel.direction.toLowerCase() === 'nearest') {
            roundedPrice = Math.abs(roundedUp - price) >= Math.abs(price - roundedDown) ? roundedDown : roundedUp;
        }
    } else if (roundingModel.direction.toLowerCase() === 'up') {
        roundedPrice = Math.ceil(price / numericRoundingTarget) * numericRoundingTarget;
    } else if (roundingModel.direction.toLowerCase() === 'down') {
        roundedPrice = Math.floor(price / numericRoundingTarget) * numericRoundingTarget;
    } else if (roundingModel.direction.toLowerCase() === 'nearest') {
        const roundedUp = Math.ceil(price / numericRoundingTarget) * numericRoundingTarget;
        const roundedDown = Math.floor(price / numericRoundingTarget) * numericRoundingTarget;
        roundedPrice = Math.abs(roundedUp - price) >= Math.abs(price - roundedDown) ? roundedDown : roundedUp;
    }

    return isFractionalPart ? roundedPrice / Math.pow(10, roundingTargetLength) : roundedPrice;
}

function applyRoundingModel(price: number, roundingModel: RoundingModel | undefined): Price {
    if (!roundingModel || !roundingModel.model || price === 0) {
        return price;
    }

    if (roundingModel.direction?.toLowerCase?.() === 'none') {
        if (roundingModel.currencyExponent === 0) {
            return Math.trunc(price);
        }

        const factor = 10 ** roundingModel.currencyExponent;
        return Number(Math.trunc(price * factor) / factor);
    }

    let wholeNumber = Number.parseInt(String(price), 10);
    const [wholeModel, fractionalModel] = roundingModel.model.split('.');
    if (!fractionalModel) {
        return applyRoundingMethod(price, wholeModel, roundingModel, false);
    }
    const fractionalPart = Math.round((price % 1) * 100);
    const roundedFractionalPart = applyRoundingMethod(fractionalPart, fractionalModel, roundingModel, true);
    // truncate back to an integer so the whole-number pass isn't corrupted by the fractional remainder
    wholeNumber = Number.parseInt(String(wholeNumber + roundedFractionalPart), 10);
    const remainder = (wholeNumber + roundedFractionalPart) % 1;
    const roundedWholeNumber = applyRoundingMethod(wholeNumber, wholeModel, roundingModel, false);
    const roundedPrice = roundedWholeNumber + remainder;
    return roundingModel.currencyExponent === 0
        ? Number.parseInt(String(roundedPrice), 10)
        : roundedPrice.toFixed(roundingModel.currencyExponent);
}

export function convertPrice(): boolean {
    const priceElements = document.querySelectorAll<HTMLSpanElement>('span.esw-price:not(.esw-price-converted)');
    const selectedCurrencySymbol = String(getEswShopperCurrencyConfigByKey('symbol') ?? '');
    const isFixedPriceModel = getEswShopperCurrencyConfigByKey('isFixedPriceModel');
    const selectedFxRate = Number.parseFloat(String(getEswShopperCurrencyConfigByKey('fxRate') ?? ''));

    if (!isFixedPriceModel && !selectedFxRate) {
        return false;
    }

    const selectedCountryAdjustment = getEswShopperCurrencyConfigByKey('countryAdjustments') as CountryAdjustment | undefined;
    const roundingModel = getEswShopperCurrencyConfigByKey('roundingModel') as RoundingModel | undefined;

    priceElements.forEach((element) => {
        const rawText = element.textContent ?? '';
        let eswPrice = Number.parseFloat(rawText.replace(/[^0-9.-]+/g, '') ?? '');

        if (!isFixedPriceModel) {
            const disableRounding = element.getAttribute('data-disable-rounding') === 'true';
            const disableAdjustment = element.getAttribute('data-disable-adjustment') === 'true';

            if (selectedCountryAdjustment && !disableAdjustment) {
                const { priceUpliftPercentage } = selectedCountryAdjustment.retailerAdjustments;
                const { dutyPercentage, taxPercentage, feePercentage } = selectedCountryAdjustment.estimatedRates;

                eswPrice += (priceUpliftPercentage / 100) * eswPrice;
                eswPrice += (dutyPercentage / 100) * eswPrice;
                eswPrice += (taxPercentage / 100) * eswPrice;
                if (feePercentage) {
                    eswPrice += (feePercentage / 100) * eswPrice;
                }
            }

            eswPrice = Number(eswPrice * selectedFxRate);
            if (!disableRounding) {
                eswPrice = Number(applyRoundingModel(eswPrice, roundingModel));
            }
            element.textContent = `${selectedCurrencySymbol}${eswPrice.toFixed(2)}`;
        } else {
            element.textContent = `${selectedCurrencySymbol}${rawText.replace(/[^0-9.-]+/g, '') ?? ''}`;
        }

        element.classList.add('esw-price-converted');
    });

    return false;
}