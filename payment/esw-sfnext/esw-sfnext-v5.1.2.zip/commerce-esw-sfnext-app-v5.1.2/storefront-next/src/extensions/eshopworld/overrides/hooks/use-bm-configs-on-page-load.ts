import { useEffect, useMemo, useRef } from 'react';
import { useLocation } from 'react-router';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useScapiFetcher } from '@/hooks/use-scapi-fetcher';
import { saveToLocalStorage } from '../helpers/esw-helpers';

const BM_CONFIGS_STORAGE_KEY = 'eswCustom.getBmConfigs.response';

function getCountryFromPath(pathname: string, defaultCountry: string): string {
    const parts = pathname.split('/').filter(Boolean);

    const locale = parts[1];

    if (!locale) {
        return defaultCountry;
    }

    const localeParts = locale.split('-');

    return localeParts.length > 1
        ? localeParts[1].toUpperCase()
        : defaultCountry;
}

function resolveCountryFromLocale(locale: string | undefined, defaultCountry: string): string {
    if (!locale) {
        return defaultCountry;
    }

    const parts = locale.split(/[-_]/).filter(Boolean);
    const candidate = parts.length > 1 ? parts[parts.length - 1] : '';
    return candidate ? candidate.toUpperCase() : defaultCountry;
}

/**
 * Calls eswCustom.getBmConfigs as a GET request whenever the route changes.
 * The request is executed client-side via useScapiFetcher.load(), so it is visible in browser network tools.
 */
export function useBmConfigsOnPageLoad() {
    const { site, language } = useSite();
    const location = useLocation();

    const defaultCountry = resolveCountryFromLocale(site.defaultLocale, 'US');
    const pathCountry = getCountryFromPath(location.pathname, defaultCountry);
    const localeCountry = useMemo(
        () => resolveCountryFromLocale(language || site.defaultLocale, defaultCountry),
        [language, site.defaultLocale]
    );
    // Path country takes precedence when the shopper has navigated to a specific locale.
    const country = pathCountry !== localeCountry ? pathCountry : localeCountry;

    const fetcher = useScapiFetcher('eswCustom', 'getBmConfigs', {
        params: {
            query: {
                siteId: site.id,
                c_country: country,
            },
        },
    });

    const lastRequestKeyRef = useRef<string>('');

    useEffect(() => {
        const requestKey = `${location.pathname}${location.search}|${site.id}|${country}`;
        if (lastRequestKeyRef.current === requestKey) {
            return;
        }

        lastRequestKeyRef.current = requestKey;

        void fetcher.load();
    }, [country, fetcher, location.pathname, location.search, site.id]);

    useEffect(() => {
        if (!fetcher.success || typeof fetcher.data === 'undefined' || !(fetcher.data as Record<string, unknown>)?.eswBmConfigs) {
            return;
        }
        saveToLocalStorage(BM_CONFIGS_STORAGE_KEY, fetcher.data);

        // Dispatch a custom event so components can react immediately when BM
        // configs are saved. Keep the event dispatch here (hook-level) rather
        // than inside the generic saveToLocalStorage helper to avoid coupling.
        if (typeof window !== 'undefined') {
            try {
                window.dispatchEvent(new CustomEvent(ESW_BM_CONFIGS_UPDATED, { detail: fetcher.data }));
            } catch (e) {
                // ignore dispatch errors in restricted environments
            }
        }
    }, [fetcher.data]);

    return fetcher;
}

// Export a shared event name so subscribers do not hardcode the string.
export const ESW_BM_CONFIGS_UPDATED = 'esw:bm-configs-updated';
