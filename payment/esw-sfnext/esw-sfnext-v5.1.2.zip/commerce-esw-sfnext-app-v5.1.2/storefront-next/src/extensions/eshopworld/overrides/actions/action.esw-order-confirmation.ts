/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import type { ActionFunctionArgs } from 'react-router';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { loginGuestUser } from '@/middlewares/auth.server';

function getHeaders(request: Request, accessToken: string) {
    const headers = new Headers(request.headers);
    headers.set('Authorization', `Bearer ${accessToken}`);
    headers.set('Content-Type', 'application/json');
    headers.delete('Content-Length');
    headers.delete('Content-Encoding');
    return headers;
}

function getBody(request: Request) {
    return request.arrayBuffer();
}

export async function action({ request, context }: ActionFunctionArgs) {
    const body = await getBody(request);
    const config = getConfig(context);
    const { shortCode, organizationId } = config.commerce.api;
    const session = await loginGuestUser(context);
    if (!session?.access_token) {
        throw new Error('No SCAPI access token available');
    }
    const url = new URL(
        `https://${shortCode}.api.commercecloud.salesforce.com/custom/product/v1/organizations/${organizationId}/processEswOrderConfirmation`
    );
    url.searchParams.set('siteId', config.defaultSiteId);

    const response = await fetch(url, {
        method: 'POST',
        headers: getHeaders(request, session.access_token),
        body: JSON.stringify({ Body: new TextDecoder().decode(body) }),
    });

    const headers = new Headers(response.headers);
    headers.delete('Content-Encoding');
    headers.delete('Content-Length');

    return new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers,
    });
}

export const loader = action;
