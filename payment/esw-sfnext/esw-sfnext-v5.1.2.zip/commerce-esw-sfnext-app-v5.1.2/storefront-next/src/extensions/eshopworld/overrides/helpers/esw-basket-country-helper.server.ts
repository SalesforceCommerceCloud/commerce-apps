/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { siteContext } from '@salesforce/storefront-next-runtime/site-context';
import type { MiddlewareFunction, RouterContextProvider } from 'react-router';
import type { ShopperBasketsV2 } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { getBasket, updateBasketResource } from '@/middlewares/basket.server';

type Basket = ShopperBasketsV2.schemas['Basket'];

type EswBmConfigsResponse = {
    shopperPricingConfigs?: {
        retailerBaseCurrency?: string;
    };
};

type EswLocale = {
    countryCode?: string;
    isFixedPriceModel?: boolean;
};

type EswBasketRecalculation = {
    countryCode: string;
    currency: string;
};

/**
 * Returns the dynamic base price-book currency when a basket created in a
 * fixed-price country is opened in a configured dynamic-price country. The
 * dynamic-price flag comes from the storefront environment configuration and
 * the currency is read from the getBmConfigs SCAPI response.
 *
 * @param basket - Current shopper basket
 * @param context - Request context containing the active locale
 * @returns Configured base currency when the basket requires dynamic-price recalculation
 */
export async function getEswBasketRecalculation(
    basket: Basket,
    context: Readonly<RouterContextProvider>
): Promise<EswBasketRecalculation | undefined> {
    const basketCountry = (basket as Basket & { c_eswShopperCurrency?: string }).c_eswShopperCurrency;
    const site = context.get(siteContext)?.site;
    const activeLocale = context.get(siteContext)?.locale?.id;
    const activeCountry = activeLocale?.split(/[-_]/).pop()?.toUpperCase();
    const activeCountryConfig = (site?.supportedLocales as EswLocale[] | undefined)?.find(
        (locale) => locale.countryCode === activeCountry
    );

    if (
        !basketCountry ||
        !activeCountry ||
        basketCountry === activeCountry ||
        activeCountryConfig?.isFixedPriceModel !== false
    ) {
        return undefined;
    }

    const siteId = site?.id;
    if (!siteId) {
        return undefined;
    }

    const clients = createApiClients(context);
    const { data } = await clients.eswCustom.getBmConfigs({
        params: {
            query: {
                siteId,
                c_country: activeCountry,
            },
        },
    });
    const bmConfigs = data as unknown as EswBmConfigsResponse;
    const baseCurrency = bmConfigs.shopperPricingConfigs?.retailerBaseCurrency;

    return typeof baseCurrency === 'string' && baseCurrency
        ? { countryCode: activeCountry, currency: baseCurrency }
        : undefined;
}

/**
 * Refreshes a stale fixed-price basket only for cart requests after a shopper
 * switches to a configured dynamic-price country, so the cart receives the
 * localized dynamic prices before rendering.
 */
export const eswBasketCountryMiddleware: MiddlewareFunction<Response> = async ({ request, context }, next) => {
    if (!/\/cart(?:\.data)?$/.test(new URL(request.url).pathname)) {
        return next();
    }

    try {
        const basket = (await getBasket(context, { ensureBasket: 'read' })).current;
        const site = context.get(siteContext);
        const countryCode = site?.locale?.id.split(/[-_]/).pop()?.toUpperCase();
        const countryConfig = (site?.site.supportedLocales as EswLocale[] | undefined)?.find(
            (locale) => locale.countryCode === countryCode
        );
        const hasUnpricedItems = basket?.productItems?.some(
            (item) =>
                !item.bonusProductLineItem &&
                typeof item.basePrice === 'number' &&
                item.basePrice > 0 &&
                (typeof item.price !== 'number' || item.price === 0)
        );

        if (
            !basket?.basketId ||
            !countryCode ||
            countryConfig?.isFixedPriceModel !== false ||
            (basket.c_eswShopperCurrency === countryCode && !hasUnpricedItems)
        ) {
            return next();
        }

        const clients = createApiClients(context);
        for (const item of basket.productItems ?? []) {
            if (!item.itemId || typeof item.quantity !== 'number' || item.bonusProductLineItem) continue;

            const { data: updatedBasket } = await clients.shopperBasketsV2.updateItemInBasket({
                params: { path: { basketId: basket.basketId, itemId: item.itemId } },
                body: { quantity: item.quantity },
            });
            updateBasketResource(context, updatedBasket);
        }
    } catch (error) {
        getLogger(context).error('ESW basket country recalculation failed', {
            error,
        });
    }

    return next();
};
