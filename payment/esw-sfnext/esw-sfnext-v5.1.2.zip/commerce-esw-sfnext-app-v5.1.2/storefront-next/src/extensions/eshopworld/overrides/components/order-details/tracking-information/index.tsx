import type { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent } from '@/components/ui/card';
import type { EswOrder } from '@esw-overrides/components/order-details/types';

export interface TrackingInformationProps {
    order: EswOrder;
}

function isSafeTrackingUrl(value: string): boolean {
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && url.hostname.length > 0 && !url.username && !url.password;
    } catch {
        return false;
    }
}

export default function TrackingInformation({ order }: TrackingInformationProps): ReactElement | null {
    const { t: eswT } = useTranslation('extEsw');
    const { t: accountT } = useTranslation('account');
    const trackingNumber = order.c_eswPackageReference?.trim();
    const trackingUrl = order.c_eswTrackingURL?.trim();

    if (order.c_eswReceivedASN !== true || !trackingNumber || !trackingUrl || !isSafeTrackingUrl(trackingUrl)) {
        return null;
    }

    return (
        <div className="space-y-1.5" data-section="esw-tracking-information">
            <p className="text-xs font-semibold text-foreground">{eswT('orderDetails.trackingInformation.title')}</p>
            <Card className="rounded-none p-0 bg-card border border-border">
                <CardContent className="p-3 py-2 space-y-1 text-sm">
                    <p className="font-medium text-muted-foreground">{accountT('orders.trackingNumber')}</p>
                    <a
                        className="block break-all font-medium text-primary underline"
                        href={trackingUrl}
                        target="_blank"
                        rel="noopener noreferrer">
                        {trackingNumber}
                    </a>
                </CardContent>
            </Card>
        </div>
    );
}