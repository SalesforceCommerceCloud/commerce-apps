/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { render } from '@testing-library/react';
// eslint-disable-next-line import/no-namespace -- vi.spyOn requires namespace import
import * as ReactRouter from 'react-router';
import EswCheckoutComponent from './EswCheckoutComponent';
import {
    ESW_CLIENT_LAST_ORDER_ID_KEY,
    ESW_CLIENT_LAST_ORDER_TOKEN,
} from '../../hooks/use-abandonment-cart-on-page-load';

const { getConfig } = vi.hoisted(() => ({ getConfig: vi.fn(() => undefined) }));

vi.mock('../../helpers/esw-helpers', () => ({
    getEswConfigByKey: getConfig,
    getEswShopperCurrencyConfigByKey: getConfig,
}));

vi.mock('@/components/link', () => ({
    Link: ({ children, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>) => <a {...props}>{children}</a>,
}));

describe('EswCheckoutComponent order token storage', () => {
    const locationDescriptor = Object.getOwnPropertyDescriptor(window, 'location');

    beforeEach(() => {
        localStorage.clear();
        vi.spyOn(ReactRouter, 'useFetcher').mockReturnValue({
            state: 'idle',
            data: {
                success: true,
                orderNo: 'order-123',
                order: {
                    orderToken: 'secure-token',
                    c_eswPreOrderResponse: { redirectUrl: 'https://checkout.example.test' },
                },
            },
            submit: vi.fn(),
            load: vi.fn(),
        } as never);
        Object.defineProperty(window, 'location', {
            configurable: true,
            value: { href: '' },
        });
    });

    afterEach(() => {
        localStorage.clear();
        vi.restoreAllMocks();
        if (locationDescriptor) Object.defineProperty(window, 'location', locationDescriptor);
    });

    it('stores the returned order ID and token before redirecting to ESW', () => {
        render(<EswCheckoutComponent basketId="basket-123" hasInventoryIssues={false} checkoutLabel="Checkout" />);

        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_ID_KEY)).toBe('order-123');
        expect(localStorage.getItem(ESW_CLIENT_LAST_ORDER_TOKEN)).toBe('secure-token');
        expect(window.location.href).toBe('https://checkout.example.test');
    });
});
