/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { type ReactElement, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router';
import { useTranslation } from 'react-i18next';
import type { ShopperSearch } from '@/scapi';
import PriceRangeInput from '@/components/price-range-input';
import { formatCurrency } from '@/lib/currency';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import DefaultRefinement from '../../../../src/components/category-refinements/refine-default';
import type { RefinementProps } from '../../../../src/components/category-refinements/types';

function formatPriceLabel(range: string, fallbackLabel: string, locale: string, currency: string): string {
    const bounds = range.replace(/^\(|\)$/g, '').split('..');
    if (bounds.length !== 2 || bounds.some((bound) => bound !== '' && Number.isNaN(Number(bound)))) {
        return fallbackLabel;
    }

    const [min, max] = bounds;
    const formatBound = (bound: string) => (bound ? formatCurrency(Number(bound), locale, currency) : '');
    const formattedMin = formatBound(min);
    const formattedMax = formatBound(max);

    if (!formattedMin) return formattedMax ? `Up to ${formattedMax}` : fallbackLabel;
    if (!formattedMax) return `${formattedMin}+`;
    return `${formattedMin} - ${formattedMax}`;
}

export default function RefinePrice({
    values,
    attributeId,
    isFilterSelected,
    toggleFilter,
    result,
}: RefinementProps & {
    result?: ShopperSearch.schemas['ProductSearchResult'];
}): ReactElement {
    const location = useLocation();
    const { i18n } = useTranslation();
    const { currency } = useSite();
    const [minPrice, setMinPrice] = useState('');
    const [maxPrice, setMaxPrice] = useState('');

    useEffect(() => {
        const params = new URLSearchParams(location.search);
        const refines = params.getAll('refine');
        const priceRefine = refines.find((refine) => refine.startsWith('price='));
        if (priceRefine) {
            const match = priceRefine.match(/price=\(([^.]*)\.\.([^)]*)\)/);
            if (match) {
                setMinPrice(match[1] || '');
                setMaxPrice(match[2] || '');
            }
        } else {
            setMinPrice('');
            setMaxPrice('');
        }
    }, [location.search]);

    const { minAllowed, maxAllowed } = useMemo(() => {
        if (!result?.hits?.length) return { minAllowed: undefined, maxAllowed: undefined };
        const prices = result.hits
            .map((product) => product.price)
            .filter((price): price is number => typeof price === 'number' && price > 0);
        if (prices.length === 0) return { minAllowed: undefined, maxAllowed: undefined };
        return {
            minAllowed: Math.min(...prices),
            maxAllowed: Math.max(...prices),
        };
    }, [result]);

    const handlePriceChange = (newMinPrice: string, newMaxPrice: string) => {
        setMinPrice(newMinPrice);
        setMaxPrice(newMaxPrice);
    };

    const handlePriceApply = () => {
        if (minPrice || maxPrice) {
            const minVal = minPrice || '0';
            const maxVal = maxPrice || '';
            toggleFilter(attributeId, `(${minVal}..${maxVal})`);
        }
    };

    return (
        <div className="flex flex-col gap-4 mt-2">
            <PriceRangeInput
                minPrice={minPrice}
                maxPrice={maxPrice}
                onChange={handlePriceChange}
                onApply={handlePriceApply}
                minAllowed={minAllowed}
                maxAllowed={maxAllowed}
                showValidationErrors={true}
            />
            {values.length > 0 && (
                <DefaultRefinement
                    values={values.map((value) => ({
                        ...value,
                        label: value.label
                            ? formatPriceLabel(value.value, value.label, i18n.language, currency)
                            : value.label,
                    }))}
                    attributeId={attributeId}
                    isFilterSelected={isFilterSelected}
                    toggleFilter={toggleFilter}
                />
            )}
        </div>
    );
}
