/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { convertPrice } from './esw-calculation-helper';

const { getConfig } = vi.hoisted(() => ({ getConfig: vi.fn() }));

vi.mock('./esw-helpers', () => ({
    getEswShopperCurrencyConfigByKey: getConfig,
}));

describe('convertPrice', () => {
    beforeEach(() => {
        const price = document.createElement('span');
        price.className = 'esw-price';
        price.textContent = '$100.00';
        document.body.replaceChildren(price);
        getConfig.mockImplementation((key: string) => {
            const values: Record<string, unknown> = {
                symbol: 'EUR ',
                isFixedPriceModel: false,
                fxRate: '0.9',
                countryAdjustments: {
                    retailerAdjustments: { priceUpliftPercentage: 10 },
                    estimatedRates: { dutyPercentage: 0, taxPercentage: 20 },
                },
                roundingModel: { direction: 'up', model: 'multiple5.none', currencyExponent: 2 },
            };
            return values[key];
        });
    });

    it('applies country adjustments, FX conversion, and configured rounding to calculated prices', () => {
        const price = document.querySelector('.esw-price') as HTMLSpanElement;

        convertPrice();

        expect(price.textContent).toBe('EUR 120.80');
        expect(price).toHaveClass('esw-price-converted');
    });

    it('preserves the retailer amount for fixed-price countries without applying FX or adjustments', () => {
        getConfig.mockImplementation(
            (key: string) =>
                ({
                    symbol: 'EUR ',
                    isFixedPriceModel: true,
                    fxRate: '0.5',
                    countryAdjustments: {
                        retailerAdjustments: { priceUpliftPercentage: 50 },
                        estimatedRates: { dutyPercentage: 25, taxPercentage: 20 },
                    },
                })[key as 'symbol' | 'isFixedPriceModel' | 'fxRate' | 'countryAdjustments']
        );
        const price = document.querySelector('.esw-price') as HTMLSpanElement;

        convertPrice();

        expect(price.textContent).toBe('EUR 100.00');
        expect(price).toHaveClass('esw-price-converted');
    });

    it('leaves calculated prices unchanged when no FX rate is available', () => {
        getConfig.mockImplementation(
            (key: string) =>
                ({
                    symbol: 'EUR ',
                    isFixedPriceModel: false,
                    fxRate: undefined,
                })[key as 'symbol' | 'isFixedPriceModel' | 'fxRate']
        );
        const price = document.querySelector('.esw-price') as HTMLSpanElement;

        convertPrice();

        expect(price.textContent).toBe('$100.00');
        expect(price).not.toHaveClass('esw-price-converted');
    });
});
