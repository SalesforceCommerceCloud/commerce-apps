import type { MiddlewareFunction } from 'react-router';
import { registerEswCountryMiddleware } from './esw-country-query-middleware.server';

/**
 * Registers an ESW SCAPI interceptor that adds optional x-esw-country header
 * to outgoing requests when the country can be resolved from site locale.
 */
export const eswCountryHttpInterceptorMiddleware: MiddlewareFunction<Response> = async ({ context }, next) => {
    registerEswCountryMiddleware(context);
    return next();
};
