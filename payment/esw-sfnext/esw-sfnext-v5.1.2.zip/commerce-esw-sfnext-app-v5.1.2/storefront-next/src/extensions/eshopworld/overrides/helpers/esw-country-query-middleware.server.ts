import { SLAS_AUTH_ENDPOINTS, type Middleware } from '@salesforce/storefront-next-runtime/scapi';
import { siteContext } from '@salesforce/storefront-next-runtime/site-context';
import type { RouterContextProvider } from 'react-router';
// IMPORTANT: Import this from your local lib, NOT the salesforce runtime
import { getScapiMiddlewareRegistry } from '../../src/lib/scapi-middleware';

const ESW_COUNTRY_HEADER = 'c_country';
type ContextLike = Pick<RouterContextProvider, 'get' | 'set'>;

function resolveEswCountryCode(context: ContextLike): string | null {
    const siteCtx = context.get(siteContext);
    const localeId = siteCtx?.locale?.id;
    if (!localeId) return null;

    const localeParts = localeId.split(/[-_]/);
    const region = localeParts.length > 1 ? localeParts[localeParts.length - 1] : '';
    return region ? region.toUpperCase() : null;
}

export function registerEswCountryMiddleware(context: ContextLike) {
    const registry = getScapiMiddlewareRegistry(context as RouterContextProvider | Readonly<RouterContextProvider>);

    if (!registry || typeof registry.register !== 'function') {
        return;
    }

    registry.register('esw-country-header', {
        factory: (ctx, _clients): Middleware | null => {
            const countryCode = resolveEswCountryCode(ctx);
            if (!countryCode) return null;

            return {
                onRequest({ request }) {
                    const url = new URL(request.url);
                    const isSlas = SLAS_AUTH_ENDPOINTS.some((path) => url.pathname.includes(path));

                    if (isSlas || request.headers.has(ESW_COUNTRY_HEADER)) {
                        return request;
                    }

                    request.headers.set(ESW_COUNTRY_HEADER, countryCode);
                    return request;
                },
            };
        },
    });
}
