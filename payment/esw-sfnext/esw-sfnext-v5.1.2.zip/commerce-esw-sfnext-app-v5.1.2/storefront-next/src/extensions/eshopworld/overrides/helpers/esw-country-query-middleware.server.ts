/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { SLAS_AUTH_ENDPOINTS, type Middleware } from '@salesforce/storefront-next-runtime/scapi';
import { siteContext } from '@salesforce/storefront-next-runtime/site-context';
import type { RouterContextProvider } from 'react-router';
// IMPORTANT: Import this from your local lib, NOT the salesforce runtime
import { getScapiMiddlewareRegistry } from '../../src/lib/scapi-middleware';

const ESW_COUNTRY_HEADER = 'c_country';
type ContextLike = Pick<RouterContextProvider, 'get' | 'set'>;

function resolveEswCountryCode(context: ContextLike): string | null {
    const siteCtx = context.get(siteContext);
    const localeId = siteCtx?.locale?.id;
    if (!localeId) return null;

    const localeParts = localeId.split(/[-_]/);
    const region = localeParts.length > 1 ? localeParts[localeParts.length - 1] : '';
    return region ? region.toUpperCase() : null;
}

export function registerEswCountryMiddleware(context: ContextLike) {
    const registry = getScapiMiddlewareRegistry(context as RouterContextProvider | Readonly<RouterContextProvider>);

    if (!registry || typeof registry.register !== 'function') {
        return;
    }

    registry.register('esw-country-header', {
        factory: (ctx, _clients): Middleware | null => {
            const countryCode = resolveEswCountryCode(ctx);
            if (!countryCode) return null;

            return {
                onRequest({ request }) {
                    const url = new URL(request.url);
                    const isSlas = SLAS_AUTH_ENDPOINTS.some((path) => url.pathname.includes(path));

                    if (isSlas || request.headers.has(ESW_COUNTRY_HEADER)) {
                        return request;
                    }

                    request.headers.set(ESW_COUNTRY_HEADER, countryCode);
                    return request;
                },
            };
        },
    });
}
