/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
export interface EswLocale {
    id: string;
    countryCode: string;
    countryName: string;
    preferredCurrency: string;
    supportedLocales: string[];
}

const eswLocalesBySite: Record<string, EswLocale[]> = (() => {
    const raw = import.meta.env.PUBLIC__app__commerce__sites;
    if (!raw) return {};

    try {
        const sites = JSON.parse(raw) as { id: string; supportedLocales: Partial<EswLocale>[] }[];
        if (!Array.isArray(sites)) return {};

        return Object.fromEntries(
            sites.map((site) => [
                site.id,
                (site.supportedLocales ?? []).filter(
                    (locale): locale is EswLocale =>
                        typeof locale.id === 'string' &&
                        typeof locale.countryCode === 'string' &&
                        typeof locale.countryName === 'string' &&
                        typeof locale.preferredCurrency === 'string' &&
                        Array.isArray(locale.supportedLocales) &&
                        locale.supportedLocales.every((supportedLocale) => typeof supportedLocale === 'string')
                ),
            ])
        );
    } catch {
        return {};
    }
})();

export function getEswLocalesForSite(siteId: string): EswLocale[] {
    return eswLocalesBySite[siteId] ?? [];
}
