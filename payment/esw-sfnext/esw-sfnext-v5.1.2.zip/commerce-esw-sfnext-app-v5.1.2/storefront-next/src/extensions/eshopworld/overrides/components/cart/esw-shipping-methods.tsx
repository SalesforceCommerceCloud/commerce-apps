import { useFetcher } from 'react-router';
import { resourceRoutes } from '@/route-paths';

export default function EswShippingMethods({
    basket,
}: EswShippingMethodsProps) {
    const fetcher = useFetcher();

    const shippingMethods =
        basket.c_available_shipping_methods ?? [];

    const selectedShippingMethod =
        basket.shipments?.[0]?.shippingMethod?.id ?? '';

    const handleShippingMethodChange = (
        event: React.ChangeEvent<HTMLSelectElement>
    ) => {
        const shippingMethodId = event.target.value;

        fetcher.submit(
            {
                shippingMethodId,
            },
            {
                method: 'post',
                action: resourceRoutes.CartShippingMethod,
            }
        );
    };

    if (shippingMethods.length <= 1) {
        return null;
    }

    return (
        <div className="w-full space-y-4">
            <label
                htmlFor="shipping-method"
                className="block text-sm font-semibold"
            >
                Shipping Methods
            </label>

            <select
                id="shipping-method"
                value={selectedShippingMethod}
                onChange={handleShippingMethodChange}
                disabled={fetcher.state !== 'idle'}
                className="w-full rounded-md border bg-white px-4 py-3"
            >
                {shippingMethods.map((method) => (
                    <option
                        key={method.id}
                        value={method.id}
                    >
                        {method.name}
                        {method.estimatedArrivalTime
                            ? ` (${method.estimatedArrivalTime})`
                            : ''}
                    </option>
                ))}
            </select>
        </div>
    );
}