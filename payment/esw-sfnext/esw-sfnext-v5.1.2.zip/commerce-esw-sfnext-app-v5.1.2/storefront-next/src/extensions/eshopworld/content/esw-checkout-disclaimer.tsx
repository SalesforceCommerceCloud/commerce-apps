import type { ReactElement } from 'react';
import EswCheckoutDisclaimer from '@esw-overrides/components/esw-checkout-disclaimer'


export default function EswCheckoutDisclaimerTarget(): ReactElement | null {
    return <EswCheckoutDisclaimer />;
}
