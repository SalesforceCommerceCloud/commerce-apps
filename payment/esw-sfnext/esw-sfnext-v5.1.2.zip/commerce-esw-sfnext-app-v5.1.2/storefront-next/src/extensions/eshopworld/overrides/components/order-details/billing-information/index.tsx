import type { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import ShippingAddressDisplay, {
    type ShippingAddressDisplayProps,
} from '@/components/checkout/components/shipping-address-display';
import { Card, CardContent } from '@/components/ui/card';
import { isAddressEmpty } from '@/lib/address/address-utils';

export interface BillingInformationProps {
    billingAddress: ShippingAddressDisplayProps['address'];
}

export default function BillingInformation({
    billingAddress,
}: BillingInformationProps): ReactElement | null {
    const { t } = useTranslation('checkout');

    if (isAddressEmpty(billingAddress)) {
        return null;
    }

    return (
        <Card className="rounded-none min-h-[4rem] p-0 bg-card" data-card="billing-address">
            <CardContent className="p-3">
                <p className="text-xs font-semibold text-foreground">
                    {t('confirmation.fields.billingAddress')}
                </p>
                <div className="mt-2">
                    <ShippingAddressDisplay address={billingAddress} />
                </div>
            </CardContent>
        </Card>
    );
}