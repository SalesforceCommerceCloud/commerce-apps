/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { type ReactElement, useEffect, useId, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useFetcher, useLocation } from 'react-router';
import { useConfig } from '@salesforce/storefront-next-runtime/config';
import { NativeSelect } from '@/components/ui/native-select';
import { useToast } from '@/components/toast';
import { buildUrl, resolvePrefix, stripPathPrefix, useSite } from '@salesforce/storefront-next-runtime/site-context';
import { resourceRoutes } from '@/route-paths';
import { useCurrentSiteAndLocaleRef } from '@/hooks/use-current-site-and-locale-ref';
import { getEswLocalesForSite } from '@esw-overrides/helpers/esw-locales';

export default function CurrencySwitcher(): ReactElement {
    const id = useId();
    const { t } = useTranslation('currencySwitcher');
    const fetcher = useFetcher();
    const config = useConfig();
    const { site: currentSite, locale: currentLocale } = useSite();
    const { addToast } = useToast();
    const location = useLocation();
    const { siteRef, localeRef } = useCurrentSiteAndLocaleRef();

    const [pendingPathname, setPendingPathname] = useState<string>();

    const eswLocales = getEswLocalesForSite(currentSite.id);
    const currentCountryCode = eswLocales.find((l) => l.id === currentLocale.id)?.countryCode ?? '';

    useEffect(() => {
        if (fetcher.state === 'idle' && fetcher.data?.success && pendingPathname) {
            window.location.href = pendingPathname;
        }
    }, [fetcher.state, fetcher.data, pendingPathname]);

    const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedCountryCode = e.target.value;
        const selectedLocale = eswLocales.find((l) => l.countryCode === selectedCountryCode);

        if (!selectedLocale) {
            addToast(t('validation.unsupportedCurrency'), 'error');
            return;
        }

        const newLocaleRef = config.localeAliasMap?.[selectedLocale.id] ?? selectedLocale.id;

        const currentPrefix = config.url?.prefix
            ? resolvePrefix({ prefix: config.url.prefix, params: { siteId: siteRef, localeId: localeRef } })
            : '';

        const barePath = stripPathPrefix({ pathname: location.pathname, prefix: currentPrefix }) || '/';

        setPendingPathname(
            buildUrl({ to: barePath, urlConfig: config.url, params: { siteId: siteRef, localeId: newLocaleRef } })
        );

        const formData = new FormData();
        formData.append('type', 'currency');
        formData.append(
            'payload',
            JSON.stringify({ currency: selectedLocale.preferredCurrency, countryCode: selectedLocale.countryCode })
        );

        void fetcher.submit(formData, { method: 'POST', action: resourceRoutes.setSiteContext });
    };

    return (
        <div>
            <NativeSelect id={id} onChange={handleCountryChange} aria-label={t('ariaLabel')} value={currentCountryCode}>
                {eswLocales.map(({ countryCode, countryName }) => (
                    <option key={countryCode} value={countryCode}>
                        {countryName}
                    </option>
                ))}
            </NativeSelect>
        </div>
    );
}
