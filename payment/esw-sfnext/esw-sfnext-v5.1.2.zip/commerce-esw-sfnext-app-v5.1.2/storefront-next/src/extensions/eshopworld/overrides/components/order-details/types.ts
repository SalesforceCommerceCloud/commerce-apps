import type { ShopperOrders } from '@/scapi';

export type EswOrder = ShopperOrders.schemas['Order'] & {
    c_eswPackageReference?: string;
    c_eswTrackingURL?: string;
    c_eswReceivedASN?: boolean;
};

export type PaymentInstrument = NonNullable<ShopperOrders.schemas['Order']['paymentInstruments']>[number] & {
    c_eswPaymentMethodCardBrand?: string;
};