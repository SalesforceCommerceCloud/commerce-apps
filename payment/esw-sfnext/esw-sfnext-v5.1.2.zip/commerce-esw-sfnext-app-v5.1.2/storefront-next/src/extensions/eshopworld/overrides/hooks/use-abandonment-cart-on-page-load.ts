/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { useEffect, useRef, useState } from 'react';
import { useFetcher } from 'react-router';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useScapiFetcher } from '@/hooks/use-scapi-fetcher';
import { resourceRoutes } from '@/route-paths';

export const ESW_CLIENT_LAST_ORDER_ID_KEY = 'esw.clientLastOrderId';
export const ESW_CLIENT_LAST_ORDER_TOKEN = 'esw.clientLastOrderToken';

interface AbandonmentCartResponse {
    orderLineItems: { products: Array<{ productId: string; quantity: number }> };
    basketItems: { products: Array<{ lineItemId: string }> };
    couponCodes: Array<{ code: string }>;
    removeLineItems: boolean;
}

/**
 * Calls eswCustom.getAbandonmentCart on initial load or browser history restoration when a last order ID is stored.
 * Clears the stored order ID after a successful response.
 */
export function useAbandonmentCartOnPageLoad() {
    const { site } = useSite();
    const [lastOrderId, setLastOrderId] = useState('');
    const [orderToken, setOrderToken] = useState('');
    const [pendingCouponCodes, setPendingCouponCodes] = useState<Array<{ code: string }> | null>(null);
    const lastRequestKeyRef = useRef<string>('');
    const cartFetcher = useFetcher();
    const couponFetcher = useFetcher();

    const fetcher = useScapiFetcher('eswCustom', 'getAbandonmentCart', {
        params: {
            query: {
                siteId: site.id,
                c_eswClientLastOrderId: lastOrderId,
                c_eswOrderToken: orderToken,
            },
        },
    });

    useEffect(() => {
        const syncLastOrderId = () => {
            const storedOrderId = localStorage.getItem(ESW_CLIENT_LAST_ORDER_ID_KEY) ?? '';
            const storedOrderToken = localStorage.getItem(ESW_CLIENT_LAST_ORDER_TOKEN) ?? '';
            if (!storedOrderId || !storedOrderToken) {
                localStorage.removeItem(ESW_CLIENT_LAST_ORDER_ID_KEY);
                localStorage.removeItem(ESW_CLIENT_LAST_ORDER_TOKEN);
            }
            setLastOrderId(storedOrderId && storedOrderToken ? storedOrderId : '');
            setOrderToken(storedOrderId && storedOrderToken ? storedOrderToken : '');
        };

        const handlePageShow = (event: PageTransitionEvent) => {
            if (!event.persisted) {
                return;
            }

            syncLastOrderId();
        };

        syncLastOrderId();
        window.addEventListener('pageshow', handlePageShow);

        return () => {
            window.removeEventListener('pageshow', handlePageShow);
        };
    }, []);

    useEffect(() => {
        if (!lastOrderId) {
            return;
        }

        const requestKey = `${site.id}|${lastOrderId}|${orderToken}`;
        if (lastRequestKeyRef.current === requestKey) {
            return;
        }

        lastRequestKeyRef.current = requestKey;

        void fetcher.load();
        // fetcher is a new object every render; lastOrderId and site.id drive this
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [lastOrderId, orderToken, site.id]);

    useEffect(() => {
        if (typeof fetcher.data === 'undefined') {
            return;
        }

        lastRequestKeyRef.current = '';
        setLastOrderId('');
        setOrderToken('');

        const data = fetcher.data as AbandonmentCartResponse | null;
        if (!data) {
            return;
        }

        if (data.removeLineItems) {
            data.basketItems.products.forEach((item) => {
                void cartFetcher.submit(
                    { itemId: item.lineItemId },
                    { method: 'POST', action: resourceRoutes.cartItemRemove }
                );
            });
            // Order was already placed — clear the key immediately, no cart add needed.
            localStorage.removeItem(ESW_CLIENT_LAST_ORDER_ID_KEY);
            localStorage.removeItem(ESW_CLIENT_LAST_ORDER_TOKEN);
        } else {
            if (data.orderLineItems.products.length > 0) {
                void cartFetcher.submit(
                    { productItems: JSON.stringify(data.orderLineItems.products) },
                    { method: 'POST', action: resourceRoutes.cartSetAdd }
                );
                // Defer coupon application until the restored items are in the basket so promotions calculate correctly.
                setPendingCouponCodes(data.couponCodes);
            } else {
                data.couponCodes.forEach((coupon) => {
                    void couponFetcher.submit(
                        { promoCode: coupon.code },
                        { method: 'POST', action: resourceRoutes.promoCodeAdd }
                    );
                });
            }
        }
        // cartFetcher is a new object every render; fetcher.data drives this
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [fetcher.data]);

    useEffect(() => {
        if (!pendingCouponCodes || cartFetcher.state !== 'idle' || !cartFetcher.data) {
            return;
        }

        if ((cartFetcher.data as { success?: boolean }).success) {
            pendingCouponCodes.forEach((coupon) => {
                void couponFetcher.submit(
                    { promoCode: coupon.code },
                    { method: 'POST', action: resourceRoutes.promoCodeAdd }
                );
            });
        } else {
            // Item restore failed — drop the stored order id so the flow doesn't retry indefinitely.
            localStorage.removeItem(ESW_CLIENT_LAST_ORDER_ID_KEY);
            localStorage.removeItem(ESW_CLIENT_LAST_ORDER_TOKEN);
        }
        setPendingCouponCodes(null);
        // couponFetcher is a new object every render; cartFetcher state/data drive this
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [cartFetcher.state, cartFetcher.data, pendingCouponCodes]);

    useEffect(() => {
        if (fetcher.state !== 'idle' || !fetcher.errors?.length) {
            return;
        }

        lastRequestKeyRef.current = '';
        setLastOrderId('');
        setOrderToken('');
    }, [fetcher.state, fetcher.errors]);

    useEffect(() => {
        if (cartFetcher.state !== 'idle' || !cartFetcher.data) {
            return;
        }
        if ((cartFetcher.data as { success?: boolean }).success) {
            localStorage.removeItem(ESW_CLIENT_LAST_ORDER_ID_KEY);
            localStorage.removeItem(ESW_CLIENT_LAST_ORDER_TOKEN);
        }
    }, [cartFetcher.state, cartFetcher.data]);

    const isRestoringBasket =
        Boolean(lastOrderId) ||
        fetcher.state !== 'idle' ||
        cartFetcher.state !== 'idle' ||
        couponFetcher.state !== 'idle';

    return { fetcher, isRestoringBasket };
}
