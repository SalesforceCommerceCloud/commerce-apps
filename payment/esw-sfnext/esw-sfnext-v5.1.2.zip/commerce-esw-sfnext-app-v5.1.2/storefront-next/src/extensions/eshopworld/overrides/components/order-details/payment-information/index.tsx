import type { ReactElement } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent } from '@/components/ui/card';
import { formatCurrency } from '@/lib/currency';
import type { PaymentInstrument } from '@esw-overrides/components/order-details/types';

type EswPaymentInstrument = PaymentInstrument & {
    amount: number;
    c_eswPaymentMethodCardBrand: string;
};

function isEswPaymentInstrument(paymentInstrument: PaymentInstrument): paymentInstrument is EswPaymentInstrument {
    return Boolean(paymentInstrument.c_eswPaymentMethodCardBrand?.trim()) && paymentInstrument.amount != null;
}

type PaymentDisplay = {
    id: string;
    label: string;
    amount?: number;
};

export interface PaymentInformationProps {
    paymentInstruments?: PaymentInstrument[];
    currency?: string;
}

export default function PaymentInformation({
    paymentInstruments,
    currency,
}: PaymentInformationProps): ReactElement | null {
    const { t: checkoutT, i18n } = useTranslation('checkout');
    const { t: accountT } = useTranslation('account');
    const paymentDisplays: PaymentDisplay[] =
        paymentInstruments?.flatMap<PaymentDisplay>((paymentInstrument, index) => {
            if (isEswPaymentInstrument(paymentInstrument)) {
                return [{
                    id: paymentInstrument.paymentInstrumentId ?? `${paymentInstrument.c_eswPaymentMethodCardBrand}-${index}`,
                    label: paymentInstrument.c_eswPaymentMethodCardBrand,
                    amount: paymentInstrument.amount,
                }];
            }
            const card = paymentInstrument.paymentCard;
            if (!card?.numberLastDigits) return [];
            return [{
                id: paymentInstrument.paymentInstrumentId ?? `payment-${index}`,
                label: accountT('orders.paymentMethodEndingIn', {
                    cardType: card.cardType ?? 'Card',
                    lastDigits: card.numberLastDigits,
                }),
            }];
        }) ?? [];

    if (!paymentDisplays.length) {
        return null;
    }

    return (
        <div className="space-y-1.5" data-section="esw-payment-information">
            <p className="text-xs font-semibold text-foreground">{checkoutT('confirmation.sections.paymentDetails')}</p>
            {paymentDisplays.map((paymentDisplay) => (
                <Card
                    key={paymentDisplay.id}
                    className="rounded-none p-0 bg-card border border-border">
                    <CardContent className="p-3 py-2 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <span className="font-medium text-muted-foreground">{paymentDisplay.label}</span>
                            {paymentDisplay.amount != null && currency != null && (
                                <span className="font-medium text-foreground">
                                    {formatCurrency(paymentDisplay.amount, i18n.language, currency)}
                                </span>
                            )}
                        </div>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}
