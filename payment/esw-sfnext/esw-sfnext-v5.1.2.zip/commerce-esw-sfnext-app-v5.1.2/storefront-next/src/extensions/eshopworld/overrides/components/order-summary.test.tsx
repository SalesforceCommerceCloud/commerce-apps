/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { AllProvidersWrapper } from '@/test-utils/context-provider';
import { createMemoryRouter, RouterProvider } from 'react-router';
import type { ShopperBasketsV2 } from '@/scapi';
import OrderSummary from './order-summary';

vi.mock('@/lib/currency', () => ({
    formatCurrency: (amount: number) => `$${amount.toFixed(2)}`,
}));

vi.mock('@/components/product-items-list', () => ({ default: () => null }));
vi.mock('@/components/promo-code-form', () => ({ default: () => null }));
vi.mock('./cart/esw-shipping-methods', () => ({ default: () => null }));
vi.mock('./esw/EswCheckoutComponent', () => ({ default: () => null }));
vi.mock('../helpers/esw-helpers', () => ({ getEswConfigByKey: () => false }));

function renderOrderSummary(basket: ShopperBasketsV2.schemas['Basket']) {
    const router = createMemoryRouter(
        [
            {
                path: '*',
                element: (
                    <AllProvidersWrapper>
                        <OrderSummary basket={basket} showCartItems={false} showTotal={false} />
                    </AllProvidersWrapper>
                ),
            },
        ],
        { initialEntries: ['/'] }
    );
    return render(<RouterProvider router={router} />);
}

describe('ESW promotion itemText rendering', () => {
    beforeEach(() => {
        localStorage.clear();
    });

    afterEach(() => {
        localStorage.clear();
    });

    it('renders allowed markup while stripping executable tags and attributes', async () => {
        const basket = {
            basketId: 'basket-123',
            productSubTotal: 100,
            orderTotal: 100,
            orderPriceAdjustments: [
                {
                    priceAdjustmentId: 'adjustment-1',
                    itemText:
                        '<strong>Sale</strong><img src="https://example.com/image.png" onerror="alert(1)"><script>alert(2)</script><a href="javascript:alert(3)">details</a>',
                    price: -10,
                },
            ],
        } as ShopperBasketsV2.schemas['Basket'];
        const { container } = renderOrderSummary(basket);

        expect(await screen.findByText('Sale')).toBeInTheDocument();
        await waitFor(() => expect(container.querySelector('strong')).toBeInTheDocument());
        expect(container.querySelector('script')).toBeNull();
        expect(container.querySelector('img')?.hasAttribute('onerror')).toBe(false);
        expect(container.querySelector('a')?.hasAttribute('href')).toBe(false);
        expect(screen.getByText('details')).toBeInTheDocument();
    });
});
