/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { type ReactElement } from 'react';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import BaseLocaleSwitcher from '../../../src/components/locale-switcher';
import { getEswLocalesForSite } from '@esw-overrides/helpers/esw-locales';

export default function LocaleSwitcher(): ReactElement {
    const { site, locale } = useSite();
    const country = getEswLocalesForSite(site.id).find(
        (configuredLocale) => configuredLocale.id === locale.id || configuredLocale.supportedLocales.includes(locale.id)
    );

    return <BaseLocaleSwitcher supportedLocales={country?.supportedLocales} />;
}
