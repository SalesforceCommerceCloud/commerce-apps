import type { ReactElement } from 'react';
import HtmlFragment from '@/components/html-fragment';
import useEswCartDisclaimer from '../../hooks/use-esw-cart-disclaimer';

export default function EswCheckoutDisclaimer(): ReactElement | null {
    const message = useEswCartDisclaimer();

    if (typeof message !== 'string' || !message.trim()) return null;

    return (
        <div data-testid="esw-checkout-disclaimer" className="mt-3 text-sm">
            <HtmlFragment content={message} contentType="plain-text" />
        </div>
    );
}
