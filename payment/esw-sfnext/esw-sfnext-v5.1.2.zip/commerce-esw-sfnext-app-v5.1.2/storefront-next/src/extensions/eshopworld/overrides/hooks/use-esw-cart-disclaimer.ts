import { useEffect, useState } from 'react';
import { getEswConfigByKey } from '../helpers/esw-helpers';
import { ESW_BM_CONFIGS_UPDATED } from './use-bm-configs-on-page-load';

/**
 * Hook that provides the current ESW checkout disclaimer message and reacts
 * to BM config updates dispatched via the ESW_BM_CONFIGS_UPDATED event.
 */
export default function useEswCartDisclaimer(): string | undefined {
    const [message, setMessage] = useState<string | undefined>(() => {
        try {
            return getEswConfigByKey('eswCheckoutDisclaimerMessage');
        } catch {
            return undefined;
        }
    });

    useEffect(() => {
        function handler(ev: any) {
            const detail = ev?.detail;
            const newVal = detail?.eswBmConfigs?.eswCheckoutDisclaimerMessage;

            if (typeof newVal === 'undefined') {
                // Fallback to reading from storage if event did not include detail
                setMessage(getEswConfigByKey('eswCheckoutDisclaimerMessage'));
            } else {
                setMessage(newVal);
            }
        }

        if (typeof window === 'undefined') return;

        window.addEventListener(ESW_BM_CONFIGS_UPDATED, handler);
        return () => window.removeEventListener(ESW_BM_CONFIGS_UPDATED, handler);
    }, []);

    return message;
}
