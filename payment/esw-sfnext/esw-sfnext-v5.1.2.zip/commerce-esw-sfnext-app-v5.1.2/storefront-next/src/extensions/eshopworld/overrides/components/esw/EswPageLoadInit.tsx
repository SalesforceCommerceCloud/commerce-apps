/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { useBmConfigsOnPageLoad } from '../../hooks/use-bm-configs-on-page-load';
import { useAbandonmentCartOnPageLoad } from '../../hooks/use-abandonment-cart-on-page-load';
import { useTranslation } from 'react-i18next';
import { useMatches } from 'react-router';
import { useEffect } from 'react';
import { useMiniCart } from '@/providers/basket';
import InventoryCheckFailureToast from './inventory-check-failure-toast';

export default function EswPageLoadInit() {
    const { t } = useTranslation('miniCart');
    const matches = useMatches();
    const { setMiniCartOpen } = useMiniCart();
    useBmConfigsOnPageLoad();
    const { isRestoringBasket } = useAbandonmentCartOnPageLoad();
    const isCartPage = matches.some((match) => match.id === 'routes/_app.cart');

    useEffect(() => {
        if (isRestoringBasket) {
            setMiniCartOpen(false);
        }
    }, [isRestoringBasket, setMiniCartOpen]);

    return (
        <>
            <InventoryCheckFailureToast />
            {isCartPage && isRestoringBasket && (
                <div className="bg-foreground/95 fixed inset-0 z-[9999]" role="status" aria-live="polite">
                    <div className="flex h-full w-full items-center justify-center">
                        <div className="flex flex-col items-center gap-4">
                            <div className="border-background/30 border-t-background h-16 w-16 animate-spin rounded-full border-4" />
                            <p className="text-background text-sm font-medium">{t('loading')}</p>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
