'use strict';

const REDACTED = '[REDACTED]';

/**
 * Identifies personal fields and credentials, including metadata entry names.
 * @param {string} name - Field or metadata name
 * @returns {boolean} Whether the value must be masked
 */
function isSensitiveField(name) {
    const normalized = String(name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    return /token|authorization|password|secret|credential|apikey|base64encodedauth|address|street|postal|postcode|zipcode|email|telephone|phone|mobile|dateofbirth|birthdate|nationalid|passport|taxid|vatnumber|identitydocument|cardnumber|cvv|cvc|iban|bankaccount/.test(normalized)
        || /((first|last|middle|full|given|family|shopper|customer|recipient|contact|company|user)name|nickname)$/.test(normalized)
        || /^(city|town|county|state|statecode|province|region|pobox|postbox|dob|ip|message|errormessage|descriptionoferror|dwsid|registeredprofileid|customernumber)$/.test(normalized)
        || /^(redirect|checkout|recovery|payment|orderconfirmation)(url|uri)$/.test(normalized);
}

/**
 * Serializes selectively masked JSON without changing service data.
 * @param {*} message - JSON string or object to log
 * @returns {string} Sanitized JSON, or a marker for unsafe/unparseable input
 */
function sanitizeLogMessage(message) {
    try {
        const payload = typeof message === 'string' ? JSON.parse(message) : message;
        if (payload === null || typeof payload !== 'object' || Array.isArray(payload)) {
            return REDACTED;
        }
        const metadataOwners = [];
        const shopperCheckoutExperienceValues = [];
        const retailerCheckoutExperiences = [];
        const retailerMetadataItems = [];
        return JSON.stringify(payload, function (key, value) {
            // Rhino can pass numeric array indexes to the replacer.
            const fieldName = String(key);
            const metadataName = this && (this.name || this.Name);
            const isShopperCheckoutExperience = shopperCheckoutExperienceValues.indexOf(this) !== -1;
            const isOrderConfirmationUriTestOnly = String(metadataName || '').toLowerCase().replace(/[^a-z0-9]/g, '') === 'orderconfirmationuritestonly';
            if (fieldName.toLowerCase() === 'shoppercheckoutexperience' && value && typeof value === 'object') {
                shopperCheckoutExperienceValues.push(value);
            } else if (isShopperCheckoutExperience && value && typeof value === 'object') {
                shopperCheckoutExperienceValues.push(value);
            }
            if (fieldName.toLowerCase() === 'retailercheckoutexperience' && value && typeof value === 'object') {
                retailerCheckoutExperiences.push(value);
            }
            if (/^(contactdetails|product)$/i.test(fieldName) && value && typeof value === 'object') {
                metadataOwners.push(value);
                Object.keys(value).forEach(function (itemKey) {
                    if (/^\d+$/.test(itemKey) && value[itemKey] && typeof value[itemKey] === 'object') {
                        metadataOwners.push(value[itemKey]);
                    }
                });
            }
            if (fieldName.toLowerCase() === 'metadataitems' && metadataOwners.indexOf(this) !== -1) {
                return REDACTED;
            }
            if (fieldName.toLowerCase() === 'metadataitems' && retailerCheckoutExperiences.indexOf(this) !== -1 && value !== null) {
                if (typeof value !== 'object') return REDACTED;
                retailerMetadataItems.push(value);
                Object.keys(value).forEach(function (itemKey) {
                    if (/^\d+$/.test(itemKey) && value[itemKey] && typeof value[itemKey] === 'object') {
                        retailerMetadataItems.push(value[itemKey]);
                    }
                });
            }
            if (!isShopperCheckoutExperience && (isSensitiveField(fieldName) || (fieldName.toLowerCase() === 'value' && (isSensitiveField(metadataName) || (retailerMetadataItems.indexOf(this) !== -1 && !isOrderConfirmationUriTestOnly))))) {
                return REDACTED;
            }
            if (!isShopperCheckoutExperience && /^(retailerCartId|orderId|orderNo|BrandOrderReference|status|statusCode|Code|ResponseCode|HoldStatus|PreAuthorized|Settled)$/.test(fieldName)) {
                const safeString = typeof value === 'string' && /^[a-z0-9_.:-]{1,100}$/i.test(value);
                return safeString || (typeof value === 'number' && isFinite(value)) || typeof value === 'boolean'
                    ? value : REDACTED;
            }
            return value;
        });
    } catch (error) {
        return REDACTED;
    }
}

module.exports = {
    sanitizeLogMessage: sanitizeLogMessage
};