/* eslint-disable new-cap */

'use strict';

const jwtHelper = require('*/cartridge/scripts/jwt/jwtHelper');
const jwtDecode = require('*/cartridge/scripts/jwt/decode');

const Bytes = require('dw/util/Bytes');
const Encoding = require('dw/crypto/Encoding');
const Signature = require('dw/crypto/Signature');

const JWTAlgoToSFCCMapping = jwtHelper.JWTAlgoToSFCCMapping;
const SUPPORTED_VERIFICATION_ALGORITHMS = ['RS256'];

/**
 * Verifies the RSA signature of the JWT.
 * @param {string} signature - The JWT signature.
 * @param {string} input - The input string to verify.
 * @param {string} publicKey - The public key to use for verification.
 * @param {string} algorithm - The algorithm to use for verification.
 * @returns {boolean} - True if the signature is valid, false otherwise.
 */
function createRSAVerifier(signature, input, publicKey, algorithm) {
    let jwtSignatureInBytes = Encoding.fromBase64(jwtHelper.toBase64Encoded(signature));
    let contentToVerifyInBytes = new Bytes(input);

    let apiSig = new Signature();
    let verified = apiSig.verifyBytesSignature(jwtSignatureInBytes, contentToVerifyInBytes, new Bytes(publicKey), JWTAlgoToSFCCMapping[algorithm]);
    return verified;
}

function getRSAPublicKey(jsonWebKey) {
    if (jsonWebKey === null || typeof jsonWebKey !== 'object') {
        return null;
    }
    if (jsonWebKey.kty !== 'RSA' || !jsonWebKey.n || !jsonWebKey.e) {
        return null;
    }

    let keyHelper = require('*/cartridge/scripts/jwt/jwkToPemHelper');
    return keyHelper.getRSAPublicKey(jsonWebKey.n, jsonWebKey.e);
}

const JWTAlgoToVerifierMapping = {
    RS256: createRSAVerifier,
};

/**
 * Verifies the JWT token.
 * @param {string} jwt - The JWT token to verify.
 * @param {Object} options - The options for verification.
 * @param {string} [options.publicKeyOrSecret] - The public key or secret to use for verification.
 * @param {boolean} [options.ignoreExpiration] - Whether to ignore the expiration date.
 * @param {string} [options.audience] - The expected audience of the token.
 * @param {string} [options.issuer] - The expected issuer of the token.
 * @returns {boolean} - True if the token is valid, false otherwise.
 */
function verifyJWT(jwt, options) {
    options = options || {};

    if (!jwtHelper.isValidJWT(jwt)) {
        return false;
    }

    let decodedToken = jwtDecode.decodeJWT(jwt);
    if (!decodedToken) {
        return false;
    }

    let algorithm = SUPPORTED_VERIFICATION_ALGORITHMS[0];
    if (!algorithm || decodedToken.header.alg !== algorithm) {
        return false;
    }

    let parts = jwt.split('.');

    let header = parts[0];
    let payload = parts[1];
    let jwtSig = parts[2];

    let contentToVerify = header + '.' + payload;

    let publicKeyOrSecret;
    if (options.publicKeyOrSecret && typeof options.publicKeyOrSecret === 'string') {
        publicKeyOrSecret = options.publicKeyOrSecret;
    } else if (options.publicKeyOrSecret && typeof options.publicKeyOrSecret === 'function') {
        let jsonWebKey = options.publicKeyOrSecret(decodedToken);
        publicKeyOrSecret = getRSAPublicKey(jsonWebKey);
    }

    if (!publicKeyOrSecret) {
        throw new Error('Cannot verify JWT token as public key or secret not supplied');
    }

    let verifier = JWTAlgoToVerifierMapping[algorithm];
    let verified = verifier(jwtSig, contentToVerify, publicKeyOrSecret, algorithm);
    if (!verified) {
        return false;
    }

    payload = decodedToken.payload;
    if (!Number.isFinite(payload.exp)) {
        return false;
    }

    let issuer = payload.iss;
    let audience = payload.aud;
    let hasValidAudience = typeof audience === 'string' && audience.length > 0;
    if (Array.isArray(audience)) {
        hasValidAudience = audience.some(function (value) {
            return typeof value === 'string' && value.length > 0;
        });
    }
    if (typeof issuer !== 'string' || !issuer || !hasValidAudience) {
        return false;
    }

    if (!options.ignoreExpiration) {
        let currentTimestamp = Date.now() / 1000;
        if (payload.exp <= currentTimestamp) {
            return false;
        }
    }

    if (options.audience) {
        let audienceMatches = typeof audience === 'string' ? options.audience === audience : audience.includes(options.audience);
        if (!audienceMatches) {
            return false;
        }
    }

    if (options.issuer) {
        if (issuer !== options.issuer) {
            return false;
        }
    }

    return true;
}

module.exports.verifyJWT = verifyJWT;
