const Transaction = require('dw/system/Transaction');
const CustomObjectMgr = require('dw/object/CustomObjectMgr');
const Logger = require('dw/system/Logger');

const eswHelper = require('*/cartridge/scripts/helper/eswCoreHelper').getEswHelper;
const sign = require('*/cartridge/scripts/jwt/sign.js');
const verify = require('*/cartridge/scripts/jwt/verify.js');
const decode = require('*/cartridge/scripts/jwt/decode.js');

/**
 * Fetches JWKS (JSON Web Key Set) from ESW (eShopWorld) and stores it in a custom object.
 * If the JWKS is not empty and contains keys, it removes the existing custom object and creates a new one with the fetched keys.
 *
 * @returns {Array} The public keys fetched from ESW.
 */
const getJwksFromEsw = function () {
    let publickeys = eswHelper.fetchJwksFromEsw();
    if (Array.isArray(publickeys) && publickeys.length > 0) {
        try {
            let co = eswHelper.getCustomObjectDetails('ESW_JWKS', 'ESW_JWKS');
            Transaction.wrap(function () {
                if (co) {
                    CustomObjectMgr.remove(co);
                }
                co = CustomObjectMgr.createCustomObject('ESW_JWKS', 'ESW_JWKS');
                co.custom.validationKeys = JSON.stringify(publickeys);
            });
        } catch (error) {
            Logger.getLogger('EShopWorld', 'EswJWT').error('Unable to store ESW JWKS: {0}', String(error));
        }
    }
    return publickeys;
};

const getValidationKeys = function (jwksCo) {
    if (jwksCo === null || typeof jwksCo !== 'object') {
        return null;
    }
    let custom = jwksCo.custom;
    if (custom === null || typeof custom !== 'object') {
        return null;
    }
    return custom.validationKeys || null;
};

const getCachedJwks = function () {
    let jwksCo = null;
    try {
        jwksCo = eswHelper.getCustomObjectDetails('ESW_JWKS', 'ESW_JWKS');
    } catch (error) {
        Logger.getLogger('EShopWorld', 'EswJWT').error('Unable to read ESW JWKS: {0}', String(error));
    }

    let jwks = getValidationKeys(jwksCo);
    if (!jwks) {
        return { keys: getJwksFromEsw(), renewed: true };
    }

    try {
        jwks = JSON.parse(jwks);
    } catch (error) {
        jwks = null;
    }
    if (!jwks) {
        return { keys: getJwksFromEsw(), renewed: true };
    }

    return { keys: jwks, renewed: false };
};

const findValidationKey = function (jwks, kid) {
    if (!Array.isArray(jwks)) {
        return null;
    }
    return jwks.find(function (jwk) {
        if (!jwk) {
            return false;
        }
        return jwk.kty === 'RSA' && jwk.n && jwk.e && jwk.kid === kid;
    });
};

const getExpectedIssuer = function () {
    let jwksServiceUrl;
    try {
        let eswCoreServices = require('*/cartridge/scripts/services/EswCoreService').getEswServices();
        jwksServiceUrl = eswCoreServices.getJwksFromEswService().getURL();
    } catch (error) {
        Logger.getLogger('EShopWorld', 'EswJWT').error('Unable to resolve ESW JWKS URL: {0}', String(error));
        return null;
    }

    if (typeof jwksServiceUrl !== 'string') {
        return null;
    }
    let issuer = jwksServiceUrl.replace(/\/.well-known\/openid-configuration\/jwks\/?$/, '');
    return issuer && issuer !== jwksServiceUrl ? issuer : null;
};

/**
 * Validates a JWT using the JWKS.
 *
 * @param {string} jwtRecieved - The JWT token to be validated.
 * @returns {Object} An object with validation results, where the key is `validated1` and the value is a boolean indicating whether the JWT is valid.
 */
const isValidJwt = function (jwtRecieved) {
    if (typeof jwtRecieved !== 'string' || !jwtRecieved) {
        return false;
    }
    let jwt = jwtRecieved.replace(/^Bearer\s+/i, '');
    let jwksCache = getCachedJwks();
    let jwks = jwksCache.keys;
    let decodedToken = decode.decodeJWT(jwt);
    if (!decodedToken || !Array.isArray(jwks)) {
        return false;
    }
    let keyToValidate = findValidationKey(jwks, decodedToken.header.kid);
    // If JWT kid is not matched and keys are not renewed recently, then fetch the keys again
    if (!keyToValidate && !jwksCache.renewed) {
        jwks = getJwksFromEsw();
        keyToValidate = findValidationKey(jwks, decodedToken.header.kid);
    }
    if (!keyToValidate) {
        // No matching key found
        return false;
    }
    let issuer = getExpectedIssuer();
    if (!issuer) {
        return false;
    }
    let audience = issuer + '/resources';
    let options = {
        issuer: issuer,
        audience: audience,
        publicKeyOrSecret: function () {
            return keyToValidate;
        }
    };
    return verify.verifyJWT(jwt, options);
};

module.exports.sign = sign.signJWT;
module.exports.verify = verify.verifyJWT;
module.exports.isValidJwt = isValidJwt;
module.exports.getJwksFromEsw = getJwksFromEsw;
