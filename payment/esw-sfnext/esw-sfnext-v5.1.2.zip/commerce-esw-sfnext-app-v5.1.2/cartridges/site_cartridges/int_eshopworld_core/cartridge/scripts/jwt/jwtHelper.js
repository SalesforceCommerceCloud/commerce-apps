/* eslint-disable no-useless-escape */
const JWT_REGEX = /^[a-zA-Z0-9\-_]+?\.[a-zA-Z0-9\-_]+?\.([a-zA-Z0-9\-_]+)?$/;
const SUPPORTED_ALGORITHMS = ['RS256'];

/**
 * Checks if the given JWT is valid.
 * @param {string} jwt - The JSON Web Token to validate.
 * @returns {boolean} True if the JWT is valid, false otherwise.
 */
function isValidJWT(jwt) {
    return JWT_REGEX.test(jwt);
}

const JWTAlgoToSFCCMapping = {
    RS256: 'SHA256withRSA'
};

/**
 * Converts a base64 string to a base64 URL encoded string.
 * @param {string} input - The base64 string to convert.
 * @returns {string} The base64 URL encoded string.
 */
function toBase64UrlEncoded(input) {
    return input.split('+').join('-')
            .split('/').join('_')
            .replace(/\=+$/m, '');
}

/**
 * Converts a base64 URL encoded string to standard base64.
 * @param {string} input - The base64 URL encoded string.
 * @returns {string} The padded standard base64 string.
 */
function toBase64Encoded(input) {
    let base64 = input.split('-').join('+').split('_').join('/');
    let paddingLength = (4 - (base64.length % 4)) % 4;
    return base64 + '===='.substring(0, paddingLength);
}

module.exports.isValidJWT = isValidJWT;
module.exports.toBase64UrlEncoded = toBase64UrlEncoded;
module.exports.toBase64Encoded = toBase64Encoded;
module.exports.SUPPORTED_ALGORITHMS = SUPPORTED_ALGORITHMS;
module.exports.JWTAlgoToSFCCMapping = JWTAlgoToSFCCMapping;
