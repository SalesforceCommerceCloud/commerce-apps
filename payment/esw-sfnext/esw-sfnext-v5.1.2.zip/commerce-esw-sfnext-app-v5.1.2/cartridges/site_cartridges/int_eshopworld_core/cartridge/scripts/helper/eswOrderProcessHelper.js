'use strict';

const Transaction = require('dw/system/Transaction');
const logger = require('dw/system/Logger');
const OrderMgr = require('dw/order/OrderMgr');
const Order = require('dw/order/Order');
const Constants = require('*/cartridge/scripts/util/Constants');
const eswCoreHelper = require('*/cartridge/scripts/helper/eswCoreHelper').getEswHelper;

const eswOrderProcessHelper = {
    /**
     * Mark an order as return and add return response
     * @param {Object} reqBodyJson - request object
     * @param {string} requestType - the type of request
     * @return {Object} - JSON response
     */
    markOrderAsReturn: function (reqBodyJson, requestType) {
        let finalFunctionResponse = {
            ResponseCode: Constants.ESW_NO_OPERATION_STATUS,
            ResponseText: Constants.NO_ORDER_RETURN_PERFORMED_MSG
        };
        try {
            let reqObj = reqBodyJson;
            let order = OrderMgr.getOrder(reqObj.ReturnOrder.BrandOrderReference);
            let rmaJSON = [];
            let isStoreReturn = false;
            if (requestType === 'logistics-return-order-retailer') {
                isStoreReturn = reqObj.ReturnOrder.ReturnOrderStatus === eswCoreHelper.getEswReturnOrderStatus().value;
            } else {
                isStoreReturn = reqObj.ReturnOrder.ReturnOrderStatus === Constants.PROCESSED;
            }
            if (!empty(order) && isStoreReturn) {
                Transaction.wrap(function () {
                    // eslint-disable-next-line no-param-reassign
                    if (!empty(order.custom.eswRmaJson)) {
                        rmaJSON = JSON.parse(order.custom.eswRmaJson);
                    }
                    rmaJSON.push(reqObj);
                    order.custom.eswRmaJson = JSON.stringify(rmaJSON);
                    order.custom.eswIsReturned = true;
                });
                finalFunctionResponse.ResponseCode = '200';
                finalFunctionResponse.ResponseText = 'Order Return successfuly';
            }
        } catch (e) {
            const eswLogHelper = require('*/cartridge/scripts/helper/eswLogHelper');
            const logSummary = eswLogHelper.sanitizeLogMessage(reqBodyJson);
            logger.error('ESW Order Return Error: {0}', logSummary);
            eswCoreHelper.eswInfoLogger('Order return payload', logSummary);
            return {
                ResponseCode: '400',
                ResponseText: 'Error: Internal Error'
            };
        }
        return finalFunctionResponse;
    },
    /**
     * Mark an order appeasement
     * @param {Object} reqBodyJson - request object
     * @return {Object} - JSON response
     */
    markOrderAppeasement: function (reqBodyJson) {
        let finalFunctionResponse = {
            ResponseCode: Constants.ESW_NO_OPERATION_STATUS,
            ResponseText: Constants.NO_APPEASEMRNT_PERFORMED_MSG
        };
        try {
            let appeasementJsonPayload = [];
            let order = OrderMgr.getOrder(reqBodyJson.Request.BrandOrderReference);
            if (!empty(order)) {
                Transaction.wrap(function () {
                    // update SFCC side order appeasement values
                    order.custom.isAppeasement = true;
                    if ('appeasementJsonPayload' in order.custom && !empty(order.custom.appeasementJsonPayload)) {
                        appeasementJsonPayload = JSON.parse(order.custom.appeasementJsonPayload);
                        appeasementJsonPayload.push(reqBodyJson);
                        order.custom.appeasementJsonPayload = JSON.stringify(appeasementJsonPayload);
                    } else {
                        appeasementJsonPayload.push(reqBodyJson);
                        order.custom.appeasementJsonPayload = JSON.stringify(appeasementJsonPayload);
                    }
                });
                finalFunctionResponse.ResponseCode = '200';
                finalFunctionResponse.ResponseText = 'Order appeased successfuly';
            }
        } catch (e) {
            const eswLogHelper = require('*/cartridge/scripts/helper/eswLogHelper');
            eswCoreHelper.eswInfoLogger('ESW Order Appeasement Error', eswLogHelper.sanitizeLogMessage(reqBodyJson));
            return {
                ResponseCode: '400',
                ResponseText: 'Error: Internal error'
            };
        }
        return finalFunctionResponse;
    },
    /**
     * Cancel an order
     * @param {Object} reqBodyJson - request object
     * @return {Object} - JSON response
     */
    cancelAnOrder: function (reqBodyJson) {
        let finalFunctionResponse = {
            OrderNumber: reqBodyJson.Request.BrandOrderReference,
            ResponseCode: Constants.ESW_NO_OPERATION_STATUS,
            ResponseText: Constants.NO_ORDER_CANCEL_PERFORMED_MSG
        };
        try {
            let order;
            // cancel order check
            if (eswCoreHelper.isEswEnabledEmbeddedCheckout()) {
                order = OrderMgr.searchOrder('orderNo={0} OR custom.eswBasketUuid={0}', reqBodyJson.Request.BrandOrderReference);
            } else {
                order = OrderMgr.getOrder(reqBodyJson.Request.BrandOrderReference);
            }
            let cancelOrderJsonPayload = [];
            if (order && order.status.value !== Order.ORDER_STATUS_CANCELLED) {
                let isPartialOrderCancelled = reqBodyJson.Request && 'LineItemId' in reqBodyJson.Request;
                Transaction.wrap(function () {
                    if (!isPartialOrderCancelled) {
                        order.custom.isEswCancelledOrder = true;
                    }
                    if ('cancelOrderJsonPayload' in order.custom && !empty(order.custom.cancelOrderJsonPayload)) {
                        cancelOrderJsonPayload = JSON.parse(order.custom.cancelOrderJsonPayload);
                        cancelOrderJsonPayload.push(reqBodyJson);
                        order.custom.cancelOrderJsonPayload = JSON.stringify(cancelOrderJsonPayload);
                    } else {
                        cancelOrderJsonPayload.push(reqBodyJson);
                        order.custom.cancelOrderJsonPayload = JSON.stringify(cancelOrderJsonPayload);
                    }
                });
                finalFunctionResponse.ResponseCode = '200';
                finalFunctionResponse.ResponseText = 'Order processed successfuly';
            }
        } catch (e) {
            const eswLogHelper = require('*/cartridge/scripts/helper/eswLogHelper');
            eswCoreHelper.eswInfoLogger('ESW Order Cancel Error', eswLogHelper.sanitizeLogMessage(reqBodyJson));
            logger.error('ESW Order Cancel Error');
            return {
                OrderNumber: reqBodyJson.Request.BrandOrderReference,
                ResponseCode: '400',
                ResponseText: 'Error: Internal error'
            };
        }
        return finalFunctionResponse;
    },
    /**
     * process payment status of order
     * @param {Object} reqBodyJson - request object
     * @return {Object} - JSON response
     */
    processKonbiniPayment: function (reqBodyJson) {
        let finalFunctionResponse = {
            ResponseCode: Constants.ESW_NO_OPERATION_STATUS,
            ResponseText: Constants.NO_OTC_PAYMENT_PERFORMED_MSG
        };
        try {
            let eswOverTheCounterPayloadJson = [];
            let order = OrderMgr.getOrder(reqBodyJson.BrandOrderReference);

            if (!empty(order) && reqBodyJson.HoldStatus === Constants.NOHOLD) {
                Transaction.wrap(function () {
                    order.setExportStatus(Order.EXPORT_STATUS_READY);
                    order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);

                    if ('eswOverTheCounterPayloadJson' in order.custom && !empty(order.custom.eswOverTheCounterPayloadJson)) {
                        eswOverTheCounterPayloadJson.push(JSON.parse(order.custom.eswOverTheCounterPayloadJson));
                    }

                    eswOverTheCounterPayloadJson.push(reqBodyJson);
                    order.custom.eswOverTheCounterPayloadJson = JSON.stringify(eswOverTheCounterPayloadJson);
                });
                finalFunctionResponse.ResponseCode = '200';
                finalFunctionResponse.ResponseText = 'Successfully processed Konbini payment';
            }
        } catch (e) {
            const eswLogHelper = require('*/cartridge/scripts/helper/eswLogHelper');
            logger.error('ESW Order Konbini payment failed Error');
            eswCoreHelper.eswInfoLogger('ESW Order Konbini payment failed Error', eswLogHelper.sanitizeLogMessage(reqBodyJson));
            return {
                ResponseCode: '400',
                ResponseText: 'Error: Internal error'
            };
        }
        return finalFunctionResponse;
    },
    /**
     * Handles ESW post-order webhook payload.
     * @param {Object} webhookPayloadJson - The webhook payload as an object.
     * @returns {boolean} - true if processed, false otherwise.
     */
    handlePostOrderOrderHook: function (webhookPayloadJson) {
        const eswLogHelper = require('*/cartridge/scripts/helper/eswLogHelper');
        let result = false;

        if (!webhookPayloadJson || !webhookPayloadJson.Payment || !webhookPayloadJson.BrandOrderReference) {
            eswCoreHelper.eswInfoLogger('Invalid webhook payload', eswLogHelper.sanitizeLogMessage(webhookPayloadJson));
            return false;
        }
        try {
            // Get the order by BrandOrderReference (case-insensitive)
            let orderId = webhookPayloadJson.BrandOrderReference;
            let order = OrderMgr.getOrder(orderId);

            if (!order) {
                eswCoreHelper.eswInfoLogger('Order not found for BrandOrderReference', eswLogHelper.sanitizeLogMessage(webhookPayloadJson));
                return false;
            }

            let isPreAuthorized = webhookPayloadJson.Payment.PreAuthorized || false;
            let isSettled = webhookPayloadJson.Payment.Settled || false;
            let paymentStatus = Constants.TXT_PAYMENT_NOT_AUTHORIZED;

            Transaction.wrap(function () {
                // Update payment status
                if (isSettled) {
                    if (isPreAuthorized) {
                        paymentStatus = Constants.TXT_PAYMENT_SETTLED;
                        order.setPaymentStatus(Order.PAYMENT_STATUS_PAID);
                    }
                } else {
                    paymentStatus = isPreAuthorized ? Constants.TXT_PAYMENT_AUTHORIZED : Constants.TXT_PAYMENT_NOT_AUTHORIZED;
                    order.setPaymentStatus(Order.PAYMENT_STATUS_NOTPAID);
                }

                order.paymentInstruments[0].paymentTransaction.custom.eswPaymentStatus = paymentStatus;

                // Update confirmation and export status
                if (isSettled) {
                    order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
                    order.setExportStatus(Order.EXPORT_STATUS_READY);
                } else {
                    order.setConfirmationStatus(Order.CONFIRMATION_STATUS_NOTCONFIRMED);
                    order.setExportStatus(Order.EXPORT_STATUS_NOTEXPORTED);
                }
                result = isSettled;
            });
        } catch (e) {
            eswCoreHelper.eswInfoLogger('PostOrder WebHook processing error', eswLogHelper.sanitizeLogMessage(webhookPayloadJson));
        }
        return result;
    }
};

module.exports = eswOrderProcessHelper;
