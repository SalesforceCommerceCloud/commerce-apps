'use strict';

const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const proxyquire = require('proxyquire').noCallThru();
const globalNames = ['empty', 'dw', 'request', 'response'];
let previousGlobals;

const helperPath = '../../../../cartridge/scripts/helper/eswCoreApiHelper';
const status = { FAILED: 'FAILED', CREATED: 'CREATED', NEW: 'NEW', OPEN: 'OPEN' };

function makeHarness(options) {
    const settings = options || {};
    const getOrder = sinon.stub();
    if (settings.throwOnGetOrder) getOrder.throws(new Error('order lookup failed'));
    const failOrder = sinon.stub();
    const currentBasket = { getUUID: () => 'basket-123' };
    const productLineItem = Object.create(ProductLineItem.prototype);
    productLineItem.getProductID = () => 'product-1';
    productLineItem.getPriceValue = () => 12.5;
    productLineItem.getQuantityValue = () => 2;
    productLineItem.getUUID = () => 'line-item-1';
    const productLineItems = settings.withLineItems ? [productLineItem] : [];
    const order = settings.order || {
        status: { value: status.FAILED },
        getOrderNo: () => 'order-123',
        getAllLineItems: () => ({
            iterator: () => {
                let index = 0;
                return {
                    hasNext: () => index < productLineItems.length,
                    next: () => productLineItems[index++]
                };
            }
        })
    };
    if (!settings.throwOnGetOrder) {
        getOrder.returns(Object.prototype.hasOwnProperty.call(settings, 'order') ? settings.order : order);
    }

    const eswHelper = { rebuildCartUponBackFromESW: sinon.stub() };
    const eswPwaHelper = { getRetailerPromoCodes: sinon.stub().returns([{ code: 'PROMO' }]) };
    global.empty = (value) => value === null || typeof value === 'undefined' || value === '' || value === false;
    global.dw = { order: {
        Order: {
            ORDER_STATUS_FAILED: status.FAILED,
            ORDER_STATUS_CREATED: status.CREATED,
            ORDER_STATUS_NEW: status.NEW,
            ORDER_STATUS_OPEN: status.OPEN
        },
        ProductLineItem
    } };
    global.request = {
        httpParameterMap: {
            get: (name) => ({ stringValue: name === 'c_eswClientLastOrderId' ? settings.orderId ?? 'order-123' : settings.token ?? 'secure-token' })
        },
        isSCAPI: () => true
    };
    global.response = { setStatus: sinon.stub() };

    const helper = proxyquire(helperPath, {
        'dw/system/Site': { getCurrent: () => ({}) },
        'dw/system/Logger': { getLogger: () => ({ error: sinon.stub() }) },
        'dw/order/OrderMgr': { getOrder, failOrder },
        'dw/order/BasketMgr': { getCurrentOrNewBasket: () => currentBasket },
        'dw/system/Transaction': { wrap: (callback) => callback() },
        'dw/order/ShippingMgr': {},
        '*/cartridge/scripts/helper/eswCoreHelper': { getEswHelper: eswHelper },
        '*/cartridge/scripts/helper/eswPricingHelper': { eswPricingHelper: {} },
        '*/cartridge/scripts/helper/eswPwaCoreHelper': eswPwaHelper
    });

    return { helper, getOrder, failOrder, eswHelper, order };
}

function ProductLineItem() {}

describe('eswCoreApiHelper.rebuildBasket', function () {
    beforeEach(function () {
        previousGlobals = globalNames.map((name) => Object.getOwnPropertyDescriptor(global, name));
    });

    afterEach(function () {
        globalNames.forEach((name, index) => {
            if (previousGlobals[index]) Object.defineProperty(global, name, previousGlobals[index]);
            else delete global[name];
        });
    });

    it('rejects missing and wrong order credentials', function () {
        let harness = makeHarness({ orderId: '' });
        expect(harness.helper.rebuildBasket()).to.deep.equal({ ResponseCode: '400', ResponseText: 'Error: Internal error' });
        expect(harness.getOrder.called).to.equal(false);

        harness = makeHarness({ token: 'wrong-token', order: null });
        const result = harness.helper.rebuildBasket();
        expect(harness.getOrder.calledOnceWithExactly('order-123', 'wrong-token')).to.equal(true);
        expect(result).to.deep.equal({ ResponseCode: '404', ResponseText: 'Error: Order not found' });
    });

    it('rejects a missing order token', function () {
        const harness = makeHarness({ token: '' });

        expect(harness.helper.rebuildBasket()).to.deep.equal({
            ResponseCode: '400',
            ResponseText: 'Error: Internal error'
        });
        expect(harness.getOrder.called).to.equal(false);
        expect(harness.eswHelper.rebuildCartUponBackFromESW.called).to.equal(false);
    });

    [status.FAILED, status.CREATED, status.NEW].forEach((orderStatus) => {
        it('rebuilds the cart for ' + orderStatus + ' orders', function () {
            const order = {
                status: { value: orderStatus },
                getOrderNo: () => 'order-123',
                getAllLineItems: () => ({
                    iterator: () => {
                        let index = 0;
                        const lineItem = Object.create(ProductLineItem.prototype);
                        lineItem.getProductID = () => 'product-1';
                        lineItem.getPriceValue = () => 12.5;
                        lineItem.getQuantityValue = () => 2;
                        lineItem.getUUID = () => 'line-item-1';
                        return { hasNext: () => index < 1, next: () => (index++ === 0 ? lineItem : null) };
                    }
                })
            };
            const harness = makeHarness({ order, withLineItems: true });

            const result = harness.helper.rebuildBasket();

            expect(result.orderLineItems.products).to.deep.equal([{ productId: 'product-1', price: 12.5, quantity: 2 }]);
            expect(result.basketItems.products).to.deep.equal([{ productId: 'product-1', lineItemId: 'line-item-1' }]);
            expect(harness.eswHelper.rebuildCartUponBackFromESW.calledOnceWithExactly('order-123')).to.equal(true);
            expect(harness.failOrder.calledOnce).to.equal(orderStatus === status.CREATED);
        });
    });

    it('marks OPEN orders for removing existing basket line items', function () {
        const order = { status: { value: status.OPEN } };
        const harness = makeHarness({ order });

        const result = harness.helper.rebuildBasket();

        expect(result).to.include({ basketId: 'basket-123', removeLineItems: true });
        expect(result.orderLineItems.products).to.deep.equal([]);
        expect(harness.eswHelper.rebuildCartUponBackFromESW.called).to.equal(false);
    });

    it('returns the generic error when order lookup throws', function () {
        const harness = makeHarness({ throwOnGetOrder: true });

        expect(harness.helper.rebuildBasket()).to.deep.equal({
            ResponseCode: '500',
            ResponseText: 'Error: Internal error'
        });
    });
});