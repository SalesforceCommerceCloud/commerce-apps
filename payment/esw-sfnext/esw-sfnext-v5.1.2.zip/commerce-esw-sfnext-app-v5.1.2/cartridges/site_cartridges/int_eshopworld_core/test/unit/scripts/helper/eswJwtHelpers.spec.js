var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;
var sinon = require('sinon');
var ArrayList = require('../../../../../../test/mocks/dw.util.CollectionHelper');
const URLUtilsMock = require('../../../../../../test/mocks/dw/web/URLUtils');


var Money = require('../../../../../../test/mocks/dw.value.Money');
var empty = require('../../../../../../test/mocks/dw.global.empty');
const Transaction = require('../../../../../../test/mocks/dw/system/Transaction');
var siteMock = require('../../../../../../test/mocks/dw/system/Site');
var Logger = require('../../../../../../test/mocks/dw/system/Logger');
var StringUtils = require('../../../../../../test/mocks/dw/util/StringUtils');
var CustomObjectMgr = require('../../../../../../test/mocks/dw/object/CustomObjectMgr');
var PriceBookMgrMock = require('../../../../../../test/mocks/dw/catalog/PriceBookMgr');
const Basket = require('../../../../../../test/mocks/dw/order/Basket');


const RequestMock = require('../../../../../../test/mocks/dw/system/Request');

const localizeObj = {
    applyCountryAdjustments: true,
    localizeCountryObj: {
        currencyCode: 'EUR',
        countryCode: 'en-IE'
    },
    applyRoundingModel: 'false'
};
var stubTransaction = sinon.stub();
var stubCookie = sinon.stub();
var stubArrayList = sinon.stub();
var stubURLUtils = sinon.stub();

var session = {
    getCurrency: function () {
        return 'USD';
    },
    privacy: {
        fxRate: ''
    }
};

var globalResponse = {
    setStatus: function () {
        return '401';
    }
};

let lineItemContainer = {};
lineItemContainer.shippingTotalPrice = {
    subtract: function () {
        return 10;
    }
};
lineItemContainer.adjustedShippingTotalPrice = 10;
lineItemContainer.getAdjustedMerchandizeTotalPrice = function (val) {
    if (!val) {
        return {
            subtract: function () {
                return 10;
            }
        };
    } else {
        return 10;
    }
};

global.dw = {
    system: {
        Logger: {
            getLogger: sinon.stub().returns({
                info: sinon.stub(),
                error: sinon.stub(),
            }),
        },
    },
};
const Service = require('../../../../../../test/mocks/dw/svc/Service');
const LocalServiceRegMock = {
    createService: function (serviceId, configObj) { return new Service(configObj); }
};
const Constants = require('../../../../cartridge/scripts/util/Constants');
let customObjectUnavailable = false;
let decodedKid = 'dummyKid123';
let decodedTokenAvailable = true;
let cachedValidationKeys = JSON.stringify([
    { kid: 'key1', kty: 'RSA', n: 'modulus-1', e: 'AQAB' },
    { kid: 'key2', kty: 'RSA', n: 'modulus-2', e: 'AQAB' }
]);
let cachedObjectMissing = false;
let cachedCustomMissing = false;
let fetchedKeys = [{ kty: 'RSA', kid: 'exampleKid123', n: 'publicKeyModulus', e: 'AQAB' }];
let fetchCount = 0;
let serviceUrl = 'https://security-sts.sandbox.eshopworld.com/.well-known/openid-configuration/jwks';
let serviceUrlUnavailable = false;
let storageUnavailable = false;
const verifyJWTStub = sinon.stub().callsFake(function (jwt, options) {
    options.publicKeyOrSecret();
    return true;
});
describe('/link_eshopworld/cartridges/int_eshopworld_core/cartridge/scripts/jwt/eswJwtHelpers.js', function () {
    var eswJwtHelpers = proxyquire('../../../../cartridge/scripts/jwt/eswJwtHelpers.js', {
        '*/cartridge/scripts/util/collections': ArrayList,
        'dw/system/Transaction': Transaction,
        'dw/web/Cookie': stubCookie,
        'dw/value/Money': Money,
        'dw/system/Logger': Logger,
        'dw/util/ArrayList': stubArrayList,
        'dw/web/URLUtils': stubURLUtils,
        checkRedirect: function () {},
        '*/cartridge/scripts/helper/eswCoreHelper': {
            getEswHelper: {
                getCatalogUploadMethod: function () { return 'api'; },
                beautifyJsonAsString: function () {
                    return null;
                },
                getCustomObjectDetails: function () {
                    if (customObjectUnavailable) {
                        throw new Error('Custom object type unavailable');
                    }
                    if (cachedObjectMissing) {
                        return null;
                    }
                    return {
                        custom: cachedCustomMissing ? null : { validationKeys: cachedValidationKeys },
                        getCustom: function () { return {configReport: ''} }
                    };
                },
                fetchJwksFromEsw: function () {
                    fetchCount++;
                    return fetchedKeys;
                }
            }
        },
        '*/cartridge/scripts/jwt/sign.js': {},
        '*/cartridge/scripts/jwt/verify.js': {
            verifyJWT: verifyJWTStub
        },
        '*/cartridge/scripts/jwt/decode.js': {
            decodeJWT: function (params) {
                if (!decodedTokenAvailable) {
                    return null;
                }
                return {
                    header: {
                        alg: "RS256",          // Algorithm used for signing the JWT
                        typ: "JWT",            // Type of the token
                        kid: decodedKid
                    },
                    payload: {
                        sub: "1234567890",     // Subject of the JWT
                        name: "John Doe",      // Name inside the payload
                        iat: 1516239022        // Issued At timestamp
                    }
                };
            }
        },
        'dw/system/Site': {
            getCurrent: function () {
                return {
                    getCustomPreferenceValue: function (value) {
                        if (value == 'eswBaseCurrency') {
                            return 'some value';
                        } else {
                            return undefined;
                        }
                    }
                };
            }
        },
        '*/cartridge/scripts/services/EswCoreService': {
            getEswServices: function () {
                return {
                    getJwksFromEswService: function () {
                        return {
                            getURL: function () {
                                if (serviceUrlUnavailable) {
                                    throw new Error('JWKS URL unavailable');
                                }
                                return serviceUrl;
                            },
                            call: function () {
                                return {
                                    status: 'OK',
                                    object: { keys: ['key1', 'key2'] }
                                };
                            }
                        };
                    }
                };
            }
        },
        'dw/util/StringUtils': StringUtils,
        'dw/svc/LocalServiceRegistry': LocalServiceRegMock,
        '*/cartridge/scripts/util/Constants': Constants,
        'dw/object/CustomObjectMgr': {
            createCustomObject: function () {
                if (storageUnavailable) {
                    throw new Error('Custom object storage unavailable');
                }
                return { custom: { validationKeys: '' } };
            },
            remove: function (params) {}
        },
        'dw/content/ContentMgr': {},
        'dw/catalog/PriceBookMgr': PriceBookMgrMock,
        'dw/web/URLAction': function () {
            return 'some url';
        },
        'dw/web/URLParameter': '',
        '*/cartridge/scripts/helper/eswOrderProcessHelper': {
            cancelAnOrder: function () {
                return {
                    success: 'orderProcess'
                };
            }
        },
        getBaseCurrencyPreference: function () {
            return 'EUR';
        },
        isEswCatalogFeatureEnabled: function () { return true; },
        '*/cartridge/scripts/helper/eswCalculationHelper': {
            getEswCalculationHelper: {
                getSubtotalObject: function () {
                    return Money(true, request.httpCookies['esw.currency'].value);
                },
                getMoneyObject: function () {
                    return Money;
                }
            }
        },
        '*/cartridge/scripts/helper/eswPricingHelper': {
            eswPricingHelper: {

            }
        },
        '*/cartridge/scripts/jwt/eswJwtHelpers': {
            eswPricingHelper: function () {
                return true;
            }
        },
        '*/cartridge/scripts/jwt/jwtHelper': {
            isValidJWT: function () {
                return true;
            }
        },
        'dw/crypto/Encoding': {
            fromBase64: function (params) {
                return {
                    toString: function () {
                        return JSON.stringify({ 'FJSNF': 'FKNKJ' });
                    }
                };
            }
        },
        getCatalogUploadMethod: function () { return 'API'; }
    });
    describe('isValidJwt', function () {
        beforeEach(function () {
            customObjectUnavailable = false;
            decodedKid = 'dummyKid123';
            decodedTokenAvailable = true;
            cachedValidationKeys = JSON.stringify([
                { kid: 'key1', kty: 'RSA', n: 'modulus-1', e: 'AQAB' },
                { kid: 'key2', kty: 'RSA', n: 'modulus-2', e: 'AQAB' }
            ]);
            cachedObjectMissing = false;
            cachedCustomMissing = false;
            fetchedKeys = [{ kty: 'RSA', kid: 'exampleKid123', n: 'publicKeyModulus', e: 'AQAB' }];
            fetchCount = 0;
            serviceUrl = 'https://security-sts.sandbox.eshopworld.com/.well-known/openid-configuration/jwks';
            serviceUrlUnavailable = false;
            storageUnavailable = false;
            verifyJWTStub.resetHistory();
        });

        // Unit test
        it('return validate response', function () {
            const jwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
            let isValidJwt = eswJwtHelpers.isValidJwt(jwt);
            expect(isValidJwt).to.be.false;
        });

        it('validates with freshly fetched RSA keys when the JWKS object is unavailable', function () {
            customObjectUnavailable = true;
            decodedKid = 'exampleKid123';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            let options = verifyJWTStub.lastCall.args[1];
            expect(options.issuer).to.equal('https://security-sts.sandbox.eshopworld.com');
            expect(options.audience).to.equal('https://security-sts.sandbox.eshopworld.com/resources');
            customObjectUnavailable = false;
            decodedKid = 'dummyKid123';
            verifyJWTStub.resetHistory();
        });

        it('refreshes malformed cached JSON', function () {
            cachedValidationKeys = '{invalid';
            decodedKid = 'exampleKid123';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            expect(fetchCount).to.equal(1);
        });

        it('uses a matching cached RSA key without refreshing', function () {
            decodedKid = 'key1';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            expect(fetchCount).to.equal(0);
        });

        it('returns false for a parsed non-array JWKS or undecodable token', function () {
            cachedValidationKeys = JSON.stringify({ keys: [] });
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;

            cachedValidationKeys = JSON.stringify([]);
            decodedTokenAvailable = false;
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;
        });

        it('rejects empty or non-string JWT values', function () {
            expect(eswJwtHelpers.isValidJwt('')).to.be.false;
            expect(eswJwtHelpers.isValidJwt(null)).to.be.false;
            expect(eswJwtHelpers.isValidJwt(123)).to.be.false;
        });

        it('fetches when the custom object or its custom data is missing', function () {
            cachedObjectMissing = true;
            decodedKid = 'exampleKid123';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            expect(fetchCount).to.equal(1);

            cachedObjectMissing = false;
            cachedCustomMissing = true;
            fetchCount = 0;
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            expect(fetchCount).to.equal(1);
        });

        it('fetches when the custom object has no validation keys', function () {
            cachedValidationKeys = null;
            decodedKid = 'exampleKid123';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            expect(fetchCount).to.equal(1);
        });

        it('skips null JWKS entries while searching for an RSA key', function () {
            cachedValidationKeys = JSON.stringify([
                null,
                { kid: 'key1', kty: 'RSA', n: 'modulus-1', e: 'AQAB' }
            ]);
            decodedKid = 'key1';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
            expect(fetchCount).to.equal(0);
        });

        it('fails closed when refreshed keys are unavailable or contain no matching key', function () {
            cachedObjectMissing = true;
            fetchedKeys = null;
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;

            fetchedKeys = [{ kty: 'RSA', kid: 'different-kid', n: 'modulus', e: 'AQAB' }];
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;
        });

        it('handles a non-array result when refreshing a stale cached key set', function () {
            decodedKid = 'unknown-kid';
            fetchedKeys = null;
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;
        });

        it('fails closed when the expected issuer cannot be resolved', function () {
            customObjectUnavailable = true;
            decodedKid = 'exampleKid123';
            serviceUrlUnavailable = true;
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;

            serviceUrlUnavailable = false;
            serviceUrl = 'https://security-sts.sandbox.eshopworld.com/not-a-jwks-url';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;

            serviceUrl = null;
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.false;
        });

        it('continues validation with fetched keys when storage fails', function () {
            cachedObjectMissing = true;
            storageUnavailable = true;
            decodedKid = 'exampleKid123';
            expect(eswJwtHelpers.isValidJwt('a.b.c')).to.be.true;
        });
    });
    describe('getJwksFromEsw', function () {
        // Unit test
        it('return JWT response', function () {
            let getJwksFromEsw = eswJwtHelpers.getJwksFromEsw();
            expect(getJwksFromEsw).to.be.an('array');
        });

        it('returns an empty response without attempting storage when no keys are fetched', function () {
            fetchedKeys = null;
            expect(eswJwtHelpers.getJwksFromEsw()).to.be.null;
        });
    });
});
