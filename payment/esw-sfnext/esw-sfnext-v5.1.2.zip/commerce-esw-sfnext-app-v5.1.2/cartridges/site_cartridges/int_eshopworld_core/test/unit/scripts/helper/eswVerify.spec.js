var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;
var sinon = require('sinon');
var ArrayList = require('../../../../../../test/mocks/dw.util.CollectionHelper');
const URLUtilsMock = require('../../../../../../test/mocks/dw/web/URLUtils');
const BytesMock = require('../../../../../../test/mocks/dw/util/Bytes');


var Money = require('../../../../../../test/mocks/dw.value.Money');
var empty = require('../../../../../../test/mocks/dw.global.empty');
const Transaction = require('../../../../../../test/mocks/dw/system/Transaction');
var siteMock = require('../../../../../../test/mocks/dw/system/Site');
var Logger = require('../../../../../../test/mocks/dw/system/Logger');
var StringUtils = require('../../../../../../test/mocks/dw/util/StringUtils');
var CustomObjectMgr = require('../../../../../../test/mocks/dw/object/CustomObjectMgr');
var PriceBookMgrMock = require('../../../../../../test/mocks/dw/catalog/PriceBookMgr');
const Basket = require('../../../../../../test/mocks/dw/order/Basket');
const jwtHelper = require('../../../../cartridge/scripts/jwt/jwtHelper');


const RequestMock = require('../../../../../../test/mocks/dw/system/Request');

const localizeObj = {
    applyCountryAdjustments: true,
    localizeCountryObj: {
        currencyCode: 'EUR',
        countryCode: 'en-IE'
    },
    applyRoundingModel: 'false'
};
var stubTransaction = sinon.stub();
var stubCookie = sinon.stub();
var stubArrayList = sinon.stub();
var stubURLUtils = sinon.stub();

var session = {
    getCurrency: function () {
        return 'USD';
    },
    privacy: {
        fxRate: ''
    }
};

var globalResponse = {
    setStatus: function () {
        return '401';
    }
};

let lineItemContainer = {};
lineItemContainer.shippingTotalPrice = {
    subtract: function () {
        return 10;
    }
};
lineItemContainer.adjustedShippingTotalPrice = 10;
lineItemContainer.getAdjustedMerchandizeTotalPrice = function (val) {
    if (!val) {
        return {
            subtract: function () {
                return 10;
            }
        };
    } else {
        return 10;
    }
};

global.dw = {
    system: {
        Logger: {
            getLogger: sinon.stub().returns({
                info: sinon.stub(),
                error: sinon.stub(),
            }),
        },
    },
};
const EncodingMock = {
    toHex: function (params) {}
};
const Service = require('../../../../../../test/mocks/dw/svc/Service');
const LocalServiceRegMock = {
    createService: function (serviceId, configObj) { return new Service(configObj); }
};
const Constants = require('../../../../cartridge/scripts/util/Constants');
describe('/link_eshopworld/cartridges/int_eshopworld_core/cartridge/scripts/jwt/verify.js', function () {
    let decodedToken;
    let decodedSignature;
    let tokenStringValid = true;
    let signatureValid = true;
    var verify = proxyquire('../../../../cartridge/scripts/jwt/verify.js', {
        '*/cartridge/scripts/util/collections': ArrayList,
        'dw/system/Transaction': Transaction,
        'dw/web/Cookie': stubCookie,
        'dw/value/Money': Money,
        'dw/system/Logger': Logger,
        'dw/util/ArrayList': stubArrayList,
        'dw/web/URLUtils': stubURLUtils,
        'dw/crypto/Encoding': {},
        checkRedirect: function () {},
        '*/cartridge/scripts/helper/eswCoreHelper': {
            getEswHelper: {
                getCatalogUploadMethod: function () { return 'api'; },
                beautifyJsonAsString: function () {
                    return null;
                },
                getCustomObjectDetails: function () { return {
                    custom: {
                        validationKeys: JSON.stringify([{ kid: 'key1', kty: 'RSA' }, { kid: 'key2', kty: 'RSA' }])
                    },
                    getCustom: function () { return {configReport: ''} }
                }; },
                fetchJwksFromEsw: function () {
                    return [{kid: 'key1'}, {kid: 'key2'}];
                }
            }
        },
        '*/cartridge/scripts/jwt/sign.js': {},
        '*/cartridge/scripts/jwt/verify.js': {},
        '*/cartridge/scripts/jwt/decode': {
            decodeJWT: function (params) {
                return decodedToken;
            }
        },
        '*/cartridge/scripts/jwt/jwkToPemHelper': {
            getRSAPublicKey: function () {
                return 'converted-public-key';
            }
        },
        'dw/system/Site': {
            getCurrent: function () {
                return {
                    getCustomPreferenceValue: function (value) {
                        if (value == 'eswBaseCurrency') {
                            return 'some value';
                        } else {
                            return undefined;
                        }
                    }
                };
            }
        },
        '*/cartridge/scripts/services/EswCoreService': {
            getEswServices: function () {
                return {
                    getJwksFromEswService: function () {
                        return {
                            call: function () {
                                return {
                                    status: 'OK',
                                    object: { keys: ['key1', 'key2'] }
                                };
                            }
                        };
                    }
                };
            }
        },
        'dw/util/StringUtils': StringUtils,
        'dw/svc/LocalServiceRegistry': LocalServiceRegMock,
        '*/cartridge/scripts/util/Constants': Constants,
        'dw/object/CustomObjectMgr': {
            createCustomObject: function () { return {
                custom: { validationKeys: '' }
            }},
            remove: function (params) {}
        },
        'dw/content/ContentMgr': {},
        'dw/catalog/PriceBookMgr': PriceBookMgrMock,
        'dw/web/URLAction': function () {
            return 'some url';
        },
        'dw/web/URLParameter': '',
        '*/cartridge/scripts/helper/eswOrderProcessHelper': {
            cancelAnOrder: function () {
                return {
                    success: 'orderProcess'
                };
            }
        },
        getBaseCurrencyPreference: function () {
            return 'EUR';
        },
        isEswCatalogFeatureEnabled: function () { return true; },
        '*/cartridge/scripts/helper/eswCalculationHelper': {
            getEswCalculationHelper: {
                getSubtotalObject: function () {
                    return Money(true, request.httpCookies['esw.currency'].value);
                },
                getMoneyObject: function () {
                    return Money;
                }
            }
        },
        '*/cartridge/scripts/helper/eswPricingHelper': {
            eswPricingHelper: {

            }
        },
        '*/cartridge/scripts/jwt/eswJwtHelpers': {
            eswPricingHelper: function () {
                return true;
            }
        },
        '*/cartridge/scripts/jwt/jwtHelper': {
            toBase64Encoded: jwtHelper.toBase64Encoded,
            isValidJWT: function () {
                return tokenStringValid;
            },
            toBase64UrlEncoded: function () {
                return 'SGVsbG8gd29ybGQh';
            },
            SUPPORTED_ALGORITHMS: ['RS256'],
            JWTAlgoToSFCCMapping: {
                RS256: 'SHA256withRSA'
            }
        },
        'dw/util/Bytes': BytesMock,
        'dw/crypto/Signature': function () {
            this.verifyBytesSignature = sinon.stub().callsFake(function () {
                return signatureValid;
            });
        },
        'dw/crypto/Encoding': {
            fromBase64: function (params) {
                decodedSignature = params;
                return {
                    toString: function () {
                        return JSON.stringify({ 'FJSNF': 'FKNKJ' });
                    }
                };
            },
            toHex: function (params) {
                return 'ff'
            }, // Ensure this is part of the mock
            toBase64: function (params) {
                return 'SGVsbG8sIHdvcmxkIQ=='
            },
            fromHex: sinon.stub(),
        },
        getCatalogUploadMethod: function () { return 'API'; }
    });
    describe('verifyJWT', function () {
        const jwtToken = 'a.b.c';
        const options = {
            publicKeyOrSecret: 'public-key-example',
            audience: 'example-audience',
            issuer: 'example-issuer'
        };

        beforeEach(function () {
            tokenStringValid = true;
            signatureValid = true;
            decodedToken = {
                header: { alg: 'HS256', kid: 'key1' },
                payload: {
                    exp: Math.floor(Date.now() / 1000) + 300,
                    aud: 'example-audience',
                    iss: 'example-issuer'
                }
            };
        });

        it('rejects HMAC algorithms', function () {
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;
        });

        it('rejects malformed JWT strings and decode failures', function () {
            tokenStringValid = false;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;

            tokenStringValid = true;
            decodedToken = null;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;
        });

        it('rejects tokens without an expiration', function () {
            decodedToken.header.alg = 'RS256';
            delete decodedToken.payload.exp;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;
        });

        it('rejects expired tokens unless expiration is explicitly ignored', function () {
            decodedToken.header.alg = 'RS256';
            decodedToken.payload.exp = 1;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;

            let ignoreExpirationOptions = Object.assign({}, options, { ignoreExpiration: true });
            expect(verify.verifyJWT(jwtToken, ignoreExpirationOptions)).to.be.true;
        });

        it('accepts a valid RS256 signature with matching claims', function () {
            decodedToken.header.alg = 'RS256';
            expect(verify.verifyJWT(jwtToken, options)).to.be.true;
        });

        it('normalizes the Base64URL signature before RSA verification', function () {
            decodedToken.header.alg = 'RS256';
            verify.verifyJWT('a.b.c-_', options);
            expect(decodedSignature).to.equal('c+/=');
        });

        it('rejects mismatched issuer and audience', function () {
            decodedToken.header.alg = 'RS256';
            decodedToken.payload.iss = 'wrong-issuer';
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;

            decodedToken.payload.iss = 'example-issuer';
            decodedToken.payload.aud = 'wrong-audience';
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;
        });

        it('supports an audience array and rejects missing required claims', function () {
            decodedToken.header.alg = 'RS256';
            decodedToken.payload.aud = ['other-audience', 'example-audience'];
            expect(verify.verifyJWT(jwtToken, options)).to.be.true;

            decodedToken.payload.aud = ['other-audience'];
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;

            decodedToken.payload.aud = [null];
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;

            decodedToken.payload.aud = 'example-audience';
            delete decodedToken.payload.iss;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;

            decodedToken.payload.iss = 'example-issuer';
            delete decodedToken.payload.aud;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;
        });

        it('resolves RSA JWKs and rejects invalid keys or failed signatures', function () {
            decodedToken.header.alg = 'RS256';
            let jwkOptions = Object.assign({}, options, {
                publicKeyOrSecret: function () {
                    return { kty: 'RSA', n: 'modulus', e: 'AQAB' };
                }
            });
            expect(verify.verifyJWT(jwtToken, jwkOptions)).to.be.true;

            jwkOptions.publicKeyOrSecret = function () {
                return { kty: 'EC', x: 'not-rsa' };
            };
            expect(function () {
                verify.verifyJWT(jwtToken, jwkOptions);
            }).to.throw('Cannot verify JWT token as public key or secret not supplied');

            jwkOptions.publicKeyOrSecret = function () {
                return null;
            };
            expect(function () {
                verify.verifyJWT(jwtToken, jwkOptions);
            }).to.throw('Cannot verify JWT token as public key or secret not supplied');

            signatureValid = false;
            expect(verify.verifyJWT(jwtToken, options)).to.be.false;
        });

        it('allows claim presence checks without optional expected values', function () {
            decodedToken.header.alg = 'RS256';
            expect(verify.verifyJWT(jwtToken, { publicKeyOrSecret: 'public-key-example' })).to.be.true;
            expect(function () {
                verify.verifyJWT(jwtToken);
            }).to.throw('Cannot verify JWT token as public key or secret not supplied');
        });
    });
});
