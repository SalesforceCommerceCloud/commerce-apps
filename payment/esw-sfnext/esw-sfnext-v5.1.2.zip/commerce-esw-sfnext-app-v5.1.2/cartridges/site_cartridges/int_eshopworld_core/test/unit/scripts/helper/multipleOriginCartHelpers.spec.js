'use strict';

const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const proxyquire = require('proxyquire').noCallThru();
const globalNames = ['empty', 'session', 'request'];
let previousGlobals;

const helperPath = '../../../../cartridge/scripts/helper/multipleOriginCartHelpers';

function makeHarness(originInventory) {
    const lineItems = [];
    lineItems.add = function (item) { this.push(item); };
    const inventoryInfo = originInventory.map((item) => Object.assign({}, item));
    const product = {
        ID: 'product-1',
        name: 'Test product',
        bundle: false,
        availabilityModel: { inventoryRecord: { perpetual: false, ATS: { value: 10 } } }
    };
    const productModel = { object: { ID: 'product-1', name: 'Test product', optionModel: { options: [] } } };
    const cart = {
        object: { productLineItems: lineItems, defaultShipment: {} },
        createProductLineItem: sinon.stub().callsFake(() => ({
            custom: {},
            setQuantityValue: sinon.stub()
        })),
        calculate: sinon.stub()
    };
    const multiOriginHelper = {
        syncSingleProductMoInventoryWithSfcc: sinon.stub().returns({ eswAtsValue: 10 }),
        getProductOriginDetails: sinon.stub().returns(inventoryInfo),
        getInventoryAtsFromMultiOriginResponse: sinon.stub().callsFake((response) => response.reduce((sum, item) => sum + item.quantity, 0)),
        removeProductLineitemFromBasket: sinon.stub()
    };
    const collections = {
        forEach: (items, callback) => items.forEach(callback),
        every: (items, callback) => items.every(callback),
        map: (items, callback) => items.map(callback)
    };
    global.empty = (value) => value === null || typeof value === 'undefined' || value === '' || value === false || (Array.isArray(value) && value.length === 0);
    global.session = { privacy: {} };
    global.request = { httpParameterMap: { childPids: { stringValue: '' } } };

    const helper = proxyquire(helperPath, {
        'dw/system/Transaction': { wrap: (callback) => callback() },
        'dw/web/Resource': { msg: () => 'inventory error', msgf: () => 'inventory error' },
        '*/cartridge/scripts/helper/eswCoreHelper': { getEswHelper: { isEnabledMultiOrigin: () => true } },
        '*/cartridge/scripts/helper/eswMultiOriginHelper': multiOriginHelper,
        '*/cartridge/scripts/util/collections': collections,
        '*/cartridge/scripts/helper/eswHelper': { getEswHelper: () => ({}) },
        '*/cartridge/scripts/app': { getModel: () => ({ get: () => productModel }) },
        'dw/catalog/ProductMgr': { getProduct: () => product }
    });
    helper.getExistingProductLineItemsInCart = sinon.stub().returns([]);
    helper.getExistingProductLineItemInCart = sinon.stub().returns(null);
    helper.countMultiOriginProductInCart = sinon.stub().returns(0);

    return { helper, cart, multiOriginHelper, product };
}

describe('multipleOriginCartHelpers.updateCart', function () {
    beforeEach(function () {
        previousGlobals = globalNames.map((name) => Object.getOwnPropertyDescriptor(global, name));
    });

    afterEach(function () {
        globalNames.forEach((name, index) => {
            if (previousGlobals[index]) Object.defineProperty(global, name, previousGlobals[index]);
            else delete global[name];
        });
    });

    it('creates a separate basket line item for each fulfillment origin', function () {
        const harness = makeHarness([
            { productId: 'product-1', originIso: 'IE', quantity: 1 },
            { productId: 'product-1', originIso: 'FR', quantity: 2 }
        ]);

        harness.helper.updateCart([{ key: 'product-1', value: '3' }], harness.cart);

        expect(harness.cart.createProductLineItem.callCount).to.equal(2);
        expect(harness.cart.object.productLineItems.map((item) => item.custom.eswFulfilmentCountryIso)).to.deep.equal(['IE', 'FR']);
        expect(harness.cart.object.productLineItems.map((item) => item.setQuantityValue.firstCall.args[0])).to.deep.equal([1, 2]);
    });

    it('sets the inventory error state when origins cannot fulfill the requested quantity', function () {
        const harness = makeHarness([
            { productId: 'product-1', originIso: 'IE', quantity: 1 },
            { productId: 'product-1', originIso: 'FR', quantity: 1 }
        ]);

        harness.helper.updateCart([{ key: 'product-1', value: '3' }], harness.cart);

        expect(global.session.privacy.restrictedQtyProductID).to.equal('product-1');
        expect(global.session.privacy.restrictedQtyProductMessage).to.equal('inventory error');
    });
});