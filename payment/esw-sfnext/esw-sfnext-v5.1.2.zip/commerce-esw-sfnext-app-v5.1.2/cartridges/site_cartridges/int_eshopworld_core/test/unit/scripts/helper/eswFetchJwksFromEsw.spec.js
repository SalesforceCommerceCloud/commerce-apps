var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;
var sinon = require('sinon');
var ArrayList = require('../../../../../../test/mocks/dw.util.CollectionHelper');
const URLUtilsMock = require('../../../../../../test/mocks/dw/web/URLUtils');


var Money = require('../../../../../../test/mocks/dw.value.Money');
var empty = require('../../../../../../test/mocks/dw.global.empty');
var siteMock = require('../../../../../../test/mocks/dw/system/Site');
var Logger = require('../../../../../../test/mocks/dw/system/Logger');
var StringUtils = require('../../../../../../test/mocks/dw/util/StringUtils');
var CustomObjectMgr = require('../../../../../../test/mocks/dw/object/CustomObjectMgr');
var PriceBookMgrMock = require('../../../../../../test/mocks/dw/catalog/PriceBookMgr');
const Basket = require('../../../../../../test/mocks/dw/order/Basket');

const RequestMock = require('../../../../../../test/mocks/dw/system/Request');

const localizeObj = {
    applyCountryAdjustments: true,
    localizeCountryObj: {
        currencyCode: 'EUR',
        countryCode: 'en-IE'
    },
    applyRoundingModel: 'false'
};
global.empty = empty(global);

global.empty = empty(global);
var stubTransaction = sinon.stub();
var stubCookie = sinon.stub();
var stubArrayList = sinon.stub();
var stubURLUtils = sinon.stub();

var session = {
    getCurrency: function () {
        return 'USD';
    },
    privacy: {
        fxRate: ''
    }
};

var globalResponse = {
    setStatus: function () {
        return '401';
    }
};

let lineItemContainer = {};
lineItemContainer.shippingTotalPrice = {
    subtract: function () {
        return 10;
    }
};
lineItemContainer.adjustedShippingTotalPrice = 10;
lineItemContainer.getAdjustedMerchandizeTotalPrice = function (val) {
    if (!val) {
        return {
            subtract: function () {
                return 10;
            }
        };
    } else {
        return 10;
    }
};

global.session = session;
global.response = globalResponse;
global.request = {};
global.dw = {
    system: {
        Logger: {
            getLogger: sinon.stub().returns({
                info: sinon.stub(),
                error: sinon.stub(),
            }),
        },
    },
};
const Service = require('../../../../../../test/mocks/dw/svc/Service');
const LocalServiceRegMock = {
    createService: function (serviceId, configObj) { return new Service(configObj); }
};
const Constants = require('../../../../cartridge/scripts/util/Constants');
let basicAuthEnabled = true;
let jwtValidationResult = false;
let jwtValidationCalls = 0;
let headlessMapping = 'pwa';
describe('/link_eshopworld/cartridges/int_eshopworld_core/cartridge/scripts/helper/eswCoreHelper.js', function () {
    var eswHelper = proxyquire('../../../../cartridge/scripts/helper/eswCoreHelper.js', {
        '*/cartridge/scripts/util/collections': ArrayList,
        'dw/system/Transaction': stubTransaction,
        'dw/web/Cookie': stubCookie,
        'dw/value/Money': Money,
        'dw/system/Logger': Logger,
        'dw/util/ArrayList': stubArrayList,
        'dw/web/URLUtils': stubURLUtils,
        checkRedirect: function () {},
        'dw/system/Site': {
            getCurrent: function () {
                return {
                    getCustomPreferenceValue: function (value) {
                        if (value == 'eswBasicAuthEnabled') {
                            return basicAuthEnabled;
                        } else if (value == 'eswBaseCurrency') {
                            return 'some value';
                        } else if (value === 'eswModuleEnabled' || value === 'eswMultiOriginEnabled') {
                            return true;
                        } else if (value === 'eswHeadlessResponseMapping') {
                            return { getValue: function () { return headlessMapping; } };
                        } else {
                            return undefined;
                        }
                    }
                };
            }
        },
        '*/cartridge/scripts/services/EswCoreService': {
            getEswServices: function () {
                return {
                    getJwksFromEswService: function () {
                        return {
                            call: function () {
                                return {
                                    status: 'OK',
                                    object: { keys: ['key1', 'key2'] }
                                };
                            }
                        };
                    }
                };
            }
        },
        'dw/util/StringUtils': StringUtils,
        'dw/svc/LocalServiceRegistry': LocalServiceRegMock,
        '*/cartridge/scripts/util/Constants': Constants,
        'dw/object/CustomObjectMgr': CustomObjectMgr,
        'dw/content/ContentMgr': {},
        'dw/catalog/PriceBookMgr': PriceBookMgrMock,
        'dw/web/URLAction': function () {
            return 'some url';
        },
        'dw/web/URLParameter': '',
        '*/cartridge/scripts/helper/eswOrderProcessHelper': {
            cancelAnOrder: function () {
                return {
                    success: 'orderProcess'
                };
            }
        },
        getBaseCurrencyPreference: function () {
            return 'EUR';
        },
        isEswCatalogFeatureEnabled: function () { return true; },
        '*/cartridge/scripts/helper/eswCalculationHelper': {
            getEswCalculationHelper: {
                getSubtotalObject: function () {
                    return Money(true, request.httpCookies['esw.currency'].value);
                },
                getMoneyObject: function () {
                    return Money;
                }
            }
        },
        '*/cartridge/scripts/helper/eswPricingHelper': {
            eswPricingHelper: {

            }
        },
        '*/cartridge/scripts/jwt/eswJwtHelpers': {
            isValidJwt: function () {
                jwtValidationCalls++;
                return jwtValidationResult;
            },
            eswPricingHelper: function () {
                return true;
            }
        },
        getCatalogUploadMethod: function () { return 'API'; },
        getCatalogUploadMethod: function () { return 'API'; }
    }).getEswHelper;
    describe('Happy Path', function () {
        // Unit test
        it('Fetch JWKS Keys', function () {
            let fetchJwksFromEsw = eswHelper.fetchJwksFromEsw();
            expect(fetchJwksFromEsw).to.be.an('Array');
        });
    });
    describe('Sad Path', function () {
        // Unit test
        it('return null', function () {
            global.dw = {};
            let fetchJwksFromEsw = eswHelper.fetchJwksFromEsw();
            expect(fetchJwksFromEsw).to.be.an('null');
        });
    });
    describe('validate auth Happy Path', function () {
        // Unit test
        it('return boolean', function () {
            const encodeBasicAuth = sinon.stub(eswHelper, 'encodeBasicAuth').returns('dXNlcjpwYXNz');
            global.request.httpHeaders = {
                get: function (header) {
                    if (header === 'authorization') {
                        return 'Basic dXNlcjpwYXNz';
                    }
                    return null;
                }
            };
            let isValidEswAuthorization = eswHelper.isValidEswAuthorization();
            expect(isValidEswAuthorization).to.be.true;
            encodeBasicAuth.restore();
        });

        it('accepts a valid JWT without requiring Basic Auth', function () {
            basicAuthEnabled = false;
            jwtValidationResult = true;
            jwtValidationCalls = 0;
            global.request.httpHeaders = {
                get: function () {
                    return 'Bearer valid-jwt';
                }
            };

            expect(eswHelper.isValidEswAuthorization()).to.be.true;
            expect(jwtValidationCalls).to.equal(1);

            basicAuthEnabled = true;
            jwtValidationResult = false;
        });
    });
    describe('validate auth Sad Path', function () {
        // Negative test: Missing authorization header
        it('should return false when authorization header is missing', function () {
            global.request.httpHeaders = {
                get: function () {
                    return null;
                },
                authorization: {
                    equals: function () {
                        return false;
                    }
                }
            };
            let isValidEswAuthorization = eswHelper.isValidEswAuthorization();
            expect(isValidEswAuthorization).to.be.false;
        });

        it('rejects empty Basic Auth credentials when Basic Auth is enabled', function () {
            basicAuthEnabled = true;
            global.request.httpHeaders = {
                get: function () {
                    return null;
                },
                authorization: null
            };
            expect(eswHelper.isValidEswAuthorization()).to.be.false;
        });

        it('rejects Basic null when either Basic Auth credential is empty', function () {
            const user = sinon.stub(eswHelper, 'getBasicAuthUser').returns('');
            const password = sinon.stub(eswHelper, 'getBasicAuthPassword').returns('password');
            global.request.httpHeaders = {
                get: function (header) {
                    return header === 'authorization' ? 'Basic null' : null;
                }
            };

            expect(eswHelper.isValidEswAuthorization()).to.be.false;

            user.returns('user');
            password.returns('');
            expect(eswHelper.isValidEswAuthorization()).to.be.false;

            user.restore();
            password.restore();
        });

        it('rejects Basic Auth when either credential contains only whitespace', function () {
            basicAuthEnabled = true;
            jwtValidationResult = false;
            const user = sinon.stub(eswHelper, 'getBasicAuthUser').returns(' \t ');
            const password = sinon.stub(eswHelper, 'getBasicAuthPassword').returns('password');
            global.request.httpHeaders = {
                get: function (header) {
                    return header === 'authorization' ? 'Basic dXNlcjpwYXNz' : null;
                }
            };

            try {
                expect(eswHelper.isValidEswAuthorization()).to.be.false;
                user.returns('user');
                password.returns('\n\t');
                expect(eswHelper.isValidEswAuthorization()).to.be.false;
            } finally {
                user.restore();
                password.restore();
            }
        });

        it('rejects Basic Auth when the credential service configuration is unavailable', function () {
            basicAuthEnabled = true;
            jwtValidationResult = false;
            global.request.httpHeaders = {
                get: function (header) {
                    return header === 'authorization' ? 'Basic dXNlcjpwYXNz' : null;
                }
            };
            const createService = sinon.stub(LocalServiceRegMock, 'createService').throws(new Error('service unavailable'));

            try {
                expect(eswHelper.isValidEswAuthorization()).to.be.false;
                sinon.assert.calledWith(createService, 'EswBasicAuthService', {});
            } finally {
                createService.restore();
            }
        });

        it('rejects a missing Basic Auth header when Basic Auth is enabled', function () {
            basicAuthEnabled = true;
            global.request.httpHeaders = {
                get: function () {
                    return null;
                }
            };
            expect(eswHelper.isValidEswAuthorization()).to.be.false;
        });

        it('rejects blank and malformed Basic Auth headers', function () {
            basicAuthEnabled = true;
            jwtValidationResult = false;
            const encodeBasicAuth = sinon.stub(eswHelper, 'encodeBasicAuth').returns('dXNlcjpwYXNz');
            global.request.httpHeaders = {
                get: function (header) {
                    return header === 'authorization' ? 'Basic ' : null;
                }
            };
            expect(eswHelper.isValidEswAuthorization()).to.be.false;

            global.request.httpHeaders = {
                get: function (header) {
                    return header === 'authorization' ? 'Basic !!!' : null;
                }
            };
            expect(eswHelper.isValidEswAuthorization()).to.be.false;
            encodeBasicAuth.restore();
        });

        it('should reject a missing authorization header when Basic Auth is disabled', function () {
            basicAuthEnabled = false;
            global.request.httpHeaders = {
                get: function () {
                    return null;
                }
            };
            expect(eswHelper.isValidEswAuthorization()).to.be.false;
        });
    });

    describe('isEnabledMultiOrigin', function () {
        it('disables multi-origin for SFNext mapping', function () {
            headlessMapping = 'sfnext';

            expect(eswHelper.isEnabledMultiOrigin()).to.equal(false);
        });

        it('preserves multi-origin for PWA Kit mapping', function () {
            headlessMapping = 'pwa';

            expect(eswHelper.isEnabledMultiOrigin()).to.equal(true);
        });
    });
});
