var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;
var sinon = require('sinon');

var Currency = require('../../../../../../test/mocks/dw/util/Currency');
const ProductMgrMock = require('../../../../../../test/mocks/dw/catalog/ProductMgr');
var Money = require('../../../../../../test/mocks/dw.value.Money');
var Transaction = require('../../../../../../test/mocks/dw/system/Transaction');
var empty = require('../../../../../../test/mocks/dw.global.empty');
var siteMock = require('../../../../../../test/mocks/dw/system/Site');
var Logger = require('../../../../../../test/mocks/dw/system/Logger');
var StringUtils = require('../../../../../../test/mocks/dw/util/StringUtils');
var FileReaderMock = require('../../../../../../test/mocks/dw/io/FileReader');
var FileMock = require('../../../../../../test/mocks/dw/io/File');
global.empty = empty(global);

ProductMgrMock.getProduct = function () {
    return {
        isVariant: function (params) {
            return true;
        },
        getMasterProduct: function (params) {
            return {
                custom: {
                    eswProductRestrictedCountries: false
                }
            }
        },
        custom: {
            eswProductRestrictedCountries: false
        }
    };
};

let basketMgr = {
    getCurrentOrNewBasket: function() {
        return {
            updateCurrency: function () {
                return '';
            }
        }
    }
}

var stubTransaction = sinon.stub();
var stubCookie = sinon.stub();
var stubArrayList = sinon.stub();
var stubURLUtils = sinon.stub();
var hookMgr = {
    callHook: function () {}
};

var session = {
    getCurrency: function () {
        return 'USD';
    },
    privacy: {
        fxRate: ''
    }
};

let req = {
    session: {
        setCurrency: function () {
            return '';
        }
    },
    setLocale: function () {
    }
};

global.session = session;

describe('int_eshopworld_core/cartridge/scripts/helper/eswMultiOriginHelper.js', function () {
    var eswMultiOriginHelper = proxyquire('../../../../cartridge/scripts/helper/eswMultiOriginHelper.js', {
        '*/cartridge/scripts/helper/eswCoreHelper': {
            getEswHelper: {
                // eslint-disable-next-line semi
                getOverridePriceBook: function () { return { countryCode: 'fake countryCode' } },
                overridePriceCore: function () { return {}; },
                getEShopWorldModuleEnabled: function () { return false; },
                getAvailableCountry: function () {
                    return 'USD';
                },
                setAllAvailablePriceBooks: function () {},
                setBaseCurrencyPriceBook: function () {},
                getBaseCurrencyPreference: function () {
                    return 'USD';
                },
                createCookie: function () {}
            }
        },
        'dw/io/FileReader': FileReaderMock,
        'dw/io/File': FileMock,
        'dw/util/Currency': Currency,
        'dw/catalog/ProductMgr': ProductMgrMock,
        'dw/order/BasketMgr': basketMgr,
        'dw/system/HookMgr': hookMgr,
        '*/cartridge/scripts/helper/serviceHelper': {},
        '*/cartridge/scripts/util/collections': '',
        'dw/system/Transaction': Transaction,
        'dw/web/Cookie': stubCookie,
        'dw/value/Money': Money,
        'dw/system/Logger': Logger,
        'dw/util/ArrayList': stubArrayList,
        'dw/web/URLUtils': stubURLUtils,
        'dw/system/Site': siteMock,
        'dw/util/StringUtils': StringUtils
    });
    describe('removeProductLineitemFromBasket', function () {
        it('should remove product line items and shipments correctly', function () {
            const mockBasket = {
                removeProductLineItem: sinon.stub(),
                removeShipment: sinon.stub()
            };

            const mockShipment = {
                productLineItems: { empty: true },
                default: false
            };

            const mockLineItems = [
                { shipment: mockShipment }
            ];

            eswMultiOriginHelper.removeProductLineitemFromBasket(mockLineItems, mockBasket);

            sinon.assert.calledOnce(mockBasket.removeProductLineItem);
            sinon.assert.calledOnce(mockBasket.removeShipment);
        });
    });
    describe('getGroupedPlisUuidByPid', function () {
        it('should return an array of UUIDs from the product line items', function () {
            const mockProductId = 'testProduct';
            const mockBasketPlis = [
                { UUID: 'uuid1' },
                { UUID: 'uuid2' },
                { UUID: 'uuid3' }
            ];

            const result = eswMultiOriginHelper.getGroupedPlisUuidByPid(mockProductId, mockBasketPlis);

            expect(result).to.deep.equal(['uuid1', 'uuid2', 'uuid3']);
        });
    });
    describe('isProductAvailableInMultiOrigin', function () {
        it('should return true if the product is available in multi-origin response', function () {
            const mockMultiOriginResponse = [
                { productId: 'testProduct' },
                { productId: 'anotherProduct' }
            ];
            const result = eswMultiOriginHelper.isProductAvailableInMultiOrigin(mockMultiOriginResponse, 'testProduct');
            expect(result).to.be.true;
        });

        it('should return false if the product is not available in multi-origin response', function () {
            const mockMultiOriginResponse = [
                { productId: 'anotherProduct' }
            ];
            const result = eswMultiOriginHelper.isProductAvailableInMultiOrigin(mockMultiOriginResponse, 'testProduct');
            expect(result).to.be.false;
        });
    });
    describe('getInventoryAtsFromMultiOriginResponse', function () {
        it('should return the total quantity for the given product ID', function () {
            const mockMultiOriginResponse = [
                { productId: 'testProduct', quantity: 5 },
                { productId: 'testProduct', quantity: 10 },
                { productId: 'anotherProduct', quantity: 3 }
            ];
            const result = eswMultiOriginHelper.getInventoryAtsFromMultiOriginResponse(mockMultiOriginResponse, 'testProduct');
            expect(result).to.equal(15);
        });

        it('should return 0 if the product ID is not found in the response', function () {
            const mockMultiOriginResponse = [
                { productId: 'anotherProduct', quantity: 3 }
            ];
            const result = eswMultiOriginHelper.getInventoryAtsFromMultiOriginResponse(mockMultiOriginResponse, 'testProduct');
            expect(result).to.equal(0);
        });
    });
    describe('getProductOriginDetails', function () {
        it('should return the product origin details for a multi-location scenario', function () {
            global.getTestOutputFromFile = sinon.stub().returns('MULTI_LOCATION');
            global.generateRandomAlphaString = sinon.stub().returns('US');
            
            const productWithQuantities = { productId: 'testProduct', quantity: 2 };
            const result = eswMultiOriginHelper.getProductOriginDetails(productWithQuantities);
            
            expect(result).to.be.an('Array');
        });
    });
});
