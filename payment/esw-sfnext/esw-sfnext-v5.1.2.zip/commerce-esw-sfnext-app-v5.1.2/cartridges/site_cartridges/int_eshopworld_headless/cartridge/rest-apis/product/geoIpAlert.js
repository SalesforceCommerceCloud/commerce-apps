
'use strict';


/* API includes */
const logger = require('dw/system/Logger');
const eswHelper = require('*/cartridge/scripts/helper/eswCoreHelper').getEswHelper;
const RESTResponseMgr = require('dw/system/RESTResponseMgr');

exports.getGeoIpAlert = function () {
    let responseJSON;
    try {
    let shopperCountry = request.httpParameters.get('c_shopperCountry')[0];
    let geoIpInfo = eswHelper.isSameGeoIpCountry(shopperCountry);
    responseJSON = { geoIpInfo: geoIpInfo };
    } catch (e) {
        logger.error('ESW geoIpAlert Error: {0}', e.message);
        RESTResponseMgr
            .createError(e.statusCode || 500, 'request-error', 'Request failed', 'Request failed')
            .render();
        return;
    }
    RESTResponseMgr
        .createSuccess(responseJSON)
        .render();
};

exports.getGeoIpAlert.public = true;
