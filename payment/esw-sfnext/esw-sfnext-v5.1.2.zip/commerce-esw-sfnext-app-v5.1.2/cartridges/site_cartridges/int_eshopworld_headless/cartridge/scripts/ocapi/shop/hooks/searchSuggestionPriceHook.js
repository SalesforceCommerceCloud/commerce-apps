'use strict';

exports.modifyGETResponse = function (doc) {
    // API Includes
    let Status = require('dw/system/Status');

    // Script Includes
    let OCAPIHelper = require('*/cartridge/scripts/helper/eswOCAPIHelperHL');
    try {
        OCAPIHelper.eswSearchSuggestionPriceConversions(doc);
    } catch (error) {
        require('dw/system/Logger').error('ESW search suggestion pricing failed: {0}', error.message);
        return new Status(Status.ERROR);
    }

    return new Status(Status.OK);
};
