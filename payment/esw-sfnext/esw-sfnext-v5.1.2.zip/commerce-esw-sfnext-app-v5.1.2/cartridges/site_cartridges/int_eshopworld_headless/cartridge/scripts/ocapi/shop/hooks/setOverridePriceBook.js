'use strict';

// API Includes
const Status = require('dw/system/Status');
const Logger = require('dw/system/Logger');

// Script Includes
const OCAPIHelper = require('*/cartridge/scripts/helper/eswOCAPIHelperHL');

exports.beforeGET = function () {
    try {
        OCAPIHelper.setOverridePriceBooks();
    } catch (error) {
        Logger.error('ESW pricebook setup failed: {0}', error.message);
        return new Status(Status.ERROR);
    }

    return new Status(Status.OK);
};

exports.beforePOST_v2 = function () {
    return exports.beforeGET();
};

exports.beforePOST = function (basket) {
    try {
        OCAPIHelper.setOverridePriceBooks(basket);
        OCAPIHelper.setDefaultOverrideShippingMethod(basket);
    } catch (error) {
        Logger.error('ESW basket pricing setup failed: {0}', error.message);
        return new Status(Status.ERROR);
    }

    return new Status(Status.OK);
};
