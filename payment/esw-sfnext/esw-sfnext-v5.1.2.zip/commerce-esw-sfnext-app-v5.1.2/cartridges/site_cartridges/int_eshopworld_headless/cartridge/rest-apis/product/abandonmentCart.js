
'use strict';


/* API includes */
let eswCoreApiHelper = require('*/cartridge/scripts/helper/eswCoreApiHelper');
const RESTResponseMgr = require('dw/system/RESTResponseMgr');

exports.getAbandonmentCart = function () {
    const responseJSON = eswCoreApiHelper.rebuildBasket();
    if (responseJSON.ResponseCode) {
        RESTResponseMgr
            .createError(Number(responseJSON.ResponseCode), 'abandonment-cart-error',
                responseJSON.ResponseText, responseJSON.errorMessage)
            .render();
        return;
    }

    RESTResponseMgr
        .createSuccess(responseJSON)
        .render();
};

exports.getAbandonmentCart.public = true;
