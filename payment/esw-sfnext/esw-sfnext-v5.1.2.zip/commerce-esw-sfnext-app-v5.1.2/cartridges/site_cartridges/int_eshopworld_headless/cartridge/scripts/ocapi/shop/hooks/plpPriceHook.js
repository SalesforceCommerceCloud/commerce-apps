exports.modifyGETResponse = function (doc) {
    // Script Includes
    let OCAPIHelper = require('*/cartridge/scripts/helper/eswOCAPIHelperHL');
    try {
        OCAPIHelper.eswPlpPriceConversions(doc);
    } catch (error) {
        require('dw/system/Logger').error('ESW product list pricing failed: {0}', error.message);
        const Status = require('dw/system/Status');
        return new Status(Status.ERROR);
    }
};
