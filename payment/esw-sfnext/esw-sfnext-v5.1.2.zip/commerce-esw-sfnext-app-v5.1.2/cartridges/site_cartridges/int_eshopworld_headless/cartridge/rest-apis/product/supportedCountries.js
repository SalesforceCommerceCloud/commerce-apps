
'use strict';


/* API includes */
const logger = require('dw/system/Logger');
const eswPwaHelper = require('*/cartridge/scripts/helper/eswPwaCoreHelper');
const RESTResponseMgr = require('dw/system/RESTResponseMgr');

exports.getSupportedCountries = function () {
    let responseJSON;
    try {
    responseJSON = {
        allowedCountries: eswPwaHelper.getPwaSitesData()
    };
    } catch (e) {
        logger.error('ESW supportedCountries Error: {0}', e.message);
        RESTResponseMgr
            .createError(e.statusCode || 500, 'request-error', 'Request failed', 'Request failed')
            .render();
        return;
    }
    RESTResponseMgr
        .createSuccess(responseJSON)
        .render();
};

exports.getSupportedCountries.public = true;
