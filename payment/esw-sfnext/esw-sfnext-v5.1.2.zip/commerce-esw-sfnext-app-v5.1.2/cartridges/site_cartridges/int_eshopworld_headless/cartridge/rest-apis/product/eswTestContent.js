
'use strict';


/* API includes */
const logger = require('dw/system/Logger');
const ContentMgr = require('dw/content/ContentMgr');
const RESTResponseMgr = require('dw/system/RESTResponseMgr');

exports.getEswTestContent = function () {
    let responseJSON;
    try {
        let contentBody = {};
        let content = ContentMgr.getContent('esw-test-content');
        if (content) {
            contentBody.body = content.custom ? content.custom.body.markup : '';
        }
        responseJSON = contentBody;
    } catch (e) {
        logger.error('ESW eswTestContent Error: {0}', e.message);
        RESTResponseMgr
            .createError(e.statusCode || 500, 'request-error', 'Request failed', 'Request failed')
            .render();
        return;
    }
    RESTResponseMgr
        .createSuccess(responseJSON)
        .render();
};

exports.getEswTestContent.public = true;
