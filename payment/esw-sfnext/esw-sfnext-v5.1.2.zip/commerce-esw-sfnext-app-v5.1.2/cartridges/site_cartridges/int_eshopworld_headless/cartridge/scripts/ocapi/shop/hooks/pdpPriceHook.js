exports.modifyGETResponse = function (scriptProduct, doc) {

    // Script Includes
    let OCAPIHelper = require('*/cartridge/scripts/helper/eswOCAPIHelperHL');
    try {
        OCAPIHelper.eswPdpPriceConversions(scriptProduct, doc);
    } catch (error) {
        require('dw/system/Logger').error('ESW product pricing failed: {0}', error.message);
        const Status = require('dw/system/Status');
        return new Status(Status.ERROR);
    }

};
