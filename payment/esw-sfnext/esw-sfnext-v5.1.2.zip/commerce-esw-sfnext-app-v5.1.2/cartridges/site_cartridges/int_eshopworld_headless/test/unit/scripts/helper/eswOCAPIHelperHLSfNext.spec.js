'use strict';

const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const proxyquire = require('proxyquire').noCallThru();
const emptyMock = require('../../../../../../test/mocks/dw.global.empty');

function FakeArrayList(items) {
    const list = [].concat(items || []);
    list.add = function (item) {
        this.push(item);
    };
    return list;
}

describe('int_eshopworld_headless/cartridge/scripts/helper/eswOCAPIHelperHL.js (SFNext)', function () {
    const originalGlobals = {};
    let eswHelperStub;
    let eswHelperHLStub;
    let pricingHelperStub;
    let serviceHelperV3Stub;
    let currencyStub;
    let hookMgrStub;
    let basketMgrStub;
    let loggerStub;
    let currentBasket;
    let attributeMapping;
    let coreApiHelperStub;
    let isScapi;
    let mappingMode;
    let ocapiHelper;

    function money(value) {
        return { value: Number(value) * 2 };
    }

    beforeEach(function () {
        ['empty', 'request', 'session'].forEach(function (name) {
            originalGlobals[name] = global[name];
        });
        global.empty = emptyMock(global);
        isScapi = true;
        mappingMode = 'sfnext';
        attributeMapping = {};
        global.request = {
            isSCAPI: function () {
                return isScapi;
            },
            httpParameters: {
                get: function () {
                    return ['en-IE'];
                }
            }
        };
        global.session = {
            currency: { currencyCode: 'EUR' },
            setCurrency: sinon.stub()
        };

        currentBasket = {
            updateCurrency: sinon.stub(),
            custom: {}
        };

        eswHelperStub = {
            getHeadlessLocale: sinon.stub().returns('IE'),
            getSelectedCountryDetail: sinon.stub().returns({ countryCode: 'IE', isFixedPriceModel: false }),
            isEswEnabledSparkPricingConversion: sinon.stub().returns(false),
            getCountryLocalizeObj: sinon.stub().returns({ applyRoundingModel: true }),
            getMoneyObject: sinon.spy(money),
            getContentAsset: sinon.stub().returns('return prohibited'),
            getCountryDetailByParam: sinon.stub(),
            setAllAvailablePriceBooks: sinon.stub(),
            getBaseCurrencyPreference: sinon.stub().returns('USD'),
            modifyLineItems: sinon.stub().returns({ docModifiedLineItems: [], isOrderableBasket: true }),
            isEnabledMultiOrigin: sinon.stub().callsFake(function () { return mappingMode !== 'sfnext'; }),
            getGrandTotal: sinon.stub().returns(100)
        };
        eswHelperHLStub = {
            isProductRestricted: sinon.stub().returns(false),
            isReturnProhibited: sinon.stub().returns(false)
        };
        pricingHelperStub = {
            getShopperCurrency: sinon.stub().returns('EUR'),
            setOverridePriceBooks: sinon.stub()
        };
        serviceHelperV3Stub = {
            convertPromotionMessage: sinon.spy(function (message) {
                return 'converted:' + message;
            })
        };
        currencyStub = {
            getCurrency: sinon.spy(function (code) {
                return { currencyCode: code };
            })
        };
        hookMgrStub = {
            callHook: sinon.stub()
        };
        basketMgrStub = {
            getCurrentOrNewBasket: sinon.stub().returns(currentBasket),
            getCurrentBasket: sinon.stub().returns(currentBasket)
        };
        loggerStub = {
            error: sinon.stub(),
            info: sinon.stub()
        };

        coreApiHelperStub = {
            // Identity mapping by default (SFNext/PWA); tests override attributeMapping for headless names.
            getEswAttributeMapping: sinon.spy(function (attribute) {
                return attributeMapping[attribute] || attribute;
            }),
            sendOverrideShippingMethods: sinon.stub(),
            combineProductItems: sinon.stub(),
            pwaMappingValue: sinon.stub().callsFake(function () { return mappingMode; })
        };

        ocapiHelper = proxyquire(
            '../../../../cartridge/scripts/helper/eswOCAPIHelperHL',
            {
                'dw/system/Site': {
                    getCurrent: function () {
                        return {
                            getCustomPreferenceValue: function () {
                                return 'retailer';
                            }
                        };
                    }
                },
                'dw/system/Logger': loggerStub,
                'dw/web/Resource': {
                    msg: function () {
                        return 'not available';
                    }
                },
                'dw/util/ArrayList': FakeArrayList,
                'dw/util/Currency': currencyStub,
                'dw/order/BasketMgr': basketMgrStub,
                'dw/system/HookMgr': hookMgrStub,
                '*/cartridge/scripts/helper/eswCoreApiHelper': coreApiHelperStub,
                '*/cartridge/scripts/helper/eswCoreHelper': {
                    getEswHelper: eswHelperStub
                },
                '*/cartridge/scripts/util/collections': {
                    forEach: function (items, callback) {
                        items.forEach(callback);
                    }
                },
                '*/cartridge/scripts/util/Constants': { SFNEXT_MAPPING_MODE: 'sfnext' },
                'app_storefront_base/cartridge/scripts/cart/cartHelpers': {},
                'app_storefront_base/cartridge/scripts/helpers/productHelpers': {},
                '*/cartridge/scripts/helper/eswPricingHelper': {
                    eswPricingHelper: pricingHelperStub
                },
                '*/cartridge/scripts/helper/eswHelperHL': eswHelperHLStub,
                '*/cartridge/scripts/helper/serviceHelperV3': serviceHelperV3Stub
            }
        );
    });

    afterEach(function () {
        Object.keys(originalGlobals).forEach(function (name) {
            if (originalGlobals[name] === undefined) {
                delete global[name];
            } else {
                global[name] = originalGlobals[name];
            }
        });
    });

    describe('eswPdpPriceConversions', function () {
        it('converts price ranges, variants and variant prices when attributes map to native names (SFNext)', function () {
            const doc = {
                id: 'master-1',
                price: 10,
                priceRanges: [{ minPrice: 5, maxPrice: 15 }],
                variants: [{
                    productId: 'variant-1',
                    orderable: true,
                    price: 20,
                    variantPrices: [{ price: 21 }]
                }],
                variantPrices: [{ price: 30 }]
            };

            ocapiHelper.eswPdpPriceConversions({}, doc);

            expect(doc.price).to.equal(20);
            expect(doc.priceRanges[0]).to.deep.equal({ minPrice: 10, maxPrice: 30 });
            expect(doc.variants[0].price).to.equal(40);
            expect(doc.variants[0].variantPrices[0].price).to.equal(42);
            expect(doc.variantPrices[0].price).to.equal(60);
            expect(doc.currency).to.equal('EUR');
            expect(doc.c_shopperCurrency).to.equal('EUR');
        });

        it('writes converted prices to the mapped ESW custom attributes (headless)', function () {
            attributeMapping = { price: 'c_eswPrice', priceMax: 'c_eswPrice_max' };
            const doc = { id: 'product-1', price: 10, priceMax: 12 };

            ocapiHelper.eswPdpPriceConversions({}, doc);

            expect(coreApiHelperStub.getEswAttributeMapping.calledWith('price')).to.equal(true);
            expect(coreApiHelperStub.getEswAttributeMapping.calledWith('priceMax')).to.equal(true);
            expect(doc.price).to.equal(10);
            expect(doc.c_eswPrice).to.equal(20);
            expect(doc.c_eswPrice_max).to.equal(24);
        });

        it('marks a variant not orderable when it is restricted for the selected country', function () {
            eswHelperHLStub.isProductRestricted.withArgs('variant-restricted', 'IE').returns(true);
            const doc = {
                id: 'master-1',
                price: 10,
                variants: [
                    { productId: 'variant-restricted', orderable: false, price: 10 },
                    { productId: 'variant-allowed', orderable: false, price: 10 }
                ]
            };

            ocapiHelper.eswPdpPriceConversions({}, doc);

            expect(doc.variants[0].orderable).to.equal(false);
            expect(doc.variants[1].orderable).to.equal(true);
        });

        it('keeps a variant orderable when it was already orderable', function () {
            eswHelperHLStub.isProductRestricted.returns(true);
            const doc = {
                id: 'master-1',
                price: 10,
                variants: [{ productId: 'variant-1', orderable: true, price: 10 }]
            };

            ocapiHelper.eswPdpPriceConversions({}, doc);

            expect(doc.variants[0].orderable).to.equal(true);
        });

        it('does not convert prices when Spark pricing conversion is enabled', function () {
            eswHelperStub.isEswEnabledSparkPricingConversion.returns(true);
            const doc = { id: 'product-1', price: 10, variantPrices: [{ price: 30 }] };

            ocapiHelper.eswPdpPriceConversions({}, doc);

            expect(doc.price).to.equal(10);
            expect(doc.variantPrices[0].price).to.equal(30);
            expect(eswHelperStub.getMoneyObject.called).to.equal(false);
        });
    });

    describe('eswPlpPriceConversions', function () {
        it('uses the first converted variant price as the hit price', function () {
            const doc = {
                count: 1,
                hits: [{
                    product_id: 'master-1',
                    price: 10,
                    variants: [
                        { price: 11, variantPrices: [{ price: 12 }] },
                        { price: 50 }
                    ]
                }]
            };

            ocapiHelper.eswPlpPriceConversions(doc);

            expect(doc.hits[0].variants[0].price).to.equal(22);
            expect(doc.hits[0].variants[0].variantPrices[0].price).to.equal(24);
            expect(doc.hits[0].variants[1].price).to.equal(100);
            expect(doc.hits[0].price).to.equal(22);
            expect(doc.hits[0].currency).to.equal('EUR');
        });

        it('does not convert hit prices for fixed price countries', function () {
            eswHelperStub.getSelectedCountryDetail.returns({ countryCode: 'IE', isFixedPriceModel: true });
            const doc = {
                count: 1,
                hits: [{ product_id: 'product-1', price: 10 }]
            };

            ocapiHelper.eswPlpPriceConversions(doc);

            expect(doc.hits[0].price).to.equal(10);
            expect(doc.hits[0].currency).to.equal('EUR');
        });
    });

    describe('shippingPromotionCalloutMessage', function () {
        function basketWithPromotions(promotions) {
            return {
                shipments: [{
                    shipping_method: {
                        shipping_promotions: promotions
                    }
                }]
            };
        }

        it('returns a string callout message for the matching promotion', function () {
            const basket = basketWithPromotions([
                { promotion_id: 'other', calloutMsg: 'Other' },
                { promotion_id: 'free-shipping', calloutMsg: 'Free shipping over 50' }
            ]);

            expect(ocapiHelper.shippingPromotionCalloutMessage(basket, 'free-shipping')).to.equal('Free shipping over 50');
        });

        it('returns the first non-empty localized callout message', function () {
            const basket = basketWithPromotions([
                { promotion_id: 'free-shipping', calloutMsg: { default: '', en_IE: 'Free delivery' } }
            ]);

            expect(ocapiHelper.shippingPromotionCalloutMessage(basket, 'free-shipping')).to.equal('Free delivery');
        });

        it('returns null when the promotion is not found or has no callout message', function () {
            const basket = basketWithPromotions([
                { promotion_id: 'free-shipping' },
                { promotion_id: 'empty-localized', calloutMsg: { default: '' } }
            ]);

            expect(ocapiHelper.shippingPromotionCalloutMessage(basket, 'missing')).to.equal(null);
            expect(ocapiHelper.shippingPromotionCalloutMessage(basket, 'free-shipping')).to.equal(null);
            expect(ocapiHelper.shippingPromotionCalloutMessage(basket, 'empty-localized')).to.equal(null);
        });

        it('returns null when the basket has no shipments or shipping promotions', function () {
            expect(ocapiHelper.shippingPromotionCalloutMessage(null, 'free-shipping')).to.equal(null);
            expect(ocapiHelper.shippingPromotionCalloutMessage({ shipments: [] }, 'free-shipping')).to.equal(null);
            expect(ocapiHelper.shippingPromotionCalloutMessage({ shipments: [{}] }, 'free-shipping')).to.equal(null);
        });

        it('returns null when reading the basket throws', function () {
            const basket = {};
            Object.defineProperty(basket, 'shipments', {
                get: function () {
                    throw new Error('Basket error');
                }
            });

            expect(ocapiHelper.shippingPromotionCalloutMessage(basket, 'free-shipping')).to.equal(null);
        });
    });

    describe('basketItemsModifyResponse shipping promotions', function () {
        beforeEach(function () {
            eswHelperStub.getCountryDetailByParam.returns({
                countryCode: 'IE',
                isFixedPriceModel: true,
                defaultCurrencyCode: 'EUR'
            });
        });

        function buildDoc(promotions) {
            return {
                productItems: [],
                shipments: [{
                    shipping_method: {
                        shipping_promotions: promotions
                    }
                }],
                shippingItems: [{
                    priceAdjustments: [{
                        promotionId: 'free-shipping',
                        itemText: 'Shipping discount'
                    }]
                }]
            };
        }

        it('converts the shipping promotion callout message instead of the item text', function () {
            const doc = buildDoc([{ promotion_id: 'free-shipping', calloutMsg: 'Free shipping over 50' }]);

            ocapiHelper.basketItemsModifyResponse(currentBasket, doc);

            expect(serviceHelperV3Stub.convertPromotionMessage.firstCall.args[0]).to.equal('Free shipping over 50');
            expect(doc.shippingItems[0].priceAdjustments[0].itemText).to.equal('converted:Free shipping over 50');
        });

        it('falls back to the price adjustment item text when no callout message exists', function () {
            const doc = buildDoc([]);

            ocapiHelper.basketItemsModifyResponse(currentBasket, doc);

            expect(serviceHelperV3Stub.convertPromotionMessage.firstCall.args[0]).to.equal('Shipping discount');
            expect(doc.shippingItems[0].priceAdjustments[0].itemText).to.equal('converted:Shipping discount');
        });

        it('does not combine product items by origin for SFNext', function () {
            const doc = buildDoc([]);

            ocapiHelper.basketItemsModifyResponse(currentBasket, doc);

            expect(coreApiHelperStub.combineProductItems.called).to.equal(false);
        });

        it('preserves product item combination for PWA Kit', function () {
            mappingMode = 'pwa';
            const doc = buildDoc([]);

            ocapiHelper.basketItemsModifyResponse(currentBasket, doc);

            expect(coreApiHelperStub.combineProductItems.calledOnce).to.equal(true);
        });
    });

    describe('setOverridePriceBooks', function () {
        it('applies country override price books for fixed price SCAPI countries', function () {
            eswHelperStub.getSelectedCountryDetail.returns({
                countryCode: 'IE',
                isFixedPriceModel: true,
                defaultCurrencyCode: 'EUR'
            });

            ocapiHelper.setOverridePriceBooks(currentBasket);

            expect(eswHelperStub.getHeadlessLocale.calledWith(global.request)).to.equal(true);
            expect(eswHelperStub.getSelectedCountryDetail.calledWith('IE')).to.equal(true);
            expect(pricingHelperStub.setOverridePriceBooks.calledOnceWith('IE', 'EUR', currentBasket)).to.equal(true);
            expect(eswHelperStub.setAllAvailablePriceBooks.called).to.equal(false);
        });

        it('resolves the SCAPI country from the c_country header instead of the locale param', function () {
            eswHelperStub.getHeadlessLocale.returns('GB');
            eswHelperStub.getSelectedCountryDetail.withArgs('GB').returns({
                countryCode: 'GB',
                isFixedPriceModel: true,
                defaultCurrencyCode: 'GBP'
            });

            ocapiHelper.setOverridePriceBooks(null);

            expect(eswHelperStub.getCountryDetailByParam.called).to.equal(false);
            expect(pricingHelperStub.setOverridePriceBooks.calledOnceWith('GB', 'GBP', null)).to.equal(true);
        });

        it('falls back to the locale param when no country can be resolved for SCAPI', function () {
            eswHelperStub.getHeadlessLocale.returns(null);
            eswHelperStub.getCountryDetailByParam.returns({
                countryCode: 'IE',
                isFixedPriceModel: true,
                defaultCurrencyCode: 'EUR'
            });

            ocapiHelper.setOverridePriceBooks(null);

            expect(eswHelperStub.getSelectedCountryDetail.called).to.equal(false);
            expect(pricingHelperStub.setOverridePriceBooks.calledOnceWith('IE', 'EUR', null)).to.equal(true);
        });

        it('aligns the session currency with the fixed price country when there is no basket', function () {
            eswHelperStub.getHeadlessLocale.returns('GB');
            eswHelperStub.getSelectedCountryDetail.returns({
                countryCode: 'GB',
                isFixedPriceModel: true,
                defaultCurrencyCode: 'GBP'
            });

            ocapiHelper.setOverridePriceBooks();

            expect(currencyStub.getCurrency.calledWith('GBP')).to.equal(true);
            expect(global.session.setCurrency.calledOnceWith({ currencyCode: 'GBP' })).to.equal(true);
        });

        it('does not change the session currency when it already matches or a basket is provided', function () {
            eswHelperStub.getSelectedCountryDetail.returns({
                countryCode: 'IE',
                isFixedPriceModel: true,
                defaultCurrencyCode: 'EUR'
            });

            ocapiHelper.setOverridePriceBooks();
            ocapiHelper.setOverridePriceBooks(currentBasket);
            global.session.currency.currencyCode = 'USD';
            ocapiHelper.setOverridePriceBooks(currentBasket);

            expect(global.session.setCurrency.called).to.equal(false);
        });

        it('uses the request currency for non-SCAPI (OCAPI) requests', function () {
            isScapi = false;
            global.request.httpParameters.currency = ['GBP'];

            ocapiHelper.setOverridePriceBooks(currentBasket);

            expect(eswHelperStub.getHeadlessLocale.calledOnceWith(global.request)).to.equal(true);
            expect(eswHelperStub.getCountryDetailByParam.called).to.equal(false);
            expect(pricingHelperStub.setOverridePriceBooks.calledOnceWith('IE', 'GBP', currentBasket)).to.equal(true);
        });

        it('switches dynamic SCAPI countries to base currency price books', function () {
            eswHelperStub.getHeadlessLocale.returns('CA');
            eswHelperStub.getSelectedCountryDetail.returns({
                countryCode: 'CA',
                isFixedPriceModel: false,
                defaultCurrencyCode: 'CAD'
            });
            const setBaseCurrencySpy = sinon.stub(ocapiHelper, 'setBaseCurrencyPriceBookSFNext');

            try {
                ocapiHelper.setOverridePriceBooks(currentBasket);

                expect(eswHelperStub.setAllAvailablePriceBooks.calledOnce).to.equal(true);
                expect(eswHelperStub.getBaseCurrencyPreference.calledWith('CA')).to.equal(true);
                expect(setBaseCurrencySpy.calledOnceWith('USD')).to.equal(true);
                expect(pricingHelperStub.setOverridePriceBooks.called).to.equal(false);
            } finally {
                setBaseCurrencySpy.restore();
            }
        });
    });

    describe('setBaseCurrencyPriceBookSFNext', function () {
        it('sets the session currency, updates the basket currency and recalculates the basket', function () {
            ocapiHelper.setBaseCurrencyPriceBookSFNext('USD');

            expect(currencyStub.getCurrency.calledWith('USD')).to.equal(true);
            expect(global.session.setCurrency.calledOnce).to.equal(true);
            expect(global.session.setCurrency.firstCall.args[0]).to.deep.equal({ currencyCode: 'USD' });
            expect(currentBasket.updateCurrency.calledOnce).to.equal(true);
            expect(hookMgrStub.callHook.calledOnceWith('dw.order.calculate', 'calculate', currentBasket)).to.equal(true);
        });

        it('does not change the session currency when the currency is unknown', function () {
            currencyStub.getCurrency = sinon.stub().returns(null);

            ocapiHelper.setBaseCurrencyPriceBookSFNext('XXX');

            expect(global.session.setCurrency.called).to.equal(false);
            expect(currentBasket.updateCurrency.calledOnce).to.equal(true);
            expect(hookMgrStub.callHook.calledOnce).to.equal(true);
        });

        it('logs an error when the basket cannot be retrieved', function () {
            basketMgrStub.getCurrentOrNewBasket.throws(new Error('Basket unavailable'));

            ocapiHelper.setBaseCurrencyPriceBookSFNext('USD');

            expect(loggerStub.error.calledOnce).to.equal(true);
            expect(hookMgrStub.callHook.called).to.equal(false);
        });
    });
});
