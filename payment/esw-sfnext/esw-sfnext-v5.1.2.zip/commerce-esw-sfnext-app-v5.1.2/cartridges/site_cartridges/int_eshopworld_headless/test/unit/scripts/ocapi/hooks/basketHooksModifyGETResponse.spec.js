'use strict';

const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const proxyquire = require('proxyquire').noCallThru();

describe('int_eshopworld_headless/cartridge/scripts/ocapi/shop/hooks/basketHooks.js modifyGETResponse', function () {
    let originalRequest;
    let isScapi;
    let mappingMode;
    let moduleEnabled;
    let ocapiHelperStub;
    let coreApiHelperStub;
    let basketHooks;

    beforeEach(function () {
        originalRequest = global.request;
        isScapi = true;
        mappingMode = 'sfnext';
        moduleEnabled = true;
        global.request = {
            isSCAPI: function () {
                return isScapi;
            }
        };

        ocapiHelperStub = {
            setOverridePriceBooks: sinon.stub(),
            basketItemsModifyResponse: sinon.stub()
        };
        coreApiHelperStub = {
            pwaMappingValue: function () {
                return mappingMode;
            },
            sendOverrideShippingMethods: sinon.stub()
        };

        basketHooks = proxyquire(
            '../../../../../cartridge/scripts/ocapi/shop/hooks/basketHooks',
            {
                'dw/system/Status': function () {},
                'dw/system/Logger': {},
                'dw/system/Transaction': {},
                '*/cartridge/scripts/util/collections': {},
                '*/cartridge/scripts/helper/eswCoreApiHelper': coreApiHelperStub,
                '*/cartridge/scripts/helper/eswOCAPIHelperHL': ocapiHelperStub,
                '*/cartridge/scripts/helper/eswCoreHelper': {
                    getEswHelper: {
                        getEShopWorldModuleEnabled: function () {
                            return moduleEnabled;
                        }
                    }
                },
                '*/cartridge/scripts/util/Constants': { SFNEXT_MAPPING_MODE: 'sfnext' }
            }
        );
    });

    afterEach(function () {
        if (originalRequest === undefined) {
            delete global.request;
        } else {
            global.request = originalRequest;
        }
    });

    it('sends override shipping methods and converts basket items for SFNext without resetting price books', function () {
        const basket = { id: 'basket' };
        const response = { id: 'response' };

        const result = basketHooks.modifyGETResponse(basket, response);

        expect(result).to.equal(undefined);
        expect(ocapiHelperStub.setOverridePriceBooks.called).to.equal(false);
        expect(coreApiHelperStub.sendOverrideShippingMethods.calledOnceWith(basket, response)).to.equal(true);
        expect(ocapiHelperStub.basketItemsModifyResponse.calledOnceWith(basket, response)).to.equal(true);
    });

    it('sets override price books before converting the basket for non-SFNext SCAPI requests', function () {
        mappingMode = 'pwa';
        const basket = {};

        basketHooks.modifyGETResponse(basket, {});

        expect(ocapiHelperStub.setOverridePriceBooks.calledOnceWith(basket)).to.equal(true);
        expect(ocapiHelperStub.setOverridePriceBooks.calledBefore(ocapiHelperStub.basketItemsModifyResponse)).to.equal(true);
    });

    it('does not set override price books for OCAPI requests', function () {
        isScapi = false;
        mappingMode = 'pwa';

        basketHooks.modifyGETResponse({}, {});

        expect(ocapiHelperStub.setOverridePriceBooks.called).to.equal(false);
        expect(ocapiHelperStub.basketItemsModifyResponse.calledOnce).to.equal(true);
    });

    it('only sends override shipping methods when the ESW module is disabled', function () {
        moduleEnabled = false;

        basketHooks.modifyGETResponse({}, {});

        expect(coreApiHelperStub.sendOverrideShippingMethods.calledOnce).to.equal(true);
        expect(ocapiHelperStub.basketItemsModifyResponse.called).to.equal(false);
    });
});
