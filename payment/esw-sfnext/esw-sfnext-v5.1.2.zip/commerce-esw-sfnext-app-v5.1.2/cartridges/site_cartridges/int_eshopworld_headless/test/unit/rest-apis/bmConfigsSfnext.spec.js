'use strict';

const chai = require('chai');
const expect = chai.expect;
const proxyquire = require('proxyquire').noCallThru();
const Constants = require('../../../../int_eshopworld_core/cartridge/scripts/util/Constants');
const globalNames = ['empty', 'request'];
let previousGlobals;

function makeHarness(mappingMode) {
    let responsePayload;
    global.empty = function (value) {
        return value === null || typeof value === 'undefined' || value === '' || (Array.isArray(value) && value.length === 0);
    };
    global.request = { httpParameters: { get: function () { return ['IE']; } } };

    const endpoint = proxyquire('../../../cartridge/rest-apis/product/bmConfigs', {
        'dw/system/Logger': { error: function () {} },
        'dw/system/Site': { getCurrent: function () { return { getPreferences: function () { return {}; } }; } },
        'dw/web/URLUtils': { url: function () { return 'mocked-url'; } },
        'dw/web/Resource': { msg: function () { return 'mocked-message'; } },
        'dw/util/Currency': { getCurrency: function () { return { symbol: 'EUR' }; } },
        'dw/system/RESTResponseMgr': {
            createSuccess: function (payload) {
                responsePayload = payload;
                return { render: function () {} };
            }
        },
        '*/cartridge/scripts/helper/eswBmHelper': {
            loadGroups: function () { return { attributes: [] }; }
        },
        '*/cartridge/scripts/helper/eswCoreHelper': {
            getEswHelper: {
                getCountryDetailByParam: function () {
                    return { countryCode: 'IE', defaultCurrencyCode: 'EUR', isFixedPriceModel: false, isSupportedByESW: true };
                },
                getCountryLocalizeObj: function () {
                    return { selectedFxRate: null, selectedRoundingRule: null, selectedCountryAdjustments: [] };
                },
                isEswEnabledSparkPricingConversion: function () { return false; },
                checkIsEswAllowedCountry: function () { return true; },
                getEShopWorldModuleEnabled: function () { return true; },
                isEswNativeShippingHidden: function () { return false; },
                isSelectedCountryOverrideShippingEnabled: function () { return false; },
                getTopLevelDomain: function () { return 'eshopworld.com'; },
                isEswEnabledAbTasty: function () { return false; },
                isEswEnabledEmbeddedCheckout: function () { return false; },
                isEnabledMultiOrigin: function () { return mappingMode !== Constants.SFNEXT_MAPPING_MODE; },
                setLocation: function () {},
                createCookie: function () {},
                getBaseCurrencyPreference: function () { return 'USD'; }
            }
        },
        '*/cartridge/scripts/helper/eswCoreApiHelper': {
            pwaMappingValue: function () { return mappingMode; },
            getContentAssetIfOnline: function () { return ''; }
        },
        '*/cartridge/scripts/util/Constants': Constants
    });

    return { endpoint, getResponsePayload: function () { return responsePayload; } };
}

describe('BM configs multi-origin capability', function () {
    beforeEach(function () {
        previousGlobals = globalNames.map((name) => Object.getOwnPropertyDescriptor(global, name));
    });

    afterEach(function () {
        globalNames.forEach((name, index) => {
            if (previousGlobals[index]) Object.defineProperty(global, name, previousGlobals[index]);
            else delete global[name];
        });
    });

    it('reports multi-origin disabled to SFNext', function () {
        const harness = makeHarness(Constants.SFNEXT_MAPPING_MODE);

        harness.endpoint.getBmConfigs();

        expect(harness.getResponsePayload().eswBmConfigs.isEnabledMultiOrigin).to.equal(false);
    });

    it('preserves the configured multi-origin flag for PWA Kit', function () {
        const harness = makeHarness('pwa');

        harness.endpoint.getBmConfigs();

        expect(harness.getResponsePayload().eswBmConfigs.isEnabledMultiOrigin).to.equal(true);
    });
});