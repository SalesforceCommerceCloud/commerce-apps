
var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;

const SiteMock = require('../../../../../../../test/mocks/dw/system/Site');
var Status = require('../../../../../../../test/mocks/dw/system/Status');
var Transaction = require('../../../../../../../test/mocks/dw/system/Transaction');
var Request = require('../../../../../../../test/mocks/dw/system/Request');
const collections = require('../../../../../../../test/mocks/dw.util.CollectionHelper');
const LoggerMock = require('../../../../../../../test/mocks/dw/system/Logger');

describe('int_eshopworld_pwa/cartridge/scripts/ocapi/shop/basketHooks.js', function () {
    let mappingMode;
    let setOverridePriceBooksCalls;
    let multiOriginAddCalls;
    let multiOriginGroupCalls;
    var basketHooks = proxyquire('../../../../../cartridge/scripts/ocapi/shop/hooks/basketHooks', {
        'dw/system/Site': SiteMock,
        'dw/system/Logger': LoggerMock,
        'dw/system/Status': Status,
        '*/cartridge/scripts/helper/eswOCAPIHelperHL': {
            basketItemsModifyResponse: function () {return {}},
            sendOverrideShippingMethods: function () {return {}},
            addMultiOriginInfoToPLI: function () { multiOriginAddCalls++; return {}; },
            groupLineItemsByOrigin: function () { multiOriginGroupCalls++; },
            setOverridePriceBooks: function () {
                setOverridePriceBooksCalls++;
            }
        },
        '*/cartridge/scripts/util/collections': collections,
        '*/cartridge/scripts/helper/eswCoreApiHelper': {
            pwaMappingValue: function () {
                return mappingMode;
            },
            getHeadlessLocale: function () { return 'IE'; },
            sendOverrideShippingMethods: function () { return {}; }
        },
        'dw/system/Transaction': Transaction,
        '*/cartridge/scripts/helper/eswPwaCoreHelper': {
            getCountryDetailByParam: function () {
                return {};
            },
            getCountryLocalizeObj: function () {return {}},
        },
        '*/cartridge/scripts/helper/eswCoreHelper': {
            getEswHelper: {
                getCountryDetailByParam: function () {
                    return {};
                },
                getCountryLocalizeObj: function () {return {}},
                getEShopWorldModuleEnabled: function () { return true; },
                isEnabledMultiOrigin: function () { return mappingMode !== 'sfnext'; },
                eswPdpPriceConversions: function () { return {}; },
            }
        },
        '*/cartridge/scripts/helper/serviceHelperV3': {
            convertPromotionMessage: function () { return {}; },
        },
        '*/cartridge/scripts/helpers/basketCalculationHelpers': {
            calculateTotals: function () {}
        },
        '*/cartridge/scripts/util/Constants': { SFNEXT_MAPPING_MODE: 'sfnext' }

    });
    beforeEach(function () {
        mappingMode = 'pwa';
        setOverridePriceBooksCalls = 0;
        multiOriginAddCalls = 0;
        multiOriginGroupCalls = 0;
        global.request = {};
        global.request.isSCAPI = function () { return true; };
        global.request.httpParameters = { get: function () { return []; } };
        global.session = { privacy: {} };
    });

    it('does not set override price books from the basket GET response hook for SF Next', function () {
        mappingMode = 'sfnext';

        basketHooks.modifyGETResponse({}, {});

        expect(setOverridePriceBooksCalls).to.equal(0);
    });

    it('preserves override price book handling in the basket GET response hook for PWA Kit', function () {
        basketHooks.modifyGETResponse({}, {});

        expect(setOverridePriceBooksCalls).to.equal(1);
    });

    it('skips SFNext multi-origin basket processing while preserving PWA behavior', function () {
        const basket = { productLineItems: [] };
        mappingMode = 'sfnext';
        basketHooks.afterPOST(basket);
        expect(multiOriginAddCalls).to.equal(0);

        mappingMode = 'pwa';
        basketHooks.afterPOST(basket);
        expect(multiOriginAddCalls).to.equal(1);
    });

    it('does not group SFNext basket items by origin or return multi-origin errors', function () {
        mappingMode = 'sfnext';
        global.session.privacy.errorMessage = 'Inventory split failed';
        const response = {};

        basketHooks.modifyPOSTResponse({}, response);

        expect(multiOriginGroupCalls).to.equal(0);
        expect(response).not.to.have.property('c_MultiOriginProductAddUpdateError');
    });

    // Unit test
    it('modify promotion get response', function () {
        global.request.httpParameters = {
            'country-code': ['en-IE'],
            get: function () { return [] }
        };
        try {
            // Call the function under test
            let modifyGETResponse = basketHooks.modifyPOSTResponse({}, { calloutMsg: { locale: '' } });
            // Validate the response
            expect(modifyGETResponse).to.be.an('object');
        } catch (error) {
        }
    });
});
