var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;

var Status = require('../../../../../../../test/mocks/dw/system/Status');
var Transaction = require('../../../../../../../test/mocks/dw/system/Transaction');
var Logger = require('../../../../../../../test/mocks/dw/system/Logger');

describe('int_eshopworld_headless/cartridge/scripts/ocapi/shop/hooks/basketItemsUpdateResponse.js', function () {
    let mappingMode;
    let setOverridePriceBooksCalls;
    let basketItemsUpdateResponse;

    beforeEach(function () {
        mappingMode = 'pwa';
        setOverridePriceBooksCalls = 0;
        global.request = {
            isSCAPI: function () { return true; },
            httpParameters: {},
            SCAPIPathParameters: { get: function () { return 'line-1'; } }
        };
        global.session = { privacy: {} };
        global.empty = function (value) { return value === null || typeof value === 'undefined' || value === ''; };

        basketItemsUpdateResponse = proxyquire('../../../../../cartridge/scripts/ocapi/shop/hooks/basketItemsUpdateResponse', {
            'dw/system/Status': Status,
            'dw/system/Logger': Logger,
            'dw/system/Transaction': Transaction,
            '*/cartridge/scripts/helper/eswCoreHelper': {
                getEswHelper: {
                    getEShopWorldModuleEnabled: function () { return true; },
                    isEnabledMultiOrigin: function () { return mappingMode !== 'sfnext'; },
                    getCountryDetailByParam: function () {
                        return { countryCode: 'IE', isFixedPriceModel: true };
                    },
                    updateShopperBasketCurrency: function () {},
                    applyOverrideShipping: function () {},
                    eswInfoLogger: function () {}
                }
            },
            '*/cartridge/scripts/helper/eswMultiOriginHelper': {},
            '*/cartridge/scripts/helper/eswOCAPIHelperHL': {
                setOverridePriceBooks: function () { setOverridePriceBooksCalls++; },
                basketItemsModifyResponse: function () {}
            },
            '*/cartridge/scripts/util/collections': {
                find: function (items, callback) { return items.find(callback); }
            },
            '*/cartridge/scripts/helpers/basketCalculationHelpers': {},
            '*/cartridge/scripts/helper/eswCoreApiHelper': {
                pwaMappingValue: function () { return mappingMode; }
            },
            '*/cartridge/scripts/util/Constants': { SFNEXT_MAPPING_MODE: 'sfnext' }
        });
    });

    it('sets override price books before adding basket items for SF Next', function () {
        mappingMode = 'sfnext';
        basketItemsUpdateResponse.beforePOST({ custom: {}, shipments: [{ shippingMethodID: 'standard' }] });
        expect(setOverridePriceBooksCalls).to.equal(1);
    });

    it('does not add SF Next price book handling to PWA Kit item requests', function () {
        basketItemsUpdateResponse.beforePOST({ custom: {}, shipments: [{ shippingMethodID: 'standard' }] });
        expect(setOverridePriceBooksCalls).to.equal(0);
    });

    it('does not retain multi-origin quantity state for SFNext basket updates', function () {
        mappingMode = 'sfnext';
        basketItemsUpdateResponse.beforePATCH({
            productLineItems: [{ UUID: 'line-1', quantity: { value: 2 } }]
        });
        expect(global.session.privacy.alreadyAddedQuantityInCart).to.equal(undefined);
    });

    it('preserves multi-origin quantity state for PWA Kit basket updates', function () {
        basketItemsUpdateResponse.beforePATCH({
            productLineItems: [{ UUID: 'line-1', quantity: { value: 2 } }]
        });
        expect(global.session.privacy.alreadyAddedQuantityInCart).to.equal(2);
    });
});