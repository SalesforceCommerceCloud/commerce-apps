
var chai = require('chai');
var proxyquire = require('proxyquire').noCallThru();
var expect = chai.expect;
var sinon = require('sinon');
var stubURLUtils = sinon.stub();

const SiteMock = require('../../../../../../../test/mocks/dw/system/Site');
var Status = require('../../../../../../../test/mocks/dw/system/Status');
var Transaction = require('../../../../../../../test/mocks/dw/system/Transaction');
const URLUtilsMock = require('../../../../../../../test/mocks/dw/web/URLUtils');

describe('int_eshopworld_headless/cartridge/scripts/ocapi/shop/orderHooks.js', function () {
    var updateBreakPaymentOrderResponse = sinon.spy();
    var combineProductItems = sinon.stub().returns([]);
    let mappingMode;
    let originalEmpty;
    var orderHooks = proxyquire('../../../../../cartridge/scripts/ocapi/shop/hooks/orderHooks', {
        'dw/system/Site': SiteMock,
        'dw/system/Status': Status,
        'dw/web/URLUtils': URLUtilsMock,
        '*/cartridge/scripts/helper/eswCoreApiHelper': {
            combineProductItems: combineProductItems,
            pwaMappingValue: function () { return mappingMode; }
        },
        '*/cartridge/scripts/helper/eswOCAPIHelperHL': {
            basketItemsModifyResponse: function () { return {}; },
            basketModifyGETResponse_v2: function () { return {}; },
            getCountryDetailByParam: function () {
                return {};
            },
            deleteBasketItem: function () { return {}; },
            handleEswPreOrderCall: function () { return {}; },
            setOverridePriceBooks: function () { return {}; },
            handleEswOrderAttributes: function () { return {}; },
            handleEswBasketAttributes: function () { return {}; },
            handleEswOrdersHistoryCall: function () { return {}; },
            handleEswOrderDetailCall: function () { return {}; },
            updateBreakPaymentOrderResponse: updateBreakPaymentOrderResponse
        },
        'dw/web/URLUtils': stubURLUtils,
        'dw/system/Transaction': Transaction,
        '*/cartridge/scripts/helper/eswPwaCoreHelper': {
            getCountryDetailByParam: function () {
                return {};
            }
        },
        '*/cartridge/scripts/helper/eswCoreHelper': {
            getEswHelper: {
                getCatalogUploadMethod: function () { return 'api'; },
                getEShopWorldModuleEnabled: function () { return true; },
                isEswEnabledEmbeddedCheckout: function () { return true; },
                isCheckoutRegisterationEnabled: function () { return false; },
                isEnabledMultiOrigin: function () { return mappingMode !== 'sfnext'; }
            }
        },
    });

    beforeEach(function () {
        originalEmpty = global.empty;
        mappingMode = 'pwa';
        global.request = {
            isSCAPI: function () { return false; }
        };
        global.empty = function (value) { return value === null || typeof value === 'undefined' || value === ''; };
        updateBreakPaymentOrderResponse.resetHistory();
        combineProductItems.resetHistory();
    });

    afterEach(function () {
        if (typeof originalEmpty === 'undefined') delete global.empty;
        else global.empty = originalEmpty;
    });

    // Unit test
    it('modify basket before calling server', function () {
        let beforePOST = orderHooks.beforePOST({}, {});
        expect(beforePOST).to.be.an('object');
    });
    it('modify basket after calling server', function () {
        let afterPOST = orderHooks.afterPOST({}, {});
        expect(afterPOST).to.be.an('object');
    });
    it('modify basket post response', function () {
        let modifyPOSTResponse = orderHooks.modifyPOSTResponse({}, {});
        expect(modifyPOSTResponse).to.be.an('object');
    });
    it('modify basket get response', function () {
        let modifyGETResponse = orderHooks.modifyGETResponse_v2({}, {});
        expect(modifyGETResponse).to.be.an('object');
    });

    it('does not combine order history items for SFNext', function () {
        mappingMode = 'sfnext';
        global.request.isSCAPI = function () { return true; };
        const orderResponse = { productItems: [] };

        orderHooks.modifyGETResponse_v2({}, orderResponse);

        expect(combineProductItems.called).to.equal(false);
    });

    it('preserves order history item combination for PWA Kit', function () {
        global.request.isSCAPI = function () { return true; };
        const orderResponse = { productItems: [] };

        orderHooks.modifyGETResponse_v2({}, orderResponse);

        expect(combineProductItems.calledOnce).to.equal(true);
    });
    it('modify basket response', function () {
        let modifyGETResponse = orderHooks.modifyGETResponse({}, {});
        expect(modifyGETResponse).to.be.an('object');
        expect(updateBreakPaymentOrderResponse.calledOnce).to.equal(true);
        expect(updateBreakPaymentOrderResponse.firstCall.args).to.deep.equal([{}, undefined]);
    });
});
