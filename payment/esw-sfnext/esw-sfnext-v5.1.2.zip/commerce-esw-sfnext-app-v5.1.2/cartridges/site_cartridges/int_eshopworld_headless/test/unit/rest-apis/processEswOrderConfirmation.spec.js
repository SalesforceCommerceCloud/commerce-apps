'use strict';

const chai = require('chai');
const expect = chai.expect;
const sinon = require('sinon');
const proxyquire = require('proxyquire').noCallThru();
const eswLogHelper = require('../../../../int_eshopworld_core/cartridge/scripts/helper/eswLogHelper');
const globalNames = ['empty', 'request', 'customer', 'session'];
let previousGlobals;

const endpointPath = '../../../cartridge/rest-apis/product/processEswOrderConfirmation';

function makeOrder(status, confirmationStatus) {
    return {
        status: { value: status },
        confirmationStatus: { value: confirmationStatus },
        shipments: [{ shippingMethodID: 'standard' }],
        productLineItems: [],
        setConfirmationStatus: sinon.spy(),
        setExportStatus: sinon.spy(),
        setPaymentStatus: sinon.spy()
    };
}

function makeHarness(options) {
    const settings = options || {};
    const sanitizeLogMessage = sinon.spy(eswLogHelper.sanitizeLogMessage);
    const order = settings.order || null;
    const payload = {
        retailerCartId: 'order-123',
        eShopWorldOrderNumber: 'esw-456',
        checkoutTotal: { shopper: { currency: 'USD', amount: '25.00' } },
        paymentDetails: { methodCardBrand: 'VISA' },
        deliveryCountryIso: 'US',
        deliveryOption: { deliveryOption: 'standard' },
        contactDetails: settings.contactDetails || [],
        retailerCheckoutExperience: {
            metadataItems: settings.omitToken ? [] : [{ name: 'SecureOrderToken', value: settings.token || 'secure-token' }]
        }
    };
    const requestObject = { body: settings.malformedBody ? '{' : JSON.stringify({ Body: JSON.stringify(payload) }) };
    const errors = [];
    let successResponse;
    const orderMgr = {
        getOrder: sinon.stub().returns(order),
        undoFailOrder: sinon.stub().returns(settings.undoResult || { error: false }),
        placeOrder: sinon.stub(),
        failOrder: sinon.stub()
    };
    if (settings.undoThrows) {
        orderMgr.undoFailOrder.throws(new Error('undo failed'));
    }
    const eswHelper = {
        eswInfoLogger: sinon.spy(),
        isValidEswAuthorization: sinon.stub().returns(settings.authorized !== false),
        isEswPostOrderSyncEnabled: sinon.stub().returns(false),
        isUpdateOrderPaymentStatusToPaidAllowed: sinon.stub().returns(true)
    };
    const ocHelper = {
        setOverridePriceBooks: sinon.stub(),
        setApplicableShippingMethods: sinon.stub(),
        updateEswOrderAttributesV3: sinon.stub(),
        updateEswOrderAttributesV2: sinon.stub(),
        updateShopperAddressDetails: sinon.stub(),
        updateEswPaymentAttributes: sinon.stub(),
        updateSfccPromotionPriceUponOrderConfirmation: sinon.stub(),
        processKonbiniOrderConfirmation: sinon.stub().returns(false),
        saveAddressinAddressBook: sinon.stub()
    };
    const responseMgr = {
        createError: function (status) {
            const response = { status, custom: {}, render: sinon.spy() };
            errors.push(response);
            return response;
        },
        createSuccess: function (response) {
            successResponse = response;
            return { render: sinon.spy() };
        }
    };

    global.empty = function (value) {
        return value === null || typeof value === 'undefined' || value === '' || value === false;
    };
    global.request = requestObject;
    global.customer = {};
    global.session = {};

    const endpoint = proxyquire(endpointPath, {
        'dw/system/RESTResponseMgr': responseMgr,
        'dw/system/Transaction': { wrap: function (callback) { callback(); } },
        'dw/order/OrderMgr': orderMgr,
        'dw/order/Order': {
            ORDER_STATUS_FAILED: 'FAILED',
            ORDER_STATUS_CREATED: 'CREATED',
            CONFIRMATION_STATUS_CONFIRMED: 'CONFIRMED',
            CONFIRMATION_STATUS_NOTCONFIRMED: 'NOT_CONFIRMED',
            EXPORT_STATUS_NOTEXPORTED: 'NOT_EXPORTED',
            EXPORT_STATUS_READY: 'READY',
            PAYMENT_STATUS_NOTPAID: 'NOT_PAID',
            PAYMENT_STATUS_PAID: 'PAID'
        },
        'dw/system/Logger': { getLogger: () => ({ error: sinon.stub() }) },
        'server/request': function Request(request) { this.body = request.body; },
        '*/cartridge/scripts/helper/eswCoreHelper': { getEswHelper: eswHelper },
        '*/cartridge/scripts/helper/eswLogHelper': { sanitizeLogMessage },
        '*/cartridge/scripts/helper/eswControllersHelper': { getCartItem: sinon.stub() },
        '*/cartridge/scripts/helper/orderConfirmationHelper': { getEswOcHelper: () => ocHelper }
    });

    return { endpoint, orderMgr, ocHelper, payload, errors, sanitizeLogMessage, responseLog: eswHelper.eswInfoLogger, getSuccessResponse: () => successResponse };
}

function expectSanitizedResponseLog(harness, response) {
    const sanitization = harness.sanitizeLogMessage.withArgs(response);
    const responseLog = harness.responseLog.withArgs('Esw Order Confirmation Response');
    expect(sanitization.calledOnceWithExactly(response)).to.equal(true);
    expect(responseLog.calledOnceWithExactly(
        'Esw Order Confirmation Response', sanitization.firstCall.returnValue
    )).to.equal(true);
}

describe('processEswOrderConfirmation', function () {
    beforeEach(function () {
        previousGlobals = globalNames.map((name) => Object.getOwnPropertyDescriptor(global, name));
    });

    afterEach(function () {
        globalNames.forEach((name, index) => {
            if (previousGlobals[index]) Object.defineProperty(global, name, previousGlobals[index]);
            else delete global[name];
        });
    });

    it('preserves sanitized array payloads with Rhino-style numeric JSON keys', function () {
        const order = makeOrder('CREATED', 'NOT_CONFIRMED');
        const harness = makeHarness({ order });
        const stringify = JSON.stringify;
        let numericKeyCount = 0;
        const stringifyStub = sinon.stub(JSON, 'stringify').callsFake(function (value, replacer, space) {
            if (typeof replacer !== 'function') {
                return stringify(value, replacer, space);
            }
            return stringify(value, function (key, entry) {
                if (Array.isArray(this)) {
                    numericKeyCount++;
                    return replacer.call(this, Number(key), entry);
                }
                return replacer.call(this, key, entry);
            }, space);
        });

        try {
            harness.endpoint.processEswOrderConfirmation();

            const expectedPayload = JSON.parse(stringify(harness.payload));
            expectedPayload.retailerCheckoutExperience.metadataItems[0].value = '[REDACTED]';
            const requestLog = harness.responseLog.withArgs('Esw Order Confirmation Request Payload');
            expect(requestLog.calledOnce).to.equal(true);
            expect(JSON.parse(requestLog.firstCall.args[1])).to.deep.equal(expectedPayload);
            expect(JSON.parse(eswLogHelper.sanitizeLogMessage(stringify(harness.payload)))).to.deep.equal(expectedPayload);
            expect(numericKeyCount).to.be.above(0);
            expect(harness.payload.retailerCheckoutExperience.metadataItems[0].value).to.equal('secure-token');
            expect(harness.orderMgr.getOrder.calledOnceWithExactly('order-123', 'secure-token')).to.equal(true);
            expect(harness.orderMgr.placeOrder.calledOnceWithExactly(order)).to.equal(true);
            expectSanitizedResponseLog(harness, harness.getSuccessResponse());
        } finally {
            stringifyStub.restore();
        }
    });

    it('logs and rejects an unauthorized confirmation', function () {
        const harness = makeHarness({ authorized: false });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.errors[0].status).to.equal(401);
        expect(harness.errors[0].custom.ResponseText).to.equal('Authentication Failed');
        expect(harness.orderMgr.getOrder.called).to.equal(false);
        expect(harness.responseLog.withArgs('Esw Order Confirmation Request Payload').called).to.equal(false);
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
    });

    it('logs a server error response for malformed JSON', function () {
        const harness = makeHarness({ malformedBody: true });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.errors[0].status).to.equal(500);
        expect(harness.errors[0].custom.ResponseText).to.equal('Request Failed');
        expect(harness.orderMgr.getOrder.called).to.equal(false);
        expect(harness.responseLog.withArgs('Esw Order Confirmation Request Payload').called).to.equal(false);
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
    });

    it('logs the sanitized incoming payload without changing order processing data', function () {
        const order = makeOrder('CREATED', 'NOT_CONFIRMED');
        const contactDetails = [{
            firstName: 'Test Shopper',
            email: 'shopper@example.test',
            address: { city: 'Test City', address1: '123 Test Street' }
        }];
        const harness = makeHarness({ order, contactDetails });

        harness.endpoint.processEswOrderConfirmation();

        const requestLog = harness.responseLog.withArgs('Esw Order Confirmation Request Payload');
        expect(requestLog.calledOnce).to.equal(true);
        expect(harness.sanitizeLogMessage.firstCall.calledWithExactly(harness.payload)).to.equal(true);
        expect(requestLog.firstCall.args[1]).to.equal(harness.sanitizeLogMessage.firstCall.returnValue);
        const loggedPayload = JSON.parse(requestLog.firstCall.args[1]);
        expect(loggedPayload.retailerCartId).to.equal('order-123');
        expect(loggedPayload.eShopWorldOrderNumber).to.equal('esw-456');
        expect(loggedPayload.contactDetails).to.deep.equal([{
            firstName: '[REDACTED]',
            email: '[REDACTED]',
            address: '[REDACTED]'
        }]);
        expect(loggedPayload.retailerCheckoutExperience.metadataItems[0].value).to.equal('[REDACTED]');
        expect(harness.orderMgr.getOrder.calledOnceWithExactly('order-123', 'secure-token')).to.equal(true);
        expect(harness.ocHelper.updateShopperAddressDetails.calledOnceWithExactly(contactDetails, order)).to.equal(true);
        expect(harness.orderMgr.placeOrder.calledOnceWithExactly(order)).to.equal(true);
        expectSanitizedResponseLog(harness, harness.getSuccessResponse());
    });

    it('returns a client error when SecureOrderToken is missing', function () {
        const harness = makeHarness({ omitToken: true });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.errors[0].status).to.equal(400);
        expect(harness.errors[0].custom.ResponseText).to.equal('SecureOrderToken is required');
        expect(harness.responseLog.withArgs('Esw Order Confirmation Request Payload').calledOnce).to.equal(true);
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
        expect(harness.orderMgr.getOrder.called).to.equal(false);
        expect(harness.orderMgr.placeOrder.called).to.equal(false);
    });

    it('rejects a wrong order token when the order lookup fails', function () {
        const harness = makeHarness({ token: 'wrong-token' });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.orderMgr.getOrder.calledOnceWithExactly('order-123', 'wrong-token')).to.equal(true);
        expect(harness.errors[0].status).to.equal(400);
        expect(harness.errors[0].custom.ResponseText).to.equal('Order not found');
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
        expect(harness.orderMgr.placeOrder.called).to.equal(false);
    });

    it('rejects an already-confirmed order', function () {
        const order = makeOrder('CREATED', 'CONFIRMED');
        const harness = makeHarness({ order });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.errors[0].status).to.equal(409);
        expect(harness.errors[0].custom.ResponseText).to.equal('Order already exists');
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
        expect(harness.orderMgr.placeOrder.called).to.equal(false);
        expect(order.setConfirmationStatus.called).to.equal(false);
        expect(order.setExportStatus.called).to.equal(false);
        expect(order.setPaymentStatus.called).to.equal(false);
    });

    it('returns a conflict when undoFailOrder reports an error', function () {
        const order = makeOrder('FAILED', 'NOT_CONFIRMED');
        const harness = makeHarness({ order, undoResult: { error: true } });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.errors[0].status).to.equal(409);
        expect(harness.errors[0].custom.ResponseText).to.equal('Error: Inventory Reservation Failed');
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
    });

    it('converts an undoFailOrder exception into a server error response', function () {
        const order = makeOrder('FAILED', 'NOT_CONFIRMED');
        const harness = makeHarness({ order, undoThrows: true });

        expect(() => harness.endpoint.processEswOrderConfirmation()).not.to.throw();
        expect(harness.errors[0].status).to.equal(500);
        expect(harness.errors[0].custom.ResponseText).to.equal('Request Failed');
        expectSanitizedResponseLog(harness, harness.errors[0].custom);
    });

    it('confirms a created order with a valid authorization and token', function () {
        const order = makeOrder('CREATED', 'NOT_CONFIRMED');
        const harness = makeHarness({ order });

        harness.endpoint.processEswOrderConfirmation();

        expect(harness.getSuccessResponse()).to.include({ OrderNumber: 'order-123', ResponseCode: '200' });
        expectSanitizedResponseLog(harness, {
            OrderNumber: 'order-123',
            EShopWorldOrderNumber: 'esw-456',
            ResponseCode: '200',
            ResponseText: 'Success'
        });
        expect(harness.orderMgr.placeOrder.calledOnceWithExactly(order)).to.equal(true);
        expect(order.setConfirmationStatus.calledWith('CONFIRMED')).to.equal(true);
    });
});