'use strict';

/**
 * Builds a minimal dw request mock used by getHeadlessLocale specs.
 * @param {Object} [options] - request options
 * @param {Object} [options.headers] - HTTP headers keyed by name
 * @param {Object} [options.params] - httpParameterMap values keyed by name
 * @param {string} [options.httpMethod] - HTTP method, defaults to GET
 * @param {string} [options.body] - raw request body
 * @returns {Object} request mock
 */
module.exports = function headlessRequest(options) {
    var opts = options || {};
    var headers = opts.headers || {};
    var params = opts.params || {};
    return {
        httpMethod: opts.httpMethod || 'GET',
        httpHeaders: {
            get: function (name) {
                return headers[name] || null;
            }
        },
        httpParameterMap: {
            requestBodyAsString: opts.body || null,
            get: function (name) {
                return params[name] ? { value: params[name] } : null;
            }
        }
    };
};
