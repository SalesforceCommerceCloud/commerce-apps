function getOrderMock(overrides) {
    var order = {
        orderNo: '00012345',
        customer: {
            ID: 'customer123',
            email: 'test@example.com'
        },
        confirmationStatus: null,
        exportStatus: null,
        paymentStatus: null,
        setConfirmationStatus: function (status) {
            this.confirmationStatus = status;
        },
        setExportStatus: function (status) {
            this.exportStatus = status;
        },
        setPaymentStatus: function (status) {
            this.paymentStatus = status;
        },
        getUUID: function () {
            return 'mock-uuid-123';
        }
        // Add more properties/methods as needed for your tests
    };

    // Allow overriding defaults for specific test cases
    if (overrides && typeof overrides === 'object') {
        Object.keys(overrides).forEach(function (key) {
            order[key] = overrides[key];
        });
    }

    return order;
}

module.exports = getOrderMock;
