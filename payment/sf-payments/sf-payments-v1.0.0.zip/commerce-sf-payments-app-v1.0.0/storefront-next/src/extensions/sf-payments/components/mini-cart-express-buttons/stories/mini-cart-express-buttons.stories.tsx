/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type React from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import MiniCartExpressButtons from '../index';

const meta = {
    title: 'SF Payments/Mini Cart Express Buttons',
    component: MiniCartExpressButtons,
    parameters: {
        layout: 'centered',
    },
    tags: ['autodocs'],
} satisfies Meta<typeof MiniCartExpressButtons>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Default mini-cart express buttons with a typical basket.
 * Vertical layout with maximum 3 buttons optimized for drawer UI.
 */
export const Default: Story = {
    decorators: [
        (Story: React.ComponentType) => (
            <div className="w-80 bg-card p-4 rounded-lg border">
                <Story />
            </div>
        ),
    ],
};

/**
 * Mini-cart express buttons without billing address.
 * Falls back to locale-derived country code.
 */
export const NoBillingAddress: Story = {
    decorators: [
        (Story: React.ComponentType) => (
            <div className="w-80 bg-card p-4 rounded-lg border">
                <Story />
            </div>
        ),
    ],
};

/**
 * International transaction with EUR currency and Germany as country.
 */
export const InternationalTransaction: Story = {
    decorators: [
        (Story: React.ComponentType) => (
            <div className="w-80 bg-card p-4 rounded-lg border">
                <Story />
            </div>
        ),
    ],
};

/**
 * Edge case: No basket available.
 * Component returns null (nothing rendered).
 */
export const NoBasket: Story = {
    decorators: [
        (Story: React.ComponentType) => (
            <div className="w-80 bg-card p-4 rounded-lg border">
                <p className="text-sm text-muted-foreground mb-4">No basket available - component returns null</p>
                <Story />
            </div>
        ),
    ],
};

/**
 * High-value transaction (testing large amounts).
 */
export const LargeOrder: Story = {
    decorators: [
        (Story: React.ComponentType) => (
            <div className="w-80 bg-card p-4 rounded-lg border">
                <Story />
            </div>
        ),
    ],
};

/**
 * Fallback to productTotal when orderTotal is undefined.
 */
export const ProductTotalFallback: Story = {
    decorators: [
        (Story: React.ComponentType) => (
            <div className="w-80 bg-card p-4 rounded-lg border">
                <p className="text-xs text-muted-foreground mb-4">
                    orderTotal is undefined, using productTotal ($75.50)
                </p>
                <Story />
            </div>
        ),
    ],
};
