/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback } from 'react';
import { useFetcher } from 'react-router';
import { useFetcherPromise } from './use-fetcher-promise';

export interface FailureRecoveryResult {
    basketRecovered: boolean;
    orderNo: string;
}

type FailOrderResponse = { success: true; basketRecovered: boolean } | { success: false; error?: string };

/**
 * Shared hook for failing an order and recovering the basket after payment failure.
 *
 * Calls `/action/sf-payments-fail-order`. Never throws — network or SCAPI errors
 * resolve as `{ basketRecovered: false }`.
 *
 * Idempotency guard (failOrderCalledRef) is intentionally NOT in this hook — it
 * must live in the consuming component so resets are scoped to that component's
 * session.
 *
 * Single-in-flight invariant: calling failAndRecover a second time before the first
 * resolves abandons the first promise. Consumers must ensure at most one call is
 * in flight at a time — the component-local failOrderCalledRef guard satisfies this.
 */
export function useSFPaymentsFailureRecovery(): {
    failAndRecover: (orderNo: string, flow?: 'express' | 'sheet') => Promise<FailureRecoveryResult>;
} {
    const fetcher = useFetcher<FailOrderResponse>();
    const awaitResult = useFetcherPromise(fetcher, 'fail-order action did not respond');

    const failAndRecover = useCallback(
        async (orderNo: string, flow?: 'express' | 'sheet'): Promise<FailureRecoveryResult> => {
            if (!orderNo) return { basketRecovered: false, orderNo };
            try {
                const form = new FormData();
                form.set('orderNo', orderNo);
                if (flow) form.set('flow', flow);
                void fetcher.submit(form, { method: 'POST', action: '/action/sf-payments-fail-order' });
                const result = await awaitResult();
                return {
                    basketRecovered: result?.success === true ? result.basketRecovered : false,
                    orderNo,
                };
            } catch {
                return { basketRecovered: false, orderNo };
            }
        },
        [fetcher, awaitResult]
    );

    return { failAndRecover };
}
