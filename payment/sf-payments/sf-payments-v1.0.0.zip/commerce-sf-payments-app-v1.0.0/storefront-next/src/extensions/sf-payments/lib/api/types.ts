/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Client-safe type definitions shared by `lib/api/*.server` mutations and the
 * client-side hooks/components that call those mutations through action
 * routes. Server modules use the `.server.ts` suffix so that React Router's
 * Vite plugin rejects accidental client imports — but client code still needs
 * the wire shapes, so they live here.
 */

/**
 * Minimal payment config shape needed when building a SF Payments instrument.
 * Mirrors the fields this module consumes from the full
 * `shopperPayments.getPaymentConfiguration` response.
 */
export interface PaymentConfig {
    // SCAPI marks zoneId optional and may return it as null; typed as
    // `string | null` so consumers see the real wire shape.
    zoneId?: string | null;
    paymentMethods?: Array<{ paymentMethodType: string; accountId: string }>;
    paymentMethodSetAccounts?: Array<{ accountId: string; vendor: string }>;
}
