/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import type { LoaderFunctionArgs } from 'react-router';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { getLogger } from '@/lib/logger.server';

/**
 * Transforms relative icon paths in payment metadata to absolute URLs.
 */
function transformIconPaths(data: Record<string, unknown>, baseHost: string): Record<string, unknown> {
    const baseUrl = `https://${baseHost}/on/demandware.static/Sites-Site/-/-/internal`;
    const methodTypes = (data?.paymentMethodTypes ?? {}) as Record<string, { images?: { src?: string }[] }>;

    for (const method of Object.values(methodTypes)) {
        for (const image of method.images ?? []) {
            if (image.src?.startsWith('/icons/')) {
                image.src = `${baseUrl}${image.src}`;
            }
        }
    }

    return data;
}

/**
 * Server-to-server proxy that fetches the static payment metadata JSON
 * from the Commerce Cloud instance. This is the SDK's rendering blueprint —
 * instrument type definitions, gateway mappings, Express vs Multistep modes.
 *
 * The metadataUrl is configured in config.server.ts under sfPayments.metadataUrl
 * and is kept server-only so the merchant's Commerce Cloud host isn't exposed
 * to the browser. The client never reads metadataUrl directly — it just calls
 * this route.
 *
 * Note: `sdkUrl` is intentionally NOT included in this response. It's static
 * config and the client reads it synchronously via `useConfig()` in the SF
 * Payments provider so the SDK script can start loading on first render in
 * parallel with this fetch, rather than waiting for it.
 *
 * GET /resource/sf-payments-metadata
 */
export async function loader({ context }: LoaderFunctionArgs) {
    try {
        const config = getConfig<{ sfPayments?: { metadataUrl?: string } }>(context);
        const sfPayments = config.sfPayments;

        if (!sfPayments?.metadataUrl) {
            getLogger(context).error('[sf-payments] metadataUrl not configured in config.server.ts');
            return Response.json({ error: 'Payment metadata URL not configured in config.server.ts' }, { status: 501 });
        }

        const response = await fetch(sfPayments.metadataUrl, {
            headers: { Accept: 'application/json' },
        });

        if (!response.ok) {
            throw new Error(`Metadata fetch failed: ${response.status}`);
        }

        const data = (await response.json()) as Record<string, unknown>;
        const hostname = new URL(sfPayments.metadataUrl).hostname;

        return Response.json({
            metadata: transformIconPaths(data, hostname),
        });
    } catch (error) {
        getLogger(context).error('[sf-payments] fetch payment metadata failed', {
            message: error instanceof Error ? error.message : String(error),
        });

        return Response.json(
            {
                error: 'Failed to fetch metadata',
                details: error instanceof Error ? error.message : 'Unknown error',
            },
            { status: 500 }
        );
    }
}
