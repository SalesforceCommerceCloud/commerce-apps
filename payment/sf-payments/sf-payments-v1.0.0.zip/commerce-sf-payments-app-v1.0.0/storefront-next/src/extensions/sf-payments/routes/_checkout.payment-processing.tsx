/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

/**
 * Payment Processing Route — /payment-processing
 *
 * Lives under the `_checkout` pathless layout (minimal header) but NOT under
 * `_checkout.checkout` (the basket-guarded layout). After order creation the
 * basket is consumed, so inheriting that layout would trigger a "No items"
 * redirect before the loader can run.
 *
 * Landing page for redirect-based payment methods. The gateway appends
 * `redirect_status` and gateway-specific params to the return URL; our
 * `buildPaymentProcessingUrl` adds `orderNo`, `type`, and `zoneId`.
 *
 * Loader logic (server-side):
 *   - `vendor=Stripe` (any/absent status)     → gateway-redirect; client calls sfp.handleRedirect()
 *   - `vendor=Adyen` + `redirectResult`      → handleAdyenRedirect server-side → success or error state
 *   - `vendor=Adyen` (no redirectResult)     → attemptFailOrder + error state
 *   - no vendor                               → attemptFailOrder + error state; component goes to checkout
 *   - `orderNo` absent                       → immediate redirect to checkout
 */

import { useCallback, useEffect, useRef } from 'react';
import { type LoaderFunctionArgs, redirect, useLoaderData } from 'react-router';
import { useTranslation } from 'react-i18next';
import { getLogger } from '@/lib/logger.server';
import { useNavigate } from '@/hooks/use-navigate';
import { useToast } from '@/components/toast';
import { useSFPaymentsContext } from '../providers/sf-payments-provider';
import { useSFPaymentsFailureRecovery } from '../hooks/use-sf-payments-failure-recovery';
import { attemptFailOrder, handleAdyenRedirect } from '../lib/api/order-mutations.server';

/** Matches `STATUS_SUCCESS = 0` exported from the SF Payments SDK . */
const SDK_RESPONSE_SUCCESS = 0;
const REDIRECT_ERROR_TOAST_DURATION_MS = 8000;
const STRIPE_VENDOR = 'Stripe';
const ADYEN_VENDOR = 'Adyen';
type LoaderData =
    | { state: 'success'; orderNo: string }
    | { state: 'gateway-redirect'; orderNo: string; vendor: 'Stripe' }
    | { state: 'error' };

export async function loader({ request, context }: LoaderFunctionArgs): Promise<LoaderData | Response> {
    const url = new URL(request.url);
    const orderNo = url.searchParams.get('orderNo');
    const redirectStatus = url.searchParams.get('redirect_status');
    const redirectResult = url.searchParams.get('redirectResult');
    const vendor = url.searchParams.get('vendor');
    const logger = getLogger(context);

    if (!orderNo) {
        return redirect('/checkout');
    }

    // Stripe: delegate to sfp.handleRedirect() client-side for all redirect outcomes.
    if (vendor === STRIPE_VENDOR) {
        return { state: 'gateway-redirect', orderNo, vendor: 'Stripe' };
    }

    // Adyen: complete the redirect server-side by patching the PI with
    // `redirectResult`. Adyen appends this to the return URL after 3DS/bank redirect.
    if (vendor === ADYEN_VENDOR) {
        const paymentMethodType = url.searchParams.get('type');
        const zoneId = url.searchParams.get('zoneId');
        if (!redirectResult) {
            logger.warn('[sf-payments] payment-processing: Adyen redirect missing redirectResult', { orderNo });
            await attemptFailOrder(context, orderNo);
            return { state: 'error' };
        }
        if (!paymentMethodType || !zoneId) {
            logger.warn('[sf-payments] payment-processing: Adyen redirect missing type or zoneId', {
                orderNo,
                paymentMethodType,
                zoneId,
            });
            await attemptFailOrder(context, orderNo);
            return { state: 'error' };
        }
        try {
            const success = await handleAdyenRedirect(context, orderNo, redirectResult, paymentMethodType, zoneId);
            if (success) {
                return { state: 'success', orderNo };
            }
            logger.warn('[sf-payments] payment-processing: Adyen redirect non-success resultCode', { orderNo });
            await attemptFailOrder(context, orderNo);
            return { state: 'error' };
        } catch (err) {
            logger.error('[sf-payments] payment-processing: Adyen handleRedirect threw', {
                orderNo,
                message: String(err),
            });
            await attemptFailOrder(context, orderNo);
            return { state: 'error' };
        }
    }

    if (redirectStatus === 'succeeded') {
        return { state: 'success', orderNo };
    }

    const reason = redirectStatus ?? 'abandoned';
    logger.warn('[sf-payments] payment-processing: non-success return', { orderNo, redirectStatus: reason });
    await attemptFailOrder(context, orderNo);
    return { state: 'error' };
}

function PaymentProcessingView({ state }: { state: 'loading' | 'success' | 'error' }) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    return (
        <div className="flex min-h-screen items-center justify-center bg-background">
            <div className="w-full max-w-md space-y-6 p-6">
                <div className="text-center" role="status" aria-live="polite">
                    {state === 'loading' && (
                        <>
                            <div className="mb-4 flex justify-center">
                                <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                            </div>
                            <h1 className="text-2xl font-semibold">{t('sfPayments.paymentProcessing.loadingTitle')}</h1>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {t('sfPayments.paymentProcessing.loadingDescription')}
                            </p>
                        </>
                    )}

                    {state === 'success' && (
                        <>
                            <div className="mb-4 flex justify-center">
                                <svg
                                    className="h-12 w-12 text-success"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                    aria-hidden="true">
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M5 13l4 4L19 7"
                                    />
                                </svg>
                            </div>
                            <h1 className="text-2xl font-semibold">{t('sfPayments.paymentProcessing.successTitle')}</h1>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {t('sfPayments.paymentProcessing.successDescription')}
                            </p>
                        </>
                    )}

                    {state === 'error' && (
                        <>
                            <div className="mb-4 flex justify-center">
                                <svg
                                    className="h-12 w-12 text-destructive"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                    aria-hidden="true">
                                    <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M6 18L18 6M6 6l12 12"
                                    />
                                </svg>
                            </div>
                            <h1 className="text-2xl font-semibold">{t('sfPayments.paymentProcessing.errorTitle')}</h1>
                            <p className="mt-2 text-sm text-destructive">
                                {t('sfPayments.paymentProcessing.errorDescription')}
                            </p>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {t('sfPayments.paymentProcessing.errorRedirect')}
                            </p>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

async function handleStripeRedirect(sfp: {
    handleRedirect: () => Promise<{ responseCode: number }>;
}): Promise<boolean> {
    const result = await sfp.handleRedirect();
    return result?.responseCode === SDK_RESPONSE_SUCCESS;
}

export default function PaymentProcessingPage() {
    const data = useLoaderData<typeof loader>();
    const navigate = useNavigate();
    const { sfp } = useSFPaymentsContext();
    const { addToast } = useToast();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const { failAndRecover } = useSFPaymentsFailureRecovery();
    const isHandled = useRef(false);

    const navigateToCheckoutWithError = useCallback(() => {
        addToast(t('sfPayments.paymentProcessing.errorDescription'), 'error', {
            duration: REDIRECT_ERROR_TOAST_DURATION_MS,
        });
        void navigate('/checkout');
    }, [addToast, t, navigate]);

    useEffect(() => {
        if (isHandled.current) return;

        switch (data.state) {
            case 'success':
                isHandled.current = true;
                void navigate(`/order-confirmation/${data.orderNo}`);
                return;

            case 'error':
                isHandled.current = true;
                // Yield once so sonner's Toaster (at storefront root) has subscribed
                // before the toast fires — otherwise it's dropped on initial page load.
                void Promise.resolve().then(navigateToCheckoutWithError);
                return;

            case 'gateway-redirect':
                if (!sfp) {
                    return;
                }
                isHandled.current = true;
                void (async () => {
                    try {
                        const success = await handleStripeRedirect(sfp);
                        if (success) {
                            void navigate(`/order-confirmation/${data.orderNo}`);
                        } else {
                            await failAndRecover(data.orderNo);
                            navigateToCheckoutWithError();
                        }
                    } catch {
                        await failAndRecover(data.orderNo);
                        navigateToCheckoutWithError();
                    }
                })();
        }
    }, [data, sfp, navigate, navigateToCheckoutWithError, failAndRecover]);

    return <PaymentProcessingView state={data.state === 'gateway-redirect' ? 'loading' : data.state} />;
}
