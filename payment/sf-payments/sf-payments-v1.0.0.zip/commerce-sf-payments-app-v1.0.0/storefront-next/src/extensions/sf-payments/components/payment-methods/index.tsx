/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useFetcher } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useSite, resolvePrefix } from '@salesforce/storefront-next-runtime/site-context';
import { useConfig } from '@salesforce/storefront-next-runtime/config';
import { useBasket } from '@/providers/basket';
import { useAuth } from '@/providers/auth';
import { useNavigate } from '@/hooks/use-navigate';
import { usePaymentSubmissionRef } from '@/components/checkout/payment-submission-context';
import { useSFPaymentsContext } from '../../providers/sf-payments-provider';
import { useSFPaymentsConfig, type PaymentMethodSetAccount } from '../../hooks/use-sf-payments-config';
import type { ShopperCustomers } from '@/scapi';
import { useShopperConfigField, SHOPPER_CONFIG_DEFAULTS } from '../../hooks/use-sf-payments-shopper-config';
import { getLocaleDerivedCountryCode } from '../../lib/sf-payments-country';
import {
    getGatewayFromPaymentMethod,
    transformPaymentMethodReferences,
    type PaymentGateway,
    type PaymentMethodType,
    type SavedPaymentMethod,
} from '../../lib/sf-payments-utils';
import { buildTheme } from '../../lib/sf-payments-theme';
import { usePaymentMethodsCallbacks, type SFPCheckoutComponent } from './use-payment-methods-callbacks';
import type { SdkIntentPayload } from '../../lib/gateways/types';
import { createLogger } from '@/lib/logger';

const logger = createLogger();

interface SdkConfig {
    theme: Record<string, unknown>;
    actions: {
        createIntent: (paymentData?: Record<string, unknown>) => Promise<SdkIntentPayload>;
        onClick: () => void;
    };
    options: {
        savedPaymentMethods: SavedPaymentMethod[];
        useManualCapture: boolean;
        returnUrl: string;
        showSaveForFutureUsageCheckbox?: boolean;
        showSaveAsDefaultCheckbox?: boolean;
    };
}

/**
 * PaymentMethods — mounts the SF Payments SDK checkout surface on the Payment step.
 *
 * Registered at the `sfcc.checkout.payment.paymentMethods` UITarget, replacing the
 * OOTB CreditCardInputFields when the CAP is installed.
 *
 * This component handles the full payment flow: SDK initialization, order creation via
 * createIntent callback, and payment confirmation via confirmPayment.
 *
 * The component lives inside <ToggleCardEdit> in payment.tsx, which unmounts its
 * children when editing is false — no step-state check is needed here; mounting
 * is the gate.
 */
export default function PaymentMethods() {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { t } = useTranslation('extSfPayments' as any);
    const { enabled, sfp, metadata, metadataLoading } = useSFPaymentsContext();
    const basket = useBasket();
    const { site, locale } = useSite();
    const appConfig = useConfig<{ url?: { prefix?: string } }>();
    const paymentSubmissionRef = usePaymentSubmissionRef();
    const [confirmError, setConfirmError] = useState<string | null>(null);

    const currency = basket?.currency ?? '';
    const countryCode = getLocaleDerivedCountryCode(locale.id);

    const {
        config: paymentConfig,
        loading: paymentConfigLoading,
        error: paymentConfigError,
    } = useSFPaymentsConfig({ currency, countryCode });

    const { value: cardCaptureAutomatic, loading: shopperConfigLoading } = useShopperConfigField(
        'cardCaptureAutomatic',
        SHOPPER_CONFIG_DEFAULTS.cardCaptureAutomatic
    );

    const { value: futureUsageOffSession } = useShopperConfigField(
        'futureUsageOffSession',
        SHOPPER_CONFIG_DEFAULTS.futureUsageOffSession
    );

    const auth = useAuth();
    const isRegistered = auth?.userType === 'registered';

    const savedMethodsFetcher = useFetcher<ShopperCustomers.schemas['CustomerPaymentMethodReference'][]>();
    const savedMethodsFetcherLoad = savedMethodsFetcher.load;
    useEffect(() => {
        if (isRegistered) {
            void savedMethodsFetcherLoad('/resource/sf-payments-saved-methods');
        }
    }, [isRegistered, savedMethodsFetcherLoad]);
    // data is undefined until the fetch settles; the resource route always returns [] on error
    const savedMethodsReady = !isRegistered || savedMethodsFetcher.data !== undefined;

    const containerRef = useRef<HTMLDivElement>(null);
    const checkoutComponent = useRef<SFPCheckoutComponent | null>(null);
    const sdkConfigRef = useRef<SdkConfig | null>(null);

    const paymentMethodType = useRef<PaymentMethodType | ''>('');
    const storePaymentMethodRef = useRef(false);

    const gateway = useRef<PaymentGateway | null>(null);

    const sitePrefix = useMemo(
        () => resolvePrefix({ prefix: appConfig.url?.prefix ?? '', params: { siteId: site.id, localeId: locale.id } }),
        [appConfig.url?.prefix, site.id, locale.id]
    );
    const initialReturnUrl = `${typeof window !== 'undefined' ? window.location.origin : ''}${sitePrefix}/payment-processing`;

    const updateSdkReturnUrl = useCallback((params: Record<string, string>) => {
        if (!sdkConfigRef.current) return;
        const url = new URL(sdkConfigRef.current.options.returnUrl, window.location.origin);
        for (const [key, value] of Object.entries(params)) {
            url.searchParams.set(key, value);
        }
        sdkConfigRef.current.options.returnUrl = url.toString();
    }, []);

    const navigate = useNavigate();

    // Host reads its billing form via PaymentSubmissionRef.billingAddressGetter
    // and persists to the basket before onPlaceOrder — we just re-read it here
    // to shape the SDK's billingDetails payload (basket in closure is stale).
    // Warn once per checkout when the host bundle predates the field so MRT
    // deploy skew is visible in logs; order still places via
    // basket.billingAddress fallback (equivalent to pre-fix behavior).
    // Stable identity so downstream `confirmPayment` (and its onPlaceOrder
    // registration effect) don't re-run on every render.
    const getBillingAddress = useCallback(() => {
        const ref = paymentSubmissionRef.current;
        if (!('billingAddressGetter' in ref)) {
            logger.warn('[sf-payments] host ref missing billingAddressGetter — possible version skew');
            return null;
        }
        return ref.billingAddressGetter?.() ?? null;
    }, [paymentSubmissionRef]);

    const { createIntent, confirmPayment, onPaymentApprove } = usePaymentMethodsCallbacks({
        basket,
        paymentConfig,
        checkoutComponentRef: checkoutComponent,
        paymentMethodTypeRef: paymentMethodType,
        storePaymentMethodRef,
        futureUsageOffSession,
        sitePrefix,
        updateReturnUrl: updateSdkReturnUrl,
        getBillingAddress,
    });

    // Latest-value ref so the long-lived sfp:paymentapprove listener calls the
    // freshest onPaymentApprove (closes over current basket/config) without
    // re-binding the SDK each render.
    const onPaymentApproveRef = useRef(onPaymentApprove);
    useEffect(() => {
        onPaymentApproveRef.current = onPaymentApprove;
    }, [onPaymentApprove]);

    // ToggleCardEdit unmounts this component when editing is false, so no step-state guard is needed.
    useEffect(() => {
        if (!savedMethodsReady) return;
        if (checkoutComponent.current) return;
        if (!sfp || !metadata || !paymentConfig || shopperConfigLoading || !containerRef.current) return;

        const paymentMethodSetAccounts = (paymentConfig.paymentMethodSetAccounts ?? []).map(
            (account: PaymentMethodSetAccount) => ({ ...account, gatewayId: account.accountId })
        );
        const paymentMethodSet = {
            paymentMethods: paymentConfig.paymentMethods,
            paymentMethodSetAccounts,
        };
        const savedPaymentMethods = transformPaymentMethodReferences(
            savedMethodsFetcher.data ?? [],
            paymentConfig.paymentMethodSetAccounts ?? []
        );
        const config: SdkConfig = {
            theme: buildTheme(),
            actions: {
                createIntent,
                // No-op — sheet flow has no click-time validation to run.
                onClick: () => undefined,
            },
            options: {
                savedPaymentMethods,
                useManualCapture: !cardCaptureAutomatic,
                returnUrl: initialReturnUrl,
                showSaveForFutureUsageCheckbox: isRegistered,
                showSaveAsDefaultCheckbox: false,
            },
        };
        sdkConfigRef.current = config;
        const paymentRequest = {
            amount: basket?.orderTotal,
            currency,
            country: countryCode,
            locale: locale.id,
        };
        // Create a fresh inner element — the SDK renders into it directly
        const paymentElement = document.createElement('div');
        containerRef.current.replaceChildren(paymentElement);
        checkoutComponent.current = sfp.checkout(
            metadata,
            paymentMethodSet,
            config,
            paymentRequest,
            paymentElement
        ) as SFPCheckoutComponent;

        const el = containerRef.current;
        const onMethodSelected = (e: Event) => {
            const detail = (e as CustomEvent).detail;
            const methodType = detail?.selectedPaymentMethod || detail?.paymentMethodType;
            if (methodType) {
                paymentMethodType.current = methodType;
                gateway.current = getGatewayFromPaymentMethod(
                    methodType,
                    paymentConfig.paymentMethods,
                    paymentConfig.paymentMethodSetAccounts
                );
            }
            // Capture save preference when the shopper selects/changes payment method
            if (isRegistered && detail?.savePaymentMethodForFutureUse !== undefined) {
                storePaymentMethodRef.current = detail.savePaymentMethodForFutureUse === true;
            }
        };
        el.addEventListener('sfp:paymentmethodselected', onMethodSelected);

        // PayPal authorizes inside its popup before Place Order. On approve,
        // finalize the commerce order via the strategy and navigate. Stripe
        // and Adyen don't define `onApprove`, so the handler returns `{}` and
        // we stay on the page — their Place Order owns finalization.
        const onApprove = () => {
            void onPaymentApproveRef.current().then(({ orderNo, error }) => {
                if (error) {
                    logger.error('[sf-payments] sheet onPaymentApprove failed', {
                        basketId: basket?.basketId,
                        orderNo,
                        error,
                    });
                    // Surface the failure to the shopper via the same inline banner
                    // Place Order uses — the popup just closed and they're back
                    // on the checkout page with no other signal.
                    setConfirmError(error || t('paymentMethods.errorConfirmationFailed'));
                    return;
                }
                if (orderNo) {
                    // useNavigate prepends the site prefix automatically — pass the
                    // bare path. (Express path uses the same idiom.)
                    void navigate(`/order-confirmation/${orderNo}`);
                }
            });
        };
        el.addEventListener('sfp:paymentapprove', onApprove);

        return () => {
            el.removeEventListener('sfp:paymentmethodselected', onMethodSelected);
            el.removeEventListener('sfp:paymentapprove', onApprove);
            try {
                checkoutComponent.current?.destroy();
            } catch (error) {
                // Stripe throws "This Element has already been destroyed" on double-cleanup.
                logger.warn('[sf-payments] checkout component already destroyed', { error });
            }
            checkoutComponent.current = null;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps -- sfp/metadata/paymentConfig/shopperConfig are the mount triggers; basket/currency/locale snapshot at mount time is correct for the checkout surface
    }, [sfp, metadata, paymentConfig, shopperConfigLoading, cardCaptureAutomatic, savedMethodsReady]);

    useEffect(() => {
        if (checkoutComponent.current && basket?.orderTotal != null) {
            checkoutComponent.current.updateAmount(basket.orderTotal);
        }
    }, [basket?.orderTotal]);

    useEffect(() => {
        const ref = paymentSubmissionRef.current;
        ref.onPlaceOrder = async () => {
            setConfirmError(null);
            try {
                const result = await confirmPayment();
                if (result.success && result.orderNo) {
                    return result.orderNo;
                }
                setConfirmError(result.error || t('paymentMethods.errorConfirmationFailed'));
                return null;
            } catch (error) {
                setConfirmError(error instanceof Error ? error.message : t('paymentMethods.errorConfirmationFailed'));
                return null;
            }
        };
        return () => {
            ref.onPlaceOrder = null;
        };
    }, [confirmPayment, paymentSubmissionRef, t]);

    if (!basket?.currency) {
        return null;
    }

    if (!enabled && !metadataLoading) {
        return null;
    }

    if (metadataLoading || paymentConfigLoading) {
        return <div className="py-4 text-center text-sm text-muted-foreground">{t('paymentMethods.loading')}</div>;
    }

    if (paymentConfigError) {
        return (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm text-center">
                {paymentConfigError}
            </div>
        );
    }

    return (
        <div data-testid="sf-payments-checkout">
            <div ref={containerRef} />
            {confirmError && (
                <div className="mt-2 p-2 rounded bg-destructive/10 text-destructive text-sm text-center">
                    {confirmError}
                </div>
            )}
        </div>
    );
}
