/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, test, expect, vi, beforeEach } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import {
    createOrderFromBasket,
    updatePaymentInstrumentForOrder,
    attemptFailOrder,
    buildPaymentReturnUrl,
    createOrderAndUpdatePayment,
    handleAdyenRedirect,
    type OrderCreationError,
} from './order-mutations.server';
import { createApiClients } from '@/lib/api-clients.server';

vi.mock('@/lib/api-clients.server', () => ({
    createApiClients: vi.fn(),
}));

const mockContext = {
    get: vi.fn(),
    set: vi.fn(),
} as unknown as RouterContextProvider;

function mockClients(overrides: Record<string, unknown>) {
    vi.mocked(createApiClients).mockReturnValue(overrides as any);
}

beforeEach(() => {
    vi.clearAllMocks();
});

describe('createOrderFromBasket', () => {
    test('calls shopperOrders.createOrder with the basketId', async () => {
        const order = { orderNo: 'o1' };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        mockClients({ shopperOrders: { createOrder } });

        const result = await createOrderFromBasket(mockContext, 'b1');

        expect(createOrder).toHaveBeenCalledWith({ params: {}, body: { basketId: 'b1' } });
        expect(result).toBe(order);
    });
});

describe('updatePaymentInstrumentForOrder', () => {
    test('patches the PI on the order', async () => {
        const order = { orderNo: 'o1' };
        const update = vi.fn().mockResolvedValue({ data: order });
        mockClients({ shopperOrders: { updatePaymentInstrumentForOrder: update } });
        const body = { amount: 100 } as any;

        const result = await updatePaymentInstrumentForOrder(mockContext, 'o1', 'pi1', body);

        expect(update).toHaveBeenCalledWith({
            params: { path: { orderNo: 'o1', paymentInstrumentId: 'pi1' } },
            body,
        });
        expect(result).toBe(order);
    });
});

describe('attemptFailOrder', () => {
    test('returns false when orderNo is empty', async () => {
        const result = await attemptFailOrder(mockContext, '');
        expect(result).toBe(false);
    });

    test('fails and reopens basket when order is in "created" status', async () => {
        const getOrder = vi.fn().mockResolvedValue({ data: { status: 'created' } });
        const failOrder = vi.fn().mockResolvedValue({});
        mockClients({ shopperOrders: { getOrder, failOrder } });

        const result = await attemptFailOrder(mockContext, 'o1');

        expect(failOrder).toHaveBeenCalledWith({
            params: { path: { orderNo: 'o1' }, query: { reopenBasket: true } },
            body: { reasonCode: 'payment_confirm_failure' },
        });
        expect(result).toBe(true);
    });

    test('returns false when order is not in "created" status', async () => {
        const getOrder = vi.fn().mockResolvedValue({ data: { status: 'completed' } });
        const failOrder = vi.fn();
        mockClients({ shopperOrders: { getOrder, failOrder } });

        const result = await attemptFailOrder(mockContext, 'o1');

        expect(failOrder).not.toHaveBeenCalled();
        expect(result).toBe(false);
    });

    test('swallows errors and returns false', async () => {
        const getOrder = vi.fn().mockRejectedValue(new Error('boom'));
        mockClients({ shopperOrders: { getOrder } });

        const result = await attemptFailOrder(mockContext, 'o1');

        expect(result).toBe(false);
    });
});

describe('buildPaymentReturnUrl', () => {
    test('builds /payment-processing URL with query params', () => {
        const url = buildPaymentReturnUrl('https://shop.example', 'o1', 'zone1', 'card', undefined);

        expect(url).toBe('https://shop.example/payment-processing?orderNo=o1&type=card&zoneId=zone1');
    });

    test('encodes special characters in params', () => {
        const url = buildPaymentReturnUrl('https://shop.example', 'o 1', 'z/1', 'c&d', undefined);

        expect(url).toContain('orderNo=o+1');
        expect(url).toContain('zoneId=z%2F1');
        expect(url).toContain('type=c%26d');
    });

    test('omits zoneId from the URL when undefined (fail-loud on /payment-processing)', () => {
        const url = buildPaymentReturnUrl('https://shop.example', 'o1', undefined, 'card', undefined);

        expect(url).not.toContain('zoneId');
    });

    test('includes vendor when provided', () => {
        const url = buildPaymentReturnUrl('https://shop.example', 'o1', 'zone1', 'card', 'Adyen');

        expect(url).toContain('vendor=Adyen');
    });

    test('omits vendor when not provided', () => {
        const url = buildPaymentReturnUrl('https://shop.example', 'o1', 'zone1', 'card', undefined);

        expect(url).not.toContain('vendor');
    });
});

describe('createOrderAndUpdatePayment', () => {
    const paymentConfig = {
        zoneId: 'z1',
        paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_stripe' }],
        paymentMethodSetAccounts: [{ accountId: 'acct_stripe', vendor: 'Stripe' }],
    };

    test('creates order then patches its SF Payments PI', async () => {
        const order = {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        };
        const updated = { ...order, status: 'created' };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        const update = vi.fn().mockResolvedValue({ data: updated });
        mockClients({
            shopperOrders: { createOrder, updatePaymentInstrumentForOrder: update },
        });

        const result = await createOrderAndUpdatePayment(mockContext, {
            basketId: 'b1',
            paymentMethodType: 'card',
            paymentConfig,
            origin: 'https://shop.example',
        });

        expect(createOrder).toHaveBeenCalledWith({ params: {}, body: { basketId: 'b1' } });
        expect(update).toHaveBeenCalledWith(
            expect.objectContaining({
                params: { path: { orderNo: 'o1', paymentInstrumentId: 'pi1' } },
            })
        );
        expect(result).toBe(updated);
    });

    test('passes returnUrl through paymentData into the PI body', async () => {
        const order = {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        const update = vi.fn().mockResolvedValue({ data: order });
        mockClients({
            shopperOrders: { createOrder, updatePaymentInstrumentForOrder: update },
        });

        await createOrderAndUpdatePayment(mockContext, {
            basketId: 'b1',
            paymentMethodType: 'card',
            paymentConfig,
            paymentData: { paymentMethod: { type: 'scheme' } },
            origin: 'https://shop.example',
        });

        const body = update.mock.calls[0][0].body;
        // Returnurl is consumed by createPaymentInstrumentBody for Adyen;
        // for Stripe gateway it's built but not echoed on the ref request.
        // Assert PI body shape is correct regardless.
        expect(body.paymentMethodId).toBe('Salesforce Payments');
        expect(body.amount).toBe(100);
    });

    test('throws when paymentConfig is missing zoneId', async () => {
        await expect(
            createOrderAndUpdatePayment(mockContext, {
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig: { ...paymentConfig, zoneId: undefined },
                origin: 'https://shop.example',
            })
        ).rejects.toThrow(/zoneId/);
    });

    test('throws when order creation returns no orderNo', async () => {
        const createOrder = vi.fn().mockResolvedValue({ data: {} });
        mockClients({ shopperOrders: { createOrder } });

        await expect(
            createOrderAndUpdatePayment(mockContext, {
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://shop.example',
            })
        ).rejects.toThrow(/orderNo/);
    });

    test.each([
        ['missing', undefined],
        ['null', null],
        ['zero', 0],
        ['negative', -50],
        ['NaN', Number.NaN],
        ['Infinity', Number.POSITIVE_INFINITY],
    ])('throws when order.orderTotal is %s', async (_label, orderTotal) => {
        const order = {
            orderNo: 'o1',
            orderTotal,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        mockClients({ shopperOrders: { createOrder } });

        await expect(
            createOrderAndUpdatePayment(mockContext, {
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://shop.example',
            })
        ).rejects.toThrow(/orderTotal/);
    });

    test('throws when order has no SF Payments instrument', async () => {
        const order = {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [{ paymentMethodId: 'CREDIT_CARD' }],
        };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        mockClients({ shopperOrders: { createOrder } });

        await expect(
            createOrderAndUpdatePayment(mockContext, {
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://shop.example',
            })
        ).rejects.toThrow(/Salesforce Payments/);
    });

    test('attaches orderNo to the error when PI patch fails', async () => {
        const order = {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        const update = vi.fn().mockRejectedValue(new Error('gateway declined'));
        mockClients({
            shopperOrders: { createOrder, updatePaymentInstrumentForOrder: update },
        });

        try {
            await createOrderAndUpdatePayment(mockContext, {
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://shop.example',
            });
            throw new Error('should have thrown');
        } catch (error) {
            const err = error as OrderCreationError;
            expect(err.message).toBe('gateway declined');
            expect(err.orderNo).toBe('o1');
        }
    });

    test('wraps non-Error rejections and attaches orderNo', async () => {
        const order = {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        const update = vi.fn().mockRejectedValue('string failure');
        mockClients({
            shopperOrders: { createOrder, updatePaymentInstrumentForOrder: update },
        });

        try {
            await createOrderAndUpdatePayment(mockContext, {
                basketId: 'b1',
                paymentMethodType: 'card',
                paymentConfig,
                origin: 'https://shop.example',
            });
            throw new Error('should have thrown');
        } catch (error) {
            const err = error as OrderCreationError;
            expect(err).toBeInstanceOf(Error);
            expect(err.orderNo).toBe('o1');
        }
    });

    test('includes vendor in the return URL when paymentConfig has a matching account', async () => {
        const adyenConfig = {
            zoneId: 'z1',
            paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_adyen' }],
            paymentMethodSetAccounts: [{ accountId: 'acct_adyen', vendor: 'Adyen' }],
        };
        const order = {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        };
        const createOrder = vi.fn().mockResolvedValue({ data: order });
        const update = vi.fn().mockResolvedValue({ data: order });
        mockClients({ shopperOrders: { createOrder, updatePaymentInstrumentForOrder: update } });

        await createOrderAndUpdatePayment(mockContext, {
            basketId: 'b1',
            paymentMethodType: 'card',
            paymentConfig: adyenConfig,
            origin: 'https://shop.example',
        });

        const body = update.mock.calls[0][0].body;
        expect(body.paymentReferenceRequest.gatewayProperties.adyen.returnUrl).toContain('vendor=Adyen');
    });
});

describe('handleAdyenRedirect', () => {
    function makeOrder(resultCode: string | undefined, piId = 'pi1') {
        return {
            orderNo: 'o1',
            orderTotal: 100,
            paymentInstruments: [
                {
                    paymentMethodId: 'Salesforce Payments',
                    paymentInstrumentId: piId,
                    paymentReference: {
                        gatewayProperties: {
                            adyen: {
                                adyenPaymentIntent: resultCode !== undefined ? { resultCode } : undefined,
                            },
                        },
                    },
                },
            ],
        };
    }

    test.each(['Authorised', 'PartiallyAuthorised', 'Pending', 'Received', 'PresentToShopper'])(
        'returns true for resultCode=%s (PascalCase)',
        async (resultCode) => {
            const getOrder = vi.fn().mockResolvedValue({ data: makeOrder(undefined) });
            const update = vi.fn().mockResolvedValue({ data: makeOrder(resultCode) });
            mockClients({ shopperOrders: { getOrder, updatePaymentInstrumentForOrder: update } });

            const result = await handleAdyenRedirect(mockContext, 'o1', 'enc_result', 'klarna', 'adyen-us');

            expect(result).toBe(true);
        }
    );

    test.each(['Authorised', 'PartiallyAuthorised', 'Pending', 'Received', 'PresentToShopper'])(
        'skips PATCH and returns true when PI already has resultCode=%s (page refresh)',
        async (resultCode) => {
            const getOrder = vi.fn().mockResolvedValue({ data: makeOrder(resultCode) });
            const update = vi.fn();
            mockClients({ shopperOrders: { getOrder, updatePaymentInstrumentForOrder: update } });

            const result = await handleAdyenRedirect(mockContext, 'o1', 'enc_result', 'klarna', 'adyen-us');

            expect(result).toBe(true);
            expect(update).not.toHaveBeenCalled();
        }
    );

    test('skips PATCH and returns false when PI already has a failure resultCode (page refresh)', async () => {
        const getOrder = vi.fn().mockResolvedValue({ data: makeOrder('Refused') });
        const update = vi.fn();
        mockClients({ shopperOrders: { getOrder, updatePaymentInstrumentForOrder: update } });

        const result = await handleAdyenRedirect(mockContext, 'o1', 'enc_result', 'klarna', 'adyen-us');

        expect(result).toBe(false);
        expect(update).not.toHaveBeenCalled();
    });

    test('returns false for resultCode=Refused', async () => {
        const getOrder = vi.fn().mockResolvedValue({ data: makeOrder(undefined) });
        const update = vi.fn().mockResolvedValue({ data: makeOrder('Refused') });
        mockClients({ shopperOrders: { getOrder, updatePaymentInstrumentForOrder: update } });

        const result = await handleAdyenRedirect(mockContext, 'o1', 'enc_result', 'klarna', 'adyen-us');

        expect(result).toBe(false);
    });

    test('returns false when resultCode is absent on updated order', async () => {
        const getOrder = vi.fn().mockResolvedValue({ data: makeOrder(undefined) });
        const update = vi.fn().mockResolvedValue({ data: makeOrder(undefined) });
        mockClients({ shopperOrders: { getOrder, updatePaymentInstrumentForOrder: update } });

        const result = await handleAdyenRedirect(mockContext, 'o1', 'enc_result', 'klarna', 'adyen-us');

        expect(result).toBe(false);
    });

    test('passes redirectResult to updatePaymentInstrumentForOrder', async () => {
        const getOrder = vi.fn().mockResolvedValue({ data: makeOrder(undefined) });
        const update = vi.fn().mockResolvedValue({ data: makeOrder('Authorised') });
        mockClients({ shopperOrders: { getOrder, updatePaymentInstrumentForOrder: update } });

        await handleAdyenRedirect(mockContext, 'o1', 'my_redirect_result', 'klarna', 'adyen-us');

        const body = update.mock.calls[0][0].body;
        expect(body.paymentReferenceRequest.gatewayProperties.adyen.redirectResult).toBe('my_redirect_result');
        expect(body.paymentReferenceRequest.paymentMethodType).toBe('klarna');
        expect(body.paymentReferenceRequest.zoneId).toBe('adyen-us');
    });

    test('throws when order has no SF Payments instrument', async () => {
        const getOrder = vi.fn().mockResolvedValue({
            data: { orderNo: 'o1', paymentInstruments: [{ paymentMethodId: 'CREDIT_CARD' }] },
        });
        mockClients({ shopperOrders: { getOrder } });

        await expect(handleAdyenRedirect(mockContext, 'o1', 'enc_result', 'klarna', 'adyen-us')).rejects.toThrow(
            /Salesforce Payments/
        );
    });
});
