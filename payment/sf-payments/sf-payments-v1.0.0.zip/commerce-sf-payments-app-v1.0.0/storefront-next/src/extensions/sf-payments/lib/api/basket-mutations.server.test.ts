/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, test, expect, vi, beforeEach } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import {
    createTemporaryBasket,
    addItemToBasket,
    deleteBasket,
    updateShippingAddressForShipment,
    updateShippingMethodForShipment,
    validateAndUpdateShippingMethod,
    getCustomerTemporaryBaskets,
    cleanupTemporaryBaskets,
    ensurePaymentInstrumentInBasket,
    cleanupExpressBasket,
    patchPaymentInstrumentOnBasket,
} from './basket-mutations.server';
import { createApiClients } from '@/lib/api-clients.server';
import { addPaymentInstrumentToBasket, removePaymentInstrumentFromBasket } from '@/lib/api/basket.server';
import { ApiError } from '@/scapi';

function makeApiError(status: number): ApiError {
    return new ApiError({
        status,
        statusText: 'error',
        headers: new Headers(),
        body: { type: '', title: '', detail: '' },
        rawBody: '',
        url: '',
        method: 'DELETE',
    });
}

vi.mock('@/lib/api-clients.server', () => ({
    createApiClients: vi.fn(),
}));

vi.mock('@/lib/api/basket.server', () => ({
    addPaymentInstrumentToBasket: vi.fn(),
    removePaymentInstrumentFromBasket: vi.fn(),
}));

const { mockLogger } = vi.hoisted(() => ({
    mockLogger: {
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        debug: vi.fn(),
    },
}));
vi.mock('@/lib/logger.server', () => ({
    getLogger: () => mockLogger,
}));

const mockContext = {
    get: vi.fn(),
    set: vi.fn(),
} as unknown as RouterContextProvider;

function mockClients(overrides: Record<string, unknown>) {
    vi.mocked(createApiClients).mockReturnValue(overrides as any);
}

beforeEach(() => {
    vi.clearAllMocks();
});

describe('createTemporaryBasket', () => {
    test('creates a basket with temporary=true and the given currency', async () => {
        const basket = { basketId: 'b1' };
        const createBasket = vi.fn().mockResolvedValue({ data: basket });
        mockClients({ shopperBasketsV2: { createBasket } });

        const result = await createTemporaryBasket(mockContext, 'EUR');

        expect(createBasket).toHaveBeenCalledWith({
            params: { query: { temporary: true } },
            body: { currency: 'EUR' },
        });
        expect(result).toBe(basket);
    });
});

describe('addItemToBasket', () => {
    test('adds item with default shipmentId "me"', async () => {
        const basket = { basketId: 'b1' };
        const addItem = vi.fn().mockResolvedValue({ data: basket });
        mockClients({ shopperBasketsV2: { addItemToBasket: addItem } });

        await addItemToBasket(mockContext, 'b1', { productId: 'p1', quantity: 2 });

        expect(addItem).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1' } },
            body: [{ productId: 'p1', quantity: 2, shipmentId: 'me' }],
        });
    });

    test('passes inventoryId through when provided', async () => {
        const addItem = vi.fn().mockResolvedValue({ data: { basketId: 'b1' } });
        mockClients({ shopperBasketsV2: { addItemToBasket: addItem } });

        await addItemToBasket(mockContext, 'b1', {
            productId: 'p1',
            quantity: 1,
            inventoryId: 'inv1',
        });

        expect(addItem).toHaveBeenCalledWith(
            expect.objectContaining({
                body: [{ productId: 'p1', quantity: 1, inventoryId: 'inv1', shipmentId: 'me' }],
            })
        );
    });
});

describe('deleteBasket', () => {
    test('calls the SCAPI endpoint with the basket id', async () => {
        const deleteBasketFn = vi.fn().mockResolvedValue({});
        mockClients({ shopperBasketsV2: { deleteBasket: deleteBasketFn } });

        await deleteBasket(mockContext, 'b1');

        expect(deleteBasketFn).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1' }, query: { locale: undefined } },
        });
    });

    test('swallows 404 errors (basket already gone is the desired state)', async () => {
        const deleteBasketFn = vi.fn().mockRejectedValue(makeApiError(404));
        mockClients({ shopperBasketsV2: { deleteBasket: deleteBasketFn } });

        await expect(deleteBasket(mockContext, 'b1')).resolves.toBeUndefined();
    });

    test('rethrows non-404 ApiErrors', async () => {
        const deleteBasketFn = vi.fn().mockRejectedValue(makeApiError(500));
        mockClients({ shopperBasketsV2: { deleteBasket: deleteBasketFn } });

        await expect(deleteBasket(mockContext, 'b1')).rejects.toBeInstanceOf(ApiError);
    });

    test('rethrows non-ApiError errors (e.g. network failures)', async () => {
        const deleteBasketFn = vi.fn().mockRejectedValue(new Error('network down'));
        mockClients({ shopperBasketsV2: { deleteBasket: deleteBasketFn } });

        await expect(deleteBasket(mockContext, 'b1')).rejects.toThrow('network down');
    });
});

describe('updateShippingAddressForShipment', () => {
    test('sends address body with useAsBilling defaulting to false', async () => {
        const basket = { basketId: 'b1' };
        const update = vi.fn().mockResolvedValue({ data: basket });
        mockClients({ shopperBasketsV2: { updateShippingAddressForShipment: update } });
        const address = { firstName: 'Jane', lastName: 'Doe', city: 'SF' } as any;

        await updateShippingAddressForShipment(mockContext, 'b1', 'me', address);

        expect(update).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', shipmentId: 'me' }, query: { useAsBilling: false } },
            body: address,
        });
    });
});

describe('updateShippingMethodForShipment', () => {
    test('sends method id in body', async () => {
        const basket = { basketId: 'b1' };
        const update = vi.fn().mockResolvedValue({ data: basket });
        mockClients({ shopperBasketsV2: { updateShippingMethodForShipment: update } });

        await updateShippingMethodForShipment(mockContext, 'b1', 'me', 'std');

        expect(update).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', shipmentId: 'me' } },
            body: { id: 'std' },
        });
    });
});

describe('validateAndUpdateShippingMethod', () => {
    test('returns basket unchanged when current method is still applicable', async () => {
        const basket = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'std' } }] } as any;
        const update = vi.fn();
        mockClients({ shopperBasketsV2: { updateShippingMethodForShipment: update } });

        const result = await validateAndUpdateShippingMethod(mockContext, basket, {
            applicableShippingMethods: [{ id: 'std' }, { id: 'express' }],
        });

        expect(result).toBe(basket);
        expect(update).not.toHaveBeenCalled();
    });

    test('switches to defaultShippingMethodId when current method is gone and default is applicable', async () => {
        const basket = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'old' } }] } as any;
        const updated = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'standard' } }] };
        const update = vi.fn().mockResolvedValue({ data: updated });
        mockClients({ shopperBasketsV2: { updateShippingMethodForShipment: update } });

        const result = await validateAndUpdateShippingMethod(mockContext, basket, {
            applicableShippingMethods: [{ id: 'express' }, { id: 'standard' }, { id: 'overnight' }],
            defaultShippingMethodId: 'standard',
        });

        expect(update).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', shipmentId: 'me' } },
            body: { id: 'standard' },
        });
        expect(result).toEqual(updated);
    });

    test('falls back to first applicable method when defaultShippingMethodId is not applicable', async () => {
        const basket = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'old' } }] } as any;
        const updated = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'express' } }] };
        const update = vi.fn().mockResolvedValue({ data: updated });
        mockClients({ shopperBasketsV2: { updateShippingMethodForShipment: update } });

        const result = await validateAndUpdateShippingMethod(mockContext, basket, {
            applicableShippingMethods: [{ id: 'express' }, { id: 'overnight' }],
            defaultShippingMethodId: 'standard',
        });

        expect(update).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', shipmentId: 'me' } },
            body: { id: 'express' },
        });
        expect(result).toEqual(updated);
    });

    test('falls back to first applicable method when defaultShippingMethodId is missing', async () => {
        const basket = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'old' } }] } as any;
        const updated = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'express' } }] };
        const update = vi.fn().mockResolvedValue({ data: updated });
        mockClients({ shopperBasketsV2: { updateShippingMethodForShipment: update } });

        const result = await validateAndUpdateShippingMethod(mockContext, basket, {
            applicableShippingMethods: [{ id: 'express' }, { id: 'overnight' }],
        });

        expect(update).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', shipmentId: 'me' } },
            body: { id: 'express' },
        });
        expect(result).toEqual(updated);
    });

    test('returns basket unchanged when no applicable methods exist', async () => {
        const basket = { basketId: 'b1', shipments: [{ shippingMethod: { id: 'old' } }] } as any;
        const update = vi.fn();
        mockClients({ shopperBasketsV2: { updateShippingMethodForShipment: update } });

        const result = await validateAndUpdateShippingMethod(mockContext, basket, {
            applicableShippingMethods: [],
        });

        expect(result).toBe(basket);
        expect(update).not.toHaveBeenCalled();
    });
});

describe('getCustomerTemporaryBaskets', () => {
    test('filters out non-temporary baskets', async () => {
        const baskets = [
            { basketId: 'b1', temporaryBasket: true },
            { basketId: 'b2', temporaryBasket: false },
            { basketId: 'b3', temporaryBasket: true },
        ];
        const getCustomerBaskets = vi.fn().mockResolvedValue({ data: { baskets } });
        mockClients({ shopperCustomers: { getCustomerBaskets } });

        const result = await getCustomerTemporaryBaskets(mockContext, 'c1');

        expect(result).toEqual([baskets[0], baskets[2]]);
    });

    test('returns empty array when no baskets', async () => {
        const getCustomerBaskets = vi.fn().mockResolvedValue({ data: {} });
        mockClients({ shopperCustomers: { getCustomerBaskets } });

        const result = await getCustomerTemporaryBaskets(mockContext, 'c1');

        expect(result).toEqual([]);
    });
});

describe('cleanupTemporaryBaskets', () => {
    test('deletes all temporary baskets in parallel', async () => {
        const baskets = [
            { basketId: 'b1', temporaryBasket: true },
            { basketId: 'b2', temporaryBasket: true },
        ];
        const getCustomerBaskets = vi.fn().mockResolvedValue({ data: { baskets } });
        const deleteFn = vi.fn().mockResolvedValue({});
        mockClients({
            shopperCustomers: { getCustomerBaskets },
            shopperBasketsV2: { deleteBasket: deleteFn },
        });

        await cleanupTemporaryBaskets(mockContext, 'c1');

        expect(deleteFn).toHaveBeenCalledTimes(2);
        expect(deleteFn).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1' }, query: { locale: undefined } },
        });
        expect(deleteFn).toHaveBeenCalledWith({
            params: { path: { basketId: 'b2' }, query: { locale: undefined } },
        });
    });

    test('no-ops when there are no temp baskets', async () => {
        const getCustomerBaskets = vi.fn().mockResolvedValue({ data: { baskets: [] } });
        const deleteFn = vi.fn();
        mockClients({
            shopperCustomers: { getCustomerBaskets },
            shopperBasketsV2: { deleteBasket: deleteFn },
        });

        await cleanupTemporaryBaskets(mockContext, 'c1');

        expect(deleteFn).not.toHaveBeenCalled();
    });

    test('logs and continues when one basket fails to delete (non-404)', async () => {
        const baskets = [
            { basketId: 'b1', temporaryBasket: true },
            { basketId: 'b2', temporaryBasket: true },
        ];
        const getCustomerBaskets = vi.fn().mockResolvedValue({ data: { baskets } });
        const deleteFn = vi.fn().mockRejectedValueOnce(makeApiError(500)).mockResolvedValueOnce({});
        mockClients({
            shopperCustomers: { getCustomerBaskets },
            shopperBasketsV2: { deleteBasket: deleteFn },
        });

        await cleanupTemporaryBaskets(mockContext, 'c1');

        expect(deleteFn).toHaveBeenCalledTimes(2);
        expect(mockLogger.warn).toHaveBeenCalledWith(
            '[sf-payments] failed to delete temp basket',
            expect.objectContaining({ basketId: 'b1', status: 500 })
        );
    });
});

describe('ensurePaymentInstrumentInBasket', () => {
    const paymentConfig = {
        zoneId: 'z1',
        paymentMethods: [{ paymentMethodType: 'card', accountId: 'acct_stripe' }],
        paymentMethodSetAccounts: [{ accountId: 'acct_stripe', vendor: 'Stripe' }],
    };

    test('returns basket unchanged when SF Payments instrument already attached', async () => {
        const basket = {
            basketId: 'b1',
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        } as any;

        const result = await ensurePaymentInstrumentInBasket(mockContext, basket, 'card', paymentConfig);

        expect(result).toBe(basket);
        expect(addPaymentInstrumentToBasket).not.toHaveBeenCalled();
    });

    test('adds a Salesforce Payments instrument when missing', async () => {
        const basket = { basketId: 'b1', orderTotal: 100, paymentInstruments: [] } as any;
        const updatedBasket = {
            ...basket,
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments' }],
        };
        vi.mocked(addPaymentInstrumentToBasket).mockResolvedValue(updatedBasket);

        const result = await ensurePaymentInstrumentInBasket(mockContext, basket, 'card', paymentConfig);

        expect(addPaymentInstrumentToBasket).toHaveBeenCalledWith(
            mockContext,
            'b1',
            expect.objectContaining({
                paymentMethodId: 'Salesforce Payments',
                amount: 100,
            })
        );
        expect(result).toBe(updatedBasket);
    });

    test('throws when basket is missing basketId', async () => {
        await expect(ensurePaymentInstrumentInBasket(mockContext, {} as any, 'card', paymentConfig)).rejects.toThrow(
            /basketId/
        );
    });

    test('throws when paymentConfig is missing zoneId', async () => {
        const basket = { basketId: 'b1', paymentInstruments: [] } as any;
        await expect(
            ensurePaymentInstrumentInBasket(mockContext, basket, 'card', {
                ...paymentConfig,
                zoneId: undefined,
            })
        ).rejects.toThrow(/zoneId/);
    });

    test('throws when basket has no orderTotal or productSubTotal', async () => {
        const basket = { basketId: 'b1', paymentInstruments: [] } as any;
        await expect(ensurePaymentInstrumentInBasket(mockContext, basket, 'card', paymentConfig)).rejects.toThrow(
            /orderTotal or productSubTotal/
        );
    });

    test('falls back to productSubTotal when orderTotal is missing', async () => {
        const basket = { basketId: 'b1', productSubTotal: 75, paymentInstruments: [] } as any;
        vi.mocked(addPaymentInstrumentToBasket).mockResolvedValue(basket);

        await ensurePaymentInstrumentInBasket(mockContext, basket, 'card', paymentConfig);

        expect(addPaymentInstrumentToBasket).toHaveBeenCalledWith(
            mockContext,
            'b1',
            expect.objectContaining({ amount: 75 })
        );
    });
});

describe('cleanupExpressBasket', () => {
    test('no-ops when the order was created (basket consumed)', async () => {
        const basket = { basketId: 'b1' } as any;
        const deleteFn = vi.fn();
        mockClients({ shopperBasketsV2: { deleteBasket: deleteFn } });

        await cleanupExpressBasket(mockContext, basket, true);

        expect(deleteFn).not.toHaveBeenCalled();
        expect(removePaymentInstrumentFromBasket).not.toHaveBeenCalled();
    });

    test('no-ops when basket is null', async () => {
        await expect(cleanupExpressBasket(mockContext, null, false)).resolves.toBeUndefined();
    });

    test('removes the SF Payments PI and deletes the basket', async () => {
        const basket = {
            basketId: 'b1',
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        } as any;
        vi.mocked(removePaymentInstrumentFromBasket).mockResolvedValue(basket);
        const deleteFn = vi.fn().mockResolvedValue({});
        mockClients({ shopperBasketsV2: { deleteBasket: deleteFn } });

        await cleanupExpressBasket(mockContext, basket, false);

        expect(removePaymentInstrumentFromBasket).toHaveBeenCalledWith(mockContext, 'b1', 'pi1');
        expect(deleteFn).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1' }, query: { locale: undefined } },
        });
    });

    test('still deletes the basket when PI removal fails, logging the failure', async () => {
        const basket = {
            basketId: 'b1',
            paymentInstruments: [{ paymentMethodId: 'Salesforce Payments', paymentInstrumentId: 'pi1' }],
        } as any;
        vi.mocked(removePaymentInstrumentFromBasket).mockRejectedValue(new Error('nope'));
        const deleteFn = vi.fn().mockResolvedValue({});
        mockClients({ shopperBasketsV2: { deleteBasket: deleteFn } });

        await cleanupExpressBasket(mockContext, basket, false);

        expect(deleteFn).toHaveBeenCalled();
        expect(mockLogger.warn).toHaveBeenCalledWith(
            '[sf-payments] failed to remove PI during express cleanup',
            expect.objectContaining({ basketId: 'b1', paymentInstrumentId: 'pi1', message: 'Error: nope' })
        );
    });

    test('logs and swallows when deleteBasket fails (non-404), so cancel flow completes', async () => {
        const basket = { basketId: 'b1', paymentInstruments: [] } as any;
        const deleteFn = vi.fn().mockRejectedValue(makeApiError(500));
        mockClients({ shopperBasketsV2: { deleteBasket: deleteFn } });

        await expect(cleanupExpressBasket(mockContext, basket, false)).resolves.toBeUndefined();

        expect(mockLogger.warn).toHaveBeenCalledWith(
            '[sf-payments] failed to delete temp basket during express cleanup',
            expect.objectContaining({ basketId: 'b1' })
        );
    });

    test('deletes the basket even when no SF Payments PI is attached', async () => {
        const basket = { basketId: 'b1', paymentInstruments: [] } as any;
        const deleteFn = vi.fn().mockResolvedValue({});
        mockClients({ shopperBasketsV2: { deleteBasket: deleteFn } });

        await cleanupExpressBasket(mockContext, basket, false);

        expect(removePaymentInstrumentFromBasket).not.toHaveBeenCalled();
        expect(deleteFn).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1' }, query: { locale: undefined } },
        });
    });
});

describe('patchPaymentInstrumentOnBasket', () => {
    test('PATCHes the PI with the given body and returns the updated basket', async () => {
        const updated = { basketId: 'b1' };
        const updatePI = vi.fn().mockResolvedValue({ data: updated });
        mockClients({ shopperBasketsV2: { updatePaymentInstrumentInBasket: updatePI } });
        const body = { paymentMethodId: 'Salesforce Payments', amount: 50 } as any;

        const result = await patchPaymentInstrumentOnBasket(mockContext, 'b1', 'pi1', body);

        expect(updatePI).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1', paymentInstrumentId: 'pi1' } },
            body,
        });
        expect(result).toBe(updated);
    });
});
