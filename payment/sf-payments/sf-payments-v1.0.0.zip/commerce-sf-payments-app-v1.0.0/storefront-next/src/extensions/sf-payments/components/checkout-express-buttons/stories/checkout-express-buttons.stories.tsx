/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { Meta, StoryObj } from '@storybook/react-vite';
import CheckoutExpressButtons from '../index';

/**
 * Checkout Express Buttons Component
 *
 * NOTE: This component requires live integration with SF Payments SDK and SCAPI.
 * Storybook stories show the component structure but won't render actual payment buttons
 * without backend configuration. For full testing, use the dev server at localhost:5173/checkout.
 */
const meta = {
    title: 'SF Payments/Checkout Express Buttons',
    component: CheckoutExpressButtons,
    parameters: {
        layout: 'padded',
        docs: {
            description: {
                component: 'Express payment buttons for checkout page. Requires SF Payments SDK and active basket.',
            },
        },
    },
    tags: ['autodocs'],
} satisfies Meta<typeof CheckoutExpressButtons>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Default checkout express buttons rendering with a typical basket.
 * Shows horizontal layout with Apple Pay, Google Pay, and PayPal buttons.
 */
export const Default: Story = {
    parameters: {
        basketProvider: {
            basket: {
                basketId: 'checkout-basket-123',
                currency: 'USD',
                orderTotal: 149.99,
                billingAddress: {
                    countryCode: 'US',
                    city: 'San Francisco',
                    stateCode: 'CA',
                },
                productTotal: 129.99,
                taxTotal: 10.0,
                shippingTotal: 10.0,
            },
        },
        siteContext: {
            currency: 'USD',
            locale: { id: 'en-US' },
        },
    },
};

/**
 * Checkout express buttons with no billing address — falls back to locale-derived country.
 */
export const NoBillingAddress: Story = {
    parameters: {
        basketProvider: {
            basket: {
                basketId: 'checkout-basket-456',
                currency: 'USD',
                orderTotal: 89.99,
                billingAddress: null,
                productTotal: 79.99,
                taxTotal: 5.0,
                shippingTotal: 5.0,
            },
        },
        siteContext: {
            currency: 'USD',
            locale: { id: 'en-GB' },
        },
    },
};

/**
 * Checkout express buttons for international transaction (EUR, Germany).
 */
export const InternationalTransaction: Story = {
    parameters: {
        basketProvider: {
            basket: {
                basketId: 'checkout-basket-789',
                currency: 'EUR',
                orderTotal: 199.99,
                billingAddress: {
                    countryCode: 'DE',
                    city: 'Berlin',
                },
                productTotal: 179.99,
                taxTotal: 15.0,
                shippingTotal: 5.0,
            },
        },
        siteContext: {
            currency: 'EUR',
            locale: { id: 'de-DE' },
        },
    },
};

/**
 * No basket available — component returns null and renders nothing.
 */
export const NoBasket: Story = {
    parameters: {
        basketProvider: {
            basket: null,
        },
        siteContext: {
            currency: 'USD',
            locale: { id: 'en-US' },
        },
    },
};

/**
 * Large order total — verify formatting and button rendering.
 */
export const LargeOrder: Story = {
    parameters: {
        basketProvider: {
            basket: {
                basketId: 'checkout-basket-999',
                currency: 'USD',
                orderTotal: 2499.99,
                billingAddress: {
                    countryCode: 'US',
                    city: 'New York',
                    stateCode: 'NY',
                },
                productTotal: 2399.99,
                taxTotal: 80.0,
                shippingTotal: 20.0,
            },
        },
        siteContext: {
            currency: 'USD',
            locale: { id: 'en-US' },
        },
    },
};
