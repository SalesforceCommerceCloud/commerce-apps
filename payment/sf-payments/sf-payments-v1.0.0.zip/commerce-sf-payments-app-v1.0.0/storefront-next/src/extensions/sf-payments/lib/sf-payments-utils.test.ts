/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { describe, test, expect } from 'vitest';
import {
    transformAddressDetails,
    transformShippingMethods,
    getSelectedShippingMethodId,
    isShippingMethodValid,
    isPayPalPaymentMethodType,
    createPaymentInstrumentBody,
    getSFPaymentsInstrument,
    getClientSecret,
    findPaymentAccount,
    getGatewayFromPaymentMethod,
    getExpressPaymentMethodType,
    buildExpressCallbackData,
    buildPaypalPatchSync,
    buildPaymentProcessingUrl,
    transformPaymentMethodReferences,
    transformPayPalAddressFromPaymentReference,
    getPaymentReference,
    SETUP_FUTURE_USAGE,
} from './sf-payments-utils';

const STRIPE_ACCOUNTS = [
    { accountId: 'acct_stripe', vendor: 'Stripe' },
    { accountId: 'acct_paypal', vendor: 'PayPal' },
];
const PAYMENT_METHODS = [
    { paymentMethodType: 'card', accountId: 'acct_stripe' },
    { paymentMethodType: 'applepay', accountId: 'acct_stripe' },
    { paymentMethodType: 'googlepay', accountId: 'acct_stripe' },
    { paymentMethodType: 'amazon_pay', accountId: 'acct_stripe' },
    { paymentMethodType: 'paypal', accountId: 'acct_paypal' },
];

describe('transformAddressDetails', () => {
    const shippingDetails = {
        name: 'Jane Doe',
        address: {
            line1: '123 Main St',
            line2: 'Apt 4',
            city: 'San Francisco',
            state: 'CA',
            postalCode: '94105',
            country: 'US',
        },
        phone: '555-1234',
    };

    const billingDetails = {
        name: 'John Smith',
        address: {
            line1: '456 Oak Ave',
            city: 'New York',
            state: 'NY',
            postalCode: '10001',
            country: 'US',
        },
    };

    test('transforms both billing and shipping addresses', () => {
        const result = transformAddressDetails(billingDetails, shippingDetails);

        expect(result.shippingAddress).toEqual({
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '123 Main St',
            address2: 'Apt 4',
            city: 'San Francisco',
            stateCode: 'CA',
            postalCode: '94105',
            countryCode: 'US',
            phone: '555-1234',
        });

        expect(result.billingAddress).toEqual({
            firstName: 'John',
            lastName: 'Smith',
            address1: '456 Oak Ave',
            address2: null,
            city: 'New York',
            stateCode: 'NY',
            postalCode: '10001',
            countryCode: 'US',
            phone: null,
        });
    });

    test('uses billing as-is without fallback (caller decides substitution)', () => {
        const incompleteBilling = {
            address: { line1: '456 Oak Ave', city: 'New York', postalCode: '10001', country: 'US' },
        };
        const result = transformAddressDetails(incompleteBilling, shippingDetails);

        expect(result.billingAddress.address1).toBe('456 Oak Ave');
        expect(result.billingAddress.firstName).toBeNull();
    });

    test('splits multi-word names correctly', () => {
        const details = {
            name: 'Mary Jane Watson Parker',
            address: { line1: '1 St', city: 'NYC', postalCode: '10001', country: 'US' },
        };
        const result = transformAddressDetails(details, details);

        expect(result.shippingAddress.firstName).toBe('Mary Jane Watson');
        expect(result.shippingAddress.lastName).toBe('Parker');
    });

    test('handles single-word name', () => {
        const details = {
            name: 'Madonna',
            address: { line1: '1 St', city: 'LA', postalCode: '90001', country: 'US' },
        };
        const result = transformAddressDetails(details, details);

        expect(result.shippingAddress.firstName).toBe('');
        expect(result.shippingAddress.lastName).toBe('Madonna');
    });

    test('throws when shipping details are missing', () => {
        expect(() =>
            transformAddressDetails(
                billingDetails,
                undefined as unknown as Parameters<typeof transformAddressDetails>[1]
            )
        ).toThrow();
    });
});

describe('createPaymentInstrumentBody', () => {
    test('creates basic PI body with method ID and amount', () => {
        const result = createPaymentInstrumentBody({
            amount: 99.99,
            paymentMethodType: 'card',
            zoneId: 'zone1',
        });

        expect(result.paymentMethodId).toBe('Salesforce Payments');
        expect(result.amount).toBe(99.99);
        expect((result as any).paymentReferenceRequest.paymentMethodType).toBe('card');
        expect((result as any).paymentReferenceRequest.zoneId).toBe('zone1');
    });

    test('throws when zoneId is missing or empty', () => {
        expect(() =>
            createPaymentInstrumentBody({
                amount: 10,
                paymentMethodType: 'card',
                zoneId: '' as unknown as string,
            })
        ).toThrow(/zoneId/);
    });

    test('adds PayPal shipping preference when gateway is PayPal', () => {
        const result = createPaymentInstrumentBody({
            amount: 50,
            paymentMethodType: 'paypal',
            zoneId: 'zone1',
            shippingPreference: 'GET_FROM_FILE',
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBe('paypal');
        expect(ref.gatewayProperties.paypal.shippingPreference).toBe('GET_FROM_FILE');
    });

    test('does not add PayPal properties when shipping preference is undefined', () => {
        const result = createPaymentInstrumentBody({
            amount: 50,
            paymentMethodType: 'paypal',
            zoneId: 'zone1',
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gatewayProperties).toBeUndefined();
    });

    test('adds Stripe future usage on_session when storePaymentMethod is true', () => {
        const result = createPaymentInstrumentBody({
            amount: 100,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            storePaymentMethod: true,
            futureUsageOffSession: false,
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBe('stripe');
        expect(ref.gatewayProperties.stripe.setupFutureUsage).toBe(SETUP_FUTURE_USAGE.ON_SESSION);
    });

    test('adds Stripe future usage off_session for subscriptions', () => {
        const result = createPaymentInstrumentBody({
            amount: 100,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            storePaymentMethod: true,
            futureUsageOffSession: true,
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gatewayProperties.stripe.setupFutureUsage).toBe(SETUP_FUTURE_USAGE.OFF_SESSION);
    });

    test('skips Stripe future usage when storePaymentMethod is false and futureUsageOffSession is false', () => {
        const result = createPaymentInstrumentBody({
            amount: 100,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            storePaymentMethod: false,
            futureUsageOffSession: false,
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gatewayProperties).toBeUndefined();
    });

    test('adds Stripe future usage off_session when futureUsageOffSession is true even without storePaymentMethod', () => {
        const result = createPaymentInstrumentBody({
            amount: 100,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            storePaymentMethod: false,
            futureUsageOffSession: true,
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBe('stripe');
        expect(ref.gatewayProperties.stripe.setupFutureUsage).toBe(SETUP_FUTURE_USAGE.OFF_SESSION);
    });

    test('adds Stripe returnUrl for amazon_pay when provided in paymentData', () => {
        const result = createPaymentInstrumentBody({
            amount: 58.78,
            paymentMethodType: 'amazon_pay',
            zoneId: 'zone1',
            paymentData: {
                returnUrl: 'https://example.com/checkout/payment-processing?orderNo=0001&type=amazon_pay',
            },
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBe('stripe');
        expect(ref.gatewayProperties.stripe.returnUrl).toBe(
            'https://example.com/checkout/payment-processing?orderNo=0001&type=amazon_pay'
        );
    });

    test('skips Stripe properties on POST request', () => {
        const result = createPaymentInstrumentBody({
            amount: 100,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            storePaymentMethod: true,
            isPostRequest: true,
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBeUndefined();
        expect(ref.gatewayProperties).toBeUndefined();
    });

    test('adds Adyen payment data properties', () => {
        const adyenAccounts = [{ accountId: 'acct_adyen', vendor: 'Adyen' }];
        const adyenMethods = [{ paymentMethodType: 'card', accountId: 'acct_adyen' }];

        const result = createPaymentInstrumentBody({
            amount: 75,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            paymentData: {
                paymentMethod: { type: 'scheme' },
                returnUrl: 'https://example.com/return',
                origin: 'https://example.com',
                lineItems: [],
                billingDetails: { name: 'Test' },
            },
            paymentMethods: adyenMethods,
            paymentMethodSetAccounts: adyenAccounts,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBe('adyen');
        expect(ref.gatewayProperties.adyen.paymentMethod).toEqual({ type: 'scheme' });
        expect(ref.gatewayProperties.adyen.returnUrl).toBe('https://example.com/return');
    });

    test('skips Adyen properties on POST request', () => {
        const adyenAccounts = [{ accountId: 'acct_adyen', vendor: 'Adyen' }];
        const adyenMethods = [{ paymentMethodType: 'card', accountId: 'acct_adyen' }];

        const result = createPaymentInstrumentBody({
            amount: 75,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            isPostRequest: true,
            paymentMethods: adyenMethods,
            paymentMethodSetAccounts: adyenAccounts,
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gateway).toBeUndefined();
    });

    test('emits paypal patch sync fields when paypalPatchSync is set', () => {
        const result = createPaymentInstrumentBody({
            amount: 25,
            paymentMethodType: 'paypal',
            zoneId: 'zone1',
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
            paypalPatchSync: {
                amount: '25.00',
                currencyCode: 'USD',
                shippingOptions: [
                    { id: 'standard', label: 'Standard', amount: '5.99', currencyCode: 'USD', selected: true },
                ],
            },
        });

        const paypal = (result as any).paymentReferenceRequest.gatewayProperties.paypal;
        expect(paypal.amount).toBe('25.00');
        expect(paypal.currencyCode).toBe('USD');
        expect(paypal.shippingOptions).toEqual([
            { id: 'standard', label: 'Standard', amount: '5.99', currencyCode: 'USD', selected: true },
        ]);
        expect(paypal.shippingPreference).toBeUndefined();
    });

    test('paypal patch sync without shippingOptions omits the field', () => {
        const result = createPaymentInstrumentBody({
            amount: 25,
            paymentMethodType: 'paypal',
            zoneId: 'zone1',
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
            paypalPatchSync: { amount: '25.00', currencyCode: 'USD' },
        });

        const paypal = (result as any).paymentReferenceRequest.gatewayProperties.paypal;
        expect(paypal.amount).toBe('25.00');
        expect(paypal.currencyCode).toBe('USD');
        expect(paypal).not.toHaveProperty('shippingOptions');
    });

    test('combines paypalPatchSync with shippingPreference when both are set', () => {
        const result = createPaymentInstrumentBody({
            amount: 25,
            paymentMethodType: 'paypal',
            zoneId: 'zone1',
            shippingPreference: 'GET_FROM_FILE',
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
            paypalPatchSync: { amount: '25.00', currencyCode: 'USD' },
        });

        const paypal = (result as any).paymentReferenceRequest.gatewayProperties.paypal;
        expect(paypal.shippingPreference).toBe('GET_FROM_FILE');
        expect(paypal.amount).toBe('25.00');
        expect(paypal.currencyCode).toBe('USD');
    });

    test('paypalPatchSync is ignored when gateway is not PayPal', () => {
        const result = createPaymentInstrumentBody({
            amount: 25,
            paymentMethodType: 'card',
            zoneId: 'zone1',
            paymentMethods: PAYMENT_METHODS,
            paymentMethodSetAccounts: STRIPE_ACCOUNTS,
            paypalPatchSync: { amount: '25.00', currencyCode: 'USD' },
        });

        const ref = (result as any).paymentReferenceRequest;
        expect(ref.gatewayProperties?.paypal).toBeUndefined();
    });
});

describe('getSFPaymentsInstrument', () => {
    test('finds the Salesforce Payments instrument', () => {
        const basket = {
            paymentInstruments: [
                { paymentMethodId: 'CREDIT_CARD', amount: 50 },
                { paymentMethodId: 'Salesforce Payments', amount: 100 },
            ],
        };
        const result = getSFPaymentsInstrument(basket as any);
        expect(result?.paymentMethodId).toBe('Salesforce Payments');
    });

    test('returns undefined when no SF Payments instrument exists', () => {
        const basket = {
            paymentInstruments: [{ paymentMethodId: 'CREDIT_CARD', amount: 50 }],
        };
        expect(getSFPaymentsInstrument(basket as any)).toBeUndefined();
    });

    test('returns undefined when paymentInstruments is empty', () => {
        expect(getSFPaymentsInstrument({ paymentInstruments: [] } as any)).toBeUndefined();
    });

    test('returns undefined when paymentInstruments is missing', () => {
        expect(getSFPaymentsInstrument({} as any)).toBeUndefined();
    });
});

describe('getClientSecret', () => {
    test('extracts Stripe client secret from payment instrument', () => {
        const pi = {
            paymentReference: {
                gatewayProperties: {
                    stripe: { clientSecret: 'pi_abc_secret_xyz' },
                },
            },
        };
        expect(getClientSecret(pi as any)).toBe('pi_abc_secret_xyz');
    });

    test('returns undefined when gateway properties are missing', () => {
        expect(getClientSecret({} as any)).toBeUndefined();
        expect(getClientSecret({ paymentReference: {} } as any)).toBeUndefined();
    });
});

describe('findPaymentAccount', () => {
    test('finds account matching payment method type', () => {
        const result = findPaymentAccount(PAYMENT_METHODS, STRIPE_ACCOUNTS, 'card');
        expect(result?.vendor).toBe('Stripe');
    });

    test('returns null for unknown payment method type', () => {
        expect(findPaymentAccount(PAYMENT_METHODS, STRIPE_ACCOUNTS, 'bitcoin')).toBeNull();
    });

    test('returns null when accounts array is null', () => {
        expect(findPaymentAccount(PAYMENT_METHODS, null as any, 'card')).toBeNull();
    });

    test('returns null when payment methods array is empty', () => {
        expect(findPaymentAccount([], STRIPE_ACCOUNTS, 'card')).toBeNull();
    });
});

describe('getGatewayFromPaymentMethod', () => {
    test('resolves stripe gateway', () => {
        expect(getGatewayFromPaymentMethod('card', PAYMENT_METHODS, STRIPE_ACCOUNTS)).toBe('stripe');
    });

    test('resolves paypal gateway', () => {
        expect(getGatewayFromPaymentMethod('paypal', PAYMENT_METHODS, STRIPE_ACCOUNTS)).toBe('paypal');
    });

    test('returns null for unknown method', () => {
        expect(getGatewayFromPaymentMethod('bitcoin', PAYMENT_METHODS, STRIPE_ACCOUNTS)).toBeNull();
    });
});

describe('getExpressPaymentMethodType', () => {
    test('maps Apple Pay to card for Stripe', () => {
        expect(getExpressPaymentMethodType('applepay', PAYMENT_METHODS, STRIPE_ACCOUNTS)).toBe('card');
    });

    test('maps Google Pay to card for Stripe', () => {
        expect(getExpressPaymentMethodType('googlepay', PAYMENT_METHODS, STRIPE_ACCOUNTS)).toBe('card');
    });

    test('returns original type for PayPal', () => {
        expect(getExpressPaymentMethodType('paypal', PAYMENT_METHODS, STRIPE_ACCOUNTS)).toBe('paypal');
    });

    test('returns original type when gateway is unknown', () => {
        expect(getExpressPaymentMethodType('klarna', [], [])).toBe('klarna');
    });
});

describe('transformShippingMethods', () => {
    const methods = [
        { id: 'standard', name: 'Standard', description: 'Ground', price: 5.99 },
        { id: 'express', name: 'Express', description: '2-day', price: 12.99 },
        { id: 'overnight', name: 'Overnight', price: 24.99 },
    ];

    test('transforms fields to express payment format', () => {
        const result = transformShippingMethods(methods, {} as any);

        expect(result[0]).toEqual({
            id: 'standard',
            name: 'Standard',
            classOfService: 'Ground',
            amount: '5.99',
        });
        expect(result[2].classOfService).toBeUndefined();
    });

    test('sorts selected method to the front', () => {
        const result = transformShippingMethods(methods, {} as any, 'express');

        expect(result[0].id).toBe('express');
    });

    test('skips sorting when sortSelected is false', () => {
        const result = transformShippingMethods(methods, {} as any, 'express', false);

        expect(result[0].id).toBe('standard');
    });

    test('skips sorting when selectedId is null', () => {
        const result = transformShippingMethods(methods, {} as any, null);

        expect(result[0].id).toBe('standard');
    });
});

describe('getSelectedShippingMethodId', () => {
    test('returns shipping method ID from basket', () => {
        const basket = { shipments: [{ shippingMethod: { id: 'express' } }] };
        expect(getSelectedShippingMethodId(basket as any)).toBe('express');
    });

    test('falls back to default when basket has no shipping method', () => {
        expect(getSelectedShippingMethodId({} as any, 'standard')).toBe('standard');
    });

    test('returns undefined when no method and no default', () => {
        expect(getSelectedShippingMethodId({} as any)).toBeUndefined();
    });
});

describe('isShippingMethodValid', () => {
    test('returns true when current method is in applicable list', () => {
        const basket = { shipments: [{ shippingMethod: { id: 'express' } }] };
        const methods = { applicableShippingMethods: [{ id: 'standard' }, { id: 'express' }] };

        expect(isShippingMethodValid(basket as any, methods)).toBe(true);
    });

    test('returns false when current method is not in applicable list', () => {
        const basket = { shipments: [{ shippingMethod: { id: 'overnight' } }] };
        const methods = { applicableShippingMethods: [{ id: 'standard' }, { id: 'express' }] };

        expect(isShippingMethodValid(basket as any, methods)).toBe(false);
    });

    test('returns false when basket has no shipping method', () => {
        expect(isShippingMethodValid({} as any, { applicableShippingMethods: [{ id: 'standard' }] })).toBe(false);
    });
});

describe('isPayPalPaymentMethodType', () => {
    test('returns true for paypal', () => {
        expect(isPayPalPaymentMethodType('paypal')).toBe(true);
    });

    test('returns true for venmo', () => {
        expect(isPayPalPaymentMethodType('venmo')).toBe(true);
    });

    test('returns false for card', () => {
        expect(isPayPalPaymentMethodType('card')).toBe(false);
    });

    test('returns false for applepay', () => {
        expect(isPayPalPaymentMethodType('applepay')).toBe(false);
    });
});

describe('buildExpressCallbackData', () => {
    const labels = { subtotal: 'Subtotal', shipping: 'Shipping', tax: 'Tax' };
    const shippingMethodsResult = {
        applicableShippingMethods: [
            { id: 'standard', name: 'Standard', description: 'Ground', price: 5.99 },
            { id: 'express', name: 'Express', description: '2-day', price: 12.99 },
        ],
    };

    test('builds payload with selected method, total, and subtotal line item', () => {
        const basket = {
            orderTotal: 100,
            shipments: [{ shippingMethod: { id: 'express' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        expect(result.total).toBe('100');
        expect(result.selectedShippingMethod?.id).toBe('express');
        expect(result.shippingMethods[0].id).toBe('express');
        expect(result.lineItems).toEqual([{ name: 'Subtotal', amount: '100' }]);
    });

    test('adds shipping and tax line items when present on basket', () => {
        const basket = {
            orderTotal: 119,
            productSubTotal: 100,
            shippingTotal: 10,
            taxTotal: 9,
            shipments: [{ shippingMethod: { id: 'standard' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        // Subtotal line item is `productSubTotal`, not `orderTotal` — so the
        // wallet sees subtotal + shipping + tax === total. Using `orderTotal`
        // would double-count shipping/tax and the wallet rejects the payload.
        expect(result.total).toBe('119');
        expect(result.lineItems).toEqual([
            { name: 'Subtotal', amount: '100' },
            { name: 'Shipping', amount: '10' },
            { name: 'Tax', amount: '9' },
        ]);
    });

    test('includes shipping line at 0 (store pickup / free shipping)', () => {
        const basket = {
            orderTotal: 100,
            productSubTotal: 100,
            shippingTotal: 0,
            shipments: [{ shippingMethod: { id: 'standard' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        expect(result.lineItems).toEqual([
            { name: 'Subtotal', amount: '100' },
            { name: 'Shipping', amount: '0' },
        ]);
    });

    test('includes tax line at 0 (tax-exempt / pre-address)', () => {
        const basket = {
            orderTotal: 110,
            productSubTotal: 100,
            shippingTotal: 10,
            taxTotal: 0,
            shipments: [{ shippingMethod: { id: 'standard' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        expect(result.lineItems).toEqual([
            { name: 'Subtotal', amount: '100' },
            { name: 'Shipping', amount: '10' },
            { name: 'Tax', amount: '0' },
        ]);
    });

    test('subtotal falls back to total when productSubTotal is absent', () => {
        const basket = {
            orderTotal: 100,
            shipments: [{ shippingMethod: { id: 'standard' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        // No shipping/tax means total === subtotal, so the fallback is harmless.
        expect(result.lineItems).toEqual([{ name: 'Subtotal', amount: '100' }]);
    });

    test('falls back to productSubTotal when orderTotal is missing', () => {
        const basket = {
            productSubTotal: 50,
            shipments: [{ shippingMethod: { id: 'standard' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        expect(result.total).toBe('50');
    });

    test('throws when basket total is zero', () => {
        const basket = { orderTotal: 0, shipments: [] } as any;

        expect(() => buildExpressCallbackData(basket, shippingMethodsResult, labels)).toThrow(/Invalid basket total/);
    });

    test('throws when basket total is not finite', () => {
        const basket = { orderTotal: Number.NaN, shipments: [] } as any;

        expect(() => buildExpressCallbackData(basket, shippingMethodsResult, labels)).toThrow(/Invalid basket total/);
    });

    test('falls back to first method when selectedId is not in applicable list', () => {
        const basket = {
            orderTotal: 100,
            shipments: [{ shippingMethod: { id: 'nonexistent' } }],
        } as any;

        const result = buildExpressCallbackData(basket, shippingMethodsResult, labels);

        expect(result.selectedShippingMethod?.id).toBe('standard');
    });
});

describe('buildPaymentProcessingUrl', () => {
    test('returns base URL with no params when only origin is provided', () => {
        const result = buildPaymentProcessingUrl({ origin: 'https://shop.example' });
        expect(result).toBe('https://shop.example/payment-processing');
    });

    test('includes orderNo, type, and zoneId when all params provided', () => {
        const result = buildPaymentProcessingUrl({
            origin: 'https://shop.example',
            orderNo: 'ORDER123',
            type: 'amazon_pay',
            zoneId: 'zone1',
        });
        const url = new URL(result);
        expect(url.pathname).toBe('/payment-processing');
        expect(url.searchParams.get('orderNo')).toBe('ORDER123');
        expect(url.searchParams.get('type')).toBe('amazon_pay');
        expect(url.searchParams.get('zoneId')).toBe('zone1');
    });

    test('includes vendor when provided', () => {
        const result = buildPaymentProcessingUrl({
            origin: 'https://shop.example',
            orderNo: 'O1',
            type: 'card',
            vendor: 'Stripe',
        });
        const url = new URL(result);
        expect(url.searchParams.get('vendor')).toBe('Stripe');
    });

    test('omits zoneId when not provided', () => {
        const result = buildPaymentProcessingUrl({
            origin: 'https://shop.example',
            orderNo: 'O1',
            type: 'amazon_pay',
        });
        const url = new URL(result);
        expect(url.searchParams.has('zoneId')).toBe(false);
        expect(url.searchParams.get('orderNo')).toBe('O1');
    });

    test('omits orderNo and type when not provided', () => {
        const result = buildPaymentProcessingUrl({
            origin: 'https://shop.example',
            zoneId: 'zone1',
        });
        const url = new URL(result);
        expect(url.searchParams.has('orderNo')).toBe(false);
        expect(url.searchParams.has('type')).toBe(false);
        expect(url.searchParams.get('zoneId')).toBe('zone1');
    });
});

describe('transformPaymentMethodReferences', () => {
    const accounts = [{ accountId: 'acct_stripe' }, { accountId: 'acct_adyen' }];

    test('maps ref to full SDK shape', () => {
        const result = transformPaymentMethodReferences(
            [{ id: 'pm_123', type: 'card', last4: '4242', accountId: 'acct_stripe' }],
            accounts
        );
        expect(result).toHaveLength(1);
        expect(result[0]).toMatchObject({
            id: 'pm_123',
            gatewayTokenId: 'pm_123',
            gatewayId: 'acct_stripe',
            type: 'card',
            last4: '4242',
            status: 'Active',
            isDefault: false,
            usageType: 'OffSession',
            savedByMerchant: false,
        });
    });

    test('drops ref missing id', () => {
        const result = transformPaymentMethodReferences(
            [{ type: 'card', last4: '4242', accountId: 'acct_stripe' }],
            accounts
        );
        expect(result).toHaveLength(0);
    });

    test('drops ref missing accountId', () => {
        const result = transformPaymentMethodReferences([{ id: 'pm_123', type: 'card' }], accounts);
        expect(result).toHaveLength(0);
    });

    test('drops ref with no matching account', () => {
        const result = transformPaymentMethodReferences(
            [{ id: 'pm_123', type: 'card', accountId: 'acct_unknown' }],
            accounts
        );
        expect(result).toHaveLength(0);
    });

    test('returns empty array for empty refs', () => {
        expect(transformPaymentMethodReferences([], accounts)).toEqual([]);
    });

    test('returns empty array for empty accounts', () => {
        const result = transformPaymentMethodReferences([{ id: 'pm_123', type: 'card', accountId: 'acct_stripe' }], []);
        expect(result).toHaveLength(0);
    });
});

describe('buildPaypalPatchSync', () => {
    const basket = {
        orderTotal: 99.5,
        currency: 'USD',
        shipments: [{ shippingMethod: { id: 'standard' } }],
    } as never;

    test('formats amount and currency from the basket', () => {
        const result = buildPaypalPatchSync(basket, undefined);
        expect(result).toEqual({ amount: '99.50', currencyCode: 'USD' });
    });

    test('omits shippingOptions when applicableShippingMethods is undefined', () => {
        const result = buildPaypalPatchSync(basket, undefined);
        expect(result).not.toHaveProperty('shippingOptions');
    });

    test('maps shippingOptions and marks the selected method', () => {
        const methods = [
            { id: 'standard', name: 'Standard', price: 5.99 },
            { id: 'express', name: 'Express', price: 12.99 },
        ];
        const result = buildPaypalPatchSync(basket, methods);
        expect(result?.shippingOptions).toEqual([
            { id: 'standard', label: 'Standard', amount: '5.99', currencyCode: 'USD', selected: true },
            { id: 'express', label: 'Express', amount: '12.99', currencyCode: 'USD', selected: false },
        ]);
    });

    test('drops shipping methods missing required fields', () => {
        const methods = [
            { id: 'standard', name: 'Standard', price: 5.99 },
            { id: 'incomplete' }, // missing name + price
        ];
        const result = buildPaypalPatchSync(basket, methods);
        expect(result?.shippingOptions).toHaveLength(1);
        expect(result?.shippingOptions?.[0].id).toBe('standard');
    });

    test('falls back to productSubTotal when orderTotal is missing', () => {
        const subTotalBasket = { productSubTotal: 50, currency: 'USD' } as never;
        expect(buildPaypalPatchSync(subTotalBasket, undefined)?.amount).toBe('50.00');
    });

    test('returns null when total is missing', () => {
        const noTotal = { currency: 'USD' } as never;
        expect(buildPaypalPatchSync(noTotal, undefined)).toBeNull();
    });

    test('returns null when currency is missing', () => {
        const noCurrency = { orderTotal: 50 } as never;
        expect(buildPaypalPatchSync(noCurrency, undefined)).toBeNull();
    });
});

describe('transformPayPalAddressFromPaymentReference', () => {
    test('maps payer + shipping into an OrderAddress', () => {
        const result = transformPayPalAddressFromPaymentReference({
            payer: { givenName: 'Jane', surname: 'Doe' },
            shipping: {
                addressLine1: '123 Main St',
                addressLine2: 'Apt 4',
                adminArea1: 'CA',
                adminArea2: 'San Francisco',
                postalCode: '94105',
                countryCode: 'US',
            },
        });
        expect(result).toEqual({
            firstName: 'Jane',
            lastName: 'Doe',
            address1: '123 Main St',
            address2: 'Apt 4',
            city: 'San Francisco',
            stateCode: 'CA',
            postalCode: '94105',
            countryCode: 'US',
        });
    });

    test('returns null when shipping is missing', () => {
        expect(transformPayPalAddressFromPaymentReference({ payer: { givenName: 'Jane' } })).toBeNull();
        expect(transformPayPalAddressFromPaymentReference(undefined)).toBeNull();
    });

    test('omits payer fields when payer is absent', () => {
        const result = transformPayPalAddressFromPaymentReference({
            shipping: { addressLine1: '123 Main St', countryCode: 'US' },
        });
        expect(result?.firstName).toBeUndefined();
        expect(result?.lastName).toBeUndefined();
        expect(result?.address1).toBe('123 Main St');
    });
});

describe('getPaymentReference', () => {
    test('returns the paymentReference of the first PI matching the gateway', () => {
        const basket = {
            paymentInstruments: [
                { paymentReference: { gateway: 'stripe' } },
                {
                    paymentReference: {
                        gateway: 'paypal',
                        gatewayProperties: { paypal: { payer: { givenName: 'Jane' } } },
                    },
                },
            ],
        };
        const ref = getPaymentReference(basket as any);
        expect(ref?.gateway).toBe('paypal');
        expect(ref?.gatewayProperties?.paypal?.payer?.givenName).toBe('Jane');
    });

    test('defaults to paypal when no gateway argument is given', () => {
        const basket = { paymentInstruments: [{ paymentReference: { gateway: 'paypal' } }] };
        expect(getPaymentReference(basket as any)?.gateway).toBe('paypal');
    });

    test('honors an explicit gateway argument', () => {
        const basket = {
            paymentInstruments: [
                { paymentReference: { gateway: 'stripe' } },
                { paymentReference: { gateway: 'paypal' } },
            ],
        };
        expect(getPaymentReference(basket as any, 'stripe')?.gateway).toBe('stripe');
    });

    test('returns undefined when no PI matches', () => {
        expect(getPaymentReference({ paymentInstruments: [] } as any)).toBeUndefined();
        expect(getPaymentReference(undefined)).toBeUndefined();
    });
});
