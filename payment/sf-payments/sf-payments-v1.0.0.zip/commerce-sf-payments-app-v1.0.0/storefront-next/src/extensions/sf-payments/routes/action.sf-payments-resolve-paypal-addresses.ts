/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

import { type ActionFunctionArgs, data } from 'react-router';
import { ApiError } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { withRevalidateTags } from '@/lib/revalidation/tags';
import { CHECKOUT_PAYMENT_COMPLETE_TAG } from '../lib/constants';
import {
    updateBillingAddressForBasket,
    updateCustomerForBasket,
    updateShippingAddressForShipment,
} from '../lib/api/basket-mutations.server';
import { getPaymentReference, transformPayPalAddressFromPaymentReference } from '../lib/sf-payments-utils';

const DEFAULT_SHIPMENT_ID = 'me';

// PayPal sandbox buyers use RFC 2606 reserved-TLD emails
// (e.g. sb-xxx@personal.example.com). SCAPI's create-order runs
// EmailValidatorImpl → MailUtils.validateEmailAddress which rejects
// these; skipping the customer update preserves the pre-fix flow
// where the order just places without a shopper email.
const RFC2606_RESERVED = /(\.(test|example|invalid|localhost)|[@.]example\.(com|net|org))$/i;
const isBasketAcceptableEmail = (email: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && !RFC2606_RESERVED.test(email);

/**
 * Resolve PayPal-sourced shipping/billing addresses onto the basket.
 *
 * Called from `usePaypalStrategy.onPayerApprove` after the PayPal popup
 * approves. Pulls the basket with `expand=payment_references` so SCAPI populates
 * `gatewayProperties.paypal` with payer + shipping pushed by PayPal, then maps
 * those onto the basket's shipping + billing addresses.
 *
 * POST body (FormData):
 *   basketId: string (required)
 *   shipmentId: string (optional, defaults to 'me')
 */
export async function action({ request, context }: ActionFunctionArgs) {
    if (request.method !== 'POST') {
        return data({ success: false, error: 'Method not allowed' }, { status: 405 });
    }

    const logger = getLogger(context);
    let basketId: string | undefined;
    try {
        const formData = await request.formData();
        basketId = formData.get('basketId')?.toString();
        const shipmentId = formData.get('shipmentId')?.toString() || DEFAULT_SHIPMENT_ID;

        if (!basketId) {
            return data({ success: false, error: 'basketId is required' }, { status: 400 });
        }

        const clients = createApiClients(context);
        // TODO: drop the cast once the SCAPI OAS adds `expand` to getBasket.
        // The endpoint accepts `expand=payment_references` today (used by
        // PWA-Kit PR #3838); only the bundled TS types are stale.
        const expandQuery = { expand: ['payment_references'] } as unknown as { locale?: string };
        const { data: expandedBasket } = await clients.shopperBasketsV2.getBasket({
            params: { path: { basketId }, query: expandQuery },
        });

        const paypal = getPaymentReference(expandedBasket)?.gatewayProperties?.paypal;
        const address = transformPayPalAddressFromPaymentReference(paypal);
        // PayPal hasn't pushed the address yet — the SDK retries.
        if (!address) {
            return data({ success: false, error: 'paypal_address_unavailable' }, { status: 400 });
        }
        const payerEmail = paypal?.payer?.emailAddress;

        let basket = await updateShippingAddressForShipment(context, basketId, shipmentId, address);
        basket = await updateBillingAddressForBasket(context, basketId, address);
        // Email update is best-effort: SCAPI can reject payer emails
        // (reserved-TLD sandboxes, etc.). Skip on any failure so the
        // order still places — parity with the pre-fix behavior.
        if (payerEmail && isBasketAcceptableEmail(payerEmail)) {
            try {
                basket = await updateCustomerForBasket(context, basketId, payerEmail);
            } catch (emailError: unknown) {
                logger.warn('[sf-payments] resolve-paypal-addresses: skipping payer email update', {
                    ...(emailError instanceof ApiError ? emailError.toJSON() : { message: String(emailError) }),
                });
            }
        }
        return withRevalidateTags({ success: true, basket }, [CHECKOUT_PAYMENT_COMPLETE_TAG]);
    } catch (error) {
        const isApiError = error instanceof ApiError;
        logger.error('[sf-payments] resolve-paypal-addresses failed', {
            basketId,
            ...(isApiError ? error.toJSON() : { message: String(error) }),
        });
        return data(
            { success: false, error: isApiError ? error.body?.detail || error.message : String(error) },
            { status: isApiError ? error.status : 500 }
        );
    }
}
