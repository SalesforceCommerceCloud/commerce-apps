/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { beforeEach, describe, expect, test, vi } from 'vitest';
import type { RouterContextProvider } from 'react-router';
import { action } from './action.sf-payments-resolve-paypal-addresses';
import { createApiClients } from '@/lib/api-clients.server';
import { updateBillingAddressForBasket, updateShippingAddressForShipment } from '../lib/api/basket-mutations.server';

vi.mock('@/lib/api-clients.server', () => ({
    createApiClients: vi.fn(),
}));

vi.mock('../lib/api/basket-mutations.server', () => ({
    updateBillingAddressForBasket: vi.fn(),
    updateShippingAddressForShipment: vi.fn(),
}));

vi.mock('@/lib/logger.server', () => ({
    getLogger: vi.fn(() => ({ error: vi.fn(), info: vi.fn() })),
}));

const mockContext = { get: vi.fn(), set: vi.fn() } as unknown as RouterContextProvider;

function statusOf(result: unknown): number | undefined {
    return (result as { init?: { status?: number } })?.init?.status;
}

function dataOf(result: unknown): { success: boolean; error?: string; basket?: unknown } {
    const d = (result as { data?: unknown })?.data;
    return (d ?? result) as { success: boolean; error?: string; basket?: unknown };
}

function makeRequest(method = 'POST', basketId: string | null = 'b1') {
    const form = new FormData();
    if (basketId) form.set('basketId', basketId);
    const canHaveBody = method !== 'GET' && method !== 'HEAD';
    return new Request('https://shop.example/action/sf-payments-resolve-paypal-addresses', {
        method,
        ...(canHaveBody && { body: form }),
    });
}

const PAYPAL_BASKET = {
    basketId: 'b1',
    paymentInstruments: [
        {
            paymentReference: {
                gateway: 'paypal',
                gatewayProperties: {
                    paypal: {
                        payer: { givenName: 'Jane', surname: 'Doe' },
                        shipping: {
                            addressLine1: '123 Main St',
                            adminArea1: 'CA',
                            adminArea2: 'San Francisco',
                            postalCode: '94105',
                            countryCode: 'US',
                        },
                    },
                },
            },
        },
    ],
};

beforeEach(() => {
    vi.clearAllMocks();
});

describe('action.sf-payments-resolve-paypal-addresses', () => {
    test('returns 405 on non-POST', async () => {
        const result = await action({
            request: makeRequest('GET'),
            context: mockContext,
            params: {},
        } as any);
        expect(statusOf(result)).toBe(405);
    });

    test('returns 400 when basketId is missing', async () => {
        const result = await action({
            request: makeRequest('POST', null),
            context: mockContext,
            params: {},
        } as any);
        expect(statusOf(result)).toBe(400);
    });

    test('PUTs shipping + billing addresses derived from PayPal payment reference', async () => {
        const getBasket = vi.fn().mockResolvedValue({ data: PAYPAL_BASKET });
        vi.mocked(createApiClients).mockReturnValue({ shopperBasketsV2: { getBasket } } as any);
        const updatedBasket = { basketId: 'b1' };
        vi.mocked(updateShippingAddressForShipment).mockResolvedValue(updatedBasket as never);
        vi.mocked(updateBillingAddressForBasket).mockResolvedValue(updatedBasket as never);

        const result = (await action({
            request: makeRequest(),
            context: mockContext,
            params: {},
        } as any)) as { success: boolean; basket?: unknown };

        expect(getBasket).toHaveBeenCalledWith({
            params: { path: { basketId: 'b1' }, query: { expand: ['payment_references'] } },
        });
        expect(updateShippingAddressForShipment).toHaveBeenCalledWith(
            mockContext,
            'b1',
            'me',
            expect.objectContaining({ firstName: 'Jane', address1: '123 Main St', city: 'San Francisco' })
        );
        expect(updateBillingAddressForBasket).toHaveBeenCalledWith(
            mockContext,
            'b1',
            expect.objectContaining({ firstName: 'Jane' })
        );
        expect(result.success).toBe(true);
    });

    test('returns paypal_address_unavailable when shipping is missing', async () => {
        const noShippingBasket = {
            paymentInstruments: [
                {
                    paymentReference: {
                        gateway: 'paypal',
                        gatewayProperties: { paypal: { payer: { givenName: 'Jane' } } },
                    },
                },
            ],
        };
        const getBasket = vi.fn().mockResolvedValue({ data: noShippingBasket });
        vi.mocked(createApiClients).mockReturnValue({ shopperBasketsV2: { getBasket } } as any);

        const result = await action({
            request: makeRequest(),
            context: mockContext,
            params: {},
        } as any);

        expect(dataOf(result)).toEqual({ success: false, error: 'paypal_address_unavailable' });
        expect(updateShippingAddressForShipment).not.toHaveBeenCalled();
    });
});
