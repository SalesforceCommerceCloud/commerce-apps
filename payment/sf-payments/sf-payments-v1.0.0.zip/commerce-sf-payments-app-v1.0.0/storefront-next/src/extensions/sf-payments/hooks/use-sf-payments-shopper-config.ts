/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** @sfdc-extension-file SFDC_EXT_SF_PAYMENTS */

'use client';

import { useEffect, useState } from 'react';

type ShopperConfigMap = Record<string, unknown>;

const BOOLEAN_CONFIG_KEYS = new Set(['SalesforcePaymentsAllowed', 'cardCaptureAutomatic', 'futureUsageOffSession']);

// Module-level single-flight memo: concurrent callers share a single in-flight
// request rather than each firing their own fetch. `resolvedShopperConfig` holds
// the resolved payload so later callers can synchronously return it instead of
// chaining through the completed promise. This is request deduplication, not a
// data cache — there is no TTL or revalidation. Both slots are cleared on
// module reload (hard/soft refresh), and the in-flight memo is cleared on
// error so the next consumer can retry.
let resolvedShopperConfig: ShopperConfigMap | null = null;
let pendingShopperConfigRequest: Promise<ShopperConfigMap> | null = null;

function normalizeConfigValue(key: string, value: unknown): unknown {
    if (!BOOLEAN_CONFIG_KEYS.has(key) || typeof value !== 'string') return value;
    const lower = value.trim().toLowerCase();
    if (lower === 'true') return true;
    if (lower === 'false') return false;
    return value;
}

function normalizeConfigMap(data: ShopperConfigMap): ShopperConfigMap {
    const normalized: ShopperConfigMap = {};
    for (const [key, value] of Object.entries(data)) {
        normalized[key] = normalizeConfigValue(key, value);
    }
    return normalized;
}

/**
 * Fetches the Shopper Configurations SCAPI response
 * (via the `/resource/sf-payments-shopper-config` resource route).
 *
 * Imperative version for use by the lazy provider initialization. Concurrent
 * callers share a single in-flight request via module-level memoization.
 *
 * Known payment-related keys returned by the route:
 * - `SalesforcePaymentsAllowed` — feature toggle (boolean)
 * - `cardCaptureAutomatic` — authorize+capture vs auth-only (boolean)
 * - `futureUsageOffSession` — off-session reuse for subscriptions (boolean)
 */
export function fetchShopperConfig(): Promise<ShopperConfigMap> {
    if (resolvedShopperConfig) return Promise.resolve(resolvedShopperConfig);

    if (!pendingShopperConfigRequest) {
        pendingShopperConfigRequest = fetch('/resource/sf-payments-shopper-config')
            .then(async (res) => {
                if (!res.ok) {
                    const body = await res.json().catch(() => ({}));
                    throw new Error(body.error ?? `HTTP ${res.status}`);
                }
                return res.json();
            })
            .then((data: ShopperConfigMap) => {
                const normalizedData = normalizeConfigMap(data);
                resolvedShopperConfig = normalizedData;
                pendingShopperConfigRequest = null;
                return normalizedData;
            })
            .catch((err) => {
                pendingShopperConfigRequest = null;
                throw err;
            });
    }

    return pendingShopperConfigRequest;
}

/**
 * Client-side fallbacks applied when a key is absent from the SCAPI response
 * (field not configured in Business Manager, or fetch failed).
 *
 * - cardCaptureAutomatic: false — default to authorize-only; merchants opt in to auto-capture.
 * - futureUsageOffSession: false — default to on-session; merchants opt in to off-session.
 */
export const SHOPPER_CONFIG_DEFAULTS = {
    cardCaptureAutomatic: false,
    futureUsageOffSession: false,
} as const;

/** Result of reading a single shopper-config field. */
export interface ShopperConfigFieldResult<T> {
    /** Field value, or `undefined` if the field is genuinely missing or the
     *  fetch failed. Distinguish from "still loading" via `loading`. */
    value: T | undefined;
    /** True until the shopper-config fetch resolves (success or error). After
     *  that, `value` is final for the session. Callers should gate
     *  SDK initialization on `!loading` so they don't bind with a stale
     *  default during the loading window. */
    loading: boolean;
}

/**
 * React hook for reading a single shopper-config field (e.g. `cardCaptureAutomatic`).
 *
 * Components call this without worrying about who's already fetched the config
 * — the hook shares one network request per session with everyone else
 * (`fetchShopperConfig` and any other consumer of this hook).
 *
 * What it returns, when:
 * - If the config has already loaded (the provider usually fetches it on app
 *   start), the first render returns `{ value, loading: false }` immediately.
 *   No network call.
 * - If a consumer mounts before the provider's fetch lands (or the provider
 *   isn't using us), the hook returns `{ value: undefined, loading: true }`
 *   for the first render, kicks off `fetchShopperConfig()`, and re-renders
 *   with `loading: false` when it resolves. The fetch is deduped by the
 *   module-level memo, so a page with three consumers still only triggers
 *   one HTTP call.
 *
 * Use the `loading` flag to gate dependent SDK calls — relying on `?? default`
 * during the loading window will bind the SDK with a value that may not match
 * the merchant's actual configuration.
 *
 * Example:
 *   const { value: cardCaptureAutomatic, loading } = useShopperConfigField('cardCaptureAutomatic', SHOPPER_CONFIG_DEFAULTS.cardCaptureAutomatic)
 *   if (loading) return <Spinner />
 */
export function useShopperConfigField<T>(key: string, defaultValue: T): { value: T; loading: boolean };
export function useShopperConfigField<T>(key: string): ShopperConfigFieldResult<T>;
export function useShopperConfigField<T>(key: string, defaultValue?: T): ShopperConfigFieldResult<T> {
    const [value, setValue] = useState<T | undefined>(() =>
        resolvedShopperConfig ? ((resolvedShopperConfig[key] as T | undefined) ?? defaultValue) : defaultValue
    );
    const [loading, setLoading] = useState<boolean>(() => !resolvedShopperConfig);

    useEffect(() => {
        const currentResolved = resolvedShopperConfig;
        if (currentResolved) {
            setValue((currentResolved[key] as T | undefined) ?? defaultValue);
            setLoading(false);
            return;
        }
        let cancelled = false;
        fetchShopperConfig()
            .then((cfg) => {
                if (cancelled) return;
                setValue((cfg[key] as T | undefined) ?? defaultValue);
                setLoading(false);
            })
            .catch(() => {
                // On error, defaultValue applies. Setting loading=false unblocks
                // consumers gated on it; they'll see their default value.
                if (!cancelled) setLoading(false);
            });
        return () => {
            cancelled = true;
        };
    }, [key]); // eslint-disable-line react-hooks/exhaustive-deps -- defaultValue is intentionally excluded; it must be stable (a constant) and re-running on every render would thrash the state

    return { value: value ?? defaultValue, loading };
}
