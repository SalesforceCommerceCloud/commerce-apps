# Checkout.com Flow for Storefront Next

Accept cards, Apple Pay, Google Pay, PayPal and local payment methods at the payment step
of a Storefront Next checkout, with [Checkout.com Flow](https://www.checkout.com/docs/payments/accept-payments/accept-a-payment-on-your-website/get-started-with-flow).

- **One component** for every payment method enabled on your Checkout.com account; card
  data never touches your storefront or instance.
- **Order first:** the order is created when the shopper places it, and the payment's
  reference is the order number. A failed payment fails the order and gives the shopper
  their basket back.
- **3D Secure and redirect methods** return through the storefront's `/cko-return` route.
- **Business Manager console** (*Merchant Tools → Checkout.com Manager*): capture, void and
  refund, with every action recorded on the order.
- **Signed webhooks** (HMAC) update the order's payment status and transactions; repeated
  events are ignored.

## What the app installs

| Part | Where |
| --- | --- |
| `int_checkoutcom_next` cartridge: the `checkoutcom` Custom API (payment session, submit, complete) and the webhook controller | Site cartridge path |
| `bm_checkoutcom` cartridge: the Checkout.com Manager console | Business Manager cartridge path |
| Metadata: the **Checkout.com Flow** site preferences, the `CHECKOUTCOM_FLOW` payment method and processor, the Checkout.com services, the `ckoWebhookEvent` and `ckoPayment` custom objects, order and transaction attributes | Your instance |
| Storefront extension `checkoutcom`: Flow at `sfcc.checkout.payment.paymentMethods`, and a wrapper at `sfcc.checkout.payment` that owns Place Order | `src/extensions/checkoutcom` in your storefront repository |

## Requirements

- A Checkout.com account with Flow, and from its Dashboard: a secret key with the
  `payment-sessions` scope, a public key with `payment-sessions:pay` and
  `vault-tokenization`, and a processing channel.
- A Storefront Next storefront on B2C Commerce, with taxes and shipping methods set up for
  the site (Flow needs the basket's order total).
- **Payment Commerce Apps** (Beta) on the instance: `PaymentFraudOrchestrationEnabled`
  (Salesforce enables it) and **API hook execution** (`ScapiHookExecutionEnabled`,
  Administration → Global Preferences → Feature Switches). The app claims the
  `CHECKOUTCOM_FLOW` payment method and implements the `sfcc.app.payment.*` hooks.

## After installing

Business Manager lists the setup tasks. In short:

1. Secret keys in the **service credentials** (*Administration → Operations → Services*,
   **Credentials** tab, field **Password**, the key alone): `cko.keys.sandbox.credential` and
   `cko.keys.production.credential` (the secret API key of each mode), `cko.webhook.credential`
   (the webhook signature key; comma separated during a rotation). Secrets are never site
   preferences.
2. **Checkout.com Flow** site preferences: Mode, Public Key, Processing Channel ID, and **Allowed
   Storefront Origins**.
3. Enable the `CHECKOUTCOM_FLOW` payment method.
4. Add the `c_checkoutcom` scope to the storefront's SLAS client.
5. Register the extension's Content Security Policy contributor (below).
6. Register the webhook on the Checkout.com Dashboard:
   `https://<instance-host>/on/demandware.store/Sites-<site-id>-Site/default/CKOWebhook-Handle`,
   with the `cko.webhook.credential` password as its signature key.
7. Place a test order.

### Salesforce Order Management

The payment method ID is `CHECKOUTCOM_FLOW`. It matches none of Order Management's wallet
patterns: create a `GtwyProvPaymentMethodType` junction record with **DeveloperName**
`CHECKOUTCOM_FLOW` so payments land as AlternativePaymentMethod records. Without it they land
as CardPaymentMethod with `Type = "Unknown"`.

### Content Security Policy

Flow, its payment methods (Klarna, PayPal) and the Apple Pay and Google Pay buttons load from
hosts the storefront's Content Security Policy blocks by default. The extension ships a CSP
contributor with the exact list (`lib/csp-contributor.ts`, production and sandbox hosts, no
wildcards), which app updates keep current. Registering it is a one-time manual edit: the
storefront builds its policy in `src/middlewares/security-headers.server.ts`, a file the app
install doesn't change. Add:

```ts
// @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
import { createCheckoutcomCspContributor } from '@/extensions/checkoutcom/lib/csp-contributor';

// at the end of the contributors list:
// @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
createCheckoutcomCspContributor(config.extension?.checkoutcom),
```

Then set your account's API prefix (the `<prefix>` of `https://<prefix>.api.checkout.com`, on
the Checkout.com Dashboard under Developers → Overview) in each environment. 3D Secure device
checks frame that account-specific host:

```bash
PUBLIC__app__extension__checkoutcom__accountPrefix=<your prefix>
PUBLIC__app__extension__checkoutcom__publicKey=<your public key>   # pk_sbox_… or pk_…, matching Mode
```

The public key in the environment wins; the Checkout.com Flow **Public Key** is the fallback for
storefronts that don't set it. The full host list, how to check the policy, and what to do when
the browser console reports a blocked host are in the installation guide, step 13.

| Directive | Hosts (production; in sandbox, `.sandbox.checkout.com` and `www.sandbox.paypal.com`) |
| --- | --- |
| `script-src` | `checkout-web-components.checkout.com`, `risk.checkout.com`, `pay.google.com`, `www.paypal.com`, `www.paypalobjects.com` |
| `connect-src` | `api.checkout.com`, `devices.api.checkout.com`, `checkout-web-components-events.checkout.com`, `risk.checkout.com`, `card-acquisition-gateway.checkout.com`, `apme-api.checkout.com`, `<prefix>.api.checkout.com`, `apple-pay-gateway.apple.com`, `pay.google.com`, `google.com`, `www.paypal.com` |
| `frame-src` | `checkout-web-components.checkout.com` (the card fields), `authentication-devices.checkout.com`, `risk.checkout.com`, `<prefix>.api.checkout.com`, `pay.google.com`, `www.paypal.com` |
| `img-src` | `risk.checkout.com`, `cdnjs.cloudflare.com` (country flags), `www.paypal.com`, `www.paypalobjects.com` |

Apple Pay, Google Pay and PayPal hosts are included.

If your network restricts outbound traffic, allow the same hostnames (hostname rules, not
IP addresses: Checkout.com's CDN addresses change).

## Settings (Checkout.com Flow)

| Setting | Purpose |
| --- | --- |
| Mode | `sandbox` or `production`; the keys must belong to it |
| Public Key | Optional: used only when the storefront doesn't set `PUBLIC__app__extension__checkoutcom__publicKey` |
| Processing Channel ID | Your Checkout.com account (the secret keys are service credentials, above) |
| Service Endpoint | Only for a dedicated or regional Checkout.com API URL |
| Enable Debug Mode | Logs every Checkout.com call (secrets masked) under the `checkoutcom` category |
| Allowed Storefront Origins | Where Checkout.com may send shoppers back after 3DS or a redirect |
| Flow Auto Capture | Capture on authorization (on by default) |
| 3D Secure, 3DS Challenge Indicator, Attempt Non-3DS | 3D Secure behaviour |
| Risk Assessment | Checkout.com fraud check |
| Flow Payment Methods | Limit the methods Flow offers (empty: all enabled on the account) |
| Flow Appearance, Flow Component Options, Flow Translations | Optional JSON to customise Flow |

## Customising Flow

Flow follows the storefront theme (colours, corner radius, font) with nothing to configure.
To change it:

- **Business Manager:** the **Flow Appearance**, **Flow Component Options** and **Flow
  Translations** preferences take JSON in the formats of
  [Checkout Web Components](https://www.checkout.com/docs/payments/accept-payments/accept-a-payment-on-your-website/flow-library-reference/checkoutwebcomponents).
  No deploy needed; invalid JSON is ignored.
- **Code:** `src/extensions/checkoutcom/flow-options.ts` in your storefront repository is the
  one file of the extension meant to be edited (values from the basket, callbacks such as
  `onReady`). Keep it when you review an upgrade pull request.

Keys, the payment session, payment submission, the amount and the items can't be
overridden.

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| Payment step stays on *Loading payment methods…*; browser console `step: "basket"` | The basket has no order total: set up taxes and a shipping method |
| HTTP 403 when the payment step loads | Add `c_checkoutcom` to the SLAS client, clear cookies |
| Browser console: CSP violation for a `checkout.com`, Klarna, Apple or Google host; a payment method is missing | Register the CSP contributor (above); update the app, or add the host in `config.server.ts` (installation guide, step 13.4) |
| Instance log: `HTTP 401` from Checkout.com | The `cko.keys.<mode>.credential` password isn't the secret key of the selected Mode |
| Instance log: `The return URLs are not allowed` | Add the storefront address to Allowed Storefront Origins |
| Webhook delivery 401 | The Dashboard signature key isn't in the `cko.webhook.credential` password |

Security notes:

- Payments are only ever applied to, or reversed for, the order they were made for: the
  order number as reference, or for wallets the shopper's own basket (each payment session
  records the calling shopper).
- Orders paid with a pending method (vouchers, bank transfers) stay *Created* until the
  payment arrives, and are failed if it never does: nothing is fulfilled before it is paid.
- Webhooks are accepted only with a valid HMAC signature, and captures, refunds and voids
  are recorded only once Checkout.com's balances confirm them.
- Set up risk rules and velocity limits on the Checkout.com Dashboard against card testing.

Visa and Mastercard Level 2 / Level 3 data is sent for card payments only, when the order has
it: with Apple Pay and Google Pay express payments, and with captures of Flow card payments
(tax and shipping totals, the order number, item tax under net taxation, and unit of measure
from the product's Unit). Never on the Flow payment session, so Klarna stays available. See the
installation guide, step 17.

Logs: category `checkoutcom`; Checkout.com calls are in the `service-cko-flow-*` log files.

## Uninstalling

Uninstalling removes the services. Also remove the two `SFDC_EXT_CHECKOUTCOM` lines from
`src/middlewares/security-headers.server.ts` and delete the webhook on the Checkout.com Dashboard.

## Support

[Checkout.com support](https://www.checkout.com/contact/support)
