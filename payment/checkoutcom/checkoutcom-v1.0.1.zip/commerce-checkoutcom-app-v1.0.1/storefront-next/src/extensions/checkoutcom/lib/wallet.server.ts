/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Server side of the express wallet buttons (Google Pay; Apple Pay follows the
 * same path): the basket a button pays for, the shipping options the wallet
 * sheet shows, and the payment.
 *
 *  - Product page: a temporary basket holding only that product, so the
 *    shopper's cart is never touched. Cart and mini cart: the current basket.
 *  - The wallet token is exchanged for a Checkout.com token (POST /tokens) here,
 *    with the public key, so the wallet's payment data never reaches the
 *    instance. The instance pays the order with that token through the
 *    Payment Commerce Apps hook (Custom API POST /wallets/payments).
 */
import type { RouterContextProvider } from 'react-router';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { createApiClients } from '@/lib/api-clients.server';
import type { ShopperBasketsV2 } from '@/scapi';
import { postCheckoutcomApi } from '@/extensions/checkoutcom/lib/checkoutcom-api.server';
import {
    createOrder,
    getReturnUrls,
    releaseOrder,
    restoreBasket,
    type CompletionResult,
} from '@/extensions/checkoutcom/lib/checkoutcom.server';
import { resolvePublicKey, type FlowEnvironment } from '@/extensions/checkoutcom/lib/public-key';
import type {
    ApplePaySettings,
    GooglePaySettings,
    WalletBasketSummary,
    WalletConfig,
    WalletContact,
    WalletMethod,
    WalletPaymentResult,
    WalletShippingOption,
} from './wallet-types';

type Basket = ShopperBasketsV2.schemas['Basket'];
type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];
type Context = Readonly<RouterContextProvider>;

export { GOOGLE_PAY, APPLE_PAY } from './wallet-types';
export type {
    WalletMethod,
    WalletConfig,
    WalletShippingOption,
    WalletBasketSummary,
    WalletPaymentResult,
    WalletContact,
} from './wallet-types';

const SHIPMENT_ID = 'me';

/** Response of the Custom API POST /wallets/config. */
interface InstanceWalletConfig {
    environment: FlowEnvironment;
    publicKey: string | null;
    merchantName: string;
    googlePay: GooglePaySettings;
    applePay: ApplePaySettings;
}

function extensionConfig(context: Context): { publicKey?: string; accountPrefix?: string } {
    return ((
        getConfig(context).extension as { checkoutcom?: { publicKey?: string; accountPrefix?: string } } | undefined
    )?.checkoutcom ?? {}) as { publicKey?: string; accountPrefix?: string };
}

/**
 * The express buttons' settings: the instance says which wallets are on; the
 * public key comes from the storefront environment first.
 */
export async function getWalletConfig(context: Context): Promise<WalletConfig> {
    const instance = await postCheckoutcomApi<InstanceWalletConfig>(context, '/wallets/config', {});
    const key = resolvePublicKey(extensionConfig(context).publicKey, instance.publicKey, instance.environment);

    return {
        environment: instance.environment,
        publicKey: key?.publicKey ?? null,
        merchantName: instance.merchantName,
        googlePay: instance.googlePay,
        applePay: instance.applePay ?? { enabled: false, buttonStyle: 'black' },
    };
}

/**
 * Apple Pay merchant validation: the instance asks Apple for a merchant session
 * with the merchant identity certificate, for the storefront's domain.
 */
export async function createApplePaySession(context: Context, validationUrl: string, domain: string): Promise<unknown> {
    const { session } = await postCheckoutcomApi<{ session: unknown }>(context, '/wallets/apple-pay/session', {
        validationUrl,
        domain,
    });

    return session;
}

/** The Apple Pay domain association file content (empty when not set). */
export async function getApplePayDomainAssociation(context: Context): Promise<string> {
    const { content } = await postCheckoutcomApi<{ content: string }>(
        context,
        '/wallets/apple-pay/domain-association',
        {}
    );

    return content ?? '';
}

/** The product page's basket: a new temporary basket with only this product. */
export async function createProductBasket(
    context: Context,
    productId: string,
    quantity: number,
    currency: string
): Promise<Basket> {
    const clients = createApiClients(context);
    const { data: created } = await clients.shopperBasketsV2.createBasket({
        params: { query: { temporary: true } },
        body: { currency },
    });
    const { data: basket } = await clients.shopperBasketsV2.addItemToBasket({
        params: { path: { basketId: created.basketId as string } },
        body: [{ productId, quantity, shipmentId: SHIPMENT_ID }],
    });

    return basket;
}

/** Delete a temporary basket the shopper did not pay (the sheet was closed). */
export async function deleteTemporaryBasket(context: Context, basketId: string): Promise<void> {
    const clients = createApiClients(context);
    const { data: basket } = await clients.shopperBasketsV2.getBasket({ params: { path: { basketId } } });

    // Never the shopper's cart
    if (!(basket as Basket & { temporaryBasket?: boolean }).temporaryBasket) {
        return;
    }

    await clients.shopperBasketsV2.deleteBasket({
        params: { path: { basketId }, query: { locale: undefined } as never },
    });
}

/** The basket's totals, and its applicable shipping methods. */
export async function summarize(context: Context, basket: Basket): Promise<WalletBasketSummary> {
    const clients = createApiClients(context);
    const basketId = basket.basketId as string;
    let shippingOptions: WalletShippingOption[] = [];

    if (basket.shipments?.[0]?.shippingAddress) {
        const { data } = await clients.shopperBasketsV2.getShippingMethodsForShipment({
            params: { path: { basketId, shipmentId: SHIPMENT_ID } },
        });

        shippingOptions = (data.applicableShippingMethods ?? []).map((method) => ({
            id: method.id,
            label: method.name ?? method.id,
            description: method.description ?? '',
            price: method.price ?? 0,
        }));
    }

    const discount = (basket.orderPriceAdjustments ?? []).reduce((sum, adjustment) => sum + (adjustment.price ?? 0), 0);

    return {
        basketId,
        currency: basket.currency as string,
        total: basket.orderTotal ?? basket.productTotal ?? 0,
        subtotal: basket.productSubTotal ?? 0,
        shipping: basket.shippingTotal ?? 0,
        tax: basket.taxation === 'net' ? (basket.taxTotal ?? 0) : 0,
        discount,
        selectedShippingOptionId: basket.shipments?.[0]?.shippingMethod?.id ?? null,
        shippingOptions,
    };
}

/**
 * The wallet sheet changed the address or the shipping option: update the
 * basket, keep or pick an applicable shipping method, and return the totals.
 */
export async function updateShipping(
    context: Context,
    basketId: string,
    address: OrderAddress | null,
    shippingOptionId: string | null
): Promise<WalletBasketSummary> {
    const clients = createApiClients(context);
    let basket: Basket;

    if (address) {
        ({ data: basket } = await clients.shopperBasketsV2.updateShippingAddressForShipment({
            params: { path: { basketId, shipmentId: SHIPMENT_ID }, query: { useAsBilling: false } },
            body: address,
        }));
    } else {
        ({ data: basket } = await clients.shopperBasketsV2.getBasket({ params: { path: { basketId } } }));
    }

    const { data: methods } = await clients.shopperBasketsV2.getShippingMethodsForShipment({
        params: { path: { basketId, shipmentId: SHIPMENT_ID } },
    });
    const applicable = (methods.applicableShippingMethods ?? []).map((method) => method.id);
    const current = basket.shipments?.[0]?.shippingMethod?.id;
    const wanted =
        (shippingOptionId && applicable.includes(shippingOptionId) && shippingOptionId) ||
        (current && applicable.includes(current) && current) ||
        (methods.defaultShippingMethodId &&
            applicable.includes(methods.defaultShippingMethodId) &&
            methods.defaultShippingMethodId) ||
        applicable[0];

    if (wanted && wanted !== current) {
        ({ data: basket } = await clients.shopperBasketsV2.updateShippingMethodForShipment({
            params: { path: { basketId, shipmentId: SHIPMENT_ID } },
            body: { id: wanted },
        }));
    }

    return summarize(context, basket);
}

/** Exchange a wallet token for a Checkout.com token (POST /tokens, public key). */
export async function exchangeWalletToken(
    context: Context,
    config: WalletConfig,
    type: 'googlepay' | 'applepay',
    tokenData: unknown
): Promise<{ token: string; tokenFormat: string | null }> {
    if (!config.publicKey) {
        throw new Error('No Checkout.com public key is configured');
    }

    const prefix = extensionConfig(context).accountPrefix;
    const sandbox = config.environment === 'sandbox' ? '.sandbox' : '';
    const host =
        prefix && /^[a-z0-9]+$/i.test(prefix)
            ? `https://${prefix}.api${sandbox}.checkout.com`
            : `https://api${sandbox}.checkout.com`;
    const response = await fetch(`${host}/tokens`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.publicKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, token_data: tokenData }),
    });
    const data = (await response.json().catch(() => ({}))) as { token?: string; token_format?: string };

    if (!response.ok || !data.token) {
        throw new Error(`Token exchange failed: HTTP ${response.status}`);
    }

    return { token: data.token, tokenFormat: data.token_format ?? null };
}

/**
 * Pay the basket with a wallet: put the wallet's addresses, email and shipping
 * option on it, make its one payment instrument the wallet's, create the order
 * and have the instance pay it. A failure after the order exists releases it
 * (the instance looks for a payment first), so the basket can be paid again.
 */
export async function payWithWallet(
    request: Request,
    context: Context,
    basketId: string,
    method: WalletMethod,
    contact: WalletContact,
    checkoutcomToken: { token: string; tokenFormat: string | null }
): Promise<WalletPaymentResult> {
    const clients = createApiClients(context);

    await clients.shopperBasketsV2.updateShippingAddressForShipment({
        params: { path: { basketId, shipmentId: SHIPMENT_ID }, query: { useAsBilling: false } },
        body: contact.shippingAddress,
    });
    await clients.shopperBasketsV2.updateBillingAddressForBasket({
        params: { path: { basketId } },
        body: contact.billingAddress,
    });
    await clients.shopperBasketsV2.updateCustomerForBasket({
        params: { path: { basketId } },
        body: { email: contact.email },
    });
    await updateShipping(context, basketId, null, contact.shippingOptionId);

    // One payment instrument, the wallet's, for the order total
    let { data: basket } = await clients.shopperBasketsV2.getBasket({ params: { path: { basketId } } });

    for (const instrument of basket.paymentInstruments ?? []) {
        if (instrument.paymentInstrumentId) {
            ({ data: basket } = await clients.shopperBasketsV2.removePaymentInstrumentFromBasket({
                params: { path: { basketId, paymentInstrumentId: instrument.paymentInstrumentId } },
            }));
        }
    }

    await clients.shopperBasketsV2.addPaymentInstrumentToBasket({
        params: { path: { basketId } },
        body: { paymentMethodId: method, amount: basket.orderTotal ?? 0 },
    });

    const orderNo = (await createOrder(context, basketId)).orderNo as string;
    let result: WalletPaymentResult;

    try {
        result = await postCheckoutcomApi<WalletPaymentResult>(context, '/wallets/payments', {
            orderNo,
            paymentMethodId: method,
            token: checkoutcomToken.token,
            tokenFormat: checkoutcomToken.tokenFormat,
            ...getReturnUrls(request, context),
        });
    } catch {
        // Not knowing is not a decline: the instance releases the order only
        // when Checkout.com has no payment for it
        const released: CompletionResult = await releaseOrder(context, orderNo).catch(() => ({
            status: 'unverified' as const,
            orderNo,
        }));

        result = {
            status: released.status === 'no_order' ? 'failed' : released.status,
            orderNo: released.orderNo ?? orderNo,
        };
    }

    // Declined: the order was failed and the cart reopened; make it the shopper's
    // basket again (a product page's temporary basket is left alone)
    if (result.status === 'failed') {
        result = { ...result, basket: await restoreBasket(context, basketId).catch(() => null) };
    }

    return result;
}
