/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The outcome of a payment that left the page (3DS, a redirect method, an
 * express wallet's 3DS), shown at the top of checkout
 * (sfcc.checkout.mainContent.before), outside the steps: the payment step may
 * be collapsed when the shopper comes back, which would hide the message.
 *
 * The return route sends ?paymentError=<code> (routes/_empty.cko-return.tsx):
 * payment_failed for a declined or cancelled payment (the basket is back),
 * payment_unverified when its outcome could not be checked, which must not read
 * as a decline. The banner hides when the shopper pays again.
 */
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { PAYMENT_ATTEMPT_EVENT } from '../../lib/place-order-handler';

export default function CheckoutcomPaymentReturnError() {
    const { t } = useTranslation('extCheckoutcom');
    const [searchParams] = useSearchParams();
    const code = searchParams.get('paymentError');
    const [message, setMessage] = useState<{ title: string; description: string } | null>(null);
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (!code) {
            return;
        }

        setMessage(
            code === 'payment_unverified'
                ? { title: t('errors.unverifiedTitle'), description: t('errors.unverified') }
                : { title: t('errors.returnFailedTitle'), description: t('errors.returnFailed') }
        );

        // Drop the code from the address bar so a reload does not show it again
        const url = new URL(window.location.href);

        url.searchParams.delete('paymentError');
        window.history.replaceState(window.history.state, '', url.toString());
    }, [code, t]);

    useEffect(() => {
        if (message) {
            ref.current?.scrollIntoView({ block: 'nearest' });
        }
    }, [message]);

    useEffect(() => {
        const hide = () => setMessage(null);

        window.addEventListener(PAYMENT_ATTEMPT_EVENT, hide);

        return () => window.removeEventListener(PAYMENT_ATTEMPT_EVENT, hide);
    }, []);

    if (!message) {
        return null;
    }

    return (
        <div ref={ref} aria-live="assertive" aria-atomic="true" data-testid="checkoutcom-return-error">
            <Alert variant="destructive" className="relative pr-10">
                <AlertTitle>{message.title}</AlertTitle>
                <AlertDescription>{message.description}</AlertDescription>
                <button
                    type="button"
                    onClick={() => setMessage(null)}
                    className="absolute right-3 top-3 text-sm leading-none opacity-70 hover:opacity-100"
                    aria-label={t('errors.dismiss')}>
                    ×
                </button>
            </Alert>
        </div>
    );
}
