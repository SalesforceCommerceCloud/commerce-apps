/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The shopper closed the wallet sheet: delete the product page's temporary
 * basket. The shopper's cart is never deleted.
 *
 * POST { basketId } -> 204
 */
import type { ActionFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { deleteTemporaryBasket } from '../lib/wallet.server';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const { basketId } = ((await request.json().catch(() => ({}))) ?? {}) as { basketId?: string };

    if (basketId) {
        await deleteTemporaryBasket(context, basketId).catch((error: unknown) => {
            getLogger(context).info('[checkoutcom] temporary basket not deleted', { error: String(error) });
        });
    }

    return new Response(null, { status: 204 });
}
