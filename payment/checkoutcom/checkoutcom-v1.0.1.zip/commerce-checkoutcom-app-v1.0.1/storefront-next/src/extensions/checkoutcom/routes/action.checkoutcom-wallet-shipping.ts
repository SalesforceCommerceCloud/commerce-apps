/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The wallet sheet changed the shipping address or option: update the basket
 * and return its shipping options and totals.
 *
 * POST { basketId, address?, shippingOptionId? } -> 200 WalletBasketSummary | 4xx/5xx { error }
 */
import type { ActionFunctionArgs } from 'react-router';
import type { ShopperBasketsV2 } from '@/scapi';
import { getLogger } from '@/lib/logger.server';
import { updateShipping } from '../lib/wallet.server';

interface ShippingBody {
    basketId?: string;
    address?: ShopperBasketsV2.schemas['OrderAddress'] | null;
    shippingOptionId?: string | null;
}

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const body = ((await request.json().catch(() => ({}))) ?? {}) as ShippingBody;

    if (!body.basketId) {
        return Response.json({ error: 'basketId is required' }, { status: 400 });
    }

    try {
        return Response.json(
            await updateShipping(context, body.basketId, body.address ?? null, body.shippingOptionId ?? null)
        );
    } catch (error) {
        getLogger(context).warn('[checkoutcom] wallet shipping update failed', { error: String(error) });

        // The sheet tells the shopper the address can't be shipped to
        return Response.json({ error: 'shipping_unavailable' }, { status: 422 });
    }
}
