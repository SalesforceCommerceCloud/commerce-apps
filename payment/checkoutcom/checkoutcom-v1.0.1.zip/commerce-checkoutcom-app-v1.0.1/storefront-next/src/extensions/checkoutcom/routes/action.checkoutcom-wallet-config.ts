/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The express wallet buttons' settings: which wallets are switched on, the
 * Google Pay merchant id and button colour, the environment and the public key.
 *
 * POST -> 200 WalletConfig | 502
 */
import type { ActionFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { getWalletConfig } from '../lib/wallet.server';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    try {
        return Response.json(await getWalletConfig(context));
    } catch (error) {
        getLogger(context).error('[checkoutcom] wallet config failed', { error: String(error) });

        return Response.json({ error: 'Wallet configuration unavailable' }, { status: 502 });
    }
}
