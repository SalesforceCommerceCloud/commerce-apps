/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The basket an express wallet button pays for. Product page: a new temporary
 * basket holding only that product, so the cart is never touched. Cart and mini
 * cart: the shopper's basket.
 *
 * POST { source: 'product', productId, quantity, currency } | { source: 'cart' }
 *   -> 200 WalletBasketSummary | 4xx/5xx { error }
 */
import type { ActionFunctionArgs } from 'react-router';
import { getBasket } from '@/middlewares/basket.server';
import { getLogger } from '@/lib/logger.server';
import { createProductBasket, summarize } from '../lib/wallet.server';

interface BasketBody {
    source?: 'product' | 'cart';
    productId?: string;
    quantity?: number;
    currency?: string;
}

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const body = ((await request.json().catch(() => ({}))) ?? {}) as BasketBody;

    try {
        if (body.source === 'product') {
            if (!body.productId || !body.currency) {
                return Response.json({ error: 'productId and currency are required' }, { status: 400 });
            }

            const quantity =
                Number.isInteger(body.quantity) && (body.quantity as number) > 0 ? (body.quantity as number) : 1;

            return Response.json(
                await summarize(context, await createProductBasket(context, body.productId, quantity, body.currency))
            );
        }

        const basket = (await getBasket(context)).current;

        if (!basket?.basketId || !(basket.productItems ?? []).length) {
            return Response.json({ error: 'The cart is empty' }, { status: 409 });
        }

        return Response.json(await summarize(context, basket));
    } catch (error) {
        getLogger(context).error('[checkoutcom] wallet basket failed', { error: String(error) });

        return Response.json({ error: 'The basket could not be prepared' }, { status: 502 });
    }
}
