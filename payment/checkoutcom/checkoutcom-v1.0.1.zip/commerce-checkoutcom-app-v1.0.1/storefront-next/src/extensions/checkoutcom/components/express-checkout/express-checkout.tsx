/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Express checkout at the top of checkout (sfcc.checkout.expressPayments):
 * Apple Pay and Google Pay for the whole basket, with the template's "or continue below"
 * divider under it. It replaces the template's placeholder express buttons. The
 * divider shows only once a wallet button is on screen.
 */
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useBasket } from '@/providers/basket';
import ExpressButtons from '../express-buttons';

export default function CheckoutcomExpressCheckout() {
    const { t } = useTranslation('checkout');
    const basket = useBasket();
    const [shown, setShown] = useState(false);

    if (!basket?.basketId || !(basket.productItems ?? []).length || !basket.currency) {
        return null;
    }

    return (
        <div className={shown ? 'flex flex-col gap-4' : 'contents'} data-testid="checkoutcom-express-checkout">
            <ExpressButtons
                basket={{
                    source: 'cart',
                    currency: basket.currency,
                    estimatedTotal: basket.orderTotal ?? basket.productTotal ?? 0,
                }}
                onReady={() => setShown(true)}
            />
            {shown ? (
                <div className="relative flex items-center gap-[15px]">
                    <div className="flex-1 h-px bg-separator" />
                    <span className="text-sm font-normal leading-5 text-muted-foreground whitespace-nowrap">
                        {t('expressPayments.separator')}
                    </span>
                    <div className="flex-1 h-px bg-separator" />
                </div>
            ) : null}
        </div>
    );
}
