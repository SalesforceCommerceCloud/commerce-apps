/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Google Pay for the express checkout buttons: the script loader, the payment
 * request (the same card settings as the SFRA cartridge) and the sheet's
 * transaction info. Only the surface the buttons use is typed.
 *
 * The script must be loaded from pay.google.com; the Content Security Policy
 * contributor (lib/csp-contributor.ts) allows it.
 */
import type { WalletBasketSummary } from './wallet-types';

const SCRIPT_URL = 'https://pay.google.com/gp/p/js/pay.js';

/** Checkout.com's gateway name for Google Pay tokenization. */
const GATEWAY = 'checkoutltd';

const ALLOWED_AUTH_METHODS = ['PAN_ONLY', 'CRYPTOGRAM_3DS'];
const ALLOWED_CARD_NETWORKS = ['AMEX', 'DISCOVER', 'JCB', 'MASTERCARD', 'VISA'];

export interface GoogleAddress {
    name?: string;
    address1?: string;
    address2?: string;
    address3?: string;
    locality?: string;
    administrativeArea?: string;
    postalCode?: string;
    countryCode?: string;
    phoneNumber?: string;
}

export interface GooglePaymentData {
    email?: string;
    shippingAddress?: GoogleAddress;
    shippingOptionData?: { id?: string };
    paymentMethodData: {
        tokenizationData: { token: string };
        info?: { billingAddress?: GoogleAddress };
    };
}

export interface GoogleIntermediatePaymentData {
    callbackTrigger: 'INITIALIZE' | 'SHIPPING_ADDRESS' | 'SHIPPING_OPTION' | string;
    shippingAddress?: GoogleAddress;
    shippingOptionData?: { id?: string };
}

export interface GooglePaymentsClient {
    isReadyToPay(request: unknown): Promise<{ result: boolean }>;
    createButton(options: Record<string, unknown>): HTMLElement;
    loadPaymentData(request: unknown): Promise<GooglePaymentData>;
}

type GoogleNamespace = {
    payments: { api: { PaymentsClient: new (options: Record<string, unknown>) => GooglePaymentsClient } };
};

declare global {
    interface Window {
        google?: GoogleNamespace;
    }
}

let scriptPromise: Promise<GoogleNamespace> | null = null;

/** Load pay.js once per page. */
export function loadGooglePay(): Promise<GoogleNamespace> {
    if (typeof window === 'undefined') {
        return Promise.reject(new Error('Google Pay runs in the browser only'));
    }

    if (window.google?.payments?.api) {
        return Promise.resolve(window.google);
    }

    scriptPromise ??= new Promise<GoogleNamespace>((resolve, reject) => {
        const script = document.createElement('script');

        script.src = SCRIPT_URL;
        script.async = true;
        script.onload = () => (window.google ? resolve(window.google) : reject(new Error('Google Pay did not load')));
        script.onerror = () => {
            scriptPromise = null;
            reject(new Error('Google Pay could not be loaded'));
        };
        document.head.appendChild(script);
    });

    return scriptPromise;
}

const API_VERSION = { apiVersion: 2, apiVersionMinor: 0 };

/** The card method, tokenized by Checkout.com with the public key. */
export function cardPaymentMethod(publicKey: string) {
    return {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: ALLOWED_AUTH_METHODS,
            allowedCardNetworks: ALLOWED_CARD_NETWORKS,
            billingAddressRequired: true,
            billingAddressParameters: { format: 'FULL', phoneNumberRequired: true },
        },
        tokenizationSpecification: {
            type: 'PAYMENT_GATEWAY',
            parameters: { gateway: GATEWAY, gatewayMerchantId: publicKey },
        },
    };
}

export function isReadyToPayRequest(publicKey: string) {
    return { ...API_VERSION, allowedPaymentMethods: [cardPaymentMethod(publicKey)] };
}

/** Decimal digits of a currency, for the price strings Google Pay expects. */
function fractionDigits(currency: string): number {
    try {
        return (
            new Intl.NumberFormat('en', { style: 'currency', currency }).resolvedOptions().maximumFractionDigits ?? 2
        );
    } catch {
        return 2;
    }
}

function price(value: number, currency: string): string {
    return value.toFixed(fractionDigits(currency));
}

/** The sheet's line items and total, from the basket. */
export function transactionInfo(
    summary: Pick<WalletBasketSummary, 'currency' | 'total' | 'subtotal' | 'shipping' | 'tax' | 'discount'>,
    labels: Labels,
    status: 'FINAL' | 'ESTIMATED' = 'FINAL'
) {
    const items: Array<{ label: string; type: string; price: string; status: string }> = [
        { label: labels.subtotal, type: 'SUBTOTAL', price: price(summary.subtotal, summary.currency), status: 'FINAL' },
    ];

    if (summary.discount) {
        items.push({
            label: labels.discount,
            type: 'LINE_ITEM',
            price: price(summary.discount, summary.currency),
            status: 'FINAL',
        });
    }

    items.push({
        label: labels.shipping,
        type: 'LINE_ITEM',
        price: price(summary.shipping, summary.currency),
        status: 'FINAL',
    });

    if (summary.tax) {
        items.push({ label: labels.tax, type: 'TAX', price: price(summary.tax, summary.currency), status: 'FINAL' });
    }

    return {
        displayItems: items,
        currencyCode: summary.currency,
        totalPriceStatus: status,
        totalPrice: price(summary.total, summary.currency),
        totalPriceLabel: labels.total,
    };
}

export function shippingOptionParameters(summary: WalletBasketSummary) {
    return {
        defaultSelectedOptionId: summary.selectedShippingOptionId ?? summary.shippingOptions[0]?.id,
        shippingOptions: summary.shippingOptions.map((option) => ({
            id: option.id,
            label: `${option.label} (${price(option.price, summary.currency)} ${summary.currency})`,
            description: option.description,
        })),
    };
}

export interface Labels {
    subtotal: string;
    discount: string;
    shipping: string;
    tax: string;
    total: string;
}

/** The PaymentDataRequest: card, email, shipping address and options, all callbacks. */
export function paymentDataRequest(options: {
    publicKey: string;
    merchantId: string | null;
    merchantName: string;
    initial: ReturnType<typeof transactionInfo>;
}) {
    return {
        ...API_VERSION,
        allowedPaymentMethods: [cardPaymentMethod(options.publicKey)],
        merchantInfo: {
            ...(options.merchantId ? { merchantId: options.merchantId } : {}),
            merchantName: options.merchantName,
        },
        transactionInfo: options.initial,
        emailRequired: true,
        shippingAddressRequired: true,
        shippingAddressParameters: { phoneNumberRequired: true },
        shippingOptionRequired: true,
        callbackIntents: ['SHIPPING_ADDRESS', 'SHIPPING_OPTION', 'PAYMENT_AUTHORIZATION'],
    };
}
