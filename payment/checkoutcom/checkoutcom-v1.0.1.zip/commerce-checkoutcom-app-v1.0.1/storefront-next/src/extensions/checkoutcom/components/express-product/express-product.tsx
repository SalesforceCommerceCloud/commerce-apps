/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Express checkout on the product page (sfcc.pdp.payments.expressCheckout):
 * Apple Pay and Google Pay for the product and quantity the shopper picked, through a
 * temporary basket, so the cart is never touched. It replaces the template's
 * placeholder express buttons.
 */
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import { useOptionalProductView } from '@/providers/product-view';
import { useCurrentVariant } from '@/hooks/product/use-current-variant';
import ExpressButtons from '../express-buttons';

export default function CheckoutcomExpressProduct() {
    const view = useOptionalProductView();
    const { currency } = useSite();
    const currentVariant = useCurrentVariant({ product: view?.product as never });

    if (!view?.product || !view.canAddToCart) {
        return null;
    }

    const productId = currentVariant?.productId || view.product.id;
    const unitPrice = (view.isMasterOrVariantProduct ? currentVariant?.price : undefined) ?? view.product.price ?? 0;

    if (!productId) {
        return null;
    }

    return (
        <div className="mt-4 w-full">
            <ExpressButtons
                basket={{
                    source: 'product',
                    productId,
                    quantity: view.quantity,
                    currency,
                    estimatedTotal: unitPrice * view.quantity,
                }}
            />
        </div>
    );
}
