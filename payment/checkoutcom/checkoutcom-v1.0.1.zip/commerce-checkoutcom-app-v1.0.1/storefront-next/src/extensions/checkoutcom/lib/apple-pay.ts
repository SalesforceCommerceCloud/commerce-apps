/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Apple Pay on the Web for the express checkout buttons: Apple's button script
 * (the <apple-pay-button> element), the payment request, and the sheet's line
 * items and shipping methods. Only the surface the buttons use is typed.
 *
 * The script must be loaded from applepay.cdn-apple.com; the Content Security
 * Policy contributor (lib/csp-contributor.ts) allows it.
 */
import type { WalletBasketSummary } from './wallet-types';

const SCRIPT_URL = 'https://applepay.cdn-apple.com/jsapi/1.latest/apple-pay-sdk.js';

/** Apple Pay JS version: 3 has the contact fields and the update objects used here. */
export const APPLE_PAY_VERSION = 3;

/** The same networks as the SFRA cartridge. */
const SUPPORTED_NETWORKS = ['amex', 'discover', 'jcb', 'masterCard', 'visa'];

export interface ApplePayContact {
    givenName?: string;
    familyName?: string;
    emailAddress?: string;
    phoneNumber?: string;
    addressLines?: string[];
    locality?: string;
    administrativeArea?: string;
    postalCode?: string;
    countryCode?: string;
}

export interface ApplePayLineItem {
    label: string;
    amount: string;
    type?: 'final' | 'pending';
}

export interface ApplePayShippingMethod {
    label: string;
    detail: string;
    amount: string;
    identifier: string;
}

export interface ApplePaySessionLike {
    begin(): void;
    abort(): void;
    completeMerchantValidation(session: unknown): void;
    completeShippingContactSelection(update: Record<string, unknown>): void;
    completeShippingMethodSelection(update: Record<string, unknown>): void;
    completePayment(result: { status: number; errors?: unknown[] }): void;
    onvalidatemerchant: ((event: { validationURL: string }) => void) | null;
    onshippingcontactselected: ((event: { shippingContact: ApplePayContact }) => void) | null;
    onshippingmethodselected: ((event: { shippingMethod: { identifier: string } }) => void) | null;
    onpaymentauthorized:
        | ((event: {
              payment: {
                  token: { paymentData: unknown };
                  shippingContact?: ApplePayContact;
                  billingContact?: ApplePayContact;
              };
          }) => void)
        | null;
    oncancel: (() => void) | null;
}

export interface ApplePaySessionConstructor {
    new (version: number, request: Record<string, unknown>): ApplePaySessionLike;
    canMakePayments(): boolean;
    supportsVersion(version: number): boolean;
    STATUS_SUCCESS: number;
    STATUS_FAILURE: number;
}

declare global {
    interface Window {
        ApplePaySession?: ApplePaySessionConstructor;
    }
}

let scriptPromise: Promise<void> | null = null;

/** Load Apple's button script once per page; it also provides ApplePaySession outside Safari. */
export function loadApplePay(): Promise<void> {
    if (typeof window === 'undefined') {
        return Promise.reject(new Error('Apple Pay runs in the browser only'));
    }

    scriptPromise ??= new Promise<void>((resolve, reject) => {
        const script = document.createElement('script');

        script.src = SCRIPT_URL;
        script.async = true;
        script.crossOrigin = 'anonymous';
        script.onload = () => resolve();
        script.onerror = () => {
            scriptPromise = null;
            reject(new Error('Apple Pay could not be loaded'));
        };
        document.head.appendChild(script);
    });

    return scriptPromise;
}

/** @returns The ApplePaySession class when this browser can pay with Apple Pay */
export function applePaySession(): ApplePaySessionConstructor | null {
    const Session = typeof window !== 'undefined' ? window.ApplePaySession : undefined;

    try {
        return Session && Session.supportsVersion(APPLE_PAY_VERSION) && Session.canMakePayments() ? Session : null;
    } catch {
        return null;
    }
}

function fractionDigits(currency: string): number {
    try {
        return (
            new Intl.NumberFormat('en', { style: 'currency', currency }).resolvedOptions().maximumFractionDigits ?? 2
        );
    } catch {
        return 2;
    }
}

function amount(value: number, currency: string): string {
    return value.toFixed(fractionDigits(currency));
}

export interface Labels {
    subtotal: string;
    discount: string;
    shipping: string;
    tax: string;
}

type Totals = Pick<WalletBasketSummary, 'currency' | 'total' | 'subtotal' | 'shipping' | 'tax' | 'discount'>;

/** The sheet's line items, from the basket. */
export function lineItems(summary: Totals, labels: Labels): ApplePayLineItem[] {
    const items: ApplePayLineItem[] = [
        { label: labels.subtotal, amount: amount(summary.subtotal, summary.currency), type: 'final' },
    ];

    if (summary.discount) {
        items.push({ label: labels.discount, amount: amount(summary.discount, summary.currency), type: 'final' });
    }

    items.push({ label: labels.shipping, amount: amount(summary.shipping, summary.currency), type: 'final' });

    if (summary.tax) {
        items.push({ label: labels.tax, amount: amount(summary.tax, summary.currency), type: 'final' });
    }

    return items;
}

/** The sheet's total, labelled with the merchant name as Apple requires. */
export function total(summary: Totals, merchantName: string, type: 'final' | 'pending' = 'final'): ApplePayLineItem {
    return { label: merchantName, amount: amount(summary.total, summary.currency), type };
}

/** The basket's shipping methods, the selected one first (Apple preselects the first). */
export function shippingMethods(summary: WalletBasketSummary): ApplePayShippingMethod[] {
    const methods = summary.shippingOptions.map((option) => ({
        label: option.label,
        detail: option.description,
        amount: amount(option.price, summary.currency),
        identifier: option.id,
    }));
    const selected = methods.findIndex((method) => method.identifier === summary.selectedShippingOptionId);

    return selected > 0 ? [methods[selected], ...methods.slice(0, selected), ...methods.slice(selected + 1)] : methods;
}

/** The payment request: cards, 3DS-capable, email, phone, name and both addresses. */
export function paymentRequest(options: { countryCode: string; currency: string; total: ApplePayLineItem }) {
    return {
        countryCode: options.countryCode,
        currencyCode: options.currency,
        supportedNetworks: SUPPORTED_NETWORKS,
        merchantCapabilities: ['supports3DS'],
        total: options.total,
        requiredShippingContactFields: ['postalAddress', 'name', 'phone', 'email'],
        requiredBillingContactFields: ['postalAddress', 'name'],
    };
}

/** A partial contact from the sheet (country, postal code, region, city) for shipping options. */
export function partialAddress(contact: ApplePayContact | undefined) {
    return contact
        ? {
              countryCode: contact.countryCode?.toUpperCase(),
              postalCode: contact.postalCode,
              stateCode: contact.administrativeArea || undefined,
              city: contact.locality,
          }
        : null;
}

/** A full Apple Pay contact as a Shopper Baskets order address. */
export function toOrderAddress(contact: ApplePayContact, fallback: ApplePayContact = {}) {
    const lines = contact.addressLines ?? [];

    return {
        firstName: contact.givenName || fallback.givenName,
        lastName: contact.familyName || fallback.familyName,
        address1: lines[0],
        address2: lines.slice(1).join(' ') || undefined,
        city: contact.locality,
        stateCode: contact.administrativeArea || undefined,
        postalCode: contact.postalCode,
        countryCode: contact.countryCode?.toUpperCase(),
        phone: contact.phoneNumber || fallback.phoneNumber || undefined,
    };
}
