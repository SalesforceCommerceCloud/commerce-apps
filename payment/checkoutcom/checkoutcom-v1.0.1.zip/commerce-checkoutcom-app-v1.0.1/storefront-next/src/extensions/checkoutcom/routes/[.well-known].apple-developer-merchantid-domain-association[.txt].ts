/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The Apple Pay domain association file under the name Apple asks for now,
 * /.well-known/apple-developer-merchantid-domain-association.txt. Same content
 * as the route without the extension, which domains verified before keep using.
 */
export { loader } from './[.well-known].apple-developer-merchantid-domain-association';
