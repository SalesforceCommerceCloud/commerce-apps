/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import targetConfig from '../target-config.json';

/**
 * The storefront's component loader imports each target component into the
 * template file that holds its UI target, as `Checkoutcom_<FileName>`. Two
 * components with the same file name in one template file (two of our targets
 * on the checkout page) would be declared twice and break the page.
 */
const importName = (path: string) =>
    (path.split('/').pop() ?? '')
        .replace(/\.(tsx|ts|jsx|js)$/, '')
        .split(/[-.]/)
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
        .join('');

describe('target-config.json', () => {
    it('gives every distinct component file its own import name', () => {
        const paths = [...new Set(targetConfig.components.map((component) => component.path))];
        const names = paths.map(importName);

        expect(new Set(names).size).toBe(paths.length);
        expect(names).not.toContain('Index');
    });
});
