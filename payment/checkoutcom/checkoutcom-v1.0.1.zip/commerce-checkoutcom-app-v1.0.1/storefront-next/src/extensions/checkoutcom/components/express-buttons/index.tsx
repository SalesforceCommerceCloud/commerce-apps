/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The express wallet buttons, for one basket source: Apple Pay first (Apple's
 * guidelines), then Google Pay. Each shows only when its wallet is switched on
 * and available in this browser.
 */
import ExpressApplePay from '../express-apple-pay';
import ExpressGooglePay from '../express-google-pay';
import type { ExpressSource } from '../../lib/express-client';

interface Props {
    basket: ExpressSource;
    disabled?: boolean;
    /** Called once a button is on screen */
    onReady?: () => void;
}

export default function ExpressButtons({ basket, disabled, onReady }: Props) {
    return (
        <div className="flex w-full flex-col gap-2">
            <ExpressApplePay basket={basket} disabled={disabled} onReady={onReady} />
            <ExpressGooglePay basket={basket} disabled={disabled} onReady={onReady} />
        </div>
    );
}
