/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Where an express wallet payment goes next: 3D Secure (the redirect), the
 * order confirmation page (placed, pending, or not confirmed yet: the order
 * exists and the shopper must not pay again), or back to the button with an
 * error (declined: the basket is back).
 */
import { useCallback } from 'react';
import { useConfig } from '@salesforce/storefront-next-runtime/config';
import { buildUrl } from '@salesforce/storefront-next-runtime/site-context';
import { useCurrentSiteAndLocaleRef } from '@/hooks/use-current-site-and-locale-ref';
import { useBasketUpdater } from '@/providers/basket';
import { routeHref, routes } from '@/route-paths';
import type { WalletPaymentResult } from './wallet-types';

/** @returns finish(result): true when the shopper is leaving the page */
export function useExpressFinish(): (result: WalletPaymentResult) => boolean {
    const config = useConfig();
    const { siteRef, localeRef } = useCurrentSiteAndLocaleRef();
    const updateBasket = useBasketUpdater();

    return useCallback(
        (result: WalletPaymentResult) => {
            if (result.status === 'pending' && result.redirectUrl) {
                window.location.href = result.redirectUrl;

                return true;
            }

            if ((result.status === 'complete' || result.status === 'unverified') && result.orderNo) {
                window.location.href = buildUrl({
                    to: routeHref(routes.orderConfirmation, { orderNo: result.orderNo }),
                    urlConfig: config.url,
                    params: { siteId: siteRef, localeId: localeRef },
                });

                return true;
            }

            // Declined: the reopened cart, so the page shows it again
            if (result.status === 'failed' && result.basket?.basketId) {
                updateBasket(result.basket);
            }

            return false;
        },
        [config.url, siteRef, localeRef, updateBasket]
    );
}
