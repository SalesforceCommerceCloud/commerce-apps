/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Types shared by the express wallet buttons (browser) and their action routes
 * (server, lib/wallet.server.ts).
 */
import type { ShopperBasketsV2 } from '@/scapi';
import type { FlowEnvironment } from './public-key';

type OrderAddress = ShopperBasketsV2.schemas['OrderAddress'];

export const GOOGLE_PAY = 'CHECKOUTCOM_GOOGLE_PAY';
export const APPLE_PAY = 'CHECKOUTCOM_APPLE_PAY';
export type WalletMethod = typeof GOOGLE_PAY | typeof APPLE_PAY;

/** Google Pay settings from the instance (Custom API POST /wallets/config). */
export interface GooglePaySettings {
    enabled: boolean;
    merchantId: string | null;
    buttonColor: 'default' | 'black' | 'white';
}

/** Apple Pay settings from the instance: on only when merchant validation can work. */
export interface ApplePaySettings {
    enabled: boolean;
    buttonStyle: 'black' | 'white' | 'white-outline';
}

/** What the buttons need in the browser. Nothing secret. */
export interface WalletConfig {
    environment: FlowEnvironment;
    publicKey: string | null;
    /** The site name, shown in the wallet sheets */
    merchantName: string;
    googlePay: GooglePaySettings;
    applePay: ApplePaySettings;
}

/** A shipping option, as the wallet sheet shows it. */
export interface WalletShippingOption {
    id: string;
    label: string;
    description: string;
    price: number;
}

/** The basket's totals and shipping options, for the wallet sheet. */
export interface WalletBasketSummary {
    basketId: string;
    currency: string;
    total: number;
    subtotal: number;
    shipping: number;
    tax: number;
    discount: number;
    selectedShippingOptionId: string | null;
    shippingOptions: WalletShippingOption[];
}

/** The outcome of a wallet payment, for the button. */
export interface WalletPaymentResult {
    status: 'complete' | 'pending' | 'failed' | 'unverified';
    pending?: boolean;
    orderNo?: string | null;
    redirectUrl?: string | null;
    errorMessage?: string | null;
    /** On failed: the cart reopened for another try (never a product page's temporary basket) */
    basket?: ShopperBasketsV2.schemas['Basket'] | null;
}

/** What the wallet returned about the shopper. */
export interface WalletContact {
    email: string;
    shippingAddress: OrderAddress;
    billingAddress: OrderAddress;
    shippingOptionId: string | null;
}
