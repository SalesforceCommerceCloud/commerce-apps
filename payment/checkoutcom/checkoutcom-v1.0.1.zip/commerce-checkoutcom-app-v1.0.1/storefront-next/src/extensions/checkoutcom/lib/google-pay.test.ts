/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import { cardPaymentMethod, paymentDataRequest, shippingOptionParameters, transactionInfo } from './google-pay';

const labels = { subtotal: 'Subtotal', discount: 'Discount', shipping: 'Shipping', tax: 'Tax', total: 'Total' };
const summary = {
    basketId: 'b1',
    currency: 'GBP',
    total: 55.5,
    subtotal: 50,
    shipping: 5,
    tax: 0.5,
    discount: 0,
    selectedShippingOptionId: 'standard',
    shippingOptions: [
        { id: 'standard', label: 'Standard', description: '3-5 days', price: 5 },
        { id: 'express', label: 'Express', description: 'Next day', price: 10 },
    ],
};

describe('Google Pay request', () => {
    it('tokenizes cards with Checkout.com (checkoutltd + public key), PAN_ONLY and CRYPTOGRAM_3DS, SFRA networks', () => {
        const method = cardPaymentMethod('pk_sbox_test');

        expect(method.tokenizationSpecification.parameters).toEqual({
            gateway: 'checkoutltd',
            gatewayMerchantId: 'pk_sbox_test',
        });
        expect(method.parameters.allowedAuthMethods).toEqual(['PAN_ONLY', 'CRYPTOGRAM_3DS']);
        expect(method.parameters.allowedCardNetworks).toEqual(['AMEX', 'DISCOVER', 'JCB', 'MASTERCARD', 'VISA']);
        expect(method.parameters.billingAddressParameters).toEqual({ format: 'FULL', phoneNumberRequired: true });
    });

    it('asks for email, shipping address and option, with all three callbacks', () => {
        const request = paymentDataRequest({
            publicKey: 'pk_sbox_test',
            merchantId: null,
            merchantName: 'Shop',
            initial: transactionInfo(summary, labels, 'ESTIMATED'),
        });

        expect(request.emailRequired).toBe(true);
        expect(request.shippingAddressRequired).toBe(true);
        expect(request.shippingOptionRequired).toBe(true);
        expect(request.callbackIntents).toEqual(['SHIPPING_ADDRESS', 'SHIPPING_OPTION', 'PAYMENT_AUTHORIZATION']);
        // Without a merchant id (Sandbox), only the name is sent
        expect(request.merchantInfo).toEqual({ merchantName: 'Shop' });
    });

    it("shows subtotal, shipping and tax lines and a final total in the currency's decimals", () => {
        const info = transactionInfo(summary, labels);

        expect(info.totalPrice).toBe('55.50');
        expect(info.totalPriceStatus).toBe('FINAL');
        expect(info.displayItems.map((item) => item.label)).toEqual(['Subtotal', 'Shipping', 'Tax']);
        expect(transactionInfo({ ...summary, currency: 'JPY', total: 1200 }, labels).totalPrice).toBe('1200');
    });

    it("offers the basket's shipping methods, the selected one first", () => {
        const options = shippingOptionParameters(summary);

        expect(options.defaultSelectedOptionId).toBe('standard');
        expect(options.shippingOptions.map((option) => option.id)).toEqual(['standard', 'express']);
    });
});
