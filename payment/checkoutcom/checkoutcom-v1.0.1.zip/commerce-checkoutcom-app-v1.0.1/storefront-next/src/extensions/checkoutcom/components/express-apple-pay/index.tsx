/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The Apple Pay express checkout button (product page, cart, mini cart,
 * checkout).
 *
 * The session starts in the click, as Apple Pay requires, with an estimated
 * total, while the basket is prepared in parallel (a temporary basket with the
 * product on the product page, the cart elsewhere). The instance validates the
 * merchant with Apple (onvalidatemerchant); the sheet's contact and method
 * changes update the basket's shipping; the authorization pays the order with
 * the Apple Pay token, which Checkout.com decrypts. No 3D Secure step: Apple Pay
 * is authenticated on the device.
 */
import { createElement, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import {
    APPLE_PAY_VERSION,
    applePaySession,
    lineItems,
    loadApplePay,
    partialAddress,
    paymentRequest,
    shippingMethods,
    toOrderAddress,
    total,
    type Labels,
} from '../../lib/apple-pay';
import {
    APPLE_PAY,
    type WalletBasketSummary,
    type WalletConfig,
    type WalletPaymentResult,
} from '../../lib/wallet-types';
import { loadWalletConfig, postJson, releaseBasket, requestBasket, type ExpressSource } from '../../lib/express-client';
import { useExpressFinish } from '../../lib/use-express-finish';

interface Props {
    basket: ExpressSource;
    disabled?: boolean;
    /** Called once the button is on screen (Apple Pay available and configured) */
    onReady?: () => void;
}

/** The merchant's country for the payment request: the locale's region (en-US -> US). */
function countryOf(localeId: string | undefined): string {
    const region = localeId?.split(/[-_]/)[1];

    return region && /^[A-Za-z]{2}$/.test(region) ? region.toUpperCase() : 'US';
}

export default function ExpressApplePay({ basket, disabled = false, onReady }: Props) {
    const { t } = useTranslation('extCheckoutcom');
    const site = useSite();
    const finish = useExpressFinish();
    const buttonRef = useRef<HTMLElement | null>(null);
    const configRef = useRef<WalletConfig | null>(null);
    const sourceRef = useRef(basket);
    const disabledRef = useRef(disabled);
    const finishRef = useRef(finish);
    const [ready, setReady] = useState(false);
    const [error, setError] = useState<string | null>(null);

    sourceRef.current = basket;
    disabledRef.current = disabled;
    finishRef.current = finish;

    const labels: Labels = {
        subtotal: t('express.subtotal'),
        discount: t('express.discount'),
        shipping: t('express.shipping'),
        tax: t('express.tax'),
    };
    const labelsRef = useRef(labels);

    labelsRef.current = labels;

    useEffect(() => {
        let cancelled = false;

        void (async () => {
            const walletConfig = await loadWalletConfig().catch(() => null);

            if (cancelled || !walletConfig?.applePay?.enabled || !walletConfig.publicKey) {
                return;
            }

            await loadApplePay().catch(() => null);

            if (cancelled || !applePaySession()) {
                return;
            }

            configRef.current = walletConfig;
            setReady(true);
            onReady?.();
        })();

        return () => {
            cancelled = true;
        };
        // Loaded once; the source is read through a ref
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const button = buttonRef.current;

        if (!ready || !button) {
            return;
        }

        const onClick = () => {
            const Session = applePaySession();
            const walletConfig = configRef.current;

            if (disabledRef.current || !Session || !walletConfig) {
                return;
            }

            setError(null);

            const source = sourceRef.current;
            const merchantName = walletConfig.merchantName || document.title;
            // Until the first shipping update: the product price or the cart total
            const estimate = {
                currency: source.currency,
                total: source.estimatedTotal,
                subtotal: source.estimatedTotal,
                shipping: 0,
                tax: 0,
                discount: 0,
            };
            const prepared = requestBasket(source);
            let summary: WalletBasketSummary | null = null;
            let paid = false;

            prepared.then((value) => (summary = value)).catch(() => undefined);

            // Started in the click, with an estimate the shipping updates replace
            const session = new Session(
                APPLE_PAY_VERSION,
                paymentRequest({
                    countryCode: countryOf(site.locale?.id),
                    currency: source.currency,
                    total: total(estimate, merchantName, 'pending'),
                })
            );

            /** The basket after a shipping change, or null when the address can't be served. */
            const updateShipping = async (body: { address: unknown; shippingOptionId: string | null }) => {
                const current = await prepared;
                const { ok, data } = await postJson<WalletBasketSummary>('/action/checkoutcom-wallet-shipping', {
                    basketId: current.basketId,
                    ...body,
                });

                if (!ok || !data.shippingOptions?.length) {
                    return null;
                }

                summary = data;

                return data;
            };

            session.onvalidatemerchant = (event) => {
                void postJson<{ session?: unknown }>('/action/checkoutcom-applepay-session', {
                    validationUrl: event.validationURL,
                }).then(({ ok, data }) => {
                    if (ok && data.session) {
                        session.completeMerchantValidation(data.session);
                    } else {
                        session.abort();
                        setError(t('errors.payment'));
                    }
                });
            };

            session.onshippingcontactselected = (event) => {
                void updateShipping({ address: partialAddress(event.shippingContact), shippingOptionId: null })
                    .catch(() => null)
                    .then((data) => {
                        const base = data ?? summary;

                        session.completeShippingContactSelection(
                            data
                                ? {
                                      newTotal: total(data, merchantName),
                                      newLineItems: lineItems(data, labelsRef.current),
                                      newShippingMethods: shippingMethods(data),
                                  }
                                : {
                                      errors: [
                                          new (
                                              window as unknown as { ApplePayError: new (...args: string[]) => unknown }
                                          ).ApplePayError(
                                              'addressUnserviceable',
                                              'postalAddress',
                                              t('express.addressUnserviceable')
                                          ),
                                      ],
                                      newTotal: base
                                          ? total(base, merchantName)
                                          : total(estimate, merchantName, 'pending'),
                                  }
                        );
                    });
            };

            session.onshippingmethodselected = (event) => {
                void updateShipping({ address: null, shippingOptionId: event.shippingMethod.identifier })
                    .catch(() => null)
                    .then((data) => {
                        const base = data ?? summary;

                        session.completeShippingMethodSelection(
                            base
                                ? {
                                      newTotal: total(base, merchantName),
                                      newLineItems: lineItems(base, labelsRef.current),
                                  }
                                : { newTotal: total(estimate, merchantName, 'pending') }
                        );
                    });
            };

            session.onpaymentauthorized = (event) => {
                const shipping = event.payment.shippingContact ?? {};
                const billing = event.payment.billingContact ?? shipping;

                void prepared
                    .then((current) =>
                        postJson<WalletPaymentResult>('/action/checkoutcom-wallet-pay', {
                            basketId: current.basketId,
                            paymentMethodId: APPLE_PAY,
                            tokenData: event.payment.token.paymentData,
                            contact: {
                                email: shipping.emailAddress,
                                shippingAddress: toOrderAddress(shipping),
                                billingAddress: toOrderAddress(billing, shipping),
                                shippingOptionId: summary?.selectedShippingOptionId ?? null,
                            },
                        })
                    )
                    .then(({ data }) => {
                        const success = data.status !== 'failed';

                        paid = success;
                        session.completePayment({ status: success ? Session.STATUS_SUCCESS : Session.STATUS_FAILURE });

                        if (!finishRef.current(data)) {
                            setError(t('errors.payment'));
                        }
                    })
                    .catch(() => {
                        session.completePayment({ status: Session.STATUS_FAILURE });
                        setError(t('errors.payment'));
                    });
            };

            session.oncancel = () => {
                // Closed: a product page basket is deleted, the cart is kept
                if (!paid) {
                    releaseBasket(source, prepared);
                }
            };

            session.begin();
        };

        button.addEventListener('click', onClick);

        return () => button.removeEventListener('click', onClick);
    }, [ready, site.locale?.id, t]);

    if (!ready) {
        return null;
    }

    return (
        <div data-checkoutcom-express="apple-pay" className="w-full">
            {createElement('apple-pay-button', {
                ref: buttonRef,
                buttonstyle: configRef.current?.applePay.buttonStyle ?? 'black',
                type: 'buy',
                locale: site.locale?.id,
                style: { display: 'block', width: '100%', height: '48px', cursor: 'pointer' },
            })}
            {error ? (
                <p role="alert" className="mt-2 text-sm text-destructive">
                    {error}
                </p>
            ) : null}
        </div>
    );
}
