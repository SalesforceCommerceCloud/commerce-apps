/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Gateway return route for payments that leave the page: 3DS challenges and
 * redirect methods (iDEAL, Klarna, PayPal, ...). Checkout.com sends the shopper
 * to the success_url or failure_url (this route, built by getReturnUrls) with
 * the payment appended: `cko-payment-id` after Flow, `cko-session-id` after a
 * payments API 3DS challenge (the express wallets). GET /payments/{id} accepts
 * either, so both are verified the same way.
 *
 * Both legs go through the same verification: the instance places the order for
 * an approved or pending payment, and fails it (reopening the basket) for a
 * declined one. Never trust the leg alone.
 */
import { redirect, type LoaderFunctionArgs } from 'react-router';
import { finalizeOrderSuccess } from '@/lib/checkout/place-order-orchestration.server';
import { buildUrlFromContext } from '@/lib/url.server';
import { getLogger } from '@/lib/logger.server';
import { routes } from '@/route-paths';
import { getBasketSnapshot } from '@/middlewares/basket.server';
import { completePayment, restoreBasket } from '../lib/checkoutcom.server';

export async function loader({ request, context }: LoaderFunctionArgs) {
    const logger = getLogger(context);
    const url = new URL(request.url);
    const paymentId = url.searchParams.get('cko-payment-id') || url.searchParams.get('cko-session-id');
    const checkoutUrl = buildUrlFromContext(routes.checkout, context);

    if (!paymentId) {
        logger.warn('[checkoutcom] return route called without cko-payment-id or cko-session-id');

        return redirect(`${checkoutUrl}?paymentError=payment_failed`);
    }

    // payment_failed: declined, the basket is back. payment_unverified: the outcome
    // is not known (verification failed), so the shopper must not be told they
    // were not charged, nor invited to pay again
    let errorCode = 'payment_unverified';

    try {
        const result = await completePayment(context, { paymentId });

        if (result.status === 'complete' && result.orderNo) {
            return redirect(finalizeOrderSuccess(context, { orderNo: result.orderNo }));
        }

        if (result.status === 'failed') {
            errorCode = 'payment_failed';
            // The reopened basket, so the checkout shows it again
            await restoreBasket(context, getBasketSnapshot(context)?.basketId).catch(() => null);
        }

        logger.info('[checkoutcom] return leg did not complete', {
            paymentId,
            status: result.status,
            leg: url.searchParams.get('leg'),
        });
    } catch (error) {
        logger.error('[checkoutcom] return leg could not verify the payment', { paymentId, error: String(error) });
    }

    return redirect(`${checkoutUrl}?paymentError=${errorCode}`);
}

export default function CheckoutcomReturn() {
    return null;
}
