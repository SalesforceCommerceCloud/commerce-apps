/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import { lineItems, partialAddress, paymentRequest, shippingMethods, toOrderAddress, total } from './apple-pay';

const labels = { subtotal: 'Subtotal', discount: 'Discount', shipping: 'Shipping', tax: 'Tax' };
const summary = {
    basketId: 'b1',
    currency: 'GBP',
    total: 55.5,
    subtotal: 50,
    shipping: 5,
    tax: 0.5,
    discount: 0,
    selectedShippingOptionId: 'express',
    shippingOptions: [
        { id: 'standard', label: 'Standard', description: '3-5 days', price: 5 },
        { id: 'express', label: 'Express', description: 'Next day', price: 10 },
    ],
};

describe('Apple Pay request', () => {
    it('asks for cards with 3DS capability, the SFRA networks, contact and both addresses', () => {
        const request = paymentRequest({ countryCode: 'GB', currency: 'GBP', total: total(summary, 'Shop') });

        expect(request.supportedNetworks).toEqual(['amex', 'discover', 'jcb', 'masterCard', 'visa']);
        expect(request.merchantCapabilities).toEqual(['supports3DS']);
        expect(request.requiredShippingContactFields).toEqual(['postalAddress', 'name', 'phone', 'email']);
        expect(request.requiredBillingContactFields).toEqual(['postalAddress', 'name']);
        expect(request.total).toEqual({ label: 'Shop', amount: '55.50', type: 'final' });
    });

    it("shows subtotal, shipping and tax, in the currency's decimals", () => {
        expect(lineItems(summary, labels).map((item) => [item.label, item.amount])).toEqual([
            ['Subtotal', '50.00'],
            ['Shipping', '5.00'],
            ['Tax', '0.50'],
        ]);
        expect(total({ ...summary, currency: 'JPY', total: 1200 }, 'Shop').amount).toBe('1200');
    });

    it('lists the selected shipping method first, which Apple preselects', () => {
        expect(shippingMethods(summary).map((method) => method.identifier)).toEqual(['express', 'standard']);
    });

    it('turns Apple Pay contacts into order addresses, filling the billing name and phone from shipping', () => {
        const shipping = {
            givenName: 'Jordan',
            familyName: 'Smith',
            phoneNumber: '+44 20 7946 0000',
            emailAddress: 'jordan@example.com',
            addressLines: ['1 Main St', 'Flat 2'],
            locality: 'London',
            postalCode: 'N1 1AA',
            countryCode: 'gb',
        };

        expect(toOrderAddress(shipping)).toEqual({
            firstName: 'Jordan',
            lastName: 'Smith',
            address1: '1 Main St',
            address2: 'Flat 2',
            city: 'London',
            stateCode: undefined,
            postalCode: 'N1 1AA',
            countryCode: 'GB',
            phone: '+44 20 7946 0000',
        });
        expect(toOrderAddress({ addressLines: ['2 Side St'], countryCode: 'GB' }, shipping).firstName).toBe('Jordan');
        expect(
            partialAddress({ countryCode: 'us', postalCode: '10001', administrativeArea: 'NY', locality: 'New York' })
        ).toEqual({
            countryCode: 'US',
            postalCode: '10001',
            stateCode: 'NY',
            city: 'New York',
        });
    });
});
