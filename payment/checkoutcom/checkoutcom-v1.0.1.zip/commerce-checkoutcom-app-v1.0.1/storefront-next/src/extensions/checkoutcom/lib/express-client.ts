/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Browser helpers shared by the express wallet buttons (Google Pay, Apple
 * Pay): the calls to the extension's wallet routes, and what a button pays for.
 */
import type { WalletBasketSummary, WalletConfig } from './wallet-types';

/** What a button pays for: the product on the product page, or the cart. */
export type ExpressSource =
    | { source: 'product'; productId: string; quantity: number; currency: string; estimatedTotal: number }
    | { source: 'cart'; currency: string; estimatedTotal: number };

export async function postJson<T>(url: string, body: unknown): Promise<{ ok: boolean; data: T }> {
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });

    if (response.status === 204) {
        return { ok: true, data: {} as T };
    }

    const data = (await response.json().catch(() => ({}))) as T;

    return { ok: response.ok, data };
}

let configPromise: Promise<WalletConfig | null> | null = null;

/** The wallet settings, fetched once per page. */
export function loadWalletConfig(): Promise<WalletConfig | null> {
    configPromise ??= postJson<WalletConfig>('/action/checkoutcom-wallet-config', {}).then(({ ok, data }) =>
        ok ? data : null
    );

    return configPromise;
}

/** The basket for a sheet: a temporary one with the product, or the cart. */
export async function requestBasket(source: ExpressSource): Promise<WalletBasketSummary> {
    const { ok, data } = await postJson<WalletBasketSummary>('/action/checkoutcom-wallet-basket', source);

    if (!ok || !data.basketId) {
        throw new Error('The basket could not be prepared');
    }

    return data;
}

/** The sheet was closed: a product page basket is deleted, the cart is kept. */
export function releaseBasket(source: ExpressSource, basket: Promise<WalletBasketSummary> | null): void {
    if (source.source === 'product' && basket) {
        void basket
            .then((summary) => postJson('/action/checkoutcom-wallet-cancel', { basketId: summary.basketId }))
            .catch(() => undefined);
    }
}
