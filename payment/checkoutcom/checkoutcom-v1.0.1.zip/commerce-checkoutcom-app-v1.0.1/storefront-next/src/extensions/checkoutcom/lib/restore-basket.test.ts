/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

import { beforeEach, describe, expect, it, vi } from 'vitest';

const getBasket = vi.fn();
const getCustomerBaskets = vi.fn();
const updateBasketResource = vi.fn();
const getAuth = vi.fn();

vi.mock('@/lib/api-clients.server', () => ({
    createApiClients: () => ({
        shopperBasketsV2: { getBasket },
        shopperCustomers: { getCustomerBaskets },
    }),
}));
vi.mock('@/middlewares/basket.server', () => ({ updateBasketResource }));
vi.mock('@/middlewares/auth.server', () => ({ getAuth }));
vi.mock('@/lib/api/basket.server', () => ({}));
vi.mock('@/lib/url.server', () => ({ buildUrlFromContext: () => '/cko-return' }));
vi.mock('@/extensions/checkoutcom/lib/checkoutcom-api.server', () => ({ postCheckoutcomApi: vi.fn() }));

const { restoreBasket } = await import('./checkoutcom.server');

const context = {} as never;
const withItems = (basketId: string, lastModified = '2026-10-26T10:00:00Z') => ({
    basketId,
    lastModified,
    productItems: [{ productId: 'P1', quantity: 1 }],
});

describe('restoreBasket (a failed payment reopened the basket)', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        getAuth.mockReturnValue({ customerId: 'cust-1' });
    });

    it('makes the reopened basket the session basket again', async () => {
        getBasket.mockResolvedValue({ data: withItems('b-1') });

        expect(await restoreBasket(context, 'b-1')).toMatchObject({ basketId: 'b-1' });
        expect(updateBasketResource).toHaveBeenCalledWith(context, expect.objectContaining({ basketId: 'b-1' }));
        expect(getCustomerBaskets).not.toHaveBeenCalled();
    });

    it("falls back to the shopper's newest basket with items when the id is gone", async () => {
        getBasket.mockRejectedValue(new Error('404'));
        getCustomerBaskets.mockResolvedValue({
            data: {
                baskets: [
                    { basketId: 'empty', productItems: [] },
                    withItems('older', '2026-10-26T09:00:00Z'),
                    withItems('newer', '2026-10-26T11:00:00Z'),
                ],
            },
        });

        expect(await restoreBasket(context, 'gone')).toMatchObject({ basketId: 'newer' });
    });

    it('never restores a temporary basket or an empty one', async () => {
        getBasket.mockResolvedValue({ data: { ...withItems('tmp'), temporaryBasket: true } });
        getCustomerBaskets.mockResolvedValue({ data: { baskets: [{ basketId: 'empty', productItems: [] }] } });

        expect(await restoreBasket(context, 'tmp')).toBeNull();
        expect(updateBasketResource).not.toHaveBeenCalled();
    });
});
