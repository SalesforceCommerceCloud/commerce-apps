/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The Apple Pay domain association file, at
 * /.well-known/apple-developer-merchantid-domain-association (and with .txt,
 * the name Apple asks for now), where Apple verifies each storefront domain. Its content is the Apple Pay Domain
 * Association preference (Business Manager > Checkout.com Flow).
 *
 * Apple requests it without the site and locale prefix: add '/.well-known/**'
 * to url.excludeRoutes in config.server.ts (see the installation guide).
 */
import type { LoaderFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { getApplePayDomainAssociation } from '../lib/wallet.server';

export async function loader({ context }: LoaderFunctionArgs): Promise<Response> {
    let content = '';

    try {
        content = await getApplePayDomainAssociation(context);
    } catch (error) {
        getLogger(context).error('[checkoutcom] Apple Pay domain association unavailable', { error: String(error) });

        return new Response('Unavailable', { status: 503, headers: { 'Content-Type': 'text/plain' } });
    }

    if (!content) {
        return new Response('Not Found', { status: 404, headers: { 'Content-Type': 'text/plain' } });
    }

    return new Response(content, {
        status: 200,
        headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'public, max-age=3600' },
    });
}
