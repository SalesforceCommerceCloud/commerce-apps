'use strict';

var Logger = require('dw/system/Logger');
var PaymentTransaction = require('dw/order/PaymentTransaction');
var Status = require('dw/system/Status');

var config = require('*/cartridge/scripts/checkoutcom/config');
var details = require('*/cartridge/scripts/checkoutcom/details');
var gateway = require('*/cartridge/scripts/checkoutcom/gateway');
var ledger = require('*/cartridge/scripts/checkoutcom/ledger');
var orders = require('*/cartridge/scripts/checkoutcom/orders');
var payload = require('*/cartridge/scripts/checkoutcom/payload');

var log = Logger.getLogger(config.LOG_CATEGORY);

/**
 * The sfcc.app.payment.* hooks (Payment Commerce Apps, Beta), registered in
 * cartridge/hooks.json through scripts/hooks/payment.js.
 *
 * The platform dispatches them for the methods this app claims only (see
 * getClaimedPaymentMethods: CHECKOUTCOM_FLOW, and the express wallets
 * CHECKOUTCOM_APPLE_PAY and CHECKOUTCOM_GOOGLE_PAY) and runs each inside its
 * own transaction, so
 * nothing here opens a Transaction or calls OrderMgr: order state is changed by
 * the Custom API and the webhook, through OrderMgr.attemptOrderTransition and
 * OrderMgr.failOrder (see checkout.js).
 *
 * The order transition endpoints hand the payment to onAttemptOrderTransition
 * in request.custom, for the length of the request: checkout.submitPayment the
 * Flow session data, checkout.submitWalletPayment the Checkout.com token of a
 * wallet payment. Neither is ever stored.
 */

/* global request */

/** The request attribute that carries the Flow submission into the hook. */
var SUBMISSION = 'ckoFlowSubmission';

/** The request attribute the hook leaves the gateway's submit response in, for Flow. */
var SUBMIT_RESPONSE = 'ckoFlowSubmitResponse';

/** The request attribute that carries a wallet payment (token, return URLs) into the hook. */
var WALLET_SUBMISSION = 'ckoWalletSubmission';

/** The request attribute the hook leaves a wallet payment's outcome in (id, status, redirectUrl). */
var WALLET_RESPONSE = 'ckoWalletResponse';

var APPROVED_STATUSES = ['Authorized', 'Captured', 'Card Verified', 'Paid'];
var CAPTURED_STATUSES = ['Captured', 'Paid', 'Partially Refunded'];

/**
 * @returns {Object} The current request's custom attributes, or an empty map outside a request
 */
function requestScope() {
    return typeof request !== 'undefined' && request && request.custom ? request.custom : {};
}

/**
 * Keep a value for the rest of the request. Stored as JSON: request custom
 * attributes hold plain values.
 * @param {string} name The attribute name
 * @param {*} value The value; null clears it
 */
function setScoped(name, value) {
    requestScope()[name] = value === null || value === undefined ? null : JSON.stringify(value);
}

/**
 * @param {string} name The attribute name
 * @returns {*} The value kept for this request, or null
 */
function getScoped(name) {
    var raw = requestScope()[name];

    if (!raw) {
        return null;
    }

    try {
        return JSON.parse(raw);
    } catch (e) {
        return null;
    }
}

/**
 * @param {string} code The error code, for the log
 * @param {string} message The message, for the log
 * @returns {dw.system.Status} An error status
 */
function error(code, message) {
    return new Status(Status.ERROR, code, message);
}

/** @returns {dw.system.Status} An OK status */
function ok() {
    return new Status(Status.OK);
}

/**
 * @param {dw.order.PaymentTransaction} transaction The transaction
 * @returns {*} Its lifecycle status (PaymentTransaction.STATUS_*)
 */
function statusOf(transaction) {
    return typeof transaction.getStatus === 'function' ? transaction.getStatus() : transaction.status;
}

/**
 * @param {dw.order.PaymentTransaction} transaction The transaction
 * @returns {boolean} True when the platform counts it as paid
 */
function isSettled(transaction) {
    var status = statusOf(transaction);

    return status === PaymentTransaction.STATUS_AUTHORIZED || status === PaymentTransaction.STATUS_CAPTURED;
}

/**
 * The order's payment instrument: the first instrument of a claimed method.
 * Later ones are ledger entries for the Business Manager console (captures,
 * refunds, voids) and are never authorized or reversed on their own.
 * @param {dw.order.Order} order The order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
 * @returns {boolean} True for the order's payment instrument
 */
function isPrimary(order, paymentInstrument) {
    return orders.getPaymentInstrument(order) === paymentInstrument;
}

/**
 * The payment of an instrument, only when it is this order's: bound to it, or
 * submitted with its number as the reference.
 * @param {dw.order.Order} order The order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
 * @returns {string|null} The payment id
 */
function paymentIdOf(order, paymentInstrument) {
    var paymentId = paymentInstrument.getPaymentTransaction().getTransactionID() || order.custom.ckoPaymentId || null;
    var boundOrderNo = paymentId ? orders.getBoundOrderNo(paymentId) : null;

    return paymentId && (!boundOrderNo || boundOrderNo === order.getOrderNo()) ? paymentId : null;
}

/**
 * Record a verified payment on the order and set the instrument's status.
 * @param {dw.order.Order} order The order
 * @param {Object} payment The payment read back from Checkout.com
 * @returns {dw.system.Status} OK when approved or pending; ERROR when declined or not this order's
 */
function applyPayment(order, payment) {
    if (payment.reference !== order.getOrderNo() && orders.getBoundOrderNo(payment.id) !== order.getOrderNo()) {
        return error('PAYMENT_NOT_FOR_ORDER', 'Payment ' + payment.id + ' references ' + payment.reference);
    }

    if (payment.currency !== order.getCurrencyCode() || payment.amount !== payload.toMinorUnits(payload.getTotal(order))) {
        return error('AMOUNT_MISMATCH', 'Payment ' + payment.id + ' is for ' + payment.amount + ' ' + payment.currency);
    }

    if (APPROVED_STATUSES.indexOf(payment.status) === -1 && payment.status !== 'Pending') {
        return error('PAYMENT_' + String(payment.status).toUpperCase().replace(/\W+/g, '_'), 'Payment ' + payment.id + ' is ' + payment.status);
    }

    // Sets the transaction id, type and status: AUTHORIZED, CAPTURED or PENDING
    ledger.recordPayment(order, payment);
    orders.bindPayment(payment.id, order);
    // Card brand, last 4, AVS/CVC and 3DS, or the local method's details class
    details.apply(orders.getPaymentInstrument(order), payment);

    return ok();
}

/**
 * Finish an instrument whose payment exists at Checkout.com: read it back and
 * apply it. A payment that cannot be read stays PENDING for the webhook.
 * @param {dw.order.Order} order The order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
 * @param {string} paymentId The payment id
 * @returns {dw.system.Status} The outcome
 */
function finalize(order, paymentInstrument, paymentId) {
    var verification = gateway.getPayment(paymentId);

    if (!verification.ok || !verification.object) {
        log.warn('Order {0}: payment {1} could not be read back; left pending for its webhook.', order.getOrderNo(), paymentId);
        paymentInstrument.getPaymentTransaction().setTransactionID(paymentId);
        ledger.setStatus(paymentInstrument.getPaymentTransaction(), 'STATUS_PENDING');

        return ok();
    }

    return applyPayment(order, verification.object);
}

/**
 * Submit the payment Flow collected for the order, and apply the outcome.
 * @param {dw.order.Order} order The order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
 * @param {Object} submission sessionId and sessionData, from the transition endpoint
 * @returns {dw.system.Status} The outcome
 */
function submit(order, paymentInstrument, submission) {
    var transaction = paymentInstrument.getPaymentTransaction();
    var attempt = orders.getAttempt(order.getOrderNo());
    var request = payload.buildSubmitRequest(order, submission.sessionData);
    var result = gateway.submitPaymentSession(submission.sessionId, request);
    var retry = result.rejected ? payload.withoutRefusedUpdates(request, result.errorMessage) : null;

    if (retry) {
        // The method fixed the session's addresses (Klarna): keep them
        log.info('Order {0}: submitting again without the fields the session does not allow to update.', order.getOrderNo());
        result = gateway.submitPaymentSession(submission.sessionId, retry);
    }

    if (!result.ok || !result.object) {
        if (attempt) {
            attempt.custom.attemptState = result.rejected ? orders.ATTEMPT.REJECTED : orders.ATTEMPT.UNKNOWN;
        }

        if (result.rejected) {
            return error('SUBMIT_REFUSED', result.errorMessage);
        }

        // It may still have created a payment: the order stays open, and the
        // release endpoint or the webhook finds it by the order number
        log.warn('Order {0}: payment submission outcome unknown ({1}); left pending.', order.getOrderNo(), result.errorMessage);
        ledger.setStatus(transaction, 'STATUS_PENDING');

        return ok();
    }

    var response = result.object;

    setScoped(SUBMIT_RESPONSE, response);
    log.info('Payment {0} submitted for order {1}: {2}.', response.id, order.getOrderNo(), response.status);

    if (attempt) {
        attempt.custom.attemptState = orders.ATTEMPT.SUBMITTED;
        attempt.custom.attemptPaymentId = response.id || null;
    }

    if (!response.id) {
        return error('SUBMIT_NO_PAYMENT', 'The submission returned no payment id');
    }

    transaction.setTransactionID(response.id);
    order.custom.ckoPaymentId = response.id;
    orders.bindPayment(response.id, order);

    if (response.status === 'Declined') {
        return error('PAYMENT_DECLINED', 'Payment ' + response.id + ' declined');
    }

    if (response.status === 'Approved') {
        return finalize(order, paymentInstrument, response.id);
    }

    // Action Required (3DS, a redirect) or Pending: Flow completes it in the
    // browser and the completion endpoint or the webhook moves the order on
    ledger.setStatus(transaction, 'STATUS_PENDING');

    return ok();
}

/**
 * Pay the order with an express wallet (Apple Pay, Google Pay): POST /payments
 * with the Checkout.com token the storefront exchanged for the wallet token.
 * The idempotency key is derived from the order number, so a retried transition
 * never pays twice.
 * @param {dw.order.Order} order The order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
 * @param {Object} wallet token, tokenFormat, successUrl, failureUrl, from the wallet endpoint
 * @returns {dw.system.Status} The outcome
 */
function payWithWallet(order, paymentInstrument, wallet) {
    var transaction = paymentInstrument.getPaymentTransaction();
    var methodId = paymentInstrument.getPaymentMethod();
    var attempt = orders.getAttempt(order.getOrderNo());
    var result = gateway.requestPayment(payload.buildWalletPaymentRequest(order, methodId, wallet), order.getOrderNo());

    if (!result.ok || !result.object) {
        if (attempt) {
            attempt.custom.attemptState = result.rejected ? orders.ATTEMPT.REJECTED : orders.ATTEMPT.UNKNOWN;
        }

        if (result.rejected) {
            return error('PAYMENT_REFUSED', result.errorMessage);
        }

        // It may still have created a payment: the order stays open, and the
        // release endpoint or the webhook finds it by the order number
        log.warn('Order {0}: {1} payment outcome unknown ({2}); left pending.', order.getOrderNo(), methodId, result.errorMessage);
        ledger.setStatus(transaction, 'STATUS_PENDING');

        return ok();
    }

    var response = result.object;
    var redirect = response._links && response._links.redirect ? response._links.redirect.href : null;

    log.info('{0} payment {1} for order {2}: {3}.', methodId, response.id, order.getOrderNo(), response.status);
    setScoped(WALLET_RESPONSE, { id: response.id || null, status: response.status || null, redirectUrl: redirect });

    if (attempt) {
        attempt.custom.attemptState = orders.ATTEMPT.SUBMITTED;
        attempt.custom.attemptPaymentId = response.id || null;
    }

    if (!response.id) {
        return error('PAYMENT_NO_ID', 'The payment request returned no payment id');
    }

    transaction.setTransactionID(response.id);
    order.custom.ckoPaymentId = response.id;
    orders.bindPayment(response.id, order);

    if (response.status === 'Declined' || response.approved === false && !redirect) {
        return error('PAYMENT_DECLINED', 'Payment ' + response.id + ' declined');
    }

    if (redirect || response.status === 'Pending') {
        // 3D Secure for a card stored in the shopper's Google account: the
        // shopper returns through /cko-return, whose completion places the order
        ledger.setStatus(transaction, 'STATUS_PENDING');

        return ok();
    }

    return finalize(order, paymentInstrument, response.id);
}

/**
 * Release a payment: void it while authorized, refund it once captured. The
 * gateway's own state decides, so a repeated reversal does nothing.
 * @param {Object} payment The payment read back from Checkout.com
 * @param {string} reference The reversal reference
 * @returns {{ok: boolean, status: string|null, errorMessage: string|null}} status is the transaction status reached
 */
function reverse(payment, reference) {
    var captured = CAPTURED_STATUSES.indexOf(payment.status) !== -1;

    if (!captured && payment.status !== 'Authorized' && payment.status !== 'Card Verified') {
        // Voided, Refunded, Declined, Expired: nothing left to release. Pending:
        // not reversible yet; if it is approved later, the webhook releases it
        return { ok: true, status: null, errorMessage: null };
    }

    var result = captured ? gateway.refundPayment(payment.id, reference) : gateway.voidPayment(payment.id, reference);

    return {
        ok: result.ok,
        status: captured ? 'STATUS_CAPTUREVOIDED' : 'STATUS_AUTHORIZATIONVOIDED',
        errorMessage: result.errorMessage,
    };
}

/**
 * A utility hook action on one of our instruments.
 * @param {dw.order.Order} order The order
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
 * @param {string} requiredStatus The transaction status the action needs
 * @param {Function} perform (paymentId, transaction) => gateway call result
 * @param {string} statusAfter The transaction status after success
 * @param {string} [typeAfter] The transaction type after success
 * @returns {dw.system.Status} The outcome
 */
function utility(order, paymentInstrument, requiredStatus, perform, statusAfter, typeAfter) {
    if (!config.isClaimed(paymentInstrument.getPaymentMethod())) {
        return error('NOT_CHECKOUTCOM', 'The instrument is not a Checkout.com instrument');
    }

    var transaction = paymentInstrument.getPaymentTransaction();
    var paymentId = paymentIdOf(order, paymentInstrument);

    if (!paymentId || statusOf(transaction) !== PaymentTransaction[requiredStatus]) {
        return error('INVALID_STATE', 'The transaction must be ' + requiredStatus + ' with a Checkout.com payment');
    }

    var result = perform(paymentId, transaction);

    if (!result.ok) {
        return error('GATEWAY_ERROR', result.errorMessage);
    }

    if (typeAfter) {
        transaction.setType(PaymentTransaction[typeAfter]);
    }

    ledger.setStatus(transaction, statusAfter);

    return ok();
}

module.exports = {
    SUBMISSION: SUBMISSION,
    SUBMIT_RESPONSE: SUBMIT_RESPONSE,
    WALLET_SUBMISSION: WALLET_SUBMISSION,
    WALLET_RESPONSE: WALLET_RESPONSE,
    setScoped: setScoped,
    getScoped: getScoped,
    applyPayment: applyPayment,
    reverse: reverse,

    /** @returns {string[]} The payment methods this app owns */
    getClaimedPaymentMethods: function() {
        return config.CLAIMED_METHODS.slice();
    },

    /**
     * A basket may hold one Checkout.com instrument: a second would add to the amounts,
     * and the order could never match its total.
     * @param {dw.order.Basket} basket The basket
     * @param {dw.order.PaymentInstrument} paymentInstrument The new instrument
     * @returns {dw.system.Status} ERROR rolls the creation back
     */
    afterCreateBasketPaymentInstrument: function(basket, paymentInstrument) {
        var others = orders.getClaimedInstruments(basket).filter(function(instrument) {
            return instrument !== paymentInstrument;
        });

        return others.length > 0 ? error('DUPLICATE_INSTRUMENT', 'The basket already has a Checkout.com instrument') : ok();
    },

    /** @returns {dw.system.Status} OK: nothing to check when the amount is updated */
    afterUpdateBasketPaymentInstrument: function() {
        return ok();
    },

    /**
     * An order instrument updated through SCAPI (a redirect return that PATCHes
     * it): finish a pending payment server-to-server. The platform then
     * attempts the order transition itself.
     * @param {dw.order.Order} order The order
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {dw.system.Status} The outcome
     */
    afterUpdateOrderPaymentInstrument: function(order, paymentInstrument) {
        var transaction = paymentInstrument.getPaymentTransaction();
        var paymentId = paymentIdOf(order, paymentInstrument);

        if (!isPrimary(order, paymentInstrument) || isSettled(transaction) || !paymentId) {
            return ok();
        }

        return finalize(order, paymentInstrument, paymentId);
    },

    /**
     * Authorize the order's instrument (attemptOrderTransition, status CREATED):
     * submit the payment Flow collected, or pick up the payment it already has.
     * @param {dw.order.Order} order The order
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {dw.system.Status} OK (authorized, captured or pending); ERROR fails the order
     */
    onAttemptOrderTransition: function(order, paymentInstrument) {
        var transaction = paymentInstrument.getPaymentTransaction();

        if (!isPrimary(order, paymentInstrument)) {
            return error('DUPLICATE_INSTRUMENT', 'Order ' + order.getOrderNo() + ' has more than one Checkout.com instrument');
        }

        if (isSettled(transaction)) {
            return ok();
        }

        var paymentId = paymentIdOf(order, paymentInstrument);

        if (paymentId) {
            // A retried transition: the payment exists, never submit another one
            return finalize(order, paymentInstrument, paymentId);
        }

        if (paymentInstrument.getPaymentMethod() !== config.METHODS.FLOW) {
            var wallet = getScoped(WALLET_SUBMISSION);

            if (wallet && wallet.orderNo === order.getOrderNo()) {
                return payWithWallet(order, paymentInstrument, wallet);
            }
        } else {
            var submission = getScoped(SUBMISSION);

            if (submission && submission.orderNo === order.getOrderNo()) {
                return submit(order, paymentInstrument, submission);
            }
        }

        // Nothing submitted in this request: wait for the completion or the webhook
        ledger.setStatus(transaction, 'STATUS_PENDING');

        return ok();
    },

    /**
     * The order failed or was cancelled: void or refund its payment. Called for
     * every claimed instrument; only the order's payment instrument reverses.
     * @param {dw.order.Order} order The order
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {dw.system.Status} ERROR is logged by the platform; the order fails anyway
     */
    reversePayment: function(order, paymentInstrument) {
        var paymentId = paymentIdOf(order, paymentInstrument);

        if (!isPrimary(order, paymentInstrument) || !paymentId) {
            return ok();
        }

        var verification = gateway.getPayment(paymentId);

        if (!verification.ok || !verification.object) {
            log.error('Order {0}: payment {1} could not be read to reverse it; reconcile it in the Checkout.com Dashboard.', order.getOrderNo(), paymentId);

            return error('REVERSAL_UNVERIFIED', verification.errorMessage);
        }

        var reversal = reverse(verification.object, 'sfcc_order_' + order.getOrderNo());

        if (!reversal.ok) {
            log.error('Order {0}: payment {1} could not be reversed: {2}', order.getOrderNo(), paymentId, reversal.errorMessage);

            return error('REVERSAL_FAILED', reversal.errorMessage);
        }

        if (reversal.status) {
            ledger.setStatus(paymentInstrument.getPaymentTransaction(), reversal.status);
            log.info('Order {0}: payment {1} reversed ({2}).', order.getOrderNo(), paymentId, reversal.status);
        }

        return ok();
    },

    /**
     * Not supported: a Flow payment is authorized in the shopper's browser
     * session, through the order transition endpoint.
     * @returns {dw.system.Status} ERROR
     */
    authorizePayment: function() {
        return error('NOT_SUPPORTED', 'Checkout.com Flow payments are authorized in the shopper session');
    },

    /**
     * Capture an authorized payment in full (for example on shipment).
     * @param {dw.order.Order} order The order
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {dw.system.Status} The outcome
     */
    capturePayment: function(order, paymentInstrument) {
        return utility(order, paymentInstrument, 'STATUS_AUTHORIZED', function(paymentId, transaction) {
            // With the order's Level 2 / Level 3 data for a card payment (payload.buildCaptureRequest)
            return gateway.capturePayment(paymentId, payload.buildCaptureRequest(
                order,
                payload.toMinorUnits(transaction.getAmount()),
                details.isCard(paymentInstrument)
            ));
        }, 'STATUS_CAPTURED', 'TYPE_CAPTURE');
    },

    /**
     * Void an authorized payment before capture.
     * @param {dw.order.Order} order The order
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {dw.system.Status} The outcome
     */
    cancelAuthorization: function(order, paymentInstrument) {
        return utility(order, paymentInstrument, 'STATUS_AUTHORIZED', function(paymentId) {
            return gateway.voidPayment(paymentId, 'sfcc_order_' + order.getOrderNo());
        }, 'STATUS_AUTHORIZATIONVOIDED');
    },

    /**
     * Refund a captured payment in full.
     * @param {dw.order.Order} order The order
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {dw.system.Status} The outcome
     */
    refundCapture: function(order, paymentInstrument) {
        return utility(order, paymentInstrument, 'STATUS_CAPTURED', function(paymentId) {
            return gateway.refundPayment(paymentId, 'sfcc_order_' + order.getOrderNo());
        }, 'STATUS_CAPTUREVOIDED');
    },
};
