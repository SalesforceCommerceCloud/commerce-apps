'use strict';

var KeyRef = require('dw/crypto/KeyRef');
var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');

var config = require('*/cartridge/scripts/checkoutcom/config');

var log = Logger.getLogger(config.LOG_CATEGORY);

/**
 * Apple Pay merchant validation for the express checkout buttons.
 *
 * When the payment sheet opens, Apple gives the browser a validation URL; the
 * instance POSTs the merchant's identity to it over mutual TLS, presenting the
 * Apple Pay merchant identity certificate from Business Manager (Administration
 * > Operations > Private Keys and Certificates, alias in the Apple Pay
 * Certificate Alias preference), and the opaque merchant session it returns
 * goes back to the sheet. The payment itself is the express wallet payment
 * (payments.js payWithWallet), with the token Checkout.com decrypts.
 *
 * Only Apple's validation hosts are ever called: the URL comes from the
 * browser.
 */

/** Apple's merchant validation hosts, production and sandbox (Apple Pay on the Web). */
var VALIDATION_URL = /^https:\/\/(cn-)?apple-pay-gateway(-(nc|pr|sh|tj)-pod\d{1,2}|-cert)?\.apple\.com\/paymentservices\/(paymentSession|startSession)$/;

/** A host name, without port or path. */
var DOMAIN = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i;

module.exports = {
    VALIDATION_URL: VALIDATION_URL,

    /**
     * @param {string} url The validation URL from the Apple Pay sheet
     * @returns {boolean} True for one of Apple's validation endpoints
     */
    isValidationUrl: function(url) {
        return typeof url === 'string' && VALIDATION_URL.test(url);
    },

    /**
     * @param {string} domain The storefront domain
     * @returns {boolean} True for a plain host name
     */
    isDomain: function(domain) {
        return typeof domain === 'string' && DOMAIN.test(domain);
    },

    /**
     * Request a merchant session from Apple.
     * @param {string} validationUrl Apple's validation URL (checked by isValidationUrl)
     * @param {Object} merchant merchantIdentifier, displayName, initiativeContext (the storefront domain), certificateAlias
     * @returns {{ok: boolean, session: Object|null, errorMessage: string|null}} The merchant session, opaque, for the sheet
     */
    validateMerchant: function(validationUrl, merchant) {
        var service = LocalServiceRegistry.createService('cko.applepay.validation.service', {
            createRequest: function(svc, body) {
                // Mutual TLS with the merchant identity certificate
                svc.setIdentity(new KeyRef(merchant.certificateAlias));
                svc.setRequestMethod('POST');
                svc.addHeader('Content-Type', 'application/json');

                return JSON.stringify(body);
            },
            parseResponse: function(svc, response) {
                try {
                    return JSON.parse(response.text);
                } catch (e) {
                    return null;
                }
            },
            // The merchant session is a payment credential for the sheet: never logged
            filterLogMessage: function() {
                return '[Apple Pay merchant session request or response]';
            },
        });

        service.setURL(validationUrl);

        var result = service.call({
            merchantIdentifier: merchant.merchantIdentifier,
            displayName: merchant.displayName,
            initiative: 'web',
            initiativeContext: merchant.initiativeContext,
        });

        if (!result.isOk() || !result.getObject()) {
            log.error('Apple Pay merchant validation failed: {0}', result.getErrorMessage() || result.getError());

            return { ok: false, session: null, errorMessage: 'Apple Pay merchant validation failed' };
        }

        return { ok: true, session: result.getObject(), errorMessage: null };
    },
};
