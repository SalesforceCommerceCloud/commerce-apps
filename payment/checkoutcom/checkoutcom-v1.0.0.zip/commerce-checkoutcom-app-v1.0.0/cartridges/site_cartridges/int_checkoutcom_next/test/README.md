# Cartridge unit tests

Unit tests for the `int_checkoutcom_next` and `bm_checkoutcom` cartridges, with fakes for the
B2C Commerce Script API (`helpers/sfcc.js`). No instance or network is needed.

```bash
node --test test/*.test.js     # from int_checkoutcom_next/, Node 22 or later
```

They cover the money-critical paths, among them:

| Area | Tests |
| --- | --- |
| Webhook authentication (HMAC-SHA256 signature, key rotation) and idempotency | `webhooks.test.js` |
| Amounts: Checkout.com minor units per currency, amount matching, items adding up | `payload.test.js`, `checkout.test.js`, `level23.test.js` |
| Confirmation against the gateway's balances before a webhook is recorded | `webhooks.test.js` |
| Order placement, failure, reversal, pending orders, concurrent requests | `payments.test.js`, `checkout.test.js`, `reliability.test.js` |
| Business Manager capture, refund and void: the order's own payment, amounts capped at the payment's balances, CSRF, the transactions list | `bm-console.test.js` |
| Express wallets, Apple Pay merchant validation, card payment details | `wallets.test.js`, `applepay.test.js`, `details.test.js` |

In the source repository they run with `npm test`. The Storefront Next extension's tests are under
`storefront-next/src/extensions/checkoutcom/**/*.test.ts` (Vitest, in the storefront).
