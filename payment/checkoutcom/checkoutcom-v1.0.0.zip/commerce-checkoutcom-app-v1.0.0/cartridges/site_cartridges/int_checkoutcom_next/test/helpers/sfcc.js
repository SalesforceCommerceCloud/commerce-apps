'use strict';

/**
 * Minimal SFCC runtime for unit tests: maps `dw/*` requires to fakes and
 * `*\/cartridge/*` requires to int_checkoutcom_next, and provides factories for
 * the baskets, orders and payment instruments the checkout scripts work with.
 */

const Module = require('module');
const path = require('path');

const fs = require('fs');

/**
 * A cartridge's folder. These tests live in int_checkoutcom_next/test, next to its
 * cartridge/ folder: the other cartridges are its siblings, cartridges/<name> in
 * the source repository, or cartridges/{site,bm}_cartridges/<name> in the
 * Commerce App package, which ships these tests too.
 */
const OWN_CARTRIDGE_FOLDER = path.resolve(__dirname, '../..');
const cartridgeRoot = (name, packageFolder) =>
    [path.join(OWN_CARTRIDGE_FOLDER, '..', name, 'cartridge'), path.join(OWN_CARTRIDGE_FOLDER, '..', '..', packageFolder, name, 'cartridge')].find(
        (candidate) => fs.existsSync(candidate)
    );

const CARTRIDGE = cartridgeRoot('int_checkoutcom_next', 'site_cartridges');
// The Business Manager cartridge: load(path, { cartridge: 'bm' })
const BM_CARTRIDGE = cartridgeRoot('bm_checkoutcom', 'bm_cartridges');
// "*/cartridge/..." resolves in the cartridge of the module being loaded
let activeCartridge = CARTRIDGE;

const mocks = new Map();
const originalLoad = Module._load;
const originalResolve = Module._resolveFilename;

Module._resolveFilename = function resolve(request, parent, ...rest) {
    if (request.startsWith('*/cartridge/')) {
        const from = parent && parent.filename;
        const root = from && from.startsWith(BM_CARTRIDGE) ? BM_CARTRIDGE : from && from.startsWith(CARTRIDGE) ? CARTRIDGE : activeCartridge;

        return originalResolve.call(this, path.join(root, request.slice('*/cartridge/'.length)), parent, ...rest);
    }

    return originalResolve.call(this, request, parent, ...rest);
};

Module._load = function load(request, parent, isMain) {
    if (request.startsWith('dw/')) {
        if (!mocks.has(request)) {
            throw new Error(`No mock registered for ${request}`);
        }

        return mocks.get(request);
    }

    return originalLoad.call(this, request, parent, isMain);
};

/** Money with the subset of dw.value.Money the scripts use. */
class Money {
    constructor(value, currencyCode) {
        this.value = value;
        this.currencyCode = currencyCode;
    }

    getValue() {
        return this.value;
    }

    getCurrencyCode() {
        return this.currencyCode;
    }

    isAvailable() {
        return true;
    }
}

const ORDER = {
    ORDER_STATUS_CREATED: 0,
    ORDER_STATUS_NEW: 3,
    ORDER_STATUS_OPEN: 4,
    ORDER_STATUS_COMPLETED: 5,
    ORDER_STATUS_CANCELLED: 6,
    ORDER_STATUS_FAILED: 8,
    PAYMENT_STATUS_NOTPAID: 0,
    PAYMENT_STATUS_PARTPAID: 1,
    PAYMENT_STATUS_PAID: 2,
    CONFIRMATION_STATUS_NOTCONFIRMED: 0,
    CONFIRMATION_STATUS_CONFIRMED: 2,
    EXPORT_STATUS_NOTEXPORTED: 0,
    EXPORT_STATUS_READY: 2,
};

/** dw.system.Status */
class Status {
    constructor(status, code, message) {
        this.status = status;
        this.code = code || null;
        this.message = message || null;
    }

    isError() {
        return this.status === Status.ERROR;
    }

    getCode() {
        return this.code;
    }

    getMessage() {
        return this.message;
    }
}

Status.OK = 0;
Status.ERROR = 1;

/** @returns {Object} An iterable SFCC collection over an array */
function collection(items) {
    return {
        toArray: () => items.slice(),
        size: () => items.length,
        isEmpty: () => items.length === 0,
        iterator: () => {
            let index = 0;

            return { hasNext: () => index < items.length, next: () => items[index++] };
        },
    };
}

/** @returns {Object} A payment instrument with a transaction */
function makeInstrument(methodId, amount) {
    const transaction = {
        custom: {},
        amount,
        setTransactionID(id) { this.transactionID = id; },
        getTransactionID() { return this.transactionID || null; },
        setPaymentProcessor(processor) { this.paymentProcessor = processor; },
        setType(type) { this.type = type; },
        setStatus(status) { this.status = status; },
        getStatus() { return this.status === undefined ? 'CREATED' : this.status; },
        setAmount(value) { this.amount = value; },
        getAmount() { return this.amount; },
    };

    transaction.setTransactionDetails = function setTransactionDetails(details) { this.transactionDetails = details; };
    transaction.getTransactionDetails = function getTransactionDetails() { return this.transactionDetails || null; };

    return {
        methodId,
        getPaymentMethod: () => methodId,
        getPaymentTransaction: () => transaction,
        setPaymentDetails(details) { this.paymentDetails = details; },
        getPaymentDetails() { return this.paymentDetails || null; },
    };
}

/** @returns {Object} An order address */
function makeAddress(overrides = {}) {
    const values = {
        address1: '1 Main St', address2: null, city: 'London', stateCode: null, postalCode: 'N1 1AA',
        countryCode: 'gb', phone: null, fullName: 'Jordan Smith', ...overrides,
    };

    return {
        getAddress1: () => values.address1,
        getAddress2: () => values.address2,
        getCity: () => values.city,
        getStateCode: () => values.stateCode,
        getPostalCode: () => values.postalCode,
        getCountryCode: () => (values.countryCode ? { getValue: () => values.countryCode } : null),
        getPhone: () => values.phone,
        getFullName: () => values.fullName,
    };
}

/**
 * A basket or order (dw.order.LineItemCtnr subset).
 * @param {Object} options currency, lines [{ id, name, qty, total, base, prorated, options }], giftCertificates,
 *   shipping, shippingBase, tax, orderNo, status, customerId. A line's base is its price before promotions, total
 *   after product promotions and prorated after order promotions too; options are [{ id, valueId, text, qty, base, prorated }].
 */
function makeContainer(options = {}) {
    const currency = options.currency || 'GBP';
    const definitions = options.lines || [{ id: 'P1', name: 'Shirt', qty: 2, total: 40 }];
    const lines = definitions.map((line) => ({
        getProductID: () => line.id,
        getProductName: () => line.name,
        getQuantityValue: () => line.qty,
        getPrice: () => new Money(line.base ?? line.total, currency),
        getAdjustedPrice: () => new Money(line.total, currency),
        getProratedPrice: () => new Money(line.prorated ?? line.total, currency),
        // Optional: the line's tax and the product's sales unit (Level 2 / Level 3 data)
        ...(line.tax === undefined ? {} : { getTax: () => new Money(line.tax, currency) }),
        getProduct: () => (line.unit === undefined ? null : { getUnit: () => line.unit }),
        getOptionProductLineItems: () => collection((line.options || []).map((option) => ({
            getOptionID: () => option.id,
            getOptionValueID: () => option.valueId,
            getLineItemText: () => option.text,
            getQuantityValue: () => option.qty ?? line.qty,
            getPrice: () => new Money(option.base, currency),
            getProratedPrice: () => new Money(option.prorated ?? option.base, currency),
        }))),
    }));
    const giftCertificates = (options.giftCertificates || []).map((amount, index) => ({
        getUUID: () => `gc-${index + 1}`,
        getPrice: () => new Money(amount, currency),
    }));
    const shipping = options.shipping === undefined ? 5 : options.shipping;
    const tax = options.tax || 0;
    const merchandise = definitions.reduce((sum, line) => sum + (line.prorated ?? line.total)
        + (line.options || []).reduce((optionSum, option) => optionSum + (option.prorated ?? option.base), 0), 0);
    const total = merchandise + giftCertificates.reduce((sum, item) => sum + item.getPrice().getValue(), 0) + shipping + (options.netTax ? tax : 0);
    const instruments = Array.from({ length: options.instruments || 1 }, () => makeInstrument(options.method || 'CHECKOUTCOM_FLOW', new Money(total, currency)));
    const customerId = options.customerId || 'cust-1';

    const container = {
        custom: {},
        notes: [],
        status: options.status === undefined ? ORDER.ORDER_STATUS_CREATED : options.status,
        paymentStatus: ORDER.PAYMENT_STATUS_NOTPAID,
        getUUID: () => options.uuid || 'basket-1',
        getOrderNo: () => options.orderNo || '00001',
        getOrderToken: () => options.orderToken || `token-${options.orderNo || '00001'}`,
        getCurrencyCode: () => currency,
        getProductLineItems: () => collection(lines),
        getGiftCertificateLineItems: () => collection(giftCertificates),
        getShippingTotalPrice: () => new Money(options.shippingBase ?? shipping, currency),
        getAdjustedShippingTotalPrice: () => new Money(shipping, currency),
        getTotalTax: () => new Money(tax, currency),
        getTotalGrossPrice: () => new Money(total, currency),
        getBillingAddress: () => (options.noAddress ? null : makeAddress(options.billing)),
        getDefaultShipment: () => ({ getShippingAddress: () => (options.noAddress ? null : makeAddress()) }),
        getCustomerEmail: () => 'jordan@example.com',
        getCustomer: () => ({ getID: () => customerId, isRegistered: () => false, getProfile: () => null }),
        getStatus() { return { getValue: () => this.status }; },
        getPaymentStatus() { return { getValue: () => this.paymentStatus }; },
        setPaymentStatus(status) { this.paymentStatus = status; },
        setConfirmationStatus(status) { this.confirmationStatus = status; },
        setExportStatus(status) { this.exportStatus = status; },
        getExportStatus() { return { getValue: () => (this.exportStatus === undefined ? ORDER.EXPORT_STATUS_NOTEXPORTED : this.exportStatus) }; },
        addNote(subject, text) { this.notes.push(text); },
        getPaymentInstruments: (methodId) => collection(methodId ? instruments.filter((i) => i.methodId === methodId) : instruments),
        removePaymentInstrument: (instrument) => {
            instruments.splice(instruments.indexOf(instrument), 1);
        },
        createPaymentInstrument: (methodId, amount) => {
            const instrument = makeInstrument(methodId, amount);

            instruments.push(instrument);

            return instrument;
        },
        instruments,
    };

    return container;
}

/**
 * Register the default dw fakes, override some, and load a cartridge module fresh.
 * @param {string} modulePath Path relative to the cartridge, e.g. scripts/checkoutcom/checkout
 * @param {Object} overrides dw module fakes to replace
 * @returns {Object} The loaded module
 */
function load(modulePath, overrides = {}) {
    const preferences = overrides.preferences || {};
    // Service credential passwords (secrets): the secret API keys and the webhook key
    const credentials = {
        'cko.keys.sandbox.service': 'sk_sbox_test',
        'cko.keys.production.service': 'sk_test',
        'cko.webhook.service': 'psk_test',
        ...(overrides.credentials || {}),
    };

    mocks.clear();
    activeCartridge = overrides.cartridge === 'bm' ? BM_CARTRIDGE : CARTRIDGE;
    // The request scope the transition endpoint hands the Flow submission through
    globalThis.request = { custom: {} };

    const defaults = {
        'dw/system/Site': { getCurrent: () => ({ getID: () => 'TestSite', getName: () => 'Test Site', getCustomPreferenceValue: (id) => preferences[id] ?? null }) },
        'dw/system/Logger': { getLogger: () => ({ error() {}, warn() {}, info() {} }) },
        'dw/system/Transaction': { wrap: (fn) => fn() },
        'dw/system/Status': Status,
        'dw/util/Currency': { getCurrency: (code) => ({ getDefaultFractionDigits: () => (code === 'JPY' ? 0 : 2) }) },
        'dw/value/Money': Money,
        'dw/order/TaxMgr': { TAX_POLICY_NET: 1, TAX_POLICY_GROSS: 0, getTaxationPolicy: () => overrides.taxPolicy ?? 0 },
        'dw/order/Order': ORDER,
        'dw/order/PaymentMgr': { getPaymentMethod: () => ({ isActive: () => overrides.flowActive !== false, getPaymentProcessor: () => ({ getID: () => 'CHECKOUTCOM_FLOW' }) }) },
        'dw/order/PaymentTransaction': {
            TYPE_AUTH: 'AUTH', TYPE_CAPTURE: 'CAPTURE', TYPE_CREDIT: 'CREDIT', TYPE_AUTH_REVERSAL: 'AUTH_REVERSAL',
            STATUS_CREATED: 'CREATED', STATUS_PENDING: 'PENDING', STATUS_AUTHORIZED: 'AUTHORIZED', STATUS_CAPTURED: 'CAPTURED',
            STATUS_AUTHORIZATIONVOIDED: 'AUTHORIZATIONVOIDED', STATUS_CAPTUREVOIDED: 'CAPTUREVOIDED',
        },
        'dw/order/BasketMgr': { getCurrentBasket: () => null },
        'dw/order/OrderMgr': { getOrder: () => null },
        'dw/object/CustomObjectMgr': { getCustomObject: () => null, createCustomObject: () => ({ custom: {} }) },
        // Key-holder services serve their credential password; any other service
        // is a gateway call, which tests mock through the gateway module
        'dw/svc/LocalServiceRegistry': {
            createService: (serviceId) => {
                if (!Object.prototype.hasOwnProperty.call(credentials, serviceId)) {
                    throw new Error('gateway not mocked');
                }

                return { getConfiguration: () => ({ getCredential: () => ({ getPassword: () => credentials[serviceId] }) }) };
            },
        },
        'dw/crypto/Mac': class {},
        'dw/crypto/KeyRef': class KeyRef { constructor(alias) { this.alias = alias; } },
        'dw/crypto/Encoding': {},
    };

    Object.entries({ ...defaults, ...overrides }).forEach(([key, value]) => {
        if (key.startsWith('dw/')) {
            mocks.set(key, value);
        }
    });

    Object.keys(require.cache).forEach((file) => {
        if (file.startsWith(CARTRIDGE) || file.startsWith(BM_CARTRIDGE)) {
            delete require.cache[file];
        }
    });

    // The cartridge's own modules can be replaced too (e.g. the gateway)
    Object.entries(overrides).forEach(([key, value]) => {
        if (key.startsWith('*/cartridge/')) {
            const file = require.resolve(key);

            require.cache[file] = { id: file, filename: file, loaded: true, exports: value };
        }
    });

    return require(path.join(activeCartridge, modulePath));
}

/**
 * A Shopper Baskets (SCAPI) basket, as the storefront sends it.
 * @param {Object} options basketId, currency, items [{ productId, productName, quantity, priceAfterItemDiscount }], shippingTotal, taxTotal, taxation, orderTotal
 */
function makeScapiBasket(options = {}) {
    const items = options.items || [{ productId: 'P1', productName: 'Shirt', quantity: 2, priceAfterItemDiscount: 40 }];
    const shippingTotal = options.shippingTotal === undefined ? 5 : options.shippingTotal;
    const taxTotal = options.taxTotal || 0;
    const computed = items.reduce((sum, item) => sum + (item.priceAfterOrderDiscount ?? item.priceAfterItemDiscount), 0)
        + shippingTotal + (options.taxation === 'net' ? taxTotal : 0);
    const address = { firstName: 'Jordan', lastName: 'Smith', address1: '1 Main St', address2: null, city: 'London', postalCode: 'N1 1AA', countryCode: 'gb', stateCode: null, phone: null };

    return {
        basketId: options.basketId || 'basket-1',
        currency: options.currency || 'GBP',
        orderTotal: options.orderTotal === undefined ? computed : options.orderTotal,
        productItems: items,
        shippingTotal,
        shippingItems: options.shippingItems,
        taxTotal,
        taxation: options.taxation || 'gross',
        customerInfo: { email: 'jordan@example.com' },
        billingAddress: options.noAddress ? null : address,
        shipments: [{ shippingAddress: options.noAddress ? null : address }],
    };
}

/** An in-memory dw.object.CustomObjectMgr; `objects` holds { 'type/key': object }. */
function customObjects() {
    const objects = {};

    return {
        objects,
        getCustomObject: (type, key) => objects[`${type}/${key}`] || null,
        // Like the platform, a key can only be created once
        createCustomObject: (type, key) => {
            if (objects[`${type}/${key}`]) {
                throw new Error(`Custom object ${type}/${key} already exists`);
            }

            objects[`${type}/${key}`] = { custom: {} };

            return objects[`${type}/${key}`];
        },
    };
}

/**
 * A dw.order.OrderMgr over a set of orders. Like a storefront request with
 * Limit Storefront Order Access enabled, getOrder(no, token) needs the token.
 */
function orderManager(ordersByNo, extra = {}) {
    return {
        getOrder: (no, token) => {
            const order = ordersByNo[no] || null;

            if (order && token !== undefined && token !== order.getOrderToken()) {
                return null;
            }

            return order;
        },
        searchOrders: () => {
            throw new Error('searchOrders is restricted in storefront requests');
        },
        ...extra,
    };
}

/**
 * The Payment Commerce Apps platform, as the guide describes it, for an
 * OrderMgr fake: attemptOrderTransition runs onAttemptOrderTransition for each
 * CHECKOUTCOM_FLOW instrument still at CREATED, fails the order on an error,
 * and places it once every instrument is AUTHORIZED or CAPTURED and the amounts
 * match the total; failOrder runs reversePayment for each instrument.
 * @param {Object} calls Records placed, failed and reversed order numbers
 * @returns {Object} attemptOrderTransition and failOrder
 */
function paymentPlatform(calls) {
    const hooks = () => require(path.join(CARTRIDGE, 'scripts/checkoutcom/payments'));
    const CLAIMED = ['CHECKOUTCOM_FLOW', 'CHECKOUTCOM_APPLE_PAY', 'CHECKOUTCOM_GOOGLE_PAY'];
    const claimed = (order) => order.getPaymentInstruments().toArray().filter((instrument) => CLAIMED.includes(instrument.getPaymentMethod()));
    const result = (isError, isFinal) => ({ isError: () => isError, isFinal: () => isFinal, getStep: () => 'payment', getReason: () => null });

    const platform = {
        failOrder(order) {
            if (order.status !== ORDER.ORDER_STATUS_CREATED) {
                return new Status(Status.ERROR);
            }

            order.status = ORDER.ORDER_STATUS_FAILED;
            (calls.failed || []).push(order.getOrderNo());
            claimed(order).forEach((instrument) => {
                hooks().reversePayment(order, instrument);
            });

            return new Status(Status.OK);
        },
        attemptOrderTransition(order) {
            if (order.status !== ORDER.ORDER_STATUS_CREATED) {
                return result(false, true);
            }

            for (const instrument of claimed(order)) {
                const transaction = instrument.getPaymentTransaction();

                if (transaction.getStatus() !== 'CREATED') {
                    continue;
                }

                let status;

                try {
                    status = hooks().onAttemptOrderTransition(order, instrument);
                } catch (e) {
                    status = new Status(Status.ERROR, 'THROWN', e.message);
                }

                if (status && status.isError()) {
                    platform.failOrder(order);

                    return result(true, true);
                }

                if (transaction.getStatus() === 'CREATED') {
                    transaction.setStatus('PENDING');
                }
            }

            const instruments = claimed(order);
            const paid = instruments.every((instrument) => ['AUTHORIZED', 'CAPTURED'].includes(instrument.getPaymentTransaction().getStatus()));
            const sum = instruments.reduce((total, instrument) => total + instrument.getPaymentTransaction().getAmount().getValue(), 0);

            if (instruments.length > 0 && paid && Math.abs(sum - order.getTotalGrossPrice().getValue()) < 0.005) {
                order.status = ORDER.ORDER_STATUS_NEW;
                (calls.placed || []).push(order.getOrderNo());

                return result(false, true);
            }

            return result(false, false);
        },
    };

    return platform;
}

module.exports = { CARTRIDGE, BM_CARTRIDGE, load, paymentPlatform, Status, makeContainer, makeScapiBasket, makeAddress, customObjects, orderManager, Money, ORDER };
