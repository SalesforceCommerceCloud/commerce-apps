'use strict';

/**
 * Findings of the 2026-11-16 security scan of the SFRA cartridge that also
 * applied here: the Checkout.com risk flag (5), the communication log (14) and
 * a payment of another site carrying the same order number (4).
 */

const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const { stamped, load, makeContainer, makeScapiBasket, customObjects, orderManager, ORDER, paymentPlatform } = require('./helpers/sfcc');

const KEYS = {
    ckoMode: 'sandbox',
    ckoPublicKey: 'pk_sbox_test',
    ckoFlowAllowedReturnOrigins: 'https://shop.example',
};

let calls;
let objects;

beforeEach(() => {
    calls = { voids: [], refunds: [], failed: [], placed: [], submitted: [] };
    objects = customObjects();
    globalThis.customer = { getID: () => 'cust-1', isRegistered: () => false };
});

/**
 * The checkout module over a payment read back from Checkout.com.
 * @param {Object} payment The payment
 * @param {Object} ordersByNo The orders
 * @returns {Object} The checkout module
 */
function checkout(payment, ordersByNo) {
    return load('scripts/checkoutcom/checkout', {
        preferences: KEYS,
        'dw/order/OrderMgr': orderManager(ordersByNo, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': {
            getPayment: () => ({ ok: true, object: payment }),
            voidPayment: (id) => { calls.voids.push(id); return { ok: true }; },
            refundPayment: (id) => { calls.refunds.push(id); return { ok: true }; },
            createPaymentSession: () => ({ ok: true, object: { id: 'ps_1' } }),
        },
    });
}

const authorized = (metadata) => ({ id: 'pay_1', status: 'Authorized', amount: 4500, currency: 'GBP', reference: '00001', metadata });

// Finding 4 ----------------------------------------------------------------

test('finding 4: a payment of another site with the same order number and customer neither places nor fails the order', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = checkout(authorized({ sfcc_site_id: 'OtherSite', sfcc_customer_id: 'cust-1' }), { '00001': order })
        .completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'failed');
    assert.deepEqual(calls.placed, []);
    assert.deepEqual(calls.failed, []);
    assert.deepEqual(calls.voids, []);
    assert.equal(order.custom.ckoPaymentId, undefined);
});

test('finding 4: an unstamped payment (SFRA, the Dashboard) carrying the order number is never the order\'s', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = checkout(authorized(undefined), { '00001': order }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'failed');
    assert.deepEqual(calls.placed, []);
    assert.deepEqual(calls.voids, []);
});

test('finding 4: a wallet payment for the basket counts only with this site\'s stamp', () => {
    const order = makeContainer({ orderNo: '00001' });
    const payment = { ...authorized({ basket_id: 'basket-1', sfcc_site_id: 'OtherSite', sfcc_customer_id: 'cust-1' }), reference: 'basket-1' };
    const result = checkout(payment, { '00001': order }).completePayment({ paymentId: 'pay_1', orderNo: '00001', basketId: 'basket-1' });

    assert.notEqual(result.status, 'complete');
    assert.deepEqual(calls.placed, []);
});

test('finding 4: this site\'s payment by the order\'s shopper still completes it', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = checkout(stamped(authorized()), { '00001': order }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'complete');
    assert.deepEqual(calls.placed, ['00001']);
});

test('finding 4: payment sessions are stamped with the site', () => {
    let sent;
    const service = load('scripts/checkoutcom/checkout', {
        preferences: KEYS,
        '*/cartridge/scripts/checkoutcom/gateway': { createPaymentSession: (body) => { sent = body; return { ok: true, object: { id: 'ps_1' } }; } },
    });

    service.createSession({ basket: makeScapiBasket(), successUrl: 'https://shop.example/r', failureUrl: 'https://shop.example/r' });

    assert.equal(sent.metadata.sfcc_site_id, 'TestSite');
});

// Finding 5 ----------------------------------------------------------------

test('finding 5: a payment flagged by a Checkout.com risk rule places the order held for review', () => {
    const order = makeContainer({ orderNo: '00001' });
    const flagged = stamped({ ...authorized(), risk: { flagged: true, score: 80 } });
    const result = checkout(flagged, { '00001': order }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'complete');
    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(order.custom.ckoRiskFlagged, true);
    assert.equal(order.confirmationStatus, ORDER.CONFIRMATION_STATUS_NOTCONFIRMED);
    assert.notEqual(order.exportStatus, ORDER.EXPORT_STATUS_READY);
});

test('finding 5: an unflagged payment is confirmed and released for export', () => {
    const order = makeContainer({ orderNo: '00001' });

    checkout(stamped(authorized()), { '00001': order }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(order.confirmationStatus, ORDER.CONFIRMATION_STATUS_CONFIRMED);
    assert.equal(order.exportStatus, ORDER.EXPORT_STATUS_READY);
});

test('finding 5: a flagged approval webhook for the order\'s payment holds it', () => {
    const payments = load('scripts/checkoutcom/payments', {});
    const order = makeContainer({ orderNo: '00001' });

    order.custom.ckoPaymentId = 'pay_1';
    assert.equal(payments.recordRiskFlag(order, { id: 'pay_1', risk: { flagged: true } }), true);
    assert.equal(payments.isRiskFlagged(order), true);
    assert.equal(order.confirmationStatus, ORDER.CONFIRMATION_STATUS_NOTCONFIRMED);
    assert.equal(payments.recordRiskFlag(makeContainer({}), { id: 'pay_2', risk: { flagged: false } }), false);
});

test('finding 5: a flagged approval webhook after the order was released for export takes it back', () => {
    const payments = load('scripts/checkoutcom/payments', {});
    const released = makeContainer({ orderNo: '00001' });

    released.custom.ckoPaymentId = 'pay_1';
    released.confirmationStatus = ORDER.CONFIRMATION_STATUS_CONFIRMED;
    released.exportStatus = ORDER.EXPORT_STATUS_READY;
    assert.equal(payments.recordRiskFlag(released, { id: 'pay_1', risk: { flagged: true } }), true);
    assert.equal(released.confirmationStatus, ORDER.CONFIRMATION_STATUS_NOTCONFIRMED);
    assert.equal(released.exportStatus, ORDER.EXPORT_STATUS_NOTEXPORTED);

    const exported = makeContainer({ orderNo: '00002' });
    exported.custom.ckoPaymentId = 'pay_2';
    exported.exportStatus = ORDER.EXPORT_STATUS_EXPORTED;
    payments.recordRiskFlag(exported, { id: 'pay_2', risk: { flagged: true } });
    assert.equal(exported.exportStatus, ORDER.EXPORT_STATUS_EXPORTED);
});

// Finding 14 ---------------------------------------------------------------

test('finding 14: the communication log gets no personal data, token, card detail or session secret', () => {
    const definitions = [];
    const gateway = load('scripts/checkoutcom/gateway', {
        preferences: KEYS,
        'dw/svc/LocalServiceRegistry': {
            createService: (serviceId, definition) => {
                if (serviceId.indexOf('cko.keys.') === 0) {
                    return { getConfiguration: () => ({ getCredential: () => ({ getPassword: () => 'sk_sbox_test' }) }) };
                }

                definitions.push(definition);

                return {
                    getURL: () => 'https://api.sandbox.checkout.com/payments/{id}',
                    setURL() {},
                    setRequestMethod() {},
                    call: () => ({ isOk: () => true, getObject: () => ({}) }),
                };
            },
        },
    });

    gateway.getPayment('pay_1');

    const request = JSON.stringify({
        amount: 4500,
        currency: 'GBP',
        reference: '00001',
        customer: { email: 'jordan@example.com', name: 'Jordan Smith', phone: { country_code: '+44', number: '7700900123' } },
        billing: { address: { address_line1: '1 High Street', city: 'London', zip: 'N1 9GU', country: 'GB' } },
        source: { type: 'googlepay', token: 'tok_ubfj2q76miwundwlk72vxt2i7q', token_data: { signature: 'MEQCIF', signedMessage: 'xyz' } },
        session_data: 'sd_secret',
    });
    const response = {
        text: JSON.stringify({
            id: 'pay_1',
            status: 'Authorized',
            payment_session_secret: 'pss_secret',
            source: { type: 'card', bin: '424242', last4: '4242', expiry_month: 10, expiry_year: 2029, name: 'Jordan Smith' },
        }),
    };
    const logged = definitions[0].getRequestLogMessage(request) + definitions[0].getResponseLogMessage(response);

    ['jordan@example.com', 'Jordan', '7700900123', '1 High Street', 'London', 'N1 9GU', 'tok_ubfj2q76miwundwlk72vxt2i7q', 'MEQCIF', 'sd_secret', 'pss_secret', '424242', '"4242"', '2029'].forEach((value) => {
        assert.ok(logged.indexOf(value) === -1, value + ' was logged');
    });
    ['"amount":4500', '"reference":"00001"', '"status":"Authorized"', '"id":"pay_1"', '"country":"GB"'].forEach((value) => {
        assert.ok(logged.indexOf(value) !== -1, value + ' was not logged');
    });
    assert.ok(definitions[0].getRequestLogMessage('number=4242424242424242').indexOf('4242') === -1);
});

test('finding 14: personal data in non-Latin scripts is masked too', () => {
    const redact = load('scripts/checkoutcom/redact', {});
    const logged = redact.toLogMessage({
        customer: { name: '山田太郎', email: 'ユーザー@例え.jp' },
        billing: { address: { city: 'Москва', address_line1: 'ул. Тверская, 1', country: 'RU' } },
        amount: 4500,
    });

    ['山田', '太郎', 'ユーザー', '例え', 'Москва', 'Тверская'].forEach((value) => {
        assert.ok(logged.indexOf(value) === -1, value + ' was logged');
    });
    assert.ok(logged.indexOf('"country":"RU"') !== -1);
    assert.ok(logged.indexOf('"amount":4500') !== -1);
});
