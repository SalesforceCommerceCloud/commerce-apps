'use strict';

var Logger = require('dw/system/Logger');
var Order = require('dw/order/Order');
var OrderMgr = require('dw/order/OrderMgr');
var Transaction = require('dw/system/Transaction');

var config = require('*/cartridge/scripts/checkoutcom/config');
var gateway = require('*/cartridge/scripts/checkoutcom/gateway');
var ledger = require('*/cartridge/scripts/checkoutcom/ledger');
var orders = require('*/cartridge/scripts/checkoutcom/orders');
var payload = require('*/cartridge/scripts/checkoutcom/payload');
var payments = require('*/cartridge/scripts/checkoutcom/payments');
var applepay = require('*/cartridge/scripts/checkoutcom/applepay');

var log = Logger.getLogger(config.LOG_CATEGORY);

/**
 * Checkout operations behind the Custom API (rest-apis/checkoutcom).
 *
 * Order-first sequence, driven by the Storefront Next extension, on the
 * Payment Commerce Apps platform (Beta; see scripts/checkoutcom/payments.js):
 *  1. createSession    payment step: payment session built from the basket
 *  2. (storefront)     Place Order: the order is created through SCAPI
 *  3. submitPayment    Flow's handleSubmit, the order transition endpoint:
 *                      OrderMgr.attemptOrderTransition runs the
 *                      onAttemptOrderTransition hook, which submits the payment
 *                      with reference = orderNo, and places an approved order
 *  4. completePayment  Flow's onPaymentCompleted or the return route: verify the
 *                      payment, record it on the instrument and attempt the
 *                      transition again, which places the order
 *
 * The platform places an order only when its instrument is AUTHORIZED or
 * CAPTURED; a PENDING one (3DS, a voucher) keeps it in CREATED until the
 * completion or the webhook. Failing an order goes through
 * OrderMgr.failOrder(order, true), which reopens the basket and dispatches the
 * reversePayment hook. Payment Commerce Apps (PaymentFraudOrchestrationEnabled)
 * and SCAPI hook execution (ScapiHookExecutionEnabled) must be enabled.
 *
 * A payment that completed without handleSubmit (a wallet paying directly)
 * still carries the basket id as its reference. The storefront then creates the
 * order through SCAPI and completes it with that basket id, and the payment is
 * accepted for the order when the amounts match (see paymentMatchesOrder).
 *
 * The instance never loads baskets itself: in a Custom API script the BasketMgr
 * lookups are agent-only (getBasket/getBaskets) or unsupported
 * (getCurrentBasket), so the storefront sends the basket with the session request.
 */

var APPROVED_STATUSES = ['Authorized', 'Captured', 'Card Verified', 'Paid'];
var PENDING_STATUSES = ['Pending'];

/**
 * @param {string} message The error message
 * @returns {Object} A failed result
 */
function failure(message) {
    return { ok: false, errorMessage: message };
}

/**
 * The payment's outcome could not be established (Checkout.com unreachable, or
 * a concurrent request still placing the order). Never a reason to fail the
 * order or to pay again: the storefront asks the shopper to check their order.
 * @param {dw.order.Order} [order] The order, when known
 * @returns {Object} An unverified result
 */
function unverified(order) {
    return { ok: true, status: 'unverified', orderNo: order ? order.getOrderNo() : null, errorMessage: 'The payment could not be confirmed yet.' };
}

/**
 * Accept a return URL only when its origin is allow-listed in Business Manager,
 * so the session can never send shoppers to an arbitrary site.
 * @param {string} url The URL proposed by the storefront
 * @returns {boolean} True when allowed
 */
function isAllowedReturnUrl(url) {
    var match = /^(https?:\/\/[^/?#]+)/i.exec(url || '');

    if (!match) {
        return false;
    }

    var origin = match[1].toLowerCase();
    var allowed = config.getList(config.PREFERENCES.ALLOWED_RETURN_ORIGINS).some(function(entry) {
        return entry.replace(/\/+$/, '').toLowerCase() === origin;
    });

    if (!allowed) {
        // A setup error the shopper can't fix: the storefront's origin is missing
        log.error('Storefront origin {0} refused: add it to Allowed Storefront Origins (ckoFlowAllowedReturnOrigins).', origin);
    }

    return allowed;
}

/**
 * Void, or refund when captured, a payment that is not the payment of an order
 * (a second payment, a late one for a closed order). The order's own payment is
 * reversed by the platform, through the reversePayment hook, when it fails the
 * order. Best effort: a failure is logged for follow-up.
 * @param {Object} payment The gateway payment
 * @param {string} reason The reversal reference
 */
function reversePayment(payment, reason) {
    var captured = payment.status === 'Captured' || payment.status === 'Paid';
    var result = captured
        ? gateway.refundPayment(payment.id, reason)
        : gateway.voidPayment(payment.id, reason);

    if (!result.ok) {
        log.error('Automatic {0} of payment {1} failed: {2}', captured ? 'refund' : 'void', payment.id, result.errorMessage);
    }
}

/**
 * @param {dw.order.LineItemCtnr} lineItemCtnr The order or basket
 * @param {Object} payment The gateway payment
 * @returns {boolean} True when amount and currency match
 */
function amountMatches(lineItemCtnr, payment) {
    return payment.currency === lineItemCtnr.getCurrencyCode()
        && payment.amount === payload.toMinorUnits(payload.getTotal(lineItemCtnr));
}

/**
 * @returns {boolean} True when the instance runs Payment Commerce Apps
 */
function isPlatformEnabled() {
    return typeof OrderMgr.attemptOrderTransition === 'function';
}

/**
 * Mark a placed order ready for fulfilment, once: an order already exported or
 * held back by the merchant is left alone.
 * @param {dw.order.Order} order The placed order
 */
function confirmPlaced(order) {
    if (order.getExportStatus().getValue() !== Order.EXPORT_STATUS_NOTEXPORTED) {
        return;
    }

    try {
        Transaction.wrap(function() {
            order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
            order.setExportStatus(Order.EXPORT_STATUS_READY);
        });
    } catch (e) {
        // A concurrent request (the webhook) confirmed it at the same moment
        log.info('Order {0}: confirmation left to a concurrent request ({1}).', order.getOrderNo(), e.message);
    }
}

/**
 * Attempt the order transition: the platform runs the payment hooks for an
 * instrument still at CREATED, then places the order once its payment is
 * AUTHORIZED or CAPTURED. Safe to call twice.
 * @param {dw.order.Order} order The order
 * @returns {dw.order.Order} The order as it is now
 */
function transition(order) {
    try {
        Transaction.wrap(function() {
            var result = OrderMgr.attemptOrderTransition(order);

            if (result && result.isError()) {
                log.warn('Order {0}: transition failed at {1}: {2}', order.getOrderNo(), result.getStep(), result.getReason());
            }
        });
    } catch (e) {
        // A concurrent transition (the webhook, a retried completion) committed
        // first; the order as it is now tells what happened
        log.warn('Order {0}: transition not committed: {1}', order.getOrderNo(), e.message);
    }

    var current = orders.reload(order);

    if (orders.isPlaced(current)) {
        confirmPlaced(current);
    }

    return current;
}

/**
 * The result of a transition, for the storefront.
 * @param {dw.order.Order} order The order after the transition
 * @param {boolean} pending True when the payment is still pending
 * @returns {Object} The result
 */
function transitionResult(order, pending) {
    if (orders.isPlaced(order)) {
        return completed(order);
    }

    if (orders.isAwaitingPayment(order)) {
        // Pending (a voucher, a bank transfer): the shopper sees the order
        // confirmation; the webhook places or fails the order
        return pending
            ? { ok: true, status: 'complete', pending: true, orderNo: order.getOrderNo(), orderToken: order.getOrderToken() }
            : unverified(order);
    }

    return declined('The payment was not approved.');
}

/**
 * Record a verified payment on the order's instrument and attempt the
 * transition, which places the order once the payment is authorized.
 * @param {dw.order.Order} order The order in status CREATED
 * @param {Object} payment The verified gateway payment, matching the order
 * @returns {Object} The result
 */
function applyAndTransition(order, payment) {
    var applied = null;

    try {
        Transaction.wrap(function() {
            orders.removeDuplicateInstruments(order);
            applied = payments.applyPayment(order, payment);
        });
    } catch (e) {
        var current = orders.reload(order);

        if (orders.isPlaced(current)) {
            // Another request placed it first
            return settlePlacedOrder(current, payment);
        }

        log.warn('Order {0}: payment {1} not recorded yet ({2}).', order.getOrderNo(), payment.id, e.message);

        return unverified(current);
    }

    if (applied.isError()) {
        log.error('Order {0}: payment {1} not applied: {2}', order.getOrderNo(), payment.id, applied.getMessage());
        failOrder(order);

        return declined('The payment does not match the order.');
    }

    return transitionResult(transition(order), isPending(payment));
}

/**
 * Fail an order that is still waiting for payment and give the shopper their
 * basket back.
 * @param {dw.order.Order} order The order
 */
function failOrder(order) {
    if (orders.isAwaitingPayment(order)) {
        // The platform reopens the basket and dispatches the reversePayment hook
        Transaction.wrap(function() {
            OrderMgr.failOrder(order, true);
        });
    }
}

/**
 * @param {Object} payment The gateway payment
 * @returns {boolean} True when approved
 */
function isApproved(payment) {
    return APPROVED_STATUSES.indexOf(payment.status) !== -1;
}

/**
 * @param {Object} payment The gateway payment
 * @returns {boolean} True when still pending
 */
function isPending(payment) {
    return PENDING_STATUSES.indexOf(payment.status) !== -1;
}

/**
 * @param {dw.order.Order} order The order
 * @returns {Object} A complete result for an order
 */
function completed(order) {
    return { ok: true, status: 'complete', orderNo: order.getOrderNo(), orderToken: order.getOrderToken() };
}

/**
 * @param {string} message The message shown to the shopper
 * @returns {Object} A failed payment result
 */
function declined(message) {
    return { ok: true, status: 'failed', errorMessage: message };
}

/**
 * A payment belongs to an order when its reference is the order number (it was
 * submitted for it), or when it was made for the basket the order was created
 * from (a wallet that paid before the order existed), with the same amount, and
 * no other order is already paid with it.
 * @param {dw.order.Order} order The order
 * @param {Object} payment The gateway payment
 * @param {string} [basketId] The basket the storefront created the order from
 * @returns {boolean} True when the payment may be applied to the order
 */
function paymentMatchesOrder(order, payment, basketId) {
    if (!isForOrder(order, payment, basketId) || !amountMatches(order, payment)) {
        return false;
    }

    var boundOrderNo = orders.getBoundOrderNo(payment.id);

    return !boundOrderNo || boundOrderNo === order.getOrderNo();
}

/**
 * A payment carrying the order's number is the order's own only when the
 * order's shopper made it: the instance stamps the calling shopper on every
 * payment session and wallet payment (metadata.sfcc_customer_id, from the
 * token, never from the request). Or when it is the payment this order
 * submitted. Another shopper's payment with this reference is never the
 * order's, so it can neither complete nor fail it.
 * @param {dw.order.Order} order The order
 * @param {Object} payment The gateway payment
 * @returns {boolean} True when the payment is the order's own
 */
function isOrdersOwnPayment(order, payment) {
    var attempt = orders.getAttempt(order.getOrderNo());

    if (payment.id && ((attempt && attempt.custom.attemptPaymentId === payment.id) || order.custom.ckoPaymentId === payment.id)) {
        return true;
    }

    var stamped = payment.metadata ? payment.metadata.sfcc_customer_id : null;
    var orderCustomer = order.getCustomer();

    return !stamped || (!!orderCustomer && stamped === orderCustomer.getID());
}

/**
 * @param {dw.order.Order} order The order
 * @param {Object} payment The gateway payment
 * @param {string} [basketId] The basket the order was created from
 * @returns {boolean} True when the payment was made for this order or its basket
 */
function isForOrder(order, payment, basketId) {
    if (payment.reference === order.getOrderNo()) {
        return isOrdersOwnPayment(order, payment);
    }

    // A wallet payment made for a basket before the order existed. The basket id
    // comes from the caller, so it only counts for the shopper who created the
    // payment session: the instance stamps that shopper on the session itself
    var orderCustomer = order.getCustomer();

    return !!basketId && !!payment.metadata && payment.metadata.basket_id === basketId
        && !!orderCustomer && payment.metadata.sfcc_customer_id === orderCustomer.getID();
}

/**
 * Whether a payment belongs to an order, so that this order may reverse it.
 * Never true for a payment bound to another order: a shopper must not be able
 * to refund a paid order by pointing another order at its payment.
 * @param {dw.order.Order} order The order
 * @param {Object} payment The gateway payment
 * @param {string} [basketId] The basket the order was created from
 * @returns {boolean} True when the payment is this order's
 */
function belongsToOrder(order, payment, basketId) {
    var boundOrderNo = orders.getBoundOrderNo(payment.id);

    if (boundOrderNo) {
        return boundOrderNo === order.getOrderNo();
    }

    return isForOrder(order, payment, basketId);
}

/**
 * A payment completing an order that is already placed. Its own payment: the
 * same result again. Another payment made for it (a second charge): reversed,
 * and the order is still complete. A payment bound to another order: untouched.
 * @param {dw.order.Order} order The placed order
 * @param {Object} payment The gateway payment
 * @param {string} [basketId] The basket the order was created from
 * @returns {Object} The result
 */
function settlePlacedOrder(order, payment, basketId) {
    var boundOrderNo = orders.getBoundOrderNo(payment.id);

    if (order.custom.ckoPaymentId === payment.id || boundOrderNo === order.getOrderNo()) {
        return completed(order);
    }

    if (!boundOrderNo && isForOrder(order, payment, basketId) && (isApproved(payment) || isPending(payment))) {
        log.warn('Payment {0} is a second payment for order {1}, already paid with {2}: reversing it.', payment.id, order.getOrderNo(), order.custom.ckoPaymentId);
        reversePayment(payment, 'sfcc_duplicate_payment');
        Transaction.wrap(function() {
            order.addNote('Checkout.com', 'Duplicate payment ' + payment.id + ' reversed');
        });

        return completed(order);
    }

    return failure('The order was already paid with another payment.');
}

/**
 * Find the payment of an order's attempt: by its payment id, or, when the
 * submission's outcome is unknown, by the order number it was submitted with.
 * @param {dw.order.Order} order The order
 * @returns {{ok: boolean, payment: Object}} ok false when Checkout.com could not be asked
 */
function findAttemptPayment(order) {
    var attempt = orders.getAttempt(order.getOrderNo());

    if (!attempt || attempt.custom.attemptState === orders.ATTEMPT.REJECTED) {
        return { ok: true, payment: null };
    }

    var paymentId = attempt.custom.attemptPaymentId;

    if (!paymentId) {
        var list = gateway.listPayments(order.getOrderNo());

        if (!list.ok) {
            return { ok: false, payment: null };
        }

        // Only this order's own payments: never another shopper's with the same reference
        var found = ((list.object && list.object.data) || []).filter(function(item) {
            return item.reference === order.getOrderNo() && isOrdersOwnPayment(order, item);
        });
        var usable = found.filter(function(item) {
            return isApproved(item) || isPending(item);
        });

        paymentId = (usable[0] || found[0] || {}).id;

        if (!paymentId) {
            return { ok: true, payment: null };
        }
    }

    var verification = gateway.getPayment(paymentId);

    return verification.ok && verification.object
        ? { ok: true, payment: verification.object }
        : { ok: false, payment: null };
}

/**
 * Complete a payment that was submitted for an order (the order-first path).
 * @param {dw.order.Order} order The shopper's order
 * @param {Object} payment The verified gateway payment
 * @returns {Object} The result
 */
function completeForOrder(order, payment, basketId) {
    if (orders.isPlaced(order)) {
        return settlePlacedOrder(order, payment, basketId);
    }

    if (!orders.isAwaitingPayment(order)) {
        // A late payment for this order, which was given up: released. Anyone
        // else's payment (or this shopper's payment of another order) is left alone
        if (isApproved(payment) && belongsToOrder(order, payment, basketId)) {
            reversePayment(payment, 'sfcc_order_closed');
        }

        return declined('The order is no longer open.');
    }

    // Someone else's payment (another shopper's, or one bound to another order)
    // says nothing about this order: never a reason to fail it
    var boundElsewhere = orders.getBoundOrderNo(payment.id) && orders.getBoundOrderNo(payment.id) !== order.getOrderNo();

    if (!isForOrder(order, payment, basketId) || boundElsewhere) {
        log.warn('Payment {0} is not order {1}\'s; ignored.', payment.id, order.getOrderNo());

        return declined('The payment is not this order\'s.');
    }

    if (!paymentMatchesOrder(order, payment, basketId)) {
        log.error('Payment {0} does not match order {1}.', payment.id, order.getOrderNo());
        failOrder(order);

        // Released only when it was made for this order (a wrong amount);
        // a payment of another order is never touched. The payment recorded on
        // the order's instrument is reversed by the platform as the order fails
        var recorded = orders.getPaymentInstrument(order);
        var recordedId = recorded ? recorded.getPaymentTransaction().getTransactionID() : null;

        if ((isApproved(payment) || isPending(payment)) && belongsToOrder(order, payment, basketId) && recordedId !== payment.id) {
            reversePayment(payment, 'sfcc_order_mismatch');
        }

        return declined('The payment does not match the order.');
    }

    if (!isApproved(payment) && !isPending(payment)) {
        failOrder(order);

        return declined('The payment was not approved (' + payment.status + ').');
    }

    return applyAndTransition(order, payment);
}

module.exports = {
    isAllowedReturnUrl: isAllowedReturnUrl,

    /**
     * Create a payment session for the shopper's basket.
     * @param {Object} input basket (Shopper Baskets JSON), successUrl, failureUrl, locale
     * @returns {Object} ok + paymentSession, publicKey, environment; or errorMessage
     */
    createSession: function(input) {
        var basket = input.basket;

        if (!basket || !basket.basketId || !basket.productItems || basket.productItems.length === 0) {
            return failure('The basket is missing or has no items.');
        }

        if (typeof basket.orderTotal !== 'number' || !basket.currency) {
            return failure('The basket has no order total yet (taxes and shipping must be calculated).');
        }

        if (!config.isEnabled()) {
            return failure('Checkout.com Flow is switched off: enable the CHECKOUTCOM_FLOW payment method.');
        }

        if (!isAllowedReturnUrl(input.successUrl) || !isAllowedReturnUrl(input.failureUrl)) {
            return failure('The return URLs are not allowed. Add the storefront origin to ckoFlowAllowedReturnOrigins.');
        }

        // The public key may instead be set in the storefront environment
        // (PUBLIC__app__extension__checkoutcom__publicKey)
        if (!config.getSecretKey()) {
            return failure('The Checkout.com secret key is not configured.');
        }

        var request = payload.buildSessionRequest(basket, input);

        if (!request.billing || !request.billing.address || !request.billing.address.country) {
            return failure('The basket has no billing or shipping address yet.');
        }

        var result = gateway.createPaymentSession(request);

        if (!result.ok || !result.object || !result.object.id) {
            log.error('Payment session creation failed for basket {0}: {1}', basket.basketId, result.errorMessage);

            return failure('The payment session could not be created.');
        }

        log.info('Payment session {0} created for basket {1} ({2} {3}).', result.object.id, basket.basketId, basket.orderTotal, basket.currency);

        return {
            ok: true,
            paymentSession: result.object,
            publicKey: config.getPublicKey() || null,
            environment: config.getEnvironment(),
            accountPrefix: config.getAccountPrefix(),
            appearance: config.getAppearance(),
            componentOptions: config.getComponentOptions(),
            translations: config.getTranslations(),
        };
    },

    /**
     * Submit the payment Flow collected, for an order the storefront just created.
     * @param {Object} input sessionId, sessionData, orderNo
     * @returns {Object} ok + response (returned to Flow unmodified); or errorMessage
     */
    submitPayment: function(input) {
        var order = orders.getShopperOrder(input.orderNo);

        if (!order || !orders.isAwaitingPayment(order)) {
            return failure('The order is not waiting for a Checkout.com payment.');
        }

        if (!isPlatformEnabled()) {
            log.error('OrderMgr.attemptOrderTransition is not available: enable Payment Commerce Apps (PaymentFraudOrchestrationEnabled) on this instance.');

            return failure('Payment Commerce Apps is not enabled on this instance.');
        }

        // One payment attempt per order, reserved before money can move: a second
        // session (or a repeated request) can never charge the same order again.
        // The submit endpoint takes no idempotency key, so this is the guard.
        var attempt = null;

        Transaction.wrap(function() {
            attempt = orders.reserveAttempt(order, input.sessionId);
            orders.removeDuplicateInstruments(order);
        });

        if (!attempt) {
            log.warn('Order {0} already has a payment attempt; not submitting another one.', order.getOrderNo());

            return failure('A payment was already submitted for this order.');
        }

        // Handed to the onAttemptOrderTransition hook for this request only: the
        // session data is a payment credential and is never stored
        payments.setScoped(payments.SUBMISSION, { orderNo: order.getOrderNo(), sessionId: input.sessionId, sessionData: input.sessionData });

        var current;

        try {
            current = transition(order);
        } finally {
            payments.setScoped(payments.SUBMISSION, null);
        }

        var response = payments.getScoped(payments.SUBMIT_RESPONSE);

        payments.setScoped(payments.SUBMIT_RESPONSE, null);

        if (!response) {
            // Refused (the order failed, basket reopened) or the outcome is
            // unknown (the order stays open): the storefront releases it, which
            // looks the payment up by the order number first
            log.warn('Order {0}: no submission response (order status {1}).', order.getOrderNo(), current.getStatus().getValue());

            return failure('The payment could not be submitted.');
        }

        // Returned to Flow unmodified: it shows a decline, or runs 3DS and then
        // calls onPaymentCompleted, which completes the order
        return { ok: true, response: response };
    },

    /**
     * The express checkout buttons' settings: which wallets are switched on, and
     * what their browser SDKs need. No secret: the public key is the
     * Business Manager fallback for the storefront's own environment setting.
     * @returns {Object} ok + googlePay, applePay, publicKey, environment
     */
    getWalletConfig: function() {
        return {
            ok: true,
            environment: config.getEnvironment(),
            publicKey: config.getPublicKey() || null,
            accountPrefix: config.getAccountPrefix(),
            // Shown in the wallet sheets, as the Flow session's display_name
            merchantName: require('dw/system/Site').getCurrent().getName(),
            googlePay: {
                enabled: config.isMethodEnabled(config.METHODS.GOOGLE_PAY),
                merchantId: config.getValue(config.PREFERENCES.GOOGLE_PAY_MERCHANT_ID) || null,
                buttonColor: config.getValue(config.PREFERENCES.GOOGLE_PAY_BUTTON) || 'default',
            },
            // On only when the merchant validation can work: a merchant id and
            // the identity certificate's alias
            applePay: {
                enabled: config.isMethodEnabled(config.METHODS.APPLE_PAY)
                    && !!config.getValue(config.PREFERENCES.APPLE_PAY_MERCHANT_ID)
                    && !!config.getValue(config.PREFERENCES.APPLE_PAY_CERTIFICATE_ALIAS),
                buttonStyle: config.getValue(config.PREFERENCES.APPLE_PAY_BUTTON) || 'black',
            },
        };
    },

    /**
     * Apple Pay merchant validation (the sheet's onvalidatemerchant): a merchant
     * session from Apple, for a storefront domain the merchant allowed.
     * @param {Object} input validationUrl (from the sheet), domain (the storefront's host)
     * @returns {Object} ok + session (opaque, for completeMerchantValidation); or errorMessage
     */
    createApplePaySession: function(input) {
        var merchantId = config.getValue(config.PREFERENCES.APPLE_PAY_MERCHANT_ID);
        var alias = config.getValue(config.PREFERENCES.APPLE_PAY_CERTIFICATE_ALIAS);

        if (!config.isMethodEnabled(config.METHODS.APPLE_PAY) || !merchantId || !alias) {
            return failure('Apple Pay is switched off or not configured.');
        }

        if (!applepay.isValidationUrl(input.validationUrl)) {
            log.warn('Apple Pay merchant validation refused: not an Apple validation URL.');

            return failure('Not an Apple Pay validation URL.');
        }

        // The storefront's domain, verified with Apple: one of the allowed origins
        if (!applepay.isDomain(input.domain) || !isAllowedReturnUrl('https://' + input.domain)) {
            return failure('The domain is not allowed. Add the storefront origin to ckoFlowAllowedReturnOrigins.');
        }

        var result = applepay.validateMerchant(input.validationUrl, {
            merchantIdentifier: merchantId,
            displayName: require('dw/system/Site').getCurrent().getName(),
            initiativeContext: input.domain,
            certificateAlias: alias,
        });

        return result.ok ? { ok: true, session: result.session } : failure(result.errorMessage);
    },

    /**
     * The Apple Pay domain association file, which each storefront domain serves
     * at /.well-known/apple-developer-merchantid-domain-association.
     * @returns {Object} ok + content (empty when not set)
     */
    getApplePayDomainAssociation: function() {
        return { ok: true, content: config.getValue(config.PREFERENCES.APPLE_PAY_DOMAIN_ASSOCIATION) || '' };
    },

    /**
     * The order transition endpoint of an express wallet payment: pay the order
     * the storefront just created with the Checkout.com token of the wallet
     * token, through the onAttemptOrderTransition hook.
     * @param {Object} input orderNo, paymentMethodId, token (tok_...), tokenFormat, successUrl, failureUrl
     * @returns {Object} ok + status (complete|pending|failed|unverified), orderNo, orderToken, redirectUrl
     */
    submitWalletPayment: function(input) {
        var order = orders.getShopperOrder(input.orderNo);
        var instrument = order ? orders.getPaymentInstrument(order) : null;

        if (!order || !orders.isAwaitingPayment(order) || !instrument) {
            return failure('The order is not waiting for a Checkout.com payment.');
        }

        if (input.paymentMethodId === config.METHODS.FLOW || !config.isClaimed(input.paymentMethodId)
            || instrument.getPaymentMethod() !== input.paymentMethodId) {
            return failure('The order is not paid with ' + input.paymentMethodId + '.');
        }

        if (!config.isMethodEnabled(input.paymentMethodId)) {
            return failure(input.paymentMethodId + ' is switched off.');
        }

        if (!isAllowedReturnUrl(input.successUrl) || !isAllowedReturnUrl(input.failureUrl)) {
            return failure('The return URLs are not allowed. Add the storefront origin to ckoFlowAllowedReturnOrigins.');
        }

        if (!isPlatformEnabled()) {
            log.error('OrderMgr.attemptOrderTransition is not available: enable Payment Commerce Apps (PaymentFraudOrchestrationEnabled) on this instance.');

            return failure('Payment Commerce Apps is not enabled on this instance.');
        }

        // One payment attempt per order, as for Flow
        var attempt = null;

        Transaction.wrap(function() {
            attempt = orders.reserveAttempt(order, null);
            orders.removeDuplicateInstruments(order);
        });

        if (!attempt) {
            return failure('A payment was already submitted for this order.');
        }

        // Handed to the hook for this request only: never stored
        payments.setScoped(payments.WALLET_SUBMISSION, {
            orderNo: order.getOrderNo(),
            token: input.token,
            tokenFormat: input.tokenFormat || null,
            successUrl: input.successUrl,
            failureUrl: input.failureUrl,
        });

        var current;

        try {
            current = transition(order);
        } finally {
            payments.setScoped(payments.WALLET_SUBMISSION, null);
        }

        var response = payments.getScoped(payments.WALLET_RESPONSE) || {};

        payments.setScoped(payments.WALLET_RESPONSE, null);

        if (orders.isPlaced(current)) {
            return completed(current);
        }

        if (orders.isAwaitingPayment(current)) {
            if (response.redirectUrl) {
                // 3D Secure: the shopper comes back through /cko-return
                return { ok: true, status: 'pending', orderNo: current.getOrderNo(), orderToken: current.getOrderToken(), redirectUrl: response.redirectUrl };
            }

            // The outcome is unknown, or a pending method: the release and the
            // webhook find the payment by the order number
            return response.id ? { ok: true, status: 'complete', pending: true, orderNo: current.getOrderNo(), orderToken: current.getOrderToken() } : unverified(current);
        }

        return declined('The payment was not approved.');
    },

    /**
     * Verify a payment against the gateway and place its order. Idempotent: a
     * repeated call for a placed order returns the same result.
     * @param {Object} input paymentId, orderNo (else the payment reference), and the basketId
     *     the order was created from when the payment was made before the order existed
     * @returns {Object} ok + status (complete|failed), pending, orderNo, orderToken; or errorMessage
     */
    completePayment: function(input) {
        var verification = gateway.getPayment(input.paymentId);

        if (!verification.ok || !verification.object) {
            log.warn('Payment {0} could not be verified: {1}', input.paymentId, verification.errorMessage);

            return unverified(input.orderNo ? orders.getShopperOrder(input.orderNo) : null);
        }

        var payment = verification.object;
        // The order given, else the one the payment is bound to (a wallet payment
        // whose completion is retried), else the order its reference names
        var order = orders.getShopperOrder(input.orderNo || orders.getBoundOrderNo(payment.id) || payment.reference);

        log.info('Completing payment {0} ({1}, {2} {3}) for order {4}.', payment.id, payment.status, payment.amount, payment.currency, order ? order.getOrderNo() : 'none');

        if (!order) {
            // Without an order number: a wallet payment that has no order yet
            return input.orderNo ? failure('No order was found for this payment.') : { ok: true, status: 'no_order' };
        }

        // A wallet payment for the basket this order was just created from: bind
        // them now, so a retried completion finds the order rather than a basket
        if (input.basketId && isForOrder(order, payment, input.basketId) && !orders.getBoundOrderNo(payment.id)) {
            Transaction.wrap(function() {
                orders.bindPayment(payment.id, order);
            });
        }

        return completeForOrder(order, payment, input.basketId);
    },

    /**
     * Give up on an order's payment: fail the order and reopen its basket, unless
     * Checkout.com has a payment for it, which then completes the order instead.
     * Used whenever the storefront would fail an order, because an error there
     * does not prove that no money moved.
     * @param {Object} input orderNo
     * @returns {Object} ok + status complete (orderNo, orderToken), failed, or unverified
     */
    releaseOrder: function(input) {
        var order = orders.getShopperOrder(input.orderNo);

        if (!order) {
            return failure('No order was found.');
        }

        if (orders.isPlaced(order)) {
            return completed(order);
        }

        if (!orders.isAwaitingPayment(order)) {
            return { ok: true, status: 'failed' };
        }

        var found = findAttemptPayment(order);

        if (!found.ok) {
            log.warn('Order {0} kept open: its payment could not be checked with Checkout.com.', order.getOrderNo());

            return unverified(order);
        }

        if (found.payment) {
            log.info('Order {0} has payment {1} ({2}): completing instead of failing.', order.getOrderNo(), found.payment.id, found.payment.status);

            return completeForOrder(order, found.payment);
        }

        failOrder(order);
        log.info('Order {0} failed with no payment; basket reopened.', order.getOrderNo());

        return { ok: true, status: 'failed' };
    },

    /**
     * Apply a payment to an order found by a webhook (no shopper session): the
     * same checks and placement as a completion. A late payment for a failed
     * order, or a second one for a placed order, is reversed.
     * @param {dw.order.Order} order The order
     * @param {Object} payment The verified gateway payment
     * @returns {Object} The result
     */
    reconcilePayment: function(order, payment) {
        return completeForOrder(order, payment);
    },
};
