'use strict';

var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var Order = require('dw/order/Order');
var OrderMgr = require('dw/order/OrderMgr');

var config = require('*/cartridge/scripts/checkoutcom/config');

/**
 * Order lookups.
 *
 * Shopper requests (the Custom API) run with the shopper's SLAS token, so the
 * global `customer` is the shopper; every order number arriving from the
 * storefront is checked against it, so a shopper can never pay for, complete or
 * fail somebody else's order.
 *
 * Webhooks arrive with no shopper session. With the Limit Storefront Order
 * Access site preference enabled (the default on new sites), such a request may
 * only load an order with OrderMgr.getOrder(orderNo, orderToken); the search
 * methods are restricted too. So every payment is bound to its order, number and
 * token, in a ckoPayment custom object when it is submitted or applied.
 *
 * The same custom object type holds one more record per order, under a prefixed
 * key (Checkout.com payment ids start with pay_, so they never collide):
 *
 *   attempt_<orderNo>  the order's one payment attempt, reserved before the
 *                      payment is submitted (state, session id, payment id)
 *
 * Creating a custom object with an existing key fails, which makes the
 * reservation atomic. Placing the order once is the platform's job
 * (OrderMgr.attemptOrderTransition).
 */

var BINDING_TYPE = 'ckoPayment';

/** Attempt states: submitting (call in flight), submitted, rejected (refused by Checkout.com), unknown. */
var ATTEMPT = {
    SUBMITTING: 'submitting',
    SUBMITTED: 'submitted',
    REJECTED: 'rejected',
    UNKNOWN: 'unknown',
};

/**
 * Create a ckoPayment record, or report that the key is taken.
 * @param {string} key The key
 * @returns {dw.object.CustomObject|null} The new record, or null when it already exists
 */
function createUnique(key) {
    if (CustomObjectMgr.getCustomObject(BINDING_TYPE, key) !== null) {
        return null;
    }

    try {
        return CustomObjectMgr.createCustomObject(BINDING_TYPE, key);
    } catch (e) {
        // Created by a concurrent request in the meantime
        return null;
    }
}

/* global customer */

/**
 * @param {dw.order.Order} order The order
 * @returns {boolean} True when the order belongs to the calling shopper
 */
function isShopperOrder(order) {
    var orderCustomer = order.getCustomer();

    var shopper = typeof customer !== 'undefined' ? customer : null;

    return !!(orderCustomer && shopper && orderCustomer.getID() === shopper.getID());
}

module.exports = {
    ATTEMPT: ATTEMPT,
    isShopperOrder: isShopperOrder,

    /**
     * Load an order of the calling shopper.
     * @param {string} orderNo The order number
     * @returns {dw.order.Order|null} The order, or null when missing or not the shopper's
     */
    getShopperOrder: function(orderNo) {
        if (!orderNo) {
            return null;
        }

        var order = OrderMgr.getOrder(orderNo);

        return order && isShopperOrder(order) ? order : null;
    },

    /**
     * Bind a payment to its order. Idempotent; must run inside a Transaction.
     * @param {string} paymentId The Checkout.com payment id
     * @param {dw.order.Order} order The order the payment is for
     */
    bindPayment: function(paymentId, order) {
        var binding = CustomObjectMgr.getCustomObject(BINDING_TYPE, paymentId)
            || CustomObjectMgr.createCustomObject(BINDING_TYPE, paymentId);

        binding.custom.orderNo = order.getOrderNo();
        binding.custom.orderToken = order.getOrderToken();
    },

    /**
     * @param {string} paymentId The Checkout.com payment id
     * @returns {string|null} The number of the order the payment is bound to
     */
    getBoundOrderNo: function(paymentId) {
        var binding = paymentId ? CustomObjectMgr.getCustomObject(BINDING_TYPE, paymentId) : null;

        return binding ? binding.custom.orderNo : null;
    },

    /**
     * Load the order a payment is bound to. Works without a shopper session.
     * @param {string} paymentId The Checkout.com payment id
     * @returns {dw.order.Order|null} The order
     */
    getBoundOrder: function(paymentId) {
        var binding = paymentId ? CustomObjectMgr.getCustomObject(BINDING_TYPE, paymentId) : null;

        return binding ? OrderMgr.getOrder(binding.custom.orderNo, binding.custom.orderToken) : null;
    },

    /**
     * Reserve the order's one payment attempt. Must run inside a Transaction.
     * @param {dw.order.Order} order The order
     * @param {string} sessionId The payment session the attempt submits
     * @returns {dw.object.CustomObject|null} The attempt, or null when the order already has one
     */
    reserveAttempt: function(order, sessionId) {
        var attempt = createUnique('attempt_' + order.getOrderNo());

        if (attempt) {
            attempt.custom.orderNo = order.getOrderNo();
            attempt.custom.orderToken = order.getOrderToken();
            attempt.custom.sessionId = sessionId;
            attempt.custom.attemptState = ATTEMPT.SUBMITTING;
        }

        return attempt;
    },

    /**
     * @param {string} orderNo The order number
     * @returns {dw.object.CustomObject|null} The order's payment attempt
     */
    getAttempt: function(orderNo) {
        return orderNo ? CustomObjectMgr.getCustomObject(BINDING_TYPE, 'attempt_' + orderNo) : null;
    },

    /**
     * Load the order of a payment attempt, by the payment's reference (the order
     * number it was submitted with). Works without a shopper session.
     * @param {string} reference The payment reference
     * @returns {dw.order.Order|null} The order
     */
    getAttemptOrder: function(reference) {
        var attempt = reference ? CustomObjectMgr.getCustomObject(BINDING_TYPE, 'attempt_' + reference) : null;

        return attempt ? OrderMgr.getOrder(attempt.custom.orderNo, attempt.custom.orderToken) : null;
    },

    /**
     * Remove the empty duplicates of the order's Flow instrument. Two payment
     * session requests at the same time can each add one to the basket; the
     * platform places an order only when its instrument amounts match the total.
     * Must run inside a Transaction.
     * @param {dw.order.Order} order The order
     */
    removeDuplicateInstruments: function(order) {
        order.getPaymentInstruments(config.PAYMENT_METHOD_ID).toArray().slice(1).forEach(function(extra) {
            var transaction = extra.getPaymentTransaction();

            if (!transaction.getTransactionID() && !transaction.custom.ckoTransactionType) {
                order.removePaymentInstrument(extra);
            }
        });
    },

    /**
     * Reload an order from the database, to see what a concurrent request did.
     * @param {dw.order.Order} order The order
     * @returns {dw.order.Order} The current order
     */
    reload: function(order) {
        return OrderMgr.getOrder(order.getOrderNo(), order.getOrderToken()) || order;
    },

    /**
     * @param {dw.order.Order} order The order
     * @returns {boolean} True when the order still waits for its payment
     */
    isAwaitingPayment: function(order) {
        return order.getStatus().getValue() === Order.ORDER_STATUS_CREATED
            && order.getPaymentInstruments(config.PAYMENT_METHOD_ID).size() > 0;
    },

    /**
     * @param {dw.order.Order} order The order
     * @returns {boolean} True when the order has been placed
     */
    isPlaced: function(order) {
        var status = order.getStatus().getValue();

        return status === Order.ORDER_STATUS_NEW
            || status === Order.ORDER_STATUS_OPEN
            || status === Order.ORDER_STATUS_COMPLETED;
    },
};
