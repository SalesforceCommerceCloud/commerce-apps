'use strict';

/**
 * Implementation of the checkoutcom Custom API (see schema.yaml). Each export
 * is the operationId of an endpoint and must be marked public.
 */

/* global request */

var RESTResponseMgr = require('dw/system/RESTResponseMgr');

/**
 * @returns {Object|null} The parsed JSON request body
 */
function readBody() {
    try {
        return JSON.parse(request.getHttpParameterMap().getRequestBodyAsString()) || {};
    } catch (e) {
        return null;
    }
}

/**
 * Render a 400 for a missing or malformed body.
 * @param {string} detail What is missing
 */
function invalidRequest(detail) {
    RESTResponseMgr.createError(400, 'invalid-request', 'Invalid Request', detail).render();
}

/**
 * Render a checkout operation result.
 * @param {Object} result The result: ok plus fields, or errorMessage
 * @param {Function} toBody Maps a successful result to the response body
 */
function render(result, toBody) {
    if (!result.ok) {
        RESTResponseMgr.createError(422, 'checkoutcom-error', 'Checkout.com Error', result.errorMessage).render();

        return;
    }

    RESTResponseMgr.createSuccess(toBody(result)).render();
}

/**
 * POST /payment-sessions
 */
exports.createPaymentSession = function() {
    var body = readBody();

    if (!body || !body.successUrl || !body.failureUrl) {
        invalidRequest('successUrl and failureUrl are required.');

        return;
    }

    render(require('*/cartridge/scripts/checkoutcom/checkout').createSession(body), function(result) {
        return {
            paymentSession: result.paymentSession,
            publicKey: result.publicKey,
            environment: result.environment,
            accountPrefix: result.accountPrefix,
            appearance: result.appearance,
            componentOptions: result.componentOptions,
            translations: result.translations,
        };
    });
};
exports.createPaymentSession.public = true;

/**
 * POST /payments/submit
 */
exports.submitPayment = function() {
    var body = readBody();

    if (!body || !body.sessionId || !body.sessionData || !body.orderNo) {
        invalidRequest('sessionId, sessionData and orderNo are required.');

        return;
    }

    render(require('*/cartridge/scripts/checkoutcom/checkout').submitPayment(body), function(result) {
        return result.response;
    });
};
exports.submitPayment.public = true;

/**
 * POST /wallets/config
 */
exports.getWalletConfig = function() {
    render(require('*/cartridge/scripts/checkoutcom/checkout').getWalletConfig(), function(result) {
        return {
            environment: result.environment,
            publicKey: result.publicKey,
            accountPrefix: result.accountPrefix,
            merchantName: result.merchantName,
            googlePay: result.googlePay,
            applePay: result.applePay,
        };
    });
};
exports.getWalletConfig.public = true;

/**
 * POST /wallets/apple-pay/session
 */
exports.createApplePaySession = function() {
    var body = readBody();

    if (!body || !body.validationUrl || !body.domain) {
        invalidRequest('validationUrl and domain are required.');

        return;
    }

    render(require('*/cartridge/scripts/checkoutcom/checkout').createApplePaySession(body), function(result) {
        return { session: result.session };
    });
};
exports.createApplePaySession.public = true;

/**
 * POST /wallets/apple-pay/domain-association
 */
exports.getApplePayDomainAssociation = function() {
    render(require('*/cartridge/scripts/checkoutcom/checkout').getApplePayDomainAssociation(), function(result) {
        return { content: result.content };
    });
};
exports.getApplePayDomainAssociation.public = true;

/**
 * POST /wallets/payments
 */
exports.submitWalletPayment = function() {
    var body = readBody();

    if (!body || !body.orderNo || !body.paymentMethodId || !body.token || !body.successUrl || !body.failureUrl) {
        invalidRequest('orderNo, paymentMethodId, token, successUrl and failureUrl are required.');

        return;
    }

    render(require('*/cartridge/scripts/checkoutcom/checkout').submitWalletPayment(body), function(result) {
        return {
            status: result.status,
            pending: result.pending === true,
            orderNo: result.orderNo || null,
            orderToken: result.orderToken || null,
            redirectUrl: result.redirectUrl || null,
            errorMessage: result.errorMessage || null,
        };
    });
};
exports.submitWalletPayment.public = true;

/**
 * POST /payments/complete
 */
exports.completePayment = function() {
    var body = readBody();

    if (!body || !body.paymentId) {
        invalidRequest('paymentId is required.');

        return;
    }

    render(require('*/cartridge/scripts/checkoutcom/checkout').completePayment(body), function(result) {
        return {
            status: result.status,
            pending: result.pending === true,
            orderNo: result.orderNo || null,
            orderToken: result.orderToken || null,
            errorMessage: result.errorMessage || null,
        };
    });
};
exports.completePayment.public = true;

/**
 * POST /orders/release
 */
exports.releaseOrder = function() {
    var body = readBody();

    if (!body || !body.orderNo) {
        invalidRequest('orderNo is required.');

        return;
    }

    render(require('*/cartridge/scripts/checkoutcom/checkout').releaseOrder(body), function(result) {
        return {
            status: result.status,
            orderNo: result.orderNo || null,
            orderToken: result.orderToken || null,
            errorMessage: result.errorMessage || null,
        };
    });
};
exports.releaseOrder.public = true;
