'use strict';

var Logger = require('dw/system/Logger');

var config = require('*/cartridge/scripts/checkoutcom/config');

var log = Logger.getLogger(config.LOG_CATEGORY);

/**
 * The typed payment details (Payment Commerce Apps, Beta) of a Checkout.com
 * card payment: SalesforceCardPaymentDetails on the instrument and
 * SalesforceCardTransactionDetails on its transaction.
 *
 * Only card payments (source.type card) carry these details. The values come
 * from a payment read back from Checkout.com, or from a signed payment_approved
 * webhook, which carries the same source, 3ds and eci fields.
 *
 * Instances without the classes (releases before the Beta) are left unchanged.
 */

/** Checkout.com card schemes to SalesforceCardPaymentDetails brands. */
var BRANDS = {
    VISA: 'BRAND_VISA',
    MASTERCARD: 'BRAND_MASTERCARD',
    AMEX: 'BRAND_AMEX',
    'AMERICAN EXPRESS': 'BRAND_AMEX',
    DINERS: 'BRAND_DINERS',
    'DINERS CLUB': 'BRAND_DINERS',
    'DINERS CLUB INTERNATIONAL': 'BRAND_DINERS',
    DISCOVER: 'BRAND_DISCOVER',
    JCB: 'BRAND_JCB',
    UNIONPAY: 'BRAND_UNIONPAY',
    'CHINA UNION PAY': 'BRAND_UNIONPAY',
    CUP: 'BRAND_UNIONPAY',
};

var FUNDING_TYPES = { CREDIT: 'FUNDING_TYPE_CREDIT', DEBIT: 'FUNDING_TYPE_DEBIT', PREPAID: 'FUNDING_TYPE_PREPAID' };

var WALLET_TYPES = { applepay: 'WALLET_TYPE_APPLE_PAY', apple_pay: 'WALLET_TYPE_APPLE_PAY', googlepay: 'WALLET_TYPE_GOOGLE_PAY', google_pay: 'WALLET_TYPE_GOOGLE_PAY' };

/** Checkout.com cvv_check codes to CVC results. */
var CVC_RESULTS = { Y: 'CVC_RESULT_MATCH', N: 'CVC_RESULT_NO_MATCH', P: 'CVC_RESULT_NOT_PROCESSED' };

/** Checkout.com avs_check codes to the one-letter AVS results. */
var AVS_RESULTS = {
    Y: 'AVS_RESULT_MATCH', X: 'AVS_RESULT_MATCH', D: 'AVS_RESULT_MATCH', F: 'AVS_RESULT_MATCH', M: 'AVS_RESULT_MATCH',
    A: 'AVS_RESULT_PARTIAL_MATCH_ADDRESS', B: 'AVS_RESULT_PARTIAL_MATCH_ADDRESS',
    Z: 'AVS_RESULT_PARTIAL_MATCH_ZIP', W: 'AVS_RESULT_PARTIAL_MATCH_ZIP', P: 'AVS_RESULT_PARTIAL_MATCH_ZIP',
    N: 'AVS_RESULT_NO_MATCH', C: 'AVS_RESULT_NO_MATCH',
    R: 'AVS_RESULT_RETRY',
    S: 'AVS_RESULT_NOT_SUPPORTED', G: 'AVS_RESULT_NOT_SUPPORTED',
    U: 'AVS_RESULT_UNAVAILABLE', I: 'AVS_RESULT_UNAVAILABLE', E: 'AVS_RESULT_UNAVAILABLE',
};

/** 3DS authentication_response (transStatus) to 3DS results. */
var THREE_DS_RESULTS = { Y: 'THREE_DS_RESULT_AUTHENTICATED', A: 'THREE_DS_RESULT_ATTEMPTED', N: 'THREE_DS_RESULT_FAILED', R: 'THREE_DS_RESULT_REJECTED', U: 'THREE_DS_RESULT_UNAVAILABLE' };

/**
 * The dw.extensions.payments card classes, or null on an instance without them.
 * Each path is a literal: the Commerce Apps security scan refuses computed requires.
 * @returns {{CardDetails: Function, CardTransaction: Function|null}|null} The classes
 */
function loadCardClasses() {
    var CardDetails = null;
    var CardTransaction = null;

    try {
        CardDetails = require('dw/extensions/payments/SalesforceCardPaymentDetails');
    } catch (e) {
        return null;
    }

    try {
        CardTransaction = require('dw/extensions/payments/SalesforceCardTransactionDetails');
    } catch (e) {
        CardTransaction = null;
    }

    return { CardDetails: CardDetails, CardTransaction: CardTransaction };
}

/**
 * @param {Object} table A map of source codes to constant names
 * @param {*} code The Checkout.com code
 * @param {Function} Class The class holding the constants
 * @returns {string|null} The constant's value
 */
function constant(table, code, Class) {
    var name = code === undefined || code === null ? null : table[String(code).toUpperCase()] || table[String(code).toLowerCase()];

    return name && Class[name] !== undefined ? Class[name] : null;
}

/**
 * Call a setter only with a value.
 * @param {Object} target The details object
 * @param {string} setter The setter name
 * @param {*} value The value
 */
function set(target, setter, value) {
    if (value !== undefined && value !== null && value !== '' && typeof target[setter] === 'function') {
        target[setter](value);
    }
}

/**
 * @param {Object} payment The Checkout.com payment or webhook data
 * @param {Function} CardDetails SalesforceCardPaymentDetails
 * @returns {Object} The card payment details
 */
function cardPaymentDetails(payment, CardDetails) {
    var source = payment.source;
    var details = new CardDetails();

    set(details, 'setBrand', source.scheme ? constant(BRANDS, source.scheme, CardDetails) || CardDetails.BRAND_UNKNOWN : null);
    set(details, 'setLast4', source.last_4);
    set(details, 'setBin', source.bin ? String(source.bin).substring(0, 8) : null);
    set(details, 'setExpirationMonth', source.expiry_month);
    set(details, 'setExpirationYear', source.expiry_year);
    set(details, 'setFundingType', constant(FUNDING_TYPES, source.card_type, CardDetails));
    set(details, 'setIssuingCountry', source.issuer_country);
    set(details, 'setWalletType', constant(WALLET_TYPES, source.wallet_type, CardDetails));

    return details;
}

/**
 * @param {Object} payment The Checkout.com payment or webhook data
 * @param {Function} CardTransaction SalesforceCardTransactionDetails
 * @returns {Object} The card transaction details
 */
function cardTransactionDetails(payment, CardTransaction) {
    var source = payment.source;
    var threeDS = payment['3ds'] || {};
    var details = new CardTransaction();

    set(details, 'setCvcResult', source.cvv_check ? constant(CVC_RESULTS, source.cvv_check, CardTransaction) || CardTransaction.CVC_RESULT_UNAVAILABLE : null);
    set(details, 'setAvsResult', constant(AVS_RESULTS, source.avs_check, CardTransaction));
    set(details, 'setThreeDSResult', constant(THREE_DS_RESULTS, threeDS.authentication_response, CardTransaction));

    if (threeDS.version) {
        set(details, 'setThreeDSVersion', String(threeDS.version).charAt(0) === '1' ? CardTransaction.THREE_DS_VERSION_V1 : CardTransaction.THREE_DS_VERSION_V2);
    }

    set(details, 'setThreeDSTransactionId', threeDS.ds_transaction_id || threeDS.xid);
    set(details, 'setElectronicCommerceIndicator', threeDS.eci || payment.eci);

    return details;
}


module.exports = {
    /**
     * Set the typed card details of the order's instrument from a card payment.
     * Never fails the caller: a problem is logged and the details are skipped.
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The order's payment instrument
     * @param {Object} payment The Checkout.com payment, or the data of a signed webhook
     * @returns {boolean} True when details were set
     */
    apply: function(paymentInstrument, payment) {
        if (!paymentInstrument || !payment || !payment.source || !payment.source.type
            || typeof paymentInstrument.setPaymentDetails !== 'function') {
            return false;
        }

        if (String(payment.source.type).toLowerCase() !== 'card') {
            return false;
        }

        try {
            var classes = loadCardClasses();
            var transaction = paymentInstrument.getPaymentTransaction();

            if (!classes) {
                return false;
            }

            var CardDetails = classes.CardDetails;
            var CardTransaction = classes.CardTransaction;

            paymentInstrument.setPaymentDetails(cardPaymentDetails(payment, CardDetails));

            if (CardTransaction && typeof transaction.setTransactionDetails === 'function') {
                transaction.setTransactionDetails(cardTransactionDetails(payment, CardTransaction));
            }

            return true;
        } catch (e) {
            log.warn('Payment {0}: payment details not recorded: {1}', payment.id, e.message);
        }

        return false;
    },

    /**
     * @param {dw.order.OrderPaymentInstrument} paymentInstrument The instrument
     * @returns {boolean} True when it has no typed payment details yet
     */
    isMissing: function(paymentInstrument) {
        return !!paymentInstrument && typeof paymentInstrument.getPaymentDetails === 'function' && !paymentInstrument.getPaymentDetails();
    },
};
