'use strict';

/**
 * Masking of Checkout.com payloads before they reach a log (the service
 * communication log).
 *
 * The payloads carry the shopper's name, email, phone and addresses, wallet
 * tokens, card details (BIN, last 4, expiry) and the Flow session secrets, and
 * their shapes change with every payment method. So the masking is not a list
 * of fields to hide: it walks the whole structure, nested objects and arrays
 * included, and keeps in clear only the values of the keys listed below, which
 * describe the payment and never the shopper, the card or a credential. Every
 * other value is masked, whatever its key and wherever it is.
 */

/** Keys whose values are kept in clear. Compared in lower case. */
var CLEAR_KEYS = [
    // The payment, its actions and its outcome
    'id', 'action_id', 'amount', 'currency', 'status', 'approved', 'reference', 'type', 'payment_type',
    'capture', 'capture_on', 'response_code', 'response_summary', 'processing_channel_id',
    'created_on', 'processed_on', 'requested_on', 'expires_on', 'payment_processor', 'integration',
    'platform_data', 'locale', 'country', 'enabled_payment_methods', 'disabled_payment_methods',
    'flagged', 'score',
    // Balances
    'total_authorized', 'total_voided', 'available_to_void', 'total_captured',
    'available_to_capture', 'total_refunded', 'available_to_refund',
    // Order lines and Level 2 / 3 data: amounts and quantities, never names
    'quantity', 'unit_price', 'total_amount', 'tax_amount', 'discount_amount', 'shipping_amount',
    'duty_amount', 'commodity_code', 'unit_of_measure', 'order_id',
    // Card attributes that identify no card
    'scheme', 'local_schemes', 'card_type', 'card_category', 'card_wallet_type', 'issuer_country',
    'product_type', 'product_id',
    // 3-D Secure flags
    'enabled', 'attempt_n3d', 'challenge_indicator', 'exemption', 'version', 'eci',
    'authentication_response', 'challenged', 'downgraded', 'enrolled',
    // Errors
    'error_type', 'error_codes', 'request_id', 'code',
];

var MAX_DEPTH = 20;

/**
 * @param {*} value A primitive value
 * @returns {*} The value masked, keeping its length and separators; booleans and null are kept
 */
function maskValue(value) {
    if (value === null || value === undefined || typeof value === 'boolean') {
        return value;
    }

    return String(value).replace(/[A-Za-z0-9]/g, '*');
}

/**
 * @param {string} key An object key
 * @returns {boolean} True when the key's value may be logged in clear
 */
function isClearKey(key) {
    return CLEAR_KEYS.indexOf(String(key).toLowerCase()) !== -1;
}

/**
 * @param {*} value The value
 * @param {boolean} clear True when the value sits under a clear key
 * @param {number} depth The nesting depth
 * @returns {*} A masked copy
 */
function walk(value, clear, depth) {
    if (value === null || value === undefined) {
        return value;
    }

    if (depth > MAX_DEPTH) {
        return '[redacted]';
    }

    if (Array.isArray(value)) {
        return value.map(function(item) {
            return walk(item, clear, depth + 1);
        });
    }

    if (typeof value === 'object') {
        var result = {};

        Object.keys(value).forEach(function(key) {
            result[key] = walk(value[key], isClearKey(key), depth + 1);
        });

        return result;
    }

    return clear ? value : maskValue(value);
}

module.exports = {
    /**
     * @param {*} data A payload
     * @returns {*} A masked copy; the input is not changed
     */
    redact: function(data) {
        return walk(data, false, 0);
    },

    /**
     * Mask a payload for a log line.
     * @param {Object|string} data A payload, or its JSON text
     * @returns {string} The masked JSON text; text that is not JSON is never logged
     */
    toLogMessage: function(data) {
        var parsed = data;

        if (data === null || data === undefined || data === '') {
            return '';
        }

        if (typeof data === 'string') {
            try {
                parsed = JSON.parse(data);
            } catch (e) {
                return '[payload of ' + data.length + ' characters, not JSON: not logged]';
            }
        }

        try {
            return JSON.stringify(this.redact(parsed));
        } catch (e) {
            return '[payload not logged: ' + e.message + ']';
        }
    },

    isClearKey: isClearKey,
};
