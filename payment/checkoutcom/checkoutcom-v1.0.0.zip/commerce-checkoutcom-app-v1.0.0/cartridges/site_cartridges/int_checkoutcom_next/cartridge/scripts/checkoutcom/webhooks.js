'use strict';

var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var Encoding = require('dw/crypto/Encoding');
var Logger = require('dw/system/Logger');
var Mac = require('dw/crypto/Mac');
var Order = require('dw/order/Order');
var OrderMgr = require('dw/order/OrderMgr');
var Transaction = require('dw/system/Transaction');

var checkout = require('*/cartridge/scripts/checkoutcom/checkout');
var config = require('*/cartridge/scripts/checkoutcom/config');
var details = require('*/cartridge/scripts/checkoutcom/details');
var gateway = require('*/cartridge/scripts/checkoutcom/gateway');
var ledger = require('*/cartridge/scripts/checkoutcom/ledger');
var orders = require('*/cartridge/scripts/checkoutcom/orders');

var payload = require('*/cartridge/scripts/checkoutcom/payload');

var EVENT_TYPE = 'ckoWebhookEvent';

/** How long an event for one of our payments may wait for its order before it is let go. */
var RETRY_WINDOW_MS = 24 * 60 * 60 * 1000;

/** Event outcomes: applied, ignored (nothing of ours to update), retry (try again later). */
var OUTCOME = { APPLIED: 'applied', IGNORED: 'ignored', RETRY: 'retry' };

var log = Logger.getLogger(config.LOG_CATEGORY);

/**
 * Compare two strings in constant time.
 * @param {string} a First string
 * @param {string} b Second string
 * @returns {boolean} True when equal
 */
function constantTimeEquals(a, b) {
    if (a.length !== b.length) {
        return false;
    }

    var result = 0;

    for (var i = 0; i < a.length; i += 1) {
        result |= a.charCodeAt(i) ^ b.charCodeAt(i); // eslint-disable-line no-bitwise
    }

    return result === 0;
}

/**
 * Webhook authentication, de-duplication and order reconciliation.
 * Checkout never waits for webhooks: completion is synchronous. Webhooks keep
 * the order and the BM transaction ledger in step afterwards (captures,
 * refunds, voids, late approvals and declines).
 */
/**
 * Events that move an order still waiting for its payment (CREATED, payment
 * PENDING) to placed: the payment is verified and the transition attempted.
 */
var SETTLING_EVENTS = ['payment_approved', 'payment_captured'];

/** The ledger entry each money-moving event records. */
var LEDGER_EVENTS = { payment_captured: 'Capture', payment_refunded: 'Refund', payment_voided: 'Void' };

/**
 * Confirm a capture, refund or void with Checkout.com before recording it: the
 * payment's own balances must cover what the ledger would then hold. A forged
 * or replayed event can never mark an order paid or refunded.
 * @param {dw.order.Order} order The order
 * @param {string} type Capture, Refund or Void
 * @param {Object} data The event data
 * @param {Object} payment The payment read back from Checkout.com
 * @returns {boolean} True when the gateway confirms the action
 */
function isConfirmedByGateway(order, type, data, payment) {
    var balances = payment.balances || {};
    var currency = order.getCurrencyCode();
    var recorded = function(entry) {
        return payload.numberToMinorUnits(ledger.totalOf(order, entry), currency);
    };
    var amount = Number(data.amount) || 0;

    if (type === 'Capture') {
        // The capture of an auto captured payment is already recorded at
        // placement; its webhook only adds the action id, not another amount
        var added = ledger.hasCaptureAwaitingAction(order) ? 0 : amount;

        return Number(balances.total_captured || 0) >= recorded('Capture') + added;
    }

    if (type === 'Refund') {
        return Number(balances.total_refunded || 0) >= recorded('Refund') + amount;
    }

    return Number(balances.total_voided || 0) > 0 || payment.status === 'Voided';
}

/**
 * @param {Object} data The event data
 * @returns {boolean} True for a payment made through this integration
 */
function isOurPayment(data) {
    return !!data.metadata && data.metadata.integration === 'sfcc_storefront_next';
}

/**
 * @param {Object} event The webhook event
 * @returns {boolean} True while an unmatched event is still worth retrying
 */
function isRecent(event) {
    var created = Date.parse(event.created_on || '');

    return isNaN(created) || Date.now() - created < RETRY_WINDOW_MS;
}

module.exports = {
    OUTCOME: OUTCOME,

    /**
     * Authenticate a webhook: HMAC-SHA256 of the raw body in Cko-Signature,
     * only. A static key in a header proves nothing about the body.
     * @param {string} rawBody The raw request body
     * @param {string} signature The Cko-Signature header
     * @returns {boolean} True when authentic
     */
    isAuthentic: function(rawBody, signature) {
        if (!signature) {
            return false;
        }

        // Any of the configured keys: several are accepted during a key rotation
        return config.getWebhookKeys().some(function(key) {
            var computed = Encoding.toHex(new Mac(Mac.HMAC_SHA_256).digest(rawBody, key));

            return constantTimeEquals(computed.toLowerCase(), String(signature).toLowerCase());
        });
    },

    /**
     * @param {string} eventId The event id
     * @returns {boolean} True when the event was already processed
     */
    isProcessed: function(eventId) {
        return !!eventId && CustomObjectMgr.getCustomObject(EVENT_TYPE, eventId) !== null;
    },

    /**
     * @param {string} eventId The event id
     * @param {string} eventType The event type
     */
    markProcessed: function(eventId, eventType) {
        if (!eventId) {
            return;
        }

        Transaction.wrap(function() {
            if (CustomObjectMgr.getCustomObject(EVENT_TYPE, eventId) === null) {
                CustomObjectMgr.createCustomObject(EVENT_TYPE, eventId).custom.eventType = eventType;
            }
        });
    },

    /**
     * Apply an event to its order.
     * @param {Object} event The webhook event ({ id, type, created_on, data })
     * @returns {string} The outcome (OUTCOME): retry asks Checkout.com to deliver it again
     */
    handleEvent: function(event) {
        var data = event.data || {};
        // Webhooks have no shopper session: the order is loaded through its
        // payment binding (order number + token), see orders.getBoundOrder, or
        // through the payment attempt its reference (the order number) names,
        // which exists before Checkout.com even answers the submission
        var order = orders.getBoundOrder(data.id);
        var bound = !!order;

        if (!order) {
            order = orders.getAttemptOrder(data.reference);
        }

        log.info('Webhook {0} {1} received for payment {2} (action {3}, reference {4}).', event.id, event.type, data.id, data.action_id, data.reference);

        if (!order) {
            if (isOurPayment(data) && isRecent(event)) {
                // A wallet payment whose order the storefront is still creating
                log.info('Webhook {0} {1}: payment {2} has no order yet; asking for a retry.', event.id, event.type, data.id);

                return OUTCOME.RETRY;
            }

            // A payment that never got an order, or another integration's
            log.info('Webhook {0} {1}: payment {2} has no order; nothing to update.', event.id, event.type, data.id);

            return OUTCOME.IGNORED;
        }

        var waiting = orders.isAwaitingPayment(order) && SETTLING_EVENTS.indexOf(event.type) !== -1;

        if (!bound || waiting) {
            // Found only by its reference: the completion that binds it has not run
            // (lost response, closed browser). Or the order still waits for this
            // payment (3DS the shopper left, a voucher paid later). Apply it now,
            // with the same checks: the transition places the order, and a payment
            // for a failed or already paid order is reversed.
            var verification = gateway.getPayment(data.id);

            if (!verification.ok || !verification.object) {
                log.warn('Webhook {0} {1}: payment {2} could not be verified; asking for a retry.', event.id, event.type, data.id);

                return OUTCOME.RETRY;
            }

            var result = checkout.reconcilePayment(order, verification.object);

            log.info('Webhook {0} {1}: payment {2} reconciled with order {3}: {4}.', event.id, event.type, data.id, order.getOrderNo(), result.status || result.errorMessage);

            if (result.status === 'unverified') {
                return OUTCOME.RETRY;
            }

            order = orders.reload(order);

            if (orders.getBoundOrderNo(data.id) !== order.getOrderNo()) {
                return OUTCOME.APPLIED;
            }
        }

        var ledgerType = LEDGER_EVENTS[event.type];

        // An action already in the ledger is a repeat: nothing new to confirm
        if (ledgerType && !ledger.hasAction(order, data.action_id)) {
            var gatewayPayment = gateway.getPayment(data.id);

            if (!gatewayPayment.ok || !gatewayPayment.object) {
                return OUTCOME.RETRY;
            }

            if (!isConfirmedByGateway(order, ledgerType, data, gatewayPayment.object)) {
                log.warn('Webhook {0} {1}: not confirmed by the balances of payment {2}; not recorded.', event.id, event.type, data.id);

                return isRecent(event) ? OUTCOME.RETRY : OUTCOME.IGNORED;
            }
        }

        Transaction.wrap(function() {
            // A signed card approval carries the payment's source, 3ds and eci:
            // they fill the card details when the order lacks them
            var primary = order.getPaymentInstruments(config.PAYMENT_METHOD_ID).toArray()[0];

            if (event.type === 'payment_approved' && details.isMissing(primary)) {
                details.apply(primary, data);
            }

            switch (event.type) {
                case 'payment_captured':
                case 'payment_refunded':
                case 'payment_voided':
                    // Not for an order still waiting: its payment is not placed yet
                    if (!orders.isAwaitingPayment(order)) {
                        ledger.recordAction(order, ledgerType, data);
                    }
                    break;
                case 'payment_declined':
                case 'payment_expired':
                case 'payment_canceled':
                    if (order.getStatus().getValue() === Order.ORDER_STATUS_CREATED) {
                        // The payment never came through: the platform reopens
                        // the basket and runs reversePayment (nothing to release)
                        OrderMgr.failOrder(order, true);
                    } else if (order.getPaymentStatus().getValue() !== Order.PAYMENT_STATUS_PAID) {
                        order.setConfirmationStatus(Order.CONFIRMATION_STATUS_NOTCONFIRMED);
                    }
                    break;
                default:
                    break;
            }

            order.addNote('Checkout.com', event.type + ' (' + data.id + ')');
        });

        log.info('Webhook {0} {1} applied to order {2}; payment status {3}.', event.id, event.type, order.getOrderNo(), order.getPaymentStatus().getDisplayValue ? order.getPaymentStatus().getDisplayValue() : order.getPaymentStatus().getValue());

        return OUTCOME.APPLIED;
    },
};
