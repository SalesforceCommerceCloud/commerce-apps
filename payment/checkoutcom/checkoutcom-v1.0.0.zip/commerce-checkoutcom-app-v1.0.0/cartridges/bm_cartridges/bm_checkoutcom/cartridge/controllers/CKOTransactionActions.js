'use strict';

/**
 * Capture, refund and void from the Checkout.com Manager console. Money moves,
 * so this controller is its own Business Manager module (bm_extensions.xml,
 * menu action checkoutcom_transaction_actions): a role needs that module, as
 * well as the transactions list, to use these actions.
 *
 * Nothing about the payment is taken from the request but the order number,
 * the action and its amount. The payment and currency come from the order,
 * and the amount may not exceed what Checkout.com still allows for the payment
 * (its balances: available_to_capture, available_to_refund, available_to_void).
 */

/* API Includes */
var CSRFProtection = require('dw/web/CSRFProtection');
var Logger = require('dw/system/Logger');
var OrderMgr = require('dw/order/OrderMgr');

/* Checkout.com Helper functions */
var CKOHelper = require('*/cartridge/scripts/helpers/CKOHelper');

/** Checkout Data Configuration File **/
var constants = require('*/cartridge/config/constants');

var log = Logger.getLogger('checkoutcom');

/** The actions the console may request, and the balance that limits each. */
var LIMITS = {
    capture: 'available_to_capture',
    refund: 'available_to_refund',
    void: 'available_to_void',
};

/**
 * Answer an action request.
 * @param {number} status The HTTP status
 * @param {*} body The JSON body: the accepted gateway response, or false / an error
 */
function respond(status, body) {
    // eslint-disable-next-line
    response.setStatus(status);
    // eslint-disable-next-line
    response.setContentType('application/json');
    // eslint-disable-next-line
    response.writer.println(JSON.stringify(body));
}

/**
 * Whether the order was paid with a card: an express wallet payment (always a
 * card), or a Flow payment holding card details (set only from a card payment).
 * @param {dw.order.Order} order The order
 * @returns {boolean} True for a card payment; false when unknown
 */
function isCardOrder(order) {
    var instrument = CKOHelper.getCkoInstrument(order);
    var method = instrument ? instrument.getPaymentMethod() : null;

    if (method === 'CHECKOUTCOM_APPLE_PAY' || method === 'CHECKOUTCOM_GOOGLE_PAY') {
        return true;
    }

    return method === 'CHECKOUTCOM_FLOW' && typeof instrument.getPaymentDetails === 'function' && !!instrument.getPaymentDetails();
}

/**
 * Visa and Mastercard Level 2 data for a capture of a card payment: the order
 * number, and the order's tax and shipping when the whole order is captured
 * (they would not be true for part of it). Other methods get none.
 * @param {dw.order.Order} order The order
 * @param {number} amount The capture amount, in minor units
 * @returns {Object|null} processing.order_id, tax_amount and shipping_amount
 */
function levelTwoProcessing(order, amount) {
    if (!isCardOrder(order)) {
        return null;
    }

    var currency = order.getCurrencyCode();
    var processing = {};
    var minor = function(money) {
        return money && money.isAvailable() ? Number(CKOHelper.getFormattedPrice(String(money.getValue()), currency)) : null;
    };

    if (String(order.getOrderNo()).length <= 15) {
        processing.order_id = String(order.getOrderNo());
    }

    if (minor(order.getTotalGrossPrice()) === amount) {
        var tax = minor(order.getTotalTax());
        var shipping = minor(order.getAdjustedShippingTotalPrice());

        if (tax !== null) {
            processing.tax_amount = tax;
        }

        if (shipping !== null) {
            processing.shipping_amount = shipping;
        }
    }

    return Object.keys(processing).length > 0 ? processing : null;
}

/**
 * Check an action against the order and the payment's balances.
 * @param {string} task capture, refund or void
 * @param {string} orderNo The order number from the console
 * @param {string} amountValue The amount from the console, in major units (unused for void)
 * @returns {Object} { ok, status, error } or { ok, order, paymentId, amount (minor units), limit }
 */
function checkAction(task, orderNo, amountValue) {
    if (!Object.prototype.hasOwnProperty.call(LIMITS, task)) {
        return { ok: false, status: 400, error: 'unknown_action' };
    }

    var order = orderNo ? OrderMgr.getOrder(orderNo) : null;

    if (!order) {
        return { ok: false, status: 404, error: 'no_order' };
    }

    // The order's own Checkout.com payment, never one named by the request
    var paymentId = CKOHelper.getOrderPaymentId(order);

    if (!paymentId) {
        return { ok: false, status: 409, error: 'no_payment' };
    }

    var amount = null;

    if (task !== 'void') {
        // A plain decimal ("12.34"), at least one minor unit: never "5abc", "1e-9" or "1,5"
        if (!/^\d{1,10}(\.\d{1,3})?$/.test(String(amountValue || ''))) {
            return { ok: false, status: 400, error: 'invalid_amount' };
        }

        amount = Number(CKOHelper.getFormattedPrice(String(amountValue), order.getCurrencyCode()));

        if (!Number.isInteger(amount) || amount < 1) {
            return { ok: false, status: 400, error: 'invalid_amount' };
        }
    }

    // What Checkout.com still allows for the payment, in minor units
    var balances = CKOHelper.getPaymentBalances(paymentId);

    if (!balances || typeof balances[LIMITS[task]] !== 'number') {
        return { ok: false, status: 502, error: 'balances_unavailable' };
    }

    var limit = balances[LIMITS[task]];

    if (task === 'void' ? limit <= 0 : amount > limit) {
        return { ok: false, status: 422, error: 'exceeds_available', limit: limit };
    }

    return { ok: true, order: order, paymentId: paymentId, amount: amount, limit: limit };
}

/**
 * Perform a capture, void or refund for the console. The request must be a
 * POST from the console page itself (CSRF token), from a user whose role has
 * this module.
 */
function remoteCall() {
    // eslint-disable-next-line
    if (request.getHttpMethod() !== 'POST' || !CSRFProtection.validateRequest()) {
        respond(403, false);

        return;
    }

    // eslint-disable-next-line
    var params = request.httpParameterMap;
    var task = params.get('task').stringValue;
    var orderNo = params.get('orderNo').stringValue;
    var checked = checkAction(task, orderNo, params.get('amount').stringValue);

    if (!checked.ok) {
        log.warn('Business Manager {0} refused for order {1}: {2}.', task, orderNo, checked.error);
        respond(checked.status, { error: checked.error, limit: checked.limit === undefined ? null : checked.limit });

        return;
    }

    var mode = String(CKOHelper.getValue(constants.CKO_MODE)) === 'production' ? 'production' : 'sandbox';
    var serviceName = 'cko.transaction.' + task + '.' + mode + '.service';
    var nonce = params.get('nonce').stringValue;
    var gRequest = {
        reference: checked.order.getOrderNo(),
        chargeId: checked.paymentId,
        // One action per opening of the console's dialog: a double click or a
        // retried request is processed once by Checkout.com
        idempotencyKey: nonce && /^[a-z0-9]{8,40}$/i.test(nonce) ? 'bm_' + checked.order.getOrderNo() + '_' + task + '_' + nonce : null,
    };

    if (task !== 'void') {
        gRequest.amount = checked.amount;
    }

    // Allow further partial captures after this one
    if (task === 'capture') {
        gRequest.capture_type = 'NonFinal';

        var processing = levelTwoProcessing(checked.order, checked.amount);

        if (processing) {
            gRequest.processing = processing;
        }
    }

    CKOHelper.log(CKOHelper._('cko.request.data', 'cko') + ' - ' + serviceName, gRequest);
    log.info('Business Manager {0} requested: order {1}, payment {2}, amount {3} (minor units).', task, checked.order.getOrderNo(), checked.paymentId, checked.amount);

    var gResponse = CKOHelper.getGatewayClient(serviceName, gRequest);

    // Accepted only with an action id: on failure the client returns an error
    // code, which must not read as success in the console
    var accepted = !!gResponse && typeof gResponse === 'object' && !!gResponse.action_id;

    if (accepted) {
        log.info('Business Manager {0} accepted by Checkout.com: order {1}, payment {2}, action {3}.', task, checked.order.getOrderNo(), checked.paymentId, gResponse.action_id);
    } else {
        log.warn('Business Manager {0} failed: order {1}, payment {2}, response {3}.', task, checked.order.getOrderNo(), checked.paymentId, JSON.stringify(gResponse));
    }

    respond(200, accepted ? gResponse : false);
}

/**
 * The transactions list with the capture, refund and void buttons: the entry
 * point of this module, so only the roles granted it get the actions.
 */
function listTransactions() {
    var ISML = require('dw/template/ISML');
    var startFilterYear = String(new Date().getFullYear() - constants.CKO_FILTER_YEARS_BACK);
    ISML.renderTemplate('transactions/list', { startFilterYear: startFilterYear, canAct: true });
}

/*
 * Web exposed methods
 */

listTransactions.public = true;
remoteCall.public = true;

exports.ListTransactions = listTransactions;
exports.RemoteCall = remoteCall;

// For tests
exports.checkAction = checkAction;
exports.levelTwoProcessing = levelTwoProcessing;
