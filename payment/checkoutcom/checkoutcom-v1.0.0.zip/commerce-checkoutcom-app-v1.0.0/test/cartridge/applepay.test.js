'use strict';

/**
 * Apple Pay merchant validation (express checkout): the instance calls only
 * Apple's validation hosts, for an allowed storefront domain, presenting the
 * merchant identity certificate by its key store alias.
 */

const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const { load } = require('./helpers/sfcc');

const PREFS = {
    ckoMode: 'sandbox',
    ckoFlowAllowedReturnOrigins: 'https://shop.example, https://www.shop.example',
    ckoApplePayMerchantId: 'merchant.com.example.sandbox',
    ckoApplePayCertificateAlias: 'cko-applepay',
    ckoApplePayButton: 'white-outline',
    ckoApplePayDomainAssociation: '7B227073704964223A2239...',
};

let calls;

beforeEach(() => {
    calls = [];
});

/** A LocalServiceRegistry fake for the validation service: records URL, identity and body. */
function registry(answer) {
    return {
        createService: (serviceId, callbacks) => {
            const svc = {
                url: null,
                identity: null,
                setURL(url) { this.url = url; },
                setIdentity(keyRef) { this.identity = keyRef.alias; },
                setRequestMethod() {},
                addHeader() {},
            };

            return {
                setURL: (url) => svc.setURL(url),
                call: (body) => {
                    const sent = callbacks.createRequest(svc, body);

                    calls.push({ serviceId, url: svc.url, identity: svc.identity, body: JSON.parse(sent), log: callbacks.filterLogMessage('x') });

                    return answer || { isOk: () => true, getObject: () => ({ merchantSessionIdentifier: 'SSH...', signature: 'sig' }) };
                },
            };
        },
    };
}

function checkout(prefs = {}, extra = {}) {
    return load('scripts/checkoutcom/checkout', {
        preferences: { ...PREFS, ...prefs },
        flowActive: extra.methodActive !== false,
        'dw/crypto/KeyRef': class KeyRef { constructor(alias) { this.alias = alias; } },
        'dw/svc/LocalServiceRegistry': registry(extra.answer),
    });
}

const validation = 'https://apple-pay-gateway-cert.apple.com/paymentservices/startSession';

test('validation: Apple\'s host, the merchant id, the site name, the domain, with the identity certificate', () => {
    const result = checkout().createApplePaySession({ validationUrl: validation, domain: 'shop.example' });

    assert.equal(result.ok, true);
    assert.deepEqual(result.session, { merchantSessionIdentifier: 'SSH...', signature: 'sig' });
    assert.equal(calls.length, 1);
    assert.equal(calls[0].serviceId, 'cko.applepay.validation.service');
    assert.equal(calls[0].url, validation);
    assert.equal(calls[0].identity, 'cko-applepay');
    assert.deepEqual(calls[0].body, {
        merchantIdentifier: 'merchant.com.example.sandbox',
        displayName: 'Test Site',
        initiative: 'web',
        initiativeContext: 'shop.example',
    });
    // The merchant session is never written to the communication log
    assert.equal(calls[0].log.includes('SSH'), false);
});

test('only Apple\'s validation endpoints are called: anything else is refused without a request', () => {
    const service = checkout();

    [
        'https://evil.example/paymentservices/startSession',
        'https://apple-pay-gateway.apple.com.evil.example/paymentservices/startSession',
        'http://apple-pay-gateway.apple.com/paymentservices/startSession',
        'https://apple-pay-gateway.apple.com/other',
        'https://169.254.169.254/latest/meta-data',
    ].forEach((url) => {
        assert.equal(service.createApplePaySession({ validationUrl: url, domain: 'shop.example' }).ok, false, url);
    });

    assert.equal(calls.length, 0);

    // Apple's production, China and pod hosts are accepted
    const applepay = load('scripts/checkoutcom/applepay', { 'dw/crypto/KeyRef': class {}, 'dw/svc/LocalServiceRegistry': registry() });

    [
        'https://apple-pay-gateway.apple.com/paymentservices/startSession',
        'https://apple-pay-gateway-nc-pod5.apple.com/paymentservices/paymentSession',
        'https://cn-apple-pay-gateway-sh-pod2.apple.com/paymentservices/startSession',
        'https://cn-apple-pay-gateway.apple.com/paymentservices/paymentSession',
    ].forEach((url) => assert.equal(applepay.isValidationUrl(url), true, url));
});

test('the domain must be one of the allowed storefront origins', () => {
    const service = checkout();

    assert.equal(service.createApplePaySession({ validationUrl: validation, domain: 'other.example' }).ok, false);
    assert.equal(service.createApplePaySession({ validationUrl: validation, domain: 'shop.example/path' }).ok, false);
    assert.equal(service.createApplePaySession({ validationUrl: validation, domain: 'www.shop.example' }).ok, true);
});

test('Apple Pay is off without the payment method, the merchant id or the certificate alias', () => {
    assert.equal(checkout({}, { methodActive: false }).createApplePaySession({ validationUrl: validation, domain: 'shop.example' }).ok, false);
    assert.equal(checkout({ ckoApplePayMerchantId: null }).createApplePaySession({ validationUrl: validation, domain: 'shop.example' }).ok, false);
    assert.equal(checkout({ ckoApplePayCertificateAlias: null }).createApplePaySession({ validationUrl: validation, domain: 'shop.example' }).ok, false);
    assert.equal(calls.length, 0);

    assert.equal(checkout({ ckoApplePayCertificateAlias: null }).getWalletConfig().applePay.enabled, false);
});

test('a failed validation (Apple refused the certificate) is reported, not thrown', () => {
    const result = checkout({}, { answer: { isOk: () => false, getObject: () => null, getError: () => 400, getErrorMessage: () => 'Bad Request' } })
        .createApplePaySession({ validationUrl: validation, domain: 'shop.example' });

    assert.equal(result.ok, false);
});

test('wallet config carries the Apple Pay switch and button style; the domain file is served as set', () => {
    const service = checkout();

    assert.deepEqual(service.getWalletConfig().applePay, { enabled: true, buttonStyle: 'white-outline' });
    assert.equal(service.getApplePayDomainAssociation().content, '7B227073704964223A2239...');
    assert.equal(checkout({ ckoApplePayDomainAssociation: null }).getApplePayDomainAssociation().content, '');
});
