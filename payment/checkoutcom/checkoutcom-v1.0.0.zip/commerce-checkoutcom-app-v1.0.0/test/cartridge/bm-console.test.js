'use strict';

/**
 * Business Manager console (bm_checkoutcom): capture, refund and void move
 * money, so they act only on the order's own payment, within what Checkout.com
 * still allows, from a POST with the CSRF token; the transactions list never
 * breaks on an order without a Checkout.com payment, and always pages.
 */

const { test } = require('node:test');
const assert = require('node:assert/strict');

const { load, Money } = require('./helpers/sfcc');

const PAYMENT_TRANSACTION = {
    TYPE_AUTH: 'AUTH', TYPE_CAPTURE: 'CAPTURE', TYPE_CREDIT: 'CREDIT',
};

/**
 * @param {Object} options orderNo, paymentId (order.custom.ckoPaymentId), method, details, total, currency
 * @returns {Object} A dw.order.Order fake with one Checkout.com instrument
 */
function makeOrder(options = {}) {
    const currency = options.currency || 'EUR';
    const instruments = (options.instruments || [{ method: options.method || 'CHECKOUTCOM_FLOW', transactionId: options.paymentId ?? 'pay_order1' }]).map((entry) => ({
        getPaymentMethod: () => entry.method,
        getPaymentDetails: () => options.details ?? null,
        getPaymentTransaction: () => ({
            getTransactionID: () => entry.transactionId,
            transactionID: entry.transactionId,
            type: { toString: () => entry.type || 'AUTH', displayValue: entry.type || 'AUTH' },
            amount: { value: entry.amount ?? 45, currencyCode: currency },
            custom: {},
            getCreationDate: () => new Date('2026-10-01'),
        }),
    }));

    return {
        orderNo: options.orderNo || '00000123',
        custom: { ckoPaymentId: options.paymentId === undefined ? 'pay_order1' : options.paymentId },
        getOrderNo: () => options.orderNo || '00000123',
        getCurrencyCode: () => currency,
        getTotalGrossPrice: () => new Money(options.total ?? 45, currency),
        getTotalTax: () => new Money(options.tax ?? 7.5, currency),
        getAdjustedShippingTotalPrice: () => new Money(options.shipping ?? 5, currency),
        getPaymentInstruments: () => ({
            toArray: () => instruments,
            iterator: () => {
                let index = 0;

                return { hasNext: () => index < instruments.length, next: () => instruments[index++] };
            },
        }),
    };
}

const collection = (items) => ({
    getCount: () => items.length,
    asList: (start, size) => ({ toArray: () => items.slice(start, start + size) }),
    close() {},
});

/**
 * Load a Business Manager module with dw fakes.
 * @param {string} modulePath The module, in the bm_checkoutcom cartridge
 * @param {Object} options orders (by number), balances (by payment id), gateway (records calls), csrf, method, params, searches
 * @returns {Object} The module
 */
function loadBm(modulePath, options = {}) {
    const calls = options.calls || { gateway: [], balances: [], searches: [], status: null, body: null };
    const params = options.params || {};
    const mod = load(modulePath, {
        cartridge: 'bm',
        preferences: { ckoMode: 'sandbox' },
        'dw/web/CSRFProtection': { validateRequest: () => options.csrf !== false },
        'dw/web/Resource': { msg: (key) => key },
        'dw/template/ISML': { renderTemplate() {} },
        'dw/order/PaymentTransaction': PAYMENT_TRANSACTION,
        'dw/order/PaymentMgr': { getPaymentMethod: () => ({ getPaymentProcessor: () => ({ getID: () => 'CHECKOUTCOM_FLOW' }) }) },
        'dw/order/OrderMgr': {
            getOrder: (orderNo) => (options.orders || {})[orderNo] || null,
            searchOrders: (query, sort, ...args) => {
                calls.searches.push({ query, args });

                return collection(options.searchResult || []);
            },
        },
        'dw/svc/LocalServiceRegistry': {
            createService: (serviceId, callbacks) => {
                if (serviceId.startsWith('cko.keys.')) {
                    return { getConfiguration: () => ({ getCredential: () => ({ getPassword: () => 'sk_sbox_test' }) }) };
                }

                // GET /payments/{id}: the payment's balances
                let url = 'https://api.sandbox.checkout.com/payments/{id}';
                const svc = {
                    getURL: () => url,
                    setURL: (value) => { url = value; },
                    setRequestMethod: (value) => { svc.method = value; },
                    addHeader() {},
                };

                return {
                    call: () => {
                        callbacks.createRequest(svc);
                        calls.balances.push({ serviceId, url, method: svc.method });
                        const id = decodeURIComponent(url.split('/').pop());
                        const balances = (options.balances || {})[id];

                        return { isOk: () => !!balances, getObject: () => (balances ? { id, balances } : null) };
                    },
                };
            },
        },
        '*/cartridge/scripts/services/transactionCapture': gatewayService('capture', calls),
        '*/cartridge/scripts/services/transactionRefund': gatewayService('refund', calls),
        '*/cartridge/scripts/services/transactionVoid': gatewayService('void', calls),
    });

    globalThis.request = {
        getHttpMethod: () => options.method || 'POST',
        httpQueryString: options.queryString || '',
        httpParameterMap: { get: (name) => ({ stringValue: params[name] === undefined ? null : String(params[name]), value: params[name] }) },
    };
    globalThis.response = {
        setStatus: (status) => { calls.status = status; },
        setContentType: (type) => { calls.contentType = type; },
        writer: { println: (text) => { calls.body = JSON.parse(text); } },
    };

    return Object.assign(mod, { calls });
}

function gatewayService(action, calls) {
    const make = () => {
        let url = `https://api.sandbox.checkout.com/payments/chargeId/${action === 'refund' ? 'refunds' : action === 'void' ? 'voids' : 'captures'}`;

        return {
            getURL: () => url,
            setURL: (value) => { url = value; },
            setRequestMethod() {},
            call: (body) => {
                calls.gateway.push({ action, url, body: JSON.parse(JSON.stringify(body)) });

                return { status: 'OK', object: { action_id: 'act_1' } };
            },
        };
    };

    return { sandbox: make, production: make };
}

const BALANCES = { pay_order1: { available_to_capture: 4500, available_to_refund: 2000, available_to_void: 4500 } };

test('console actions: the payment and currency come from the order, never from the request', () => {
    const order = makeOrder({ details: { cardType: 'Visa' } });
    const actions = loadBm('controllers/CKOTransactionActions', {
        orders: { '00000123': order },
        balances: BALANCES,
        params: { task: 'capture', orderNo: '00000123', amount: '45.00', pid: 'pay_someone_else', currency: 'JPY' },
    });

    actions.RemoteCall();

    assert.equal(actions.calls.gateway.length, 1);
    assert.equal(actions.calls.gateway[0].url, 'https://api.sandbox.checkout.com/payments/pay_order1/captures');
    assert.equal(actions.calls.gateway[0].body.amount, 4500);
    assert.equal(actions.calls.gateway[0].body.capture_type, 'NonFinal');
    // A whole-order capture of a card payment carries the Level 2 data
    assert.deepEqual(actions.calls.gateway[0].body.processing, { order_id: '00000123', tax_amount: 750, shipping_amount: 500 });
    assert.equal(actions.calls.body.action_id, 'act_1');
    assert.equal(actions.calls.contentType, 'application/json');
});

test('console actions: amounts must be plain decimals of at least one minor unit', () => {
    const order = makeOrder();

    ['5abc', '1,5', '1e-9', '0.001', ''].forEach((amount) => {
        const actions = loadBm('controllers/CKOTransactionActions', { orders: { '00000123': order }, balances: BALANCES, params: { task: 'refund', orderNo: '00000123', amount } });

        actions.RemoteCall();
        assert.equal(actions.calls.status, 400, amount);
        assert.equal(actions.calls.gateway.length, 0, amount);
    });
});

test('console actions: one dialog opening is one action at Checkout.com (idempotency key from its nonce)', () => {
    const order = makeOrder();
    const actions = loadBm('controllers/CKOTransactionActions', { orders: { '00000123': order }, balances: BALANCES, params: { task: 'refund', orderNo: '00000123', amount: '10.00', nonce: 'abc123def456' } });

    actions.RemoteCall();
    assert.equal(actions.calls.gateway[0].body.idempotencyKey, 'bm_00000123_refund_abc123def456');
});

test('console actions: amounts are capped at what Checkout.com still allows', () => {
    const order = makeOrder();
    const options = { orders: { '00000123': order }, balances: BALANCES };

    const refund = loadBm('controllers/CKOTransactionActions', { ...options, params: { task: 'refund', orderNo: '00000123', amount: '25.00' } });

    refund.RemoteCall();
    assert.equal(refund.calls.gateway.length, 0);
    assert.equal(refund.calls.status, 422);
    assert.deepEqual(refund.calls.body, { error: 'exceeds_available', limit: 2000 });

    const ok = loadBm('controllers/CKOTransactionActions', { ...options, params: { task: 'refund', orderNo: '00000123', amount: '20.00' } });

    ok.RemoteCall();
    assert.equal(ok.calls.gateway[0].body.amount, 2000);
    assert.equal(ok.calls.gateway[0].url, 'https://api.sandbox.checkout.com/payments/pay_order1/refunds');
});

test('console actions: a void needs an amount still available to void, and sends none', () => {
    const order = makeOrder();
    const blocked = loadBm('controllers/CKOTransactionActions', {
        orders: { '00000123': order },
        balances: { pay_order1: { available_to_capture: 0, available_to_refund: 4500, available_to_void: 0 } },
        params: { task: 'void', orderNo: '00000123' },
    });

    blocked.RemoteCall();
    assert.equal(blocked.calls.status, 422);
    assert.equal(blocked.calls.gateway.length, 0);

    const voided = loadBm('controllers/CKOTransactionActions', { orders: { '00000123': order }, balances: BALANCES, params: { task: 'void', orderNo: '00000123' } });

    voided.RemoteCall();
    assert.equal('amount' in voided.calls.gateway[0].body, false);
});

test('console actions: refused without POST, without the CSRF token, or for an unknown action, order or payment', () => {
    const order = makeOrder();
    const run = (options) => {
        const actions = loadBm('controllers/CKOTransactionActions', { orders: { '00000123': order, '00000999': makeOrder({ orderNo: '00000999', paymentId: null, instruments: [{ method: 'CHECKOUTCOM_FLOW', transactionId: null }] }) }, balances: BALANCES, ...options });

        actions.RemoteCall();

        return actions.calls;
    };
    const params = { task: 'capture', orderNo: '00000123', amount: '10' };

    assert.equal(run({ method: 'GET', params }).status, 403);
    assert.equal(run({ csrf: false, params }).status, 403);
    assert.equal(run({ params: { ...params, task: 'delete' } }).status, 400);
    assert.equal(run({ params: { ...params, orderNo: 'nope' } }).status, 404);
    assert.equal(run({ params: { ...params, orderNo: '00000999' } }).status, 409);
    assert.equal(run({ params: { ...params, amount: '-5' } }).status, 400);
    assert.equal(run({ params, balances: {} }).status, 502);
});

test('console actions: the payment id is encoded in the request URLs', () => {
    const helper = loadBm('scripts/helpers/CKOHelper', { balances: { 'pay_a/b': { available_to_capture: 1 } } });

    helper.getPaymentBalances('pay_a/b');
    assert.equal(helper.calls.balances[0].url, 'https://api.sandbox.checkout.com/payments/pay_a%2Fb');
    assert.equal(helper.calls.balances[0].method, 'GET');

    helper.getGatewayClient('cko.transaction.capture.sandbox.service', { chargeId: 'pay_a/b?x=1', amount: 1 });
    assert.equal(helper.calls.gateway[0].url, 'https://api.sandbox.checkout.com/payments/pay_a%2Fb%3Fx%3D1/captures');
});

test('transactions list: only Checkout.com orders, always paged, with a validated year range', () => {
    const helper = loadBm('scripts/helpers/CKOHelper', { queryString: 'year=2025-2027&page=2&size=500' });

    helper.getCkoOrders();
    assert.match(helper.calls.searches[0].query, /custom\.ckoPaymentId != NULL/);
    assert.equal(helper.calls.searches[0].args[0].getFullYear(), 2025);
    assert.equal(helper.calls.searches[0].args[1].getFullYear(), 2027);

    const invalid = loadBm('scripts/helpers/CKOHelper', { queryString: 'year=1900-x' });

    invalid.getCkoOrders();
    assert.equal(invalid.calls.searches[0].args[0].getFullYear(), new Date().getFullYear());

    const byPayment = loadBm('scripts/helpers/CKOHelper', { params: { tid: 'pay_order1' } });

    byPayment.getCkoOrders();
    assert.deepEqual(byPayment.calls.searches[0], { query: 'custom.ckoPaymentId = {0}', args: ['pay_order1'] });
});

test('transactions list: an order without a Checkout.com payment instrument is skipped, not fatal', () => {
    const empty = makeOrder({ orderNo: '00000001', instruments: [] });
    const paid = makeOrder({ orderNo: '00000002' });
    const helper = loadBm('scripts/helpers/CKOHelper', { searchResult: [empty, paid] });
    const result = helper.getCkoTransactions();

    assert.equal(result.data.length, 1);
    assert.equal(result.data[0].order_no, '00000002');
    assert.equal(result.data[0].transaction_id, 'pay_order1');
});

test('transactions list: a row shows the latest Checkout.com instrument (after a capture or void), not the authorization', () => {
    const order = makeOrder({
        orderNo: '00000003',
        instruments: [
            { method: 'CHECKOUTCOM_FLOW', transactionId: 'pay_order1', type: 'AUTH' },
            { method: 'CHECKOUTCOM_FLOW', transactionId: 'pay_order1', type: 'CAPTURE', amount: 45 },
        ],
    });
    const row = loadBm('scripts/helpers/CKOHelper', { searchResult: [order] }).getCkoTransactions().data[0];

    assert.equal(row.data_type, 'CAPTURE');
    assert.equal(row.captured_amount, '45.00');
});

test('refund logic: refundable is captured minus refunded; amounts in Checkout.com minor units', () => {
    const helper = loadBm('scripts/helpers/CKOHelper');
    const instrument = (type, amount) => ({ getPaymentTransaction: () => ({ type: { toString: () => type }, amount: { value: amount } }) });

    assert.equal(helper.getRefundableAmount([instrument('CAPTURE', 45), instrument('CREDIT', 10.5)]), '34.50');
    assert.equal(helper.getCapturedAmount([instrument('CAPTURE', 20), instrument('CAPTURE', 25), instrument('CREDIT', 5)]), '45.00');
    assert.equal(helper.getFormattedPrice('45.00', 'EUR'), '4500');
    assert.equal(helper.getFormattedPrice('4500', 'JPY'), '4500');
    assert.equal(helper.getFormattedPrice('1.234', 'KWD'), '1234');
});
