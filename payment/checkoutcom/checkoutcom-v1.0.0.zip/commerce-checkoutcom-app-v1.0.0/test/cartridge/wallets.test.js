'use strict';

/**
 * Express wallets (Google Pay; Apple Pay uses the same path): the storefront
 * creates the order, and the wallet transition endpoint pays it through the
 * onAttemptOrderTransition hook with POST /payments.
 */

const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const { load, makeContainer, customObjects, orderManager, ORDER, paymentPlatform } = require('./helpers/sfcc');

const GOOGLE_PAY = 'CHECKOUTCOM_GOOGLE_PAY';
const PREFS = {
    ckoMode: 'sandbox',
    ckoPublicKey: 'pk_sbox_test',
    ckoFlowAllowedReturnOrigins: 'https://shop.example',
    cko3ds: true,
    ckoGooglePayMerchantId: 'BCR2DN4T000000',
    ckoGooglePayButton: 'black',
};

let calls;
let objects;

beforeEach(() => {
    calls = { payments: [], voids: [], refunds: [], failed: [], placed: [] };
    objects = customObjects();
    globalThis.customer = { getID: () => 'cust-1', isRegistered: () => false };
});

const authorized = (overrides = {}) => ({ id: 'pay_g1', status: 'Authorized', amount: 4500, currency: 'GBP', reference: '00001', ...overrides });

/** A gateway fake: POST /payments answers with `response`; GET /payments/{id} with `payment`. */
function gateway(response, payment) {
    return {
        requestPayment: (body, orderNo) => {
            calls.payments.push({ body, orderNo });

            return response;
        },
        getPayment: () => (payment ? { ok: true, object: payment } : { ok: false }),
        voidPayment: (id) => { calls.voids.push(id); return { ok: true }; },
        refundPayment: (id) => { calls.refunds.push(id); return { ok: true }; },
    };
}

function checkout(order, response, payment, extra = {}) {
    return load('scripts/checkoutcom/checkout', {
        preferences: { ...PREFS, ...(extra.preferences || {}) },
        flowActive: extra.methodActive !== false,
        'dw/order/OrderMgr': orderManager({ '00001': order }, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': gateway(response, payment),
    });
}

const input = (overrides = {}) => ({
    orderNo: '00001',
    paymentMethodId: GOOGLE_PAY,
    token: 'tok_google',
    tokenFormat: 'cryptogram_3ds',
    successUrl: 'https://shop.example/cko-return',
    failureUrl: 'https://shop.example/cko-return?leg=failure',
    ...overrides,
});

const googlePayOrder = () => makeContainer({ orderNo: '00001', method: GOOGLE_PAY });
const transaction = (order) => order.instruments[0].getPaymentTransaction();

test('an approved Google Pay payment places the order, paid with the Checkout.com token for the order', () => {
    const order = googlePayOrder();
    const result = checkout(order, { ok: true, object: { id: 'pay_g1', status: 'Authorized', approved: true } }, authorized())
        .submitWalletPayment(input());

    assert.equal(result.status, 'complete');
    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(transaction(order).status, 'AUTHORIZED');
    assert.equal(transaction(order).getTransactionID(), 'pay_g1');

    const { body, orderNo } = calls.payments[0];

    assert.equal(orderNo, '00001');
    assert.deepEqual(body.source.type, 'token');
    assert.equal(body.source.token, 'tok_google');
    assert.equal(body.reference, '00001');
    assert.equal(body.amount, 4500);
    assert.equal(body.metadata.payment_processor, GOOGLE_PAY);
    assert.equal(body.processing.order_id, '00001');
    // A device token is already authenticated: no 3DS
    assert.equal('3ds' in body, false);
});

test('a card stored in the Google account (pan_only) goes through 3D Secure: pending, with the redirect', () => {
    const order = googlePayOrder();
    const service = checkout(order, {
        ok: true,
        object: { id: 'pay_g1', status: 'Pending', _links: { redirect: { href: 'https://3ds.example/challenge' } } },
    }, authorized());
    const result = service.submitWalletPayment(input({ tokenFormat: 'pan_only' }));

    assert.equal(result.status, 'pending');
    assert.equal(result.redirectUrl, 'https://3ds.example/challenge');
    assert.equal(order.status, ORDER.ORDER_STATUS_CREATED);
    assert.equal(transaction(order).status, 'PENDING');
    assert.equal(calls.payments[0].body['3ds'].enabled, true);
    assert.equal(calls.payments[0].body.success_url, 'https://shop.example/cko-return');

    // The shopper completes 3DS and comes back through /cko-return
    const completed = service.completePayment({ paymentId: 'pay_g1', orderNo: '00001' });

    assert.equal(completed.status, 'complete');
    assert.deepEqual(calls.placed, ['00001']);
});

test('pan_only without 3D Secure switched on is paid without 3DS', () => {
    const order = googlePayOrder();

    checkout(order, { ok: true, object: { id: 'pay_g1', status: 'Authorized', approved: true } }, authorized(), { preferences: { cko3ds: false } })
        .submitWalletPayment(input({ tokenFormat: 'pan_only' }));

    assert.equal('3ds' in calls.payments[0].body, false);
});

test('an Apple Pay payment carries the return URLs (the express button\'s page) without asking for 3D Secure', () => {
    const order = makeContainer({ orderNo: '00001', method: 'CHECKOUTCOM_APPLE_PAY' });
    const page = 'https://shop.example/cko-return?page=%2Fen-US%2Fproduct%2Fabc';

    checkout(order, { ok: true, object: { id: 'pay_a1', status: 'Authorized', approved: true } }, authorized())
        .submitWalletPayment(input({ paymentMethodId: 'CHECKOUTCOM_APPLE_PAY', token: 'tok_apple', tokenFormat: null, successUrl: page, failureUrl: `${page}&leg=failure` }));

    assert.equal('3ds' in calls.payments[0].body, false);
    assert.equal(calls.payments[0].body.success_url, page);
    assert.equal(calls.payments[0].body.failure_url, `${page}&leg=failure`);
});

test('an Apple Pay payment that still needs a redirect (issuer 3D Secure) is pending with it, like Google Pay', () => {
    const order = makeContainer({ orderNo: '00001', method: 'CHECKOUTCOM_APPLE_PAY' });
    const result = checkout(order, {
        ok: true,
        object: { id: 'pay_a1', status: 'Pending', _links: { redirect: { href: 'https://3ds.example/challenge' } } },
    }, authorized()).submitWalletPayment(input({ paymentMethodId: 'CHECKOUTCOM_APPLE_PAY', token: 'tok_apple', tokenFormat: null }));

    assert.equal(result.status, 'pending');
    assert.equal(result.redirectUrl, 'https://3ds.example/challenge');
});

test('a declined Google Pay payment fails the order (basket reopened), with nothing to reverse', () => {
    const order = googlePayOrder();
    const result = checkout(order, { ok: true, object: { id: 'pay_g1', status: 'Declined', approved: false } }, authorized({ status: 'Declined' }))
        .submitWalletPayment(input());

    assert.equal(result.status, 'failed');
    assert.deepEqual(calls.failed, ['00001']);
    assert.deepEqual(calls.voids, []);
});

test('a refused request fails the order; an unknown outcome keeps it open for the release lookup', () => {
    const refused = googlePayOrder();

    assert.equal(checkout(refused, { ok: false, rejected: true, errorMessage: 'HTTP 422' }).submitWalletPayment(input()).status, 'failed');
    assert.deepEqual(calls.failed, ['00001']);

    calls.failed = [];
    objects = customObjects();

    const unknown = googlePayOrder();
    const result = checkout(unknown, { ok: false, rejected: false, errorMessage: 'timeout' }).submitWalletPayment(input());

    assert.equal(result.status, 'unverified');
    assert.deepEqual(calls.failed, []);
    assert.equal(unknown.status, ORDER.ORDER_STATUS_CREATED);
});

test('one payment per order: a second wallet payment is refused without calling Checkout.com', () => {
    const order = googlePayOrder();
    const service = checkout(order, { ok: false, rejected: false, errorMessage: 'timeout' });

    service.submitWalletPayment(input());

    const again = service.submitWalletPayment(input({ token: 'tok_other' }));

    assert.equal(again.ok, false);
    assert.equal(calls.payments.length, 1);
});

test('refused: an order paid with another method, Flow as the method, a method switched off, a foreign return URL', () => {
    const flowOrder = makeContainer({ orderNo: '00001' });

    assert.equal(checkout(flowOrder, null).submitWalletPayment(input()).ok, false);
    assert.equal(checkout(googlePayOrder(), null).submitWalletPayment(input({ paymentMethodId: 'CHECKOUTCOM_FLOW' })).ok, false);
    assert.equal(checkout(googlePayOrder(), null, null, { methodActive: false }).submitWalletPayment(input()).ok, false);
    assert.equal(checkout(googlePayOrder(), null).submitWalletPayment(input({ successUrl: 'https://evil.example/r' })).ok, false);
    assert.equal(calls.payments.length, 0);
});

test('another shopper\'s order is never paid', () => {
    const order = makeContainer({ orderNo: '00001', method: GOOGLE_PAY, customerId: 'someone-else' });

    assert.equal(checkout(order, null).submitWalletPayment(input()).ok, false);
    assert.equal(calls.payments.length, 0);
});

test('a wallet order\'s ledger entries keep its method, so the console and reports see Google Pay', () => {
    const order = googlePayOrder();

    load('scripts/checkoutcom/ledger').recordAction(order, 'Refund', { id: 'pay_g1', action_id: 'act_r1', amount: 4500, currency: 'GBP' });

    assert.equal(order.instruments[1].getPaymentMethod(), GOOGLE_PAY);
});

test('wallet config: Google Pay switch, merchant id, button colour, environment; no secret', () => {
    const config = checkout(googlePayOrder(), null).getWalletConfig();

    assert.deepEqual(config.googlePay, { enabled: true, merchantId: 'BCR2DN4T000000', buttonColor: 'black' });
    assert.equal(config.merchantName, 'Test Site');
    assert.equal(config.environment, 'sandbox');
    assert.equal(config.publicKey, 'pk_sbox_test');
    assert.equal(JSON.stringify(config).includes('sk_'), false);
});

test('the 3DS return of a wallet payment carries cko-session-id: it completes the order on its own, found through the payment', () => {
    const order = googlePayOrder();
    const looked = [];
    const service = load('scripts/checkoutcom/checkout', {
        preferences: PREFS,
        'dw/order/OrderMgr': orderManager({ '00001': order }, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': {
            requestPayment: () => ({ ok: true, object: { id: 'pay_g1', status: 'Pending', _links: { redirect: { href: 'https://3ds.example' } } } }),
            // GET /payments/{id} accepts the session id the return URL carries
            getPayment: (id) => {
                looked.push(id);

                return { ok: true, object: authorized() };
            },
        },
    });

    service.submitWalletPayment(input({ tokenFormat: 'pan_only' }));

    // No order number on the return: the payment's binding finds it
    const result = service.completePayment({ paymentId: 'sid_g1' });

    assert.equal(result.status, 'complete');
    assert.equal(result.orderNo, '00001');
    assert.deepEqual(calls.placed, ['00001']);
    assert.ok(looked.includes('sid_g1'));
});
