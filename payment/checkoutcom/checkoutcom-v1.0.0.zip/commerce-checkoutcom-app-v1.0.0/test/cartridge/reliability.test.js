'use strict';

/**
 * Money safety when things go wrong: one payment attempt per order, unknown
 * submission outcomes, concurrent completions, duplicate payments, wallet
 * completions that must be retryable, and webhooks that arrive early.
 */

const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const { load, makeContainer, customObjects, orderManager, ORDER, paymentPlatform } = require('./helpers/sfcc');

const KEYS = { ckoMode: 'sandbox', ckoPublicKey: 'pk_sbox_test' };

let calls;
let objects;

beforeEach(() => {
    calls = { voids: [], refunds: [], failed: [], placed: [], submitted: [], lists: [] };
    objects = customObjects();
    globalThis.customer = { getID: () => 'cust-1', isRegistered: () => false };
});

const approved = (overrides = {}) => ({ id: 'pay_1', status: 'Authorized', amount: 4500, currency: 'GBP', reference: '00001', ...overrides });

/** A gateway fake; payments by id, submit and list behaviour configurable. */
function gateway({ payments = {}, submit, list, getFails } = {}) {
    return {
        getPayment: (id) => (getFails ? { ok: false, errorMessage: 'timeout' } : payments[id] ? { ok: true, object: payments[id] } : { ok: false, rejected: true }),
        listPayments: (reference) => {
            calls.lists.push(reference);

            return list || { ok: true, object: { data: [] } };
        },
        submitPaymentSession: (id, body) => {
            calls.submitted.push({ id, body });

            return submit || { ok: true, object: { id: 'pay_1', status: 'Authorized' } };
        },
        voidPayment: (id) => { calls.voids.push(id); return { ok: true }; },
        refundPayment: (id) => { calls.refunds.push(id); return { ok: true }; },
    };
}

function orderMgr(ordersByNo, extra = {}) {
    return orderManager(ordersByNo, {
        ...paymentPlatform(calls),
        ...extra,
    });
}

function checkout(ordersByNo, gatewayOptions, orderMgrExtra) {
    return load('scripts/checkoutcom/checkout', {
        preferences: KEYS,
        'dw/order/OrderMgr': orderMgr(ordersByNo, orderMgrExtra),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': gateway(gatewayOptions),
    });
}

const submitInput = (sessionId = 'ps_1') => ({ sessionId, sessionData: 'sd_1', orderNo: '00001' });

// One payment attempt per order

test('submit: an order gets one payment attempt; a second session is refused without calling Checkout.com', () => {
    const order = makeContainer({ orderNo: '00001' });
    const service = checkout({ '00001': order });

    assert.equal(service.submitPayment(submitInput('ps_1')).ok, true);
    assert.equal(service.submitPayment(submitInput('ps_2')).ok, false);
    assert.equal(calls.submitted.length, 1);

    const attempt = objects.getCustomObject('ckoPayment', 'attempt_00001');

    assert.equal(attempt.custom.attemptState, 'submitted');
    assert.equal(attempt.custom.attemptPaymentId, 'pay_1');
    assert.equal(attempt.custom.orderToken, 'token-00001');
});

test('submit: a timeout leaves the outcome unknown, and the attempt stays reserved', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = checkout({ '00001': order }, { submit: { ok: false, rejected: false, errorMessage: 'timeout' } }).submitPayment(submitInput());

    assert.equal(result.ok, false);
    assert.equal(objects.getCustomObject('ckoPayment', 'attempt_00001').custom.attemptState, 'unknown');
    assert.deepEqual(calls.failed, []);
});

// Releasing an order

test('release: an unknown submission that Checkout.com did take completes the order instead of failing it', () => {
    const order = makeContainer({ orderNo: '00001' });
    const payment = approved({ id: 'pay_9' });
    const service = checkout({ '00001': order }, {
        submit: { ok: false, rejected: false, errorMessage: 'timeout' },
        list: { ok: true, object: { data: [{ id: 'pay_9', status: 'Authorized', reference: '00001' }] } },
        payments: { pay_9: payment },
    });

    service.submitPayment(submitInput());
    const result = service.releaseOrder({ orderNo: '00001' });

    assert.equal(result.status, 'complete');
    assert.deepEqual(calls.lists, ['00001']);
    assert.deepEqual(calls.placed, ['00001']);
    assert.deepEqual(calls.failed, []);
});

test('release: a submission Checkout.com refused fails the order, without a lookup', () => {
    const order = makeContainer({ orderNo: '00001' });
    const service = checkout({ '00001': order }, { submit: { ok: false, rejected: true, errorMessage: 'HTTP 422' } });

    service.submitPayment(submitInput());

    assert.equal(service.releaseOrder({ orderNo: '00001' }).status, 'failed');
    assert.deepEqual(calls.failed, ['00001']);
    assert.deepEqual(calls.lists, []);
});

test('release: when Checkout.com cannot be asked, the order stays open (unverified)', () => {
    const order = makeContainer({ orderNo: '00001' });
    const service = checkout({ '00001': order }, { submit: { ok: false, rejected: false }, list: { ok: false } });

    service.submitPayment(submitInput());

    assert.equal(service.releaseOrder({ orderNo: '00001' }).status, 'unverified');
    assert.deepEqual(calls.failed, []);
});

test('release: an order with no attempt is failed; a placed order is reported complete', () => {
    const open = makeContainer({ orderNo: '00001' });
    const placed = makeContainer({ orderNo: '00002', status: ORDER.ORDER_STATUS_NEW });
    const service = checkout({ '00001': open, '00002': placed });

    assert.equal(service.releaseOrder({ orderNo: '00001' }).status, 'failed');
    assert.equal(service.releaseOrder({ orderNo: '00002' }).status, 'complete');
    assert.deepEqual(calls.failed, ['00001']);
});

test('release: a submitted payment that was declined fails the order and is not reversed', () => {
    const order = makeContainer({ orderNo: '00001' });
    const service = checkout({ '00001': order }, { payments: { pay_1: approved({ status: 'Declined' }) } });

    service.submitPayment(submitInput());

    assert.equal(service.releaseOrder({ orderNo: '00001' }).status, 'failed');
    assert.deepEqual(calls.failed, ['00001']);
    assert.deepEqual(calls.voids, []);
});

// Concurrent completions

test('concurrency: a transition that loses to a concurrent request still running neither fails nor reverses', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = checkout({ '00001': order }, { payments: { pay_1: approved() } }, {
        attemptOrderTransition: () => { throw new Error('optimistic lock'); },
    }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'unverified');
    assert.deepEqual(calls.placed, []);
    assert.deepEqual(calls.failed, []);
    assert.deepEqual(calls.voids, []);
});

test('concurrency: a completion that loses to a request that placed the order with this payment reports it complete', () => {
    const order = makeContainer({ orderNo: '00001' });
    const winner = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });

    winner.custom.ckoPaymentId = 'pay_1';
    objects.createCustomObject('ckoPayment', 'placed_00001');

    const ordersByNo = { '00001': order };
    const result = checkout(ordersByNo, { payments: { pay_1: approved() } }, {
        // The shopper's request still holds the CREATED order; a reload sees the winner's
        getOrder: (no, token) => (token === undefined ? ordersByNo[no] : winner),
    }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'complete');
    assert.deepEqual(calls.failed, []);
    assert.deepEqual(calls.voids, []);
});

test('a transition the platform fails (inventory, fraud) reverses the payment through the reversePayment hook', () => {
    const order = makeContainer({ orderNo: '00001' });
    let platform;

    platform = paymentPlatform(calls);

    const result = checkout({ '00001': order }, { payments: { pay_1: approved() } }, {
        attemptOrderTransition: (o) => {
            platform.failOrder(o);

            return { isError: () => true, isFinal: () => true, getStep: () => 'place', getReason: () => 'inventory' };
        },
    }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'failed');
    assert.deepEqual(calls.failed, ['00001']);
    assert.deepEqual(calls.voids, ['pay_1']);
    assert.equal(order.instruments[0].getPaymentTransaction().status, 'AUTHORIZATIONVOIDED');
});

// Duplicate payments

test('a second payment for an order already paid is reversed, and the order is still complete', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });

    order.custom.ckoPaymentId = 'pay_1';

    const result = checkout({ '00001': order }, { payments: { pay_2: approved({ id: 'pay_2', status: 'Captured' }) } })
        .completePayment({ paymentId: 'pay_2', orderNo: '00001' });

    assert.equal(result.status, 'complete');
    assert.deepEqual(calls.refunds, ['pay_2']);
});

test('a payment bound to another order is never reversed for this one', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const binding = objects.createCustomObject('ckoPayment', 'pay_2');

    order.custom.ckoPaymentId = 'pay_1';
    binding.custom.orderNo = '00099';

    const result = checkout({ '00001': order }, { payments: { pay_2: approved({ id: 'pay_2' }) } })
        .completePayment({ paymentId: 'pay_2', orderNo: '00001' });

    assert.equal(result.ok, false);
    assert.deepEqual(calls.voids, []);
    assert.deepEqual(calls.refunds, []);
});

// Wallet completions

test('wallet: the payment is bound to the order it is completed with, so a retry without the order number finds it', () => {
    const order = makeContainer({ orderNo: '00007', uuid: 'basket-7' });
    const payment = approved({ id: 'pay_w', reference: 'basket-7', metadata: { basket_id: 'basket-7', sfcc_customer_id: 'cust-1' } });
    const ordersByNo = { '00007': order };
    let placementFails = true;
    const service = checkout(ordersByNo, { payments: { pay_w: payment } }, {
        placeOrder: (o) => {
            if (placementFails) {
                throw new Error('lost response');
            }
            calls.placed.push(o.getOrderNo());
            o.status = ORDER.ORDER_STATUS_NEW;

            return { isError: () => false };
        },
    });

    assert.equal(service.completePayment({ paymentId: 'pay_w' }).status, 'no_order');

    // The first completion binds the payment before it fails
    service.completePayment({ paymentId: 'pay_w', orderNo: '00007', basketId: 'basket-7' });
    assert.equal(objects.getCustomObject('ckoPayment', 'pay_w').custom.orderNo, '00007');
});

test('verification: when the payment cannot be fetched the result is unverified, never failed', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = checkout({ '00001': order }, { getFails: true }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(result.status, 'unverified');
    assert.deepEqual(calls.failed, []);
});

// Webhooks that arrive early

function webhooks(ordersByNo, gatewayOptions) {
    return load('scripts/checkoutcom/webhooks', {
        preferences: KEYS,
        'dw/order/OrderMgr': orderMgr(ordersByNo),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': gateway(gatewayOptions),
        'dw/crypto/Mac': class {},
        'dw/crypto/Encoding': {},
    });
}

test('webhook: an event for one of our payments with no order yet asks for a retry; other events are let go', () => {
    const service = webhooks({});
    const ours = { metadata: { integration: 'sfcc_storefront_next' } };

    assert.equal(service.handleEvent({ id: 'e1', type: 'payment_captured', created_on: new Date().toISOString(), data: { id: 'pay_w', reference: 'basket-7', ...ours } }), 'retry');
    assert.equal(service.handleEvent({ id: 'e2', type: 'payment_captured', created_on: '2020-01-01T00:00:00Z', data: { id: 'pay_w', reference: 'basket-7', ...ours } }), 'ignored');
    assert.equal(service.handleEvent({ id: 'e3', type: 'payment_captured', data: { id: 'pay_x', reference: 'other' } }), 'ignored');
});

test('webhook: a payment that arrives before its binding reaches the order through the attempt, and places it', () => {
    const order = makeContainer({ orderNo: '00001' });
    const attempt = objects.createCustomObject('ckoPayment', 'attempt_00001');

    attempt.custom.orderNo = '00001';
    attempt.custom.orderToken = 'token-00001';

    const outcome = webhooks({ '00001': order }, { payments: { pay_1: approved({ status: 'Captured', balances: { total_captured: 4500 } }) } })
        .handleEvent({ id: 'e1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_1', reference: '00001', amount: 4500 } });

    assert.equal(outcome, 'applied');
    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(objects.getCustomObject('ckoPayment', 'pay_1').custom.orderNo, '00001');
});

test('webhook: a late payment for an order that was already failed is reversed', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_FAILED });
    const attempt = objects.createCustomObject('ckoPayment', 'attempt_00001');

    attempt.custom.orderNo = '00001';
    attempt.custom.orderToken = 'token-00001';

    webhooks({ '00001': order }, { payments: { pay_1: approved() } })
        .handleEvent({ id: 'e1', type: 'payment_approved', data: { id: 'pay_1', reference: '00001' } });

    assert.deepEqual(calls.voids, ['pay_1']);
    assert.deepEqual(calls.placed, []);
});
