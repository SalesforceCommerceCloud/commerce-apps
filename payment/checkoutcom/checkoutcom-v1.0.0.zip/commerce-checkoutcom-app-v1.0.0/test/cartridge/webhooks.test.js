'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const { load, makeContainer, customObjects, orderManager, ORDER, paymentPlatform } = require('./helpers/sfcc');

const KEY = 'psk_test';

/** dw.crypto fakes backed by node:crypto. */
const crypt = {
    'dw/crypto/Mac': class {
        static get HMAC_SHA_256() {
            return 'sha256';
        }

        digest(body, key) {
            return crypto.createHmac('sha256', key).update(body).digest();
        }
    },
    'dw/crypto/Encoding': { toHex: (bytes) => Buffer.from(bytes).toString('hex') },
};

/** Custom objects with pay_1 bound to the given order. */
function boundTo(order) {
    const objects = customObjects();
    const binding = objects.createCustomObject('ckoPayment', 'pay_1');

    binding.custom.orderNo = order.getOrderNo();
    binding.custom.orderToken = order.getOrderToken();

    return objects;
}

/** A gateway that confirms every action (balances well above any test amount). */
const confirmingGateway = {
    getPayment: (id) => ({ ok: true, object: { id, status: 'Captured', balances: { total_captured: 1e9, total_refunded: 1e9, total_voided: 1e9 } } }),
};

function webhooks(extra = {}) {
    return load('scripts/checkoutcom/webhooks', {
        '*/cartridge/scripts/checkoutcom/gateway': confirmingGateway,
        preferences: { ckoMode: 'sandbox' },
        credentials: { 'cko.webhook.service': KEY },
        ...crypt,
        ...extra,
    });
}

test('accepts a valid Cko-Signature and rejects a tampered body', () => {
    const body = '{"id":"evt_1","type":"payment_captured"}';
    const signature = crypto.createHmac('sha256', KEY).update(body).digest('hex');
    const service = webhooks();

    assert.equal(service.isAuthentic(body, signature, null), true);
    assert.equal(service.isAuthentic(body.replace('captured', 'refunded'), signature, null), false);
});

test('only an HMAC signature authenticates: the shared key sent as a header is refused', () => {
    const service = webhooks();

    assert.equal(service.isAuthentic('{}', null, KEY), false);
    assert.equal(service.isAuthentic('{}', null), false);
});

test('a capture webhook appends a capture and marks the order paid', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': boundTo(order) });

    order.instruments[0].getPaymentTransaction().custom.ckoTransactionType = 'Authorization';
    order.instruments[0].getPaymentTransaction().custom.ckoTransactionOpened = true;

    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', reference: '00001', amount: 4500, currency: 'GBP' } });

    assert.equal(order.instruments.length, 2);
    assert.equal(order.instruments[1].getPaymentTransaction().custom.ckoTransactionType, 'Capture');
    assert.equal(order.instruments[0].getPaymentTransaction().custom.ckoTransactionOpened, false);
    assert.equal(order.paymentStatus, ORDER.PAYMENT_STATUS_PAID);
});

test('a full refund closes the capture and leaves the order unpaid', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': boundTo(order) });

    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', reference: '00001', amount: 4500, currency: 'GBP' } });
    service.handleEvent({ id: 'evt_2', type: 'payment_refunded', data: { id: 'pay_1', reference: '00001', amount: 4500, currency: 'GBP' } });

    const capture = order.instruments.find((i) => i.getPaymentTransaction().custom.ckoTransactionType === 'Capture');

    assert.equal(capture.getPaymentTransaction().custom.ckoTransactionOpened, false);
    assert.equal(order.paymentStatus, ORDER.PAYMENT_STATUS_NOTPAID);
});

test('a declined webhook fails an order still waiting for payment', () => {
    const order = makeContainer({ orderNo: '00001' });
    const failed = [];
    const service = webhooks({
        'dw/order/OrderMgr': orderManager({ '00001': order }, { failOrder: (o) => failed.push(o.getOrderNo()) }),
        'dw/object/CustomObjectMgr': boundTo(order),
    });

    service.handleEvent({ id: 'evt_1', type: 'payment_declined', data: { id: 'pay_1', reference: '00001' } });

    assert.deepEqual(failed, ['00001']);
});

test('an event without an order is acknowledged without changes', () => {
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({}), 'dw/object/CustomObjectMgr': customObjects() });

    assert.doesNotThrow(() => service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_x', reference: 'nope' } }));
});

test('webhooks reach an order only through its binding: the order number alone is not enough', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': customObjects() });

    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', reference: '00001', amount: 4500, currency: 'GBP' } });

    assert.equal(order.instruments.length, 1);
    assert.deepEqual(order.notes, []);
});

test('auto captured payment: the payment_captured webhook completes the capture recorded at placement instead of adding one', () => {
    const ledgerOrder = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const ledger = load('scripts/checkoutcom/ledger');

    ledger.recordPayment(ledgerOrder, { id: 'pay_1', status: 'Captured', amount: 4500, currency: 'GBP' });

    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': ledgerOrder }), 'dw/object/CustomObjectMgr': boundTo(ledgerOrder) });

    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_1', reference: '00001', amount: 4500, currency: 'GBP' } });

    const captures = ledgerOrder.instruments.filter((i) => i.getPaymentTransaction().custom.ckoTransactionType === 'Capture');

    assert.equal(captures.length, 1);
    assert.equal(captures[0].getPaymentTransaction().custom.ckoActionId, 'act_1');
    assert.equal(captures[0].getPaymentTransaction().getAmount().getValue(), 45);
});

test('an action already in the ledger is not recorded again (repeated delivery under a new event id)', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': boundTo(order) });
    const refund = { id: 'pay_1', action_id: 'act_r1', reference: '00001', amount: 1000, currency: 'GBP' };

    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_c1', reference: '00001', amount: 4500, currency: 'GBP' } });
    service.handleEvent({ id: 'evt_2', type: 'payment_refunded', data: refund });
    service.handleEvent({ id: 'evt_3', type: 'payment_refunded', data: refund });

    const types = order.instruments.map((i) => i.getPaymentTransaction().custom.ckoTransactionType).filter(Boolean);

    assert.deepEqual(types.filter((t) => t === 'Capture').length, 1);
    assert.deepEqual(types.filter((t) => t === 'Refund').length, 1);
});

test('race: the capture webhook arrives before completion: it places the order, and completion adds no second capture', () => {
    const order = makeContainer({ orderNo: '00001' });
    const calls = { placed: [], failed: [] };
    const captured = { id: 'pay_1', status: 'Captured', amount: 4500, currency: 'GBP', reference: '00001', balances: { total_captured: 4500 } };
    const service = webhooks({
        '*/cartridge/scripts/checkoutcom/gateway': { getPayment: () => ({ ok: true, object: captured }) },
        'dw/order/OrderMgr': orderManager({ '00001': order }, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': boundTo(order),
    });

    globalThis.customer = { getID: () => 'cust-1' };

    // 1. webhook first: the order is bound (at submission) and still waits for its payment
    order.instruments[0].getPaymentTransaction().setStatus('PENDING');
    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_1', reference: '00001', amount: 4500, currency: 'GBP' } });

    // 2. then completion, with the payment already Captured
    load('scripts/checkoutcom/ledger').recordPayment(order, captured);

    const transactions = order.instruments.map((i) => i.getPaymentTransaction());
    const captures = transactions.filter((t) => t.custom.ckoTransactionType === 'Capture');

    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(captures.length, 1);
    assert.equal(captures[0].custom.ckoActionId, 'act_1');
    assert.equal(order.paymentStatus, ORDER.PAYMENT_STATUS_PAID);
});

test('completion removes an empty duplicate payment instrument copied from the basket', () => {
    const order = makeContainer({ orderNo: '00001', instruments: 2 });

    load('scripts/checkoutcom/ledger').recordPayment(order, { id: 'pay_1', status: 'Authorized', amount: 4500, currency: 'GBP' });

    assert.equal(order.instruments.length, 1);
    assert.equal(order.instruments[0].getPaymentTransaction().getTransactionID(), 'pay_1');
});

test('transaction statuses follow the lifecycle: capture, then full refund', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': boundTo(order) });
    const authorization = order.instruments[0].getPaymentTransaction();

    authorization.custom.ckoTransactionType = 'Authorization';
    authorization.custom.ckoTransactionOpened = true;

    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_c', reference: '00001', amount: 4500, currency: 'GBP' } });
    assert.equal(authorization.status, 'CAPTURED');
    assert.equal(order.instruments[1].getPaymentTransaction().status, 'CAPTURED');

    service.handleEvent({ id: 'evt_2', type: 'payment_refunded', data: { id: 'pay_1', action_id: 'act_r', reference: '00001', amount: 4500, currency: 'GBP' } });
    assert.equal(order.instruments[2].getPaymentTransaction().status, 'CAPTUREVOIDED');
    assert.equal(order.instruments[1].getPaymentTransaction().status, 'CAPTUREVOIDED');
});

test('a void sets the authorization to voided', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': boundTo(order) });
    const authorization = order.instruments[0].getPaymentTransaction();

    authorization.custom.ckoTransactionType = 'Authorization';

    service.handleEvent({ id: 'evt_1', type: 'payment_voided', data: { id: 'pay_1', action_id: 'act_v', reference: '00001', amount: 4500, currency: 'GBP' } });
    assert.equal(authorization.status, 'AUTHORIZATIONVOIDED');
});

test('webhook amounts use the Checkout.com format: a CLP capture of 10000 is CLP 100', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW, currency: 'CLP', lines: [{ id: 'P1', name: 'Shirt', qty: 1, total: 100 }], shipping: 0 });
    const service = webhooks({ 'dw/order/OrderMgr': orderManager({ '00001': order }), 'dw/object/CustomObjectMgr': boundTo(order) });

    order.instruments[0].getPaymentTransaction().custom.ckoTransactionType = 'Authorization';
    service.handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_c', reference: '00001', amount: 10000, currency: 'CLP' } });

    assert.equal(order.instruments[1].getPaymentTransaction().getAmount().getValue(), 100);
    assert.equal(order.paymentStatus, ORDER.PAYMENT_STATUS_PAID);
});

test('during a key rotation, a signature made with either key is accepted', () => {
    const service = webhooks({ credentials: { 'cko.webhook.service': 'old_key,new_key' } });
    const body = '{"id":"evt_1"}';
    const sign = (key) => crypto.createHmac('sha256', key).update(body).digest('hex');

    assert.equal(service.isAuthentic(body, sign('old_key')), true);
    assert.equal(service.isAuthentic(body, sign('new_key')), true);
    assert.equal(service.isAuthentic(body, sign('other_key')), false);
});

test('a forged capture, not confirmed by the payment balances, is never recorded', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const service = webhooks({
        'dw/order/OrderMgr': orderManager({ '00001': order }),
        'dw/object/CustomObjectMgr': boundTo(order),
        '*/cartridge/scripts/checkoutcom/gateway': { getPayment: (id) => ({ ok: true, object: { id, status: 'Authorized', balances: { total_captured: 0 } } }) },
    });

    order.instruments[0].getPaymentTransaction().custom.ckoTransactionType = 'Authorization';

    const outcome = service.handleEvent({ id: 'evt_forged', type: 'payment_captured', created_on: '2020-01-01T00:00:00Z', data: { id: 'pay_1', action_id: 'act_x', reference: '00001', amount: 4500, currency: 'GBP' } });

    assert.equal(outcome, 'ignored');
    assert.equal(order.instruments.length, 1);
    assert.equal(order.paymentStatus, ORDER.PAYMENT_STATUS_NOTPAID);
});

test('an order waiting for a pending payment is placed by its capture webhook, and failed if the payment expires', () => {
    const calls = { placed: [], failed: [] };
    const captured = { id: 'pay_1', status: 'Captured', amount: 4500, currency: 'GBP', reference: '00001', balances: { total_captured: 4500 } };
    const waiting = makeContainer({ orderNo: '00001' });

    globalThis.customer = { getID: () => 'cust-1' };
    waiting.exportStatus = ORDER.EXPORT_STATUS_NOTEXPORTED;
    waiting.instruments[0].getPaymentTransaction().setTransactionID('pay_1');
    waiting.instruments[0].getPaymentTransaction().setStatus('PENDING');
    webhooks({
        '*/cartridge/scripts/checkoutcom/gateway': { getPayment: () => ({ ok: true, object: captured }) },
        'dw/order/OrderMgr': orderManager({ '00001': waiting }, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': boundTo(waiting),
    }).handleEvent({ id: 'evt_1', type: 'payment_captured', data: { id: 'pay_1', action_id: 'act_c', reference: '00001', amount: 4500, currency: 'GBP' } });
    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(waiting.exportStatus, ORDER.EXPORT_STATUS_READY);

    const expired = makeContainer({ orderNo: '00001' });

    expired.instruments[0].getPaymentTransaction().setStatus('PENDING');
    webhooks({
        '*/cartridge/scripts/checkoutcom/gateway': { getPayment: () => ({ ok: true, object: { id: 'pay_1', status: 'Expired' } }) },
        'dw/order/OrderMgr': orderManager({ '00001': expired }, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': boundTo(expired),
    }).handleEvent({ id: 'evt_2', type: 'payment_expired', data: { id: 'pay_1', reference: '00001' } });
    assert.deepEqual(calls.failed, ['00001']);
    assert.equal(expired.status, ORDER.ORDER_STATUS_FAILED);
});

test('applyEvent: an event that lost a race with another order update is applied once more', () => {
    const webhooks = load('scripts/checkoutcom/webhooks');
    let calls = 0;

    webhooks.handleEvent = () => {
        calls += 1;

        if (calls === 1) {
            throw new Error('com.demandware.beehive.orm.capi.common.ORMOptimisticLockingException: Optimistic locking failure.');
        }

        return webhooks.OUTCOME.APPLIED;
    };

    assert.equal(webhooks.applyEvent({ id: 'evt_1', type: 'payment_captured' }), webhooks.OUTCOME.APPLIED);
    assert.equal(calls, 2);
});

test('applyEvent: still losing the race, it asks Checkout.com for a retry; other errors are not swallowed', () => {
    const webhooks = load('scripts/checkoutcom/webhooks');

    webhooks.handleEvent = () => {
        throw new Error('ORMOptimisticLockingException: Optimistic locking failure.');
    };
    assert.equal(webhooks.applyEvent({ id: 'evt_1', type: 'payment_captured' }), webhooks.OUTCOME.RETRY);

    webhooks.handleEvent = () => {
        throw new Error('something else');
    };
    assert.throws(() => webhooks.applyEvent({ id: 'evt_1', type: 'payment_captured' }), /something else/);
});
