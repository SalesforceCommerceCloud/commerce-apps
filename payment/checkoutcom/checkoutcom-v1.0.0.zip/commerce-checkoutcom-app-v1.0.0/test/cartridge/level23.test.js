'use strict';

/**
 * Visa and Mastercard Level 2 / Level 3 data (enhanced scheme data): sent when
 * the basket or order has the value, on the Flow session and submit request (so
 * payments captured at once carry it), on wallet payments, and on captures of
 * card payments. The item amounts never change, so they still add up.
 */

const { test } = require('node:test');
const assert = require('node:assert/strict');

const { load, makeContainer, makeScapiBasket } = require('./helpers/sfcc');

const options = { successUrl: 'https://shop.example/cko-return', failureUrl: 'https://shop.example/cko-return?leg=failure', locale: 'en-US' };

const sum = (items) => items.reduce((total, item) => total + item.total_amount, 0);

const wallet = { token: 'tok_1', tokenFormat: 'cryptogram_3ds', successUrl: options.successUrl, failureUrl: options.failureUrl };

test('session: processing.tax_amount and shipping_amount from the basket, and no order_id (no order yet)', () => {
    const request = load('scripts/checkoutcom/payload').buildSessionRequest(makeScapiBasket({ shippingTotal: 5, taxTotal: 8.5 }), options);

    assert.deepEqual(request.processing, { tax_amount: 850, shipping_amount: 500 });
});

test('session: a basket without tax or shipping values sends no processing', () => {
    const basket = makeScapiBasket();

    delete basket.taxTotal;
    delete basket.shippingTotal;

    assert.equal('processing' in load('scripts/checkoutcom/payload').buildSessionRequest(basket, options), false);
});

test('session, net taxation: product lines carry their tax; the tax line stays, so the items still add up', () => {
    const basket = makeScapiBasket({
        taxation: 'net',
        taxTotal: 9,
        items: [{ productId: 'P1', productName: 'Shirt', quantity: 2, priceAfterItemDiscount: 40, tax: 8, adjustedTax: 7.6 }],
    });
    const request = load('scripts/checkoutcom/payload').buildSessionRequest(basket, options);

    assert.equal(request.items[0].tax_amount, 760);
    assert.ok(request.items.some((item) => item.type === 'tax'));
    assert.equal(sum(request.items), request.amount);
});

test('submit, net taxation: product tax and the unit of measure, as on the session (the submitted items replace them)', () => {
    const order = makeContainer({ netTax: true, tax: 8, lines: [{ id: 'P1', name: 'Shirt', qty: 2, total: 40, tax: 8, unit: 'each' }] });
    const request = load('scripts/checkoutcom/payload', { taxPolicy: 1 }).buildSubmitRequest(order, 'sd_1');

    assert.equal(request.items[0].tax_amount, 800);
    assert.equal(request.items[0].unit_of_measure, 'EACH');
    // The submit request does not accept the Level 2 processing fields
    assert.equal('processing' in request, false);
    assert.equal(sum(request.items), request.amount);
});

test('wallet payment, net taxation: item tax, unit of measure and the Level 2 processing fields', () => {
    const order = makeContainer({ orderNo: '00000123', netTax: true, tax: 8, lines: [{ id: 'P1', name: 'Shirt', qty: 2, total: 40, tax: 8, unit: 'each' }] });
    const request = load('scripts/checkoutcom/payload', { taxPolicy: 1 }).buildWalletPaymentRequest(order, 'CHECKOUTCOM_APPLE_PAY', wallet);

    assert.equal(request.items[0].tax_amount, 800);
    assert.equal(request.items[0].unit_of_measure, 'EACH');
    assert.deepEqual(request.processing, { order_id: '00000123', tax_amount: 800, shipping_amount: 500 });
    assert.equal(sum(request.items), request.amount);
});

test('wallet payment, gross taxation: no item tax (it is inside the price); a unit that is not a measure code is left out', () => {
    const order = makeContainer({ lines: [{ id: 'P1', name: 'Shirt', qty: 2, total: 40, tax: 6.67, unit: 'Stück 2' }] });
    const item = load('scripts/checkoutcom/payload').buildWalletPaymentRequest(order, 'CHECKOUTCOM_GOOGLE_PAY', wallet).items[0];

    assert.equal('tax_amount' in item, false);
    assert.equal('unit_of_measure' in item, false);
});

test('card capture of the whole order: order_id, tax_amount, shipping_amount and the items', () => {
    const order = makeContainer({ orderNo: '00000123', tax: 7.5, lines: [{ id: 'P1', name: 'Shirt', qty: 2, total: 40, unit: 'EACH' }] });
    const request = load('scripts/checkoutcom/payload').buildCaptureRequest(order, 4500, true);

    assert.equal(request.amount, 4500);
    assert.deepEqual(request.processing, { order_id: '00000123', tax_amount: 750, shipping_amount: 500 });
    assert.equal(sum(request.items), 4500);
    assert.equal(request.items[0].unit_of_measure, 'EACH');
});

test('capture of a payment that is not a card (Klarna): only the amount and reference', () => {
    const order = makeContainer({ orderNo: '00000123', tax: 7.5, lines: [{ id: 'P1', name: 'Shirt', qty: 2, total: 40, unit: 'EACH' }] });
    const request = load('scripts/checkoutcom/payload').buildCaptureRequest(order, 4500, false);

    assert.deepEqual(request, { amount: 4500, reference: 'sfcc_order_00000123' });
});

test('partial card capture: only the order_id, since the order\'s tax, shipping and items would not be true for part of it', () => {
    const request = load('scripts/checkoutcom/payload').buildCaptureRequest(makeContainer({ orderNo: '00000123', tax: 7.5 }), 2000, true);

    assert.deepEqual(request.processing, { order_id: '00000123' });
    assert.equal('items' in request, false);
});

test('an order number longer than 15 characters is not sent as order_id', () => {
    const request = load('scripts/checkoutcom/payload').buildCaptureRequest(makeContainer({ orderNo: 'ORDER-0000000000001', tax: 7.5 }), 4500, true);

    assert.equal('order_id' in request.processing, false);
    assert.equal(request.processing.tax_amount, 750);
});

test('isCard: wallet payments are cards; a Flow payment is one only once it holds card details', () => {
    const details = load('scripts/checkoutcom/details');
    const instrument = (method, paymentDetails) => ({ getPaymentMethod: () => method, getPaymentDetails: () => paymentDetails });

    assert.equal(details.isCard(instrument('CHECKOUTCOM_APPLE_PAY', null)), true);
    assert.equal(details.isCard(instrument('CHECKOUTCOM_GOOGLE_PAY', null)), true);
    assert.equal(details.isCard(instrument('CHECKOUTCOM_FLOW', { cardType: 'Visa' })), true);
    assert.equal(details.isCard(instrument('CHECKOUTCOM_FLOW', null)), false);
    assert.equal(details.isCard(null), false);
});
