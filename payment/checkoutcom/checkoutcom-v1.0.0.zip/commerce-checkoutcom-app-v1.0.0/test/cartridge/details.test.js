'use strict';

/**
 * Typed payment details (Payment Commerce Apps): card details from the
 * payment's source, 3ds and eci; nothing for other payment methods or on
 * instances without the classes.
 */

const { test } = require('node:test');
const assert = require('node:assert/strict');

const { load, makeContainer, customObjects, orderManager, ORDER, paymentPlatform } = require('./helpers/sfcc');

/** Fakes of the dw.extensions.payments classes, recording what is set. */
function recorder(constants = {}) {
    const Class = function Details(type) {
        this.values = type === undefined ? {} : { type };
    };

    Object.assign(Class, constants);
    ['Brand', 'Last4', 'Bin', 'ExpirationMonth', 'ExpirationYear', 'FundingType', 'IssuingCountry', 'WalletType',
        'CvcResult', 'AvsResult', 'ThreeDSResult', 'ThreeDSVersion', 'ThreeDSTransactionId', 'ElectronicCommerceIndicator'].forEach((name) => {
        Class.prototype['set' + name] = function setter(value) { this.values[name] = value; };
    });

    return Class;
}

const CLASSES = {
    'dw/extensions/payments/SalesforceCardPaymentDetails': recorder({
        BRAND_VISA: 'visa', BRAND_MASTERCARD: 'mastercard', BRAND_AMEX: 'amex', BRAND_UNKNOWN: 'unknown',
        FUNDING_TYPE_CREDIT: 'CREDIT', FUNDING_TYPE_DEBIT: 'DEBIT', FUNDING_TYPE_PREPAID: 'PREPAID',
        WALLET_TYPE_APPLE_PAY: 'apple_pay', WALLET_TYPE_GOOGLE_PAY: 'google_pay',
    }),
    'dw/extensions/payments/SalesforceCardTransactionDetails': recorder({
        CVC_RESULT_MATCH: 'MATCH', CVC_RESULT_NO_MATCH: 'NO_MATCH', CVC_RESULT_NOT_PROCESSED: 'NOT_PROCESSED', CVC_RESULT_UNAVAILABLE: 'UNAVAILABLE',
        AVS_RESULT_MATCH: 'Y', AVS_RESULT_NO_MATCH: 'N', AVS_RESULT_PARTIAL_MATCH_ADDRESS: 'A', AVS_RESULT_PARTIAL_MATCH_ZIP: 'Z',
        AVS_RESULT_RETRY: 'R', AVS_RESULT_NOT_SUPPORTED: 'S', AVS_RESULT_UNAVAILABLE: 'U',
        THREE_DS_RESULT_AUTHENTICATED: 'AUTHENTICATED', THREE_DS_RESULT_ATTEMPTED: 'ATTEMPTED', THREE_DS_RESULT_FAILED: 'FAILED',
        THREE_DS_RESULT_REJECTED: 'REJECTED', THREE_DS_RESULT_UNAVAILABLE: 'UNAVAILABLE',
        THREE_DS_VERSION_V1: 'V1', THREE_DS_VERSION_V2: 'V2',
    }),
};

/** The card fields of a payment_approved webhook (Flow, 3DS challenge, sandbox test card). */
const cardPayment = (overrides = {}) => ({
    id: 'pay_1',
    status: 'Authorized',
    amount: 4500,
    currency: 'GBP',
    reference: '00001',
    eci: '05',
    '3ds': { version: '2.2.0', challenged: true, eci: '05', xid: 'ebda4467-cfa8-419c-a32d-888f5c1d47e4', authentication_response: 'Y' },
    source: {
        type: 'card', scheme: 'VISA', last_4: '4242', bin: '42424242', expiry_month: 10, expiry_year: 2029,
        card_type: 'CREDIT', issuer_country: 'GB', avs_check: 'I', cvv_check: 'P',
    },
    ...overrides,
});

const details = (extra = {}) => load('scripts/checkoutcom/details', { ...CLASSES, ...extra });

test('card: brand, last 4, BIN, expiry, funding type and issuing country on the instrument', () => {
    const instrument = makeContainer().instruments[0];

    assert.equal(details().apply(instrument, cardPayment()), true);
    assert.deepEqual(instrument.getPaymentDetails().values, {
        Brand: 'visa', Last4: '4242', Bin: '42424242', ExpirationMonth: 10, ExpirationYear: 2029, FundingType: 'CREDIT', IssuingCountry: 'GB',
    });
});

test('card: CVC, AVS and 3DS results on the transaction', () => {
    const instrument = makeContainer().instruments[0];

    details().apply(instrument, cardPayment());

    assert.deepEqual(instrument.getPaymentTransaction().getTransactionDetails().values, {
        CvcResult: 'NOT_PROCESSED',
        AvsResult: 'U',
        ThreeDSResult: 'AUTHENTICATED',
        ThreeDSVersion: 'V2',
        ThreeDSTransactionId: 'ebda4467-cfa8-419c-a32d-888f5c1d47e4',
        ElectronicCommerceIndicator: '05',
    });
});

test('card: an unknown scheme is BRAND_UNKNOWN; a card without 3DS gets no 3DS values', () => {
    const instrument = makeContainer().instruments[0];
    const payment = cardPayment({ '3ds': undefined, eci: undefined });

    payment.source.scheme = 'CARTES BANCAIRES';
    details().apply(instrument, payment);

    assert.equal(instrument.getPaymentDetails().values.Brand, 'unknown');
    assert.equal('ThreeDSResult' in instrument.getPaymentTransaction().getTransactionDetails().values, false);
});

test('other payment methods (iDEAL, PayPal, Multibanco…) get no details', () => {
    const service = details();

    ['ideal', 'paypal', 'klarna', 'multibanco'].forEach((type) => {
        const instrument = makeContainer().instruments[0];

        assert.equal(service.apply(instrument, { id: 'pay_1', source: { type } }), false);
        assert.equal(instrument.getPaymentDetails(), null);
        assert.equal(instrument.getPaymentTransaction().getTransactionDetails(), null);
    });
});

test('an instance without the classes, or a payment without a source, is left unchanged and nothing throws', () => {
    const instrument = makeContainer().instruments[0];

    assert.equal(load('scripts/checkoutcom/details').apply(instrument, cardPayment()), false);
    assert.equal(details().apply(instrument, { id: 'pay_1' }), false);
    assert.equal(instrument.getPaymentDetails(), null);
});

test('completion: the verified payment\'s card details are recorded with it', () => {
    const order = makeContainer({ orderNo: '00001' });
    const calls = { placed: [], failed: [] };

    globalThis.customer = { getID: () => 'cust-1', isRegistered: () => false };
    load('scripts/checkoutcom/checkout', {
        ...CLASSES,
        preferences: { ckoMode: 'sandbox' },
        'dw/order/OrderMgr': orderManager({ '00001': order }, paymentPlatform(calls)),
        'dw/object/CustomObjectMgr': customObjects(),
        '*/cartridge/scripts/checkoutcom/gateway': { getPayment: () => ({ ok: true, object: cardPayment() }) },
    }).completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(order.instruments[0].getPaymentDetails().values.Last4, '4242');
});

test('webhook: a signed payment_approved fills missing details on a placed order, and never replaces existing ones', () => {
    const order = makeContainer({ orderNo: '00001', status: ORDER.ORDER_STATUS_NEW });
    const objects = customObjects();
    const binding = objects.createCustomObject('ckoPayment', 'pay_1');

    binding.custom.orderNo = '00001';
    binding.custom.orderToken = order.getOrderToken();

    const service = load('scripts/checkoutcom/webhooks', {
        ...CLASSES,
        preferences: { ckoMode: 'sandbox' },
        'dw/order/OrderMgr': orderManager({ '00001': order }),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': { getPayment: () => ({ ok: true, object: cardPayment() }) },
    });

    service.handleEvent({ id: 'evt_1', type: 'payment_approved', data: cardPayment() });
    assert.equal(order.instruments[0].getPaymentDetails().values.Brand, 'visa');

    const second = cardPayment();

    second.source = { ...second.source, last_4: '0000' };
    service.handleEvent({ id: 'evt_2', type: 'payment_approved', data: second });
    assert.equal(order.instruments[0].getPaymentDetails().values.Last4, '4242');
});
