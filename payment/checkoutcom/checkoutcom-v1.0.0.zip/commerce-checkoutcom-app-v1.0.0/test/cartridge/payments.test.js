'use strict';

/**
 * The sfcc.app.payment.* hooks (Payment Commerce Apps, Beta) and the order
 * transition endpoint that drives them, against a fake of the platform that
 * behaves as the guide describes (helpers/sfcc.js paymentPlatform).
 */

const { test, beforeEach } = require('node:test');
const assert = require('node:assert/strict');

const { CARTRIDGE, load, makeContainer, customObjects, orderManager, ORDER, paymentPlatform } = require('./helpers/sfcc');

const KEYS = { ckoMode: 'sandbox', ckoPublicKey: 'pk_sbox_test' };

let calls;
let objects;

beforeEach(() => {
    calls = { voids: [], refunds: [], captures: [], failed: [], placed: [], submitted: [], lists: [] };
    objects = customObjects();
    globalThis.customer = { getID: () => 'cust-1', isRegistered: () => false };
});

const payment = (overrides = {}) => ({ id: 'pay_1', status: 'Authorized', amount: 4500, currency: 'GBP', reference: '00001', ...overrides });

/** A gateway fake: payments by id, a configurable submit response. */
function gateway({ payments = {}, submit } = {}) {
    return {
        getPayment: (id) => (payments[id] ? { ok: true, object: payments[id] } : { ok: false, rejected: true }),
        listPayments: (reference) => { calls.lists.push(reference); return { ok: true, object: { data: [] } }; },
        submitPaymentSession: (id, body) => {
            calls.submitted.push({ id, body });

            // A function answers each call in turn (its argument: the call's number, from 1)
            if (typeof submit === 'function') {
                return submit(calls.submitted.length, body);
            }

            return submit || { ok: true, object: { id: 'pay_1', status: 'Approved' } };
        },
        capturePayment: (id, request) => { calls.captures.push({ id, amount: request.amount, request }); return { ok: true }; },
        voidPayment: (id) => { calls.voids.push(id); return { ok: true }; },
        refundPayment: (id) => { calls.refunds.push(id); return { ok: true }; },
    };
}

function loadWith(modulePath, ordersByNo, gatewayOptions, orderMgrExtra = {}) {
    return load(modulePath, {
        preferences: KEYS,
        'dw/order/OrderMgr': orderManager(ordersByNo, { ...paymentPlatform(calls), ...orderMgrExtra }),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': gateway(gatewayOptions),
    });
}

const submitInput = { sessionId: 'ps_1', sessionData: 'sd_secret', orderNo: '00001' };
const transaction = (order, index = 0) => order.instruments[index].getPaymentTransaction();

test('the app claims Flow and the two express wallets', () => {
    assert.deepEqual(loadWith('scripts/checkoutcom/payments', {}).getClaimedPaymentMethods(), ['CHECKOUTCOM_FLOW', 'CHECKOUTCOM_APPLE_PAY', 'CHECKOUTCOM_GOOGLE_PAY']);
});

test('the hooks file exports every registered extension point, named after its last segment', () => {
    const hooks = require(require('path').join(CARTRIDGE, 'hooks.json')).hooks;

    loadWith('scripts/checkoutcom/payments', {});

    const exported = load('scripts/hooks/payment', { preferences: KEYS });

    hooks.forEach((hook) => {
        assert.equal(hook.script, './scripts/hooks/payment.js');
        assert.equal(typeof exported[hook.name.split('.').pop()], 'function', hook.name);
    });
});

test('transition: an approved submission is authorized in onAttemptOrderTransition and the order placed', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = loadWith('scripts/checkoutcom/checkout', { '00001': order }, { payments: { pay_1: payment() } }).submitPayment(submitInput);

    assert.equal(result.ok, true);
    assert.deepEqual(result.response, { id: 'pay_1', status: 'Approved' });
    assert.equal(calls.submitted[0].body.reference, '00001');
    assert.equal(calls.submitted[0].body.session_data, 'sd_secret');
    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(transaction(order).status, 'AUTHORIZED');
    assert.equal(transaction(order).getTransactionID(), 'pay_1');
    assert.equal(objects.getCustomObject('ckoPayment', 'pay_1').custom.orderNo, '00001');
});

test('transition: the session data is a payment credential and is never stored', () => {
    const order = makeContainer({ orderNo: '00001' });

    loadWith('scripts/checkoutcom/checkout', { '00001': order }, { payments: { pay_1: payment() } }).submitPayment(submitInput);

    const stored = JSON.stringify([order.custom, transaction(order).custom, objects.objects, globalThis.request.custom]);

    assert.equal(stored.includes('sd_secret'), false);
});

test('transition: 3DS (Action Required) leaves the order CREATED and PENDING; the completion places it', () => {
    const order = makeContainer({ orderNo: '00001' });
    const checkout = loadWith('scripts/checkoutcom/checkout', { '00001': order }, {
        payments: { pay_1: payment() },
        submit: { ok: true, object: { id: 'pay_1', status: 'Action Required', action: { type: 'redirect' } } },
    });
    const submitted = checkout.submitPayment(submitInput);

    assert.equal(submitted.response.status, 'Action Required');
    assert.equal(order.status, ORDER.ORDER_STATUS_CREATED);
    assert.equal(transaction(order).status, 'PENDING');

    // Flow ran 3DS and calls onPaymentCompleted
    const completed = checkout.completePayment({ paymentId: 'pay_1', orderNo: '00001' });

    assert.equal(completed.status, 'complete');
    assert.deepEqual(calls.placed, ['00001']);
    assert.equal(transaction(order).status, 'AUTHORIZED');
    assert.equal(calls.submitted.length, 1);
});

test('transition: a decline fails the order through the platform (basket reopened); Flow still gets the response', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = loadWith('scripts/checkoutcom/checkout', { '00001': order }, {
        payments: { pay_1: payment({ status: 'Declined' }) },
        submit: { ok: true, object: { id: 'pay_1', status: 'Declined' } },
    }).submitPayment(submitInput);

    assert.equal(result.response.status, 'Declined');
    assert.deepEqual(calls.failed, ['00001']);
    assert.deepEqual(calls.voids, []);
    assert.deepEqual(calls.refunds, []);
});

test('transition: a refused submission fails the order; an unknown outcome keeps it open for the release lookup', () => {
    const refused = makeContainer({ orderNo: '00001' });
    const refusedResult = loadWith('scripts/checkoutcom/checkout', { '00001': refused }, {
        submit: { ok: false, rejected: true, errorMessage: 'HTTP 422' },
    }).submitPayment(submitInput);

    assert.equal(refusedResult.ok, false);
    assert.deepEqual(calls.failed, ['00001']);
    assert.equal(objects.getCustomObject('ckoPayment', 'attempt_00001').custom.attemptState, 'rejected');

    calls.failed = [];
    objects = customObjects();

    const unknown = makeContainer({ orderNo: '00001' });
    const unknownResult = loadWith('scripts/checkoutcom/checkout', { '00001': unknown }, {
        submit: { ok: false, rejected: false, errorMessage: 'timeout' },
    }).submitPayment(submitInput);

    assert.equal(unknownResult.ok, false);
    assert.deepEqual(calls.failed, []);
    assert.equal(unknown.status, ORDER.ORDER_STATUS_CREATED);
    assert.equal(transaction(unknown).status, 'PENDING');
    assert.equal(objects.getCustomObject('ckoPayment', 'attempt_00001').custom.attemptState, 'unknown');
});

test('transition: a retried transition picks up the payment it has, and never submits a second one', () => {
    const order = makeContainer({ orderNo: '00001' });
    const hooks = loadWith('scripts/checkoutcom/payments', { '00001': order }, { payments: { pay_1: payment() } });

    order.custom.ckoPaymentId = 'pay_1';
    hooks.setScoped(hooks.SUBMISSION, { orderNo: '00001', sessionId: 'ps_2', sessionData: 'sd_2' });

    const status = hooks.onAttemptOrderTransition(order, order.instruments[0]);

    assert.equal(status.isError(), false);
    assert.equal(calls.submitted.length, 0);
    assert.equal(transaction(order).status, 'AUTHORIZED');
});

test('transition: refused when Payment Commerce Apps is not enabled, without calling Checkout.com', () => {
    const order = makeContainer({ orderNo: '00001' });
    const result = load('scripts/checkoutcom/checkout', {
        preferences: KEYS,
        'dw/order/OrderMgr': orderManager({ '00001': order }),
        'dw/object/CustomObjectMgr': objects,
        '*/cartridge/scripts/checkoutcom/gateway': gateway(),
    }).submitPayment(submitInput);

    assert.equal(result.ok, false);
    assert.match(result.errorMessage, /Payment Commerce Apps/);
    assert.equal(calls.submitted.length, 0);
});

test('reversePayment: voids an authorized payment, refunds a captured one, and does nothing twice', () => {
    const authorized = makeContainer({ orderNo: '00001' });

    transaction(authorized).setTransactionID('pay_1');

    let hooks = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_1: payment() } });

    assert.equal(hooks.reversePayment(authorized, authorized.instruments[0]).isError(), false);
    assert.deepEqual(calls.voids, ['pay_1']);
    assert.equal(transaction(authorized).status, 'AUTHORIZATIONVOIDED');

    const captured = makeContainer({ orderNo: '00002' });

    transaction(captured).setTransactionID('pay_2');
    hooks = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_2: payment({ id: 'pay_2', status: 'Captured', reference: '00002' }) } });
    hooks.reversePayment(captured, captured.instruments[0]);
    assert.deepEqual(calls.refunds, ['pay_2']);
    assert.equal(transaction(captured).status, 'CAPTUREVOIDED');

    // Already voided at Checkout.com (a rolled back failOrder that runs again): success, no call
    hooks = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_1: payment({ status: 'Voided' }) } });
    assert.equal(hooks.reversePayment(authorized, authorized.instruments[0]).isError(), false);
    assert.deepEqual(calls.voids, ['pay_1']);
});

test('reversePayment: nothing for an instrument that never reached Checkout.com, a ledger entry, or another order\'s payment', () => {
    const fresh = makeContainer({ orderNo: '00001' });
    const hooks = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_1: payment(), pay_9: payment({ id: 'pay_9', reference: '00009' }) } });

    assert.equal(hooks.reversePayment(fresh, fresh.instruments[0]).isError(), false);

    const ledgered = makeContainer({ orderNo: '00001', instruments: 2 });

    transaction(ledgered, 0).setTransactionID('pay_1');
    transaction(ledgered, 1).setTransactionID('pay_1');
    hooks.reversePayment(ledgered, ledgered.instruments[1]);

    // A payment id bound to another order is never released for this one
    const binding = objects.createCustomObject('ckoPayment', 'pay_9');

    binding.custom.orderNo = '00009';

    const foreign = makeContainer({ orderNo: '00001' });

    transaction(foreign).setTransactionID('pay_9');
    hooks.reversePayment(foreign, foreign.instruments[0]);

    assert.deepEqual(calls.voids, []);
    assert.deepEqual(calls.refunds, []);
});

test('utility hooks: capture, void and refund move the transaction status; the wrong state or instrument is refused', () => {
    const order = makeContainer({ orderNo: '00001' });
    const hooks = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_1: payment() } });

    transaction(order).setTransactionID('pay_1');
    transaction(order).setStatus('PENDING');
    assert.equal(hooks.capturePayment(order, order.instruments[0]).isError(), true);

    transaction(order).setStatus('AUTHORIZED');
    // A card payment (its card details are recorded): the order's Level 2 data rides on the capture
    order.instruments[0].getPaymentDetails = () => ({ cardType: 'Visa' });
    assert.equal(hooks.capturePayment(order, order.instruments[0]).isError(), false);
    assert.equal(calls.captures.length, 1);
    assert.equal(calls.captures[0].id, 'pay_1');
    assert.equal(calls.captures[0].amount, 4500);
    assert.equal(calls.captures[0].request.processing.order_id, '00001');
    assert.equal(transaction(order).status, 'CAPTURED');
    assert.equal(transaction(order).type, 'CAPTURE');

    assert.equal(hooks.cancelAuthorization(order, order.instruments[0]).isError(), true);
    assert.equal(hooks.refundCapture(order, order.instruments[0]).isError(), false);
    assert.deepEqual(calls.refunds, ['pay_1']);
    assert.equal(transaction(order).status, 'CAPTUREVOIDED');

    const voidable = makeContainer({ orderNo: '00001' });

    transaction(voidable).setTransactionID('pay_1');
    transaction(voidable).setStatus('AUTHORIZED');
    assert.equal(hooks.cancelAuthorization(voidable, voidable.instruments[0]).isError(), false);
    assert.equal(transaction(voidable).status, 'AUTHORIZATIONVOIDED');

    const other = { getPaymentMethod: () => 'CREDIT_CARD', getPaymentTransaction: () => transaction(voidable) };

    assert.equal(hooks.refundCapture(voidable, other).isError(), true);
    assert.equal(hooks.authorizePayment(order, order.instruments[0]).isError(), true);
});

test('basket hook: a second Flow instrument is refused, so the order total can match', () => {
    const basket = makeContainer({ instruments: 2 });
    const hooks = loadWith('scripts/checkoutcom/payments', {});

    assert.equal(hooks.afterCreateBasketPaymentInstrument(basket, basket.instruments[1]).isError(), true);
    const single = makeContainer();

    assert.equal(hooks.afterCreateBasketPaymentInstrument(single, single.instruments[0]).isError(), false);
});

test('order instrument PATCH (a redirect return): finishes a pending payment server-to-server', () => {
    const order = makeContainer({ orderNo: '00001' });
    const hooks = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_1: payment({ status: 'Captured' }) } });

    transaction(order).setTransactionID('pay_1');
    transaction(order).setStatus('PENDING');

    assert.equal(hooks.afterUpdateOrderPaymentInstrument(order, order.instruments[0]).isError(), false);
    assert.equal(transaction(order).status, 'CAPTURED');

    const declined = makeContainer({ orderNo: '00001' });
    const declining = loadWith('scripts/checkoutcom/payments', {}, { payments: { pay_1: payment({ status: 'Declined' }) } });

    transaction(declined).setTransactionID('pay_1');
    transaction(declined).setStatus('PENDING');
    assert.equal(declining.afterUpdateOrderPaymentInstrument(declined, declined.instruments[0]).isError(), true);
});

test('hooks file: an unexpected exception becomes Status.ERROR, and a failed claim claims nothing', () => {
    const failing = new Proxy({}, { get: () => () => { throw new Error('boom'); } });
    const hooks = load('scripts/hooks/payment', { preferences: KEYS, '*/cartridge/scripts/checkoutcom/payments': failing });

    assert.deepEqual(hooks.getClaimedPaymentMethods(), []);
    assert.equal(hooks.onAttemptOrderTransition({}, {}).isError(), true);
    assert.equal(hooks.reversePayment({}, {}).isError(), true);
});

test('transition: a session that fixed its addresses (Klarna) is submitted again without them', () => {
    const order = makeContainer({ orderNo: '00001' });
    const refusal = '{"error_type":"validation_error","error_codes":["update_billing_not_allowed","update_shipping_not_allowed"]}';
    const submit = (call) =>
        call === 1
            ? { ok: false, rejected: true, errorMessage: refusal }
            : { ok: true, object: { id: 'pay_1', status: 'Approved' } };
    const result = loadWith('scripts/checkoutcom/checkout', { '00001': order }, { payments: { pay_1: payment() }, submit }).submitPayment(submitInput);

    assert.equal(result.ok, true);
    assert.equal(calls.submitted.length, 2);
    assert.ok('billing' in calls.submitted[0].body && 'shipping' in calls.submitted[0].body);
    assert.equal('billing' in calls.submitted[1].body, false);
    assert.equal('shipping' in calls.submitted[1].body, false);
    assert.equal(calls.submitted[1].body.session_data, 'sd_secret');
    assert.deepEqual(calls.placed, ['00001']);
});

test('transition: any other refusal is not retried', () => {
    const order = makeContainer({ orderNo: '00001' });
    const submit = { ok: false, rejected: true, errorMessage: '{"error_codes":["amount_invalid"]}' };

    loadWith('scripts/checkoutcom/checkout', { '00001': order }, { submit }).submitPayment(submitInput);

    assert.equal(calls.submitted.length, 1);
});
