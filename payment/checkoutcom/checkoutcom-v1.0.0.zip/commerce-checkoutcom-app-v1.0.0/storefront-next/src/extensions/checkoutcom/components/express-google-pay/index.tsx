/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The Google Pay express checkout button (product page, cart, mini cart,
 * checkout).
 *
 * The sheet opens straight from the click, as Google Pay requires, with an
 * estimated total, while the basket is prepared in parallel: on the product
 * page a temporary basket holding only that product, elsewhere the cart. The
 * sheet's address and option changes update the basket's shipping
 * (onPaymentDataChanged); the authorization pays it (onPaymentAuthorized).
 * A card that needs 3D Secure redirects the shopper, who comes back through
 * /cko-return.
 */
import { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useSite } from '@salesforce/storefront-next-runtime/site-context';
import {
    isReadyToPayRequest,
    loadGooglePay,
    paymentDataRequest,
    shippingOptionParameters,
    transactionInfo,
    type GoogleAddress,
    type GoogleIntermediatePaymentData,
    type GooglePaymentData,
    type Labels,
} from '../../lib/google-pay';
import { GOOGLE_PAY, type WalletBasketSummary, type WalletPaymentResult } from '../../lib/wallet-types';
import { loadWalletConfig, postJson, releaseBasket, requestBasket, type ExpressSource } from '../../lib/express-client';
import { useExpressFinish } from '../../lib/use-express-finish';
import { currentPagePath } from '../../lib/return-path';
import { PAYMENT_ATTEMPT_EVENT } from '../../lib/place-order-handler';

export type { ExpressSource } from '../../lib/express-client';

interface Props {
    basket: ExpressSource;
    disabled?: boolean;
    /** Called once the button is on screen (Google Pay available and ready) */
    onReady?: () => void;
}

/** A partial address from the sheet (country, postal code, region, city) for shipping options. */
function partialAddress(address: GoogleAddress | undefined) {
    return address
        ? {
              countryCode: address.countryCode,
              postalCode: address.postalCode,
              stateCode: address.administrativeArea || undefined,
              city: address.locality,
          }
        : null;
}

/** A Google Pay address (FULL format, with phone) as a Shopper Baskets order address. */
function toOrderAddress(address: GoogleAddress) {
    const name = (address.name ?? '').trim();
    const split = name.lastIndexOf(' ');

    return {
        firstName: split > 0 ? name.slice(0, split) : name,
        lastName: split > 0 ? name.slice(split + 1) : name,
        address1: address.address1,
        address2: [address.address2, address.address3].filter(Boolean).join(' ') || undefined,
        city: address.locality,
        stateCode: address.administrativeArea || undefined,
        postalCode: address.postalCode,
        countryCode: address.countryCode,
        phone: address.phoneNumber || undefined,
    };
}

export default function ExpressGooglePay({ basket, disabled = false, onReady }: Props) {
    const { t } = useTranslation('extCheckoutcom');
    const site = useSite();
    const finish = useExpressFinish();
    const containerRef = useRef<HTMLDivElement>(null);
    const basketRef = useRef<Promise<WalletBasketSummary> | null>(null);
    const sourceRef = useRef(basket);
    const disabledRef = useRef(disabled);
    const onReadyRef = useRef(onReady);
    const finishRef = useRef(finish);
    const [ready, setReady] = useState(false);
    const [error, setError] = useState<string | null>(null);

    sourceRef.current = basket;
    disabledRef.current = disabled;
    onReadyRef.current = onReady;
    finishRef.current = finish;

    const labels: Labels = {
        subtotal: t('express.subtotal'),
        discount: t('express.discount'),
        shipping: t('express.shipping'),
        tax: t('express.tax'),
        total: t('express.total'),
    };
    const labelsRef = useRef(labels);

    labelsRef.current = labels;

    useEffect(() => {
        let cancelled = false;

        void (async () => {
            const walletConfig = await loadWalletConfig().catch(() => null);

            if (cancelled || !walletConfig?.googlePay.enabled || !walletConfig.publicKey) {
                return;
            }

            const publicKey = walletConfig.publicKey;
            const google = await loadGooglePay().catch(() => null);

            if (cancelled || !google || !containerRef.current) {
                return;
            }

            /** The basket for this sheet, created or read on the click. */
            const basketFor = (): Promise<WalletBasketSummary> => {
                basketRef.current ??= requestBasket(sourceRef.current);

                return basketRef.current;
            };

            const onPaymentDataChanged = async (intermediate: GoogleIntermediatePaymentData) => {
                try {
                    const prepared = await basketFor();
                    const { ok, data } = await postJson<WalletBasketSummary>('/action/checkoutcom-wallet-shipping', {
                        basketId: prepared.basketId,
                        address:
                            intermediate.callbackTrigger === 'SHIPPING_OPTION'
                                ? null
                                : partialAddress(intermediate.shippingAddress),
                        shippingOptionId: intermediate.shippingOptionData?.id ?? null,
                    });

                    if (!ok || !data.shippingOptions?.length) {
                        return {
                            error: {
                                reason: 'SHIPPING_ADDRESS_UNSERVICEABLE',
                                message: t('express.addressUnserviceable'),
                                intent: 'SHIPPING_ADDRESS',
                            },
                        };
                    }

                    return {
                        newTransactionInfo: transactionInfo(data, labelsRef.current),
                        newShippingOptionParameters: shippingOptionParameters(data),
                    };
                } catch {
                    return {
                        error: { reason: 'OTHER_ERROR', message: t('errors.payment'), intent: 'SHIPPING_ADDRESS' },
                    };
                }
            };

            const onPaymentAuthorized = async (paymentData: GooglePaymentData) => {
                try {
                    const prepared = await basketFor();
                    const shipping = paymentData.shippingAddress ?? {};
                    const billing = paymentData.paymentMethodData.info?.billingAddress ?? shipping;
                    const { data } = await postJson<WalletPaymentResult>('/action/checkoutcom-wallet-pay', {
                        basketId: prepared.basketId,
                        paymentMethodId: GOOGLE_PAY,
                        tokenData: JSON.parse(paymentData.paymentMethodData.tokenizationData.token),
                        // Where a 3D Secure payment that doesn't complete brings the shopper back
                        returnPage: currentPagePath(),
                        contact: {
                            email: paymentData.email,
                            shippingAddress: toOrderAddress(shipping),
                            billingAddress: toOrderAddress(billing),
                            shippingOptionId: paymentData.shippingOptionData?.id ?? null,
                        },
                    });

                    if (!finishRef.current(data)) {
                        setError(t('errors.payment'));
                    }

                    return data.status === 'failed'
                        ? {
                              transactionState: 'ERROR',
                              error: {
                                  reason: 'PAYMENT_DATA_INVALID',
                                  message: t('errors.payment'),
                                  intent: 'PAYMENT_AUTHORIZATION',
                              },
                          }
                        : { transactionState: 'SUCCESS' };
                } catch {
                    return {
                        transactionState: 'ERROR',
                        error: { reason: 'OTHER_ERROR', message: t('errors.payment'), intent: 'PAYMENT_AUTHORIZATION' },
                    };
                }
            };

            const client = new google.payments.api.PaymentsClient({
                environment: walletConfig.environment === 'production' ? 'PRODUCTION' : 'TEST',
                paymentDataCallbacks: { onPaymentDataChanged, onPaymentAuthorized },
            });
            const readiness = await client
                .isReadyToPay(isReadyToPayRequest(publicKey))
                .catch(() => ({ result: false }));

            if (cancelled || !readiness.result || !containerRef.current) {
                return;
            }

            const button = client.createButton({
                buttonColor: walletConfig.googlePay.buttonColor,
                buttonType: 'buy',
                buttonSizeMode: 'fill',
                buttonLocale: site.locale?.id?.split('-')[0],
                onClick: () => {
                    if (disabledRef.current) {
                        return;
                    }

                    setError(null);
                    // Clears the banner about an earlier payment
                    window.dispatchEvent(new Event(PAYMENT_ATTEMPT_EVENT));
                    basketRef.current = null;

                    const source = sourceRef.current;
                    const prepared = basketFor();

                    // Opened from the click, with an estimate the callbacks replace
                    client
                        .loadPaymentData(
                            paymentDataRequest({
                                publicKey,
                                merchantId: walletConfig.googlePay.merchantId,
                                merchantName: walletConfig.merchantName || document.title,
                                initial: transactionInfo(
                                    {
                                        currency: source.currency,
                                        total: source.estimatedTotal,
                                        subtotal: source.estimatedTotal,
                                        shipping: 0,
                                        tax: 0,
                                        discount: 0,
                                    },
                                    labelsRef.current,
                                    'ESTIMATED'
                                ),
                            })
                        )
                        .catch(() => {
                            // Closed or failed: a product page basket is deleted, the cart is kept
                            releaseBasket(source, prepared);
                        });
                },
            });

            containerRef.current.replaceChildren(button);
            setReady(true);
            onReadyRef.current?.();
        })();

        return () => {
            cancelled = true;
        };
        // The client is created once; the source and labels are read through refs
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div data-checkoutcom-express="google-pay" className={ready ? 'w-full' : 'hidden'}>
            <div ref={containerRef} className="w-full [&_button]:w-full" style={{ minHeight: ready ? 48 : 0 }} />
            {error ? (
                <p role="alert" className="mt-2 text-sm text-destructive">
                    {error}
                </p>
            ) : null}
        </div>
    );
}
