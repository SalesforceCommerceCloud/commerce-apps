/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The Checkout.com account prefix: the <prefix> of the account's own API host,
 * https://<prefix>.api.checkout.com (production) or
 * https://<prefix>.api.sandbox.checkout.com (sandbox). 3D Secure device checks
 * frame that host, so the storefront's Content Security Policy must allow it.
 *
 * A merchant's sandbox and production accounts have different prefixes. Each
 * Managed Runtime environment sets its own (config.ts, from the environment):
 *
 *   PUBLIC__app__extension__checkoutcom__sandboxAccountPrefix      the sandbox account's
 *   PUBLIC__app__extension__checkoutcom__productionAccountPrefix   the production account's
 *   PUBLIC__app__extension__checkoutcom__accountPrefix             either, when only one is used
 */
import type { FlowEnvironment } from './public-key';

/** The extension config the prefixes are read from (config.extension.checkoutcom). */
export interface AccountPrefixOptions {
    accountPrefix?: string;
    sandboxAccountPrefix?: string;
    productionAccountPrefix?: string;
}

/** A Checkout.com account prefix: lower-case letters and digits only. */
const PREFIX = /^[a-z0-9]{1,32}$/;

const valid = (prefix?: string | null): string | null => {
    const value = prefix?.trim().toLowerCase();

    return value && PREFIX.test(value) ? value : null;
};

/** @returns The account prefix configured for an environment, or null */
export function accountPrefixFor(
    options: AccountPrefixOptions | undefined,
    environment: FlowEnvironment
): string | null {
    const specific = environment === 'production' ? options?.productionAccountPrefix : options?.sandboxAccountPrefix;

    return valid(specific) ?? valid(options?.accountPrefix);
}

/**
 * The account prefix of a Service Endpoint (https://<prefix>.api[.sandbox].checkout.com),
 * as the instance reports it.
 * @returns The prefix, or null when the endpoint is empty or not an account host
 */
export function accountPrefixOfEndpoint(endpoint?: string | null): string | null {
    const match = /^https:\/\/([a-z0-9]+)\.api(?:\.sandbox)?\.checkout\.com\/?$/i.exec(endpoint?.trim() ?? '');

    return match ? valid(match[1]) : null;
}

/**
 * Compare the storefront's prefix with the account the instance uses.
 * @param options The storefront's extension config
 * @param environment The instance's Mode
 * @param instancePrefix The prefix of the instance's Service Endpoint, when it has one
 * @returns A warning to log, or null when they agree (or the instance doesn't say)
 */
export function accountPrefixMismatch(
    options: AccountPrefixOptions | undefined,
    environment: FlowEnvironment,
    instancePrefix: string | null | undefined
): string | null {
    const storefront = accountPrefixFor(options, environment);
    const instance = valid(instancePrefix);
    const variable =
        environment === 'production'
            ? 'PUBLIC__app__extension__checkoutcom__productionAccountPrefix'
            : 'PUBLIC__app__extension__checkoutcom__sandboxAccountPrefix';

    if (!instance) {
        return storefront
            ? null
            : `No Checkout.com account prefix for ${environment}: set ${variable}, or 3D Secure device checks are blocked by the Content Security Policy`;
    }

    if (storefront === instance) {
        return null;
    }

    return storefront
        ? `The storefront's Checkout.com account prefix for ${environment} is "${storefront}", but the instance uses "${instance}" (Service Endpoint): set ${variable}=${instance}, or 3D Secure device checks are blocked by the Content Security Policy`
        : `No Checkout.com account prefix for ${environment}: set ${variable}=${instance}, or 3D Secure device checks are blocked by the Content Security Policy`;
}
