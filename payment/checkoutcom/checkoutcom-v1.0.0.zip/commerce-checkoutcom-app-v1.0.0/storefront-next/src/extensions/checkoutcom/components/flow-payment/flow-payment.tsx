/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Checkout.com Flow at the checkout payment step (`sfcc.checkout.payment.paymentMethods`).
 *
 * Order-first sequence (the order exists before money moves, and the payment
 * reference is the order number):
 *
 *   payment step   session created from the basket, Flow mounted (own pay button hidden)
 *   Place Order    template runs place-order-prepare, then onPlaceOrder -> flow.submit()
 *   handleSubmit   create the order, submit the payment (reference = orderNo), return the response to Flow
 *   completed      verify + place the order, resolve onPlaceOrder(orderNo); template finalizes
 *   redirect       3DS / redirect methods leave the page; routes/_empty.cko-return.tsx completes
 *   failure        fail the order (basket reopened), resolve onPlaceOrder(null) with an error
 *
 * Wallets (Apple Pay, Google Pay) cannot be started with flow.submit(); their
 * buttons pay directly. If they go through handleSubmit, the same order-first
 * path runs and this component calls place-order-prepare / -finalize itself.
 * If they bypass it, the instance creates the order from the basket on
 * completion (see the cartridge's completeWithoutOrder).
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useBasket, useBasketUpdater } from '@/providers/basket';
import { createLogger } from '@/lib/logger';
import {
    loadCheckoutWebComponents,
    type CheckoutInstance,
    type FlowComponent,
    type SubmitData,
} from '@/extensions/checkoutcom/lib/checkout-web-components';
import { buildFlowOptions, type FlowConfigInput } from '@/extensions/checkoutcom/lib/flow-config';
import { getThemeAppearance } from '@/extensions/checkoutcom/lib/flow-theme';
import { toMinorUnits } from '@/extensions/checkoutcom/lib/amounts';
import { PAYMENT_ATTEMPT_EVENT, registerPlaceOrderHandler } from '@/extensions/checkoutcom/lib/place-order-handler';

/** The longest a Place Order may wait for Flow (3DS challenges can take minutes). */
const PLACE_ORDER_TIMEOUT_MS = 5 * 60 * 1000;

/** The longest the payment step may show "Loading payment methods" before reporting why. */
const LOAD_TIMEOUT_MS = 30 * 1000;

const logger = createLogger({ extension: 'checkoutcom' });

/** Loading steps, reported in the browser console when Flow does not appear. */
type LoadStage = 'basket' | 'session' | 'script' | 'init' | 'mount';

interface SessionResponse {
    paymentSession: { id: string } & Record<string, unknown>;
    publicKey: string;
    environment: 'sandbox' | 'production';
    appearance?: Record<string, unknown> | null;
    componentOptions?: Record<string, unknown> | null;
    translations?: Record<string, Record<string, string>> | null;
}

interface CompletionResult {
    status?: 'complete' | 'failed' | 'unverified' | 'no_order';
    orderNo?: string | null;
    errorMessage?: string | null;
    /** On failed: the reopened basket, the shopper's basket again */
    basket?: ReturnType<typeof useBasket> | null;
}

/** How long to wait before checking an unconfirmed payment once more. */
const RECHECK_DELAY_MS = 2000;

/**
 * The session request in flight, shared by concurrent mounts of the component:
 * React mounts effects twice in development, and two parallel requests would
 * each add a payment instrument to the basket.
 */
let sessionInFlight: { key: string; promise: Promise<{ ok: boolean; data: SessionResponse }> } | null = null;

function requestSession(key: string, locale: string): Promise<{ ok: boolean; data: SessionResponse }> {
    if (sessionInFlight?.key !== key) {
        const promise = postJson<SessionResponse>('/action/checkoutcom-session', { locale });

        sessionInFlight = { key, promise };
        void promise.finally(() => {
            if (sessionInFlight?.promise === promise) {
                sessionInFlight = null;
            }
        });
    }

    return sessionInFlight.promise;
}

async function postJson<T>(url: string, body: unknown): Promise<{ ok: boolean; data: T }> {
    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    });
    const data = (await response.json().catch(() => ({}))) as T;

    return { ok: response.ok, data };
}

async function postForm<T>(url: string, fields: Record<string, string>): Promise<{ ok: boolean; data: T }> {
    const form = new FormData();

    Object.entries(fields).forEach(([key, value]) => form.append(key, value));

    const response = await fetch(url, { method: 'POST', body: form });
    const data = (await response.json().catch(() => ({}))) as T;

    return { ok: response.ok, data };
}

export default function CheckoutcomFlowPayment() {
    const { t, i18n } = useTranslation('extCheckoutcom');
    const basket = useBasket();
    const updateBasket = useBasketUpdater();

    const containerRef = useRef<HTMLDivElement>(null);
    const flowRef = useRef<FlowComponent | null>(null);
    const checkoutRef = useRef<CheckoutInstance | null>(null);
    const sessionIdRef = useRef<string | null>(null);
    const orderNoRef = useRef<string | null>(null);
    // The basket the current attempt pays for: creating the order consumes it, and
    // a failed payment reopens it (see restoreBasket on the storefront server)
    const attemptBasketIdRef = useRef<string | null>(null);
    const placeOrderRef = useRef<((orderNo: string | null) => void) | null>(null);
    // Set when the current attempt has already been dealt with (released, or
    // reported as unconfirmed), so Flow's onError does not release it again
    const attemptEndedRef = useRef(false);
    const stageRef = useRef<LoadStage>('basket');
    // The basket flow-options.ts receives, current when Flow mounts
    const basketRef = useRef(basket);

    const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
    const [error, setError] = useState<string | null>(null);

    // The outcome of a 3DS or redirect payment that came back unsuccessful. Kept
    // apart from `error`, which is reset whenever Flow (re)mounts, so the shopper
    // sees it until they try again.

    useEffect(() => {
        basketRef.current = basket;
    }, [basket]);

    const basketId = basket?.basketId;
    const orderTotal = basket?.orderTotal;
    const currency = basket?.currency;
    const hasTotal = orderTotal != null;
    const locale = i18n.language;

    /**
     * End the current attempt: put the reopened basket back on the page (so the
     * checkout doesn't show an empty cart), resolve a pending Place Order and
     * show the message.
     */
    const fail = useCallback(
        (message: string, reopened?: CompletionResult['basket']) => {
            if (reopened?.basketId) {
                updateBasket(reopened);
            }

            setError(message);
            placeOrderRef.current?.(null);
            placeOrderRef.current = null;
        },
        [updateBasket]
    );

    /** Hand the placed order to the template, or finalize it ourselves (wallet path). */
    const settle = useCallback(async (orderNo: string) => {
        const resolve = placeOrderRef.current;

        placeOrderRef.current = null;
        orderNoRef.current = null;

        if (resolve) {
            resolve(orderNo);

            return;
        }

        const { data } = await postForm<{ redirectUrl?: string }>('/action/place-order-finalize', { orderNo });

        if (data.redirectUrl) {
            window.location.assign(data.redirectUrl);
        }
    }, []);

    /**
     * Give up on the current attempt. The instance fails the order and reopens
     * the basket, unless Checkout.com has a payment for it: then the order is
     * completed instead, and the shopper goes to the confirmation. When the
     * payment cannot be checked, the order stays open and the shopper is told
     * not to pay again.
     */
    const releaseAttempt = useCallback(
        async (message: string) => {
            const orderNo = orderNoRef.current;

            attemptEndedRef.current = true;
            orderNoRef.current = null;

            if (!orderNo) {
                fail(message);

                return;
            }

            const released = await postJson<CompletionResult>('/action/checkoutcom-fail-order', {
                orderNo,
                basketId: attemptBasketIdRef.current ?? undefined,
            });

            if (released.data.status === 'complete' && released.data.orderNo) {
                await settle(released.data.orderNo);
            } else if (released.data.status === 'failed') {
                fail(message, released.data.basket);
            } else {
                fail(t('errors.unverified'));
            }
        },
        [fail, settle, t]
    );

    // Never leave the shopper on "Loading" silently: report the step that is stuck
    useEffect(() => {
        if (status !== 'loading') {
            return undefined;
        }

        const timer = setTimeout(() => {
            logger.error('Flow did not load in time', {
                step: stageRef.current,
                basketId,
                orderTotal,
                hint:
                    stageRef.current === 'basket'
                        ? 'The basket has no order total yet: check taxes and the shipping method can be calculated for this site.'
                        : undefined,
            });
            setStatus('error');
            setError(t('errors.unavailable'));
        }, LOAD_TIMEOUT_MS);

        return () => clearTimeout(timer);
    }, [status, basketId, orderTotal, t]);

    // Create the payment session and mount Flow; again whenever the total changes
    useEffect(() => {
        if (!basketId || !hasTotal) {
            stageRef.current = 'basket';

            return undefined;
        }

        let cancelled = false;
        let mounted: FlowComponent | null = null;

        setStatus('loading');
        setError(null);

        void (async () => {
            try {
                stageRef.current = 'session';

                const session = await requestSession(`${basketId}:${currency}`, locale);

                if (!session.ok || !session.data.paymentSession?.id) {
                    throw new Error(`payment session request failed: ${JSON.stringify(session.data)}`);
                }

                stageRef.current = 'script';

                const load = await loadCheckoutWebComponents();

                if (cancelled) {
                    return;
                }

                sessionIdRef.current = session.data.paymentSession.id;
                stageRef.current = 'init';

                const own: FlowConfigInput['own'] = {
                    handleSubmit: async (_component, submitData: SubmitData) => {
                        attemptEndedRef.current = false;
                        attemptBasketIdRef.current = basketRef.current?.basketId ?? null;

                        // A wallet started the payment without Place Order: run the
                        // template's pre-flight (validation, totals) first.
                        if (!placeOrderRef.current) {
                            const prepared = await postForm('/action/place-order-prepare', {});

                            if (!prepared.ok) {
                                fail(t('errors.placeOrder'));
                                throw new Error('place-order-prepare failed');
                            }
                        }

                        const submitted = await postJson<{ orderNo?: string; response?: unknown; error?: string }>(
                            '/action/checkoutcom-submit',
                            {
                                sessionId: sessionIdRef.current,
                                sessionData: submitData.session_data,
                                orderNo: orderNoRef.current ?? undefined,
                            }
                        );

                        if (!submitted.ok || !submitted.data.orderNo) {
                            // The order may exist and the payment may even have gone
                            // through: release it through the instance, which checks
                            orderNoRef.current = submitted.data.orderNo ?? orderNoRef.current;
                            await releaseAttempt(t('errors.payment'));
                            throw new Error(submitted.data.error ?? 'submit failed');
                        }

                        orderNoRef.current = submitted.data.orderNo;

                        return submitted.data.response;
                    },

                    onPaymentCompleted: async (_component, payment) => {
                        const complete = (orderNo: string | undefined) =>
                            postJson<CompletionResult>('/action/checkoutcom-complete', {
                                paymentId: payment.id,
                                orderNo,
                                basketId: attemptBasketIdRef.current ?? basketRef.current?.basketId ?? undefined,
                            });

                        let completed = await complete(orderNoRef.current ?? undefined);

                        if (completed.data.status !== 'complete' && completed.data.status !== 'failed') {
                            // Not confirmed yet: check once more, with the order if one was created
                            await new Promise((resolve) => setTimeout(resolve, RECHECK_DELAY_MS));
                            completed = await complete(completed.data.orderNo ?? orderNoRef.current ?? undefined);
                        }

                        attemptEndedRef.current = true;

                        if (completed.data.status === 'complete' && completed.data.orderNo) {
                            await settle(completed.data.orderNo);
                        } else if (completed.data.status === 'failed') {
                            // Declined: the instance failed the order and reopened the basket
                            orderNoRef.current = null;
                            fail(completed.data.errorMessage ?? t('errors.payment'), completed.data.basket);
                        } else {
                            // Never a decline: the order stays open for the webhooks
                            orderNoRef.current = null;
                            fail(t('errors.unverified'));
                        }
                    },

                    onError: async () => {
                        if (!attemptEndedRef.current) {
                            await releaseAttempt(t('errors.payment'));
                        }
                    },
                };
                const flowOptions = (theme: Record<string, unknown>) =>
                    buildFlowOptions({
                        session: session.data,
                        theme,
                        locale,
                        context: { basket: basketRef.current, locale },
                        own,
                    });

                let checkout: CheckoutInstance;

                try {
                    checkout = await load(flowOptions(getThemeAppearance()));
                } catch (themeError) {
                    // Never let the storefront theme mapping block payment
                    logger.warn('Flow did not start with the storefront theme; starting with its default styling', {
                        error: String(themeError),
                    });
                    checkout = await load(flowOptions({}));
                }

                if (cancelled || !containerRef.current) {
                    return;
                }

                stageRef.current = 'mount';
                checkoutRef.current = checkout;
                mounted = checkout.create('flow', { showPayButton: false });

                if (!(await mounted.isAvailable())) {
                    throw new Error('unavailable');
                }

                mounted.mount(containerRef.current);
                flowRef.current = mounted;
                setStatus('ready');
            } catch (loadError) {
                if (!cancelled) {
                    logger.error('Flow failed to load', { step: stageRef.current, error: String(loadError) });
                    setStatus('error');
                    setError(t('errors.unavailable'));
                }
            }
        })();

        return () => {
            cancelled = true;
            flowRef.current = null;
            checkoutRef.current = null;
            mounted?.unmount();
        };
    }, [basketId, hasTotal, currency, locale, t, fail, releaseAttempt, settle]);

    // When shipping or taxes change the total while Flow is mounted, update the
    // amount Flow shows instead of creating a new session (which would clear what
    // the shopper typed). The amount charged is the order total, set at submission.
    useEffect(() => {
        const checkout = checkoutRef.current;

        if (status !== 'ready' || !checkout?.update || orderTotal == null || !currency) {
            return;
        }

        checkout.update({ amount: toMinorUnits(orderTotal, currency) });
    }, [status, orderTotal, currency]);

    // Let the template's Place Order button drive the payment
    useEffect(() => {
        // Offered to the payment step wrapper (components/payment-step), which owns
        // the template's onPlaceOrder, for as long as Flow is on screen
        return registerPlaceOrderHandler(
            () =>
                new Promise<string | null>((resolve) => {
                    const flow = flowRef.current;

                    attemptEndedRef.current = false;
                    setError(null);
                    // Clears the banner about an earlier payment (payment-return-error)
                    window.dispatchEvent(new Event(PAYMENT_ATTEMPT_EVENT));

                    if (!flow || !flow.isValid()) {
                        setError(t('errors.incomplete'));
                        resolve(null);

                        return;
                    }

                    const timer = setTimeout(() => fail(t('errors.timeout')), PLACE_ORDER_TIMEOUT_MS);

                    placeOrderRef.current = (orderNo) => {
                        clearTimeout(timer);
                        resolve(orderNo);
                    };

                    // Redirect methods and 3DS leave the page here; the return route completes
                    flow.submit();
                })
        );
    }, [t, fail]);

    return (
        <div className="flex flex-col gap-4" data-testid="checkoutcom-flow">
            {error ? (
                <div
                    className="rounded-md border border-destructive bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive"
                    role="alert"
                    data-testid="checkoutcom-error">
                    {error}
                </div>
            ) : null}
            <div ref={containerRef} />
            {status === 'loading' ? <p className="text-sm text-muted-foreground">{t('loading')}</p> : null}
        </div>
    );
}
