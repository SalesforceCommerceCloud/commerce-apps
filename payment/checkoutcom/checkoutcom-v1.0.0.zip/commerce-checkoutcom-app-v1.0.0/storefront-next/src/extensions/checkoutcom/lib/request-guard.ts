/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Same-origin guard for the extension's /action/checkoutcom-* routes, which
 * change state (create orders, release them, pay). They are resource routes,
 * which the framework's own CSRF check doesn't cover, and the session cookies
 * are SameSite=Lax: enough against other sites, not against a sibling
 * subdomain of the same site. So every call must:
 *
 *  - be a POST,
 *  - come from this origin (Sec-Fetch-Site same-origin, and an Origin, when the
 *    browser sends one, for this host),
 *  - carry JSON (Content-Type application/json): a cross-origin request with it
 *    needs a CORS preflight, which these routes never grant.
 *
 * The extension's own calls (fetch with a JSON body from the storefront's pages)
 * meet all three.
 */

/** The public host name the shopper is on (behind the Managed Runtime proxy too). */
export function publicHost(request: Request): string {
    const forwarded = request.headers.get('x-forwarded-host')?.split(',')[0]?.trim();

    return (forwarded || new URL(request.url).host).toLowerCase();
}

/**
 * @param request The incoming request
 * @returns A refusal to return as is, or null when the request may proceed
 */
export function refuseUnlessSameOrigin(request: Request): Response | null {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const fetchSite = request.headers.get('sec-fetch-site');
    const origin = request.headers.get('origin');
    let originHost: string | null = null;

    try {
        originHost = origin && origin !== 'null' ? new URL(origin).host.toLowerCase() : null;
    } catch {
        originHost = null;
    }

    if ((fetchSite && fetchSite !== 'same-origin') || (origin && originHost !== publicHost(request))) {
        return Response.json({ error: 'Cross-origin requests are not allowed' }, { status: 403 });
    }

    if (!(request.headers.get('content-type') ?? '').toLowerCase().startsWith('application/json')) {
        return Response.json({ error: 'Content-Type must be application/json' }, { status: 415 });
    }

    return null;
}
