/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Apple Pay merchant validation, from the sheet's onvalidatemerchant: the
 * instance asks Apple for a merchant session for this storefront's domain.
 *
 * POST { validationUrl } -> 200 { session } | 4xx/5xx { error }
 */
import type { ActionFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { createApplePaySession } from '../lib/wallet.server';
import { publicHost, refuseUnlessSameOrigin } from '../lib/request-guard';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    // POST, same origin, JSON only (lib/request-guard.ts)
    const refused = refuseUnlessSameOrigin(request);

    if (refused) {
        return refused;
    }

    const { validationUrl } = ((await request.json().catch(() => ({}))) ?? {}) as { validationUrl?: string };

    if (!validationUrl) {
        return Response.json({ error: 'validationUrl is required' }, { status: 400 });
    }

    try {
        return Response.json({
            session: await createApplePaySession(context, validationUrl, publicHost(request).replace(/:\d+$/, '')),
        });
    } catch (error) {
        getLogger(context).error('[checkoutcom] Apple Pay merchant validation failed', { error: String(error) });

        return Response.json({ error: 'Apple Pay is unavailable' }, { status: 502 });
    }
}
