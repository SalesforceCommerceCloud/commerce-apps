/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import { toMinorUnits } from './amounts';

describe('toMinorUnits (Checkout.com amount formats)', () => {
    it('multiplies most currencies by 100', () => {
        expect(toMinorUnits(45.5, 'GBP')).toBe(4550);
        expect(toMinorUnits(0.1 + 0.2, 'EUR')).toBe(30);
    });

    it('sends full-value currencies as they are', () => {
        expect(toMinorUnits(1200, 'JPY')).toBe(1200);
        expect(toMinorUnits(5000, 'UGX')).toBe(5000);
    });

    it('sends CLP times 100, ending in 00', () => {
        expect(toMinorUnits(100, 'CLP')).toBe(10000);
    });

    it('sends three-decimal currencies times 1000, ending in 0', () => {
        expect(toMinorUnits(1.234, 'KWD')).toBe(1230);
        expect(toMinorUnits(2.5, 'BHD')).toBe(2500);
    });
});
