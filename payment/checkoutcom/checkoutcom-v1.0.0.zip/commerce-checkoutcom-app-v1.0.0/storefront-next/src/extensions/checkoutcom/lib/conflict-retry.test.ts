/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

import { beforeEach, describe, expect, it, vi } from 'vitest';

const postCheckoutcomApi = vi.fn();

class CheckoutcomApiError extends Error {
    constructor(
        readonly status: number,
        readonly body: unknown
    ) {
        super(`HTTP ${status}`);
    }
}

vi.mock('@/lib/api-clients.server', () => ({ createApiClients: () => ({}) }));
vi.mock('@/middlewares/basket.server', () => ({ updateBasketResource: vi.fn() }));
vi.mock('@/middlewares/auth.server', () => ({ getAuth: vi.fn() }));
vi.mock('@/lib/api/basket.server', () => ({}));
vi.mock('@/lib/url.server', () => ({ buildUrlFromContext: () => '/cko-return' }));
vi.mock('@/extensions/checkoutcom/lib/checkoutcom-api.server', () => ({ postCheckoutcomApi, CheckoutcomApiError }));

const { completePayment, releaseOrder, withConflictRetry } = await import('./checkoutcom.server');

const context = {} as never;
const lockFailure = () => new CheckoutcomApiError(500, { title: 'Internal Server Error' });

describe('completion racing the webhook (the request fails as it commits)', () => {
    beforeEach(() => {
        vi.clearAllMocks();
        vi.useFakeTimers();
    });

    it('completes the order the webhook placed, after a 5xx', async () => {
        postCheckoutcomApi
            .mockRejectedValueOnce(lockFailure())
            .mockResolvedValueOnce({ status: 'complete', orderNo: '00001234', orderToken: 't' });

        const result = completePayment(context, { paymentId: 'pay_abcdefghij' });

        await vi.runAllTimersAsync();
        expect(await result).toMatchObject({ status: 'complete', orderNo: '00001234' });
        expect(postCheckoutcomApi).toHaveBeenCalledTimes(2);
        expect(postCheckoutcomApi.mock.calls[1]).toEqual([
            context,
            '/payments/complete',
            { paymentId: 'pay_abcdefghij' },
        ]);
    });

    it('retries a release too', async () => {
        postCheckoutcomApi.mockRejectedValueOnce(lockFailure()).mockResolvedValueOnce({ status: 'failed' });

        const result = releaseOrder(context, '00001234');

        await vi.runAllTimersAsync();
        expect(await result).toEqual({ status: 'failed' });
    });

    it('gives up after the last retry, with the error', async () => {
        postCheckoutcomApi.mockRejectedValue(lockFailure());

        const result = completePayment(context, { paymentId: 'pay_abcdefghij' }).catch((error: unknown) => error);

        await vi.runAllTimersAsync();
        expect(await result).toBeInstanceOf(CheckoutcomApiError);
        expect(postCheckoutcomApi).toHaveBeenCalledTimes(3);
    });

    it('never retries a 4xx (an answer) or an error before the request', async () => {
        for (const error of [new CheckoutcomApiError(422, {}), new Error('No shopper session')]) {
            const operation = vi.fn().mockRejectedValue(error);

            await expect(withConflictRetry(operation, [1, 1])).rejects.toBe(error);
            expect(operation).toHaveBeenCalledTimes(1);
        }
    });
});
