/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The basket an express wallet button pays for. Product page: a new temporary
 * basket holding only that product, so the cart is never touched. Cart and mini
 * cart: the shopper's basket.
 *
 * POST { source: 'product', productId, quantity, currency } | { source: 'cart' }
 *   -> 200 WalletBasketSummary | 4xx/5xx { error }
 */
import type { ActionFunctionArgs } from 'react-router';
import { getBasket } from '@/middlewares/basket.server';
import { getLogger } from '@/lib/logger.server';
import { createProductBasket, summarize } from '../lib/wallet.server';
import { refuseUnlessSameOrigin } from '../lib/request-guard';

interface BasketBody {
    source?: 'product' | 'cart';
    productId?: string;
    quantity?: number;
    currency?: string;
}

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    // POST, same origin, JSON only (lib/request-guard.ts)
    const refused = refuseUnlessSameOrigin(request);

    if (refused) {
        return refused;
    }

    const body = ((await request.json().catch(() => ({}))) ?? {}) as BasketBody;

    try {
        if (body.source === 'product') {
            if (!body.productId || !body.currency) {
                return Response.json({ error: 'productId and currency are required' }, { status: 400 });
            }

            // 1 to 99: the product page's own quantity selector; the basket API checks the stock
            const quantity =
                Number.isInteger(body.quantity) && (body.quantity as number) > 0
                    ? Math.min(body.quantity as number, 99)
                    : 1;

            return Response.json(
                await summarize(context, await createProductBasket(context, body.productId, quantity, body.currency))
            );
        }

        const basket = (await getBasket(context)).current;

        if (!basket?.basketId || !(basket.productItems ?? []).length) {
            return Response.json({ error: 'The cart is empty' }, { status: 409 });
        }

        return Response.json(await summarize(context, basket));
    } catch (error) {
        getLogger(context).error('[checkoutcom] wallet basket failed', { error: String(error) });

        return Response.json({ error: 'The basket could not be prepared' }, { status: 502 });
    }
}
