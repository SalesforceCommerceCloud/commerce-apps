/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Where a shopper goes back to when an express wallet payment leaves the page
 * (Google Pay 3D Secure) and doesn't complete: the page the button was on (the
 * product page, the cart), not checkout, where a product page's temporary
 * basket isn't the shopper's cart.
 *
 * Only a path on the storefront's own origin is accepted, so the return URL
 * can't send shoppers to another site.
 */

/** The query parameter of the return route that carries the page. */
export const RETURN_PAGE_PARAM = 'page';

/** A throwaway origin to resolve paths against: only the path part is ever kept. */
const BASE = 'https://storefront.invalid';

/**
 * @param value A path proposed by the browser
 * @returns The normalized path (path, query, hash) when it stays on this origin, else null
 */
export function safeReturnPath(value: unknown): string | null {
    if (typeof value !== 'string' || value.length > 2048) {
        return null;
    }

    // Same origin only: no scheme, no protocol-relative "//host", no backslashes or control characters
    if (!value.startsWith('/') || value.startsWith('//') || value.includes('\\') || /[\u0000-\u001f]/.test(value)) {
        return null;
    }

    let url: URL;

    try {
        url = new URL(value, BASE);
    } catch {
        return null;
    }

    // Checked again after normalization: "/.//evil.example/" resolves to the path "//evil.example/",
    // which a browser would read as another host
    if (url.origin !== BASE || url.pathname.startsWith('//')) {
        return null;
    }

    return `${url.pathname}${url.search}${url.hash}`;
}

/**
 * @param path A safe return path (safeReturnPath)
 * @param code The outcome code (payment_failed, payment_unverified)
 * @returns The path with ?paymentError=<code>, replacing an earlier one
 */
export function withPaymentError(path: string, code: string): string {
    const url = new URL(path, BASE);

    url.searchParams.set('paymentError', code);

    return `${url.pathname}${url.search}${url.hash}`;
}

/** @returns The current page, for the return route: path and query, without an earlier paymentError */
export function currentPagePath(): string | undefined {
    if (typeof window === 'undefined') {
        return undefined;
    }

    const url = new URL(window.location.href);

    url.searchParams.delete('paymentError');

    return `${url.pathname}${url.search}`;
}
