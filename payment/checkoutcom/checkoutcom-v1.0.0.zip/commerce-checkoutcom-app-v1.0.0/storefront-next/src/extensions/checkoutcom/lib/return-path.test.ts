/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

import { describe, expect, it } from 'vitest';
import { safeReturnPath, withPaymentError } from './return-path';

describe('return page of an express payment', () => {
    it('accepts only a path on the storefront origin', () => {
        expect(safeReturnPath('/new-site/en-US/product/abc?color=red')).toBe('/new-site/en-US/product/abc?color=red');
        expect(safeReturnPath('//evil.example/x')).toBeNull();
        expect(safeReturnPath('https://evil.example/x')).toBeNull();
        expect(safeReturnPath('/\\evil.example')).toBeNull();
        expect(safeReturnPath('relative')).toBeNull();
        expect(safeReturnPath(undefined)).toBeNull();
    });

    it('adds the outcome code, replacing an earlier one and keeping the query', () => {
        expect(withPaymentError('/p/abc?color=red', 'payment_failed')).toBe(
            '/p/abc?color=red&paymentError=payment_failed'
        );
        expect(withPaymentError('/p/abc?paymentError=x', 'payment_unverified')).toBe(
            '/p/abc?paymentError=payment_unverified'
        );
    });
});
