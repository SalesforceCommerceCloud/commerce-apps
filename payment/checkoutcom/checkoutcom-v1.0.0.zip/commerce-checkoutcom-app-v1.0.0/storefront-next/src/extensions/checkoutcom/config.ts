/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Checkout.com extension configuration, available at
 * `config.app.extension.checkoutcom`. Override per environment with
 * `PUBLIC__app__extension__checkoutcom__<setting>`.
 *
 * The secret key and the sandbox/production environment are not here: they
 * come from the instance (service credentials and the CKO Flow Mode). Nothing
 * secret ever belongs here.
 */
export default {
    /**
     * Your Checkout.com public key (`pk_sbox_…` for sandbox, `pk_…` for
     * production), as the Payment Commerce Apps guide asks for publishable keys.
     * Set it with `PUBLIC__app__extension__checkoutcom__publicKey` in each
     * environment. It must match the instance's Mode; when it is empty or for
     * the other Mode, the Business Manager *Public Key* is used instead
     * (lib/public-key.ts).
     */
    publicKey: '',

    /**
     * Your Checkout.com account's API prefix: the `<prefix>` of
     * `https://<prefix>.api.checkout.com` shown on the Checkout.com Dashboard
     * (Developers > Overview). Flow frames that account-specific host for 3D
     * Secure device checks, so the Content Security Policy must allow it
     * (lib/csp-contributor.ts). Set it with
     * `PUBLIC__app__extension__checkoutcom__accountPrefix`; it is not a secret.
     */
    accountPrefix: '',
};
