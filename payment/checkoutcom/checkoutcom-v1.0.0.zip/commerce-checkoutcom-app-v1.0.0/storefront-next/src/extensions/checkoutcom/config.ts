/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Checkout.com extension configuration, available at
 * `config.app.extension.checkoutcom`. Override per environment with
 * `PUBLIC__app__extension__checkoutcom__<setting>`.
 *
 * The secret key and the sandbox/production environment are not here: they
 * come from the instance (service credentials and the Checkout.com Flow Mode). Nothing
 * secret ever belongs here.
 */
export default {
    /**
     * Your Checkout.com public key (`pk_sbox_…` for sandbox, `pk_…` for
     * production), as the Payment Commerce Apps guide asks for publishable keys.
     * Set it with `PUBLIC__app__extension__checkoutcom__publicKey` in each
     * environment. It must match the instance's Mode; when it is empty or for
     * the other Mode, the Business Manager *Public Key* is used instead
     * (lib/public-key.ts).
     */
    publicKey: '',

    /**
     * Your Checkout.com accounts' API prefixes: the `<prefix>` of
     * `https://<prefix>.api.checkout.com` (production) or
     * `https://<prefix>.api.sandbox.checkout.com` (sandbox), shown on the
     * Checkout.com Dashboard (Developers > Overview) of each account. Flow frames
     * that account-specific host for 3D Secure device checks, so the Content
     * Security Policy must allow it (lib/csp-contributor.ts). They are not secrets.
     *
     * A sandbox account and a production account have different prefixes. Set
     * them per environment with
     * `PUBLIC__app__extension__checkoutcom__sandboxAccountPrefix` and
     * `PUBLIC__app__extension__checkoutcom__productionAccountPrefix`;
     * `PUBLIC__app__extension__checkoutcom__accountPrefix` applies to both when
     * the environment-specific one is empty. The storefront log warns when the
     * prefix doesn't match the account the instance uses (lib/account-prefix.ts).
     */
    sandboxAccountPrefix: '',
    productionAccountPrefix: '',
    accountPrefix: '',
};
