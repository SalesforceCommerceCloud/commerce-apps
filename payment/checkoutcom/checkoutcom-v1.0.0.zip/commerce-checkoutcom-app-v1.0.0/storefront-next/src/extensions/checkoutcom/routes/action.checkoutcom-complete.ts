/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Verify a completed Flow payment and place its order (idempotent).
 *
 * POST { paymentId, orderNo?, basketId? } -> 200 CompletionResult (complete | failed + basket | unverified) | 4xx
 */
import type { ActionFunctionArgs } from 'react-router';
import { getBasket } from '@/middlewares/basket.server';
import { getLogger } from '@/lib/logger.server';
import { completePayment, createOrder, restoreBasket, type CompletionResult } from '../lib/checkoutcom.server';
import { refuseUnlessSameOrigin } from '../lib/request-guard';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    // POST, same origin, JSON only (lib/request-guard.ts)
    const refused = refuseUnlessSameOrigin(request);

    if (refused) {
        return refused;
    }

    const logger = getLogger(context);
    const {
        paymentId,
        orderNo,
        basketId: attemptBasketId,
    } = ((await request.json().catch(() => ({}))) ?? {}) as {
        paymentId?: string;
        orderNo?: string;
        basketId?: string;
    };

    /** A declined payment's order was failed and its basket reopened: hand it back. */
    const respond = async (result: CompletionResult): Promise<Response> =>
        Response.json(
            result.status === 'failed'
                ? { ...result, basket: await restoreBasket(context, attemptBasketId).catch(() => null) }
                : result
        );

    if (!paymentId) {
        return Response.json({ status: 'failed', errorMessage: 'paymentId is required' }, { status: 400 });
    }

    // The order this request created, so a failure can still point the shopper to it
    let createdOrderNo: string | undefined;

    try {
        if (orderNo) {
            return respond(await completePayment(context, { paymentId, orderNo }));
        }

        // A payment completed without an order (a wallet that paid without
        // handleSubmit). It may already have one: a retried callback after a lost
        // response. The instance finds it through the payment's binding.
        const existing = await completePayment(context, { paymentId });

        if (existing.status !== 'no_order') {
            return respond(existing);
        }

        // Otherwise create the order from the basket it was made for; the instance
        // binds the payment to it before anything else can fail
        const basketId = (await getBasket(context, { ensureBasket: 'read' })).current?.basketId;

        if (!basketId) {
            return Response.json({ status: 'failed', errorMessage: 'No basket for this payment' }, { status: 409 });
        }

        createdOrderNo = (await createOrder(context, basketId)).orderNo as string;

        return respond(await completePayment(context, { paymentId, orderNo: createdOrderNo, basketId }));
    } catch (error) {
        logger.error('[checkoutcom] payment completion failed', {
            paymentId,
            orderNo,
            createdOrderNo,
            error: String(error),
        });

        // Not knowing is not a decline: the order stays open for a retry or a webhook
        const result: CompletionResult = {
            status: 'unverified',
            orderNo: orderNo ?? createdOrderNo ?? null,
            errorMessage: 'The payment could not be confirmed yet',
        };

        return Response.json(result);
    }
}
