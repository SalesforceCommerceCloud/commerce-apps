/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Pay a basket with an express wallet: exchange the wallet token for a
 * Checkout.com token, put the wallet's addresses and email on the basket,
 * create the order, and have the instance pay it.
 *
 * POST { basketId, paymentMethodId, tokenData, contact, returnPage? }
 *   -> 200 WalletPaymentResult (complete | pending + redirectUrl | failed | unverified) | 4xx
 */
import type { ActionFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import {
    APPLE_PAY,
    GOOGLE_PAY,
    exchangeWalletToken,
    getWalletConfig,
    payWithWallet,
    type WalletContact,
    type WalletMethod,
} from '../lib/wallet.server';

interface PayBody {
    basketId?: string;
    paymentMethodId?: WalletMethod;
    tokenData?: unknown;
    contact?: WalletContact;
    /** The page the button is on: where a 3D Secure payment that doesn't complete returns to */
    returnPage?: string;
}

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const logger = getLogger(context);
    const body = ((await request.json().catch(() => ({}))) ?? {}) as PayBody;

    const method = body.paymentMethodId;

    if (!body.basketId || (method !== GOOGLE_PAY && method !== APPLE_PAY) || !body.tokenData || !body.contact?.email) {
        return Response.json(
            { status: 'failed', errorMessage: 'basketId, paymentMethodId, tokenData and contact are required' },
            { status: 400 }
        );
    }

    let token: { token: string; tokenFormat: string | null };

    try {
        token = await exchangeWalletToken(
            context,
            await getWalletConfig(context),
            method === APPLE_PAY ? 'applepay' : 'googlepay',
            body.tokenData
        );
    } catch (error) {
        // Nothing was charged and no order exists: the shopper can try again
        logger.warn('[checkoutcom] wallet token exchange failed', { error: String(error) });

        return Response.json({ status: 'failed', errorMessage: 'The payment could not be processed' });
    }

    try {
        const result = await payWithWallet(
            request,
            context,
            body.basketId,
            method,
            body.contact,
            token,
            body.returnPage
        );

        logger.info('[checkoutcom] wallet payment', {
            method,
            status: result.status,
            orderNo: result.orderNo,
        });

        return Response.json(result);
    } catch (error) {
        // Before the order exists (basket updates, order creation): nothing charged
        logger.error('[checkoutcom] wallet payment failed', { error: String(error) });

        return Response.json({ status: 'failed', errorMessage: 'The order could not be placed' });
    }
}
