/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The express wallet buttons' settings: which wallets are switched on, the
 * Google Pay merchant id and button colour, the environment and the public key.
 *
 * POST -> 200 WalletConfig | 502
 */
import type { ActionFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { getWalletConfig } from '../lib/wallet.server';
import { refuseUnlessSameOrigin } from '../lib/request-guard';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    // POST, same origin, JSON only (lib/request-guard.ts)
    const refused = refuseUnlessSameOrigin(request);

    if (refused) {
        return refused;
    }

    try {
        return Response.json(await getWalletConfig(context));
    } catch (error) {
        getLogger(context).error('[checkoutcom] wallet config failed', { error: String(error) });

        return Response.json({ error: 'Wallet configuration unavailable' }, { status: 502 });
    }
}
