/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Server-side helpers shared by the Checkout.com routes: SCAPI basket and order
 * mutations, and calls to the instance's `checkoutcom` Custom API. The Custom
 * API holds the secret key; nothing here sees card data or keys.
 */
import type { RouterContextProvider } from 'react-router';
import { createApiClients } from '@/lib/api-clients.server';
import { addPaymentInstrumentToBasket, removePaymentInstrumentFromBasket } from '@/lib/api/basket.server';
import { buildUrlFromContext } from '@/lib/url.server';
import { RETURN_PAGE_PARAM, safeReturnPath } from '@/extensions/checkoutcom/lib/return-path';
import { getAuth } from '@/middlewares/auth.server';
import { updateBasketResource } from '@/middlewares/basket.server';
import { CheckoutcomApiError, postCheckoutcomApi } from '@/extensions/checkoutcom/lib/checkoutcom-api.server';
import type { ShopperBasketsV2, ShopperOrders } from '@/scapi';

type Basket = ShopperBasketsV2.schemas['Basket'];
type Order = ShopperOrders.schemas['Order'];
type Context = Readonly<RouterContextProvider>;

export const PAYMENT_METHOD_ID = 'CHECKOUTCOM_FLOW';

/** Storefront path of the gateway return route (routes/_empty.cko-return.tsx). */
export const RETURN_PATH = '/cko-return';

/** Response of `POST /payment-sessions`. */
export interface PaymentSessionResult {
    paymentSession: { id: string } & Record<string, unknown>;
    /** The Business Manager Public Key; null when only the environment variable is set */
    publicKey: string | null;
    environment: 'sandbox' | 'production';
    /** The account prefix of the instance's Service Endpoint, when it is an account host */
    accountPrefix?: string | null;
    appearance?: Record<string, unknown> | null;
    componentOptions?: Record<string, unknown> | null;
    translations?: Record<string, Record<string, string>> | null;
}

/**
 * Outcome of `POST /payments/complete` and `POST /orders/release`. unverified:
 * the payment could not be checked, the order stays open and the shopper must
 * not pay again; no_order: a wallet payment with no order yet.
 */
export interface CompletionResult {
    status: 'complete' | 'failed' | 'unverified' | 'no_order';
    pending?: boolean;
    orderNo?: string | null;
    orderToken?: string | null;
    errorMessage?: string | null;
    /** On failed: the basket reopened for another try, now the shopper's basket again */
    basket?: Basket | null;
}

/** Absolute success and failure URLs for the payment session, on the storefront's own origin. */
export function getReturnUrls(
    request: Request,
    context: Context,
    returnPage?: string | null
): { successUrl: string; failureUrl: string } {
    const origin = new URL(request.url).origin;
    const url = new URL(`${origin}${buildUrlFromContext(RETURN_PATH, context)}`);
    // The page an express payment started on: where the shopper goes back if it doesn't complete
    const page = safeReturnPath(returnPage);

    if (page) {
        url.searchParams.set(RETURN_PAGE_PARAM, page);
    }

    const failure = new URL(url);

    failure.searchParams.set('leg', 'failure');

    return { successUrl: url.toString(), failureUrl: failure.toString() };
}

/**
 * Make the basket carry exactly one CHECKOUTCOM_FLOW payment instrument for its
 * total. The template's place-order-prepare step keeps its amount in step with
 * the order total, and createOrder needs it.
 */
export async function ensurePaymentInstrument(context: Context, basket: Basket): Promise<Basket> {
    const basketId = basket.basketId;

    if (!basketId) {
        throw new Error('Basket has no basketId');
    }

    const current = await removeExtraPaymentInstruments(context, basket);

    if ((current.paymentInstruments ?? []).some((instrument) => instrument.paymentMethodId === PAYMENT_METHOD_ID)) {
        return current;
    }

    try {
        return await addPaymentInstrumentToBasket(context, basketId, {
            paymentMethodId: PAYMENT_METHOD_ID,
            amount: current.orderTotal ?? current.productTotal ?? 0,
        });
    } catch (error) {
        // A concurrent request added it first: the app's basket hook refuses a
        // second CHECKOUTCOM_FLOW instrument
        const { data: latest } = await createApiClients(context).shopperBasketsV2.getBasket({
            params: { path: { basketId } },
        });

        if ((latest.paymentInstruments ?? []).some((instrument) => instrument.paymentMethodId === PAYMENT_METHOD_ID)) {
            return latest;
        }

        throw error;
    }
}

/**
 * Remove every payment instrument except the first CHECKOUTCOM_FLOW one. Two
 * payment session requests running at the same time (React runs effects twice
 * in development; a double click does the same) can each add an instrument; a
 * second one would be copied into the order as an empty payment.
 */
export async function removeExtraPaymentInstruments(context: Context, basket: Basket): Promise<Basket> {
    if (!basket.basketId) {
        throw new Error('Basket has no basketId');
    }

    const instruments = basket.paymentInstruments ?? [];
    const keep = instruments.find((instrument) => instrument.paymentMethodId === PAYMENT_METHOD_ID);
    let current = basket;

    for (const instrument of instruments) {
        if (instrument !== keep && instrument.paymentInstrumentId) {
            current = await removePaymentInstrumentFromBasket(context, basket.basketId, instrument.paymentInstrumentId);
        }
    }

    return current;
}

/** Create the order from the basket through SCAPI Shopper Orders. */
export async function createOrder(context: Context, basketId: string): Promise<Order> {
    const clients = createApiClients(context);
    const { data: order } = await clients.shopperOrders.createOrder({ params: {}, body: { basketId } });

    if (!order.orderNo) {
        throw new Error('createOrder returned no orderNo');
    }

    return order;
}

/**
 * Give up on an order's payment through the Custom API (`POST /orders/release`):
 * the instance fails the order and reopens the basket, unless Checkout.com has a
 * payment for it, in which case it completes the order instead. A storefront
 * error never proves that no money moved, so orders are never failed directly.
 */
export async function releaseOrder(context: Context, orderNo: string): Promise<CompletionResult> {
    return withConflictRetry(() => postCheckoutcomApi<CompletionResult>(context, '/orders/release', { orderNo }));
}

/** Waits before each retry of an idempotent order operation, in milliseconds. */
export const CONFLICT_RETRY_DELAYS_MS = [400, 1200];

/**
 * Run an idempotent order operation (complete, release) again when the instance
 * answered 5xx. A Custom API request commits its changes only when it ends, so
 * when the webhook updates the same order at that moment (it arrives within a
 * second of a 3DS return) the request fails with an optimistic locking error,
 * however the script handles it. Run again, the operation reads the order as the
 * webhook left it: a placed order completes. A 4xx is an answer, never retried.
 */
export async function withConflictRetry<T>(
    operation: () => Promise<T>,
    delays: readonly number[] = CONFLICT_RETRY_DELAYS_MS
): Promise<T> {
    for (let attempt = 0; ; attempt++) {
        try {
            return await operation();
        } catch (error) {
            const retriable = error instanceof CheckoutcomApiError && error.status >= 500;

            if (!retriable || attempt >= delays.length) {
                throw error;
            }

            await new Promise((resolve) => setTimeout(resolve, delays[attempt]));
        }
    }
}

/**
 * Make the basket a failed payment reopened the shopper's basket again.
 *
 * Creating the order consumes the basket; when the payment fails, the instance
 * fails the order and reopens that basket (OrderMgr.failOrder(order, true)).
 * Meanwhile the storefront may have dropped the consumed basket from the
 * session, or started a new empty one, which left the shopper on an empty
 * checkout. The reopened basket is read again (by id, else the shopper's newest
 * basket that has items: products or gift certificates) and set as the session's basket, so the response's
 * basket cookie points at it. Never a temporary basket (product page wallets).
 * @returns The basket, or null when none with items was found
 */
export async function restoreBasket(context: Context, basketId?: string | null): Promise<Basket | null> {
    const clients = createApiClients(context);
    const hasItems = (candidate?: Basket | null): candidate is Basket =>
        !!candidate?.basketId &&
        !(candidate as Basket & { temporaryBasket?: boolean }).temporaryBasket &&
        (candidate.productItems ?? []).length + (candidate.giftCertificateItems ?? []).length > 0;
    let basket: Basket | null = null;

    if (basketId) {
        basket = await clients.shopperBasketsV2
            .getBasket({ params: { path: { basketId } } })
            .then(({ data }) => data)
            .catch(() => null);
    }

    if (!hasItems(basket)) {
        const { customerId } = getAuth(context);

        if (customerId) {
            const { data } = await clients.shopperCustomers
                .getCustomerBaskets({ params: { path: { customerId } } })
                .catch(() => ({ data: { baskets: [] as Basket[] } }));
            const baskets = ((data as { baskets?: Basket[] }).baskets ?? []).filter(hasItems);

            baskets.sort((a, b) => String(b.lastModified ?? '').localeCompare(String(a.lastModified ?? '')));
            basket = baskets[0] ?? null;
        }
    }

    if (!hasItems(basket)) {
        return null;
    }

    updateBasketResource(context, basket);

    return basket;
}

/**
 * Custom API: create the payment session for the basket. The basket is sent in
 * full because a Custom API script cannot load the shopper's basket itself.
 */
export async function createPaymentSession(
    context: Context,
    body: { basket: Basket; successUrl: string; failureUrl: string; locale?: string }
): Promise<PaymentSessionResult> {
    return postCheckoutcomApi<PaymentSessionResult>(context, '/payment-sessions', body);
}

/** Custom API: submit the payment Flow collected, for an order. */
export async function submitPayment(
    context: Context,
    body: { sessionId: string; sessionData: string; orderNo: string }
): Promise<unknown> {
    // The gateway's submit response, returned to Flow unmodified
    return postCheckoutcomApi<unknown>(context, '/payments/submit', body);
}

/** Custom API: verify the payment and place its order. */
export async function completePayment(
    context: Context,
    body: { paymentId: string; orderNo?: string; basketId?: string }
): Promise<CompletionResult> {
    return withConflictRetry(() => postCheckoutcomApi<CompletionResult>(context, '/payments/complete', body));
}
