/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Content Security Policy contributor for Checkout.com Flow: the exact hosts
 * Flow and its wallets (Apple Pay, Google Pay, PayPal) load scripts from, call,
 * frame and load images from (Checkout.com's documented list, checked against
 * the hosts Flow's script uses). Register it in
 * src/middlewares/security-headers.server.ts:
 *
 *     // @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
 *     import { createCheckoutcomCspContributor } from '@/extensions/checkoutcom/lib/csp-contributor';
 *     ...
 *     const contributors = [
 *         ...
 *         // @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
 *         createCheckoutcomCspContributor(config.extension?.checkoutcom),
 *     ];
 *
 * Production and sandbox hosts are both contributed: the policy is built when
 * the storefront starts, while the Checkout.com mode is a Business Manager
 * preference that can change at any time.
 */
import type { CspContribution, CspContributor } from '@salesforce/storefront-next-runtime/security';
import { accountPrefixFor, type AccountPrefixOptions } from './account-prefix';

type Directive = 'script-src' | 'connect-src' | 'frame-src' | 'img-src' | 'font-src' | 'style-src';

/**
 * The extension config the contributor reads (config.ts): the account prefixes,
 * for https://<prefix>.api.checkout.com and https://<prefix>.api.sandbox.checkout.com.
 * A merchant's sandbox and production accounts have different prefixes (see account-prefix.ts).
 */
export type CheckoutcomCspOptions = AccountPrefixOptions;

/**
 * The hosts per directive, for one Checkout.com environment. Flow itself, then
 * the wallets it renders: Apple Pay (merchant validation), Google Pay and PayPal
 * (scripts, frames and button images).
 */
function hosts(env: 'production' | 'sandbox', accountPrefix: string | null): Record<Directive, string[]> {
    const cko = env === 'production' ? 'checkout.com' : 'sandbox.checkout.com';
    const paypal = env === 'production' ? 'www.paypal.com' : 'www.sandbox.paypal.com';
    // The account-specific API host, framed for 3D Secure device checks
    const account = accountPrefix ? [`${accountPrefix}.api.${cko}`] : [];

    return {
        'script-src': [
            `checkout-web-components.${cko}`,
            `risk.${cko}`,
            'pay.google.com',
            // The Apple Pay button and ApplePaySession of the express checkout buttons
            'applepay.cdn-apple.com',
            paypal,
            'www.paypalobjects.com',
        ],
        'connect-src': [
            // Flow's own host: its source map, fetched by the browser developer tools
            `checkout-web-components.${cko}`,
            `api.${cko}`,
            ...account,
            `devices.api.${cko}`,
            `checkout-web-components-events.${cko}`,
            `risk.${cko}`,
            `card-acquisition-gateway.${cko}`,
            `apme-api.${cko}`,
            'apple-pay-gateway.apple.com',
            'pay.google.com',
            'google.com',
            // Google Pay's script reports to https://www.google.com/pay
            'www.google.com',
            paypal,
        ],
        // Flow's card fields and Remember Me device frame are pages on its own
        // host; risk is the fraud check's device frame
        'frame-src': [
            `checkout-web-components.${cko}`,
            `authentication-devices.${cko}`,
            `risk.${cko}`,
            ...account,
            'pay.google.com',
            // Apple's button script frames its own page for Apple Pay outside Safari (the QR code sheet)
            'applepay.cdn-apple.com',
            paypal,
        ],
        // cdnjs serves the country flags of Flow's phone and address fields;
        // gstatic the Google Pay button's logo where the button isn't a frame (Safari)
        'img-src': [`risk.${cko}`, 'cdnjs.cloudflare.com', 'www.gstatic.com', paypal, 'www.paypalobjects.com'],
        // The Apple Pay button's font, loaded by Apple's button script
        'font-src': ['applepay.cdn-apple.com'],
        'style-src': [],
    };
}

/**
 * Klarna, which Flow loads for its Klarna payment method (Klarna Payments'
 * documented policy, https://docs.klarna.com/klarna-payments/integrate-with-klarna-payments/step-2-check-out/).
 * Klarna lists *.klarna.com and *.klarnaevt.com; contributors can't add
 * wildcards, so these are the hosts Klarna Payments uses: production, and
 * playground for sandbox accounts, with Klarna's event hosts per region.
 */
const KLARNA: Record<Directive, string[]> = {
    'script-src': ['x.klarnacdn.net', 'js.klarna.com', 'js.playground.klarna.com'],
    // Klarna's loading indicators and overlay ('unsafe-inline' is already in the template's style-src)
    'style-src': ['x.klarnacdn.net'],
    'font-src': ['x.klarnacdn.net'],
    'connect-src': [
        'x.klarnacdn.net',
        'js.klarna.com',
        'js.playground.klarna.com',
        'eu.klarnaevt.com',
        'na.klarnaevt.com',
        'oc.klarnaevt.com',
        'eu.playground.klarnaevt.com',
        'na.playground.klarnaevt.com',
        'oc.playground.klarnaevt.com',
    ],
    'frame-src': [
        'x.klarnacdn.net',
        'js.klarna.com',
        'js.playground.klarna.com',
        'payments.klarna.com',
        'payments.playground.klarna.com',
    ],
    'img-src': ['x.klarnacdn.net'],
};

/** @returns The hosts per directive, production and sandbox, without duplicates */
export function getCheckoutcomCspContribution(options: CheckoutcomCspOptions = {}): CspContribution {
    // Each environment's own account: the production prefix on checkout.com, the sandbox one on sandbox.checkout.com
    const production = hosts('production', accountPrefixFor(options, 'production'));
    const sandbox = hosts('sandbox', accountPrefixFor(options, 'sandbox'));
    const contribution: CspContribution = {};

    (Object.keys(production) as Directive[]).forEach((directive) => {
        contribution[directive] = [
            ...new Set([...production[directive], ...sandbox[directive], ...KLARNA[directive]]),
        ].map((host) => `https://${host}`);
    });

    return contribution;
}

/** @param options The extension config: `config.extension?.checkoutcom` */
export function createCheckoutcomCspContributor(options: CheckoutcomCspOptions = {}): CspContributor {
    return {
        id: 'checkoutcom-flow',
        isActive: () => true,
        contribute: () => getCheckoutcomCspContribution(options),
    };
}
