/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

import { describe, expect, it } from 'vitest';
import { refuseUnlessSameOrigin } from './request-guard';

const call = (headers: Record<string, string>, method = 'POST') =>
    refuseUnlessSameOrigin(new Request('https://shop.example/action/checkoutcom-submit', { method, headers }));

describe('same-origin guard of the action routes', () => {
    it("lets the storefront's own JSON calls through", () => {
        expect(
            call({
                'content-type': 'application/json',
                origin: 'https://shop.example',
                'sec-fetch-site': 'same-origin',
            })
        ).toBeNull();
        expect(call({ 'content-type': 'application/json; charset=utf-8' })).toBeNull();
    });

    it('refuses cross-site and same-site (sibling subdomain) calls', () => {
        expect(call({ 'content-type': 'application/json', 'sec-fetch-site': 'same-site' })?.status).toBe(403);
        expect(call({ 'content-type': 'application/json', 'sec-fetch-site': 'cross-site' })?.status).toBe(403);
        expect(call({ 'content-type': 'application/json', origin: 'https://evil.shop.example' })?.status).toBe(403);
        expect(call({ 'content-type': 'application/json', origin: 'null' })?.status).toBe(403);
    });

    it('refuses bodies a cross-site form or a no-preflight fetch can send', () => {
        expect(call({ 'content-type': 'text/plain' })?.status).toBe(415);
        expect(call({ 'content-type': 'application/x-www-form-urlencoded' })?.status).toBe(415);
        expect(call({})?.status).toBe(415);
    });

    it('refuses anything but POST', () => {
        expect(call({ 'content-type': 'application/json' }, 'GET')?.status).toBe(405);
    });

    it('compares with the public host behind the Managed Runtime proxy', () => {
        const request = new Request('https://internal.example/action/checkoutcom-submit', {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                origin: 'https://shop.example',
                'x-forwarded-host': 'shop.example',
            },
        });

        expect(refuseUnlessSameOrigin(request)).toBeNull();
    });
});
