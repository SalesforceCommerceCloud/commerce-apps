/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

import { describe, expect, it } from 'vitest';
import { accountPrefixFor, accountPrefixMismatch, accountPrefixOfEndpoint } from './account-prefix';
import { getCheckoutcomCspContribution } from './csp-contributor';

describe('account prefixes (sandbox and production accounts differ)', () => {
    it('uses the environment-specific prefix, else the shared one', () => {
        const options = {
            sandboxAccountPrefix: 's33fohm3',
            productionAccountPrefix: 'prod1234',
            accountPrefix: 'shared99',
        };

        expect(accountPrefixFor(options, 'sandbox')).toBe('s33fohm3');
        expect(accountPrefixFor(options, 'production')).toBe('prod1234');
        expect(accountPrefixFor({ accountPrefix: 'shared99' }, 'production')).toBe('shared99');
        expect(accountPrefixFor({ accountPrefix: '*.evil' }, 'sandbox')).toBeNull();
    });

    it('reads the prefix of an instance Service Endpoint', () => {
        expect(accountPrefixOfEndpoint('https://s33fohm3.api.sandbox.checkout.com')).toBe('s33fohm3');
        expect(accountPrefixOfEndpoint('https://abcd1234.api.checkout.com/')).toBe('abcd1234');
        expect(accountPrefixOfEndpoint('https://api.checkout.com')).toBeNull();
        expect(accountPrefixOfEndpoint(null)).toBeNull();
    });

    it('warns when the storefront prefix is not the instance account, naming the variable to set', () => {
        const warning = accountPrefixMismatch({ accountPrefix: 'nrmywhdy' }, 'sandbox', 's33fohm3');

        expect(warning).toContain('"nrmywhdy"');
        expect(warning).toContain('PUBLIC__app__extension__checkoutcom__sandboxAccountPrefix=s33fohm3');
        expect(accountPrefixMismatch({ sandboxAccountPrefix: 's33fohm3' }, 'sandbox', 's33fohm3')).toBeNull();
        expect(accountPrefixMismatch({}, 'production', null)).toContain('productionAccountPrefix');
        expect(accountPrefixMismatch({ accountPrefix: 'abcd1234' }, 'production', null)).toBeNull();
    });

    it('allows each account host in the Content Security Policy for its own environment', () => {
        const frames = getCheckoutcomCspContribution({
            sandboxAccountPrefix: 's33fohm3',
            productionAccountPrefix: 'prod1234',
        })['frame-src'];

        expect(frames).toContain('https://s33fohm3.api.sandbox.checkout.com');
        expect(frames).toContain('https://prod1234.api.checkout.com');
        expect(frames).not.toContain('https://s33fohm3.api.checkout.com');
        expect(frames).not.toContain('https://prod1234.api.sandbox.checkout.com');
    });
});
