/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Wraps the checkout payment step (`sfcc.checkout.payment`) and owns its Place
 * Order callback, as the Payment Commerce Apps guide asks: a component at
 * `sfcc.checkout.payment.paymentMethods` unmounts when the shopper collapses the
 * step, which would clear the callback.
 *
 * The template's payment step is rendered unchanged (`children`), so its
 * billing address form and `billingAddressGetter` keep working; Flow renders
 * inside it at `sfcc.checkout.payment.paymentMethods`.
 */
import { useEffect, useState, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { usePaymentSubmissionRef } from '@/components/checkout/payment-submission-context';
import { getPlaceOrderHandler } from '@/extensions/checkoutcom/lib/place-order-handler';

export default function CheckoutcomPaymentStep({ children }: { children?: ReactNode }) {
    const { t } = useTranslation('extCheckoutcom');
    const paymentSubmissionRef = usePaymentSubmissionRef();
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const submission = paymentSubmissionRef.current;

        if (!submission) {
            return undefined;
        }

        submission.onPlaceOrder = async () => {
            const placeOrder = getPlaceOrderHandler();

            if (!placeOrder) {
                // The payment step is collapsed: Flow is not on screen to pay with
                setError(t('errors.incomplete'));

                return null;
            }

            setError(null);

            return placeOrder();
        };

        return () => {
            submission.onPlaceOrder = null;
        };
    }, [paymentSubmissionRef, t]);

    return (
        <>
            {error ? (
                <div
                    className="mb-4 rounded-md border border-destructive bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive"
                    role="alert"
                    data-testid="checkoutcom-payment-step-error">
                    {error}
                </div>
            ) : null}
            {children}
        </>
    );
}
