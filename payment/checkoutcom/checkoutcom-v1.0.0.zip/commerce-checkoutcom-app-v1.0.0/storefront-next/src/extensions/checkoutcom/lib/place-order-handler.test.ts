/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import { getPlaceOrderHandler, registerPlaceOrderHandler } from './place-order-handler';

describe('Place Order hand-off between the payment step and Flow', () => {
    it('offers the mounted Flow component handler, and withdraws it on unmount', async () => {
        const withdraw = registerPlaceOrderHandler(() => Promise.resolve('00001'));

        expect(await getPlaceOrderHandler()?.()).toBe('00001');

        withdraw();
        expect(getPlaceOrderHandler()).toBeNull();
    });

    it('a stale unmount never withdraws the handler of a newer mount (React remounts)', () => {
        const withdrawFirst = registerPlaceOrderHandler(() => Promise.resolve('first'));
        const second = () => Promise.resolve('second');
        const withdrawSecond = registerPlaceOrderHandler(second);

        withdrawFirst();
        expect(getPlaceOrderHandler()).toBe(second);

        withdrawSecond();
        expect(getPlaceOrderHandler()).toBeNull();
    });
});
