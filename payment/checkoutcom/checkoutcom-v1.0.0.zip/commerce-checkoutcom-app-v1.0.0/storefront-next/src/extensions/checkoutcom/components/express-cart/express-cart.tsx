/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Express checkout for the shopper's cart (sfcc.cart.payments.expressCheckout
 * and sfcc.miniCart.payments.expressCheckout): Apple Pay and Google Pay for the whole basket.
 */
import { useBasket } from '@/providers/basket';
import ExpressButtons from '../express-buttons';
import CheckoutcomPaymentReturnError from '../payment-return-error/payment-return-error';

export default function CheckoutcomExpressCart() {
    const basket = useBasket();

    if (!basket?.basketId || !(basket.productItems ?? []).length || !basket.currency) {
        return null;
    }

    return (
        <div className="mt-3 w-full">
            {/* An express payment that left the page (3D Secure) and didn't complete */}
            <CheckoutcomPaymentReturnError className="mb-3" />
            <ExpressButtons
                basket={{
                    source: 'cart',
                    currency: basket.currency,
                    estimatedTotal: basket.orderTotal ?? basket.productTotal ?? 0,
                }}
            />
        </div>
    );
}
