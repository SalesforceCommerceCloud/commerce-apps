'use strict';

var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

/**
 * Verifies the required information for billing form is provided.
 * @param {Object} req - The request object
 * @param {Object} paymentForm - the payment form
 * @param {Object} viewFormData - object contains billing form data
 * @returns {Object} an object that has error information or payment information
 */
function processForm(req, paymentForm, viewFormData) {
    try {
        var array = require('*/cartridge/scripts/util/array');

        var viewData = viewFormData;
        var creditCardErrors = {};

        if (!req.form.storedPaymentUUID) {
            // verify credit card form data
            creditCardErrors = COHelpers.validateCreditCard(paymentForm);
        }

        if (Object.keys(creditCardErrors).length) {
            return {
                fieldErrors: creditCardErrors,
                error: true,
            };
        }

        viewData.paymentMethod = {
            value: paymentForm.paymentMethod.value,
            htmlName: paymentForm.paymentMethod.value,
        };

        viewData.paymentInformation = {
            saveCard: {
                value: paymentForm.creditCardFields.saveCard.value,
                htmlName: paymentForm.creditCardFields.saveCard.htmlName,
            },
            firstName: {
                value: paymentForm.addressFields.firstName.value,
                htmlName: paymentForm.addressFields.firstName.htmlName,
            },
            lastName: {
                value: paymentForm.addressFields.lastName.value,
                htmlName: paymentForm.addressFields.lastName.htmlName,
            },
            cardType: {
                value: paymentForm.creditCardFields.cardType.value,
                htmlName: paymentForm.creditCardFields.cardType.htmlName,
            },
            cardNumber: {
                value: paymentForm.creditCardFields.cardNumber.value,
                htmlName: paymentForm.creditCardFields.cardNumber.htmlName,
            },
            securityCode: {
                value: paymentForm.creditCardFields.securityCode.value,
                htmlName: paymentForm.creditCardFields.securityCode.htmlName,
            },
            expirationMonth: {
                value: parseInt(
                    paymentForm.creditCardFields.expirationMonth.selectedOption,
                    10
                ),
                htmlName: paymentForm.creditCardFields.expirationMonth.htmlName,
            },
            expirationYear: {
                value: parseInt(paymentForm.creditCardFields.expirationYear.value, 10),
                htmlName: paymentForm.creditCardFields.expirationYear.htmlName,
            },
        };

        if (req.form.storedPaymentUUID) {
            viewData.storedPaymentUUID = req.form.storedPaymentUUID;
        }

        viewData.saveCard = paymentForm.creditCardFields.saveCard.checked;

        // process payment information
        if (viewData.storedPaymentUUID
            && req.currentCustomer.raw.authenticated
            && req.currentCustomer.raw.registered
        ) {
            var paymentInstruments = req.currentCustomer.wallet.paymentInstruments;
            var paymentInstrument = array.find(paymentInstruments, function(item) {
                return viewData.storedPaymentUUID === item.UUID;
            });

            viewData.paymentInformation.firstName.value = paymentForm.addressFields.firstName.htmlValue;
            viewData.paymentInformation.lastName.value = paymentForm.addressFields.lastName.htmlValue;
            viewData.paymentInformation.cardNumber.value = paymentInstrument.creditCardNumber;
            viewData.paymentInformation.cardType.value = paymentInstrument.creditCardType;
            viewData.paymentInformation.securityCode.value = req.form.securityCode;
            viewData.paymentInformation.expirationMonth.value = paymentInstrument.creditCardExpirationMonth;
            viewData.paymentInformation.expirationYear.value = paymentInstrument.creditCardExpirationYear;
            viewData.paymentInformation.creditCardToken = paymentInstrument.raw.creditCardToken;
            viewData.paymentInformation.storedPaymentUUID = viewData.storedPaymentUUID;
            viewData.paymentInformation.cardBin = paymentInstrument.raw.custom.ckoCreditCardBin;
        }

        return {
            error: false,
            viewData: viewData,
        };
    } catch (e) {
        var Logger = require('dw/system/Logger');
        Logger.getLogger('ckoPayments').error('CHECKOUTCOM_CARD processForm failed: {0}', e.message);
        return {
            fieldErrors: {},
            error: true,
        };
    }
}

/**
 * Save the credit card information to login account if save card option is selected
 * @param {Object} req - The request object
 * @param {dw.order.Basket} basket - The current basket
 * @param {Object} billingData - payment information
 */
function savePaymentInformation(req, basket, billingData) {
    try {
        var CustomerMgr = require('dw/customer/CustomerMgr');

        if (!billingData.storedPaymentUUID
            && req.currentCustomer.raw.authenticated
            && req.currentCustomer.raw.registered
            && billingData.saveCard
            && (billingData.paymentMethod.value === 'CREDIT_CARD')
        ) {
            var customer = CustomerMgr.getCustomerByCustomerNumber(
                req.currentCustomer.profile.customerNo
            );

            var saveCardResult = COHelpers.savePaymentInstrumentToWallet(
                billingData,
                basket,
                customer
            );

            req.currentCustomer.wallet.paymentInstruments.push({
                creditCardHolder: saveCardResult.creditCardHolder,
                maskedCreditCardNumber: saveCardResult.maskedCreditCardNumber,
                creditCardType: saveCardResult.creditCardType,
                creditCardExpirationMonth: saveCardResult.creditCardExpirationMonth,
                creditCardExpirationYear: saveCardResult.creditCardExpirationYear,
                UUID: saveCardResult.UUID,
                creditCardNumber: Object.hasOwnProperty.call(
                    saveCardResult,
                    'creditCardNumber'
                )
                    ? saveCardResult.creditCardNumber
                    : null,
                raw: saveCardResult,
            });
        }
    } catch (e) {
        var Logger = require('dw/system/Logger');
        Logger.getLogger('ckoPayments').error('CHECKOUTCOM_CARD savePaymentInformation failed: {0}', e.message);
    }
}

exports.processForm = processForm;
exports.savePaymentInformation = savePaymentInformation;

// Alias export required by the Commerce Apps registry scan: the hook name's
// last segment (hooks.json) must exist as an export. SFCC resolves the hook
// functions above by name through HookMgr; this alias is not invoked.
exports.checkoutcom_card = { processForm: processForm, savePaymentInformation: savePaymentInformation };
