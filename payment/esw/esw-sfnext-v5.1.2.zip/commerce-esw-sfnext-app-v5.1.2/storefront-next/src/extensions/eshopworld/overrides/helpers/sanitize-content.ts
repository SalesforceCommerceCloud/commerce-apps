const allowedTags = new Set([
    'a',
    'abbr',
    'b',
    'blockquote',
    'br',
    'caption',
    'code',
    'dd',
    'div',
    'dl',
    'dt',
    'em',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'hr',
    'i',
    'img',
    'li',
    'ol',
    'p',
    'pre',
    's',
    'small',
    'span',
    'strong',
    'sub',
    'sup',
    'table',
    'tbody',
    'td',
    'tfoot',
    'th',
    'thead',
    'tr',
    'u',
    'ul',
]);

const droppedTags = new Set(['iframe', 'object', 'script', 'style', 'svg', 'math', 'template']);
const allowedAttributes = new Set([
    'alt',
    'class',
    'colspan',
    'height',
    'id',
    'lang',
    'role',
    'rowspan',
    'scope',
    'title',
    'width',
]);
const htmlNamespace = 'http://www.w3.org/1999/xhtml';

function isSafeUrl(value: string, attribute: 'href' | 'src'): boolean {
    try {
        const protocol = new URL(value, document.baseURI).protocol;
        return attribute === 'href'
            ? ['http:', 'https:', 'mailto:', 'tel:'].includes(protocol)
            : ['http:', 'https:'].includes(protocol);
    } catch {
        return false;
    }
}

function appendSanitizedNode(parent: Node, source: Node, targetDocument: Document): void {
    if (source.nodeType === Node.TEXT_NODE) {
        parent.appendChild(targetDocument.createTextNode(source.textContent ?? ''));
        return;
    }

    if (source.nodeType !== Node.ELEMENT_NODE) return;

    const sourceElement = source as Element;
    if (sourceElement.namespaceURI !== htmlNamespace) return;

    const tagName = sourceElement.tagName.toLowerCase();
    if (droppedTags.has(tagName)) return;

    if (!allowedTags.has(tagName)) {
        sourceElement.childNodes.forEach((child) => appendSanitizedNode(parent, child, targetDocument));
        return;
    }

    const safeElement = targetDocument.createElement(tagName);
    sourceElement.getAttributeNames().forEach((attribute) => {
        const value = sourceElement.getAttribute(attribute) ?? '';
        if (allowedAttributes.has(attribute) || attribute.startsWith('aria-') || attribute.startsWith('data-')) {
            safeElement.setAttribute(attribute, value);
        } else if ((attribute === 'href' || attribute === 'src') && isSafeUrl(value, attribute)) {
            safeElement.setAttribute(attribute, value);
        } else if (attribute === 'target' && ['_blank', '_self'].includes(value.toLowerCase())) {
            safeElement.setAttribute('target', value.toLowerCase());
            if (value.toLowerCase() === '_blank') safeElement.setAttribute('rel', 'noopener noreferrer');
        }
    });

    sourceElement.childNodes.forEach((child) => appendSanitizedNode(safeElement, child, targetDocument));
    parent.appendChild(safeElement);
}

export function appendSanitizedHtml(target: HTMLElement, markup: string): void {
    const parsed = new DOMParser().parseFromString(markup, 'text/html');
    const fragment = target.ownerDocument.createDocumentFragment();
    parsed.body.childNodes.forEach((child) => appendSanitizedNode(fragment, child, target.ownerDocument));
    target.replaceChildren(fragment);
}