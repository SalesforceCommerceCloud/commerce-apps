/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { siteContext } from '@salesforce/storefront-next-runtime/site-context';
import type { MiddlewareFunction, RouterContextProvider } from 'react-router';
import type { ShopperBasketsV2 } from '@/scapi';
import { createApiClients } from '@/lib/api-clients.server';
import { getLogger } from '@/lib/logger.server';
import { getBasket, updateBasketResource } from '@/middlewares/basket.server';

type Basket = ShopperBasketsV2.schemas['Basket'];

type EswBmConfigsResponse = {
    shopperPricingConfigs?: {
        retailerBaseCurrency?: string;
    };
};

type EswLocale = {
    countryCode?: string;
    isFixedPriceModel?: boolean;
};

/**
 * Returns the dynamic base price-book currency when a basket created in a
 * fixed-price country is opened in a configured dynamic-price country. The
 * dynamic-price flag comes from the storefront environment configuration and
 * the currency is read from the getBmConfigs SCAPI response.
 *
 * @param basket - Current shopper basket
 * @param context - Request context containing the active locale
 * @returns Configured base currency when the basket requires dynamic-price recalculation
 */
export async function getEswBasketRecalculationCurrency(
    basket: Basket,
    context: Readonly<RouterContextProvider>
): Promise<string | undefined> {
    const basketCountry = (basket as Basket & { c_eswShopperCurrency?: string }).c_eswShopperCurrency;
    const site = context.get(siteContext)?.site;
    const activeLocale = context.get(siteContext)?.locale?.id;
    const activeCountry = activeLocale?.split(/[-_]/).pop()?.toUpperCase();
    const activeCountryConfig = (site?.supportedLocales as EswLocale[] | undefined)?.find(
        (locale) => locale.countryCode === activeCountry
    );

    if (
        !basketCountry ||
        !activeCountry ||
        basketCountry === activeCountry ||
        activeCountryConfig?.isFixedPriceModel !== false
    ) {
        return undefined;
    }

    const siteId = site?.id;
    if (!siteId) {
        return undefined;
    }

    const clients = createApiClients(context);
    const { data } = await clients.eswCustom.getBmConfigs({
        params: {
            query: {
                siteId,
                c_country: activeCountry,
            },
        },
    });
    const bmConfigs = data as unknown as EswBmConfigsResponse;
    const baseCurrency = bmConfigs.shopperPricingConfigs?.retailerBaseCurrency;

    return typeof baseCurrency === 'string' && baseCurrency ? baseCurrency : undefined;
}

/**
 * Refreshes a stale fixed-price basket only for cart requests after a shopper
 * switches to a configured dynamic-price country, so the cart receives the
 * localized dynamic prices before rendering.
 */
export const eswBasketCountryMiddleware: MiddlewareFunction<Response> = async ({ request, context }, next) => {
    if (!/\/cart(?:\.data)?$/.test(new URL(request.url).pathname)) {
        return next();
    }

    try {
        const basket = (await getBasket(context, { ensureBasket: 'read' })).current;
        const recalculationCurrency = basket ? await getEswBasketRecalculationCurrency(basket, context) : undefined;

        if (!basket?.basketId || !recalculationCurrency) {
            return next();
        }

        const clients = createApiClients(context);
        const { data: updatedBasket } = await clients.shopperBasketsV2.updateBasket({
            params: { path: { basketId: basket.basketId } },
            body: { currency: recalculationCurrency },
        });
        updateBasketResource(context, updatedBasket);
    } catch (error) {
        getLogger(context).error('ESW basket country recalculation failed', {
            error,
        });
    }

    return next();
};
