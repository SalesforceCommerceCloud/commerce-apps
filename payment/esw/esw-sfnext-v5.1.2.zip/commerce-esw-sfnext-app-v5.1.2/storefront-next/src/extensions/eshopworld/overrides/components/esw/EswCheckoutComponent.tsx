/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { type MouseEvent, type ReactElement, useEffect, useRef, useState } from 'react';
import { useFetcher } from 'react-router';
import { Link } from '@/components/link';
import { Button } from '@/components/ui/button';
import { getEswConfigByKey, getEswShopperCurrencyConfigByKey } from '../../helpers/esw-helpers';
import { ESW_CLIENT_LAST_ORDER_ID_KEY } from '../../hooks/use-abandonment-cart-on-page-load';
import { ESW_BM_CONFIGS_UPDATED } from '../../hooks/use-bm-configs-on-page-load';
import { resourceRoutes, routes } from '@/route-paths';

interface EswOrderCreateActionData {
    success: boolean;
    orderNo?: string;
    order?: { c_eswPreOrderResponse?: { redirectUrl?: string } };
}

interface EswCheckoutComponentProps {
    basketId?: string;
    hasInventoryIssues: boolean;
    checkoutLabel: string;
    orderTotalLabel?: string;
    inventoryErrorId?: string;
    source?: 'cart' | 'miniCart';
    onStandardCheckoutClick?: () => void;
}

export default function EswCheckoutComponent({
    basketId,
    hasInventoryIssues,
    checkoutLabel,
    orderTotalLabel,
    inventoryErrorId,
    source = 'cart',
    onStandardCheckoutClick,
}: EswCheckoutComponentProps): ReactElement {
    const [isEswModuleEnabled, setIsEswModuleEnabled] = useState(false);
    const [isEswSupportedCurrency, setIsEswSupportedCurrency] = useState(false);
    const [isEswRedirectPending, setIsEswRedirectPending] = useState(false);
    const [eswLoaderText, setEswLoaderText] = useState('Connecting to secure checkout');

    const eswOrderFetcher = useFetcher<EswOrderCreateActionData>();
    const isEswRedirectStartedRef = useRef(false);

    useEffect(() => {
        const handlePageShow = (event: PageTransitionEvent) => {
            if (event.persisted && isEswRedirectStartedRef.current) {
                setIsEswRedirectPending(false);
            }
        };

        window.addEventListener('pageshow', handlePageShow);

        return () => {
            window.removeEventListener('pageshow', handlePageShow);
        };
    }, []);

    useEffect(() => {
        function readConfigs() {
            setIsEswModuleEnabled(Boolean(getEswConfigByKey('eswModuleEnabled')));
            setIsEswSupportedCurrency(Boolean(getEswShopperCurrencyConfigByKey('isEswSupported')));
            const loaderText = getEswConfigByKey('defaultLoaderText');
            if (typeof loaderText === 'string' && loaderText.trim()) {
                setEswLoaderText(loaderText);
            }
        }

        readConfigs();
        // Re-read whenever BM configs are refreshed (e.g. on route change).
        window.addEventListener(ESW_BM_CONFIGS_UPDATED, readConfigs);
        return () => window.removeEventListener(ESW_BM_CONFIGS_UPDATED, readConfigs);
    }, []);

    const isEswCheckout = isEswModuleEnabled && isEswSupportedCurrency;
    const buttonLabel =
        source === 'miniCart' && orderTotalLabel ? `${checkoutLabel} ${orderTotalLabel}` : checkoutLabel;
    const buttonClassName =
        source === 'cart'
            ? 'w-full text-sm mt-2'
            : 'flex self-stretch w-full h-10 px-8 py-2 justify-center items-center gap-2 bg-primary text-sm font-semibold leading-5 text-primary-foreground font-sans rounded-none shadow-2xs';
    const isCartSource = source === 'cart';

    const handleEswCheckout = (event: MouseEvent<HTMLAnchorElement>) => {
        if (!isEswCheckout) {
            onStandardCheckoutClick?.();
            return;
        }

        event.preventDefault();

        if (!basketId) {
            setIsEswRedirectPending(false);
            return;
        }

        setIsEswRedirectPending(true);
        const formData = new FormData();
        formData.append('basketId', basketId);
        void eswOrderFetcher.submit(formData, {
            method: 'POST',
            action: resourceRoutes.eswOrderCreate,
        });
    };

    useEffect(() => {
        if (isEswRedirectStartedRef.current) {
            return;
        }

        if (!eswOrderFetcher.data) {
            if (eswOrderFetcher.state === 'idle') {
                setIsEswRedirectPending(false);
            }
            return;
        }

        if (!eswOrderFetcher.data.success) {
            isEswRedirectStartedRef.current = false;
            setIsEswRedirectPending(false);
            return;
        }

        const redirectUrl = eswOrderFetcher.data.order?.c_eswPreOrderResponse?.redirectUrl;
        if (redirectUrl) {
            localStorage.setItem(ESW_CLIENT_LAST_ORDER_ID_KEY, eswOrderFetcher.data.orderNo ?? '');
            isEswRedirectStartedRef.current = true;
            window.location.href = redirectUrl;
            return;
        }

        isEswRedirectStartedRef.current = false;
        setIsEswRedirectPending(false);
    }, [eswOrderFetcher.state, eswOrderFetcher.data]);

    return (
        <>
            {isEswRedirectPending && (
                <div className="bg-foreground/95 fixed inset-0 z-[9999]">
                    <div className="flex h-full w-full items-center justify-center">
                        <div className="flex flex-col items-center gap-4">
                            <div className="border-background/30 border-t-background h-16 w-16 animate-spin rounded-full border-4" />
                            <p className="text-background text-sm font-medium">{eswLoaderText}</p>
                        </div>
                    </div>
                </div>
            )}

            {/* ESW-START: Checkout button (cart and miniCart) */}
            <Button
                asChild={!hasInventoryIssues}
                className={buttonClassName}
                disabled={isCartSource && hasInventoryIssues}
                aria-disabled={hasInventoryIssues}
                aria-describedby={isCartSource && hasInventoryIssues ? inventoryErrorId : undefined}
                size={!isCartSource ? 'lg' : undefined}>
                {isCartSource && hasInventoryIssues ? (
                    <span>{buttonLabel}</span>
                ) : (
                    <Link
                        to={routes.checkout}
                        onClick={handleEswCheckout}
                        aria-disabled={hasInventoryIssues}
                        className={!isCartSource && hasInventoryIssues ? 'pointer-events-none opacity-60' : undefined}>
                        {buttonLabel}
                    </Link>
                )}
            </Button>
            {/* ESW-END */}
        </>
    );
}
