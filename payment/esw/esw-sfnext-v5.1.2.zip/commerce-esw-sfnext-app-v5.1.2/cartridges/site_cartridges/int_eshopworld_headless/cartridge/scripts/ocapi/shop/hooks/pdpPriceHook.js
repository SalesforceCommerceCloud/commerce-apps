exports.modifyGETResponse = function (scriptProduct, doc) {

    // Script Includes
    let OCAPIHelper = require('*/cartridge/scripts/helper/eswOCAPIHelperHL');
    OCAPIHelper.eswPdpPriceConversions(scriptProduct, doc);

};
