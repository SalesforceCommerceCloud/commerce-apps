exports.modifyGETResponse = function (doc) {
    // Script Includes
    let OCAPIHelper = require('*/cartridge/scripts/helper/eswOCAPIHelperHL');
    OCAPIHelper.eswPlpPriceConversions(doc);
};
