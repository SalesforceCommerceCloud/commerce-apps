/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

/**
 * B2C Service Framework services for the Salesforce Core Scheduler org.
 *
 * The Core OAuth client-credentials secret lives on the B2C instance as a Service credential
 * (Business Manager > Administration > Operations > Services), NOT in storefront env — this is the
 * HLD's security model. Both services' credential URL is the Core My Domain origin, e.g.
 * `https://example.my.salesforce.com`.
 *
 * - `scheduler.core.token` : credential URL = Core origin; credential User = OAuth client_id;
 *   credential Password = OAuth client_secret. Exchanges a client-credentials access token.
 * - `scheduler.core.api`   : credential URL = Core origin (no user/password needed — Bearer auth).
 *   Calls Connect REST + Data API with the token.
 */

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

function stripTrailingSlash(url) {
    return String(url).replace(/\/+$/, '');
}

exports.tokenService = function () {
    return LocalServiceRegistry.createService('scheduler.core.token', {
        createRequest: function (service) {
            var cred = service.configuration.credential;
            service.URL = stripTrailingSlash(cred.URL) + '/services/oauth2/token';
            service.setRequestMethod('POST');
            service.addHeader('Content-Type', 'application/x-www-form-urlencoded');
            service.addHeader('Accept', 'application/json');
            return 'grant_type=client_credentials' +
                '&client_id=' + encodeURIComponent(cred.user) +
                '&client_secret=' + encodeURIComponent(cred.password);
        },
        parseResponse: function (service, response) {
            return JSON.parse(response.text);
        },
        // Never log the token request body (carries the client secret) or the response (carries the token).
        getRequestLogMessage: function () {
            return '[sfnext-appointment token request redacted]';
        },
        getResponseLogMessage: function () {
            return '[sfnext-appointment token response redacted]';
        },
        filterLogMessage: function () {
            return '';
        }
    });
};

/**
 * @param {Object} args - { method, path, token, body }
 */
exports.apiService = function () {
    return LocalServiceRegistry.createService('scheduler.core.api', {
        createRequest: function (service, args) {
            var cred = service.configuration.credential;
            service.URL = stripTrailingSlash(cred.URL) + args.path;
            service.setRequestMethod(args.method);
            service.addHeader('Authorization', 'Bearer ' + args.token);
            service.addHeader('Accept', 'application/json');
            if (args.body) {
                service.addHeader('Content-Type', 'application/json');
                return JSON.stringify(args.body);
            }
            return null;
        },
        parseResponse: function (service, response) {
            return response; // raw: caller inspects statusCode + text
        },
        getRequestLogMessage: function (request) {
            // Bodies here (availability window, appointment fields) are non-secret; the Bearer header
            // is not part of the logged body. Safe to log for diagnostics.
            return request;
        },
        getResponseLogMessage: function (response) {
            return response && response.text ? response.text : '';
        }
    });
};
