/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var Site = require('dw/system/Site');
var Logger = require('dw/system/Logger');
var svc = require('*/cartridge/scripts/services/schedulerCoreService');

var log = Logger.getLogger('sfnext-appointment', 'sfnext-appointment');

function escapeSoql(val) {
    return String(val).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

var EXTERNAL_ID_PATTERN = /^[A-Za-z0-9_\-]{1,64}$/;
function isValidExternalId(val) {
    return typeof val === 'string' && EXTERNAL_ID_PATTERN.test(val);
}

var _tokenCache = { token: null, expiry: 0 };
var TOKEN_MARGIN_MS = 5 * 60 * 1000;

/**
 * Non-secret Core scheduling config, read from site custom preferences (see impex
 * SitePreferences.xml). The Core origin + OAuth client id/secret live on the Service
 * credential, not here.
 */
function pref(name, fallback) {
    try {
        var v = Site.current.getCustomPreferenceValue(name);
        return v === null || v === undefined || v === '' ? fallback : v;
    } catch (e) {
        return fallback;
    }
}

function getConfig() {
    return {
        apiVersion: pref('sfnextSchedulerApiVersion', 'v64.0'),
        territoryId: pref('sfnextSchedulerTerritoryId', ''),
        workTypeGroupId: pref('sfnextSchedulerWorkTypeGroupId', ''),
        workTypeId: pref('sfnextSchedulerWorkTypeId', ''),
        parentRecordId: pref('sfnextSchedulerParentRecordId', ''),
        schedulingPolicyId: pref('sfnextSchedulerPolicyId', ''),
        serviceResourceId: pref('sfnextSchedulerResourceId', '')
    };
}

function mapStatus(status) {
    if (status === 400 || status === 404) return 'INVALID_REQUEST';
    if (status === 401 || status === 403) return 'SCHEDULER_AUTHORIZATION';
    if (status === 429) return 'SCHEDULER_RATE_LIMITED';
    return 'SCHEDULER_UNAVAILABLE';
}

/** Acquire a client-credentials access token from the Core org via the Service Framework. */
function getToken() {
    if (_tokenCache.token && Date.now() < _tokenCache.expiry) {
        return { ok: true, token: _tokenCache.token };
    }
    var res = svc.tokenService().call();
    if (!res.ok) {
        log.error('scheduler token failed status={0} msg={1}', res.error, res.errorMessage);
        return { ok: false, code: (res.error === 401 || res.error === 403) ? 'SCHEDULER_AUTHORIZATION' : 'SCHEDULER_UNAVAILABLE' };
    }
    var data = res.object;
    if (!data || !data.access_token) {
        return { ok: false, code: 'SCHEDULER_AUTHORIZATION' };
    }
    var ttl = data.expires_in ? Number(data.expires_in) * 1000 : 1800000;
    _tokenCache.token = data.access_token;
    _tokenCache.expiry = Date.now() + ttl - TOKEN_MARGIN_MS;
    return { ok: true, token: _tokenCache.token };
}

/**
 * Get consolidated availability for the configured territory + work-type group.
 * The Connect REST response is wrapped in a `result` envelope — unwrap it.
 * @param {Object} window - { startTime, endTime, storeId? } ISO 8601
 */
function getAvailability(window) {
    var cfg = getConfig();
    if (!cfg.workTypeGroupId) {
        return { ok: false, code: 'SCHEDULER_NOT_CONFIGURED' };
    }
    var tokenRes = getToken();
    if (!tokenRes.ok) {
        return { ok: false, code: tokenRes.code };
    }

    var territoryId = cfg.territoryId;
    var territoryTimezone = null;

    if (window.storeId) {
        if (!isValidExternalId(window.storeId)) {
            return { ok: false, code: 'INVALID_REQUEST' };
        }
        var soql = 'SELECT Id, OperatingHours.TimeZone FROM ServiceTerritory WHERE StoreId__c = \'' + escapeSoql(window.storeId) + '\' LIMIT 1';
        var lookupRes = svc.apiService().call({
            method: 'GET',
            path: '/services/data/' + cfg.apiVersion + '/query?q=' + encodeURIComponent(soql),
            token: tokenRes.token
        });
        if (!lookupRes.ok) {
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
        try {
            var lookupJson = JSON.parse(lookupRes.object.text);
            if (!lookupJson.records || !lookupJson.records[0] || !lookupJson.records[0].Id) {
                return { ok: false, code: 'INVALID_REQUEST' };
            }
            territoryId = lookupJson.records[0].Id;
            if (lookupJson.records[0].OperatingHours && lookupJson.records[0].OperatingHours.TimeZone) {
                territoryTimezone = lookupJson.records[0].OperatingHours.TimeZone;
            }
        } catch (e) {
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
    }

    if (!territoryId) {
        return { ok: false, code: 'SCHEDULER_NOT_CONFIGURED' };
    }

    var body = {
        startTime: window.startTime,
        endTime: window.endTime,
        territoryIds: [territoryId],
        workTypeGroupId: cfg.workTypeGroupId
    };
    if (cfg.schedulingPolicyId) {
        body.schedulingPolicyId = cfg.schedulingPolicyId;
    }
    if (cfg.serviceResourceId) {
        body.requiredResourceIds = [cfg.serviceResourceId];
    }

    var avRes = svc.apiService().call({
        method: 'POST',
        path: '/services/data/' + cfg.apiVersion + '/connect/scheduling/available-territory-slots',
        token: tokenRes.token,
        body: body
    });
    if (!avRes.ok && avRes.error === 401) {
        _tokenCache.token = null;
        _tokenCache.expiry = 0;
        var retryTokenRes = getToken();
        if (!retryTokenRes.ok) {
            return { ok: false, code: retryTokenRes.code };
        }
        avRes = svc.apiService().call({
            method: 'POST',
            path: '/services/data/' + cfg.apiVersion + '/connect/scheduling/available-territory-slots',
            token: retryTokenRes.token,
            body: body
        });
    }
    if (!avRes.ok) {
        log.error('scheduler availability failed status={0} msg={1}', avRes.error, avRes.errorMessage);
        return { ok: false, code: mapStatus(avRes.error) };
    }

    var json;
    try {
        json = JSON.parse(avRes.object.text);
    } catch (e) {
        return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
    }
    var envelope = json && json.result ? json.result : json;
    var territorySlots = (envelope && envelope.territorySlots) || [];
    var slots = [];
    for (var i = 0; i < territorySlots.length; i++) {
        var ts = territorySlots[i].slots || [];
        for (var j = 0; j < ts.length; j++) {
            slots.push({ startTime: ts[j].startTime, endTime: ts[j].endTime, resources: ts[j].resources });
        }
    }

    var advanceNoticeMinutes = Number(pref('sfnextAppointmentAdvanceNoticeMinutes', 120)) || 120;
    return { ok: true, slots: slots, timezone: territoryTimezone, advanceNoticeMinutes: advanceNoticeMinutes };
}

/**
 * Create a ServiceAppointment (no Contact — shopper identity on b2cCustomerId__c), then assign the
 * configured required resource so the slot is consumed. The Core record-triggered Flow emails the
 * confirmation.
 * @param {Object} input - { schedStartTime, schedEndTime, email, b2cCustomerId, subject?, storeId?, serviceId? }
 */
function bookAppointment(input) {
    var cfg = getConfig();
    if (!cfg.parentRecordId) {
        return { ok: false, code: 'SCHEDULER_NOT_CONFIGURED' };
    }
    var tokenRes = getToken();
    if (!tokenRes.ok) {
        return { ok: false, code: tokenRes.code };
    }

    var resolvedTerritoryId = cfg.territoryId;
    if (input.storeId) {
        if (!isValidExternalId(input.storeId)) {
            return { ok: false, code: 'INVALID_REQUEST' };
        }
        var territorySoql = 'SELECT Id FROM ServiceTerritory WHERE StoreId__c = \'' + escapeSoql(input.storeId) + '\' LIMIT 1';
        var territoryLookup = svc.apiService().call({
            method: 'GET',
            path: '/services/data/' + cfg.apiVersion + '/query?q=' + encodeURIComponent(territorySoql),
            token: tokenRes.token
        });
        if (!territoryLookup.ok) {
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
        try {
            var tJson = JSON.parse(territoryLookup.object.text);
            if (!tJson.records || !tJson.records[0] || !tJson.records[0].Id) {
                return { ok: false, code: 'INVALID_REQUEST' };
            }
            resolvedTerritoryId = tJson.records[0].Id;
        } catch (e) {
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
    }

    var resolvedWorkTypeId = cfg.workTypeId;
    if (input.serviceId) {
        if (!isValidExternalId(input.serviceId)) {
            return { ok: false, code: 'INVALID_REQUEST' };
        }
        var workTypeSoql = 'SELECT Id FROM WorkType WHERE ServiceId__c = \'' + escapeSoql(input.serviceId) + '\' LIMIT 1';
        var workTypeLookup = svc.apiService().call({
            method: 'GET',
            path: '/services/data/' + cfg.apiVersion + '/query?q=' + encodeURIComponent(workTypeSoql),
            token: tokenRes.token
        });
        if (!workTypeLookup.ok) {
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
        try {
            var wtJson = JSON.parse(workTypeLookup.object.text);
            if (!wtJson.records || !wtJson.records[0] || !wtJson.records[0].Id) {
                return { ok: false, code: 'INVALID_REQUEST' };
            }
            resolvedWorkTypeId = wtJson.records[0].Id;
        } catch (e) {
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
    }

    if (!resolvedTerritoryId || !resolvedWorkTypeId) {
        return { ok: false, code: 'SCHEDULER_NOT_CONFIGURED' };
    }

    var saBody = {
        ParentRecordId: cfg.parentRecordId,
        ServiceTerritoryId: resolvedTerritoryId,
        WorkTypeId: resolvedWorkTypeId,
        Status: 'Scheduled',
        SchedStartTime: input.schedStartTime,
        SchedEndTime: input.schedEndTime,
        Email: input.email,
        b2cCustomerId__c: input.b2cCustomerId
    };
    if (input.subject) {
        saBody.Subject = input.subject;
    }

    var saRes = svc.apiService().call({
        method: 'POST',
        path: '/services/data/' + cfg.apiVersion + '/sobjects/ServiceAppointment',
        token: tokenRes.token,
        body: saBody
    });
    if (!saRes.ok && saRes.error === 401) {
        _tokenCache.token = null;
        _tokenCache.expiry = 0;
        var saRetryTokenRes = getToken();
        if (!saRetryTokenRes.ok) {
            return { ok: false, code: saRetryTokenRes.code };
        }
        tokenRes = saRetryTokenRes;
        saRes = svc.apiService().call({
            method: 'POST',
            path: '/services/data/' + cfg.apiVersion + '/sobjects/ServiceAppointment',
            token: tokenRes.token,
            body: saBody
        });
    }
    if (!saRes.ok) {
        log.error('scheduler booking failed status={0} msg={1}', saRes.error, saRes.errorMessage);
        return { ok: false, code: mapStatus(saRes.error) };
    }

    var created;
    try {
        created = JSON.parse(saRes.object.text);
    } catch (e) {
        return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
    }
    if (!created || !created.id) {
        return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
    }

    // Assign the required resource so the slot is consumed (anti-double-booking).
    // If assignment fails, roll back by deleting the ServiceAppointment.
    if (cfg.serviceResourceId) {
        var arRes = svc.apiService().call({
            method: 'POST',
            path: '/services/data/' + cfg.apiVersion + '/sobjects/AssignedResource',
            token: tokenRes.token,
            body: {
                ServiceAppointmentId: created.id,
                ServiceResourceId: cfg.serviceResourceId,
                IsRequiredResource: true
            }
        });
        if (!arRes.ok) {
            log.error('scheduler assigned-resource failed sa={0} status={1} — rolling back SA', created.id, arRes.error);
            svc.apiService().call({
                method: 'DELETE',
                path: '/services/data/' + cfg.apiVersion + '/sobjects/ServiceAppointment/' + created.id,
                token: tokenRes.token
            });
            return { ok: false, code: 'SCHEDULER_UNAVAILABLE' };
        }
        var assignedResourceId = null;
        try {
            var ar = JSON.parse(arRes.object.text);
            if (ar && ar.id) {
                assignedResourceId = ar.id;
            }
        } catch (e) {
            // non-fatal parse error; AR was created (arRes.ok === true)
        }
        return { ok: true, serviceAppointmentId: created.id, assignedResourceId: assignedResourceId };
    }

    return { ok: true, serviceAppointmentId: created.id };
}

module.exports = {
    getAvailability: getAvailability,
    bookAppointment: bookAppointment
};
