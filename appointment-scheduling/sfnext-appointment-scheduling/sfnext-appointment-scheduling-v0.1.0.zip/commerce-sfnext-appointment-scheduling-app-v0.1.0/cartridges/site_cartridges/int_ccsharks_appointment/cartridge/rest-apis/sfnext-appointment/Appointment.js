/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var RESTResponseMgr = require('dw/system/RESTResponseMgr');
var Logger = require('dw/system/Logger');

var log = Logger.getLogger('sfnext-appointment', 'sfnext-appointment');

var ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/;

/** Map an internal scheduler error code to an HTTP status + SCAPI error render. */
function renderError(code) {
    var statuses = {
        INVALID_REQUEST: 400,
        SCHEDULER_NOT_CONFIGURED: 503,
        SCHEDULER_AUTHORIZATION: 502,
        SCHEDULER_RATE_LIMITED: 429,
        SCHEDULER_UNAVAILABLE: 503
    };
    var status = statuses[code] || 503;
    RESTResponseMgr.createError(status, code, 'Scheduler error', code).render();
}

function paramString(name) {
    var p = request.httpParameterMap.get(name);
    return p && p.submitted ? p.stringValue : null;
}

/**
 * GET /custom/sfnext-appointment/v1/appointment-availability
 *
 * Availability is public (same for every shopper); the SCAPI gateway enforces the
 * c_sfnext_appointment scope before this handler runs.
 */
exports.getAppointmentAvailability = function () {
    var schedulerCore = require('*/cartridge/scripts/helpers/schedulerCore');

    var startTime = paramString('startTime');
    var endTime = paramString('endTime');
    if (!startTime || !endTime || !ISO_DATETIME.test(startTime) || !ISO_DATETIME.test(endTime)) {
        RESTResponseMgr.createError(400, 'INVALID_REQUEST', 'Bad Request', 'startTime and endTime must be ISO 8601').render();
        return;
    }

    var storeId = paramString('storeId');
    var result = schedulerCore.getAvailability({ startTime: startTime, endTime: endTime, storeId: storeId || null });
    if (!result.ok) {
        renderError(result.code);
        return;
    }
    var successBody = { success: true, slots: result.slots };
    if (result.timezone) successBody.timezone = result.timezone;
    if (typeof result.advanceNoticeMinutes === 'number') successBody.advanceNoticeMinutes = result.advanceNoticeMinutes;
    RESTResponseMgr.createSuccess(successBody).render();
};
exports.getAppointmentAvailability.public = true;

/**
 * POST /custom/sfnext-appointment/v1/appointments
 *
 * `b2cCustomerId` is derived server-side from the authenticated SCAPI shopper session
 * (`session.customer.ID`). This prevents a caller with the `c_sfnext_appointment` scope
 * from booking under an arbitrary shopper identity — the value is never trusted from the
 * request body.
 */
exports.createAppointment = function () {
    var schedulerCore = require('*/cartridge/scripts/helpers/schedulerCore');

    // Derive b2cCustomerId from the authenticated shopper session — NEVER from the request body.
    // The SCAPI gateway validates the ShopperToken before this handler runs, so session.customer
    // is always the token-authenticated shopper.
    var b2cCustomerId = session.customer ? session.customer.ID : null;
    if (!b2cCustomerId) {
        // ShopperToken auth should guarantee a customer session; treat absence as auth failure.
        RESTResponseMgr.createError(401, 'SCHEDULER_AUTHORIZATION', 'Unauthorized', 'An active shopper session is required').render();
        return;
    }

    var body;
    try {
        body = JSON.parse(request.httpParameterMap.requestBodyAsString);
    } catch (e) {
        RESTResponseMgr.createError(400, 'INVALID_REQUEST', 'Bad Request', 'Request body is not valid JSON').render();
        return;
    }
    if (!body || typeof body !== 'object') {
        RESTResponseMgr.createError(400, 'INVALID_REQUEST', 'Bad Request', 'Missing request body').render();
        return;
    }

    var schedStartTime = body.schedStartTime;
    var schedEndTime = body.schedEndTime;
    var email = body.email;

    if (!ISO_DATETIME.test(String(schedStartTime)) || !ISO_DATETIME.test(String(schedEndTime))) {
        RESTResponseMgr.createError(400, 'INVALID_REQUEST', 'Bad Request', 'schedStartTime/schedEndTime must be ISO 8601').render();
        return;
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email)) || String(email).length > 254) {
        RESTResponseMgr.createError(400, 'INVALID_REQUEST', 'Bad Request', 'Invalid email').render();
        return;
    }

    var subject = typeof body.subject === 'string' ? body.subject : null;
    if (typeof subject === 'string' && subject.length > 255) {
        subject = subject.slice(0, 255);
    }

    var result = schedulerCore.bookAppointment({
        schedStartTime: schedStartTime,
        schedEndTime: schedEndTime,
        email: email,
        b2cCustomerId: b2cCustomerId,
        subject: subject,
        storeId: typeof body.storeId === 'string' ? body.storeId : null,
        serviceId: typeof body.serviceId === 'string' ? body.serviceId : null
    });

    if (!result.ok) {
        renderError(result.code);
        return;
    }
    log.info('appointment booked sa={0}', result.serviceAppointmentId);
    var successBody = { success: true, serviceAppointmentId: result.serviceAppointmentId };
    if (result.assignedResourceId) {
        successBody.assignedResourceId = result.assignedResourceId;
    }
    RESTResponseMgr.createSuccess(successBody).render();
};
exports.createAppointment.public = true;
