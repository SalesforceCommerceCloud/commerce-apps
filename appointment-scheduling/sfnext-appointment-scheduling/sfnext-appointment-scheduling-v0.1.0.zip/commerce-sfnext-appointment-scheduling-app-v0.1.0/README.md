# SFNext Appointment Scheduling (Salesforce Scheduler)

Backend-only Commerce App that lets a Storefront Next storefront book **boutique / store appointments** against **Salesforce Scheduler** on a separate Core Salesforce org.

## Architecture

- **Custom SCAPI** (`/custom/sfnext-appointment/v1/appointment-availability`, `/appointments`) served by this app's site cartridge.
- The cartridge reaches the Core org's **Connect REST** (`available-territory-slots`, `service-appointments`) through the B2C **Service Framework** using OAuth **client-credentials**. The Core credential lives on the B2C instance (Service Framework), never in storefront env.
- Shopper correlation is `ServiceAppointment.b2cCustomerId__c` — **no Core Contact**. Confirmation emails are sent by a Core-side record-triggered Flow.
- **Provider only** — the booking UX is a canonical, overridable Storefront Next template component (e.g. the luxury `boutique-booking` wizard), not shipped by this app.

## Capacity model

Boutique appointments use a **person ServiceResource** → an intrinsic **hard cap of one appointment per advisor per slot**. (The grocery delivery-slots companion app uses concurrent scheduling / `TimeSlot.MaxAppointments` for an N-per-window soft cap.)

## Install (private)

`b2c cap validate <this dir>` then `b2c cap install <this dir> --site-id <SITE>`, then complete the steps in `app-configuration/tasksList.json`.

## Prerequisites (Core org, one-time)

A provisioned Salesforce Scheduler Core org: ServiceTerritory + WorkType/WorkTypeGroup + OperatingHours, a person ServiceResource, the `b2cCustomerId__c` field, the confirmation Flow + verified Org-Wide Email Address, an External Client App (client-credentials) + integration user with the Scheduler PSL. See the HLD (W-24428182).
