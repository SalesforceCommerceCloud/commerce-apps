'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'calculate');

/**
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @returns {string}
 */
function getContainerIdentifier(lineItemCtnr) {
    try {
        if (lineItemCtnr && typeof lineItemCtnr.getUUID === 'function') {
            return lineItemCtnr.getUUID();
        }
        if (lineItemCtnr && typeof lineItemCtnr.getOrderNo === 'function') {
            return lineItemCtnr.getOrderNo();
        }
    } catch (e) {
        // ignore
    }
    return 'unknown';
}

/**
 * Calculate taxes using the AvaTax API.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate taxes for
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.calculate = function(lineItemCtnr) {
    if (!avataxHelper.getConfig().taxCalculation) {
        logger.warn('AvaTax not enabled for this site');
        return new Status(Status.OK, 'AVATAX_DISABLED', 'AvaTax not enabled for this site.');
    }

    if (!lineItemCtnr) {
        logger.warn('Empty basket passed to tax calculation');
        return new Status(Status.OK, 'EMPTY_BASKET', 'No basket provided for tax calculation.');
    }

    try {
        var buildResult = avataxHelper.buildTransactionModel(lineItemCtnr);
        var transactionModel = buildResult.model;
        var lineUUIDMap = buildResult.lineUUIDMap;

        if (!transactionModel.lines || transactionModel.lines.length === 0) {
            return new Status(Status.OK, 'NO_TAXABLE_ITEMS', 'No taxable line items found in basket.');
        }

        var response = avataxHelper.callAvaTaxAPI(transactionModel);

        if (!response.success) {
            logger.error('AvaTax API call failed: ' + JSON.stringify(response.details));

            // Fall back to zero tax on error
            setZeroTax(lineItemCtnr);

            return new Status(Status.OK, 'TAX_API_ERROR', 'AvaTax API call failed. Tax set to zero. Error: ' + JSON.stringify(response.details));
        }

        if (response.deduplicated) {
            if (response.data) {
                try {
                    avataxHelper.applyTaxesToBasket(lineItemCtnr, response.data, lineUUIDMap);
                } catch (applyError) {
                    logger.error('AvaTax tax apply failed (deduplicated): ' + applyError.message + '\n' + applyError.stack);
                    setZeroTax(lineItemCtnr);
                    return new Status(Status.OK, 'TAX_APPLY_EXCEPTION',
                        'Tax apply failed after deduplicated response. Tax set to zero. Error: ' + applyError.message);
                }
            }

            // logger.warn('AvaTax CreateTransaction request (deduplicated): ' + JSON.stringify(transactionModel));
            // if (response.data) {
            //     logger.warn('AvaTax CreateTransaction response (deduplicated): ' + JSON.stringify(response.data));
            // }

            return new Status(Status.OK, 'DEDUPLICATED', 'Tax calculation skipped — basket unchanged since last call.');
        }

        try {
            avataxHelper.applyTaxesToBasket(lineItemCtnr, response.data, lineUUIDMap);
        } catch (applyError) {
            logger.error('AvaTax tax apply failed: ' + applyError.message + '\n' + applyError.stack);
            setZeroTax(lineItemCtnr);
            return new Status(Status.OK, 'TAX_APPLY_EXCEPTION',
                'Tax apply failed. Tax set to zero. Error: ' + applyError.message);
        }

        // logger.warn('AvaTax CreateTransaction request (checkout): ' + JSON.stringify(transactionModel));
        // if (response.data) {
        //     logger.warn('AvaTax CreateTransaction response (checkout): ' + JSON.stringify(response.data));
        // }

        return new Status(Status.OK, 'TAX_CALCULATED', 'Tax successfully calculated and applied.');
    } catch (e) {
        logger.error('Error during tax calculation: ' + e.message + '\n' + e.stack);

        // Fall back to zero tax on exception. Return OK so SCAPI basket mutations
        // (shipping method, address) do not fail with 500 Internal Server Error.
        setZeroTax(lineItemCtnr);

        return new Status(Status.OK, 'TAX_CALCULATION_EXCEPTION',
            'Tax calculation failed with exception. Tax set to zero. Error: ' + e.message);
    }
};

/**
 * Sets all line items to zero tax (fallback for errors)
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order
 */
function setZeroTax(lineItemCtnr) {
    var lineItems = lineItemCtnr.getAllLineItems().iterator();
    while (lineItems.hasNext()) {
        try {
            avataxHelper.setLineItemTaxToZero(lineItems.next());
        } catch (e) {
            // Some line items may not support tax (e.g., price adjustments)
        }
    }
    if (typeof lineItemCtnr.updateTotals === 'function') {
        lineItemCtnr.updateTotals();
    }
}

