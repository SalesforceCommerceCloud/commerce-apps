'use strict';

/**
 * Legacy SCAPI tax hook (dw.order.calculateTax).
 *
 * Invoked by dw.order.calculate during basket recalculation when SCAPI hook
 * execution is enabled. Storefront Next may not reach sfcc.app.tax.calculate
 * if PUT /baskets/{id}/storefront returns 403 — this hook provides the
 * headless/PWA fallback path documented by Avalara for composable storefronts.
 */
var calculateHook = require('./calculate');

/**
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order
 * @returns {dw.system.Status}
 */
exports.calculateTax = function (lineItemCtnr) {
    return calculateHook.calculate(lineItemCtnr);
};
