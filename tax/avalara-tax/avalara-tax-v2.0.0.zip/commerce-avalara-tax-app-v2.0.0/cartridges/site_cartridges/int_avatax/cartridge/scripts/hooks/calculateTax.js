'use strict';

/**
 * Legacy SCAPI tax hook (dw.order.calculateTax).
 *
 * Invoked by dw.order.calculate during basket recalculation when SCAPI hook
 * execution is enabled. Storefront Next may not reach sfcc.app.tax.calculate
 * if PUT /baskets/{id}/storefront returns 403 — this hook provides the
 * headless/PWA fallback path documented by Avalara for composable storefronts.
 */
var calculateHook = require('./calculate');
var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var logger = Logger.getLogger('AvaTax', 'calculateTax');

/**
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order
 * @returns {dw.system.Status}
 */
exports.calculateTax = function (lineItemCtnr) {
    try {
        return calculateHook.calculate(lineItemCtnr);
    } catch (e) {
        logger.error('Unhandled error in dw.order.calculateTax hook: ' + e.message + '\n' + e.stack);
        return new Status(Status.ERROR, 'TAX_CALCULATION_EXCEPTION', 'Tax calculation failed.');
    }
};
