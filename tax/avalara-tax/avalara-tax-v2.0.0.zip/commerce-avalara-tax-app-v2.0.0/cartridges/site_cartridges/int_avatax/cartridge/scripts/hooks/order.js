'use strict';

var Logger = require('dw/system/Logger');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'order');

/**
 * Posts a SalesInvoice to AvaTax after SCAPI order creation.
 * Required for headless storefronts where sfcc.app.tax.commit may not run.
 *
 * @param {dw.order.Order} order
 */
exports.afterPOST = function (order) {
    if (!avataxHelper.getConfig().taxCalculation) {
        return;
    }

    var orderNo = order.getOrderNo();

    try {
        var response = avataxHelper.finalizeOrderTransaction(order);

        if (!response.success) {
            logger.error('AvaTax order finalization failed for order ' + orderNo + ': ' +
                (response.error || JSON.stringify(response.details)));
        }
    } catch (e) {
        logger.error('Exception during AvaTax order finalization for order ' + orderNo + ': ' +
            e.message + '\n' + e.stack);
    }
};
