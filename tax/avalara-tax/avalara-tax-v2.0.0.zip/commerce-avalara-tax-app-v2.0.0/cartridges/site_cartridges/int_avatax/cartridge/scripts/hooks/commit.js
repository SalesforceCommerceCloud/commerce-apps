'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'commit');

/**
 * Commit tax transaction with AvaTax after order placement.
 *
 * @param {dw.order.Order} order - The placed order
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.commit = function (order) {
    if (!avataxHelper.getConfig().taxCalculation) {
        logger.warn('AvaTax not enabled for this site');
        return new Status(Status.ERROR, 'AVATAX_DISABLED', 'AvaTax not enabled for this site.');
    }

    var orderNo = order.getOrderNo();

    try {
        // Creates the order's SalesInvoice in AvaTax (never created during basket calculate,
        // which only ever produces an uncommitted SalesOrder quote keyed by basket UUID) and
        // commits it in the same call when AVSettings.commitTransactions is enabled.
        var response = avataxHelper.finalizeOrderTransaction(order);

        if (!response.success) {
            var errorDetail = response.details ? JSON.stringify(response.details) : response.error;
            logger.error('AvaTax commit failed for order ' + orderNo + ': ' + errorDetail);
            return new Status(Status.ERROR, 'TAX_COMMIT_FAILED', 'Failed to commit tax for order ' + orderNo + '. Error: ' + errorDetail);
        }

        return new Status(Status.OK, 'TAX_COMMITTED', 'Tax transaction committed for order ' + orderNo + '.');
    } catch (e) {
        logger.error('Exception during tax commit for order ' + orderNo + ': ' + e.message + '\n' + e.stack);
        return new Status(Status.ERROR, 'TAX_COMMIT_EXCEPTION', 'Tax commit failed with exception for order ' + orderNo + '. Error: ' + e.message);
    }
};
