/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

/**
 * Builds an SFRA-style structured log payload with safe defaults.
 *
 * @param {string} connectorName
 * @param {string} connectorVersion
 * @param {Object} params
 * @returns {Object}
 */
function buildStructuredLogEntry(connectorName, connectorVersion, params) {
    var safeParams = params || {};
    var clientString = 'SF B2C Commerce || ' + connectorVersion;
    var entry = {
        CallerAccuNum: safeParams.callerAccuNum || '',
        AvaTaxEnvironment: safeParams.avaTaxEnvironment || '',
        ERPDetails: safeParams.erpDetails || 'Salesforce',
        ConnectorName: connectorName || '',
        ConnectorVersion: connectorVersion || '',
        ClientString: safeParams.clientString || clientString,
        Source: safeParams.source || 'Backend hook - dw.order.calculateTax',
        Operation: safeParams.operation || '',
        Message: safeParams.message || '',
        LogType: safeParams.logType || 'Debug',
        LogLevel: safeParams.logLevel || 'Informational',
        FunctionName: safeParams.functionName || '',
        DocCode: safeParams.docCode || '',
        DocType: safeParams.docType || 'SalesOrder',
        Error: !!safeParams.error,
        CreationDate: new Date()
    };

    if (safeParams.errorType) {
        entry.ErrorType = safeParams.errorType;
    }
    if (safeParams.lineCount !== undefined) {
        entry.LineCount = safeParams.lineCount;
    }
    if (safeParams.connectorTime !== undefined) {
        entry.ConnectorTime = safeParams.connectorTime;
    }
    if (safeParams.latency !== undefined) {
        entry.ConnectorLatency = safeParams.latency;
    }
    return entry;
}

module.exports = {
    buildStructuredLogEntry: buildStructuredLogEntry
};
