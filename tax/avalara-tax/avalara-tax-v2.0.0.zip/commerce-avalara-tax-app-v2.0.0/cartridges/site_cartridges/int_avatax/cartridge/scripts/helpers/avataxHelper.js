'use strict';

var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var avataxService = require('~/cartridge/scripts/services/avataxService');
var buildStructuredLogEntry = require('./avataxLogger').buildStructuredLogEntry;

var logger = Logger.getLogger('AvaTax', 'avataxHelper');
var CONNECTOR_NAME = avataxService.CONNECTOR_NAME;
var CONNECTOR_VERSION = avataxService.CONNECTOR_VERSION;

// AvaTax setting preference (synced from BM)
var settingsObject = {};
try {
    settingsObject = JSON.parse(Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (e) {
    logger.warn('Could not parse AVSettings: ' + e.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = {};
}

/**
 * Utility class for merchant settings from AVSettings.
 */
function AvataxHelper() {}

AvataxHelper.prototype = {
    getCustomCustomerAttribute: function () {
        return settingsObject.configs.customCustomerAttribute || '';
    },
    getCustomerCodePreference: function () {
        return settingsObject.configs.useCustomCustomerCode || 'customer_number';
    },
    saveTransactionsToAvatax: function () {
        return !!settingsObject.configs.saveTransactions;
    },
    commitTransactionsToAvatax: function () {
        return !!settingsObject.configs.commitTransactions;
    },
    getDefaultShippingMethodTaxCode: function () {
        return settingsObject.configs.defaultShippingMethodTaxCode || 'FR';
    },
    getDefaultProductTaxCode: function () {
        return 'P0000000';
    },
    getShipFromLocationCode: function () {
        return settingsObject.configs.locationCode || '';
    },
    getShipFromLine1: function () {
        return settingsObject.configs.line1 || '';
    },
    getShipFromLine2: function () {
        return settingsObject.configs.line2 || '';
    },
    getShipFromLine3: function () {
        return settingsObject.configs.line3 || '';
    },
    getShipFromCity: function () {
        return settingsObject.configs.city || '';
    },
    getShipFromStateCode: function () {
        return settingsObject.configs.state || '';
    },
    getShipFromZipCode: function () {
        return settingsObject.configs.zipCode || '';
    },
    getShipFromCountryCode: function () {
        return settingsObject.configs.countryCode || '';
    },
    getCompanyCode: function () {
        return settingsObject.configs.companyCode || 'DEFAULT';
    },
    isTaxCalculationEnabled: function () {
        return !!settingsObject.configs.taxCalculation;
    },
    getTaxationPolicy: function () {
        if (settingsObject.configs.taxationpolicy) {
            return settingsObject.configs.taxationpolicy.toString();
        }
        var TaxMgr = require('dw/order/TaxMgr');
        return TaxMgr.getTaxationPolicy() === TaxMgr.TAX_POLICY_NET ? 'net' : 'gross';
    }
};

var avataxSettingsHelper = new AvataxHelper();

/**
 * Emits a structured log entry matching the Avalara connector logging standard.
 * Uses INFO level for performance/instrumentation, ERROR level for errors/exceptions.
 *
 * @param {Object} params - Log parameters
 */
function logStructured(params) {
    var safeParams = params || {};
    var entry = buildStructuredLogEntry(CONNECTOR_NAME, CONNECTOR_VERSION, safeParams);
    if (safeParams.error) {
        logger.error(JSON.stringify(entry));
    } else {
        logger.info(JSON.stringify(entry));
    }
}

/**
 * Gets AvaTax configuration from parsed AVSettings.configs.
 *
 * @returns {Object} Configuration object
 */
function getConfig() {
    return {
        taxCalculation: avataxSettingsHelper.isTaxCalculationEnabled(),
        addressValidation: settingsObject.configs.addressValidation !== undefined ?
            !!settingsObject.configs.addressValidation : true,
        saveTransactions: avataxSettingsHelper.saveTransactionsToAvatax(),
        commitTransactions: avataxSettingsHelper.commitTransactionsToAvatax(),
        companyCode: avataxSettingsHelper.getCompanyCode(),
        customCustomerAttribute: avataxSettingsHelper.getCustomCustomerAttribute(),
        useCustomCustomerCode: avataxSettingsHelper.getCustomerCodePreference(),
        defaultShippingMethodTaxCode: avataxSettingsHelper.getDefaultShippingMethodTaxCode(),
        locationCode: avataxSettingsHelper.getShipFromLocationCode(),
        line1: avataxSettingsHelper.getShipFromLine1(),
        line2: avataxSettingsHelper.getShipFromLine2(),
        line3: avataxSettingsHelper.getShipFromLine3(),
        city: avataxSettingsHelper.getShipFromCity(),
        state: avataxSettingsHelper.getShipFromStateCode(),
        zipCode: avataxSettingsHelper.getShipFromZipCode(),
        countryCode: avataxSettingsHelper.getShipFromCountryCode(),
        taxationpolicy: avataxSettingsHelper.getTaxationPolicy(),
        companyId: settingsObject.configs.companyId || ''
    };
}

/**
 * Resolves the customer code to send to AvaTax based on ATCustomerCode preference.
 * Supports 4 strategies: customer_number, customer_email, custom_attribute, guest fallback.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket or order
 * @returns {string} Customer code for AvaTax
 */
function getCustomerCode(basket) {
    var customerCodePref = avataxSettingsHelper.getCustomerCodePreference();
    var customer = basket.getCustomer();

    if (customer && customer.profile) {
        var profile = customer.profile;

        if (customerCodePref === 'customer_number') {
            return profile.customerNo;
        }

        if (customerCodePref === 'customer_email') {
            return basket.getCustomerEmail() || profile.email;
        }

        if (customerCodePref === 'custom_attribute') {
            var customAttr = avataxSettingsHelper.getCustomCustomerAttribute();
            if (customAttr) {
                try {
                    var customValue = profile[customAttr.toString().trim()];
                    if (customValue) {
                        return customValue;
                    }
                } catch (e) {
                    logger.warn('Cannot find custom attribute "' + customAttr + '" on customer profile. Falling back to customerNo. Error: ' + e.message);
                }
            }
            return profile.customerNo;
        }

        return profile.customerNo;
    }

    return basket.getCustomerEmail() || 'guest-cust-code';
}

/**
 * Returns true when AVSettings taxation policy is gross.
 *
 * @returns {boolean}
 */
function isGrossTaxationPolicy() {
    return avataxSettingsHelper.getTaxationPolicy() === 'gross';
}

/**
 * Converts calculateTaxHelper SortedMaps into the lineUUIDMap used for tax application.
 *
 * @param {dw.util.SortedMap} uuidLineNumbersMap
 * @param {dw.util.SortedMap} lineIdShipmentIdMap
 * @returns {Object}
 */
function buildLineUUIDMap(uuidLineNumbersMap, lineIdShipmentIdMap) {
    var lineUUIDMap = {};
    var keyIterator = uuidLineNumbersMap.keySet().iterator();

    while (keyIterator.hasNext()) {
        var lineNumber = keyIterator.next();
        var uuid = uuidLineNumbersMap.get(lineNumber);
        var itemIdShipmentId = lineIdShipmentIdMap.get(lineNumber) || '';
        var parts = itemIdShipmentId.split('|');
        var lineInfo = {
            uuid: uuid,
            shipmentId: parts[1] || '',
            itemId: parts[0] || ''
        };
        var numericKey = parseInt(lineNumber, 10);

        // AvaTax may return lineNumber as number or string — index both.
        lineUUIDMap[numericKey] = lineInfo;
        lineUUIDMap[lineNumber] = lineInfo;
    }

    return lineUUIDMap;
}

/**
 * Returns true when any AvaTax line includes hsCode (cross-border / lineLevelAddress).
 *
 * @param {Array} lines - Transaction lines from calculateTaxHelper
 * @returns {boolean}
 */
function transactionHasCrossBorderHsCode(lines) {
    if (!lines || !lines.length) {
        return false;
    }

    for (var i = 0; i < lines.length; i++) {
        if (lines[i].hsCode) {
            return true;
        }
    }

    return false;
}

/**
 * Builds the AvaTax CreateTransaction request payload.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket or order
 * @returns {Object} Object with {model: transactionModel, lineUUIDMap: {lineNumber: UUID}}
 */
function buildTransactionModel(basket) {
    var calculateTaxHelper = require('~/cartridge/scripts/helpers/calculateTaxHelper');
    var customer = basket.getCustomer();
    var customerTaxId = (customer && customer.profile) ? customer.profile.taxID : null;
    var isSellerImporterOfRecord = (customer && customer.profile) ?
        customer.profile.custom.ATisSellerImporterOfRecord : false;

    var allLineItemsObj = calculateTaxHelper.getAllLineItems(basket);
    var lines = allLineItemsObj.lines;
    var lineUUIDMap = buildLineUUIDMap(
        allLineItemsObj.uuidLineNumbersMap,
        allLineItemsObj.lineIdShipmentIdMap
    );

    // Cross-border hardcode: products with hsCode in lineLevelAddress.json are seller IoR.
    if (!isSellerImporterOfRecord && transactionHasCrossBorderHsCode(lines)) {
        isSellerImporterOfRecord = true;
    }

    if (lines.length === 0) {
        logger.debug('No taxable line items found for basket ' + basket.getUUID());
    }

    var orderNo = getOrderNoFromContainer(basket);
    var documentCode = orderNo || basket.getUUID();
    var isOrderDocument = !!orderNo;

    var transactionModel = {
        code: documentCode,
        type: isOrderDocument && avataxSettingsHelper.saveTransactionsToAvatax() ? 'SalesInvoice' : 'SalesOrder',
        companyCode: avataxSettingsHelper.getCompanyCode(),
        date: new Date().toISOString().split('T')[0],
        customerCode: getCustomerCode(basket),
        currencyCode: basket.getCurrencyCode(),
        businessIdentificationNo: customerTaxId,
        isSellerImporterOfRecord: isSellerImporterOfRecord,
        debugLevel: 'Normal',
        serviceMode: 'Automatic',
        lines: lines,
        commit: !!(isOrderDocument && avataxSettingsHelper.commitTransactionsToAvatax())
    };

    if (session.privacy.deliveryTerms) {
        transactionModel.parameters = transactionModel.parameters || [];
        transactionModel.parameters.push({
            name: 'DeliveryTerms',
            value: session.privacy.deliveryTerms
        });
    }

    return {
        model: transactionModel,
        lineUUIDMap: lineUUIDMap
    };
}

/** Max chars for session tax snapshot — SFCC api.session.maxStringLength warn threshold is 1200. */
var SESSION_TAX_SNAPSHOT_MAX_LENGTH = 1150;

/**
 * Builds a minimal AvaTax response for session caching (tax application only).
 * Full CreateTransaction responses exceed SFCC session string quotas.
 *
 * @param {Object} avaTaxResponse - Full AvaTax API response
 * @returns {Object|null} Compact response or null when empty
 */
function compactAvaTaxResponseForSession(avaTaxResponse) {
    if (!avaTaxResponse || !avaTaxResponse.lines || !avaTaxResponse.lines.length) {
        return null;
    }

    var compact = {
        totalTax: avaTaxResponse.totalTax || 0,
        lines: []
    };

    for (var i = 0; i < avaTaxResponse.lines.length; i++) {
        var line = avaTaxResponse.lines[i];
        var compactLine = {
            lineNumber: getResponseLineNumber(line),
            number: getResponseLineNumber(line),
            tax: line.tax || 0,
            taxableAmount: line.taxableAmount || 0
        };

        compact.lines.push(compactLine);
    }

    return compact;
}

/**
 * Reads a cached compact tax snapshot from session.
 *
 * @returns {Object|null}
 */
function readCachedTaxSnapshot() {
    var snapshotJson = session.custom.avataxTaxSnapshot;
    if (!snapshotJson) {
        return null;
    }

    try {
        return JSON.parse(snapshotJson);
    } catch (e) {
        logger.warn('Could not parse cached AvaTax tax snapshot: ' + e.message);
        delete session.custom.avataxTaxSnapshot;
        return null;
    }
}

/**
 * Stores a compact tax snapshot in session when it fits platform quotas.
 *
 * @param {Object} avaTaxResponse - Full AvaTax API response
 */
function storeTaxSnapshotInSession(avaTaxResponse) {
    delete session.custom.avataxLastResponse;

    var compact = compactAvaTaxResponseForSession(avaTaxResponse);
    if (!compact) {
        delete session.custom.avataxTaxSnapshot;
        return;
    }

    var snapshotJson = JSON.stringify(compact);
    if (snapshotJson.length > SESSION_TAX_SNAPSHOT_MAX_LENGTH) {
        logger.warn('AvaTax tax snapshot too large for session (' + snapshotJson.length +
            ' chars) — skipping session cache to avoid quota errors.');
        delete session.custom.avataxTaxSnapshot;
        return;
    }

    session.custom.avataxTaxSnapshot = snapshotJson;
}

/**
 * Calls AvaTax CreateTransaction API with request deduplication.
 * Hashes the transaction model and compares against the session to skip
 * redundant API calls when the basket hasn't changed.
 *
 * @param {Object} transactionModel - The transaction request payload
 * @returns {Object} Response object with {success: boolean, data: Object, error: String, deduplicated: boolean}
 */
function callAvaTaxAPI(transactionModel) {
    var murmurhash = require('~/cartridge/scripts/helpers/murmurhash');
    var enterTime = Date.now();
    var modelJson = JSON.stringify(transactionModel);
    var hash = murmurhash.hashBytes(modelJson, modelJson.length, 523);

    // Never stash full request JSON in session — exceeds api.session.maxStringLength (2000).
    delete session.custom.avataxLastRequest;

    // Use == (loose equality) because session.custom may store the number as a string
    if (session.custom.avataxtransactionmodel && session.custom.avataxtransactionmodel == hash) {
        var cachedResponse = readCachedTaxSnapshot();
        if (cachedResponse) {
            return { success: true, data: cachedResponse, deduplicated: true };
        }
        // Stale hash without a readable snapshot — clear and recalculate via API.
        delete session.custom.avataxtransactionmodel;
        delete session.custom.avataxTaxSnapshot;
    }

    var response = avataxService.createTransaction(transactionModel, 'Details');

    var completionTime = Date.now();
    var connectorTime = (completionTime - enterTime) - (response.latency || 0);

    if (response.success) {
        session.custom.avataxtransactionmodel = hash;
        if (response.data) {
            storeTaxSnapshotInSession(response.data);
        }

        logger.warn('AvaTax CreateTransaction request (api): ' + JSON.stringify(transactionModel));
        logger.warn('AvaTax CreateTransaction response (api): ' + JSON.stringify(response.data));

        logStructured({
            operation: 'CreateTransaction',
            docCode: transactionModel.code || '',
            logType: 'Performance',
            logLevel: 'Informational',
            lineCount: transactionModel.lines ? transactionModel.lines.length : 0,
            connectorTime: connectorTime,
            latency: response.latency || 0,
            message: 'CreateTransaction succeeded. Lines: ' + (transactionModel.lines ? transactionModel.lines.length : 0) +
                ', Latency: ' + (response.latency || 0) + 'ms, ConnectorTime: ' + connectorTime + 'ms'
        });
    } else {
        logStructured({
            operation: 'CreateTransaction',
            docCode: transactionModel.code || '',
            logType: 'Debug',
            logLevel: 'Error',
            error: true,
            errorType: 'Data',
            lineCount: transactionModel.lines ? transactionModel.lines.length : 0,
            connectorTime: connectorTime,
            latency: response.latency || 0,
            message: 'CreateTransaction failed: ' + response.error
        });
    }

    return response;
}

/**
 * Applies tax details to a line item using the multilevel tax API.
 *
 * @param {dw.order.LineItem} lineItem - Basket line item
 * @param {Object} resLine - AvaTax response line
 * @param {string} currencyCode - Basket currency code
 * @param {Function} ArrayList - dw/util/ArrayList constructor
 * @param {Function} LineItemTax - dw/order/LineItemTax constructor
 */
/**
 * @returns {boolean} true when multilevel tax rows were applied to the line item
 */
function applyMultilevelTaxesToLineItem(lineItem, resLine, currencyCode, ArrayList, LineItemTax) {
    var Money = require('dw/value/Money');
    var taxItems = new ArrayList();
    var details = resLine.details || [];
    var responseLineNumber = getResponseLineNumber(resLine);
    var maxTaxItems = 10;
    var itemsToApply = details.length > maxTaxItems ? details.slice(0, maxTaxItems) : details;

    if (!itemsToApply.length) {
        return false;
    }

    if (details.length > maxTaxItems) {
        logger.warn('AvaTax returned ' + details.length + ' tax details for line ' + responseLineNumber +
            '. Only the first ' + maxTaxItems + ' tax details were applied.');
    }

    for (var j = 0; j < itemsToApply.length; j++) {
        var detail = itemsToApply[j];
        var jurisdictionType = detail.jurisdictionType || 'UNKNOWN';
        var jurisdictionName = detail.jurisName || 'UNKNOWN';
        var taxId = jurisdictionType + ':' + jurisdictionName;
        var detailRate = (detail.rate === null || detail.rate === undefined) ? 0 : detail.rate;
        var detailTax = (detail.tax === null || detail.tax === undefined) ? 0 : detail.tax;

        taxItems.add(new LineItemTax(taxId, detailRate, new Money(detailTax, currencyCode)));
    }

    lineItem.setTaxes(taxItems);
    return true;
}

/**
 * Returns the order number when the container is an order, otherwise null.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @returns {string|null}
 */
function getOrderNoFromContainer(lineItemCtnr) {
    var Order = require('dw/order/Order');
    if (lineItemCtnr instanceof Order) {
        return lineItemCtnr.getOrderNo();
    }
    return null;
}

/**
 * Detects product-level shipping line items (per-unit shipping surcharges on a PLI).
 *
 * @param {dw.order.LineItem} lineItem
 * @returns {boolean}
 */
function isProductShippingLineItem(lineItem) {
    var ProductShippingLineItem = require('dw/order/ProductShippingLineItem');
    return lineItem instanceof ProductShippingLineItem;
}

/**
 * Detects product line items. Excludes ProductShippingLineItem — on SFCC it can
 * satisfy instanceof ProductLineItem but throws SCRIPT_FIELD_ACCESS when reading
 * product-only properties such as productID or bonusProductLineItem.
 *
 * @param {dw.order.LineItem} lineItem
 * @returns {boolean}
 */
function isProductLineItem(lineItem) {
    var ProductLineItem = require('dw/order/ProductLineItem');
    return lineItem instanceof ProductLineItem && !isProductShippingLineItem(lineItem);
}

/**
 * Detects shipment-level shipping line items.
 *
 * @param {dw.order.LineItem} lineItem
 * @returns {boolean}
 */
function isShippingLineItem(lineItem) {
    var ShippingLineItem = require('dw/order/ShippingLineItem');
    return lineItem instanceof ShippingLineItem;
}

/**
 * Sets a line item tax to zero using APIs compatible with and without multilevel tax.
 *
 * @param {dw.order.LineItem} lineItem
 */
function setLineItemTaxToZero(lineItem) {
    try {
        lineItem.updateTax(0);
        return;
    } catch (e) {
        // Fall back to multilevel API when available
    }

    try {
        var ArrayList = require('dw/util/ArrayList');
        lineItem.setTaxes(new ArrayList());
    } catch (e2) {
        // Some line items may not support tax updates
    }
}

/**
 * Reads tax amount from an AvaTax summary or line object (tax vs taxCalculated).
 *
 * @param {Object} item
 * @returns {number}
 */
function getAvaTaxItemAmount(item) {
    if (!item) {
        return 0;
    }
    var amount = Number(item.tax);
    if (!isNaN(amount) && amount !== 0) {
        return amount;
    }
    amount = Number(item.taxCalculated);
    return isNaN(amount) ? 0 : amount;
}

/**
 * Applies the exact AvaTax line tax via updateTaxAmount (no SFCC rate recalculation).
 *
 * @param {dw.order.LineItem} lineItem
 * @param {Object} resLine
 * @param {string} currencyCode
 */
function applySingleLevelTaxToLineItem(lineItem, resLine, currencyCode) {
    var Money = require('dw/value/Money');
    var ProductLineItem = require('dw/order/ProductLineItem');

    var taxAmount = getAvaTaxItemAmount(resLine);
    var taxableAmount = resLine.taxableAmount || 0;
    var tax = new Money(taxAmount, currencyCode);
    var taxRate = taxableAmount > 0 ? taxAmount / taxableAmount : (taxAmount > 0 ? taxAmount : 0);

    lineItem.setTaxRate(taxRate);
    lineItem.setTax(tax);

    if (lineItem instanceof ProductLineItem) {
        var isBonus = false;
        try {
            isBonus = lineItem.bonusProductLineItem;
        } catch (e) {
            isBonus = false;
        }
        if (isBonus) {
            lineItem.updateTax(0);
            return;
        }
    }

    lineItem.updateTaxAmount(tax);
}

/**
 * Applies AvaTax taxes to a line item (BM updateTaxes parity — single-level only).
 *
 * @param {dw.order.LineItem} lineItem
 * @param {Object} resLine
 * @param {string} currencyCode
 * @returns {boolean} multilevelFallbackLogged (unused, kept for call-site compatibility)
 */
function applyTaxesToLineItem(lineItem, resLine, currencyCode) {
    applySingleLevelTaxToLineItem(lineItem, resLine, currencyCode);
    return false;
}

/**
 * Returns the response line identifier in a backward-compatible way.
 *
 * @param {Object} line - AvaTax response line object
 * @returns {string|number|undefined} line identifier
 */
function getResponseLineNumber(line) {
    return line.lineNumber || line.number;
}

/**
 * Resolves AvaTax line metadata from the UUID map (keys may be number or string).
 *
 * @param {Object} lineUUIDMap
 * @param {number|string} responseLineNumber
 * @returns {Object|null}
 */
function resolveLineInfoFromMap(lineUUIDMap, responseLineNumber) {
    if (!lineUUIDMap || responseLineNumber === undefined || responseLineNumber === null) {
        return null;
    }

    if (lineUUIDMap[responseLineNumber]) {
        return lineUUIDMap[responseLineNumber];
    }

    var numericKey = parseInt(responseLineNumber, 10);
    if (!isNaN(numericKey) && lineUUIDMap[numericKey]) {
        return lineUUIDMap[numericKey];
    }

    var stringKey = String(responseLineNumber);
    if (lineUUIDMap[stringKey]) {
        return lineUUIDMap[stringKey];
    }

    return null;
}

/**
 * Commits a previously created transaction in AvaTax.
 *
 * @param {string} transactionCode - The transaction code (order number)
 * @returns {Object} Response object with {success: boolean, data: Object, error: String}
 */
function commitTransaction(transactionCode) {
    if (!avataxSettingsHelper.saveTransactionsToAvatax()) {
        logger.warn('Document commit not allowed — saveTransactions is disabled in AVSettings');
        return {
            success: false,
            error: 'Document commit not allowed for this site. Enable save transactions in Avalara settings.'
        };
    }

    var companyCode = avataxSettingsHelper.getCompanyCode();
    if (!companyCode) {
        logger.error('companyCode not configured in AVSettings');
        return { success: false, error: 'companyCode not configured in AVSettings.' };
    }

    var response = avataxService.commitTransaction(companyCode, transactionCode, { commit: true });

    logStructured({
        operation: 'CommitTransaction',
        docCode: transactionCode,
        logType: response.success ? 'Performance' : 'Debug',
        logLevel: response.success ? 'Informational' : 'Error',
        error: !response.success,
        errorType: response.success ? undefined : 'Data',
        latency: response.latency || 0,
        message: response.success
            ? 'CommitTransaction succeeded for ' + transactionCode
            : 'CommitTransaction failed: ' + response.error
    });

    return response;
}

/**
 * Creates the AvaTax SalesInvoice for a placed order so it appears in the AvaTax portal.
 * Uses the order number as the document code and optionally commits in the same API call.
 *
 * @param {dw.order.Order} order
 * @returns {Object} Response object with {success: boolean, data: Object, error: String}
 */
function finalizeOrderTransaction(order) {
    if (!avataxSettingsHelper.isTaxCalculationEnabled()) {
        return { success: false, error: 'AvaTax not enabled for this site.' };
    }

    if (!avataxSettingsHelper.saveTransactionsToAvatax()) {
        logger.warn('Save transactions disabled — order ' + order.getOrderNo() + ' will not be posted to AvaTax');
        return { success: false, error: 'Save transactions disabled.' };
    }

    if (!avataxSettingsHelper.getCompanyCode()) {
        logger.error('companyCode not configured in AVSettings');
        return { success: false, error: 'companyCode not configured in AVSettings.' };
    }

    var orderNo = order.getOrderNo();
    var enterTime = Date.now();

    delete session.custom.avataxtransactionmodel;
    delete session.custom.avataxTaxSnapshot;
    delete session.custom.avataxLastResponse;

    var buildResult = buildTransactionModel(order);
    if (!buildResult.model.lines || buildResult.model.lines.length === 0) {
        logger.warn('No taxable line items found for order ' + orderNo);
        return { success: false, error: 'No taxable line items found for order.' };
    }

    var response = avataxService.createTransaction(buildResult.model, 'Details');
    var completionTime = Date.now();
    var connectorTime = (completionTime - enterTime) - (response.latency || 0);

    logger.warn('AvaTax CreateTransaction request (order-' + orderNo + '): ' +
        JSON.stringify(buildResult.model));
    if (response.data) {
        logger.warn('AvaTax CreateTransaction response (order-' + orderNo + '): ' +
            JSON.stringify(response.data));
    }

    if (response.success) {
        session.custom.avataxtransactionmodel = null;

        logStructured({
            operation: 'CreateTransaction',
            docCode: orderNo,
            logType: 'Performance',
            logLevel: 'Informational',
            lineCount: buildResult.model.lines.length,
            connectorTime: connectorTime,
            latency: response.latency || 0,
            message: 'SalesInvoice created for order ' + orderNo +
                (buildResult.model.commit ? ' (committed)' : ' (saved, uncommitted)')
        });

        updateTaxDetails(order, response.data, buildResult.lineUUIDMap, orderNo);
    } else {
        logStructured({
            operation: 'CreateTransaction',
            docCode: orderNo,
            logType: 'Debug',
            logLevel: 'Error',
            error: true,
            errorType: 'Data',
            lineCount: buildResult.model.lines.length,
            connectorTime: connectorTime,
            latency: response.latency || 0,
            message: 'SalesInvoice creation failed for order ' + orderNo + ': ' + response.error
        });
    }

    return response;
}

/**
 * Voids a previously saved transaction in AvaTax.
 *
 * @param {string} transactionCode - The transaction code (order number)
 * @returns {Object} Response object with {success: boolean, data: Object, error: String}
 */
function voidTransaction(transactionCode) {
    if (!avataxSettingsHelper.saveTransactionsToAvatax()) {
        logger.warn('Document void not allowed — saveTransactions is disabled in AVSettings');
        return {
            success: false,
            error: 'Document void not allowed for this site. Enable save transactions in Avalara settings.'
        };
    }

    var companyCode = avataxSettingsHelper.getCompanyCode();
    if (!companyCode) {
        logger.error('companyCode not configured in AVSettings');
        return { success: false, error: 'companyCode not configured in AVSettings.' };
    }

    var response = avataxService.voidTransaction(companyCode, transactionCode, { code: 'DocVoided' });

    logStructured({
        operation: 'VoidTransaction',
        docCode: transactionCode,
        logType: response.success ? 'Performance' : 'Debug',
        logLevel: response.success ? 'Informational' : 'Error',
        error: !response.success,
        errorType: response.success ? undefined : 'Data',
        latency: response.latency || 0,
        message: response.success
            ? 'VoidTransaction succeeded for ' + transactionCode
            : 'VoidTransaction failed: ' + response.error
    });

    return response;
}

/**
 * Finds a line item in the basket by its UUID.
 * Checks all line items including nested shipping line items on product line items.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket
 * @param {string} uuid - The UUID to find
 * @returns {dw.order.LineItem|null} The matching line item or null
 */
function getLineItemByUUID(basket, uuid) {
    var allLineItems = basket.getAllLineItems().iterator();
    while (allLineItems.hasNext()) {
        var li = allLineItems.next();
        if (li.UUID === uuid) {
            return li;
        }
        // Only ProductLineItem has a nested shippingLineItem — never probe other line types
        // (ProductShippingLineItem throws SCRIPT_FIELD_ACCESS on unknown properties).
        if (isProductLineItem(li) && li.shippingLineItem && li.shippingLineItem.UUID === uuid) {
            return li.shippingLineItem;
        }
    }
    return null;
}

/**
 * @param {dw.order.LineItemCtnr} basket
 * @returns {number}
 */
function getBasketTotalTaxValue(basket) {
    try {
        return basket.getTotalTax().value;
    } catch (e) {
        return basket.totalTax ? basket.totalTax.value : 0;
    }
}

/**
 * Adjusts the last taxed line so basket taxTotal matches AvaTax totalTax.
 *
 * @param {dw.order.LineItemCtnr} basket
 * @param {Object} avaTaxResponse
 * @param {dw.order.LineItem|null} lastAppliedLineItem
 * @param {string} currencyCode
 */
function reconcileBasketToTotalTax(basket, avaTaxResponse, lastAppliedLineItem, currencyCode) {
    var expectedTotal = Number(avaTaxResponse.totalTax);
    if (isNaN(expectedTotal) || expectedTotal === 0 || !lastAppliedLineItem) {
        return;
    }

    basket.updateTotals();
    var actualTotal = getBasketTotalTaxValue(basket);
    var diff = Math.round((expectedTotal - actualTotal) * 100) / 100;

    if (Math.abs(diff) < 0.005) {
        return;
    }

    var Money = require('dw/value/Money');
    var currentLineTax = 0;

    try {
        currentLineTax = lastAppliedLineItem.getTax().value;
    } catch (e) {
        currentLineTax = 0;
    }

    var adjustedTax = new Money(currentLineTax + diff, currencyCode);
    lastAppliedLineItem.setTax(adjustedTax);
    lastAppliedLineItem.updateTaxAmount(adjustedTax);
    basket.updateTotals();

    logger.warn('AvaTax reconciled basket tax by ' + diff + ' (totalTax: ' + expectedTotal +
        ', basket was: ' + actualTotal + ')');
}

/**
 * Applies AvaTax response to basket line items using UUID-based matching.
 *
 * @param {dw.order.LineItemCtnr} basket - The basket
 * @param {Object} avaTaxResponse - Response from AvaTax API
 * @param {Object} lineUUIDMap - Map of line numbers to line item UUIDs
 */
function applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap) {
    if (!avaTaxResponse || !avaTaxResponse.lines) {
        logger.warn('No tax lines in AvaTax response');
        return;
    }

    var ProductLineItem = require('dw/order/ProductLineItem');
    var ProductShippingLineItem = require('dw/order/ProductShippingLineItem');
    var ShippingLineItem = require('dw/order/ShippingLineItem');
    var currencyCode = basket.getCurrencyCode();
    var linesApplied = 0;
    var lastAppliedLineItem = null;

    var responseLines = avaTaxResponse.lines;
    for (var i = 0; i < responseLines.length; i++) {
        var resLine = responseLines[i];
        var responseLineNumber = getResponseLineNumber(resLine);
        var lineInfo = resolveLineInfoFromMap(lineUUIDMap, responseLineNumber);

        if (!lineInfo) {
            logger.warn('No UUID mapping for AvaTax line number ' + responseLineNumber);
            continue;
        }

        var lineItem = getLineItemByUUID(basket, lineInfo.uuid);
        if (!lineItem) {
            logger.warn('Line item not found for UUID ' + lineInfo.uuid + ' (line ' + responseLineNumber + ')');
            continue;
        }

        try {
            applyTaxesToLineItem(lineItem, resLine, currencyCode);
            linesApplied++;
            lastAppliedLineItem = lineItem;
        } catch (lineTaxError) {
            logger.warn('Failed to apply AvaTax to line ' + responseLineNumber + ' (UUID ' +
                lineInfo.uuid + '): ' + lineTaxError.message);
        }

        // Zero out tax on price adjustments for this line item
        if (lineItem instanceof ProductLineItem || lineItem instanceof ProductShippingLineItem) {
            var paIterator = lineItem.priceAdjustments.iterator();
            while (paIterator.hasNext()) {
                paIterator.next().updateTax(0);
            }
        } else if (lineItem instanceof ShippingLineItem) {
            var spaIterator = lineItem.shippingPriceAdjustments.iterator();
            while (spaIterator.hasNext()) {
                spaIterator.next().updateTax(0);
            }
        }
    }

    // Zero out basket-level price adjustments
    var basketPAIterator = basket.priceAdjustments.iterator();
    while (basketPAIterator.hasNext()) {
        basketPAIterator.next().updateTax(0);
    }
    var basketSPAIterator = basket.shippingPriceAdjustments.iterator();
    while (basketSPAIterator.hasNext()) {
        basketSPAIterator.next().updateTax(0);
    }

    reconcileBasketToTotalTax(basket, avaTaxResponse, lastAppliedLineItem, currencyCode);

    updateTaxDetails(basket, avaTaxResponse, lineUUIDMap, null);

    basket.updateTotals();

    logger.warn('AvaTax applied tax to ' + linesApplied + ' of ' + responseLines.length +
        ' response lines (totalTax: ' + (avaTaxResponse.totalTax || 0) +
        ', basket taxTotal: ' + getBasketTotalTaxValue(basket) + ')');
}

/**
 * Sets a custom attribute on basket/order; logs and continues when metadata is missing.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @param {string} name
 * @param {string} value
 */
function setAvaTaxCustomAttribute(lineItemCtnr, name, value) {
    var Order = require('dw/order/Order');
    var Transaction = require('dw/system/Transaction');

    function assign() {
        lineItemCtnr.custom[name] = value;
    }

    try {
        // Basket updates during calculateTax need Transaction.wrap (BM parity).
        // Order finalize (afterPOST) must not wrap — breaks extension point execution.
        if (lineItemCtnr instanceof Order) {
            assign();
        } else {
            Transaction.wrap(assign);
        }
    } catch (e) {
        logger.warn('Could not store ' + name + ': ' + e.message);
    }
}

/**
 * Computes ATTax (vat/gst total) and ATCustomsDuty from AvaTax summary, with totalTax fallback.
 *
 * @param {Object} svcResponse
 * @returns {{ vatgst: number, customsDuty: number }}
 */
function computeTaxSummaryAmounts(svcResponse) {
    var customsDuty = 0;
    var vatgst = 0;
    var hasSummary = svcResponse.summary && svcResponse.summary.length > 0;

    if (hasSummary) {
        for (var i = 0; i < svcResponse.summary.length; i++) {
            var curSummaryItem = svcResponse.summary[i];
            var taxType = (curSummaryItem.taxType || '').toString().toLowerCase();
            var taxSubType = (curSummaryItem.taxSubType || '').toString().toLowerCase();
            var itemTax = getAvaTaxItemAmount(curSummaryItem);

            if (taxType === 'landedcost' && taxSubType === 'importduty') {
                customsDuty += itemTax;
            } else {
                vatgst += itemTax;
            }
        }
    }

    var totalTax = Number(svcResponse.totalTax);
    if (isNaN(totalTax)) {
        totalTax = 0;
    }

    // Summary can be present but empty/zero while totalTax is authoritative (common on US sales tax).
    if (totalTax > 0 && vatgst === 0) {
        vatgst = Math.max(0, totalTax - customsDuty);
    } else if (!hasSummary && totalTax > 0) {
        vatgst = totalTax;
    }

    if (vatgst === 0 && svcResponse.lines) {
        for (var li = 0; li < svcResponse.lines.length; li++) {
            vatgst += getAvaTaxItemAmount(svcResponse.lines[li]);
        }
        if (customsDuty > 0 && totalTax > 0) {
            vatgst = Math.max(0, totalTax - customsDuty);
        }
    }

    return { vatgst: vatgst, customsDuty: customsDuty };
}

/**
 * Persists AvaTax response details on basket/order (BM updateTaxDetails parity).
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr
 * @param {Object} svcResponse
 * @param {Object} lineUUIDMap
 * @param {string|null} orderNo
 */
function updateTaxDetails(lineItemCtnr, svcResponse, lineUUIDMap, orderNo) {
    if (!lineItemCtnr || !svcResponse) {
        return;
    }

    var taxDetailsJSON = [];

    if (svcResponse.lines) {
        for (var count = 0; count < svcResponse.lines.length; count++) {
            var resItem = svcResponse.lines[count];
            var jsonObj = {};
            var responseLineNumber = getResponseLineNumber(resItem);
            var lineInfo = resolveLineInfoFromMap(lineUUIDMap, responseLineNumber);
            var itemId = lineInfo ? lineInfo.itemId : String(responseLineNumber);
            var shipmentId = lineInfo ? lineInfo.shipmentId : '';

            if (resItem.details && resItem.details.length) {
                var taxes = [];
                for (var i = 0; i < resItem.details.length; i++) {
                    var detail = resItem.details[i];
                    taxes.push({
                        jurisdictiontype: detail.jurisdictionType,
                        jurisdiction: detail.jurisName,
                        exempt: detail.exemptAmount,
                        nontaxable: detail.nonTaxableAmount,
                        taxable: detail.taxableAmount,
                        rate: detail.rate,
                        tax: detail.tax,
                        taxName: detail.taxName,
                        taxSubTypeId: detail.taxSubTypeId,
                        taxType: detail.taxType
                    });
                }
                jsonObj.lineitemid = itemId;
                jsonObj.shipmentid = shipmentId;
                jsonObj.taxes = taxes;
            }

            taxDetailsJSON.push(jsonObj);
        }
    }

    var invoiceMsgDetails = '';
    var landedCostMessages = '';
    var genericMsgDetails = '';

    if (svcResponse.invoiceMessages && svcResponse.invoiceMessages.length) {
        for (var inv = 0; inv < svcResponse.invoiceMessages.length; inv++) {
            invoiceMsgDetails += String(svcResponse.invoiceMessages[inv].content || '') + ' ';
        }
    }

    if (svcResponse.messages && svcResponse.messages.length) {
        for (var m = 0; m < svcResponse.messages.length; m++) {
            var currentMessage = svcResponse.messages[m];
            var refersTo = (currentMessage.refersTo || '').toString().toLowerCase();
            var severity = (currentMessage.severity || '').toString().toLowerCase();

            if (refersTo === 'landedcost' && severity === 'success') {
                landedCostMessages += (currentMessage.summary || '').toString() + ' ' +
                    (currentMessage.details || '').toString() + ' ';
            } else {
                genericMsgDetails += (currentMessage.refersTo || '').toString() + ' - ' +
                    (currentMessage.details || '').toString() + ' ';
            }
        }
    }

    var taxAmounts = computeTaxSummaryAmounts(svcResponse);

    var vatCode = '';
    if (svcResponse.lines && svcResponse.lines.length > 0) {
        for (var vc = 0; vc < svcResponse.lines.length; vc++) {
            if (svcResponse.lines[vc].vatCode) {
                vatCode += 'Line ' + getResponseLineNumber(svcResponse.lines[vc]) + ': ' +
                    svcResponse.lines[vc].vatCode + '; ';
            }
        }
    }

    setAvaTaxCustomAttribute(lineItemCtnr, 'ATInvoiceMessage', invoiceMsgDetails.replace(/\s+$/, ''));
    setAvaTaxCustomAttribute(lineItemCtnr, 'ATTaxDetail', JSON.stringify(taxDetailsJSON));
    setAvaTaxCustomAttribute(lineItemCtnr, 'ATLandedCost', landedCostMessages.replace(/\s+$/, ''));
    setAvaTaxCustomAttribute(lineItemCtnr, 'ATCustomsDuty', String(taxAmounts.customsDuty));
    setAvaTaxCustomAttribute(lineItemCtnr, 'ATGenericMessage', genericMsgDetails.replace(/\s+$/, ''));
    var responseTotalTax = Number(svcResponse.totalTax);
    var attTaxValue = !isNaN(responseTotalTax) && responseTotalTax > 0 ?
        responseTotalTax : taxAmounts.vatgst;
    setAvaTaxCustomAttribute(lineItemCtnr, 'ATTax', String(attTaxValue));
    setAvaTaxCustomAttribute(lineItemCtnr, 'ATVatCode', vatCode.replace(/\s+$/, ''));

    logger.warn('AvaTax custom attrs stored — ATTax: ' + taxAmounts.vatgst +
        ', ATCustomsDuty: ' + taxAmounts.customsDuty +
        ' (response totalTax: ' + (svcResponse.totalTax || 0) + ')');

    logStructured({
        operation: 'UpdateTaxDetails',
        docCode: orderNo ||
            getOrderNoFromContainer(lineItemCtnr) ||
            (lineItemCtnr && typeof lineItemCtnr.getUUID === 'function' ? lineItemCtnr.getUUID() : '') ||
            '',
        logType: 'Performance',
        logLevel: 'Informational',
        lineCount: svcResponse.lines ? svcResponse.lines.length : 0,
        message: 'AvaTax tax details persisted on basket/order.'
    });

    if (invoiceMsgDetails) {
        try {
            session.custom.ATInvoiceMessage = invoiceMsgDetails.replace(/\s+$/, '');
        } catch (e) {
            logger.warn('Could not store session ATInvoiceMessage: ' + e.message);
        }
    }
}

/**
 * Tests the connection to the AvaTax API by calling the ping endpoint.
 *
 * @returns {Object} Response object with {success: boolean, authenticated: boolean, error: String}
 */
function testConnection() {
    var response = avataxService.ping();

    if (!response.success) {
        logStructured({
            operation: 'TestConnection',
            logType: 'Debug',
            logLevel: 'Error',
            error: true,
            errorType: 'Configuration',
            message: 'TestConnection failed: ' + response.error
        });
        return { success: false, error: response.error };
    }

    var authenticated = response.data && response.data.authenticated;

    logStructured({
        operation: 'TestConnection',
        logType: 'Performance',
        logLevel: 'Informational',
        latency: response.latency || 0,
        message: 'TestConnection succeeded. Authenticated: ' + authenticated
    });

    return {
        success: true,
        authenticated: authenticated,
        data: response.data
    };
}

module.exports = {
    buildTransactionModel: buildTransactionModel,
    callAvaTaxAPI: callAvaTaxAPI,
    applyTaxesToBasket: applyTaxesToBasket,
    commitTransaction: commitTransaction,
    finalizeOrderTransaction: finalizeOrderTransaction,
    voidTransaction: voidTransaction,
    testConnection: testConnection,
    getConfig: getConfig,
    setLineItemTaxToZero: setLineItemTaxToZero,
    avataxSettingsHelper: avataxSettingsHelper
};