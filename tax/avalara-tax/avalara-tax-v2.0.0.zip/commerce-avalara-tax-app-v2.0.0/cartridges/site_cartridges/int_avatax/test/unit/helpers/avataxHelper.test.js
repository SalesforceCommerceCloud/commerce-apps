'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Money = require('../../mocks/dw/value/Money');
var ProductLineItem = require('../../mocks/dw/order/ProductLineItem');
var ProductShippingLineItem = require('../../mocks/dw/order/ProductShippingLineItem');
var ShippingLineItem = require('../../mocks/dw/order/ShippingLineItem');
var Order = require('../../mocks/dw/order/Order');
var ArrayListMock = function () {
    this.items = [];
    this.length = 0;
};
ArrayListMock.prototype.add = function (item) {
    this.items.push(item);
    this.length = this.items.length;
};
ArrayListMock.prototype.size = function () {
    return this.items.length;
};
var LineItemTaxMock = function (taxId, taxRate, taxValue) {
    if (LineItemTaxMock.throwMultilevel) {
        throw new Error('java.lang.IllegalArgumentException: new LineItemTax() requires the Multilevel Tax feature to be enabled.');
    }
    this.taxId = taxId;
    this.taxRate = taxRate;
    this.taxValue = taxValue;
};
LineItemTaxMock.throwMultilevel = false;

function SortedMapMock() {
    this.map = {};
}
SortedMapMock.prototype.put = function (key, value) {
    this.map[String(key)] = value;
};
SortedMapMock.prototype.get = function (key) {
    return this.map[String(key)];
};
SortedMapMock.prototype.size = function () {
    return Object.keys(this.map).length;
};
SortedMapMock.prototype.keySet = function () {
    var keys = Object.keys(this.map).sort(function (a, b) {
        return parseInt(a, 10) - parseInt(b, 10);
    });
    var index = 0;
    return {
        iterator: function () {
            return {
                hasNext: function () { return index < keys.length; },
                next: function () { return keys[index++]; }
            };
        }
    };
};

var createTransactionModelModule = require('../../../cartridge/models/createTransactionModel');

function buildDefaultAvSettings(overrides) {
    var settings = {
        configs: {
            taxCalculation: true,
            companyCode: 'TESTCO',
            useCustomCustomerCode: 'customer_email',
            taxationpolicy: 'net',
            line1: '100 Warehouse Ave',
            city: 'Portland',
            state: 'OR',
            countryCode: 'US',
            zipCode: '97201',
            saveTransactions: false,
            commitTransactions: false,
            defaultShippingMethodTaxCode: 'FR'
        }
    };
    if (overrides) {
        settings.configs = Object.assign({}, settings.configs, overrides.configs || overrides);
    }
    return JSON.stringify(settings);
}

describe('avataxHelper', function () {
    var avataxHelper;
    var calculateTaxHelper;
    var avataxServiceStub;
    var siteStub;
    var loggerStub;
    var murmurhashStub;
    var taxMgrStub;
    var sessionMock;
    var sitePreferences;

    function getCalculateTaxHelperStubs(overrides) {
        return Object.assign({
            'dw/system/Logger': {
                getLogger: sinon.stub().returns(loggerStub)
            },
            'dw/system/Site': siteStub,
            'dw/order/TaxMgr': taxMgrStub,
            'dw/util/SortedMap': SortedMapMock,
            '~/cartridge/scripts/lineLevelAddress.json': { lladdresses: {} },
            '~/cartridge/scripts/avaMerchantConf.json': {},
            '~/cartridge/models/createTransactionModel': createTransactionModelModule
        }, overrides || {});
    }

    beforeEach(function () {
        sitePreferences = {};

        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        avataxServiceStub = {
            call: sinon.stub(),
            createTransaction: sinon.stub(),
            commitTransaction: sinon.stub(),
            voidTransaction: sinon.stub(),
            ping: sinon.stub(),
            CONNECTOR_NAME: 'AvaTax for SFCC',
            CONNECTOR_VERSION: '2.0.0'
        };

        siteStub = {
            getCurrent: sinon.stub().returns({
                getCustomPreferenceValue: sinon.stub().callsFake(function (key) {
                    return sitePreferences[key] !== undefined ? sitePreferences[key] : null;
                })
            })
        };

        taxMgrStub = {
            TAX_POLICY_GROSS: 1,
            TAX_POLICY_NET: 0,
            taxationPolicy: 0,
            getTaxationPolicy: sinon.stub().returns(0)
        };

        murmurhashStub = {
            hashBytes: sinon.stub().returns(99999)
        };

        sessionMock = { custom: {}, privacy: {} };
        global.session = sessionMock;
        sitePreferences.AVSettings = buildDefaultAvSettings();

        calculateTaxHelper = proxyquire(
            '../../../cartridge/scripts/helpers/calculateTaxHelper',
            getCalculateTaxHelperStubs()
        );

        avataxHelper = proxyquire(
            '../../../cartridge/scripts/helpers/avataxHelper',
            {
                'dw/system/Logger': {
                    getLogger: sinon.stub().returns(loggerStub)
                },
                'dw/system/Site': siteStub,
                'dw/system/Transaction': {
                    wrap: function (callback) {
                        callback();
                    }
                },
                'dw/value/Money': Money,
                'dw/order/TaxMgr': taxMgrStub,
                'dw/order/ProductLineItem': ProductLineItem,
                'dw/order/ProductShippingLineItem': ProductShippingLineItem,
                'dw/order/ShippingLineItem': ShippingLineItem,
                'dw/order/Order': Order,
                'dw/util/ArrayList': ArrayListMock,
                'dw/order/LineItemTax': LineItemTaxMock,
                '~/cartridge/scripts/services/avataxService': avataxServiceStub,
                '~/cartridge/scripts/helpers/murmurhash': murmurhashStub,
                '~/cartridge/scripts/helpers/calculateTaxHelper': calculateTaxHelper
            }
        );
    });

    afterEach(function () {
        LineItemTaxMock.throwMultilevel = false;
        delete global.session;
        sinon.restore();
    });

    // =========================================================================
    // Helper factories
    // =========================================================================

    function createIterator(items) {
        var index = 0;
        return {
            hasNext: function () { return index < items.length; },
            next: function () { return items[index++]; }
        };
    }

    function createCollection(items) {
        return {
            iterator: function () { return createIterator(items); },
            length: items.length
        };
    }

    function createMockAddress(overrides) {
        return Object.assign({
            address1: '123 Main St',
            address2: '',
            city: 'Seattle',
            stateCode: 'WA',
            countryCode: { value: 'US' },
            postalCode: '98101'
        }, overrides || {});
    }

    function createMockShipment(address, id) {
        var shippingLineItems = createCollection([]);
        return {
            ID: id || 'shipment-1',
            shippingAddress: address,
            shippingLineItems: shippingLineItems,
            getShippingAddress: sinon.stub().returns(address),
            getShippingLineItems: sinon.stub().returns(shippingLineItems)
        };
    }

    function createMockProductLineItem(overrides) {
        var defaults = {
            UUID: 'pli-uuid-1',
            productID: 'PROD-001',
            productName: 'Test Product',
            quantityValue: 2,
            proratedPrice: { value: 29.99 },
            taxClassID: 'P0000000',
            optionProductLineItems: createCollection([]),
            shippingLineItem: null,
            getProduct: sinon.stub().returns({
                UPC: '012345678901',
                taxClassID: 'P0000000',
                shortDescription: { source: { toString: function () { return 'A test product'; } } }
            }),
            getShipment: sinon.stub()
        };
        return Object.assign(defaults, overrides || {});
    }

    function createMockBasket(options) {
        options = options || {};
        var productLineItems = options.productLineItems || [];
        var shipments = options.shipments || [];
        var giftCertLineItems = options.giftCertLineItems || [];
        var allLineItems = options.allLineItems || [];

        return {
            getUUID: sinon.stub().returns(options.uuid || 'basket-uuid-1'),
            getCurrencyCode: sinon.stub().returns(options.currency || 'USD'),
            getCustomerEmail: sinon.stub().returns(options.customerEmail || 'test@example.com'),
            getCustomer: sinon.stub().returns(options.customer || null),
            getProductLineItems: sinon.stub().returns(createCollection(productLineItems)),
            getShipments: sinon.stub().returns(createCollection(shipments)),
            getGiftCertificateLineItems: sinon.stub().returns(createCollection(giftCertLineItems)),
            getBillingAddress: sinon.stub().returns(options.billingAddress || null),
            getAllLineItems: sinon.stub().returns(createCollection(allLineItems)),
            updateTotals: sinon.stub(),
            priceAdjustments: createCollection(options.priceAdjustments || []),
            shippingPriceAdjustments: createCollection(options.shippingPriceAdjustments || []),
            custom: {}
        };
    }

    function createMockCustomer(overrides) {
        var profileDefaults = {
            customerNo: 'CUST-001',
            email: 'profile@example.com',
            taxID: 'TAX-123',
            custom: { ATisSellerImporterOfRecord: false }
        };
        return {
            profile: Object.assign(profileDefaults, overrides || {})
        };
    }

    // =========================================================================
    // getCustomerCode (tested via buildTransactionModel)
    // =========================================================================
    describe('getCustomerCode (via buildTransactionModel)', function () {
        var defaultShipment;
        var defaultPli;

        beforeEach(function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ useCustomCustomerCode: 'customer_email' });
            var address = createMockAddress();
            defaultShipment = createMockShipment(address);
            defaultPli = createMockProductLineItem();
            defaultPli.getShipment.returns(defaultShipment);
        });

        it('should use customerNo when preference is customer_number', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ useCustomCustomerCode: 'customer_number' });
            var customer = createMockCustomer({ customerNo: 'CN-999' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'CN-999');
        });

        it('should use basket email when preference is customer_email', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ useCustomCustomerCode: 'customer_email' });
            var customer = createMockCustomer();
            var basket = createMockBasket({
                customer: customer,
                customerEmail: 'basket@test.com',
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'basket@test.com');
        });

        it('should fall back to profile email when basket email is null', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ useCustomCustomerCode: 'customer_email' });
            var customer = createMockCustomer({ email: 'fallback@test.com' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });
            basket.getCustomerEmail.returns(null);

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'fallback@test.com');
        });

        it('should use custom attribute when preference is custom_attribute', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                useCustomCustomerCode: 'custom_attribute',
                customCustomerAttribute: 'loyaltyId'
            });
            sitePreferences.ATCustomCustomerCode = { toString: function () { return 'loyaltyId'; }, trim: function () { return 'loyaltyId'; } };
            var customer = createMockCustomer({ loyaltyId: 'LOYAL-42' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'LOYAL-42');
        });

        it('should fall back to customerNo when custom attribute is not found', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                useCustomCustomerCode: 'custom_attribute',
                customCustomerAttribute: 'nonExistentAttr'
            });
            sitePreferences.ATCustomCustomerCode = { toString: function () { return 'nonExistentAttr'; }, trim: function () { return 'nonExistentAttr'; } };
            var customer = createMockCustomer({ customerNo: 'CN-FALLBACK' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'CN-FALLBACK');
        });

        it('should fall back to customerNo for unknown preference value', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ useCustomCustomerCode: 'some_unknown_strategy' });
            var customer = createMockCustomer({ customerNo: 'CN-DEFAULT' });
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'CN-DEFAULT');
        });

        it('should return basket email for guest customer', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ useCustomCustomerCode: 'customer_email' });
            var basket = createMockBasket({
                customer: { profile: null },
                customerEmail: 'guest@shop.com',
                productLineItems: [defaultPli],
                shipments: [defaultShipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.customerCode, 'guest@shop.com');
        });
    });

    // =========================================================================
    // buildTransactionModel
    // =========================================================================
    describe('buildTransactionModel', function () {
        var address;
        var shipment;

        beforeEach(function () {
            sitePreferences.AVSettings = buildDefaultAvSettings();

            address = createMockAddress();
            shipment = createMockShipment(address, 'ship-1');
        });

        it('should build correct top-level transaction model structure', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var customer = createMockCustomer();
            var basket = createMockBasket({
                customer: customer,
                uuid: 'basket-123',
                currency: 'USD',
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);
            var model = result.model;

            assert.equal(model.code, 'basket-123');
            assert.equal(model.type, 'SalesOrder');
            assert.equal(model.companyCode, 'TESTCO');
            assert.equal(model.currencyCode, 'USD');
            assert.equal(model.businessIdentificationNo, 'TAX-123');
            assert.isFalse(model.isSellerImporterOfRecord);
            assert.isFalse(model.commit);
            assert.equal(model.debugLevel, 'Normal');
            assert.isArray(model.lines);
        });

        it('should use AtShipFrom site preferences on product lines', function () {
            sitePreferences.AtShipFromLine1 = '100 Warehouse Ave';
            sitePreferences.AtShipFromCity = 'Portland';
            sitePreferences.AtShipFromStateCode = 'OR';
            sitePreferences.AtShipFromZipCode = '97201';
            sitePreferences.AtShipFromCountryCode = 'US';

            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                uuid: 'basket-123',
                currency: 'USD',
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);
            var shipFrom = result.model.lines[0].addresses.shipFrom;

            assert.equal(shipFrom.line1, '100 Warehouse Ave');
            assert.equal(shipFrom.city, 'Portland');
            assert.equal(shipFrom.region, 'OR');
            assert.equal(shipFrom.postalCode, '97201');
            assert.equal(shipFrom.country, 'US');
        });

        it('should apply hsCode from lineLevelAddress', function () {
            var hsCodeHelper = proxyquire(
                '../../../cartridge/scripts/helpers/calculateTaxHelper',
                getCalculateTaxHelperStubs({
                    '~/cartridge/scripts/lineLevelAddress.json': {
                        lladdresses: {
                            'PROD-001': { hsCode: '6206900040' }
                        }
                    }
                })
            );
            var hsCodeAvataxHelper = proxyquire(
                '../../../cartridge/scripts/helpers/avataxHelper',
                {
                    'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                    'dw/system/Site': siteStub,
                    'dw/system/Transaction': { wrap: function (callback) { callback(); } },
                    'dw/value/Money': Money,
                    'dw/order/TaxMgr': taxMgrStub,
                    'dw/order/ProductLineItem': ProductLineItem,
                    'dw/order/ProductShippingLineItem': ProductShippingLineItem,
                    'dw/order/ShippingLineItem': ShippingLineItem,
                    'dw/order/Order': Order,
                    'dw/util/ArrayList': ArrayListMock,
                    'dw/order/LineItemTax': LineItemTaxMock,
                    '~/cartridge/scripts/services/avataxService': avataxServiceStub,
                    '~/cartridge/scripts/helpers/murmurhash': murmurhashStub,
                    '~/cartridge/scripts/helpers/calculateTaxHelper': hsCodeHelper
                }
            );

            var pli = createMockProductLineItem({ productID: 'PROD-001' });
            pli.getProduct.returns({
                UPC: '012345678901',
                taxClassID: 'P0000000',
                shortDescription: { source: { toString: function () { return 'Cross-border product'; } } }
            });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = hsCodeAvataxHelper.buildTransactionModel(basket);
            var line = result.model.lines[0];

            assert.equal(line.hsCode, '6206900040');
            assert.isTrue(result.model.isSellerImporterOfRecord);
            assert.isArray(line.parameters);
            assert.lengthOf(line.parameters, 0);
        });

        it('should apply lineLevelAddress shipfrom when line1 and countryCode are set', function () {
            sitePreferences.AtShipFromLine1 = '100 Warehouse Ave';
            sitePreferences.AtShipFromCity = 'Portland';
            sitePreferences.AtShipFromStateCode = 'OR';
            sitePreferences.AtShipFromCountryCode = 'US';
            sitePreferences.AtShipFromZipCode = '97201';

            var lineLevelHelper = proxyquire(
                '../../../cartridge/scripts/helpers/calculateTaxHelper',
                getCalculateTaxHelperStubs({
                    '~/cartridge/scripts/lineLevelAddress.json': {
                        lladdresses: {
                            'PROD-001': {
                                shipfrom: {
                                    line1: 'Musterstrasse 1',
                                    city: 'Berlin',
                                    region: 'BE',
                                    postalCode: '10115',
                                    countryCode: 'DE'
                                }
                            }
                        }
                    }
                })
            );
            var lineLevelAvataxHelper = proxyquire(
                '../../../cartridge/scripts/helpers/avataxHelper',
                {
                    'dw/system/Logger': { getLogger: sinon.stub().returns(loggerStub) },
                    'dw/system/Site': siteStub,
                    'dw/system/Transaction': { wrap: function (callback) { callback(); } },
                    'dw/value/Money': Money,
                    'dw/order/TaxMgr': taxMgrStub,
                    'dw/order/ProductLineItem': ProductLineItem,
                    'dw/order/ProductShippingLineItem': ProductShippingLineItem,
                    'dw/order/ShippingLineItem': ShippingLineItem,
                    'dw/order/Order': Order,
                    'dw/util/ArrayList': ArrayListMock,
                    'dw/order/LineItemTax': LineItemTaxMock,
                    '~/cartridge/scripts/services/avataxService': avataxServiceStub,
                    '~/cartridge/scripts/helpers/murmurhash': murmurhashStub,
                    '~/cartridge/scripts/helpers/calculateTaxHelper': lineLevelHelper
                }
            );

            var pli = createMockProductLineItem({ productID: 'PROD-001' });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = lineLevelAvataxHelper.buildTransactionModel(basket);
            var shipFrom = result.model.lines[0].addresses.shipFrom;

            assert.equal(shipFrom.line1, 'Musterstrasse 1');
            assert.equal(shipFrom.city, 'Berlin');
            assert.equal(shipFrom.region, 'BE');
            assert.equal(shipFrom.postalCode, '10115');
            assert.equal(shipFrom.country, 'DE');
        });

        it('should use order number and SalesInvoice when container is an order', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            sitePreferences.AVSettings = buildDefaultAvSettings({
                saveTransactions: true,
                commitTransactions: true
            });

            var order = new Order();
            Object.assign(order, createMockBasket({
                uuid: 'basket-123',
                currency: 'USD',
                productLineItems: [pli],
                shipments: [shipment]
            }));
            order.getOrderNo = sinon.stub().returns('00001234');

            var result = avataxHelper.buildTransactionModel(order);
            var model = result.model;

            assert.equal(model.code, '00001234');
            assert.equal(model.type, 'SalesInvoice');
            assert.isTrue(model.commit);
        });

        it('should process product line items with correct fields', function () {
            var pli = createMockProductLineItem({
                UUID: 'pli-1',
                productID: 'SKU-100',
                quantityValue: 3,
                proratedPrice: { value: 59.97 }
            });
            pli.getProduct.returns({
                UPC: '111222333444',
                taxClassID: 'CUSTOM_TAX',
                shortDescription: { source: { toString: function () { return 'Widget'; } } }
            });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);
            var line = result.model.lines[0];

            assert.equal(line.number, 1);
            assert.equal(line.quantity, 3);
            assert.equal(line.amount, 59.97);
            assert.equal(line.taxCode, 'CUSTOM_TAX');
            assert.equal(line.itemCode, 'UPC:111222333444');
            assert.equal(line.description, 'Widget');
        });

        it('should use productName as itemCode when UPC is not available', function () {
            var pli = createMockProductLineItem({ productName: 'Fancy Hat' });
            pli.getProduct.returns({
                UPC: null,
                taxClassID: 'P0000000',
                shortDescription: { source: { toString: function () { return ''; } } }
            });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines[0].itemCode, 'Fancy Hat');
        });

        it('should set taxIncluded true when taxation policy is gross', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ taxationpolicy: 'gross' });
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.isTrue(result.model.lines[0].taxIncluded);
        });

        it('should skip product line items when shipment has no shipping address', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns({ getShippingAddress: sinon.stub().returns(null), ID: 'no-addr' });
            var billingAddress = createMockAddress({ city: 'Billing City', stateCode: 'CA' });
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [],
                billingAddress: billingAddress
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should skip product line items when no shipping or billing address exists', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns({ getShippingAddress: sinon.stub().returns(null), ID: 'no-addr' });
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [],
                billingAddress: null
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should skip product line items without shipment', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns(null);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: []
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should build correct lineUUIDMap', function () {
            var pli = createMockProductLineItem({ UUID: 'uuid-abc', productID: 'SKU-1' });
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.deepEqual(result.lineUUIDMap[1], {
                uuid: 'uuid-abc',
                shipmentId: 'ship-1',
                itemId: 'SKU-1'
            });
        });

        it('should include businessIdentificationNo from customer profile', function () {
            var customer = createMockCustomer({ taxID: 'VAT-EU-123' });
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.businessIdentificationNo, 'VAT-EU-123');
            assert.equal(result.model.lines[0].businessIdentificationNo, 'VAT-EU-123');
        });

        it('should set isSellerImporterOfRecord from customer profile', function () {
            var customer = createMockCustomer();
            customer.profile.custom.ATisSellerImporterOfRecord = true;
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: customer,
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.isTrue(result.model.isSellerImporterOfRecord);
        });

        // --- Option line items ---
        it('should process option line items nested under product line items', function () {
            var optionItem = {
                UUID: 'oli-uuid-1',
                optionID: 'OPT-1',
                productName: 'Gift Wrapping',
                quantityValue: 1,
                proratedPrice: { value: 4.99 },
                taxClassID: 'P0000000'
            };
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            pli.optionProductLineItems = createCollection([optionItem]);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 2);
            var optionLine = result.model.lines[1];
            assert.equal(optionLine.amount, 4.99);
            assert.equal(optionLine.itemCode, 'Gift Wrapping');
            assert.equal(result.lineUUIDMap[2].uuid, 'oli-uuid-1');
            assert.equal(result.lineUUIDMap[2].itemId, 'OPT-1');
        });

        // --- Product-level shipping line item ---
        it('should process product-level shipping line items', function () {
            var psli = {
                UUID: 'psli-uuid-1',
                ID: 'psli-1',
                lineItemText: 'Oversized Surcharge',
                adjustedPrice: { value: 12.50 },
                taxClassID: 'FR020100'
            };
            var pli = createMockProductLineItem();
            pli.productID = 'SKU-123';
            pli.getShipment.returns(shipment);
            pli.shippingLineItem = psli;
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 2);
            var shippingLine = result.model.lines[1];
            assert.equal(shippingLine.amount, 12.50);
            assert.equal(shippingLine.quantity, 1);
            assert.equal(shippingLine.itemCode, 'Oversized Surcharge');
            assert.equal(result.lineUUIDMap[2].itemId, 'ship-1');
        });

        // --- Shipment-level shipping line items ---
        it('should process shipment-level shipping line items', function () {
            var sli = {
                UUID: 'sli-uuid-1',
                ID: 'StandardShipping',
                lineItemText: 'Standard Ground',
                adjustedPrice: { value: 7.99 },
                taxClassID: 'FR020100'
            };
            shipment.shippingLineItems = createCollection([sli]);
            shipment.getShippingLineItems.returns(createCollection([sli]));
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 1);
            assert.equal(result.model.lines[0].amount, 7.99);
            assert.equal(result.model.lines[0].itemCode, 'StandardShipping');
        });

        it('should include shipment-level shipping line items with zero amount', function () {
            var sli = {
                UUID: 'sli-free',
                ID: 'FreeShipping',
                adjustedPrice: { value: 0 },
                taxClassID: 'FR020100'
            };
            shipment.shippingLineItems = createCollection([sli]);
            shipment.getShippingLineItems.returns(createCollection([sli]));
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 1);
            assert.equal(result.model.lines[0].amount, 0);
        });


        // --- Gift certificate line items ---
        it('should process gift certificate line items with PG050000 tax code', function () {
            var gcShipment = createMockShipment(createMockAddress(), 'gc-ship');
            var gc = {
                UUID: 'gc-uuid-1',
                giftCertificateID: 'GC-001',
                lineItemText: 'Gift Card $50',
                shipment: gcShipment,
                getPriceValue: sinon.stub().returns(50.00)
            };
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [gc]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 1);
            assert.equal(result.model.lines[0].taxCode, 'PG050000');
            assert.equal(result.model.lines[0].amount, 50);
            assert.equal(result.lineUUIDMap[1].itemId, 'GC-001');
        });

        it('should fall back to billing address for gift certs without shipment address', function () {
            var billingAddress = createMockAddress({ city: 'Billing City' });
            var gc = {
                UUID: 'gc-uuid-2',
                giftCertificateID: 'GC-002',
                lineItemText: 'Gift Card',
                shipment: { getShippingAddress: sinon.stub().returns(null), ID: 'gc-s' },
                getPriceValue: sinon.stub().returns(25)
            };
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [gc],
                billingAddress: billingAddress
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines[0].addresses.shipTo.city, 'Billing City');
        });

        it('should skip gift certs with no address available', function () {
            var gc = {
                UUID: 'gc-uuid-3',
                giftCertificateID: 'GC-003',
                lineItemText: 'Gift Card',
                shipment: { getShippingAddress: sinon.stub().returns(null), ID: 'gc-s' },
                getPriceValue: sinon.stub().returns(25)
            };
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [gc],
                billingAddress: null
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.equal(result.model.lines.length, 0);
        });

        it('should log debug when no taxable line items found', function () {
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [],
                shipments: [],
                giftCertLineItems: [],
                uuid: 'empty-basket'
            });

            avataxHelper.buildTransactionModel(basket);

            assert.isTrue(loggerStub.debug.calledOnce);
            assert.include(loggerStub.debug.firstCall.args[0], 'empty-basket');
        });

        it('should include DeliveryTerms parameter when session.privacy.deliveryTerms is set', function () {
            sessionMock.privacy.deliveryTerms = 'DDP';

            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.deepEqual(result.model.parameters, [{
                name: 'DeliveryTerms',
                value: 'DDP'
            }]);
        });

        it('should omit parameters when session.privacy.deliveryTerms is not set', function () {
            var pli = createMockProductLineItem();
            pli.getShipment.returns(shipment);
            var basket = createMockBasket({
                customer: createMockCustomer(),
                productLineItems: [pli],
                shipments: [shipment]
            });

            var result = avataxHelper.buildTransactionModel(basket);

            assert.isUndefined(result.model.parameters);
        });
    });

    // =========================================================================
    // callAvaTaxAPI
    // =========================================================================
    describe('callAvaTaxAPI', function () {
        var transactionModel;

        beforeEach(function () {
            transactionModel = {
                code: 'basket-1',
                lines: [{ number: 1 }]
            };
        });

        it('should call avataxService createTransaction with Details include', function () {
            avataxServiceStub.createTransaction.returns({ success: true, data: { id: 1 }, latency: 50 });

            avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isTrue(avataxServiceStub.createTransaction.calledOnce);
            assert.deepEqual(avataxServiceStub.createTransaction.firstCall.args[0], transactionModel);
            assert.equal(avataxServiceStub.createTransaction.firstCall.args[1], 'Details');
        });

        it('should return success response and store hash in session', function () {
            avataxServiceStub.createTransaction.returns({
                success: true,
                data: { totalTax: 1, lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }] },
                latency: 50
            });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isTrue(result.success);
            assert.equal(sessionMock.custom.avataxtransactionmodel, 99999);
            assert.isDefined(sessionMock.custom.avataxTaxSnapshot);
            assert.isUndefined(sessionMock.custom.avataxLastResponse);
        });

        it('should return deduplicated response when hash matches session', function () {
            murmurhashStub.hashBytes.returns(55555);
            sessionMock.custom.avataxtransactionmodel = 55555;
            sessionMock.custom.avataxTaxSnapshot = JSON.stringify({
                totalTax: 1.5,
                lines: [{ lineNumber: 1, tax: 1.5, taxableAmount: 18 }]
            });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isTrue(result.success);
            assert.isTrue(result.deduplicated);
            assert.equal(result.data.lines[0].tax, 1.5);
            assert.isTrue(avataxServiceStub.createTransaction.notCalled);
        });

        it('should call AvaTax when hash matches but tax snapshot is missing', function () {
            murmurhashStub.hashBytes.returns(55555);
            sessionMock.custom.avataxtransactionmodel = 55555;
            avataxServiceStub.createTransaction.returns({ success: true, data: { totalTax: 2, lines: [] }, latency: 10 });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isFalse(!!result.deduplicated);
            assert.isTrue(avataxServiceStub.createTransaction.calledOnce);
        });

        it('should NOT deduplicate when hash differs from session', function () {
            murmurhashStub.hashBytes.returns(11111);
            sessionMock.custom.avataxtransactionmodel = 22222;
            avataxServiceStub.createTransaction.returns({ success: true, data: {}, latency: 10 });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isFalse(!!result.deduplicated);
            assert.isTrue(avataxServiceStub.createTransaction.calledOnce);
        });

        it('should return error response on API failure', function () {
            avataxServiceStub.createTransaction.returns({ success: false, error: 'Bad request', latency: 30 });

            var result = avataxHelper.callAvaTaxAPI(transactionModel);

            assert.isFalse(result.success);
            assert.equal(result.error, 'Bad request');
        });

});

    // =========================================================================
    // commitTransaction
    // =========================================================================
    describe('commitTransaction', function () {
        it('should call commitTransaction with company code and transaction code', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                saveTransactions: true,
                companyCode: 'MYCO'
            });
            avataxServiceStub.commitTransaction.returns({ success: true, data: {}, latency: 50 });

            avataxHelper.commitTransaction('ORD-100');

            assert.isTrue(avataxServiceStub.commitTransaction.calledOnce);
            assert.equal(avataxServiceStub.commitTransaction.firstCall.args[0], 'MYCO');
            assert.equal(avataxServiceStub.commitTransaction.firstCall.args[1], 'ORD-100');
            assert.deepEqual(avataxServiceStub.commitTransaction.firstCall.args[2], { commit: true });
        });

        it('should pass company code and transaction code to commitTransaction', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                saveTransactions: true,
                companyCode: 'MY CO/INC'
            });
            avataxServiceStub.commitTransaction.returns({ success: true, data: {}, latency: 10 });

            avataxHelper.commitTransaction('ORD 200/A');

            assert.equal(avataxServiceStub.commitTransaction.firstCall.args[0], 'MY CO/INC');
            assert.equal(avataxServiceStub.commitTransaction.firstCall.args[1], 'ORD 200/A');
        });

        it('should return error when saveTransactions is disabled', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ saveTransactions: false });

            var result = avataxHelper.commitTransaction('ORD-1');

            assert.isFalse(result.success);
            assert.include(result.error, 'Document commit not allowed');
            assert.isTrue(avataxServiceStub.commitTransaction.notCalled);
        });

        it('should return error when companyCode is not configured', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                saveTransactions: true,
                companyCode: ''
            });

            var result = avataxHelper.commitTransaction('ORD-1');

            assert.isFalse(result.success);
            assert.include(result.error, 'companyCode not configured');
            assert.isTrue(avataxServiceStub.commitTransaction.notCalled);
        });

});

    // =========================================================================
    // voidTransaction
    // =========================================================================
    describe('voidTransaction', function () {
        it('should call voidTransaction with company code and transaction code', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                saveTransactions: true,
                companyCode: 'VOIDCO'
            });
            avataxServiceStub.voidTransaction.returns({ success: true, data: {}, latency: 30 });

            avataxHelper.voidTransaction('ORD-V1');

            assert.isTrue(avataxServiceStub.voidTransaction.calledOnce);
            assert.equal(avataxServiceStub.voidTransaction.firstCall.args[0], 'VOIDCO');
            assert.equal(avataxServiceStub.voidTransaction.firstCall.args[1], 'ORD-V1');
            assert.deepEqual(avataxServiceStub.voidTransaction.firstCall.args[2], { code: 'DocVoided' });
        });

        it('should return error when saveTransactions is disabled', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ saveTransactions: false });

            var result = avataxHelper.voidTransaction('ORD-V3');

            assert.isFalse(result.success);
            assert.include(result.error, 'Document void not allowed');
            assert.isTrue(avataxServiceStub.voidTransaction.notCalled);
        });

        it('should return error when companyCode is not configured', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({
                saveTransactions: true,
                companyCode: ''
            });

            var result = avataxHelper.voidTransaction('ORD-V4');

            assert.isFalse(result.success);
            assert.include(result.error, 'companyCode not configured');
            assert.isTrue(avataxServiceStub.voidTransaction.notCalled);
        });

});

    // =========================================================================
    // applyTaxesToBasket
    // =========================================================================
    describe('applyTaxesToBasket', function () {
        function createProductLineItemInstance(props) {
            var item = new ProductLineItem();
            Object.assign(item, {
                UUID: props.uuid || 'pli-1',
                setTaxes: sinon.stub(),
                setTaxRate: sinon.stub(),
                setTax: sinon.stub(),
                updateTax: sinon.stub(),
                updateTaxAmount: sinon.stub(),
                bonusProductLineItem: props.bonusProductLineItem || false,
                proratedPrice: props.proratedPrice || { value: 25.00 },
                priceAdjustments: createCollection(props.priceAdjustments || [])
            });
            // Allow direct property set for tax
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }

        function createShippingLineItemInstance(props) {
            var item = new ShippingLineItem();
            Object.assign(item, {
                UUID: props.uuid || 'sli-1',
                setTaxes: sinon.stub(),
                setTaxRate: sinon.stub(),
                setTax: sinon.stub(),
                updateTax: sinon.stub(),
                updateTaxAmount: sinon.stub(),
                adjustedNetPrice: props.adjustedNetPrice || { value: 5.00 },
                adjustedGrossPrice: props.adjustedGrossPrice || { value: 5.00 },
                shippingPriceAdjustments: createCollection(props.shippingPriceAdjustments || [])
            });
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }

        function createProductShippingLineItemInstance(props) {
            var item = new ProductShippingLineItem();
            Object.assign(item, {
                UUID: props.uuid || 'psli-1',
                setTaxRate: sinon.stub(),
                setTax: sinon.stub(),
                updateTax: sinon.stub(),
                updateTaxAmount: sinon.stub(),
                adjustedNetPrice: props.adjustedNetPrice || { value: 5.00 },
                adjustedGrossPrice: props.adjustedGrossPrice || { value: 5.00 },
                netPrice: props.netPrice || { value: 5.00 },
                grossPrice: props.grossPrice || { value: 5.00 },
                priceAdjustments: createCollection(props.priceAdjustments || [])
            });
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }

        it('should set tax rate and tax amount on matched line items', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-1' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 2.50,
                    taxableAmount: 25.00,
                    details: [{
                        jurisdictionType: 'State',
                        jurisName: 'WA',
                        rate: 0.1,
                        tax: 2.5
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-1', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(lineItem.setTaxes.calledOnce);
        });

        it('should fallback to single-level tax when Multilevel Tax is not enabled', function () {
            LineItemTaxMock.throwMultilevel = true;

            var lineItem = createProductLineItemInstance({ uuid: 'uuid-single-level' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 2.5,
                    taxableAmount: 25.00,
                    details: [{
                        jurisdictionType: 'State',
                        jurisName: 'WA',
                        rate: 0.1,
                        tax: 2.5
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-single-level', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(lineItem.setTaxes.notCalled);
            assert.isTrue(lineItem.updateTaxAmount.calledOnce);
            assert.equal(lineItem.updateTaxAmount.firstCall.args[0].value, 2.5);
            assert.isTrue(loggerStub.warn.calledWith('Multilevel Tax is not enabled on this site — applying single-level AvaTax amounts instead.'));

            LineItemTaxMock.throwMultilevel = false;
        });

        it('should apply single-level tax to product shipping line items', function () {
            LineItemTaxMock.throwMultilevel = true;

            var lineItem = createProductShippingLineItemInstance({ uuid: 'uuid-psli' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 0.45,
                    taxableAmount: 5.00,
                    details: [{
                        jurisdictionType: 'State',
                        jurisName: 'WA',
                        rate: 0.09,
                        tax: 0.45
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-psli', shipmentId: 's1', itemId: 'P1-shipping' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(lineItem.updateTaxAmount.called);

            LineItemTaxMock.throwMultilevel = false;
        });

        it('should build multilevel tax items with deterministic ids', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-taxid' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 3.00,
                    taxableAmount: 30.00,
                    details: [
                        { jurisdictionType: 'State', jurisName: 'WASHINGTON', rate: 0.06, tax: 1.8 },
                        { jurisdictionType: 'City', jurisName: 'SEATTLE', rate: 0.04, tax: 1.2 }
                    ]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-taxid', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(lineItem.setTaxes.calledOnce);
            var taxItems = lineItem.setTaxes.firstCall.args[0];
            assert.equal(taxItems.size(), 2);
            assert.equal(taxItems.items[0].taxId, 'State:WASHINGTON');
            assert.equal(taxItems.items[1].taxId, 'City:SEATTLE');
        });

        it('should default missing jurisdiction/rate/tax fields when building LineItemTax', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-defaults' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    details: [{
                        // intentionally missing jurisdictionType, jurisName, rate, tax
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-defaults', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            var taxItems = lineItem.setTaxes.firstCall.args[0];
            assert.equal(taxItems.size(), 1);
            assert.equal(taxItems.items[0].taxId, 'UNKNOWN:UNKNOWN');
            assert.equal(taxItems.items[0].taxRate, 0);
            assert.equal(taxItems.items[0].taxValue.value, 0);
        });

        it('should cap multilevel tax items to 10 and log warning', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-cap' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var details = [];
            for (var i = 0; i < 12; i++) {
                details.push({
                    jurisdictionType: 'J' + i,
                    jurisName: 'N' + i,
                    rate: 0.01,
                    tax: 0.1
                });
            }
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    details: details
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-cap', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            var taxItems = lineItem.setTaxes.firstCall.args[0];
            assert.equal(taxItems.size(), 10);
            assert.isTrue(loggerStub.warn.called);
            assert.isTrue(loggerStub.warn.getCalls().some(function (call) {
                return String(call.args[0]).indexOf('Only the first 10 tax details were applied') >= 0;
            }));
        });

        it('should apply single-level tax when AvaTax line has no details (compact cache)', function () {
            sitePreferences.AVSettings = buildDefaultAvSettings({ taxationpolicy: 'net' });

            var lineItem = createProductLineItemInstance({ uuid: 'uuid-no-details' });
            var basket = createMockBasket({
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 2.50,
                    taxableAmount: 25.00
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-no-details', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(lineItem.updateTaxAmount.called);
            assert.isTrue(lineItem.setTax.calledOnce);
            var lastUpdateTaxCall = lineItem.updateTaxAmount.lastCall;
            assert.isAbove(lastUpdateTaxCall.args[0].value, 0);
        });

        it('should handle missing UUID mapping gracefully', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 99, tax: 1.00, taxableAmount: 10.00 }]
            };
            var lineUUIDMap = {};

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(loggerStub.warn.called);
            assert.include(loggerStub.warn.firstCall.args[0], '99');
        });

        it('should handle line item not found for UUID gracefully', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }]
            };
            var lineUUIDMap = { 1: { uuid: 'missing-uuid', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(loggerStub.warn.called);
            assert.isTrue(loggerStub.warn.getCalls().some(function (call) {
                return String(call.args[0]).indexOf('missing-uuid') >= 0;
            }));
        });

        it('should zero out price adjustments on ProductLineItem', function () {
            var pa = { updateTax: sinon.stub() };
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-pa', priceAdjustments: [pa] });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-pa', shipmentId: 's', itemId: 'P' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(pa.updateTax.calledWith(0));
        });

        it('should zero out shipping price adjustments on ShippingLineItem', function () {
            var spa = { updateTax: sinon.stub() };
            var lineItem = createShippingLineItemInstance({ uuid: 'uuid-spa', shippingPriceAdjustments: [spa] });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [{ lineNumber: 1, tax: 0.50, taxableAmount: 5 }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-spa', shipmentId: 's', itemId: 'S' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isTrue(spa.updateTax.calledWith(0));
        });

        it('should zero out basket-level price adjustments', function () {
            var basketPA = { updateTax: sinon.stub() };
            var basketSPA = { updateTax: sinon.stub() };
            var basket = createMockBasket({
                allLineItems: [],
                priceAdjustments: [basketPA],
                shippingPriceAdjustments: [basketSPA]
            });
            var avaTaxResponse = { lines: [] };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, {});

            assert.isTrue(basketPA.updateTax.calledWith(0));
            assert.isTrue(basketSPA.updateTax.calledWith(0));
        });

        it('should call basket.updateTotals at the end', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = { lines: [] };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, {});

            assert.isTrue(basket.updateTotals.calledOnce);
        });

        it('should handle null response gracefully', function () {
            var basket = createMockBasket({ allLineItems: [] });

            avataxHelper.applyTaxesToBasket(basket, null, {});

            assert.isTrue(loggerStub.warn.called);
        });

        // --- storeTaxDetails (tested indirectly) ---
        it('should store tax jurisdiction details in basket.custom.ATTaxDetail', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-td' });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 2.00,
                    taxableAmount: 20.00,
                    details: [
                        {
                            jurisdictionType: 'State',
                            jurisName: 'WASHINGTON',
                            exemptAmount: 0,
                            nonTaxableAmount: 0,
                            taxableAmount: 20,
                            rate: 0.065,
                            tax: 1.30
                        },
                        {
                            jurisdictionType: 'City',
                            jurisName: 'SEATTLE',
                            exemptAmount: 0,
                            nonTaxableAmount: 0,
                            taxableAmount: 20,
                            rate: 0.035,
                            tax: 0.70
                        }
                    ]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-td', shipmentId: 's1', itemId: 'ITEM-1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.isDefined(basket.custom.ATTaxDetail);
            var parsed = JSON.parse(basket.custom.ATTaxDetail);
            assert.equal(parsed.length, 1);
            assert.equal(parsed[0].lineitemid, 'ITEM-1');
            assert.equal(parsed[0].shipmentid, 's1');
            assert.equal(parsed[0].taxes.length, 2);
            assert.equal(parsed[0].taxes[0].jurisdiction, 'WASHINGTON');
            assert.equal(parsed[0].taxes[1].jurisdiction, 'SEATTLE');
        });

        it('should not store empty objects for lines without details', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-blank' });
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var avaTaxResponse = {
                lines: [
                    {
                        lineNumber: 1,
                        tax: 2.00,
                        taxableAmount: 20.00,
                        details: [{
                            jurisdictionType: 'State',
                            jurisName: 'WASHINGTON',
                            exemptAmount: 0,
                            nonTaxableAmount: 0,
                            taxableAmount: 20,
                            rate: 0.1,
                            tax: 2.0
                        }]
                    },
                    {
                        lineNumber: 2,
                        tax: 0,
                        taxableAmount: 0
                    }
                ]
            };
            var lineUUIDMap = {
                1: { uuid: 'uuid-blank', shipmentId: 's1', itemId: 'ITEM-1' }
            };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            var parsed = JSON.parse(basket.custom.ATTaxDetail);
            assert.equal(parsed.length, 2);
            assert.equal(parsed[0].lineitemid, 'ITEM-1');
            assert.isUndefined(parsed[1].taxes);
        });

        // --- storeInvoiceMessages (tested indirectly) ---
        it('should store VAT invoice messages in basket.custom.ATInvoiceMessage', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var avaTaxResponse = {
                lines: [{
                    lineNumber: 1,
                    tax: 1,
                    taxableAmount: 10,
                    details: [{
                        jurisdictionType: 'Country',
                        jurisName: 'DE',
                        rate: 0.19,
                        tax: 1
                    }]
                }],
                invoiceMessages: [
                    { content: 'VAT: 20% standard rate applies' }
                ]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-inv', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.equal(basket.custom.ATInvoiceMessage, 'VAT: 20% standard rate applies');
        });

        it('should store landed cost, customs duty, generic messages, and summary tax attributes', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-xborder' });
            var basket = createMockBasket({
                uuid: 'basket-xborder',
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                summary: [
                    { taxType: 'LandedCost', taxSubType: 'ImportDuty', tax: 5.25 },
                    { taxType: 'SalesTax', taxSubType: 'Standard', tax: 2.75 }
                ],
                messages: [
                    {
                        refersTo: 'LandedCost',
                        severity: 'Success',
                        summary: 'Landed cost calculated',
                        details: 'Import duty included'
                    },
                    {
                        refersTo: 'General',
                        severity: 'Warning',
                        summary: 'Note',
                        details: 'Additional documentation may be required'
                    }
                ],
                lines: [{
                    lineNumber: 1,
                    tax: 8,
                    taxableAmount: 100,
                    vatCode: 'DE-S',
                    details: [{
                        jurisdictionType: 'Country',
                        jurisName: 'DE',
                        rate: 0.19,
                        tax: 8,
                        taxName: 'VAT',
                        taxSubTypeId: 'Standard',
                        taxType: 'Output'
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-xborder', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.equal(basket.custom.ATTax, '2.75');
            assert.equal(basket.custom.ATCustomsDuty, '5.25');
            assert.equal(basket.custom.ATLandedCost, 'Landed cost calculated Import duty included');
            assert.include(basket.custom.ATGenericMessage, 'General - Additional documentation may be required');
            assert.equal(basket.custom.ATVatCode, 'Line 1: DE-S;');
        });

        it('should store ATTax summary attribute without ATDocCode persistence', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-summary' });
            var basket = createMockBasket({
                uuid: 'basket-doc-123',
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                totalTax: 3.75,
                lines: [{
                    lineNumber: 1,
                    tax: 3.75,
                    taxableAmount: 37.50,
                    details: [{
                        jurisdictionType: 'State',
                        jurisName: 'WA',
                        rate: 0.1,
                        tax: 3.75
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-summary', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.equal(basket.custom.ATTax, '3.75');
            assert.isUndefined(basket.custom.ATDocCode);
        });

        it('should use totalTax for ATTax when summary rows sum to zero', function () {
            var lineItem = createProductLineItemInstance({ uuid: 'uuid-summary-fallback' });
            var basket = createMockBasket({
                uuid: 'basket-summary-fallback',
                currency: 'USD',
                allLineItems: [lineItem]
            });
            var avaTaxResponse = {
                totalTax: 3.86,
                summary: [
                    { taxType: 'SalesTax', taxSubType: 'Standard', tax: 0 }
                ],
                lines: [{
                    lineNumber: 1,
                    tax: 3.86,
                    taxableAmount: 38.60,
                    details: [{
                        jurisdictionType: 'State',
                        jurisName: 'WA',
                        rate: 0.1,
                        tax: 3.86
                    }]
                }]
            };
            var lineUUIDMap = { 1: { uuid: 'uuid-summary-fallback', shipmentId: 's1', itemId: 'P1' } };

            avataxHelper.applyTaxesToBasket(basket, avaTaxResponse, lineUUIDMap);

            assert.equal(basket.custom.ATTax, '3.86');
        });
    });

    // =========================================================================
    // getLineItemByUUID (tested indirectly via applyTaxesToBasket)
    // =========================================================================
    describe('getLineItemByUUID (via applyTaxesToBasket)', function () {
        it('should find a regular line item by UUID', function () {
            var lineItem = createMockProductLineItemForApply('target-uuid');
            var basket = createMockBasket({ allLineItems: [lineItem] });
            var response = {
                lines: [{
                    lineNumber: 1,
                    tax: 1,
                    taxableAmount: 10,
                    details: [{
                        jurisdictionType: 'State',
                        jurisName: 'WA',
                        rate: 0.1,
                        tax: 1
                    }]
                }]
            };
            var map = { 1: { uuid: 'target-uuid', shipmentId: 's', itemId: 'P' } };

            avataxHelper.applyTaxesToBasket(basket, response, map);

            assert.isTrue(lineItem.setTaxes.called);
        });

        it('should find nested shippingLineItem by UUID', function () {
            var nestedSli = {
                UUID: 'nested-sli-uuid',
                setTaxes: sinon.stub()
            };
            Object.defineProperty(nestedSli, 'tax', { writable: true, value: null });

            var parentPli = new ProductLineItem();
            Object.assign(parentPli, {
                UUID: 'parent-uuid',
                shippingLineItem: nestedSli,
                setTaxes: sinon.stub()
            });

            var basket = createMockBasket({ allLineItems: [parentPli] });
            var response = {
                lines: [{
                    lineNumber: 1,
                    tax: 0.50,
                    taxableAmount: 5,
                    details: [{
                        jurisdictionType: 'County',
                        jurisName: 'KING',
                        rate: 0.1,
                        tax: 0.5
                    }]
                }]
            };
            var map = { 1: { uuid: 'nested-sli-uuid', shipmentId: 's', itemId: 'SLI' } };

            avataxHelper.applyTaxesToBasket(basket, response, map);

            assert.isTrue(nestedSli.setTaxes.called);
        });

        it('should return null and log warning when UUID not found', function () {
            var basket = createMockBasket({ allLineItems: [] });
            var response = { lines: [{ lineNumber: 1, tax: 1, taxableAmount: 10 }] };
            var map = { 1: { uuid: 'nonexistent', shipmentId: 's', itemId: 'P' } };

            avataxHelper.applyTaxesToBasket(basket, response, map);

            assert.isTrue(loggerStub.warn.called);
            assert.isTrue(loggerStub.warn.getCalls().some(function (call) {
                return String(call.args[0]).indexOf('nonexistent') >= 0;
            }));
        });

        function createMockProductLineItemForApply(uuid) {
            var item = new ProductLineItem();
            item.UUID = uuid;
            item.setTaxes = sinon.stub();
            item.priceAdjustments = createCollection([]);
            Object.defineProperty(item, 'tax', { writable: true, value: null });
            return item;
        }
    });
});
