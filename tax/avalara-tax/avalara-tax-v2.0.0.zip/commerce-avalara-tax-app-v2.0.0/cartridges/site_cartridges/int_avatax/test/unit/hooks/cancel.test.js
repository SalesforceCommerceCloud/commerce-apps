'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

describe('cancel hook', function () {
    var cancelHook;
    var avataxHelperStub;
    var loggerStub;

    beforeEach(function () {
        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub()
        };

        avataxHelperStub = {
            getConfig: sinon.stub(),
            voidTransaction: sinon.stub()
        };

        cancelHook = proxyquire(
            '../../../cartridge/scripts/hooks/cancel',
            {
                'dw/system/Logger': {
                    getLogger: sinon.stub().returns(loggerStub)
                },
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/avataxHelper': avataxHelperStub
            }
        );
    });

    afterEach(function () {
        sinon.restore();
    });

    function createMockOrder(orderNo) {
        return {
            getOrderNo: sinon.stub().returns(orderNo || 'ORDER-001')
        };
    }

    // =============================================
    // Test: AvaTax disabled
    // =============================================
    describe('when AvaTax is disabled', function () {
        it('should return Status.ERROR with AVATAX_DISABLED code', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: false });
            var order = createMockOrder();

            var result = cancelHook.cancel(order);

            assert.equal(result.status, Status.ERROR);
            assert.equal(result.code, 'AVATAX_DISABLED');
            assert.isTrue(avataxHelperStub.voidTransaction.notCalled);
        });
    });

    // =============================================
    // Test: Successful void
    // =============================================
    describe('when void succeeds', function () {
        it('should call voidTransaction with the order number', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.returns({ success: true });
            var order = createMockOrder('ORD-CANCEL-1');

            cancelHook.cancel(order);

            assert.isTrue(avataxHelperStub.voidTransaction.calledOnce);
            assert.isTrue(avataxHelperStub.voidTransaction.calledWith('ORD-CANCEL-1'));
        });

        it('should return TAX_VOIDED with order number in message', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.returns({ success: true });
            var order = createMockOrder('ORD-CANCEL-1');

            var result = cancelHook.cancel(order);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'TAX_VOIDED');
            assert.include(result.message, 'ORD-CANCEL-1');
        });
    });

    // =============================================
    // Test: API failure
    // =============================================
    describe('when void API call fails', function () {
        it('should return Status.ERROR with TAX_VOID_FAILED code', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.returns({
                success: false,
                details: 'Transaction already voided'
            });
            var order = createMockOrder('ORD-V-1');

            var result = cancelHook.cancel(order);

            assert.equal(result.status, Status.ERROR);
            assert.equal(result.code, 'TAX_VOID_FAILED');
        });

        it('should include the error and order number in status message', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.returns({
                success: false,
                details: 'Network error'
            });
            var order = createMockOrder('ORD-NET');

            var result = cancelHook.cancel(order);

            assert.include(result.message, 'Network error');
            assert.include(result.message, 'ORD-NET');
        });

        it('should log the error with order number', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.returns({
                success: false,
                details: 'Auth failed'
            });
            var order = createMockOrder('ORD-LOG-1');

            cancelHook.cancel(order);

            assert.isTrue(loggerStub.error.calledOnce);
            var logMessage = loggerStub.error.firstCall.args[0];
            assert.include(logMessage, 'ORD-LOG-1');
            assert.include(logMessage, 'Auth failed');
        });
    });

    // =============================================
    // Test: Exception during void
    // =============================================
    describe('when an exception is thrown', function () {
        it('should return Status.ERROR with TAX_VOID_EXCEPTION code', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.throws(new Error('Runtime crash'));
            var order = createMockOrder('ORD-EXC-1');

            var result = cancelHook.cancel(order);

            assert.equal(result.status, Status.ERROR);
            assert.equal(result.code, 'TAX_VOID_EXCEPTION');
            assert.include(result.message, 'Runtime crash');
            assert.include(result.message, 'ORD-EXC-1');
        });

        it('should log the exception with order number and stack', function () {
            var err = new Error('Serialization error');
            err.stack = 'Error: Serialization error\n    at cancel.js:30';
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.voidTransaction.throws(err);
            var order = createMockOrder('ORD-EXC-2');

            cancelHook.cancel(order);

            assert.isTrue(loggerStub.error.calledOnce);
            var logMessage = loggerStub.error.firstCall.args[0];
            assert.include(logMessage, 'ORD-EXC-2');
            assert.include(logMessage, 'Serialization error');
        });
    });
});
