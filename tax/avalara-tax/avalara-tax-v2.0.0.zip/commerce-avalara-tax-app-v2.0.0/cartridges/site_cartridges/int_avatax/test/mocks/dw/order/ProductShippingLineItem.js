'use strict';

function ProductShippingLineItem() {}

module.exports = ProductShippingLineItem;
