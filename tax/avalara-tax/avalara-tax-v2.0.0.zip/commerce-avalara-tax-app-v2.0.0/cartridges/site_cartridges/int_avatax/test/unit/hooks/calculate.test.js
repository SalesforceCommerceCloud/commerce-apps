'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');
var Money = require('../../mocks/dw/value/Money');
var ArrayList = function () {
    this.items = [];
};
ArrayList.prototype.add = function (item) {
    this.items.push(item);
};

describe('calculate hook', function () {
    var calculateHook;
    var avataxHelperStub;
    var loggerStub;

    beforeEach(function () {
        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub(),
            debug: sinon.stub()
        };

        avataxHelperStub = {
            getConfig: sinon.stub(),
            buildTransactionModel: sinon.stub(),
            callAvaTaxAPI: sinon.stub(),
            applyTaxesToBasket: sinon.stub(),
            setLineItemTaxToZero: sinon.stub().callsFake(function (lineItem) {
                lineItem.updateTax(0);
            })
        };

        calculateHook = proxyquire(
            '../../../cartridge/scripts/hooks/calculate',
            {
                'dw/system/Logger': {
                    getLogger: sinon.stub().returns(loggerStub)
                },
                'dw/system/Status': Status,
                'dw/value/Money': Money,
                'dw/util/ArrayList': ArrayList,
                '~/cartridge/scripts/helpers/avataxHelper': avataxHelperStub
            }
        );
    });

    afterEach(function () {
        sinon.restore();
    });

    // --- Helper to build a mock lineItemCtnr ---
    function createMockBasket(options) {
        options = options || {};
        var lineItems = options.lineItems || [];

        return {
            getCurrencyCode: sinon.stub().returns('USD'),
            getAllLineItems: sinon.stub().returns({
                iterator: function () {
                    var index = 0;
                    return {
                        hasNext: function () { return index < lineItems.length; },
                        next: function () { return lineItems[index++]; }
                    };
                }
            })
        };
    }

    // =============================================
    // Test: AvaTax disabled
    // =============================================
    describe('when AvaTax is disabled', function () {
        it('should return Status.OK and skip calculation when AvaTax is disabled', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: false });
            var basket = createMockBasket();

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'AVATAX_DISABLED');
            assert.isTrue(avataxHelperStub.buildTransactionModel.notCalled);
            assert.isTrue(avataxHelperStub.callAvaTaxAPI.notCalled);
        });
    });

    // =============================================
    // Test: Null basket
    // =============================================
    describe('when lineItemCtnr is null', function () {
        it('should return Status.OK when lineItemCtnr is null', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });

            var result = calculateHook.calculate(null);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'EMPTY_BASKET');
            assert.isTrue(avataxHelperStub.buildTransactionModel.notCalled);
        });
    });

    // =============================================
    // Test: No taxable lines
    // =============================================
    describe('when basket has no taxable line items', function () {
        it('should return Status.OK with NO_TAXABLE_ITEMS when lines array is empty', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.buildTransactionModel.returns({
                model: { lines: [] },
                lineUUIDMap: {}
            });
            var basket = createMockBasket();

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'NO_TAXABLE_ITEMS');
            assert.isTrue(avataxHelperStub.callAvaTaxAPI.notCalled);
        });

        it('should return Status.OK when lines is null', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.buildTransactionModel.returns({
                model: { lines: null },
                lineUUIDMap: {}
            });
            var basket = createMockBasket();

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.isTrue(avataxHelperStub.callAvaTaxAPI.notCalled);
        });
    });

    // =============================================
    // Test: Successful tax calculation
    // =============================================
    describe('when API call succeeds', function () {
        it('should apply taxes to basket and return TAX_CALCULATED', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            var mockModel = { lines: [{ number: 1 }] };
            var mockUUIDMap = { 1: { uuid: 'uuid-1' } };
            avataxHelperStub.buildTransactionModel.returns({
                model: mockModel,
                lineUUIDMap: mockUUIDMap
            });
            var mockResponse = { success: true, data: { lines: [] } };
            avataxHelperStub.callAvaTaxAPI.returns(mockResponse);
            var basket = createMockBasket();

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'TAX_CALCULATED');
            assert.isTrue(avataxHelperStub.callAvaTaxAPI.calledOnce);
            assert.isTrue(avataxHelperStub.callAvaTaxAPI.calledWith(mockModel));
            assert.isTrue(avataxHelperStub.applyTaxesToBasket.calledOnce);
            assert.isTrue(avataxHelperStub.applyTaxesToBasket.calledWith(basket, mockResponse.data, mockUUIDMap));
        });
    });

    // =============================================
    // Test: API failure falls back to zero tax
    // =============================================
    describe('when API call fails', function () {
        it('should set zero tax and return TAX_API_ERROR', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.buildTransactionModel.returns({
                model: { lines: [{ number: 1 }] },
                lineUUIDMap: {}
            });
            avataxHelperStub.callAvaTaxAPI.returns({ success: false, details: 'timeout' });

            var mockLineItem = {
                netPrice: { value: 10 },
                setPriceValue: sinon.stub(),
                updateTax: sinon.stub()
            };
            var basket = createMockBasket({ lineItems: [mockLineItem] });

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'TAX_API_ERROR');
            assert.include(result.message, 'timeout');
            assert.isTrue(avataxHelperStub.applyTaxesToBasket.notCalled);
            assert.isTrue(mockLineItem.updateTax.calledWith(0));
        });
    });

    // =============================================
    // Test: Deduplicated response
    // =============================================
    describe('when response is deduplicated', function () {
        it('should re-apply cached taxes when response is deduplicated', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.buildTransactionModel.returns({
                model: { lines: [{ number: 1 }] },
                lineUUIDMap: { 1: { uuid: 'uuid-1' } }
            });
            avataxHelperStub.callAvaTaxAPI.returns({
                success: true,
                data: { lines: [{ lineNumber: 1, tax: 1.66, taxableAmount: 18 }] },
                deduplicated: true
            });
            var basket = createMockBasket();

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'DEDUPLICATED');
            assert.isTrue(avataxHelperStub.applyTaxesToBasket.calledOnce);
        });
    });

    // =============================================
    // Test: Exception during calculation
    // =============================================
    describe('when an exception is thrown', function () {
        it('should set zero tax and return Status.OK so SCAPI basket updates are not blocked', function () {
            avataxHelperStub.getConfig.returns({ taxCalculation: true });
            avataxHelperStub.buildTransactionModel.throws(new Error('Something broke'));

            var mockLineItem = {
                updateTax: sinon.stub()
            };
            var basket = createMockBasket({ lineItems: [mockLineItem] });

            var result = calculateHook.calculate(basket);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'TAX_CALCULATION_EXCEPTION');
            assert.include(result.message, 'Something broke');
            assert.isTrue(mockLineItem.updateTax.calledWith(0));
            assert.isTrue(avataxHelperStub.setLineItemTaxToZero.calledOnce);
            assert.isTrue(loggerStub.error.calledOnce);
        });
    });
});
