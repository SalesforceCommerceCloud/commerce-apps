'use strict';

function Order() {}

module.exports = Order;
