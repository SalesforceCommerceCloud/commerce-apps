'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

describe('calculateTax hook', function () {
    var calculateTaxHook;
    var calculateStub;
    var loggerStub;

    beforeEach(function () {
        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub()
        };

        calculateStub = {
            calculate: sinon.stub().returns(new Status(Status.OK))
        };

        calculateTaxHook = proxyquire('../../../cartridge/scripts/hooks/calculateTax', {
            './calculate': calculateStub,
            'dw/system/Logger': {
                getLogger: sinon.stub().returns(loggerStub)
            },
            'dw/system/Status': Status
        });
    });

    it('should delegate to calculate hook calculate function', function () {
        var basket = { basketId: 'test-basket' };
        var result = calculateTaxHook.calculateTax(basket);

        assert.isTrue(calculateStub.calculate.calledOnceWith(basket));
        assert.instanceOf(result, Status);
        assert.equal(result.status, Status.OK);
    });
});
