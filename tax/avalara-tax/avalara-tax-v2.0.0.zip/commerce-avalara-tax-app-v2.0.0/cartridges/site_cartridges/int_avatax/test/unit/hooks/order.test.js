'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

describe('order hook', function () {
    var orderHook;
    var avataxHelperStub;
    var loggerStub;

    beforeEach(function () {
        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub()
        };

        avataxHelperStub = {
            getConfig: sinon.stub(),
            finalizeOrderTransaction: sinon.stub()
        };

        orderHook = proxyquire(
            '../../../cartridge/scripts/hooks/order',
            {
                'dw/system/Logger': {
                    getLogger: sinon.stub().returns(loggerStub)
                },
                '~/cartridge/scripts/helpers/avataxHelper': avataxHelperStub
            }
        );
    });

    afterEach(function () {
        sinon.restore();
    });

    it('should finalize the AvaTax transaction after order creation', function () {
        avataxHelperStub.getConfig.returns({ taxCalculation: true });
        avataxHelperStub.finalizeOrderTransaction.returns({ success: true, data: {} });

        var order = { getOrderNo: sinon.stub().returns('ORD-100') };
        orderHook.afterPOST(order);

        assert.isTrue(avataxHelperStub.finalizeOrderTransaction.calledOnce);
        assert.isTrue(avataxHelperStub.finalizeOrderTransaction.calledWith(order));
    });

    it('should skip finalization when AvaTax is disabled', function () {
        avataxHelperStub.getConfig.returns({ taxCalculation: false });

        orderHook.afterPOST({ getOrderNo: sinon.stub().returns('ORD-100') });

        assert.isTrue(avataxHelperStub.finalizeOrderTransaction.notCalled);
    });

    it('should log errors without throwing when finalization fails', function () {
        avataxHelperStub.getConfig.returns({ taxCalculation: true });
        avataxHelperStub.finalizeOrderTransaction.returns({
            success: false,
            error: 'CreateTransaction failed'
        });

        orderHook.afterPOST({ getOrderNo: sinon.stub().returns('ORD-200') });

        assert.isTrue(loggerStub.error.calledOnce);
        assert.include(loggerStub.error.firstCall.args[0], 'ORD-200');
    });
});
