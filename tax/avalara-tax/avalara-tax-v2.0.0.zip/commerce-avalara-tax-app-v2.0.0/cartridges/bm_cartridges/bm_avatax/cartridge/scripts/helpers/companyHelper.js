'use strict';

var dwlogger = require('dw/system/Logger');
var avaTaxClient = require('~/cartridge/scripts/services/avataxService');

var LOGGER = dwlogger.getLogger('Avalara', 'AvaTax');

/**
 * Fetches companies for current AvaTax user.
 *
 * @returns {Array}
 */
function getCompanies() {
    var companies = [];
    try {
        var svcResponse = avaTaxClient.getCompanies();
        if (!svcResponse.statusCode && !!svcResponse.value) {
            var count = svcResponse.value.length;
            for (var i = 0; i < count; i++) {
                var company = svcResponse.value[i];
                companies.push({
                    id: company.id || '',
                    companyCode: company.companyCode,
                    name: company.name,
                    isDefault: company.isDefault,
                    isActive: company.isActive
                });
            }
        }
    } catch (error) {
        LOGGER.warn('Problem while fetching companies from AvaTax account' + error);
    }
    return companies;
}

/**
 * Verifies whether the entered company code string is a valid company.
 * If valid, returns company ID.
 *
 * @param {string} companyCode
 * @returns {string}
 */
function verifyCompanyCode(companyCode) {
    var companyId = '';
    if (empty(companyCode)) {
        return companyId;
    }
    try {
        var companies = getCompanies();
        for (var i = 0; i < companies.length; i++) {
            var company = companies[i];
            if (companyCode.toLowerCase() === company.companyCode.toLowerCase()) {
                companyId = company.id;
                break;
            }
        }
    } catch (error) {
        LOGGER.warn('There was a problem processing this request. Please try again.' + error);
    }
    return companyId;
}

module.exports = {
    getCompanies: getCompanies,
    verifyCompanyCode: verifyCompanyCode
};
