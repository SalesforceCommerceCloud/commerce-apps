'use strict';

var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');
var Logger = require('dw/system/Logger');
var Site = require('dw/system/Site');
var cache = require('~/cartridge/scripts/avatax/avataxSettingsCache');

/**
 * Updates site preferences with new settings
 */
function updateSitePreferences(settings) {
    try {
        Transaction.wrap(() => {
            Site.getCurrent().setCustomPreferenceValue('AVSettings', JSON.stringify(settings));
        });
        Logger.warn('Auto sync completed successfully. Updated cartridge configuration with latest settings from Avalara.'+JSON.stringify(settings));
          
        return true;
    } catch (error) {
        Logger.warn('Failed to update AVSettings. Details: '+ JSON.stringify(error));
        return false;
    }
}

/**
 * Validates site context and settings
 * @returns {Object} - Validation result
 */
function validateSitePreferences() {
    const currentSite = Site.getCurrent();
    if (!currentSite) {
        return { isValid: false, error: 'Site context not available' };
    }

    const avSettings = currentSite.getCustomPreferenceValue('AVSettings');
    if (!avSettings) {
        return { isValid: false, error: 'AVSettings not found in site preferences' };
    }

    try {
        var parsedSettings = JSON.parse(avSettings);
        if (!parsedSettings.configId) {
            return { isValid: false, error: 'Config ID not created for current site. Please go to Avalara Settings page and click Connect to Sandbox/Production.' };
        }
        
        Logger.warn('Fetching Configuration settings from Avalara for Config ID: '+ JSON.stringify(parsedSettings.configId));
        return { isValid: true, settings: parsedSettings };
    } catch (error) {
        return { isValid: false, error: error };
    }
}

/**
* Sync Avalara Settings Job Step
* @returns {dw.system.Status} Status of the job step execution
*/
module.exports = {
    execute: function () {
        // Initialize status
        let statusMessage = '';
        let statusCode = Status.OK;

        try {
            Logger.warn('Starting Avalara sync');

            // Validate site preferences and settings
            const validation = validateSitePreferences();
            if (!validation.isValid) {
                throw new Error(validation.error);
            }

            // Fetch new settings
            var fetchSettings = cache.autoSync();
            if (!fetchSettings) {
                throw new Error('Failed to fetch Avalara configuration settings');
            }

            // Update site preferences
            const updateSuccess = updateSitePreferences(fetchSettings);
            if (!updateSuccess) {
                throw new Error('Failed to update site preferences');
            }
            
            statusMessage = 'Avalara settings sync completed and metadata updated successfully.';
            Logger.warn(statusMessage);

        } catch (error) {
            statusCode = Status.ERROR;
            statusMessage = 'Failed to sync Avalara settings. Details: '+ JSON.stringify(error);
            Logger.warn(statusMessage);
        }

        return new Status(statusCode, statusCode === Status.OK ? 'OK' : 'ERROR', statusMessage);
    }
};

