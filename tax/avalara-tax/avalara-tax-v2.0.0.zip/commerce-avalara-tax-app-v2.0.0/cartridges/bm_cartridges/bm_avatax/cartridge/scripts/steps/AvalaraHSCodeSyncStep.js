'use strict';

var Status = require('dw/system/Status');
var Transaction = require('dw/system/Transaction');
var Logger = require('dw/system/Logger').getLogger('Avalara', 'HSCodeSync');
var ProductMgr = require('dw/catalog/ProductMgr');

// Load avataxService from bm_avatax cartridge
var avaTaxClient;

/**
 * Configuration for batch processing
 */
var BATCH_CONFIG = {
    BATCH_SIZE: 10, 
    DEFAULT_COUNTRY: 'US' // Default country of destination for classification
};

/**
 * @param {dw.catalog.Product} product - The SFCC product object
 * @returns {Object} Product data formatted for HS Code API request
 */
function buildProductPayload(product) {
    var payload = {
        product_title: product.name || product.ID,
        cod: BATCH_CONFIG.DEFAULT_COUNTRY
    };

    // Get product description
    if (product.shortDescription && product.shortDescription.markup) {
        payload.product_description = product.shortDescription.markup;
    } else if (product.longDescription && product.longDescription.markup) {
        payload.product_description = product.longDescription.markup;
    }

    if (product.primaryCategory) {
        var categoryPath = [];
        var cat = product.primaryCategory;
        while (cat) {
            categoryPath.unshift(cat.displayName || cat.ID);
            cat = cat.parent;
        }
        payload.product_category = categoryPath.join(' > ');
    }

    if (product.priceModel && product.priceModel.price && product.priceModel.price.available) {
        payload.price = product.priceModel.price.currencyCode + ' ' + product.priceModel.price.value;
    }

    if (product.image && product.image.absURL) {
        payload.image_url = product.image.absURL.toString();
    }

    var attributes = [];

    // Add country of manufacture
    if ('ATCountryOfManufacture' in product.custom && product.custom.ATCountryOfManufacture) {
        attributes.push({ 'Country of Origin': product.custom.ATCountryOfManufacture });
        payload.cod = product.custom.ATCountryOfManufacture;
    }

    if ('ATProductCategory' in product.custom && product.custom.ATProductCategory) {
        attributes.push({ 'Avalara Category': product.custom.ATProductCategory });
    }

    if (product.brand) {
        attributes.push({ 'Brand': product.brand });
    }

    if ('ATNetWeightValue' in product.custom && product.custom.ATNetWeightValue) {
        var weightUnit = product.custom.ATNetWeightUOM || 'kg';
        attributes.push({ 'Net Weight': product.custom.ATNetWeightValue + ' ' + weightUnit });
    }

    if (attributes.length > 0) {
        payload.attributes = attributes;
    }

    return payload;
}

/**
 * Updates the product with the retrieved HS code in ATAutomatedHSCode field
 * 
 * @param {dw.catalog.Product} product - The product object (used for ID)
 * @param {number|string} hsCode - The HS code to save
 * @param {string} confidence - The confidence level (HIGH, MEDIUM, LOW)
 * @returns {boolean} Success status
 */
function updateProductHSCode(product, hsCode, confidence) {
    var productId = product.ID;
    
    try {
        Transaction.wrap(function () {
            // Re-fetch the product fresh to avoid optimistic locking
            var freshProduct = ProductMgr.getProduct(productId);
            
            if (!freshProduct) {
                throw new Error('Product not found: ' + productId);
            }
            
            // Update the automated HS Code field (not the manual one)
            freshProduct.custom.ATAutomatedHSCode = String(hsCode);
        });
        Logger.debug('Updated ATAutomatedHSCode for product {0}: {1} (confidence: {2})', 
            productId, hsCode, confidence || 'N/A');
        return true;
    } catch (e) {
        Logger.error('Failed to update HS code for product {0}: {1}', productId, e.message);
        return false;
    }
}

/**
 * Gets all products with ATEnableHSCodeAutomatedJob set to true
 * These are products marked as "Classification Required" in Business Manager
 * 
 * @returns {Array} Array of products to process
 */
function getEnabledProducts() {
    var enabledProducts = [];
    var products = ProductMgr.queryAllSiteProducts();

    Logger.info('Scanning products for Classification Required flag...');

    while (products.hasNext()) {
        var product = products.next();

        // Check if product has ATEnableHSCodeAutomatedJob set to true
        if ('ATEnableHSCodeAutomatedJob' in product.custom && 
            product.custom.ATEnableHSCodeAutomatedJob === true) {
            enabledProducts.push(product);
        }
    }

    products.close();

    Logger.info('Found {0} products with Classification Required = Yes', enabledProducts.length);
    return enabledProducts;
}

/**
 * Processes a batch of products through the HS Code API
 * 
 * @param {Array} productBatch - Array of products to process
 * @param {Object} stats - Statistics object to track progress
 * @returns {Object} Updated statistics
 */
function processBatch(productBatch, stats) {
    // Build API request payloads for all products in batch
    var apiPayloads = [];
    var productMap = {};

    productBatch.forEach(function (product, index) {
        var payload = buildProductPayload(product);
        apiPayloads.push(payload);
        productMap[index] = product;
    });

    Logger.info('Calling HS Code API for batch of {0} products', apiPayloads.length);

    // Call the Avalara HS Code Classification API
    var apiResult = avaTaxClient.classifyHSCode(apiPayloads);

    if (apiResult.success && apiResult.classifications) {
        // Process each classification result
        apiResult.classifications.forEach(function (classification, index) {
            var product = productMap[index];

            if (classification && classification.code) {
                // Update the product with the retrieved HS code
                var updateSuccess = updateProductHSCode(
                    product, 
                    classification.code, 
                    classification.confidence
                );

                if (updateSuccess) {
                    stats.successCount++;
                    Logger.info('Product {0}: HS Code = {1}, Confidence = {2}', 
                        product.ID, classification.code, classification.confidence);
                } else {
                    stats.errorCount++;
                }
            } else {
                stats.errorCount++;
                Logger.warn('No HS code returned for product {0}', product.ID);
            }
        });
    } else {
        // API call failed - log error for all products in batch
        Logger.error('HS Code API call failed: {0}', 
            JSON.stringify(apiResult.errorMessage || 'Unknown error'));
        stats.errorCount += productBatch.length;
    }

    return stats;
}

/**
 * HS Code Sync Job Step
 * 
 * This scheduled job:
 * 1. Queries all products in Business Manager
 * 2. Finds products where ATEnableHSCodeAutomatedJob (Classification Required?) = Yes
 * 3. Calls the Avalara HS Code Classification API to fetch HS codes
 * 4. Updates the ATAutomatedHSCode field with retrieved values (shown on UI)
 * 
 * Note: The manual ATHSCode field is NOT overwritten by this job.
 * 
 * @returns {dw.system.Status} Status of the job step execution
 */
module.exports = {
    execute: function () {
        var statusMessage = '';
        var statusCode = Status.OK;
        var stats = {
            processedCount: 0,
            successCount: 0,
            errorCount: 0
        };

        try {
            // Load avaTaxClient inside execute to ensure proper module resolution
            avaTaxClient = require('~/cartridge/scripts/services/avataxService');
            
            Logger.info('===========================================');
            Logger.info('Starting Avalara HS Code Classification Sync Job');
            Logger.info('Batch Size: {0}', BATCH_CONFIG.BATCH_SIZE);
            Logger.info('===========================================');

            // Step 1: Get all products with Classification Required = Yes
            var enabledProducts = getEnabledProducts();
            stats.processedCount = enabledProducts.length;

            if (stats.processedCount === 0) {
                statusMessage = 'No products found with Classification Required flag enabled. Job completed.';
                Logger.info(statusMessage);
                return new Status(Status.OK, 'OK', statusMessage);
            }

            // Step 2: Process products in batches
            var batchCount = Math.ceil(enabledProducts.length / BATCH_CONFIG.BATCH_SIZE);
            Logger.info('Processing {0} products in {1} batches', stats.processedCount, batchCount);

            for (var i = 0; i < enabledProducts.length; i += BATCH_CONFIG.BATCH_SIZE) {
                var batchNumber = Math.floor(i / BATCH_CONFIG.BATCH_SIZE) + 1;
                var batchEnd = Math.min(i + BATCH_CONFIG.BATCH_SIZE, enabledProducts.length);
                var batch = enabledProducts.slice(i, batchEnd);

                Logger.info('Processing batch {0}/{1} (products {2}-{3})', 
                    batchNumber, batchCount, i + 1, batchEnd);

                // Step 3: Call API and update products
                stats = processBatch(batch, stats);
            }

            // Step 4: Build final status message
            statusMessage = 'HS Code Classification Sync completed. ' +
                'Total Products: ' + stats.processedCount +
                ', Successfully Updated: ' + stats.successCount +
                ', Errors: ' + stats.errorCount;

            Logger.info('===========================================');
            Logger.info(statusMessage);
            Logger.info('===========================================');

            // Determine final status
            if (stats.errorCount > 0 && stats.successCount === 0) {
                statusCode = Status.ERROR;
            }

        } catch (error) {
            statusCode = Status.ERROR;
            statusMessage = 'HS Code Classification Sync job failed: ' + error.message;
            Logger.error(statusMessage);
            Logger.error('Stack trace: {0}', error.stack || 'Not available');
        }

        return new Status(statusCode, statusCode === Status.OK ? 'OK' : 'ERROR', statusMessage);
    }
};
