'use strict';

var avataxService = require('~/cartridge/scripts/services/avataxService');
var configSettingsModel = require('~/cartridge/models/configSettings');

// Log entries data - to be modified with builds
var authInfo = !empty(avataxService.getAuthInfo()) ? avataxService.getAuthInfo() : {
    url: '',
    user: '',
    le_url: ''
};

var authUser = !empty(authInfo.user) ? authInfo.user.toString() : '';
var serviceUrl = !empty(authInfo.url) ? (avataxService.getAuthInfo().url.toString().toLowerCase().indexOf('sandbox') === -1 ? 'Production' : 'Sandbox') : '';

var connectorName = 'Avalara for SF B2C Storefront Next';
var connectorVersion = configSettingsModel.semanticVersion;
var clientString = 'SF B2C Commerce Storefront Next || ' + connectorVersion;
var erpDetails = 'Salesforce';

/**
 * Config/ Debug logs sent to Avalara
 * @param {*} source Source
 * @param {*} operation Operation
 * @param {*} message Message
 * @param {*} logType LogType
 * @param {*} logLevel LogLevel
 * @param {*} functionName FunctionName
 * @param {*} docCode DocCode
 */
function avConfigDebugLogs({source, operation, message, logType, logLevel, functionName, docCode}) {
    var logModel = {};

    logModel.CallerAccuNum = authUser || '';
    logModel.AvaTaxEnvironment = serviceUrl;
    logModel.ERPDetails = erpDetails;
    logModel.ConnectorName = connectorName;
    logModel.ConnectorVersion = connectorVersion;
    logModel.ClientString = clientString;

    logModel.Source = source || '';
    logModel.Operation = operation || '';
    logModel.Message = message || '';
    logModel.LogType = logType || '';
    logModel.LogLevel = logLevel || '';
    logModel.FunctionName = functionName || '';
    logModel.DocCode = docCode || '';

    logModel.CreationDate = new Date();
    avataxService.leLog(logModel);
}

/**
 * Performance Logs sent to Avalara
 * @param {*} source Source
 * @param {*} operation Operation
 * @param {*} message Message
 * @param {*} logType LogType
 * @param {*} logLevel LogLevel
 * @param {*} functionName FunctionName
 * @param {*} docCode DocCode
 * @param {*} docType docType
 * @param {*} lineCount lineCount
 * @param {*} connectorTime connectorTime
 * @param {*} connectorLatency connectorLatency
 */
function avPerformanceLogs({source, operation, message, logType, logLevel, functionName, docCode, docType, lineCount, connectorTime, connectorLatency}) {
    var logModel = {};

    logModel.CallerAccuNum = authUser || '';
    logModel.AvaTaxEnvironment = serviceUrl;
    logModel.ERPDetails = erpDetails;
    logModel.ConnectorName = connectorName;
    logModel.ConnectorVersion = connectorVersion;
    logModel.ClientString = clientString;

    logModel.Source = source || '';
    logModel.Operation = operation || '';
    logModel.Message = message || '';
    logModel.LogType = logType || '';
    logModel.LogLevel = logLevel || '';
    logModel.FunctionName = functionName || '';

    logModel.DocCode = docCode || '';
    logModel.LineCount = lineCount || '';
    logModel.DocType = docType || '';
    logModel.ConnectorTime = connectorTime || '';
    logModel.ConnectorLatency = connectorLatency || '';

    logModel.CreationDate = new Date();
    avataxService.leLog(logModel);
}

function getServiceUrl() {
    return serviceUrl;
}

module.exports = {
    avConfigDebugLogs: avConfigDebugLogs,
    avPerformanceLogs: avPerformanceLogs,
    getServiceUrl: getServiceUrl
};
