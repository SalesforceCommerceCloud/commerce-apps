/* eslint-disable no-undef */
/*
 * AvaTax REST service client
 */
/* eslint-disable no-unused-vars */
'use strict';

// API includes
var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

// Custom logger
var LOGGER = require('dw/system/Logger').getLogger('Avalara', 'AvaTax');
var configSettingsModel = require('~/cartridge/models/configSettings');

// Global service componentnts
var svc;
var config;
var url;
var user;
var password;
var encodedAuthStr;
var credential;
var clientHeaderStr;

const schemaId = 'avatax';
const layoutId = 'avaportal';
const configSectionId = 'avatax';
var applicationId = configSettingsModel.applicationId;
var versionId = configSettingsModel.versionId;

/**
 * Initialize the service components
 */
function initservice() {
    // Create a service object
    svc = LocalServiceRegistry.createService('avatax.rest.all', {
        createRequest: function (_svc, args) {
            if (args) {
                return JSON.stringify(args);
            }
            return null;
        },
        parseResponse: function (_svc, client) {
            return client.text;
        }
    });
    // Configure the service related parameters
    config = svc.getConfiguration();
    credential = config.getCredential();
    url = !empty(credential.getURL()) ? credential.getURL() : '';
    user = credential.getUser();
    password = credential.getPassword();
    encodedAuthStr = require('dw/util/StringUtils').encodeBase64(user + ':' + password);

    clientHeaderStr = 'SF B2C/StorefrontNext || ' + configSettingsModel.semanticVersion + '; ' + versionId;

    svc.addHeader('Accept', 'application/json');
    svc.addHeader('X-Avalara-Client', clientHeaderStr);
    svc.addHeader('Authorization', 'Basic ' + encodedAuthStr);
}


var ccs_svc;
var ccs_config;
var ccs_url;
var ccs_accno;
var ccs_lkey;
var ccs_credential;

function getCCSUrl(avataxUrl) {
    const CCS_URLS = {
        SANDBOX: 'https://config.connector.sbx.avalara.com/',
        PRODUCTION: 'https://config.connector.avalara.com/'
    };

    if (!avataxUrl) {
        return '';
    }
    
    if (avataxUrl.includes('sandbox-rest.avatax.com')) {
        return CCS_URLS.SANDBOX;
    }
    
    if (avataxUrl.includes('rest.avatax.com')) {
        return CCS_URLS.PRODUCTION;
    }
    
    return '';
}

/**
 * Initialize the service components
 */
function initccsservice() {
    // Create a service object
    ccs_svc = LocalServiceRegistry.createService('config.avatax.svc', {
        createRequest: function (_svc, args) {
            if (args) {
                return JSON.stringify(args);
            }
            return null;
        },
        parseResponse: function (_svc, client) {
            return client.text;
        }
    });

    // Configure the service related parameters
    ccs_config = ccs_svc.getConfiguration();
    ccs_credential = ccs_config.getCredential();

    const avataxUrl = !empty(ccs_credential.getURL()) ? ccs_credential.getURL() : '';
    ccs_url = getCCSUrl(avataxUrl);

    ccs_accno = ccs_credential.getUser();
    ccs_lkey = ccs_credential.getPassword();
    encodedAuthStr = require('dw/util/StringUtils').encodeBase64(ccs_accno + ':' + ccs_lkey);

    clientHeaderStr = 'SF B2C/StorefrontNext || ' + configSettingsModel.semanticVersion + '; ' + versionId;

    ccs_svc.addHeader('Accept', 'application/json');
    ccs_svc.addHeader('X-Avalara-Client', clientHeaderStr);
    ccs_svc.addHeader('Authorization', 'Basic ' + encodedAuthStr);
}

// Logentries variables
var leSvc;
var leConfig;
var leCredential;
var leUrl;
var leSvcresponse;
/**
 * Initialize the log entries service and retrieve the related configuration
 */
function initLeService() {
    // Logentries service
    leSvc = LocalServiceRegistry.createService('ceplogger.avatax.svc', {
        createRequest: function (_svc, args) {
            if (args) {
                return JSON.stringify(args);
            }
            return null;
        },
        parseResponse: function (_svc, client) {
            return client.text;
        }
    });
    // Configure service related parameters
    leConfig = leSvc.getConfiguration();
    leCredential = leConfig.getCredential();
    encodedAuthStr = require('dw/util/StringUtils').encodeBase64(leCredential.getUser() + ':' + leCredential.getPassword());

    if (url.toLowerCase().indexOf('sandbox') === -1) {
        if (session.privacy.sitesource && session.privacy.sitesource === 'sgjc') {
            leUrl = leCredential.getURL() + applicationId; // logentries sgjc production
        } else {
            leUrl = leCredential.getURL() + applicationId; // logentries sfra production
        }
    } else if (session.privacy.sitesource && session.privacy.sitesource === 'sgjc') {
        leUrl = leCredential.getURL() + applicationId; // logentries sgjc development
    } else {
        leUrl = leCredential.getURL() + applicationId; // logentries sfra development
    }
    leSvc.setURL(leUrl);

    leSvc.addHeader('Authorization', 'Basic ' + encodedAuthStr);
    leSvc.addHeader('X-API-Version','1.0');
    leSvc.addHeader('Content-Type', 'application/json');
}

/**
 * Retrives auth info for AvaTax
 * @returns {*} authinfo object
 */
function getAuthInfo() {
    initservice();
    initccsservice();
    initLeService();
    return {
        url: url,
        user: user,
        leUrl: leUrl
    };
}

/**
 * Log the log details to logentries server using the logentries service call
 * @param {*} jsonLog jsonLog
 * @returns {*} log response
 */
function leLog(jsonLog) {
    try {
        initLeService();
        leSvcresponse = leSvc.call(jsonLog);
        if (leSvcresponse.status !== 'OK') {
            LOGGER.warn('Got an error calling:' + leUrl + '. The status code is: ' + leSvcresponse.status +
                ', and the text is: ' + leSvcresponse +
                ' and the error text is: ' + leSvcresponse.getErrorMessage());
            var errorResult = {
                statusCode: leSvcresponse.status,
                errorMessage: JSON.parse(leSvcresponse.getErrorMessage()),
                url: leUrl
            };
            return errorResult;
        }
        // return a plain javascript object
        return {
            success: true
        };
    } catch (e) {
        LOGGER.warn('Unknown error occurred calling ' + leUrl);
        var errorResult = {
            success: false,
            statusCode: 500,
            errorMessage: 'Internal server error',
            url: leUrl
        };
        return errorResult;
    }
}

/**
 * Filters the service response object.
 * @param {*} httpResponse httpResponse
 * @returns {*} Returns error details if unsuccessful. Otherwise, the response JSON.
 */
function responseFilter(httpResponse) {
    if (httpResponse.status !== 'OK') {
        var errormsg;
        try {
            errormsg=JSON.parse(httpResponse.getErrorMessage());
        } catch (error) {
            errormsg=JSON.parse(JSON.stringify(httpResponse.getErrorMessage()));
        }

        var errorResult = {
            statusCode: httpResponse.status,
            errorMessage: errormsg,
            url: url
        };
        return errorResult;
    }
    // return a plain javascript object
    return JSON.parse(httpResponse.object);
}


/**
 * List all services to which the current user is subscribed
 * @returns {Object} a response object that contains information about the subscriptions
 */
 function getSubscriptions(acno, lkey, env, flag) {
    initservice();
    if ( (env === 'Production' && url.includes('sandbox-')) || (env === 'Sandbox' && url.includes('/rest.')) ) {
        return {
            code: 'AuthenticationException', statusCode: 'ERROR', 
            errorMessage: 'Environment mismatch. Please ensure you are using correct credentials for ' + env + ' environment.'
            }
    }
    url += 'api/v2/utilities/subscriptions';
    svc.setRequestMethod('GET');
    url = encodeURI(url);
    svc.setURL(url);
    // service call
    var httpResult = svc.call();
    return responseFilter(httpResult);
}

/**
 * Resolve an address against Avalara's address-validation system
 * @param {Object} addressValidationInfo - addressValidationInfo object
 * @returns {Object} a response object that contains information about the validated address
 */
function resolveAddressPost(addressValidationInfo) {
    initservice();
    url += 'api/v2/addresses/resolve';
    svc.setRequestMethod('POST');
    url = encodeURI(url);
    svc.setURL(url);
    // service call
    var httpResult = svc.call(addressValidationInfo);
    return responseFilter(httpResult);
}

/**
 * Records a new transaction in AvaTax.
 * @param {Object} createTransactionModel object - refer AvaTax documentation
 * @param {Object} include object - refer AvaTax documentation
 * @returns {Object} a response object that contains information about the taxes
 */
function createTransaction(createTransactionModel, include) {
    initservice();
    url += 'api/v2/transactions/create' + (!empty(include) ? '?$include=' + include : '');
    svc.setRequestMethod('POST');
    url = encodeURI(url);
    svc.setURL(url);
    // service call
    var httpResult = svc.call(createTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Marks a transaction by changing its status to 'Committed'
 * @param {string} companyCode - refer AvaTax documentation
 * @param {string} transactionCode - Order number in SFCC - refer AvaTax documentation
 * @param {string} commitTransactionModel object
 * @param {string} documentType string
 * @returns {Object} a response object that contains information about the transaction
 */
function commitTransaction(companyCode, transactionCode, commitTransactionModel, documentType) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/commit' + (!empty(documentType) ? '?documentType=' + documentType : '');
    url = encodeURI(url);
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(commitTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Records a new transaction or adjust an existing transaction in AvaTax
 * @param {string} include string
 * @param {Object} createOrAdjustTransactionModel object
 * @returns {Object} a response object that contains information about the transaction
 */
function createOrAdjustTransaction(include, createOrAdjustTransactionModel) {
    initservice();
    url += 'api/v2/transactions/createoradjust' + (!empty(include) ? '?$include=' + include : '');
    url = encodeURI(url);
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(createOrAdjustTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Voids the current transaction uniquely identified by transactionCode.
 * @param {string} companyCode string
 * @param {string} transactionCode string
 * @param {Object} voidTransactionModel object
 * @returns {Object} a response object that contains information about the transaction being voided
 */
function voidTransaction(companyCode, transactionCode, voidTransactionModel) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/void';
    url = encodeURI(url);
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(voidTransactionModel);
    return responseFilter(httpResult);
}


/**
 * Replaces the current transaction uniquely identified by this URL with a new transaction.
 * @param {string}companyCode string
 * @param {string} transactionCode string
 * @param {Object} adjustTransactionModel object
 * @returns {Object} a response object that contains information about the transaction being adjusted
 */
function adjustTransaction(companyCode, transactionCode, adjustTransactionModel) {
    initservice();
    url += 'api/v2/companies/' + companyCode + '/transactions/' + transactionCode + '/adjust';
    url = encodeURI(url);
    svc.setRequestMethod('POST');
    svc.setURL(url);
    // service call
    var httpResult = svc.call(adjustTransactionModel);
    return responseFilter(httpResult);
}

/**
 * Build a multi - location tax content file
 * @param {*} companyCode companyCode
 * @param {*} documentDate documentDate
 * @param {*} taxCodes taxCodes
 * @param {*} locationCodes locationCodes
 * @returns {*} object
 */
function buildTaxContent(companyCode, documentDate, taxCodes, locationCodes) {
    initservice();
    url += 'api/v2/pointofsaledata/build';
    url = encodeURI(url);
    svc.setRequestMethod('POST');
    svc.setURL(url);

    documentDate = '2019-08-13';
    companyCode = 'default';
    taxCodes = ['P0000000'];
    locationCodes = ['NY', 'TN'];


    var request = {
        companyCode: companyCode,
        documentDate: documentDate,
        responseType: 'xml',
        taxCodes: taxCodes,
        locationCodes: locationCodes,
        includeJurisCodes: true
    };

    // service call
    var httpResult = svc.call(request);
    return httpResult.object;
}


/**
 * Gets all transactions for specified company for specified date range
 * @param {string} companyCode string
 * @param {string} fromDate string
 * @param {string} toDate string
 * @returns {Object} a collection object that contains information about the transactions
 */
function getTransactions(companyCode, fromDate, toDate) {
    initservice();
    // Batch size for pagination - adjust batchSize value (e.g., 50, 100, 200) based on your API quota limits
    var batchSize = 100;
    if (empty(fromDate) || empty(toDate)) {
        url += 'api/v2/companies/' + companyCode + '/transactions?$top=' + batchSize;
    } else {
        url += 'api/v2/companies/' + companyCode + '/transactions?$top=' + batchSize + '&$filter=date between \'' + fromDate + '\' and \'' + toDate + '\' AND status <> Adjusted';
    }
    url = encodeURI(url);
    svc.setRequestMethod('GET');
    svc.setURL(url);
    // service call
    var httpResult = svc.call();
    var result = null;
    var records;
    if (httpResult.status !== 'OK') {
        result = {
            status: 'error',
            values: null,
            errorMessage: JSON.parse(httpResult.getErrorMessage())
        };
        return result;
    } else {
        records = JSON.parse((httpResult.object).replace(/@nextLink/g, 'nextLink').replace(/@recordsetCount/g, 'recordsetCount'));
    }
    var SortedMap = require('dw/util/SortedMap');
    var sm = new SortedMap();
    var totalRecordCount = records.recordsetCount || 0; // Total records available from API
    if (records.value) {
        for (var i = 0; i < records.value.length; i++) {
            sm.put(records.value[i].code, records.value[i]);
        }
        while (records.nextLink) {
            initservice();
            url += records.nextLink;
            url = encodeURI(url);
            svc.setRequestMethod('GET');
            svc.setURL(url);
            // service call
            var httpResult1 = svc.call();
            var record1;
            if (httpResult1.status !== 'OK') {
                result = {
                    status: 'error',
                    values: null,
                    errorMessage: JSON.parse(httpResult1.getErrorMessage())
                };
                break;
            } else {
                // return a plain javascript object
                record1 = JSON.parse((httpResult1.object).replace(/@nextLink/g, 'nextLink').replace(/@recordsetCount/g, 'recordsetCount'));
                if (record1.value) {
                    for (i = 0; i < record1.value.length; i++) {
                        sm.put(record1.value[i].code, record1.value[i]);
                    }
                }
                records.nextLink = record1.nextLink;
            }
        }
        result = {
            ERROR: false,
            values: sm,
            recordsetCount: totalRecordCount
        };
    } else {
        result = {
            ERROR: true,
            values: null
        };
    }
    return result;
}


/**
 * Fetches all companies of AvaTax user
 */
function getCompanies() {
    initservice();
    url += 'api/v2/companies';
    url = encodeURI(url);
    svc.setRequestMethod('GET');
    svc.setURL(url);
    // service call
    var httpResult = svc.call();
    return responseFilter(httpResult);
}

/**
 * -----------------------------------------------------------------------------------------
 * CCS APIs
 * -----------------------------------------------------------------------------------------
 */

function getConfigId(configId) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('GET');
    ccs_svc.setURL(ccs_url);
    // service call
    var httpResult = ccs_svc.call();
    return responseFilter(httpResult);
}

function postConfigId(configId, configModel) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('POST');
    ccs_svc.addHeader('Content-Type', 'application/json');
    ccs_svc.setURL(ccs_url);
    // service call
    var httpResult = ccs_svc.call(configModel);
    return responseFilter(httpResult);
}


function updateConfigId(configId, configModel) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('PUT');
    ccs_svc.addHeader('Content-Type', 'application/json');
    ccs_svc.setURL(ccs_url);
    // service call
    var httpResult = ccs_svc.call(configModel);
    return responseFilter(httpResult);
}

function getConfigSectionId(configId) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId+'/sections/'+configSectionId+'?configOnly=false&schema=false&version='+versionId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('GET');
    ccs_svc.setURL(ccs_url);
    // service call
    var httpResult = ccs_svc.call();
    return responseFilter(httpResult);
}


/**
 * -----------------------------------------------------------------------------------------
 * HS Code Classification APIs
 * Endpoint: https://hscode.avatax.avalara.com/hscode/classify
 * Authentication: OAuth 2.0 Bearer Token
 * -----------------------------------------------------------------------------------------
 */

// HS Code Classification service variables
var hsCodeSvc;
var hsCodeUrl = 'https://hscode.avatax.avalara.com/';
var hsTokenUrl = 'https://identity.avalara.com/connect/token';

// Token cache variables
var cachedAccessToken = null;
var tokenExpiryTime = null;

/**
 * Get OAuth access token from Avalara Identity service
 * Token API: https://identity.avalara.com/connect/token
 * 
 * Uses client_credentials grant type with:
 * - client_id: avatax_account_id (from config.avatax.svc credential user)
 * - client_secret: license_key (from config.avatax.svc credential password)
 * - scope: avatax_api
 * 
 * @returns {Object} Token response with access_token or error
 */
function getHSCodeAccessToken() {
    // Check if we have a valid cached token (with 5 minute buffer)
    var currentTime = new Date().getTime();
    if (cachedAccessToken && tokenExpiryTime && (currentTime < tokenExpiryTime - 300000)) {
        LOGGER.debug('Using cached access token');
        return {
            success: true,
            access_token: cachedAccessToken
        };
    }

    LOGGER.info('Requesting new access token from Avalara Identity');

    // Create token service using config.avatax.svc to get correct credentials
    var tokenSvc = LocalServiceRegistry.createService('config.avatax.svc', {
        createRequest: function (_svc, args) {
            return args;
        },
        parseResponse: function (_svc, client) {
            return client.text;
        }
    });

    // Get credentials from config.avatax.svc (client_id = account_id, client_secret = license_key)
    var tokenConfig = tokenSvc.getConfiguration();
    var tokenCredential = tokenConfig.getCredential();
    var clientId = tokenCredential.getUser();      // avatax_account_id
    var clientSecret = tokenCredential.getPassword(); // license_key

    LOGGER.debug('Token request - client_id: {0}', clientId);

    // Configure token request
    tokenSvc.setURL(hsTokenUrl);
    tokenSvc.setRequestMethod('POST');
    tokenSvc.addHeader('Content-Type', 'application/x-www-form-urlencoded');

    // Build form-urlencoded request body
    var requestBody = 'grant_type=client_credentials' +
        '&client_id=' + encodeURIComponent(clientId) +
        '&client_secret=' + encodeURIComponent(clientSecret) +
        '&scope=avatax_api';

    // Make token request
    var httpResult = tokenSvc.call(requestBody);

    if (httpResult.status === 'OK') {
        try {
            var tokenResponse = JSON.parse(httpResult.object);
            
            if (tokenResponse.access_token) {
                // Cache the token
                cachedAccessToken = tokenResponse.access_token;
                // Set expiry time (expires_in is in seconds, convert to milliseconds)
                var expiresIn = tokenResponse.expires_in || 3600;
                tokenExpiryTime = currentTime + (expiresIn * 1000);
                
                LOGGER.info('Successfully obtained access token, expires in {0} seconds', expiresIn);
                
                return {
                    success: true,
                    access_token: tokenResponse.access_token,
                    expires_in: expiresIn,
                    token_type: tokenResponse.token_type
                };
            }
            
            LOGGER.error('Token response missing access_token');
            return {
                success: false,
                errorMessage: 'Token response missing access_token'
            };
        } catch (e) {
            LOGGER.error('Failed to parse token response: {0}', e.message);
            return {
                success: false,
                errorMessage: 'Failed to parse token response: ' + e.message
            };
        }
    }

    // Token request failed
    var errorMsg;
    try {
        errorMsg = JSON.parse(httpResult.getErrorMessage());
    } catch (e) {
        errorMsg = httpResult.getErrorMessage();
    }
    
    LOGGER.error('Failed to get access token. Client ID used: {0}, Error: {1}', clientId, JSON.stringify(errorMsg));
    return {
        success: false,
        statusCode: httpResult.status,
        errorMessage: errorMsg
    };
}

/**
 * Initialize the HS Code Classification service with OAuth Bearer token
 * @returns {boolean} True if service initialized successfully
 */
function initHSCodeService() {
    // Get OAuth access token
    var tokenResult = getHSCodeAccessToken();
    
    if (!tokenResult.success) {
        LOGGER.error('Failed to initialize HS Code service: Could not obtain access token');
        return false;
    }

    // Create a service object for HS Code Classification
    // Note: args is expected to be a pre-stringified JSON string to preserve array format
    hsCodeSvc = LocalServiceRegistry.createService('avatax.rest.all', {
        createRequest: function (_svc, args) {
            // args is already a JSON string, return as-is
            return args;
        },
        parseResponse: function (_svc, client) {
            return client.text;
        }
    });

    // Configure headers with Bearer token authentication
    hsCodeSvc.addHeader('Accept', 'application/json');
    hsCodeSvc.addHeader('Content-Type', 'application/json');
    hsCodeSvc.addHeader('X-Avalara-Client', clientHeaderStr);
    hsCodeSvc.addHeader('Authorization', 'Bearer ' + tokenResult.access_token);

    return true;
}

/**
 * Filters the HS Code Classification service response
 * @param {Object} httpResponse - The HTTP response object
 * @returns {Object} Returns error details if unsuccessful. Otherwise, the response array with HS codes.
 */
function hsCodeResponseFilter(httpResponse) {
    if (httpResponse.status !== 'OK') {
        var errormsg;
        try {
            errormsg = JSON.parse(httpResponse.getErrorMessage());
        } catch (error) {
            errormsg = httpResponse.getErrorMessage();
        }

        LOGGER.error('HS Code API Error Response: {0}', JSON.stringify(errormsg));
        return {
            success: false,
            statusCode: httpResponse.status,
            errorMessage: errormsg
        };
    }
    // Return the parsed response array
    var result = JSON.parse(httpResponse.object);
    LOGGER.info('HS Code API Success Response: {0}', JSON.stringify(result));
    return {
        success: true,
        classifications: result
    };
}

/**
 * Classify products to retrieve HS Codes from Avalara HS Classification API
 * Uses OAuth 2.0 Bearer token authentication
 * 
 * @param {Array} products - Array of product objects for classification. Each object should contain:
 *   product_title (string) - Product title/name
 *   cod (string) - Country of destination ISO 2-letter code (e.g., "CA", "MX", "US")
 *   image_url (string, optional) - Product image URL
 *   product_url (string, optional) - Product page URL
 *   price (string, optional) - Product price
 *   product_category (string, optional) - Product category path (e.g., "mens > clothes")
 *   product_description (string, optional) - Product description
 *   attributes (Array, optional) - Array of attribute objects
 * 
 * @returns {Object} Response object containing success (boolean) and classifications (Array of code, confidence, description)
 */
function classifyHSCode(products) {
    // Initialize service with OAuth token
    var serviceInitialized = initHSCodeService();
    
    if (!serviceInitialized) {
        return {
            success: false,
            errorMessage: 'Failed to initialize HS Code service - could not obtain access token'
        };
    }
    
    // Ensure products is always an array
    var productsArray = products;
    if (!Array.isArray(products)) {
        productsArray = [products];
        LOGGER.debug('Converted single product to array');
    }
    
    var classifyUrl = hsCodeUrl + 'hscode/classify';
    hsCodeSvc.setRequestMethod('POST');
    classifyUrl = encodeURI(classifyUrl);
    hsCodeSvc.setURL(classifyUrl);

    // Pre-stringify the array to preserve the JSON array format
    var requestBodyJson = JSON.stringify(productsArray);

    // Log the request
    LOGGER.info('HS Code API Request URL: {0}', classifyUrl);
    LOGGER.info('HS Code API Request Body ({0} products): {1}', productsArray.length, requestBodyJson);

    // Service call with pre-stringified JSON to preserve array format
    var httpResult = hsCodeSvc.call(requestBodyJson);
    return hsCodeResponseFilter(httpResult);
}

/**
 * Build a product classification request object
 * Helper function to construct properly formatted product data for the HS Code API
 * 
 * @param {Object} params - Product parameters
 * @param {string} params.title - Product title
 * @param {string} params.countryOfDestination - ISO 2-letter country code
 * @param {string} [params.imageUrl] - Product image URL
 * @param {string} [params.productUrl] - Product page URL
 * @param {string} [params.price] - Product price with currency symbol
 * @param {string} [params.category] - Product category path
 * @param {string} [params.description] - Product description
 * @param {Object} [params.attributes] - Key-value pairs of product attributes
 * 
 * @returns {Object} Formatted product object for API request
 */
function buildHSCodeRequest(params) {
    var product = {
        product_title: params.title || '',
        cod: params.countryOfDestination || 'US'
    };

    if (params.imageUrl) {
        product.image_url = params.imageUrl;
    }
    if (params.productUrl) {
        product.product_url = params.productUrl;
    }
    if (params.price) {
        product.price = params.price;
    }
    if (params.category) {
        product.product_category = params.category;
    }
    if (params.description) {
        product.product_description = params.description;
    }
    if (params.attributes && Object.keys(params.attributes).length > 0) {
        product.attributes = [];
        Object.keys(params.attributes).forEach(function (key) {
            var attr = {};
            attr[key] = params.attributes[key];
            product.attributes.push(attr);
        });
    }

    return product;
}


function postConfigSectionId(configId, configSectionModel) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId+'/sections/'+configSectionId+'?version='+versionId+'&schema='+schemaId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('POST');
    ccs_svc.setURL(ccs_url);
    ccs_svc.addHeader('Content-Type', 'application/json');
    // service call
    var httpResult = ccs_svc.call(configSectionModel);
    return responseFilter(httpResult);
}


function deleteConfigSectionId(configId) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId+'/sections/'+configSectionId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('DELETE');
    ccs_svc.setURL(ccs_url);
    // service call
    var httpResult = ccs_svc.call();
    return responseFilter(httpResult);
}


function updateConfigSectionId(configId, configSectionModel) {
    initccsservice();
    ccs_url += 'api/active-applications/'+applicationId+'/configs/'+configId+'/sections/'+configSectionId;
    ccs_url = encodeURI(ccs_url);
    ccs_svc.setRequestMethod('PUT');
    ccs_svc.setURL(ccs_url);
    ccs_svc.addHeader('Content-Type', 'application/json');
    // service call
    var httpResult = ccs_svc.call(configSectionModel);
    return responseFilter(httpResult);
}


// Module exports
module.exports = {
    getSubscriptions: getSubscriptions,
    resolveAddressPost: resolveAddressPost,
    createTransaction: createTransaction,
    commitTransaction: commitTransaction,
    createOrAdjustTransaction: createOrAdjustTransaction,
    voidTransaction: voidTransaction,
    adjustTransaction: adjustTransaction,
    getAuthInfo: getAuthInfo,
    leLog: leLog,
    getTransactions: getTransactions,
    buildTaxContent: buildTaxContent,
    getCompanies: getCompanies,
    getConfigId: getConfigId,
    postConfigId: postConfigId,
    updateConfigId: updateConfigId,
    getConfigSectionId: getConfigSectionId,
    postConfigSectionId: postConfigSectionId,
    deleteConfigSectionId: deleteConfigSectionId,
    updateConfigSectionId: updateConfigSectionId,
    // HS Code Classification APIs (OAuth 2.0 Bearer Token Auth)
    getHSCodeAccessToken: getHSCodeAccessToken,
    classifyHSCode: classifyHSCode,
    buildHSCodeRequest: buildHSCodeRequest
};