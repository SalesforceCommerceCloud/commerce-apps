/**
 * avataxSettingsCache.js
 */
var dwlogger = require('dw/system/Logger');
var avaTaxClient = require('~/cartridge/scripts/services/avataxService');
var configSettingsModel = require('~/cartridge/models/configSettings');
var companyHelper = require('~/cartridge/scripts/helpers/companyHelper');
var LOGGER = dwlogger.getLogger('Avalara', 'AvaTax');
var settingsObject = {};
try {
    settingsObject = JSON.parse(dw.system.Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (error) {
    LOGGER.warn('Failed to parse AVSettings site preference. Details - ' + error.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = configSettingsModel.defaultSettingsObject('DEFAULT');
}

function autoSync() {
    try {
        var message = '';
        var siteId = settingsObject.configId ? settingsObject.configId : '';
        var svcResponse = avaTaxClient.getConfigSectionId(siteId);

        if (!empty(svcResponse.statusCode) && svcResponse.statusCode !== 'OK') {
            message = 'There was a problem fetching the configuration settings. Service configuration issue.';
        }
        if (svcResponse.error || svcResponse.message || svcResponse.errorMessage || !svcResponse.config || !svcResponse.config.configurations) {
            if (svcResponse.errorMessage) {
                message = svcResponse.errorMessage.Message;
            }
            if (svcResponse.message) {
                message = svcResponse.message;
            }
            if (svcResponse.error) {
                message = svcResponse.message;
            }
        } else {
            let lastsync = new Date();
            let lastSyncString = ('0' + (lastsync.getMonth() + 1)).slice(-2) + '/' + ('0' + lastsync.getDate()).slice(-2) + '/' + lastsync.getFullYear() + ' ' + 
            ('0' + (lastsync.getHours() % 12 || 12)).slice(-2) + ':' + ('0' + lastsync.getMinutes()).slice(-2) + ' ' + (lastsync.getHours() >= 12 ? 'PM' : 'AM');
            
            settingsObject.migrateflag = false;
            settingsObject.lastsync = new Date(Date.now());
            settingsObject.lastSyncString = lastSyncString;
            settingsObject.configs = configSettingsModel.handleSyncPayload(svcResponse.config);
            settingsObject.configs.companyId = companyHelper.verifyCompanyCode(svcResponse.config.configurations.company_code);
            settingsObject.configs.taxationpolicy = (dw.order.TaxMgr.taxationPolicy === dw.order.TaxMgr.TAX_POLICY_NET ) ? 'net' : 'gross'; 

            return settingsObject;
        }
        
        LOGGER.warn('Avalara Settings Sync Job Error: ' + JSON.stringify(message));
        return false;
    } catch (e) {
        LOGGER.warn('There was a problem fetching the configuration settings. Details - '+JSON.stringify(e));
        return false;
    }
}

module.exports = {
    autoSync: autoSync
};
