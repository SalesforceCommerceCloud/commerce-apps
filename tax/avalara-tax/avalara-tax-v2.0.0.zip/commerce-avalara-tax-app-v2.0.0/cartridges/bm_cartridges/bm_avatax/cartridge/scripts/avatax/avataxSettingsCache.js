/**
 * avataxSettingsCache.js
 */
var dwlogger = require('dw/system/Logger');
var avaTaxClient = require('~/cartridge/scripts/services/avataxService');
var AVSettings = require('~/cartridge/controllers/AVSettings');
var configSettingsModel = require('~/cartridge/models/configSettings');
var LOGGER = dwlogger.getLogger('Avalara', 'AvaTax');
var settingsObject = {};
try {
    settingsObject = JSON.parse(dw.system.Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (error) {
    LOGGER.warn('Failed to parse AVSettings site preference. Details - ' + error.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = configSettingsModel.defaultSettingsObject('DEFAULT');
}

/**
 * Verifies whether the entered company code string is a valid company
 * If its valid, returns its company ID
 * @param {string} companyCode
 */
function verifyCompanyCode(companyCode) {
    var companyId = '';
    if (empty(companyCode)) {
        return companyId;
    }
    try {
        var companies = getCompanies();
        for (var i = 0; i < companies.length; i++) {
            var companyObject = JSON.stringify(companies[i]);
            var company = JSON.parse(companyObject);
            if (companyCode.toLowerCase() === company.companyCode.toLowerCase()) {
                companyId = company.id;
                break;
            }
        }
    } catch (error) {
        LOGGER.warn('There was a problem processing this request. Please try again.' + error);
    }
    return companyId;
}

/**
 * Fetches companies for current AvaTax user
 */
function getCompanies() {
    var companies = [];
    try {
        var svcResponse = avaTaxClient.getCompanies();
        if (!svcResponse.statusCode && !!svcResponse.value) {
            var count = svcResponse.value.length;
            for (var i = 0; i < count; i++) {
                var company = svcResponse.value[i];
                var companyObject = {
                    id: company.id || '',
                    companyCode: company.companyCode,
                    name: company.name,
                    isDefault: company.isDefault,
                    isActive: company.isActive
                };
                companies.push(companyObject);
            }
        }
        return companies;
    } catch (error) {
        LOGGER.warn('Problem while fetching companies from AvaTax account' + error);
    }
}

function autoSync() {
    try {
        var message = '';
        var siteId = settingsObject.configId ? settingsObject.configId : '';
        var svcResponse = avaTaxClient.getConfigSectionId(siteId);

        if (!empty(svcResponse.statusCode) && svcResponse.statusCode !== 'OK') {
            message = 'There was a problem fetching the configuration settings. Service configuration issue.';
        }
        if (svcResponse.error || svcResponse.message || svcResponse.errorMessage || !svcResponse.config || !svcResponse.config.configurations) {
            if (svcResponse.errorMessage) {
                message = svcResponse.errorMessage.Message;
            }
            if (svcResponse.message) {
                message = svcResponse.message;
            }
            if (svcResponse.error) {
                message = svcResponse.message;
            }
        } else {
            let lastsync = new Date();
            let lastSyncString = ('0' + (lastsync.getMonth() + 1)).slice(-2) + '/' + ('0' + lastsync.getDate()).slice(-2) + '/' + lastsync.getFullYear() + ' ' + 
            ('0' + (lastsync.getHours() % 12 || 12)).slice(-2) + ':' + ('0' + lastsync.getMinutes()).slice(-2) + ' ' + (lastsync.getHours() >= 12 ? 'PM' : 'AM');
            
            settingsObject.migrateflag = false;
            settingsObject.lastsync = new Date(Date.now());
            settingsObject.lastSyncString = lastSyncString;
            settingsObject.configs = configSettingsModel.handleSyncPayload(svcResponse.config);
            settingsObject.configs.companyId = verifyCompanyCode(svcResponse.config.configurations.company_code);
            settingsObject.configs.taxationpolicy = (dw.order.TaxMgr.taxationPolicy === dw.order.TaxMgr.TAX_POLICY_NET ) ? 'net' : 'gross'; 

            return settingsObject;
        }
        
        LOGGER.warn('Avalara Settings Sync Job Error: ' + JSON.stringify(message));
        return false;
    } catch (e) {
        LOGGER.warn('There was a problem fetching the configuration settings. Details - '+JSON.stringify(e));
        return false;
    }
}

module.exports = {
    autoSync: autoSync
};
