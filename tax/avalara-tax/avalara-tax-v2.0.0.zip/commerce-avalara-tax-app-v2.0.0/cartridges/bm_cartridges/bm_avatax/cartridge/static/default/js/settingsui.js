jQuery(document).ready(function ($) {
    $('body').css('display', 'block');

    try {
        main($);
    } catch (e) {
        $('#message').css('color', 'red');
        $('#message').text('Avalara settings page initialization failed.');
    }
});

function main($) {

    if ($.LoadingOverlaySetup) {
        $.LoadingOverlaySetup({
            background: "rgba(255, 255, 255, 0.8)",
            image: $('#main-pane').data('img'),
            minSize: 10,
            maxSize: 80,
            imageAnimation: ''
        });
    }

    initEvents($);

    $('#tabs').tabs();
    $('#business-tabs').tabs();

}

function initEvents($) {

    initTooltips($);

    
    $('#main-pane').on('click', '#test-con-btn-sbx', function (e) {
        e.preventDefault();
        $("body").LoadingOverlay("show");
        var btnenv = $(this).data('btnenv');
        var url = $(this).data('url');

        var resolved = function (data) {
            $('#message').css('color', '#049504');
            let messageContent = `
             <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5;">
               <span style="color: #28a745;">Connected to the Sandbox account.
               <span style="color: #333;"> Adjust tax calculations with the Advanced settings 
               <a href="${data.redirectUrl}" 
                  target="_blank" 
                  style="color: #0056b3; text-decoration: none; transition: color 0.3s ease;">in Avalara</a><span style="color: #333;">
             </div>
           `;

            $('#message').html(messageContent);
              
            $('body').LoadingOverlay('hide');

        };

        var rejected = function (data) {
            $('#message').css('color', 'red');
            $('#message').html(`
                <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5; word-wrap: break-word; overflow-wrap: break-word;">
                    <span style="color: #dc3545;">${data.message}</span>
                    <span style="color: #333;"> To check the issue, go to Administration > Site Development > </span>
                    <span style="color: #333; white-space: nowrap;">Development Setup > Log Files, and select Log Center.</span>
                </div>
            `);

            $("body").LoadingOverlay("hide");
        };

        var promise = new Promise(function (resolve, reject) {
            $.ajax({
                method: 'GET',
                data: {
                    btnenv: btnenv
                },
                url: url
            }).done(function (result) {
                if (!result.success) {
                    rejected(result);
                } else {
                    resolved(result);
                }
            });
        });
        promise.then(resolved, rejected);

    });

    
    $('#main-pane').on('click', '#test-con-btn-prod', function (e) {
        e.preventDefault();
        $("body").LoadingOverlay("show");
        var btnenv = $(this).data('btnenv');
        var url = $(this).data('url');

        var resolved = function (data) {
            
            $('#message').css('color', '#049504');
             let messageContent = `
                <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5;">
                  <span style="color: #28a745;">Connected to the Production account.
                  <span style="color: #333;"> Adjust tax calculations with the Advanced settings 
                  <a href="${data.redirectUrl}" 
                     target="_blank" 
                     style="color: #0056b3; text-decoration: none; transition: color 0.3s ease;">in Avalara</a><span style="color: #333;">
                </div>
              `;

            $('#message').html(messageContent);

            var htmlContent = '';
            $('body').LoadingOverlay('hide');

        };

        var rejected = function (data) {
            $('#message').css('color', 'red');
            $('#message').html(`
                <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5; word-wrap: break-word; overflow-wrap: break-word;">
                    <span style="color: #dc3545;">${data.message}</span>
                    <span style="color: #333;"> To check the issue, go to Administration > Site Development > </span>
                    <span style="color: #333; white-space: nowrap;">Development Setup > Log Files, and select Log Center.</span>
                </div>
            `);

            $("body").LoadingOverlay("hide");
        };

        var promise = new Promise(function (resolve, reject) {
            $.ajax({
                method: 'GET',
                url: url,
                data: {
                    btnenv: btnenv
                },
            }).done(function (result) {
                if (!result.success) {
                    rejected(result);
                } else {
                    resolved(result);
                }
            });
        });
        promise.then(resolved, rejected);

    });

    $('#main-pane').on('click', '#sync-btn', function (e) {
        e.preventDefault();
        $("body").LoadingOverlay("show");
        var url = $(this).data('url');

        var resolved = function (data) {
            
            $('#message').css('color', '#049504');
            $('#message').text(data.message);

            $('body').LoadingOverlay('hide');
            
            // Display the message
            $('#message').show();

            setTimeout(function() {
                $('#message').fadeOut(2000, function() {
                    window.location.reload();
                });
            }, 9000);

        };

        var rejected = function (data) {
            $('#message').css('color', 'red');
            $('#message').html(`
                <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.5; word-wrap: break-word; overflow-wrap: break-word;">
                    <span style="color: #dc3545;">${data.message}</span>
                    <span style="color: #333;"> To check the issue, go to Administration > Site Development > </span>
                    <span style="color: #333; white-space: nowrap;">Development Setup > Log Files, and select Log Center.</span>
                </div>
            `);
            
            $("body").LoadingOverlay("hide");
        };

        var promise = new Promise(function (resolve, reject) {
            $.ajax({
                method: 'GET',
                url: url
            }).done(function (result) {
                if (!result.success) {
                    rejected(result);
                } else {
                    resolved(result);
                }
            });
        });
        promise.then(resolved, rejected);

    });

    $('#void-order-no').on('keypress', function (e) {
        var keycode = (e.keyCode ? e.keyCode : e.which);
        if (keycode == '13') {
            $('#void-btn').trigger('click');
        }

    });

    $('#commit-order-no').on('keypress', function (e) {
        var keycode = (e.keyCode ? e.keyCode : e.which);
        if (keycode == '13') {
            $('#commit-btn').trigger('click');
        }

    });


    $('#validate-order-no').on('keypress', function (e) {
        var keycode = (e.keyCode ? e.keyCode : e.which);
        if (keycode == '13') {
            $('#validate-btn').trigger('click');
        }

    });

    $('#main-pane').on('click', '#void-btn', function (e) {
        e.preventDefault();

        var orderno = $(this).closest('tr').find('#void-order-no').val().trim();

        if (orderno.length <= 0) {
            $('#transaction-msg').css('color', 'red');
            $('#transaction-msg').text('Enter order number to void its transaction.');

            return;
        }
        voidTransaction($, $(this), orderno);
    });


    $('#main-pane').on('click', '#commit-btn', function (e) {
        e.preventDefault();

        var orderno = $(this).closest('tr').find('#commit-order-no').val().trim();


        if (orderno.length <= 0) {
            $('#transaction-msg').css('color', 'red');
            $('#transaction-msg').text('Enter order number to commit its transaction.');

            return;
        }
        commitTransaction($, $(this), orderno);
    });

    $('#main-pane').on('click', '#validate-btn', function (e) {
        e.preventDefault();

        var orderno = $(this).closest('tr').find('#validate-order-no').val().trim();

        if (orderno.length <= 0) {
            $('#transaction-msg').css('color', 'red');
            $('#transaction-msg').text('Enter order number to validate its address.');

            return;
        }
        validateAddress($, $(this), orderno);
    });

     
}

function initTooltips($) {
    $('#main-pane').tooltip();
}



function voidTransaction($, $button, orderno) {
    $("body").LoadingOverlay("show");

    var url = $button.data('url');

    $('#response-json').text('');

    var resolved = function (data) {
        $('#transaction-msg').css('color', '#666');
        $('#transaction-msg').text('Void transaction: ' + data.message);

        $('#response-json').text(JSON.stringify(data.svcResponse));



        $("body").LoadingOverlay("hide");
    };

    var rejected = function (data) {
        $('#transaction-msg').css('color', 'red');
        $('#transaction-msg').text('Void transaction: ' + data.message);

        $('#response-json').text(data.message);

        $("body").LoadingOverlay("hide");
    };

    var promise = new Promise(function (resolve, reject) {
        $.ajax({
            method: 'POST',
            data: {
                orderno: orderno
            },
            url: url
        }).done(function (result) {
            if (!result.success) {
                rejected(result);
            } else {
                resolved(result);
            }
        });
    });
    promise.then(resolved, rejected);
}


function commitTransaction($, $button, orderno) {
    $("body").LoadingOverlay("show");
    $('#response-json').text('');

    var url = $button.data('url');

    var resolved = function (data) {
        $('#transaction-msg').css('color', '#666');
        $('#transaction-msg').text('Commit transaction: ' + data.message);

        $('#response-json').text(JSON.stringify(data.svcResponse));

        $("body").LoadingOverlay("hide");
    };

    var rejected = function (data) {
        $('#transaction-msg').css('color', 'red');
        $('#transaction-msg').text('Commit transaction: ' + data.message);

        $('#response-json').text(JSON.stringify(data.message));

        $("body").LoadingOverlay("hide");
    };

    var promise = new Promise(function (resolve, reject) {
        $.ajax({
            method: 'POST',
            data: {
                orderno: orderno
            },
            url: url
        }).done(function (result) {
            if (!result.success) {
                rejected(result);
            } else {
                resolved(result);
            }
        });
    });
    promise.then(resolved, rejected);
}



function validateAddress($, $button, orderno) {
    $("body").LoadingOverlay("show");
    $('#response-json').text('');

    var url = $button.data('url');

    var resolved = function (data) {
        $('#transaction-msg').css('color', '#666');
        $('#transaction-msg').text('Address validation: ' + data.message);

        $('#response-json').text(JSON.stringify(data.svcResponse));



        $("body").LoadingOverlay("hide");
    };

    var rejected = function (data) {
        $('#transaction-msg').css('color', 'red');
        $('#transaction-msg').text('Address validation: ' + data.message);

        $('#response-json').text(data.message);

        $("body").LoadingOverlay("hide");
    };

    var promise = new Promise(function (resolve, reject) {
        $.ajax({
            method: 'POST',
            data: {
                orderno: orderno
            },
            url: url
        }).done(function (result) {
            if (!result.success) {
                rejected(result);
            } else {
                resolved(result);
            }
        });
    });
    promise.then(resolved, rejected);
}