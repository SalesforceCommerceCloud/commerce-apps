jQuery(document).ready(function ($) {
    main($);
    $('body').css('display', 'block');
});

function main($) {
    // Initialize datatable
    var table = $('#customers-table').DataTable({
        columns: [
            {
                orderable: true
            },
            {
                orderable: false
            },
            {
                orderable: false
            },
            {
                orderable: false
            },
            {
                orderable: true
            }
        ]
    });
}
