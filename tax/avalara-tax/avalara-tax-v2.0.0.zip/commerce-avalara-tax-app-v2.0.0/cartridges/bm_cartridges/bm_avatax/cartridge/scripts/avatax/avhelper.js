'use strict';

var Site = require('dw/system/Site');
var dwsystem = require('dw/system');
var dwStringUtils = require('dw/util').StringUtils;

var siteInfoObj = {};
// Logger includes
var LOGGER = dw.system.Logger.getLogger('Avalara', 'AvaTax');
// AvaTax setting preference
var settingsObject = {};
try {
    settingsObject = JSON.parse(dwsystem.Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (error) {
    LOGGER.warn('Failed to parse AVSettings site preference. Details - ' + error.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = {};
}

/**
 * Utility class and methods to retrieve merchant settings related to AvaTax
 */
function avataxHelper() { }

avataxHelper.prototype = {
	// Get the Line item by its UUID
	getLineItemByUUID: function (basket, uuid) {
		var allLineItemsIterator = basket.allLineItems.iterator();
		while (allLineItemsIterator.hasNext()) {
			var li = allLineItemsIterator.next();
			if (li.UUID === uuid) {
				return li;
			} else if ('shippingLineItem' in li && !empty(li.shippingLineItem) && li.shippingLineItem.UUID === uuid) {
				return li.shippingLineItem;
			}
		}
		return null;
	},
	getCustomCustomerAttribute: function () {
		return settingsObject.configs.customCustomerAttribute;
	},
	getCustomerCodePreference: function () {
		return settingsObject.configs.useCustomCustomerCode || 'customer_number';
	},
	saveTransactionsToAvatax: function () {
		return settingsObject.configs.saveTransactions;
	},
	commitTransactionsToAvatax: function () {
		return settingsObject.configs.commitTransactions;
	},
	getDefaultShippingMethodTaxCode: function () {
		return settingsObject.configs.defaultShippingMethodTaxCode || 'FR';
	},
	getDefaultProductTaxCode: function () {
		return 'P0000000';
	},
	getShipFromLocationCode: function () {
		return settingsObject.configs.locationCode;
	},
	getShipFromLine1: function () {
		return settingsObject.configs.line1;
	},
	getShipFromLine2: function () {
		return settingsObject.configs.line2;
	},
	getShipFromLine3: function () {
		return settingsObject.configs.line3;
	},
	getShipFromLatitude: function () {
		return '';
	},
	getShipFromLongitude: function () {
		return '';
	},
	getShipFromCity: function () {
		return settingsObject.configs.city;
	},
	getShipFromStateCode: function () {
		return settingsObject.configs.state;
	},
	getShipFromZipCode: function () {
		return settingsObject.configs.zipCode;
	},
	getShipFromCountryCode: function () {
		return settingsObject.configs.countryCode;
	},
	getCompanyCode: function () {
		return settingsObject.configs.companyCode || 'DEFAULT';
	},
	getFormattedDate: function () {
		var date = new Date();
		return dwStringUtils.format('{0}-{1}-{2}', date.getUTCFullYear().toString(), this.insertLeadingZero(date.getUTCMonth() + 1), this.insertLeadingZero(date.getUTCDate()));
	},
	insertLeadingZero: function (nb) {
		if (nb < 10) {
			return '0' + nb;
		}
		return '' + nb;
	}
};

exports.avataxHelperExported = avataxHelper;


/**
 * Gets the site information and settings for the current site
 * @returns {Object} site info object
 */
function getSiteInfo() {
	var avataxEnabled = settingsObject.configs.taxCalculation ? 'Enabled' : 'Disabled';
	var saveTransactionsToAvatax = avataxHelper.prototype.saveTransactionsToAvatax() ? 'Yes' : 'No';
	var commitTransactionsToAvatax = avataxHelper.prototype.commitTransactionsToAvatax() ? 'Yes' : 'No';
	var companyCode = avataxHelper.prototype.getCompanyCode();
	var defaultShippingMethodTaxCode = avataxHelper.prototype.getDefaultShippingMethodTaxCode();
	var siteName = Site.current.name;
	var siteId = Site.current.ID;
	// Construct a shipFrom addressLocationInfo object from preferences
	var shipFromLocationCode = avataxHelper.prototype.getShipFromLocationCode();
	var shipFromLine1 = avataxHelper.prototype.getShipFromLine1();
	var shipFromLine2 = avataxHelper.prototype.getShipFromLine2();
	var shiFromLine3 = avataxHelper.prototype.getShipFromLine3();
	var shipFromCity = avataxHelper.prototype.getShipFromCity();
	var shipFromStateCode = avataxHelper.prototype.getShipFromStateCode();
	var shipFromZipCode = avataxHelper.prototype.getShipFromZipCode();
	var shipFromCountryCode = avataxHelper.prototype.getShipFromCountryCode();
	var shipFromLatitude = avataxHelper.prototype.getShipFromLatitude();
	var shipFromLongitude = avataxHelper.prototype.getShipFromLongitude();
	var aliShipFrom = {};
	aliShipFrom.locationCode = !empty(shipFromLocationCode) ? shipFromLocationCode : '';
	aliShipFrom.line1 = !empty(shipFromLine1) ? shipFromLine1 : '';
	aliShipFrom.line2 = !empty(shipFromLine2) ? shipFromLine2 : '';
	aliShipFrom.line3 = !empty(shiFromLine3) ? shiFromLine3 : '';
	aliShipFrom.city = !empty(shipFromCity) ? shipFromCity : '';
	aliShipFrom.region = !empty(shipFromStateCode) ? shipFromStateCode : '';
	aliShipFrom.postalCode = !empty(shipFromZipCode) ? shipFromZipCode : '';
	aliShipFrom.country = !empty(shipFromCountryCode) ? shipFromCountryCode : '';
	aliShipFrom.latitude = !empty(shipFromLatitude) ? shipFromLatitude : '';
	aliShipFrom.longitude = !empty(shipFromLongitude) ? shipFromLongitude : '';
	siteInfoObj = {
		avataxEnabled: avataxEnabled,
		siteName: siteName,
		siteId: siteId,
		shipFromAddress: aliShipFrom,
		saveTransactionsToAvatax: saveTransactionsToAvatax,
		commitTransactionsToAvatax: commitTransactionsToAvatax,
		companyCode: companyCode,
		defaultShippingMethodTaxCode: defaultShippingMethodTaxCode
	};
	return siteInfoObj;
}


function generateEightDigits() {
	var min = 10000000;
	var max = 99999999;
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getSiteId() {
	var siteId = Site.current.ID;
	if(settingsObject.configId) {
		return settingsObject.configId;
	}
    var randomId = generateEightDigits();
	
    return siteId + '_' + randomId;
}

exports.getSiteInfo = getSiteInfo;
exports.getSiteId = getSiteId;

exports.getSiteInfoAJAX = function getSiteInfoAJAX() {
	var r = require('~/cartridge/scripts/util/Response');
	var siteInfo = getSiteInfo();
	r.renderJSON({
		siteInfo: siteInfoObj
	});
	return;
};

