
'use strict';

var Status = require('dw/system/Status');
var dworder = require('dw/order');
var dwStringUtils = require('dw/util').StringUtils;
var dwvalue = require('dw/value');
var dwlogger = require('dw/system/Logger');
var dwsite = require('dw/system/Site');
var SortedMap = require('dw/util/SortedMap');
var Decimal = require('dw/util/Decimal');
var TaxMgr = require('dw/order/TaxMgr');
var LOGGER = dwlogger.getLogger('Avalara', 'AvaTax');

// script includes
var avaTaxClient = require('~/cartridge/scripts/services/avataxService');
var jsonAddress = { lladdresses: {} };
var merchantDetails = {};
try {
    jsonAddress = require('*/cartridge/scripts/lineLevelAddress.json');
} catch (error) {
    // Keep fallback empty mapping when optional config file is unavailable.
}
try {
    merchantDetails = require('*/cartridge/scripts/avaMerchantConf.json');
} catch (error) {
    // Keep fallback empty merchant details when optional config file is unavailable.
}

// Model includes
var AddressValidationInfo = require('~/cartridge/models/addressValidationInfo');
var CreateTransactionModel = require('~/cartridge/models/createTransactionModel');

// Logger includes

// AvaTax setting preference
var settingsObject = {};
try {
    settingsObject = JSON.parse(dwsite.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (error) {
    LOGGER.warn('Failed to parse AVSettings site preference. Details - ' + error.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = {};
}

var customerTaxId = !empty(customer.profile) ? customer.profile.taxID : null; // Tax ID of the customer
var taxationpolicy;
var defaultProductTaxCode = 'P0000000';
var defaultShippingMethodTaxCode = settingsObject.configs.defaultShippingMethodTaxCode || 'FR';
var taxIncluded;

//global variables
var uuidLineNumbersMap;
var lineIdShipmentIdMap;
var shipmentIdShipfromMap;
var counter;
var lines=[];
var shippingAddress;
var isMultipleShipTo = false;

/**
 * Extracts all line items in the Basket
 * @param {dw.order.Basket} basket  `Basket` object
 * @returns An array of `dw.order.LineItem`
 */
var getAllLineItems = function (basket) {
    uuidLineNumbersMap = new SortedMap();
    lineIdShipmentIdMap = new SortedMap();
    shipmentIdShipfromMap = new SortedMap();
    counter = 0;
    taxationpolicy = (settingsObject.configs.taxationpolicy ||
        (TaxMgr.taxationPolicy === TaxMgr.TAX_POLICY_NET ? 'net' : 'gross')).toString();
    taxIncluded = taxationpolicy === 'net' ? false : true;
    return {
        lines: getProductLineItems(basket).concat(getShippingLineItems(basket)).concat(getGiftCertificateLineItems(basket)),
        uuidLineNumbersMap: uuidLineNumbersMap,
        lineIdShipmentIdMap: lineIdShipmentIdMap
    };
};

/**
 * Extracts all product line items from the Basket
 * @param {dw.order.Basket} basket Basket object
 * @returns An array of product line items
 */
function getProductLineItems(basket){

    var pliIterator = basket.productLineItems.iterator();
    lines = [];

    while (pliIterator.hasNext()) {
        var li = pliIterator.next();

        if (!empty(li.shipment.shippingAddress)) {

            var prodID = li.productID;
            var shippingAddress = li.shipment.shippingAddress;
            var shipToAddress;
            var shipFromAddress = getAddressModelFromSettingsObject();

            // create a line item and push it to lines array
            var line = new CreateTransactionModel.LineItemModel();

            //Search for line level ship from address for specific product
            line.merchantSellerIdentifier=null;
            if(!empty(jsonAddress.lladdresses[prodID])){
                if( jsonAddress.lladdresses[prodID].shipfrom && !empty(jsonAddress.lladdresses[prodID].shipfrom.line1) && !empty(jsonAddress.lladdresses[prodID].shipfrom.countryCode)){
                    shipFromAddress = getJsonShipFrom(jsonAddress.lladdresses[prodID].shipfrom);
                }

                if(!empty(jsonAddress.lladdresses[prodID].merchantId)) {
                    line.merchantSellerIdentifier = jsonAddress.lladdresses[prodID].merchantId;

                    if(merchantDetails[line.merchantSellerIdentifier] && !empty(merchantDetails[line.merchantSellerIdentifier].parameters)) {
                        line.parameters = JSON.parse(JSON.stringify(merchantDetails[line.merchantSellerIdentifier].parameters));
                    }
                }
                
                if(!empty(jsonAddress.lladdresses[prodID].transport)) {
                    line.parameters.push({
                        "name": "Transport",
                        "value": jsonAddress.lladdresses[prodID].transport
                });
                }

                //Uncomment code below to populate hsCode on product level  for Cross Border transactions
                // See documentation for more info
                if(!empty(jsonAddress.lladdresses[prodID].hsCode)) {
                    line.hsCode = jsonAddress.lladdresses[prodID].hsCode;
                }
            }

            // Construct a shipTo addressLocationInfo object from shippingAddress
            shipToAddress = getAddressModelWithValues(shippingAddress);

            // Making maps for later use
            uuidLineNumbersMap.put((++counter).toString(), li.UUID); // assign an integer value
            lineIdShipmentIdMap.put(counter.toString(), (li.productID + '|' + li.shipment.ID)); // to store shipment id and tax details
            shipmentIdShipfromMap.put(li.shipment.ID, shipFromAddress);

            if(li.shipment.ID != 'me'){
                isMultipleShipTo=true;
            }

            line.number = counter;
            line.quantity = li.quantityValue || li.quantity;
            line.amount = li.proratedPrice.value;

            // addresses model
            line.addresses = new CreateTransactionModel.AddressesModel();
            line.addresses.shipFrom= null;
            line.addresses.shipFrom = shipFromAddress;
            line.addresses.shipTo = shipToAddress;
            line.addresses.pointOfOrderOrigin = basket.billingAddress ? getAddressModelWithValues(basket.billingAddress) : null;

            line.taxCode = !empty(li.getProduct().taxClassID) ? li.getProduct().taxClassID.toString() : defaultProductTaxCode;
            line.customerUsageType = null;
            line.itemCode = (
                !empty(li.product.UPC) ? 'UPC:' + li.product.UPC :
                (!empty(li.productName) ? li.productName.toString() :
                (!empty(li.productID) ? li.productID : ''))
            ).substring(0, 50);
            line.exemptionCode = null;
            line.discounted = false;
            line.taxIncluded = taxIncluded;
            line.revenueAccount = null;
            line.ref1 = null;
            line.ref2 = null;
            line.description = !empty(li.product.shortDescription) ? li.product.shortDescription.source.toString().substring(0, 255) : '';
            line.businessIdentificationNo = customerTaxId;
            line.taxOverride = null;

            // Set hsCode from custom product attributes if not already set
            // Priority: 1. ATAutomatedHSCode (from Avalara API), 2. ATHSCode (manual), 3. ATProductCategory
            if (!line.hsCode) {
                if (!empty(li.product.custom.ATAutomatedHSCode)) {
                    line.hsCode = li.product.custom.ATAutomatedHSCode;
                } else if (!empty(li.product.custom.ATHSCode)) {
                    line.hsCode = li.product.custom.ATHSCode;
                } else if (!empty(li.product.custom.ATProductCategory)) {
                    line.hsCode = li.product.custom.ATProductCategory;
                }
            }

            // Uncomment the code below to populate marketplaceLiabilityType and originationSite on product level 
            // See documentation for more info
            // line.marketplaceLiabilityType = "";
            // line.originationSite = "";

            // Cross-border and dimension parameters from custom product attributes
            var customAttrs = li.product.custom || null;
            if (customAttrs) {
                if (!empty(customAttrs.ATIsPreferredProgram)) {
                    line.parameters.push({ "name": "IsPreferredProgram", "value": customAttrs.ATIsPreferredProgram });
                }
                if (!empty(customAttrs.ATCountryOfManufacture)) {
                    line.parameters.push({ "name": "CountryOfManufacture", "value": customAttrs.ATCountryOfManufacture });
                }
                if (!empty(customAttrs.ATNetWeightValue)) {
                    line.parameters.push({ "name": "NetWeight", "value": customAttrs.ATNetWeightValue.toString(), "UOMCode": customAttrs.ATNetWeightUOM || "" });
                }
                if (!empty(customAttrs.ATHeightValue)) {
                    line.parameters.push({ "name": "Height", "value": customAttrs.ATHeightValue.toString(), "UOMCode": customAttrs.ATHeightUOM || "" });
                }
                if (!empty(customAttrs.ATWidthValue)) {
                    line.parameters.push({ "name": "Width", "value": customAttrs.ATWidthValue.toString(), "UOMCode": customAttrs.ATWidthUOM || "" });
                }
                if (!empty(customAttrs.ATLengthValue)) {
                    line.parameters.push({ "name": "Length", "value": customAttrs.ATLengthValue.toString(), "UOMCode": customAttrs.ATLengthUOM || "" });
                }
            }

            lines.push(line);

            // Pushing option products
            var oliIterator = li.optionProductLineItems.iterator();
            while (oliIterator.hasNext()) {
                // create a line item and push it to lines array
                var oli = oliIterator.next();
                var line = new CreateTransactionModel.LineItemModel();
                uuidLineNumbersMap.put((++counter).toString(), oli.UUID); // assign an integer value
                line.number = counter;
                lineIdShipmentIdMap.put(counter.toString(), (oli.optionID + '|' + oli.shipment.ID)); // to store shipment id and tax details
                line.quantity = oli.quantityValue || oli.quantity;
                line.amount = oli.proratedPrice.value;
                // Addresses model
                line.addresses = new CreateTransactionModel.AddressesModel();

                line.merchantSellerIdentifier=null;
                line.addresses.shipFrom = shipFromAddress;
                line.addresses.shipTo = shipToAddress;
                line.taxCode = !empty(oli.taxClassID) ? oli.taxClassID.toString() : defaultProductTaxCode;
                line.customerUsageType = null;
                line.itemCode = !empty(oli.productName) ? oli.productName.toString().substring(0, 50) : '';
                line.exemptionCode = null;
                line.discounted = false;
                line.taxIncluded = taxIncluded;
                line.revenueAccount = null;
                line.ref1 = null;
                line.ref2 = null;
                line.description = !empty(oli.productName) ? oli.productName.substring(0, 50) : '';
                line.businessIdentificationNo = customerTaxId;
                line.taxOverride = null;
                line.parameters = null;
                lines.push(line);
            }
            //pushing shipping line items
            if (!empty(li.shippingLineItem)) {
                // create a line item and push it to lines array
                var sli = li.shippingLineItem;
                var line = new CreateTransactionModel.LineItemModel();
                uuidLineNumbersMap.put((++counter).toString(), sli.UUID); // assign an integer value
                line.number = counter;
                lineIdShipmentIdMap.put(counter.toString(), (sli.shipment.ID + '|' + sli.shipment.ID)); // to store shipment id and tax details
                line.quantity = 1;
                line.amount = sli.adjustedPrice.value;
                // Addresse model
                line.addresses = new CreateTransactionModel.AddressesModel();
                line.addresses.shipFrom = shipFromAddress;
                line.addresses.shipTo = shipToAddress;
                line.taxCode = !empty(sli.taxClassID) ? sli.taxClassID.toString() : defaultShippingMethodTaxCode;
                line.customerUsageType = null;
                line.itemCode = !empty(sli.lineItemText) ? sli.lineItemText.toString().substring(0, 50) : 'shipping-line-item';
                line.exemptionCode = null;
                line.discounted = false;
                line.taxIncluded = taxIncluded;
                line.revenueAccount = null;
                line.ref1 = null;
                line.ref2 = null;
                line.description = !empty(sli.lineItemText) ? sli.lineItemText.toString().substring(0, 255) : 'shipping-line-item';
                line.businessIdentificationNo = customerTaxId;
                line.taxOverride = null;
                line.merchantSellerIdentifier=null;
                line.parameters = null;
                lines.push(line);
            }
        }
    }
    return lines;
}

/**
 * Returns all shipping line items from the basket
 * @param {dw.order.Basket} basket Basket object
 * @returns An array of shipping line items
 */
function getShippingLineItems(basket){
    lines=[];
    var shipmentsIterator = basket.shipments.iterator();
    while (shipmentsIterator.hasNext()) {
        var shipment = shipmentsIterator.next();
        if (!empty(shipment.shippingAddress)) {

            var shippingLineItemsIterator = shipment.shippingLineItems.iterator();

            while (shippingLineItemsIterator.hasNext()) {
                var li = shippingLineItemsIterator.next();
                var line = new CreateTransactionModel.LineItemModel();
                uuidLineNumbersMap.put((++counter).toString(), li.UUID); // assign an integer value
                line.number = counter;

                lineIdShipmentIdMap.put(counter.toString(), (shipment.ID + '|' + shipment.ID)); // to store shipment id and tax details
                var shipFromByID = shipmentIdShipfromMap.get(shipment.ID);
                line.quantity = 1;
                line.amount = li.adjustedPrice.value;
                // Addresse model
                shippingAddress = shipment.shippingAddress;
                line.addresses = new CreateTransactionModel.AddressesModel();

                line.addresses.shipFrom = getAddressModelFromSettingsObject();
                if(isMultipleShipTo){
                    if(shipFromByID){
                        line.addresses.shipFrom = shipFromByID;
                    }

                }
                if(shipmentIdShipfromMap.size() == 1){
                    line.addresses.shipFrom = shipFromByID;
                }
                // Construct a shipTo addressLocationInfo object from shippingAddress
                line.addresses.shipTo = getAddressModelWithValues(shippingAddress);
                line.taxCode = !empty(li.taxClassID) ? li.taxClassID.toString() : defaultShippingMethodTaxCode;
                line.customerUsageType = null;
                line.itemCode = !empty(li.ID) ? li.ID.toString().substring(0, 50) : 'shipping-line-item';
                line.exemptionCode = null;
                line.discounted = false;
                line.taxIncluded = taxIncluded;
                line.revenueAccount = null;
                line.ref1 = null;
                line.ref2 = null;
                line.description = !empty(li.lineItemText) ? li.lineItemText.toString().substring(0, 255) : 'shipping-line-item';
                line.businessIdentificationNo = customerTaxId;
                line.taxOverride = null;
                line.merchantSellerIdentifier=null;
                line.parameters = null;
                lines.push(line);
            }
        }
    }
    return lines;
}

/**
 * Returns all gift  certificate line items from Basket.
 * @param {*} basket Basket object
 * @returns An array of gift line items
 */
function getGiftCertificateLineItems(basket){
    lines=[];
    var giftCertLinesIterator = basket.giftCertificateLineItems.iterator();
    while (giftCertLinesIterator.hasNext()) {

        var giftCert = giftCertLinesIterator.next();
        var gs = giftCert.shipment;

        if (  (!empty(gs.shippingAddress))  ||  (!empty(basket.billingAddress))  ){

            var line = new CreateTransactionModel.LineItemModel();
            uuidLineNumbersMap.put((++counter).toString(), giftCert.UUID); // assign an integer value
            line.number = counter;
            lineIdShipmentIdMap.put(counter.toString(), (giftCert.giftCertificateID + '|' + giftCert.shipment.ID)); // to store shipment id and tax details
            line.quantity = 1;
            line.amount = giftCert.getPriceValue();
            // Addresse model
            line.addresses = new CreateTransactionModel.AddressesModel();
            line.addresses.shipFrom = getAddressModelFromSettingsObject();

            line.taxCode = 'PG050000'; // Default gift card tax code
            line.customerUsageType = null;
            line.itemCode = !empty(giftCert.lineItemText) ? giftCert.lineItemText.toString().substring(0, 50) : gs.giftCertificateID.toString() || 'gift-certificate';
            line.exemptionCode = null;
            line.discounted = false;
            line.taxIncluded = taxIncluded;
            line.revenueAccount = null;
            line.ref1 = null;
            line.ref2 = null;
            line.description = !empty(giftCert.lineItemText) ? giftCert.lineItemText.toString().substring(0, 255) : 'gift-certificate';
            line.businessIdentificationNo = customerTaxId;
            line.taxOverride = null;
            line.merchantSellerIdentifier=null;
            line.parameters = null;

            // Construct a shipTo addressLocationInfo object from shippingAddress
            var gsShipTo;
            if (!empty(gs.shippingAddress)) {
                gsShipTo = getAddressModelWithValues(gs.shippingAddress);
            } else {
                gsShipTo = getAddressModelWithValues(basket.billingAddress);
            }

            line.addresses.shipTo = gsShipTo;
            lines.push(line);
        }
    }
    return lines;
}

/**
 * Fetches line level shipfrom address from JSON file
 * @param {*} params shipfrom object for specific product ID
 * @returns {object} returns an object containing shipfrom address attributes
 */
function getJsonShipFrom(shipfrom){
	var jsonShipFrom = new CreateTransactionModel.AddressLocationInfo();
    jsonShipFrom.locationCode = shipfrom.locationCode || '';
    jsonShipFrom.line1 =  shipfrom.line1 || '';
	jsonShipFrom.line2 =shipfrom.line2 || '';
	jsonShipFrom.line3 =  shipfrom.line3 || '';
	jsonShipFrom.city =  shipfrom.city || '';
	jsonShipFrom.region =  shipfrom.region || '';
	jsonShipFrom.postalCode =  shipfrom.postalCode || '';
	jsonShipFrom.country =  shipfrom.countryCode || '';
	jsonShipFrom.latitude = shipfrom.latitude || '';
	jsonShipFrom.longitude = shipfrom.longitude || '';

	return jsonShipFrom;
}

/**
 * Fetches and updates Gift line item shipTo address details
 * @returns {object} returns an object containing shipto address attributes
 */
 function getAddressModelWithValues(shippingAddressObj){
    // Update the shipTo addressLocationInfo object from shippingAddress object 
    var shipToAddress = new CreateTransactionModel.AddressLocationInfo();
    shipToAddress.locationCode = '';
    shipToAddress.line1 = shippingAddressObj.address1;
    shipToAddress.line2 = shippingAddressObj.address2;
    shipToAddress.line3 = '';
    shipToAddress.city = shippingAddressObj.city;
    shipToAddress.region = shippingAddressObj.stateCode;
    shipToAddress.country = shippingAddressObj.countryCode.getDisplayValue().toString();
    shipToAddress.postalCode = shippingAddressObj.postalCode;
    shipToAddress.latitude = '';
    shipToAddress.longitude = '';
    return shipToAddress;
 }

/**
 * Fetches default shipfrom address from Avatax Settings page
 * @returns {object} returns an object containing shipfrom address attributes
 */
function getAddressModelFromSettingsObject(){
    // Construct a shipFrom addressLocationInfo object from preferences
    var aliShipFrom = new CreateTransactionModel.AddressLocationInfo();
    aliShipFrom.locationCode = !empty(settingsObject.configs.locationCode) ? settingsObject.configs.locationCode : '';
    aliShipFrom.line1 = !empty(settingsObject.configs.line1) ? settingsObject.configs.line1 : '';
    aliShipFrom.line2 = !empty(settingsObject.configs.line2) ? settingsObject.configs.line2 : '';
    aliShipFrom.line3 = !empty(settingsObject.configs.line3) ? settingsObject.configs.line3 : '';
    aliShipFrom.city = !empty(settingsObject.configs.city) ? settingsObject.configs.city : '';
    aliShipFrom.region = !empty(settingsObject.configs.state) ? settingsObject.configs.state : '';
    aliShipFrom.postalCode = !empty(settingsObject.configs.zipCode) ? settingsObject.configs.zipCode : '';
    aliShipFrom.country = !empty(settingsObject.configs.countryCode) ? settingsObject.configs.countryCode : '';
    aliShipFrom.latitude = '';
    aliShipFrom.longitude = '';
    return aliShipFrom;
}

module.exports = {
    getAllLineItems: getAllLineItems
}
