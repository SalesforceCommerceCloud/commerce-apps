# Avalara Tax Integration for Commerce Cloud

This cartridge integrates Avalara AvaTax with Salesforce Commerce Cloud to provide real-time tax calculation, transaction management, and tax reporting capabilities.

## Package manifest

This package includes a root-level **`commerce-app.json`** manifest: app identity, domain, version, capabilities, cartridge and Storefront Next extension paths, and other extensible metadata. Post-install checklist tasks live in **`app-configuration/tasksList.json`**. Tools and registries can read `commerce-app.json` for package-level metadata without relying on an external registry manifest alone.

## Overview

The Avalara Tax App provides:
- Real-time tax calculation for orders
- Tax breakdown details per jurisdiction (state, county, city, etc.)
- Transaction commitment and void support via AvaTax API
- Request deduplication to avoid redundant API calls
- Business Manager tools for Avalara configuration, order reconciliation, and help

## Cartridge Structure

### Site Cartridges
- **int_avatax**: Core AvaTax integration cartridge containing hook scripts, service definitions, and helpers. Uses a hook-based architecture so it works regardless of storefront framework.

### Business Manager Cartridges
- **bm_avatax**: Business Manager module for Avalara. Adds an **Avalara** menu under Administration with three screens:
  - **Avalara settings** — configure connection, company, ship-from address, and transaction behavior (writes to the `AVSettings` custom preference)
  - **Reconcile orders** — reconcile Commerce Cloud orders against transactions recorded in AvaTax
  - **Avalara Help** — in-BM reference guide
  - Also includes scheduled job steps (`AvalaraSettingsSyncStep`, `AvalaraHSCodeSyncStep`) for settings sync and HS code classification

## Installation

### Prerequisites
- Avalara AvaTax account with API credentials
- Company Code configured in AvaTax

### Steps

These steps match the post-install checklist in `app-configuration/tasksList.json`:

Site settings import and cartridge paths (`int_avatax` on the storefront site and `bm_avatax` on Business Manager) are handled by the install process and do not need separate checklist steps.

1. **Configure AvaTax Service Credentials**
   In Administration > Operations > Services > Credentials, configure:
   - `credentials.avatax.rest` (Dev: `https://sandbox-rest.avatax.com`, Prod: `https://rest.avatax.com`)
   - `logentries.avatax.rest` (Dev: `https://ceplogger.sbx.avalara.com/api/logger/`, Prod: `https://ceplogger.avalara.com/api/logger/`)

2. **Enable Avalara BM Module Access**
   Go to Administration > Organization > Roles & Permissions, select the role (e.g. Administrator), open Business Manager Modules, choose site context (any/all), enable **Avalara**, and click Update.

### After the checklist

Once the checklist above is complete, finish configuring the integration from the Business Manager **Administration > Avalara > Avalara settings** screen (connection details, company code, ship-from address, customer code strategy, and commit behavior). This screen writes its configuration to the `AVSettings` custom preference — see [Configuration](#configuration) below.

## Configuration

### AVSettings (SitePreferences)

Operational AvaTax configuration is **not** exposed as individual Business Manager custom preferences. It's stored as a single JSON blob in one custom preference, managed exclusively through the **Avalara settings** BM screen (Administration > Avalara > Avalara settings):

| Attribute ID | Type | Description |
|---|---|---|
| **AVSettings** | string | JSON object holding all AvaTax configuration (connection, company code, ship-from address, customer code strategy, save/commit behavior, tax codes, etc.). Default value: `{"migrateflag":true, "lastsync":""}`. Created/updated automatically when the merchant connects through the Avalara Settings page — do not edit this preference by hand. |

### Custom Attributes (from `impex/install/meta/system-objecttype-extensions.xml`)

**Basket** and **Order** (group: `avatax` — "Avalara | AvaTax")

| Attribute ID | Type | Description |
|---|---|---|
| **ATTax** | string | Standard Tax/VAT/GST total |
| **ATTaxDetail** | text | Per-line jurisdiction tax breakdown (JSON) |
| **ATCustomsDuty** | string | Import duty / fees |
| **ATLandedCost** | text | Cross-border summary |
| **ATInvoiceMessage** | string | VAT invoice messages extracted from the AvaTax response |
| **ATGenericMessage** | text | Transaction summary messages |
| **ATVatCode** | string | VAT code |
| **ATVerificationStatus** | string | Compliance verification status |
| **ATVerificationJSON** | string | Compliance verification details (JSON) |

**Profile** (group: `avatax` — "AvaTax")

| Attribute ID | Type | Description |
|---|---|---|
| **ATisSellerImporterOfRecord** | boolean | Whether the seller is importer of record for this customer |

**Product** (group: `avatax` — "Avalara | AvaTax")

| Attribute ID | Type | Description |
|---|---|---|
| **ATCountryOfManufacture** | string | 2-digit ISO country code where the product was manufactured |
| **ATIsPreferredProgram** | boolean | Whether the product qualifies for a preferred trade program |
| **ATNetWeightValue** | double | Net weight value |
| **ATNetWeightUOM** | string | Net weight unit of measure |
| **ATHeightValue** | double | Height value |
| **ATHeightUOM** | string | Height unit of measure |
| **ATWidthValue** | double | Width value |
| **ATWidthUOM** | string | Width unit of measure |
| **ATLengthValue** | double | Length value |
| **ATLengthUOM** | string | Length unit of measure |
| **ATHSCode** | string | Harmonized System code used by customs to calculate tariff rates |
| **ATProductCategory** | string | Fallback category used to estimate tax when no HS code is available |
| **ATEnableHSCodeAutomatedJob** | boolean | Whether this product is included in the automated HS code retrieval job |
| **ATAutomatedHSCode** | string (externally managed) | HS code automatically retrieved from an external API |

### Service Configuration

The integration uses the following service:
- **Service ID**: `avatax.rest.all`
- **Credential ID**: `credentials.avatax.rest`
- **Profile ID**: `profile.avatax.rest`

## Features

### Tax Calculation
- Real-time tax calculation during checkout via the `calculate` hook (`sfcc.app.tax.calculate` / `dw.order.calculateTax`)
- Product, option, shipping, and gift certificate line item support
- Per-jurisdiction tax breakdown stored in `basket.custom.ATTaxDetail`
- VAT invoice message extraction stored in `basket.custom.ATInvoiceMessage`
- Request deduplication using MurmurHash to skip redundant API calls when the basket hasn't changed
- Multilevel (per-jurisdiction) tax application via `setTaxes()` when the site has SFCC's Multilevel Tax Calculation feature enabled, with automatic fallback to single-level (exact-amount) tax application otherwise

### Transaction Management
- Creates and commits the order's AvaTax SalesInvoice on order placement via the `commit` hook (`sfcc.app.tax.commit`)
- Void/cancel transactions on order cancellation via the `cancel` hook (`sfcc.app.tax.cancel`)
- Controlled by the `saveTransactions` / `commitTransactions` keys inside `AVSettings`

## Testing

Unit tests are included under `cartridges/site_cartridges/int_avatax/test/unit/`:
- `hooks/calculate.test.js` — tax calculation hook tests
- `hooks/calculateTax.test.js` — legacy `dw.order.calculateTax` hook tests
- `hooks/commit.test.js` — transaction commit hook tests
- `hooks/cancel.test.js` — transaction void hook tests
- `helpers/avataxHelper.test.js` — helper function tests (transaction model building, tax application, deduplication, etc.)

## Uninstallation

To uninstall the integration:
1. Remove `int_avatax` from cartridge paths
2. Import uninstall metadata: `impex/uninstall/`
3. Disable the AvaTax service

## Support

For AvaTax API documentation, visit: https://developer.avalara.com/


   