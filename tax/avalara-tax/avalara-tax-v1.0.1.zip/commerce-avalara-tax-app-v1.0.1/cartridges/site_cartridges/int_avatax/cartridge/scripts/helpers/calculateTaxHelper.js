/**
 * Copyright 2026 Salesforce, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

var Site = require('dw/system/Site');
var TaxMgr = require('dw/order/TaxMgr');
var SortedMap = require('dw/util/SortedMap');
var Logger = require('dw/system/Logger');

var jsonAddress = require('~/cartridge/scripts/lineLevelAddress.json');
var merchantDetails = require('~/cartridge/scripts/avaMerchantConf.json');
var CreateTransactionModel = require('~/cartridge/models/createTransactionModel');

var logger = Logger.getLogger('AvaTax', 'avataxHelper');

var settingsObject = {};
try {
    settingsObject = JSON.parse(Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (e) {
    logger.warn('Could not parse AVSettings: ' + e.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = {};
}

/**
 * Reloads AVSettings from site preference (supports BM sync during session).
 */
function refreshSettingsFromSite() {
    try {
        settingsObject = JSON.parse(Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
    } catch (e) {
        logger.warn('Could not parse AVSettings: ' + e.message);
        settingsObject = {};
    }
    if (!settingsObject.configs) {
        settingsObject.configs = {};
    }
    defaultShippingMethodTaxCode = settingsObject.configs.defaultShippingMethodTaxCode || 'FR';
}

var customerTaxId;
var taxationpolicy;
var defaultProductTaxCode = 'P0000000';
var defaultShippingMethodTaxCode = settingsObject.configs.defaultShippingMethodTaxCode || 'FR';
var taxIncluded;

var uuidLineNumbersMap;
var lineIdShipmentIdMap;
var shipmentIdShipfromMap;
var counter;
var lines = [];
var shippingAddress;
var isMultipleShipTo = false;

/**
 * SFCC empty() equivalent for cartridge and unit test environments.
 *
 * @param {*} value
 * @returns {boolean}
 */
function isEmpty(value) {
    return value === null || value === undefined || value === '';
}

/**
 * Reads a Money-like object or number safely.
 *
 * @param {*} money
 * @returns {number|null}
 */
function getMoneyValue(money) {
    if (money === null || money === undefined) {
        return null;
    }
    if (typeof money === 'number') {
        return money;
    }
    if (typeof money.getValue === 'function') {
        return money.getValue();
    }
    if (money.value !== null && money.value !== undefined) {
        return money.value;
    }
    return null;
}

/**
 * Resolves shipping line amount using only SFCC-supported fields.
 * Priority:
 * 1) adjustedGrossPrice/adjustedNetPrice (policy aware)
 * 2) adjustedPrice
 * 3) grossPrice/netPrice
 *
 * @param {dw.order.ShippingLineItem|dw.order.ProductShippingLineItem|Object} shippingLineItem
 * @returns {number}
 */
function resolveShippingLineAmount(shippingLineItem) {
    if (!shippingLineItem) {
        return 0;
    }

    var preferredAdjusted = taxationpolicy === 'net' ?
        getMoneyValue(shippingLineItem.adjustedNetPrice) :
        getMoneyValue(shippingLineItem.adjustedGrossPrice);
    if (preferredAdjusted !== null) {
        return preferredAdjusted;
    }

    var adjusted = getMoneyValue(shippingLineItem.adjustedPrice);
    if (adjusted !== null) {
        return adjusted;
    }

    var preferredBase = taxationpolicy === 'net' ?
        getMoneyValue(shippingLineItem.netPrice) :
        getMoneyValue(shippingLineItem.grossPrice);
    if (preferredBase !== null) {
        return preferredBase;
    }

    return 0;
}

/**
 * @param {dw.order.LineItemCtnr} basket
 * @returns {string|null}
 */
function getCustomerTaxIdFromBasket(basket) {
    var customer = basket.getCustomer ? basket.getCustomer() : null;
    if (customer && customer.profile && customer.profile.taxID) {
        return customer.profile.taxID;
    }
    return null;
}

/**
 * @param {dw.value.EnumValue|string|Object} countryCode
 * @returns {string}
 */
function getCountryDisplayValue(countryCode) {
    if (!countryCode) {
        return '';
    }
    if (typeof countryCode.getDisplayValue === 'function') {
        return countryCode.getDisplayValue().toString();
    }
    if (countryCode.value) {
        return countryCode.value;
    }
    return countryCode.toString();
}

/**
 * @param {dw.order.Basket} basket
 * @returns {{lines: Array, uuidLineNumbersMap: dw.util.SortedMap, lineIdShipmentIdMap: dw.util.SortedMap}}
 */
function getAllLineItems(basket) {
    refreshSettingsFromSite();
    uuidLineNumbersMap = new SortedMap();
    lineIdShipmentIdMap = new SortedMap();
    shipmentIdShipfromMap = new SortedMap();
    counter = 0;
    isMultipleShipTo = false;
    customerTaxId = getCustomerTaxIdFromBasket(basket);
    taxationpolicy = settingsObject.configs.taxationpolicy ?
        settingsObject.configs.taxationpolicy.toString() :
        (TaxMgr.getTaxationPolicy() === TaxMgr.TAX_POLICY_NET ? 'net' : 'gross');
    taxIncluded = taxationpolicy === 'net' ? false : true;

    return {
        lines: getProductLineItems(basket)
            .concat(getShippingLineItems(basket))
            .concat(getGiftCertificateLineItems(basket)),
        uuidLineNumbersMap: uuidLineNumbersMap,
        lineIdShipmentIdMap: lineIdShipmentIdMap
    };
}

/**
 * @param {dw.order.Basket} basket
 * @returns {Array}
 */
function getProductLineItems(basket) {
    lines = [];
    var productLineItems = basket.getProductLineItems ? basket.getProductLineItems() : basket.productLineItems;

    if (!productLineItems) {
        return lines;
    }

    var pliIterator = productLineItems.iterator();
    while (pliIterator.hasNext()) {
        var li = pliIterator.next();
        var shipment = li.getShipment ? li.getShipment() : li.shipment;

        if (!shipment) {
            continue;
        }

        var shippingAddressObj = shipment.getShippingAddress ?
            shipment.getShippingAddress() :
            shipment.shippingAddress;

        if (isEmpty(shippingAddressObj)) {
            continue;
        }

        var prodID = li.productID;
        var shipToAddress;
        var shipFromAddress = getAddressModelFromSettingsObject();
        var product = li.getProduct ? li.getProduct() : li.product;
        var line = new CreateTransactionModel.LineItemModel();

        line.merchantSellerIdentifier = null;
        if (!isEmpty(jsonAddress.lladdresses[prodID])) {
            if (jsonAddress.lladdresses[prodID].shipfrom &&
                !isEmpty(jsonAddress.lladdresses[prodID].shipfrom.line1) &&
                !isEmpty(jsonAddress.lladdresses[prodID].shipfrom.countryCode)) {
                shipFromAddress = getJsonShipFrom(jsonAddress.lladdresses[prodID].shipfrom);
            }

            if (!isEmpty(jsonAddress.lladdresses[prodID].merchantId)) {
                line.merchantSellerIdentifier = jsonAddress.lladdresses[prodID].merchantId;

                if (merchantDetails[line.merchantSellerIdentifier] &&
                    !isEmpty(merchantDetails[line.merchantSellerIdentifier].parameters)) {
                    line.parameters = JSON.parse(JSON.stringify(
                        merchantDetails[line.merchantSellerIdentifier].parameters
                    ));
                }
            }

            if (!isEmpty(jsonAddress.lladdresses[prodID].transport)) {
                line.parameters.push({
                    name: 'Transport',
                    value: jsonAddress.lladdresses[prodID].transport
                });
            }

            if (!isEmpty(jsonAddress.lladdresses[prodID].hsCode)) {
                line.hsCode = jsonAddress.lladdresses[prodID].hsCode;
            }
        }

        shipToAddress = getAddressModelWithValues(shippingAddressObj);

        uuidLineNumbersMap.put((++counter).toString(), li.UUID);
        lineIdShipmentIdMap.put(counter.toString(), li.productID + '|' + shipment.ID);
        shipmentIdShipfromMap.put(shipment.ID, shipFromAddress);

        if (shipment.ID !== 'me') {
            isMultipleShipTo = true;
        }

        line.number = counter;
        line.quantity = li.quantityValue || li.quantity;
        line.amount = li.proratedPrice.value;

        line.addresses = new CreateTransactionModel.AddressesModel();
        line.addresses.shipFrom = shipFromAddress;
        line.addresses.shipTo = shipToAddress;

        var billingAddress = basket.getBillingAddress ?
            basket.getBillingAddress() :
            basket.billingAddress;
        line.addresses.pointOfOrderOrigin = billingAddress ?
            getAddressModelWithValues(billingAddress) :
            null;

        line.taxCode = (product && !isEmpty(product.taxClassID)) ?
            product.taxClassID.toString() :
            defaultProductTaxCode;
        line.customerUsageType = null;
        line.itemCode = (
            (product && !isEmpty(product.UPC)) ? 'UPC:' + product.UPC :
            (!isEmpty(li.productID) ? li.productID.toString() :
            (!isEmpty(li.productName) ? li.productName.toString() : ''))
        ).substring(0, 50);
        line.exemptionCode = null;
        line.discounted = false;
        line.taxIncluded = taxIncluded;
        line.revenueAccount = null;
        line.ref1 = null;
        line.ref2 = null;
        line.description = (product && product.shortDescription && product.shortDescription.source) ?
            product.shortDescription.source.toString().substring(0, 255) :
            '';
        line.businessIdentificationNo = customerTaxId;
        line.taxOverride = null;

        if (!line.hsCode && product && product.custom) {
            if (!isEmpty(product.custom.ATAutomatedHSCode)) {
                line.hsCode = product.custom.ATAutomatedHSCode;
            } else if (!isEmpty(product.custom.ATHSCode)) {
                line.hsCode = product.custom.ATHSCode;
            } else if (!isEmpty(product.custom.ATProductCategory)) {
                line.hsCode = product.custom.ATProductCategory;
            }
        }

        var customAttrs = product ? product.custom : null;
        if (customAttrs) {
            if (!isEmpty(customAttrs.ATIsPreferredProgram)) {
                line.parameters.push({ name: 'IsPreferredProgram', value: customAttrs.ATIsPreferredProgram });
            }
            if (!isEmpty(customAttrs.ATCountryOfManufacture)) {
                line.parameters.push({ name: 'CountryOfManufacture', value: customAttrs.ATCountryOfManufacture });
            }
            if (!isEmpty(customAttrs.ATNetWeightValue)) {
                line.parameters.push({
                    name: 'NetWeight',
                    value: customAttrs.ATNetWeightValue.toString(),
                    UOMCode: customAttrs.ATNetWeightUOM || ''
                });
            }
            if (!isEmpty(customAttrs.ATHeightValue)) {
                line.parameters.push({
                    name: 'Height',
                    value: customAttrs.ATHeightValue.toString(),
                    UOMCode: customAttrs.ATHeightUOM || ''
                });
            }
            if (!isEmpty(customAttrs.ATWidthValue)) {
                line.parameters.push({
                    name: 'Width',
                    value: customAttrs.ATWidthValue.toString(),
                    UOMCode: customAttrs.ATWidthUOM || ''
                });
            }
            if (!isEmpty(customAttrs.ATLengthValue)) {
                line.parameters.push({
                    name: 'Length',
                    value: customAttrs.ATLengthValue.toString(),
                    UOMCode: customAttrs.ATLengthUOM || ''
                });
            }
        }

        lines.push(line);

        var optionLineItems = li.optionProductLineItems;
        if (optionLineItems) {
            var oliIterator = optionLineItems.iterator();
            while (oliIterator.hasNext()) {
                var oli = oliIterator.next();
                var optionLine = new CreateTransactionModel.LineItemModel();
                uuidLineNumbersMap.put((++counter).toString(), oli.UUID);
                optionLine.number = counter;
                lineIdShipmentIdMap.put(counter.toString(), oli.optionID + '|' + shipment.ID);
                optionLine.quantity = oli.quantityValue || oli.quantity;
                optionLine.amount = oli.proratedPrice.value;
                optionLine.addresses = new CreateTransactionModel.AddressesModel();
                optionLine.merchantSellerIdentifier = null;
                optionLine.addresses.shipFrom = shipFromAddress;
                optionLine.addresses.shipTo = shipToAddress;
                optionLine.taxCode = !isEmpty(oli.taxClassID) ?
                    oli.taxClassID.toString() :
                    defaultProductTaxCode;
                optionLine.customerUsageType = null;
                optionLine.itemCode = !isEmpty(oli.productName) ?
                    oli.productName.toString().substring(0, 50) :
                    '';
                optionLine.exemptionCode = null;
                optionLine.discounted = false;
                optionLine.taxIncluded = taxIncluded;
                optionLine.revenueAccount = null;
                optionLine.ref1 = null;
                optionLine.ref2 = null;
                optionLine.description = !isEmpty(oli.productName) ?
                    oli.productName.substring(0, 50) :
                    '';
                optionLine.businessIdentificationNo = customerTaxId;
                optionLine.taxOverride = null;
                optionLine.parameters = null;
                lines.push(optionLine);
            }
        }

        if (!isEmpty(li.shippingLineItem)) {
            var sli = li.shippingLineItem;
            var sliShipment = sli.shipment || shipment;
            var productShippingLine = new CreateTransactionModel.LineItemModel();
            uuidLineNumbersMap.put((++counter).toString(), sli.UUID);
            productShippingLine.number = counter;
            lineIdShipmentIdMap.put(counter.toString(), sliShipment.ID + '|' + sliShipment.ID);
            productShippingLine.quantity = 1;
            productShippingLine.amount = resolveShippingLineAmount(sli);
            productShippingLine.addresses = new CreateTransactionModel.AddressesModel();
            productShippingLine.addresses.shipFrom = shipFromAddress;
            productShippingLine.addresses.shipTo = shipToAddress;
            productShippingLine.taxCode = !isEmpty(sli.taxClassID) ?
                sli.taxClassID.toString() :
                defaultShippingMethodTaxCode;
            productShippingLine.customerUsageType = null;
            productShippingLine.itemCode = !isEmpty(sli.lineItemText) ?
                sli.lineItemText.toString().substring(0, 50) :
                'shipping-line-item';
            productShippingLine.exemptionCode = null;
            productShippingLine.discounted = false;
            productShippingLine.taxIncluded = taxIncluded;
            productShippingLine.revenueAccount = null;
            productShippingLine.ref1 = null;
            productShippingLine.ref2 = null;
            productShippingLine.description = !isEmpty(sli.lineItemText) ?
                sli.lineItemText.toString().substring(0, 255) :
                'shipping-line-item';
            productShippingLine.businessIdentificationNo = customerTaxId;
            productShippingLine.taxOverride = null;
            productShippingLine.merchantSellerIdentifier = null;
            productShippingLine.parameters = null;
            lines.push(productShippingLine);
        }
    }

    return lines;
}

/**
 * @param {dw.order.Basket} basket
 * @returns {Array}
 */
function getShippingLineItems(basket) {
    lines = [];
    var shipments = basket.getShipments ? basket.getShipments() : basket.shipments;

    if (!shipments) {
        return lines;
    }

    var shipmentsIterator = shipments.iterator();
    while (shipmentsIterator.hasNext()) {
        var shipment = shipmentsIterator.next();
        var shippingAddressObj = shipment.getShippingAddress ?
            shipment.getShippingAddress() :
            shipment.shippingAddress;

        if (isEmpty(shippingAddressObj)) {
            continue;
        }

        var shippingLineItems = shipment.getShippingLineItems ?
            shipment.getShippingLineItems() :
            shipment.shippingLineItems;

        if (!shippingLineItems) {
            continue;
        }

        var shippingLineItemsIterator = shippingLineItems.iterator();
        while (shippingLineItemsIterator.hasNext()) {
            var li = shippingLineItemsIterator.next();
            var line = new CreateTransactionModel.LineItemModel();
            uuidLineNumbersMap.put((++counter).toString(), li.UUID);
            line.number = counter;
            lineIdShipmentIdMap.put(counter.toString(), shipment.ID + '|' + shipment.ID);
            var shipFromByID = shipmentIdShipfromMap.get(shipment.ID);
            line.quantity = 1;
            line.amount = resolveShippingLineAmount(li);
            shippingAddress = shippingAddressObj;
            line.addresses = new CreateTransactionModel.AddressesModel();
            line.addresses.shipFrom = getAddressModelFromSettingsObject();

            if (isMultipleShipTo && shipFromByID) {
                line.addresses.shipFrom = shipFromByID;
            }
            if (shipmentIdShipfromMap.size() === 1) {
                line.addresses.shipFrom = shipFromByID;
            }

            line.addresses.shipTo = getAddressModelWithValues(shippingAddress);
            line.taxCode = !isEmpty(li.taxClassID) ?
                li.taxClassID.toString() :
                defaultShippingMethodTaxCode;
            line.customerUsageType = null;
            line.itemCode = !isEmpty(li.ID) ?
                li.ID.toString().substring(0, 50) :
                'shipping-line-item';
            line.exemptionCode = null;
            line.discounted = false;
            line.taxIncluded = taxIncluded;
            line.revenueAccount = null;
            line.ref1 = null;
            line.ref2 = null;
            line.description = !isEmpty(li.lineItemText) ?
                li.lineItemText.toString().substring(0, 255) :
                'shipping-line-item';
            line.businessIdentificationNo = customerTaxId;
            line.taxOverride = null;
            line.merchantSellerIdentifier = null;
            line.parameters = null;
            lines.push(line);
        }
    }

    return lines;
}

/**
 * @param {dw.order.Basket} basket
 * @returns {Array}
 */
function getGiftCertificateLineItems(basket) {
    lines = [];
    var giftCertLineItems = basket.getGiftCertificateLineItems ?
        basket.getGiftCertificateLineItems() :
        basket.giftCertificateLineItems;

    if (!giftCertLineItems) {
        return lines;
    }

    var giftCertLinesIterator = giftCertLineItems.iterator();
    while (giftCertLinesIterator.hasNext()) {
        var giftCert = giftCertLinesIterator.next();
        var gs = giftCert.shipment;
        var billingAddress = basket.getBillingAddress ?
            basket.getBillingAddress() :
            basket.billingAddress;

        if (isEmpty(gs.shippingAddress) && isEmpty(billingAddress)) {
            continue;
        }

        var line = new CreateTransactionModel.LineItemModel();
        uuidLineNumbersMap.put((++counter).toString(), giftCert.UUID);
        line.number = counter;
        lineIdShipmentIdMap.put(counter.toString(), giftCert.giftCertificateID + '|' + gs.ID);
        line.quantity = 1;
        line.amount = giftCert.getPriceValue();
        line.addresses = new CreateTransactionModel.AddressesModel();
        line.addresses.shipFrom = getAddressModelFromSettingsObject();
        line.taxCode = 'PG050000';
        line.customerUsageType = null;
        line.itemCode = (
            (gs && !isEmpty(gs.giftCertificateID)) ? gs.giftCertificateID.toString() :
            (!isEmpty(giftCert.lineItemText) ? giftCert.lineItemText.toString() :
            'gift-certificate')
        ).substring(0, 50);
        line.exemptionCode = null;
        line.discounted = false;
        line.taxIncluded = taxIncluded;
        line.revenueAccount = null;
        line.ref1 = null;
        line.ref2 = null;
        line.description = !isEmpty(giftCert.lineItemText) ?
            giftCert.lineItemText.toString().substring(0, 255) :
            'gift-certificate';
        line.businessIdentificationNo = customerTaxId;
        line.taxOverride = null;
        line.merchantSellerIdentifier = null;
        line.parameters = null;

        var gsShipTo;
        if (!isEmpty(gs.shippingAddress)) {
            gsShipTo = getAddressModelWithValues(gs.shippingAddress);
        } else {
            gsShipTo = getAddressModelWithValues(billingAddress);
        }

        line.addresses.shipTo = gsShipTo;
        lines.push(line);
    }

    return lines;
}

/**
 * @param {Object} shipfrom
 * @returns {Object}
 */
function getJsonShipFrom(shipfrom) {
    var jsonShipFrom = new CreateTransactionModel.AddressLocationInfo();
    jsonShipFrom.locationCode = shipfrom.locationCode || '';
    jsonShipFrom.line1 = shipfrom.line1 || '';
    jsonShipFrom.line2 = shipfrom.line2 || '';
    jsonShipFrom.line3 = shipfrom.line3 || '';
    jsonShipFrom.city = shipfrom.city || '';
    jsonShipFrom.region = shipfrom.region || '';
    jsonShipFrom.postalCode = shipfrom.postalCode || '';
    jsonShipFrom.country = shipfrom.countryCode || '';
    jsonShipFrom.latitude = shipfrom.latitude || '';
    jsonShipFrom.longitude = shipfrom.longitude || '';
    return jsonShipFrom;
}

/**
 * @param {dw.order.OrderAddress} shippingAddressObj
 * @returns {Object}
 */
function getAddressModelWithValues(shippingAddressObj) {
    var shipToAddress = new CreateTransactionModel.AddressLocationInfo();
    shipToAddress.locationCode = '';
    shipToAddress.line1 = shippingAddressObj.address1;
    shipToAddress.line2 = shippingAddressObj.address2;
    shipToAddress.line3 = '';
    shipToAddress.city = shippingAddressObj.city;
    shipToAddress.region = shippingAddressObj.stateCode;
    shipToAddress.country = getCountryDisplayValue(shippingAddressObj.countryCode);
    shipToAddress.postalCode = shippingAddressObj.postalCode;
    shipToAddress.latitude = '';
    shipToAddress.longitude = '';
    return shipToAddress;
}

/**
 * @returns {Object}
 */
function getAddressModelFromSettingsObject() {
    var aliShipFrom = new CreateTransactionModel.AddressLocationInfo();
    aliShipFrom.locationCode = !isEmpty(settingsObject.configs.locationCode) ?
        settingsObject.configs.locationCode :
        '';
    aliShipFrom.line1 = !isEmpty(settingsObject.configs.line1) ? settingsObject.configs.line1 : '';
    aliShipFrom.line2 = !isEmpty(settingsObject.configs.line2) ? settingsObject.configs.line2 : '';
    aliShipFrom.line3 = !isEmpty(settingsObject.configs.line3) ? settingsObject.configs.line3 : '';
    aliShipFrom.city = !isEmpty(settingsObject.configs.city) ? settingsObject.configs.city : '';
    aliShipFrom.region = !isEmpty(settingsObject.configs.state) ? settingsObject.configs.state : '';
    aliShipFrom.postalCode = !isEmpty(settingsObject.configs.zipCode) ? settingsObject.configs.zipCode : '';
    aliShipFrom.country = !isEmpty(settingsObject.configs.countryCode) ?
        settingsObject.configs.countryCode :
        '';
    aliShipFrom.latitude = '';
    aliShipFrom.longitude = '';
    return aliShipFrom;
}

module.exports = {
    getAllLineItems: getAllLineItems
};
