'use strict';
/* eslint-disable require-jsdoc */

var applicationId = 'a0n0b00000KU6CDAA1';
var versionId = 'a0oUz00000CKG9lIAH';
var semanticVersion = 'SF B2C/Storefront Next || 1.0.1';

function defaultPayload() {
    return {
        configurations: {
            enable_tax_calculation: true,
            enable_address_validation: true,
            enable_save_transactions: true,
            enable_commit_transactions: false,
            company_code: "DEFAULT",
            customer_code: "customer_number",
            shipping_code: "FR"
        },
        address_settings: {
            address_loc_code: "",
            address_line_one: "",
            address_line_two: "",
            address_line_three: "",
            address_city: "",
            address_state: "",
            address_zipcode: "",
            address_country_code: ""
        }
    };
}

function defaultSettingsObject(companyCode) {
    return {
        taxCalculation: true,
        addressValidation: true,
        saveTransactions: true,
        commitTransactions: false,
        companyCode: companyCode || "DEFAULT",
        customCustomerAttribute: "",
        useCustomCustomerCode: "customer_number",
        defaultShippingMethodTaxCode: "FR",
        locationCode: "",
        line1: "",
        line2: "",
        line3: "",
        city: "",
        state: "",
        zipCode: "",
        countryCode: ""
    };
}

function legacySettingsPayload(settingsobj) {
    settingsobj = settingsobj || {};
    return {
        "configurations": {
            "enable_tax_calculation": settingsobj.taxCalculation != null ? settingsobj.taxCalculation : true,
            "enable_address_validation": settingsobj.addressValidation != null ? settingsobj.addressValidation : true,
            "enable_save_transactions": settingsobj.saveTransactions != null ? settingsobj.saveTransactions : true,
            "enable_commit_transactions": settingsobj.commitTransactions != null ? settingsobj.commitTransactions : false,
            "company_code": settingsobj.companyCode || "DEFAULT",
            "custom_customer_attribute": settingsobj.customCustomerAttribute || "",
            "customer_code": settingsobj.useCustomCustomerCode || "customer_number",
            "shipping_code": settingsobj.defaultShippingMethodTaxCode || "FR"
        },
        "address_settings": {
            "address_loc_code": settingsobj.locationCode || "",
            "address_line_one": settingsobj.line1 || "",
            "address_line_two": settingsobj.line2 || "",
            "address_line_three": settingsobj.line3 || "",
            "address_city": settingsobj.city || "",
            "address_state": settingsobj.state || "",
            "address_zipcode": settingsobj.zipCode || "",
            "address_country_code": settingsobj.countryCode || ""
        }
    };
}


function handleSyncPayload(syncConfigs) {
    var configurations = syncConfigs && syncConfigs.configurations ? syncConfigs.configurations : {};
    var addressSettings = syncConfigs && syncConfigs.address_settings ? syncConfigs.address_settings : {};
    return {
        "taxCalculation": configurations.enable_tax_calculation != null ? configurations.enable_tax_calculation : true,
        "addressValidation": configurations.enable_address_validation != null ? configurations.enable_address_validation : true,
        "saveTransactions": configurations.enable_save_transactions != null ? configurations.enable_save_transactions : true,
        "commitTransactions": configurations.enable_commit_transactions != null ? configurations.enable_commit_transactions : false,
        "companyCode": configurations.company_code || "DEFAULT",
        "customCustomerAttribute": configurations.custom_customer_attribute || "",
        "useCustomCustomerCode": configurations.customer_code || "customer_number",
        "defaultShippingMethodTaxCode": configurations.shipping_code || "FR",
        "locationCode": addressSettings.address_loc_code || "",
        "line1": addressSettings.address_line_one || "",
        "line2": addressSettings.address_line_two || "",
        "line3": addressSettings.address_line_three || "",
        "city": addressSettings.address_city || "",
        "state": addressSettings.address_state || "",
        "zipCode": addressSettings.address_zipcode || "",
        "countryCode": addressSettings.address_country_code || ""
    };
}

/**
 * Builds CCS section payload when creating a version-scoped section.
 * Prefers AVSettings, then ATSettings, else defaults.
 *
 * @param {Object} options
 * @param {Object} [options.sectionConfig] - Existing CCS section from GET
 * @param {Object} [options.avSettingsConfigs] - settingsObject.configs from AVSettings
 * @param {Object} [options.atSettings] - Legacy ATSettings object
 * @returns {Object} CCS section model
 */
function resolveSectionPayload(options) {
    options = options || {};

    if (options.sectionConfig && options.sectionConfig.configurations) {
        return options.sectionConfig;
    }
    if (options.avSettingsConfigs && options.avSettingsConfigs.companyCode) {
        return legacySettingsPayload(options.avSettingsConfigs);
    }
    if (options.atSettings) {
        return legacySettingsPayload(options.atSettings);
    }
    return defaultPayload();
}

function configIdModel(siteid, companyCode) {
    return {
        semanticVersion: semanticVersion,
        erpCompany: siteid,
        avaTaxCompany: companyCode || "DEFAULT",
        attributes: {
            "ERP Name": "Salesforce B2C Commerce Storefront Next"
        }
    };
}


module.exports = {
    defaultPayload: defaultPayload,
    defaultSettingsObject: defaultSettingsObject,
    legacySettingsPayload: legacySettingsPayload,
    configIdModel: configIdModel,
    resolveSectionPayload: resolveSectionPayload,
    handleSyncPayload: handleSyncPayload,
    applicationId: applicationId,
    versionId: versionId,
    semanticVersion: semanticVersion
};
