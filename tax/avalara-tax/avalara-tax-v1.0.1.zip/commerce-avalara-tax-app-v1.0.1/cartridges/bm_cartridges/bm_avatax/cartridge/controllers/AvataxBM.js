/**
 * Initializes the BM reconciliation module
 */
'use strict';

// Script Modules
var app = require('~/cartridge/scripts/app');
var guard = require('~/cartridge/scripts/guard');
var OrderMgr = require('dw/order/OrderMgr');
var dwsystem = require('dw/system');
var dworder = require('dw/order');

var avhelper = require('~/cartridge/scripts/avatax/avhelper');
var avaTaxClient = require('~/cartridge/scripts/services/avataxService');
var calculateTaxHelper = require('~/cartridge/scripts/helpers/reconcile/calculateTaxHelper');
var avataxJs = require('~/cartridge/scripts/helpers/reconcile/avaTax');

// Logger includes
var LOGGER = dw.system.Logger.getLogger('Avalara', 'AvaTax');

// Global variables
var avataxHelper = avhelper.avataxHelperExported;
var companyCode = '';
var params = request.httpParameterMap;

// Avalara setting preference
var settingsObject = {};
try {
    settingsObject = JSON.parse(dwsystem.Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (error) {
    LOGGER.warn('Failed to parse AVSettings site preference. Details - ' + error.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = {};
}

// Labels
var amountMisMatch = 'Amount Mismatch';
var taxMisMatch = 'Tax Mismatch';
var missingInAvaTax = 'Missing In AvaTax';
var missingInSFCC = 'Missing In B2C';

/**
 * Gets the site information and settings for the current site
 * @returns {*} site info
 */
function getSiteInfo() {
	return avhelper.getSiteInfo();
}

/**
 * Utility method to be used on client side
 * @returns {*} site info for ajax methods
 */
function getSiteInfoAJAX() {
	return avhelper.getSiteInfoAJAX();
}

/**
 * Displays the reconiliation page
 */
function start() {
	var currentMenuItemId = params.CurrentMenuItemId.value;
	var menuname = params.menuname.value;
	var mainmenuname = params.mainmenuname.value;

	session.privacy.currentMenuItemId = currentMenuItemId;
	session.privacy.menuname = menuname;
	session.privacy.mainmenuname = mainmenuname;
	// Preserve the dates
	session.privacy.fromdate = '';
	session.privacy.todate = '';
	var viewObj = {
		CurrentMenuItemId: currentMenuItemId,
		menuname: menuname,
		mainmenuname: mainmenuname,
		settingsObject: settingsObject
	};

	try {
		var siteInfo = avhelper.getSiteInfo();
		viewObj.siteInfo = siteInfo;
		var avataxEnabled = settingsObject.configs.taxCalculation;
		if (!avataxEnabled) {
			viewObj.errormsg = "AvaTax tax calculation is not enabled. Some features won't work. Please enable it by navigating to 'Merchants Tools > Avalara > Avalara Settings', and try again.";
		} else if (!settingsObject.configs.saveTransactions) {
			viewObj.errormsg = "'Save transactions to AvaTax' is not enabled.  Some features won't work. Please enable it by navigating to 'Merchants Tools > Avalara > Avalara Settings', and try again.";
		}
	} catch (e) {
		viewObj.errormsg = 'No Site selected. Please select a site from the dropdown, and try again.';
	}
	app.getView(viewObj).render('/avatax/ordersreconcile');
}

/**
 * Reconciles the order documents from SFCC and AvaTax
 * @param {*} sfccOrders sfccOrders
 * @param {*} avaTax avaTax
 * @returns {*} reconciled transaction
 */
function reconcileTransactions(sfccOrders, avaTax) {
	var countReport = {};
	var amountOrTaxMisMatchCount = 0;
	var missingInAvaTaxCount = 0;
	var missingInSFCCCount = 0;
	var result = [];
	var mapSFCCOrders = new dw.util.SortedMap();

	for (var i = 0; i < sfccOrders.size(); i++) {

		mapSFCCOrders.put(sfccOrders[i].orderNo, sfccOrders[i]);
		var avaTrans = avaTax.get(sfccOrders[i].orderNo);
		var rStatus = '-';
		var avTotalAmt;
		var avTotalTax;
		var avCurrency;

		if (avaTrans) {
			if (sfccOrders[i].totalNetPrice.value !== avaTrans.totalAmount) {
				rStatus = amountMisMatch;
				amountOrTaxMisMatchCount++;
			} else if (sfccOrders[i].totalTax.value !== avaTrans.totalTax) {
				rStatus = taxMisMatch;
				amountOrTaxMisMatchCount++;
			}
			avTotalAmt = avaTrans.totalAmount;
			avTotalTax = avaTrans.totalTax;
			avCurrency = avaTrans.currencyCode;
		} else {
			rStatus = missingInAvaTax;
			missingInAvaTaxCount++;
			avTotalAmt = '';
			avTotalTax = '';
		}

		if (rStatus !== '-') {

			var oDate = sfccOrders[i].creationDate;
			var odt = (BigInt(new dw.util.Decimal(oDate.getFullYear()))).toString() +
					'-' + BigInt((new dw.util.Decimal(oDate.getMonth() + 1))) +
					'-' + BigInt((new dw.util.Decimal(oDate.getDate()))).toString().padStart(2,'0');

			result.push({
				orderNo: sfccOrders[i].orderNo,
				orderDate: odt,
				orderStatus: sfccOrders[i].status,
				orderTotalAmt: sfccOrders[i].totalNetPrice.value,
				orderTax: sfccOrders[i].totalTax.value,
				avTotalAmt: avTotalAmt,
				avTotalTax: avTotalTax,
				avCurrencyCode: avCurrency,
				reconciliationStatus: rStatus
			});
		}
	}

	for (i = 0; i < avaTax.keySet().toArray().length; i++) {
		var docCode = avaTax.keySet().toArray()[i];
		var avataxDoc = avaTax.get(docCode);
		var order = mapSFCCOrders.get(docCode);
		if (!order) {
			result.push({
				orderNo: avataxDoc.code,
				orderDate: avataxDoc.date,
				orderStatus: '-',
				orderTotalAmt: '-',
				orderTax: '-',
				avTotalAmt: avataxDoc.totalAmount,
				avTotalTax: avataxDoc.totalTax,
				avCurrencyCode: avataxDoc.currencyCode,
				reconciliationStatus: missingInSFCC
			});
			missingInSFCCCount++;
		}
	}
	countReport = {
		amountOrTaxMisMatchCount: amountOrTaxMisMatchCount,
		missingInAvaTaxCount: missingInAvaTaxCount,
		missingInSFCCCount: missingInSFCCCount
	};
	return {
		orders: result,
		countReport: countReport
	};
}

/**
 * Fetches order documents from SFCC and AvaTax
 * @param {*} params collection of orders
 */
function getOrders() {
	var currentMenuItemId = session.privacy.currentMenuItemId;
	var menuname = session.privacy.menuname;
	var mainmenuname = session.privacy.mainmenuname;
	var siteInfo = null;
	var orders = null;
	var ordersList = null;
	var ordersOnAccount = null;
	var reconcileResults = null;
	var countReport = null;
	var errormsg = null;
	var reconciledOrders = null;
	var viewObj = null;

	var success = true;

	var siteInfo = getSiteInfo();

	try {
		var avataxEnabled = settingsObject.configs.taxCalculation;
		companyCode = settingsObject.configs.companyCode || 'DEFAULT';
		if (!avataxEnabled) {
			success = false;
			viewObj = {
				errormsg: "AvaTax tax calculation is not enabled. Some features won't work. Please enable it by navigating to 'Merchants Tools > Avalara > Avalara Settings', and try again.",
				CurrentMenuItemId: currentMenuItemId,
				menuname: menuname,
				mainmenuname: mainmenuname,
				settingsObject: settingsObject
			};
		} else if (!settingsObject.configs.saveTransactions) {
			success = false;
			viewObj = {
				errormsg: "'Save transactions to AvaTax' is not enabled.  Some features won't work. Please enable it by navigating to 'Merchants Tools > Avalara > Avalara Settings', and try again.",
				CurrentMenuItemId: currentMenuItemId,
				menuname: menuname,
				mainmenuname: mainmenuname,
				settingsObject: settingsObject
			};
		} else {
			siteInfo = getSiteInfo();
		}
	} catch (e) {
		success = false;
		viewObj = {
			errormsg: 'There was a problem processing this request. Please try again.',
			CurrentMenuItemId: currentMenuItemId,
			menuname: menuname,
			mainmenuname: mainmenuname,
			settingsObject: settingsObject
		};
	}
	if (success) {
		try {
			// Retrieve selected dates
			var fromdate = params.fromdate.value.toString();
			var todate = params.todate.value.toString();

			if (empty(fromdate) && empty(todate)) {
				var date = new Date();

				var today = date;
				var todayMonth = today.getUTCMonth() + 1;
				var todayDate = today.getUTCDate();
				var todayYear = today.getUTCFullYear();
				var todayDate = todayMonth + '/' + todayDate + '/' + todayYear;

				// 30 days back
				var frDay = new Date(new Date() - (30 * 24 * 60 * 60 * 1000)); // date 30 days ago
				var frMonth = frDay.getUTCMonth() + 1;
				var frDate = frDay.getUTCDate();
				var frYear = frDay.getUTCFullYear();
				var frDate = frMonth + '/' + frDate + '/' + frYear;

				fromdate = frDate;
				todate = todayDate;

			}
			// save dates to make them accessible on ISML
			session.privacy.fromdate = fromdate;
			session.privacy.todate = todate;
			if (empty(fromdate) && empty(todate)) {
				// AvaTax getTransactions API has changed to display only last 30 days transactions. Still keeping this piece
				orders = OrderMgr.queryOrders('orderNo != {0}', 'creationDate desc', '*');
				ordersOnAccount = avaTaxClient.getTransactions(companyCode); // yyyy-mm-dd
				ordersList = orders.asList();
				orders.close();
				if (!ordersOnAccount.ERROR) {
					reconcileResults = reconcileTransactions(ordersList, ordersOnAccount.values);
					reconciledOrders = reconcileResults.orders;
					countReport = reconcileResults.countReport;
				} else {
					errormsg = 'Error occured while contacting AvaTax services. If the problem persists, check service configuration settings and try again.';
				}
			} else if (empty(fromdate) || empty(todate)) {
				errormsg = 'Please select appropriate date range and try again.';
			} else {
				var fromDateArray = [fromdate.split('/')[0], fromdate.split('/')[1], fromdate.split('/')[2]];
				var toDateArray = [todate.split('/')[0], todate.split('/')[1], todate.split('/')[2]];
				var fdStr = fromDateArray[2] + '-' + fromDateArray[0] + '-' + fromDateArray[1]; // yyyy-mm-dd (AvaTax getTransactions)
				var tdStr = toDateArray[2] + '-' + toDateArray[0] + '-' + toDateArray[1]; // yyyy-mm-dd (AvaTax getTransactions)

				// OrderMgr.queryOrders needs Date objects (not strings) to compare creationDate;
				// a string bound does not filter and lets older orders leak in. Use the from-date at
				// local midnight and the day AFTER the to-date so the entire to-date is included.
				var fromDateObj = new Date(fromDateArray[2], fromDateArray[0] - 1, fromDateArray[1]);
				var toDateObj = new Date(toDateArray[2], toDateArray[0] - 1, toDateArray[1]);
				toDateObj.setDate(toDateObj.getDate() + 1);

				orders = OrderMgr.queryOrders('creationDate >= {0} AND creationDate <= {1} AND status != {2} AND status != {3}', 'creationDate desc', fromDateObj, toDateObj, 8, 6);

				ordersList = orders.asList();
				orders.close();
				ordersOnAccount = avaTaxClient.getTransactions(companyCode, fdStr, tdStr); // yyyy-mm-dd
				if (!ordersOnAccount.ERROR) {
					reconcileResults = reconcileTransactions(ordersList, ordersOnAccount.values);
					reconciledOrders = reconcileResults.orders;
					countReport = reconcileResults.countReport;
				} else {
					errormsg = 'Error occured while contacting AvaTax services. If the problem persists, check service configuration settings and try again.';
				}
			}
			viewObj = {
				orders: reconciledOrders,
				siteInfo: siteInfo,
				CurrentMenuItemId: currentMenuItemId,
				menuname: menuname,
				mainmenuname: mainmenuname,
				countReport: countReport,
				errormsg: errormsg,
				settingsObject: settingsObject
			};
		} catch (e) {
			LOGGER.warn('Problem while contacting AvaTax. Please check the logs for error details. ' + e.message);
			viewObj = {
				errormsg: 'Problem while contacting AvaTax. Please check the logs for error details.',
				CurrentMenuItemId: currentMenuItemId,
				siteInfo: siteInfo,
				menuname: menuname,
				mainmenuname: mainmenuname,
				settingsObject: settingsObject
			};
		}
	}
	app.getView(viewObj).render('/avatax/ordersreconcile');
}

var CreateTransactionModel = require('~/cartridge/models/createTransactionModel');
var counter = 0;

/**
 * Reconcile selected orders
 */
function reconcile() {
	var r = require('~/cartridge/scripts/util/Response');
	var orderNo = params.orderno.value;
	if (!settingsObject.configs.taxCalculation) {
		LOGGER.warn('AvaTax | AvaTax not enabled for this site. File - avaTax.js~calculateTax');
		r.renderJSON({
			ERROR: true,
			fatalmsg: 'AvaTax is disabled for this site.'
		});
		return;
	}
	if (!orderNo) {
		r.renderJSON({
			ERROR: true
		});
		return;
	}
	try {
		var basket = OrderMgr.getOrder(orderNo.toString());
		var uuidLineNumbersMap = new dw.util.SortedMap();
		var lineIdShipmentIdMap = new dw.util.SortedMap();
		var svcResponse = {};
		var transactionModel = new CreateTransactionModel.CreateTransactionModel();
		var customerTaxId = !empty(customer.profile) ? customer.profile.taxID : null; // Tax ID of the customer
		var isSellerImporterOfRecord = !empty(customer.profile) ? customer.profile.custom.ATisSellerImporterOfRecord : false;
		var lines = []; // Lines array
		var saveTransactionsToAvatax = avataxHelper.prototype.saveTransactionsToAvatax(); // Save transaction preference in custom preferences
		var commitTransactionsToAvatax = avataxHelper.prototype.commitTransactionsToAvatax(); // Commit transactions preference

		// Extract all line item objects from basket 
		var allLineItemsObj = calculateTaxHelper.getAllLineItems(basket);
		lines = allLineItemsObj.lines;
        uuidLineNumbersMap = allLineItemsObj.uuidLineNumbersMap;
        lineIdShipmentIdMap = allLineItemsObj.lineIdShipmentIdMap;

		var li;
		var line;

		// Lines array - END
		// Construct a transaction object
		if (orderNo) {
			transactionModel.code = orderNo;
			//  If commit document not enabled in site preferences, type is SalesOrder
			if (saveTransactionsToAvatax) {
				transactionModel.type = transactionModel.type.C_SALESINVOICE;
			} else {
				transactionModel.type = transactionModel.type.C_SALESORDER;
			}
		} else {
			r.renderJSON({
				ERROR: true,
				msg: 'Order number empty',
				orderno: orderNo
			});
			return;
		}

		transactionModel.lines = lines;
		transactionModel.commit = !!(commitTransactionsToAvatax && orderNo);
		transactionModel.companyCode = avataxHelper.prototype.getCompanyCode();
		transactionModel.date = basket.creationDate;
		transactionModel.salespersonCode = null;
		transactionModel.customerCode = empty(basket.getCustomerEmail()) ? 'so-cust-code' : basket.getCustomerEmail();
		transactionModel.debugLevel = transactionModel.debugLevel.C_NORMAL;
		transactionModel.serviceMode = transactionModel.serviceMode.C_AUTOMATIC;
		transactionModel.businessIdentificationNo = customerTaxId;
		transactionModel.currencyCode = basket.currencyCode;
		transactionModel.isSellerImporterOfRecord = isSellerImporterOfRecord;

		// ********* 	Call the tax adjustment service 	********** //
		svcResponse = avaTaxClient.createOrAdjustTransaction('', {
			createTransactionModel: transactionModel
		});

		// If AvaTax returns error, set taxes to Zero
		if (svcResponse.statusCode === 'ERROR') {
			var errormsg = svcResponse.errorMessage.error.details[0].message + ' Details - ' + svcResponse.errorMessage.error.details[0].description;
			// If error code in response is 'missingline', update logs
			if (svcResponse.errorMessage.error.code) {
				LOGGER.warn("AvaTax | AvaTax couldn't calculate taxes. Empty basket or empty shipping address. Basket details - " + basket);
				errormsg = 'Empty basket or empty shipping address';
			}
			r.renderJSON({
				ERROR: true,
				msg: errormsg,
				orderno: orderNo
			});
			return;
		}
		// If taxes cannot be calculated
		if (svcResponse.errorMessage) {
			errormsg = svcResponse.errorMessage.error.details[0].message + ' Details - ' + svcResponse.errorMessage.error.details[0].description;
			r.renderJSON({
				ERROR: true,
				msg: errormsg,
				orderno: orderNo
			});
			return;
		}
		if (!svcResponse.statusCode) {

			// Update Tax details on Order, received from Service
			avataxJs.updateTaxOnReconciledOrder({
				basket,
				svcResponse,
				transactionModel,
				orderNo,
				uuidLineNumbersMap,
				lineIdShipmentIdMap
			});

			r.renderJSON({
				ERROR: false,
				orderno: orderNo,
				taxAmt: svcResponse.totalTax,
				totalAmt: svcResponse.totalAmount
			});
			return;
		}
		errormsg = svcResponse.errorMessage.error.details[0].message + ' Details - ' + svcResponse.errorMessage.error.details[0].description;
		r.renderJSON({
			ERROR: true,
			msg: errormsg,
			orderno: orderNo
		});
		return;
	} catch (e) {
		LOGGER.warn('[Avatax gettax failed - {0}. File - AvataxBM.js]', e.message);
		r.renderJSON({
			ERROR: true,
			msg: e.message
		});
		return;
	}
}

// modules exports
exports.Start = guard.ensure(['https'], start);
exports.GetOrders = guard.ensure(['https'], getOrders);
exports.Reconcile = guard.ensure(['https', 'csrf'], reconcile);
exports.GetSiteInfoAJAX = guard.ensure(['https'], getSiteInfoAJAX);