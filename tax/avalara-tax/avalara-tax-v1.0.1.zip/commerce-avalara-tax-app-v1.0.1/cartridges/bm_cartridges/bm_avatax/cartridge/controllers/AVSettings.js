/**
 * The controller which handles various features on Avalara settings page of the BM cartridge
 */
'use strict';

// API includes
var dwsite = require('dw/system/Site');

/* Script Modules */
var app = require('~/cartridge/scripts/app');
var guard = require('~/cartridge/scripts/guard');

// script includes
var avaTaxClient = require('~/cartridge/scripts/services/avataxService');
var avLogger = require('~/cartridge/scripts/helpers/avLogger');
var r = require('~/cartridge/scripts/util/Response');
var avhelper = require('~/cartridge/scripts/avatax/avhelper');
var configSettingsModel = require('~/cartridge/models/configSettings');
var companyHelper = require('~/cartridge/scripts/helpers/companyHelper');

// Logger includes
var LOGGER = dw.system.Logger.getLogger('Avalara', 'AvaTax');
var params = request.httpParameterMap;

// Model includes
var AddressValidationInfo = require('~/cartridge/models/addressValidationInfo');
var CommitTransactionModel = require('~/cartridge/models/commitTransactionModel');
var VoidTransactionModel = require('~/cartridge/models/voidTransactionModel');

// Avalara setting preference
var settingsObject = {};
try {
    settingsObject = JSON.parse(dw.system.Site.getCurrent().getCustomPreferenceValue('AVSettings')) || {};
} catch (error) {
    LOGGER.warn('Failed to parse AVSettings site preference. Details - ' + error.message);
}
if (!settingsObject.configs) {
    settingsObject.configs = configSettingsModel.defaultSettingsObject('DEFAULT');
}
var jsonLog;
const baseProdUrl = 'https://app.avalara.com/integrations/advance-configuration-settings/a/'+configSettingsModel.applicationId+'/c/';
const baseSbxUrl = 'https://app.sbx.avalara.com/integrations/advance-configuration-settings/a/'+configSettingsModel.applicationId+'/c/';
const businessLicensesRegisterUrl = 'https://buy.avalara.com/avalara-licensing/get-started?partnerID=001300000057RfTAAU&campaignID=701Uz00000q6LaHIAU&connectorID=a0n0b00000KU6CDAA1&utm_campaign=AMER_CUST_Direct-Traffic_Online-Buy_09_2025_sf-b2c-bl-olb&marketing_channel=web_referral&vendor=partner&paid_unpaid=unpaid&target_audience=partner';
const businessLicensesStatusUrl = 'https://app.avalara.com/registrations/statuses';

var siteid = avhelper.getSiteId();

/**
 * It is a starting point for this controller and the page
 * It fetches the current settings and fills the form
 */
function start() {
    var currentMenuItemId = params.CurrentMenuItemId.value;
    var menuname = params.menuname.value;
    var mainmenuname = params.mainmenuname.value;

    session.privacy.currentMenuItemId = currentMenuItemId;
    session.privacy.menuname = menuname;
    session.privacy.mainmenuname = mainmenuname;
    var viewObj = {
        CurrentMenuItemId: currentMenuItemId,
        menuname: menuname,
        mainmenuname: mainmenuname,
        settings: settingsObject,
		businessLicensesRegisterUrl: businessLicensesRegisterUrl,
		businessLicensesStatusUrl: businessLicensesStatusUrl
    };

    app.getView(viewObj).render('/avatax/settings');
}


/**
 * Get information about AvaTax subscriptions
 */
 function getSubscriptions() {
    var res = null;
    var svcResponse = null;
    var svcResponse2 = null;
    var env = params.btnenv.value || '';
    var message = '';

    try {
        //Get Subscriptions for account 
        svcResponse = avaTaxClient.getSubscriptions(env, true);
        
        if (svcResponse.code == 'AuthenticationIncomplete' || svcResponse.code == 'AuthenticationException' || svcResponse.statusCode === 'ERROR') {
            jsonLog = {
                source: 'ConfigurationPage',
                operation: 'GetSubscriptions',
                message: 'Authentication failed',
                logType: 'Debug',
                logLevel: 'Exception',
                functionName: 'avaTax.js-getSubscriptions()'
            };
            avLogger.avConfigDebugLogs(jsonLog);
            var subErrMsg = (svcResponse.errorMessage && (svcResponse.errorMessage.Message || svcResponse.errorMessage.message || (svcResponse.errorMessage.error && svcResponse.errorMessage.error.message))) || svcResponse.errorMessage || '';
            LOGGER.warn('Couldn\'t connect to the '+env+' account. Details : ' + subErrMsg);
            
            res = {
                success: false,
                authenticated: false,
                message: 'Couldn\'t connect to the '+env+' account.'
            };
        } else {
            //Get Subscriptions successful, fetch subscribed services
            var services = [];
            var redirectUrl = env === 'Production' ? baseProdUrl+siteid : baseSbxUrl+siteid;
            if (svcResponse.value.length > 0) {
                for (var currService = 0; currService < svcResponse.value.length; currService++) {
                    var svc = svcResponse.value[currService];
                    services.push(svc.subscriptionDescription);
                }
            }
            //Push subscriptions to settings object
            settingsObject.subscriptions = services;
            LOGGER.warn('AvaTax subscriptions saved successfully for ' + env + ' account.');

            dw.system.Transaction.wrap(function () {
                dwsite.getCurrent().setCustomPreferenceValue('AVSettings', JSON.stringify(settingsObject));
            });

            svcResponse2 = findConfig();

            if(svcResponse2 === true){
                res = {
                    success: true,
                    message: 'Connected to '+env+' account. Adjust tax calculations with the Advanced settings in Avalara',
                    authenticated: true,
                    services: services,
                    redirectUrl: redirectUrl
                };
            }
            else{
                res = {
                    success: false,
                    message: 'Couldn\'t connect to the '+env+' account. '
                };
            }
        }
    } catch (error) {
        // Problem checking the AvaTax connection
        jsonLog = {
            source: 'ConfigurationPage',
            operation: 'GetSubscriptions',
            message: 'There was a problem checking the AvaTax connection',
            logType: 'Debug',
            logLevel: 'Exception',
            functionName: 'avaTax.js-getSubscriptions()'
        };
        avLogger.avConfigDebugLogs(jsonLog);
        LOGGER.warn('There was a problem checking the AvaTax connection. Details - ' + error.message);
        res = {
            success: false,
            message: 'Couldn\'t connect to the '+env+' account. '
        };
    }
    if (!res) {
        jsonLog = {
            source: 'ConfigurationPage',
            operation: 'GetSubscriptions',
            message: 'There was a problem checking the AvaTax connection',
            logType: 'Debug',
            logLevel: 'Exception',
            functionName: 'avaTax.js-getSubscriptions()'
        };
        avLogger.avConfigDebugLogs(jsonLog);
        LOGGER.warn('There was a problem checking the AvaTax connection.');
        res = {
            success: false,
            message: 'Couldn\'t connect to the '+env+' account.'
        };
    }
    r.renderJSON(res);
}


function settingsHelper(settingsObject, companyCode) {
    companyCode = companyCode || settingsObject.configs.companyCode || 'DEFAULT';
    let lastsync = new Date();
    let lastSyncString = ('0' + (lastsync.getMonth() + 1)).slice(-2) + '/' + ('0' + lastsync.getDate()).slice(-2) + '/' + lastsync.getFullYear() + ' ' + 
    ('0' + (lastsync.getHours() % 12 || 12)).slice(-2) + ':' + ('0' + lastsync.getMinutes()).slice(-2) + ' ' + (lastsync.getHours() >= 12 ? 'PM' : 'AM');

    settingsObject.migrateflag = false;
    settingsObject.lastSyncString = lastSyncString;
    settingsObject.lastsync = new Date(Date.now());
    settingsObject.configs.companyId = verifyCompanyCode(companyCode);
    settingsObject.configs.taxationpolicy = (dw.order.TaxMgr.taxationPolicy === dw.order.TaxMgr.TAX_POLICY_NET ) ? 'net' : 'gross'; 
    
    dw.system.Transaction.wrap(function () {
        dwsite.getCurrent().setCustomPreferenceValue('AVSettings', JSON.stringify(settingsObject));
    });

    return;
}

function syncSettingsData() {
    var res = null;
    var svcResponse = null;
    var message = '';

    try {
        var svcResponse=avaTaxClient.getConfigSectionId(siteid);
        if (!empty(svcResponse.statusCode) && svcResponse.statusCode !== 'OK') {
            message = 'There was a problem fetching the configuration settings. Service configuration issue.';
            
        }
        if (svcResponse.error || svcResponse.message || svcResponse.errorMessage || !svcResponse.config || !svcResponse.config.configurations) {
            message = getServiceErrorMessage(svcResponse, message);
            LOGGER.warn('Couldn’t sync Avalara settings to cartridge configuration in Salesforce B2C Commerce. Details - '+JSON.stringify(message));
            res = {
                success: false,
                message: 'Couldn’t sync Avalara settings to cartridge configuration in Salesforce B2C Commerce.'
            };
        } else {
            settingsObject.configs = configSettingsModel.handleSyncPayload(svcResponse.config);
            settingsHelper(settingsObject, svcResponse.config.configurations.company_code);
            LOGGER.warn('Settings synced successfully.');
            res = {
                success: true,
                message: 'Synced Avalara settings to cartridge configuration in Salesforce B2C Commerce.',
                configs: settingsObject
            };
        }
    } catch (error) {
        // Problem checking the AvaTax connection
        jsonLog = {
            source: 'ConfigurationPage',
            operation: 'syncSettingsData',
            message: 'There was a problem fetching the configuration settings.',
            logType: 'Debug',
            logLevel: 'Exception',
            functionName: 'avaTax.js-syncSettingsData()'
        };
        avLogger.avConfigDebugLogs(jsonLog);
        LOGGER.warn('There was a problem fetching the configuration settings. Details - ' + error.message);
            
        res = {
            success: false,
            message: 'Couldn’t sync Avalara settings to cartridge configuration in Salesforce B2C Commerce.'
        };
    }
    if (!res) {
        jsonLog = {
            source: 'ConfigurationPage',
            operation: 'syncSettingsData',
            message: 'There was a problem fetching the configuration settings.',
            logType: 'Debug',
            logLevel: 'Exception',
            functionName: 'avaTax.js-syncSettingsData()'
        };
        avLogger.avConfigDebugLogs(jsonLog);
        res = {
            success: false,
            message: 'Couldn’t sync Avalara settings to cartridge configuration in Salesforce B2C Commerce.'
        };
    }
    r.renderJSON(res);
}

/**
 * Verifies whether the entered company code string is a valid company
 * If its valid, returns its company ID
 * @param {string} companyCode
 */
function verifyCompanyCode(companyCode) {
    return companyHelper.verifyCompanyCode(companyCode);
}

/**
 * Fetches companies for current AvaTax user
 */
function getCompanies() {
    return companyHelper.getCompanies();
}

/**
 * Gets the default company code from AvaTax account
 * @returns {string} The default company code, or 'DEFAULT' if not found
 */
function getDefaultCompanyCode() {
    try {
        var companies = getCompanies();
        if (companies && companies.length > 0) {
            for (var i = 0; i < companies.length; i++) {
                if (companies[i].isDefault === true) {
                    return companies[i].companyCode;
                }
            }
        }
    } catch (error) {
        LOGGER.warn('Problem while fetching default company code: ' + error);
    }
    // If no default found or error occurred, return 'DEFAULT'
    return 'DEFAULT';
}

/**
 * Returns the service-provided error message.
 *
 * @param {Object} response - service response
 * @param {string} [defaultMessage] - current message to start from (retained if no field matches)
 * @returns {string} the error message, or the default/'' when none matches
 */
function getServiceErrorMessage(response, defaultMessage) {
    var message = defaultMessage || '';
    if (!response) {
        return message;
    }
    if (response.errorMessage) {
        message = response.errorMessage.Message;
    }
    if (response.message) {
        message = response.message;
    }
    if (response.error) {
        message = response.message || '';
    }
    return message;
}

/**
 * Returns true when a CCS config/section API response indicates the resource is missing.
 *
 * @param {Object} response - AvaTax CCS API response
 * @returns {boolean}
 */
function isCcsResourceNotFound(response) {
    if (!response || !response.errorMessage) {
        return false;
    }

    // errorMessage may arrive as a plain string or as an object ({ Message } / { message }).
    // Guard both shapes (with a JSON.stringify fallback) so detection never collapses to
    // the literal "undefined" when the CCS API returns a string payload.
    var message = typeof response.errorMessage === 'string'
        ? response.errorMessage
        : String(response.errorMessage.Message || response.errorMessage.message || JSON.stringify(response.errorMessage) || '');

    return message.indexOf('could not be located') !== -1 ||
        message.indexOf('could not be found') !== -1 ||
        message.indexOf('No tenant') !== -1;
}

function resolveCompanyCodeForConfig(configResponse) {
    var companyCode = getDefaultCompanyCode();

    if (!isCcsResourceNotFound(configResponse) && configResponse.avaTaxCompany) {
        return configResponse.avaTaxCompany;
    }
    if (settingsObject.configs && settingsObject.configs.companyCode) {
        return settingsObject.configs.companyCode;
    }

    return companyCode;
}

function buildSectionModel(sectionConfig, legacySettingsObject) {
    return configSettingsModel.resolveSectionPayload({
        sectionConfig: sectionConfig,
        avSettingsConfigs: settingsObject.configs,
        atSettings: legacySettingsObject
    });
}

function recreateConfigSection(siteid, secmodel) {
    var deleteResponse = avaTaxClient.deleteConfigSectionId(siteid);
    if (deleteResponse && deleteResponse.statusCode === 'ERROR' && !isCcsResourceNotFound(deleteResponse)) {
        LOGGER.warn('Could not delete existing CCS section before recreate. Status - ' + (deleteResponse ? deleteResponse.statusCode : 'unknown') + '. Error - ' + getServiceErrorMessage(deleteResponse));
    }

    return avaTaxClient.postConfigSectionId(siteid, secmodel);
}

function persistSettingsAfterSectionChange(companyCode, secmodel, migrateFromAtSettings, legacySettingsObject) {
    settingsObject.configId = siteid;

    if (migrateFromAtSettings) {
        settingsObject.configs = legacySettingsObject;
        settingsHelper(settingsObject, legacySettingsObject.companyCode || 'DEFAULT');
        return;
    }

    if (secmodel && secmodel.configurations) {
        settingsObject.configs = configSettingsModel.handleSyncPayload(secmodel);
        settingsHelper(settingsObject, secmodel.configurations.company_code || companyCode);
        return;
    }

    if (settingsObject.configs && settingsObject.configs.companyCode) {
        settingsHelper(settingsObject, settingsObject.configs.companyCode);
        return;
    }

    settingsObject.configs = configSettingsModel.defaultSettingsObject(companyCode);
    settingsHelper(settingsObject, companyCode);
}

/**
 * Voids a document on AvaTax with a certain order number
 */
function voidTransaction() {
    var orderno = params.orderno.value;
    var res = null;
    var message = '';

    if (empty(orderno)) {
        message = 'Empty order no.';

        res = {
            success: false,
            message: message
        };
    } else {
        try {
            var validateOrder = dw.order.OrderMgr.getOrder(orderno.toString());

            if (!validateOrder) {
                message = 'Order not found in Business Manager.';

                res = {
                    success: false,
                    message: message
                };
            } else {
                var svcResponse = voidDocument(orderno);

                if (svcResponse.error || svcResponse.message || svcResponse.errorMessage) {
                    message = 'Unsuccessful. Service response below:';

                    res = {
                        success: false,
                        message: message,
                        svcResponse: svcResponse
                    };
                } else {
                    message = 'Successful. Service response below:';
                    res = {
                        success: true,
                        message: message,
                        svcResponse: svcResponse
                    };
                }
            }
        } catch (e) {
            LOGGER.warn('There was a problem voiding the transaction - ' + orderno + '. Error - ' + e.message);
            res = {
                success: false,
                message: 'There was a problem voiding the transaction - ' + orderno + '. Please check logs.'
            };
        }
    }

    if (res == null) {
        res = {
            success: false,
            message: 'There was a problem voiding the transaction. Please check logs.'
        };
    }

    r.renderJSON(res);
}


/**
 * Commits a transaction on AvaTax with a certain order number
 */
function commitTransaction() {
    var orderno = params.orderno.value || '';

    var res = null;
    var message = '';

    if (empty(orderno)) {
        message = 'Empty order number.';

        res = {
            success: false,
            message: message
        };
    } else {
        try {
            var validateOrder = dw.order.OrderMgr.getOrder(orderno.toString());

            if (!validateOrder) {
                message = 'Order not found in Business Manager.';
                res = {
                    success: false,
                    message: message
                };
            } else {
                var svcResponse = commitDocument(orderno);

                if (svcResponse.error || svcResponse.message || svcResponse.errorMessage) {
                    message = 'Unsuccessful. Service response below:';

                    res = {
                        success: false,
                        message: message,
                        svcResponse: svcResponse
                    };
                } else {
                    message = 'Successful. Service response below:';
                    res = {
                        success: true,
                        message: message,
                        svcResponse: svcResponse
                    };
                }
            }
        } catch (e) {
            LOGGER.warn('There was a problem commiting the transaction - ' + orderno + '. Error - ' + e.message);
            res = {
                success: false,
                message: 'There was a problem commiting the transaction - ' + orderno + '. Please check logs.'
            };
        }
    }

    if (res == null) {
        res = {
            success: false,
            message: 'There was a problem commiting the transaction. Please check logs.'
        };
    }

    r.renderJSON(res);
}


/**
 * validates an address of the order
 */
function validateAddress() {
    var validateOrder;
    var address;
    var validateResponse;
    var errorMsg;
    var res = null;
    var message = '';
    var orderNo = params.orderno.value;
    validateOrder = dw.order.OrderMgr.getOrder(orderNo.toString());
    if (validateOrder) {
        var shipments = validateOrder.getShipments().iterator();
        while (shipments.hasNext()) {
            var currentShipment = shipments.next();
            address = currentShipment.shippingAddress;
            validateResponse = validateShippingAddress(address);
            if (validateResponse.messages && validateResponse.messages.length > 0) {
                message = 'Unsuccessful. Service response below:';
                res = {
                    success: true,
                    message: message,
                    svcResponse: validateResponse
                };
            } else {
                message = 'Successful. Service response below:';
                res = {
                    success: true,
                    message: message,
                    svcResponse: validateResponse
                };
            }
        }
    } else {
        errorMsg = 'Order not found in Business Manager.';
        res = {
            success: false,
            message: errorMsg
        };
    }
    r.renderJSON(res);
}


/**
 * Resolve an address against Avalara's address-validation system
 * @param {string} address dw.order address object
 * @returns {*} A response object that contains information about the validated address
 */
function validateShippingAddress(address) {
    try {
        var svcResponse = null;
        // build an addressvalidationinfo object
        var validateAddress = new AddressValidationInfo();
        validateAddress.textCase = 'Mixed';
        validateAddress.line1 = address.address1 || '';
        validateAddress.line2 = address.address2 || '';
        //validateAddress.line3 = address.address3 || '';
        validateAddress.city = address.city || '';
        validateAddress.region = address.stateCode || '';
        validateAddress.postalCode = address.postalCode || '';
        if (!empty(address.countryCode.value)) {
            validateAddress.country = address.countryCode.value || 'us';
        } else {
            validateAddress.country = address.countryCode || 'us';
        }
        // Make sure an address was provided
        if (empty(validateAddress)) {
            LOGGER.warn('AvaTax | No address provided. File - AVSettings.js');
            return {
                message: 'No address provided.'
            };;
        }
        var country = !empty(validateAddress.country) ? validateAddress.country : '';
        // countries for address validation - to be changed for Global implementation
        var countries = ['us', 'usa', 'canada'];
        if (countries.indexOf(country.toString().toLowerCase()) === -1) {
            LOGGER.warn('AvaTax | Can not validate address for this country {0}. File - AVSettings.js', country);
            return {
                message: 'The Avalara address validation service is only available in the United States and Canada.'
            };;
        }
        // Service call
        svcResponse = avaTaxClient.resolveAddressPost(validateAddress);
        return svcResponse;
    } catch (e) {
        LOGGER.warn('AvaTax | AvaTax Can not validate address at the moment. AVSettings.js~validateShippingAddress | '+e.message);
        return {
            statusCode: 'validateShippingAddressMethodFailed',
            message: e.message,
            error: true
        };
    }
}

/**
 * Marks a transaction by changing its status to 'Committed'.
 * @param {string} orderNo - DW order number of the transaction to be committed
 * @returns {*} A response object that contains information about the committed transaction
 */
function commitDocument(orderNo) {
    var message = '';

    try {
        
        var companyCode = settingsObject.configs.companyCode || 'DEFAULT';
        var transactionCode = orderNo;
        var commitTransactionModel = new CommitTransactionModel.CommitTransactionModel();
        var documentType = 'SalesInvoice';
        commitTransactionModel.commit = true;
        var svcResponse = avaTaxClient.commitTransaction(companyCode, transactionCode, commitTransactionModel, documentType);
        // ----------------- Logentries - START -------------------- //
        if (!empty(svcResponse.statusCode) && svcResponse.statusCode !== 'OK') {
            message = 'AvaTax commit document failed. Service configuration issue.';
        }
        if (svcResponse.error || svcResponse.message || svcResponse.errorMessage) {
            if (svcResponse.errorMessage) {
                message = svcResponse.errorMessage.error.message;
            }
            if (svcResponse.message) {
                message = svcResponse.message;
            }
            if (svcResponse.error) {
                message = svcResponse.message;
            }
        }
        return svcResponse;

        
        
    } catch (e) {
        LOGGER.warn('[AvaTax | Commit document failed with error - {0}. File - AvaTax.js~commitDocument]', e.message);
        return {
            error: true,
            message: 'Document commit failed'
        };
    }
}

/**
 * Voids the document.
 * @param {string} orderNo - DW order number
 * @returns {*} A response object that contains information about the voided transaction
 */
function voidDocument(orderNo) {
    var message = '';
    try {
        var companyCode = settingsObject.configs.companyCode || 'DEFAULT';
        var transactionCode = orderNo;
        var voidTransactionModel = new VoidTransactionModel.VoidTransactionModel();
        voidTransactionModel.code = voidTransactionModel.code.C_DOCVOIDED;

        var svcResponse = avaTaxClient.voidTransaction(companyCode, transactionCode, voidTransactionModel);
        // ----------------- Logentries - START --------------------
        if (!empty(svcResponse.statusCode) && svcResponse.statusCode !== 'OK') {
            message = 'AvaTax void document failed. Service configuration issue.';
        }
        if (svcResponse.error || svcResponse.message || svcResponse.errorMessage) {
            if (svcResponse.errorMessage) {
                message = svcResponse.errorMessage.error.message;
            }
            if (svcResponse.message) {
                message = svcResponse.message;
            }
            if (svcResponse.error) {
                message = svcResponse.message;
            }
        }
        return svcResponse;
    } catch (e) {
        LOGGER.warn('[AvaTax | Void document failed with error - {0}. File - AvaTax.js~voidDocument]', e.message);
        return {
            error: true,
            message: 'Document void failed'
        };
    }
}


/**
 * Resolve an address against Avalara's address-validation system
 * @param {string} address dw.order address object
 * @returns {*} A response object that contains information about the validated address
 */
 function validateShipfromAddress() {
    try {
        var svcResponse = null;
        var res = null;
        // build an addressvalidationinfo object
        var validateAddress = new AddressValidationInfo();
        validateAddress.textCase = 'Mixed';
        validateAddress.line1 = params.line1.stringValue || '';
        validateAddress.line2 = params.line2.stringValue || '';
        validateAddress.line3 = params.line3.stringValue || '';
        validateAddress.city = params.city.stringValue || '';
        validateAddress.region = params.state.stringValue || '';
        validateAddress.postalCode = params.zipCode.stringValue || '';
        validateAddress.country = params.countryCode.stringValue || 'USA';
        
        // Make sure an address was provided
        if (empty(validateAddress)) {
            LOGGER.warn('AvaTax | No address provided. File - AVSettings.js');
            return;
        }

        
        var country = !empty(validateAddress.country) ? validateAddress.country : '';
        // countries for address validation - to be changed for Global implementation
        var countries = ['us', 'usa', 'canada'];
        if (countries.indexOf(country.toString().toLowerCase()) === -1) {
            LOGGER.warn('AvaTax | Can not validate address for this country {0}. File - AVSettings.js', country);
            return;
        }
       
        // Service call
        svcResponse = avaTaxClient.resolveAddressPost(validateAddress);
        
        if (svcResponse.messages && svcResponse.messages.length > 0) {
            res = {
                success: false,
                message: svcResponse.messages[0].summary.toString()
            };
        } else {
            res = {
                success: true,
                validateAddress: svcResponse.validatedAddresses[0]
            };
        }
        r.renderJSON(res);

    } catch (e) {
        LOGGER.warn('AvaTax | AvaTax Can not validate address at the moment. AVSettings.js~validateShipfromAddress | '+ e.message);
        return {
            statusCode: 'validateShipfromAddressMethodFailed',
            message: e.message,
            error: true
        };
    }
}


function findConfig() {        
    var isConfigId = null;  
    var isSectionId = null;
    var svcResponse1 = null;
    var svcResponse2 = null;
    var message = '';
    var res = null;
    var legacySettingsObject = null;

    try {
        const atSettings = dw.system.Site.getCurrent().getCustomPreferenceValue('ATSettings');
        if (atSettings) {
            legacySettingsObject = JSON.parse(atSettings);
        }

        isConfigId = avaTaxClient.getConfigId(siteid);
        isSectionId = avaTaxClient.getConfigSectionId(siteid);

        var configMissing = isCcsResourceNotFound(isConfigId);
        var sectionMissing = isCcsResourceNotFound(isSectionId);

        if (configMissing || sectionMissing) {
            var configExists = !configMissing;
            var companyCode = resolveCompanyCodeForConfig(isConfigId);
            var cmodel = configSettingsModel.configIdModel(siteid, companyCode);
            var migrateFromAtSettings = legacySettingsObject && empty(settingsObject.lastsync) && settingsObject.migrateflag == true;
            var secmodel = buildSectionModel(null, legacySettingsObject);

            if (configMissing) {
                svcResponse1 = avaTaxClient.postConfigId(siteid, cmodel);
            } else {
                svcResponse1 = avaTaxClient.updateConfigId(siteid, cmodel);
                if (sectionMissing) {
                    LOGGER.warn(
                        'CCS section missing for connector version ' + configSettingsModel.semanticVersion +
                        '. Recreating section for site ' + siteid
                    );
                }
            }

            if (sectionMissing) {
                svcResponse2 = recreateConfigSection(siteid, secmodel);
            }

            if (!empty(svcResponse1) && !empty(svcResponse1.statusCode) && svcResponse1.statusCode !== 'OK') {
                message = getServiceErrorMessage(svcResponse1, message);
                LOGGER.warn('There was a problem saving the configuration settings. Details - ' + JSON.stringify(message));

                return false;
            }
            if (!empty(svcResponse2) && !empty(svcResponse2.statusCode) && svcResponse2.statusCode !== 'OK') {
                message = getServiceErrorMessage(svcResponse2, message);
                LOGGER.warn('There was a problem posting the configuration section. Details - ' + JSON.stringify(message));

                return false;
            }

            persistSettingsAfterSectionChange(companyCode, secmodel, migrateFromAtSettings, legacySettingsObject);

            return true;
        }
        else if (isConfigId.statusCode ==="ERROR" || isSectionId.statusCode === "ERROR"){
            message = isConfigId.errorMessage ? isConfigId.errorMessage : isSectionId.errorMessage;
            LOGGER.warn('There was a problem fetching the configuration settings. To verify Avalara credentials, go to Administration >  Operations >  Services. Details - '+JSON.stringify(message));
            return false;
        }
        else{
            var companyCodeMismatch = isConfigId.avaTaxCompany.toLowerCase() !== isSectionId.config.configurations.company_code.toLowerCase();
            var currentSemanticVersion = configSettingsModel.semanticVersion;
            var versionNeedsUpdate = isConfigId.semanticVersion && isConfigId.semanticVersion !== currentSemanticVersion;

            if(companyCodeMismatch || versionNeedsUpdate){
                var companyCode = isSectionId.config.configurations.company_code;
                var cmodel = configSettingsModel.configIdModel(siteid, companyCode);

                if(versionNeedsUpdate){
                    LOGGER.warn('AvaTax package version upgrade detected. Previous version: ' + isConfigId.semanticVersion + '. Updating to: ' + currentSemanticVersion);
                    var versionSectionModel = buildSectionModel(null, legacySettingsObject);
                    svcResponse2 = recreateConfigSection(siteid, versionSectionModel);
                    if (!empty(svcResponse2) && !empty(svcResponse2.statusCode) && svcResponse2.statusCode !== 'OK') {
                        LOGGER.warn('There was a problem recreating the configuration section for the new connector version. Status - ' + (svcResponse2 ? svcResponse2.statusCode : 'unknown') + '. Error - ' + getServiceErrorMessage(svcResponse2));
                        return false;
                    }
                    persistSettingsAfterSectionChange(companyCode, versionSectionModel, false, legacySettingsObject);
                }

                svcResponse1 = avaTaxClient.updateConfigId(siteid, cmodel);
                if(svcResponse1 !== null && svcResponse1.statusCode === 'ERROR'){   
                    LOGGER.warn('There was a problem updating the Config ID settings. Status - ' + (svcResponse1 ? svcResponse1.statusCode : 'unknown') + '. Error - ' + getServiceErrorMessage(svcResponse1));
                } else if(versionNeedsUpdate) {
                    LOGGER.warn('Config ID version updated successfully to: ' + currentSemanticVersion);
                }
            }
            message = 'Connected successfully.',
            LOGGER.warn('Connected successfully. Config ID already present.');
            return true;
        }
    } catch (error) {
        LOGGER.warn('There was a problem fetching the configuration settings.  Details - ' + error.message);
        return false;
    }
    return res;
}

// Module exports
exports.Start = guard.ensure(['https'], start);
exports.Void = guard.ensure(['https', 'csrf'], voidTransaction);
exports.Commit = guard.ensure(['https', 'csrf'], commitTransaction);
exports.Validate = guard.ensure(['https'], validateAddress); 
exports.GetSubscriptions = guard.ensure(['https', 'csrf'], getSubscriptions);
exports.ValidateShipfromAddress = guard.ensure(['https', 'post'], validateShipfromAddress);
exports.GetCompanies = guard.ensure(['https', 'get'], getCompanies);
exports.SettingsHelper = guard.ensure(['https', 'csrf'], settingsHelper);
exports.Sync = guard.ensure(['https', 'csrf'], syncSettingsData);
exports.FindConfig = guard.ensure(['https', 'csrf'], findConfig);
exports.VerifyCompanyCode = guard.ensure(['https'], verifyCompanyCode); 