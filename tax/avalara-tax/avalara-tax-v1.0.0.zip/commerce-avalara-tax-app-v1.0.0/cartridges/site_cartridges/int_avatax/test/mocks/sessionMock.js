'use strict';

module.exports = {
    create: function () {
        return {
            custom: {}
        };
    }
};
