'use strict';

var sinon = require('sinon');

module.exports = {
    getLogger: sinon.stub().returns({
        warn: sinon.stub(),
        error: sinon.stub(),
        info: sinon.stub(),
        debug: sinon.stub()
    })
};
