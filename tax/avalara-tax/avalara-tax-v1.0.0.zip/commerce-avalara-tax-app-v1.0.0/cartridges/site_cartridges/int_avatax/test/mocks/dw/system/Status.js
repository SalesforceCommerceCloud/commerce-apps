'use strict';

function Status(status, code, message) {
    this.status = status;
    this.code = code || null;
    this.message = message || null;
}

Status.OK = 0;
Status.ERROR = 1;

module.exports = Status;
