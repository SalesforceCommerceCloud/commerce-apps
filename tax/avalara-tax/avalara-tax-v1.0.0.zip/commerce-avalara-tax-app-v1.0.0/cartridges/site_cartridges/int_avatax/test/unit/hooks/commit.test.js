'use strict';

var assert = require('chai').assert;
var sinon = require('sinon');
var proxyquire = require('proxyquire').noCallThru();

var Status = require('../../mocks/dw/system/Status');

describe('commit hook', function () {
    var commitHook;
    var avataxHelperStub;
    var loggerStub;

    beforeEach(function () {
        loggerStub = {
            warn: sinon.stub(),
            error: sinon.stub(),
            info: sinon.stub()
        };

        avataxHelperStub = {
            getConfig: sinon.stub(),
            commitTransaction: sinon.stub()
        };

        commitHook = proxyquire(
            '../../../cartridge/scripts/hooks/commit',
            {
                'dw/system/Logger': {
                    getLogger: sinon.stub().returns(loggerStub)
                },
                'dw/system/Status': Status,
                '~/cartridge/scripts/helpers/avataxHelper': avataxHelperStub
            }
        );
    });

    afterEach(function () {
        sinon.restore();
    });

    function createMockOrder(orderNo) {
        return {
            getOrderNo: sinon.stub().returns(orderNo || 'ORDER-001')
        };
    }

    // =============================================
    // Test: AvaTax disabled
    // =============================================
    describe('when AvaTax is disabled', function () {
        it('should return Status.ERROR with AVATAX_DISABLED code', function () {
            avataxHelperStub.getConfig.returns({ enabled: false });
            var order = createMockOrder();

            var result = commitHook.commit(order);

            assert.equal(result.status, Status.ERROR);
            assert.equal(result.code, 'AVATAX_DISABLED');
            assert.isTrue(avataxHelperStub.commitTransaction.notCalled);
        });
    });

    // =============================================
    // Test: Successful commit
    // =============================================
    describe('when commit succeeds', function () {
        it('should call commitTransaction with the order number', function () {
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.returns({ success: true });
            var order = createMockOrder('ORD-12345');

            commitHook.commit(order);

            assert.isTrue(avataxHelperStub.commitTransaction.calledOnce);
            assert.isTrue(avataxHelperStub.commitTransaction.calledWith('ORD-12345'));
        });

        it('should return TAX_COMMITTED with order number in message', function () {
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.returns({ success: true });
            var order = createMockOrder('ORD-12345');

            var result = commitHook.commit(order);

            assert.equal(result.status, Status.OK);
            assert.equal(result.code, 'TAX_COMMITTED');
            assert.include(result.message, 'ORD-12345');
        });
    });

    // =============================================
    // Test: API failure
    // =============================================
    describe('when commit API call fails', function () {
        it('should return Status.ERROR with TAX_COMMIT_FAILED code', function () {
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.returns({
                success: false,
                error: 'Transaction not found'
            });
            var order = createMockOrder('ORD-99999');

            var result = commitHook.commit(order);

            assert.equal(result.status, Status.ERROR);
            assert.equal(result.code, 'TAX_COMMIT_FAILED');
        });

        it('should include the error and order number in status message', function () {
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.returns({
                success: false,
                error: 'Service timeout'
            });
            var order = createMockOrder('ORD-FAIL');

            var result = commitHook.commit(order);

            assert.include(result.message, 'Service timeout');
            assert.include(result.message, 'ORD-FAIL');
        });

        it('should log the error', function () {
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.returns({
                success: false,
                error: 'Connection refused'
            });
            var order = createMockOrder('ORD-001');

            commitHook.commit(order);

            assert.isTrue(loggerStub.error.calledOnce);
            var logMessage = loggerStub.error.firstCall.args[0];
            assert.include(logMessage, 'ORD-001');
            assert.include(logMessage, 'Connection refused');
        });
    });

    // =============================================
    // Test: Exception during commit
    // =============================================
    describe('when an exception is thrown', function () {
        it('should return Status.ERROR with TAX_COMMIT_EXCEPTION code', function () {
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.throws(new Error('Unexpected error'));
            var order = createMockOrder('ORD-ERR');

            var result = commitHook.commit(order);

            assert.equal(result.status, Status.ERROR);
            assert.equal(result.code, 'TAX_COMMIT_EXCEPTION');
            assert.include(result.message, 'Unexpected error');
            assert.include(result.message, 'ORD-ERR');
        });

        it('should log the exception with order number and stack', function () {
            var err = new Error('Null pointer');
            err.stack = 'Error: Null pointer\n    at commit.js:24';
            avataxHelperStub.getConfig.returns({ enabled: true });
            avataxHelperStub.commitTransaction.throws(err);
            var order = createMockOrder('ORD-EX');

            commitHook.commit(order);

            assert.isTrue(loggerStub.error.calledOnce);
            var logMessage = loggerStub.error.firstCall.args[0];
            assert.include(logMessage, 'ORD-EX');
            assert.include(logMessage, 'Null pointer');
        });
    });
});
