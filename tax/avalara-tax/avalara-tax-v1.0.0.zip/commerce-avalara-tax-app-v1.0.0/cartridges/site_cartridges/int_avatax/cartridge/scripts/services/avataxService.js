'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');

var CONNECTOR_NAME = 'AvaTax for B2C Storefront Next';
var CONNECTOR_VERSION = '1.0.0';
var VERSION_ID = 'a0oUz00000CKG9lIAH';
var REST_SERVICE_ID = 'avatax.rest.all';

/**
 * Creates and returns the AvaTax REST service instance.
 * Service ID "avatax.rest.all" must be configured in BM > Administration > Operations > Services.
 *
 * @returns {dw.svc.HTTPService} The service instance
 */
function getService() {
    return LocalServiceRegistry.createService(REST_SERVICE_ID, {
        createRequest: function (svc, args) {
            svc.addHeader('Accept', 'application/json');
            svc.addHeader('Content-Type', 'application/json');
            // (app name); (app version); (library id)
            var clientHeaderStr = 'SF B2C/Storefront Next || 1.0.0v2; ' + VERSION_ID;
            svc.addHeader('X-Avalara-Client', clientHeaderStr);

            var credential = svc.getConfiguration().getCredential();
            var user = credential.getUser();
            var password = credential.getPassword();
            var encodedAuth = require('dw/util/StringUtils').encodeBase64(user + ':' + password);
            svc.addHeader('Authorization', 'Basic ' + encodedAuth);

            svc.setRequestMethod(args.method);
            var baseUrl = credential.getURL().replace(/\/+$/, '');
            svc.setURL(baseUrl + args.endpoint);

            if (args.body) {
                return JSON.stringify(args.body);
            }
            return null;
        },
        parseResponse: function (svc, client) {
            return client.text;
        }
    });
}

/**
 * Makes an authenticated HTTP request to the AvaTax REST API via the SFCC service framework.
 *
 * @param {string} method - HTTP method (POST, GET, etc.)
 * @param {string} endpoint - API endpoint path (e.g. /api/v2/transactions/create)
 * @param {Object|null} body - Request body to send as JSON, or null
 * @returns {Object} Response object with {success: boolean, data: Object, error: String}
 */
function call(method, endpoint, body) {
    try {
        var svc = getService();
        var result = svc.call({
            method: method,
            endpoint: endpoint,
            body: body
        });

        if (result.status === 'OK') {
            return {
                success: true,
                data: JSON.parse(result.object)
            };
        }

        var errorText = result.errorMessage || result.msg || 'Unknown error';
        var errorDetails = {};
        try {
            errorDetails = JSON.parse(errorText);
        } catch (e) {
            // errorText is not JSON
        }

        return {
            success: false,
            error: 'AvaTax API error: ' + result.status,
            details: errorDetails
        };
    } catch (e) {
        var errorMessage = 'Unknown error';
        if (e && (e.message || e.errorMessage)) {
            errorMessage = e.message || e.errorMessage;
        }
        return {
            success: false,
            error: errorMessage
        };
    }
}

// ---------------------------------------------------------------------------
// Storefront API methods
// ---------------------------------------------------------------------------

/**
 * Records a new transaction in AvaTax (tax calculation).
 *
 * @param {Object} createTransactionModel - CreateTransaction request payload
 * @param {string} [include] - Optional $include query parameter (e.g. 'Details')
 * @returns {Object} Response object with {success, data, error, details}
 */
function createTransaction(createTransactionModel, include) {
    var endpoint = '/api/v2/transactions/create';
    if (include) {
        endpoint += '?$include=' + encodeURIComponent(include);
    }
    return call('POST', endpoint, createTransactionModel);
}

/**
 * Marks a transaction as committed in AvaTax.
 *
 * @param {string} companyCode - AvaTax company code
 * @param {string} transactionCode - Transaction/order code
 * @param {Object} commitTransactionModel - Commit request payload (e.g. {commit: true})
 * @returns {Object} Response object with {success, data, error, details}
 */
function commitTransaction(companyCode, transactionCode, commitTransactionModel) {
    var endpoint = '/api/v2/companies/' + encodeURIComponent(companyCode) +
        '/transactions/' + encodeURIComponent(transactionCode) + '/commit';
    return call('POST', endpoint, commitTransactionModel);
}

/**
 * Voids a transaction in AvaTax.
 *
 * @param {string} companyCode - AvaTax company code
 * @param {string} transactionCode - Transaction/order code
 * @param {Object} voidTransactionModel - Void request payload (e.g. {code: 'DocVoided'})
 * @returns {Object} Response object with {success, data, error, details}
 */
function voidTransaction(companyCode, transactionCode, voidTransactionModel) {
    var endpoint = '/api/v2/companies/' + encodeURIComponent(companyCode) +
        '/transactions/' + encodeURIComponent(transactionCode) + '/void';
    return call('POST', endpoint, voidTransactionModel);
}

/**
 * Resolves/validates an address against Avalara's address validation system.
 *
 * @param {Object} addressValidationInfo - Address validation request payload
 * @returns {Object} Response object with {success, data, error, details}
 */
function resolveAddress(addressValidationInfo) {
    return call('POST', '/api/v2/addresses/resolve', addressValidationInfo);
}

/**
 * Tests connectivity and authentication with the AvaTax API.
 *
 * @returns {Object} Response object with {success, data, error, details}
 */
function ping() {
    return call('GET', '/api/v2/utilities/ping', null);
}

module.exports = {
    call: call,
    createTransaction: createTransaction,
    commitTransaction: commitTransaction,
    voidTransaction: voidTransaction,
    resolveAddress: resolveAddress,
    ping: ping,
    CONNECTOR_NAME: CONNECTOR_NAME,
    CONNECTOR_VERSION: CONNECTOR_VERSION
};
