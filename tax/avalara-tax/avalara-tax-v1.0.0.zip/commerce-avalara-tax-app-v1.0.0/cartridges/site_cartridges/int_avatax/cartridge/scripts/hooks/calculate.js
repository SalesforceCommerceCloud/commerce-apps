'use strict';

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');
var avataxHelper = require('~/cartridge/scripts/helpers/avataxHelper');

var logger = Logger.getLogger('AvaTax', 'calculate');
/**
 * Calculate taxes using the AvaTax API.
 *
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order to calculate taxes for
 * @returns {dw.system.Status} Status indicating success or failure
 */
exports.calculate = function(lineItemCtnr) {
    if (!avataxHelper.getConfig().enabled) {
        logger.warn('AvaTax not enabled for this site');
        return new Status(Status.ERROR, 'AVATAX_DISABLED', 'AvaTax not enabled for this site.');
    }

    if (!lineItemCtnr) {
        logger.warn('Empty basket passed to tax calculation');
        return new Status(Status.ERROR, 'EMPTY_BASKET', 'No basket provided for tax calculation.');
    }

    try {
        var buildResult = avataxHelper.buildTransactionModel(lineItemCtnr);
        var transactionModel = buildResult.model;
        var lineUUIDMap = buildResult.lineUUIDMap;

        if (!transactionModel.lines || transactionModel.lines.length === 0) {
            logger.warn('No taxable line items found in basket');
            return new Status(Status.OK, 'NO_TAXABLE_ITEMS', 'No taxable line items found in basket.');
        }

        var response = avataxHelper.callAvaTaxAPI(transactionModel);

        if (!response.success) {
            logger.error('AvaTax API call failed: ' + JSON.stringify(response.details));

            // Fall back to zero tax on error
            setZeroTax(lineItemCtnr);

            return new Status(Status.OK, 'TAX_API_ERROR', 'AvaTax API call failed. Tax set to zero. Error: ' + JSON.stringify(response.details));
        }

        if (response.deduplicated) {
            return new Status(Status.OK, 'DEDUPLICATED', 'Tax calculation skipped — basket unchanged since last call.');
        }

        avataxHelper.applyTaxesToBasket(lineItemCtnr, response.data, lineUUIDMap);

        return new Status(Status.OK, 'TAX_CALCULATED', 'Tax successfully calculated and applied.');
    } catch (e) {
        logger.error('Error during tax calculation: ' + e.message + '\n' + e.stack);

        // Fall back to zero tax on exception
        setZeroTax(lineItemCtnr);

        return new Status(Status.ERROR, 'TAX_CALCULATION_EXCEPTION', 'Tax calculation failed with exception. Tax set to zero. Error: ' + e.message);
    }
};

/**
 * Sets all line items to zero tax (fallback for errors)
 * @param {dw.order.LineItemCtnr} lineItemCtnr - The basket or order
 */
function setZeroTax(lineItemCtnr) {
    var Money = require('dw/value/Money');
    var zeroTax = new Money(0, lineItemCtnr.getCurrencyCode());

    var lineItems = lineItemCtnr.getAllLineItems().iterator();
    while (lineItems.hasNext()) {
        var lineItem = lineItems.next();
        try {
            lineItem.setTax(zeroTax);
            lineItem.updateTax(0);
        } catch (e) {
            // Some line items may not support tax (e.g., price adjustments)
        }
    }
}

