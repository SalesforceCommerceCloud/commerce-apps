# Avalara AvaTax for Salesforce B2C Commerce — Storefront Next

User Guide

Product Release: 1.0.2

---

## 1.0 Summary

The AvaTax Commerce App provides rapid integration for Salesforce B2C Commerce Storefront Next implementations. The package is self-contained and can be installed from the Commerce App Catalog. After installation, it can be configured in Business Manager and contains the elements needed for a best-practices implementation of AvaTax.

---

## 2.0 Component Overview

### 2.1 Functional Overview

1. AvaTax is an online sales tax compliance solution that provides jurisdiction assignment and real-time sales tax calculation. The service can manage situs, nexus, tax tiers, tax holidays, product taxability rules, and related tax issues.

2. During checkout, basket and customer information is transmitted via the AvaTax REST v2 API. Tax information is returned and applied to the basket.

3. Connector settings (tax calculation, save/commit behavior, company, customer code, ship-from address, and related options) are managed on the Avalara Portal and synced to the site `AVSettings` preference.

4. Detailed transaction logging is available in Business Manager logs (`custom-AvaTax`) and on the AvaTax dashboard.

### 2.2 Use Cases

This package calculates taxes on the Storefront Next storefront through the AvaTax REST v2 API.

Features included in this package:

1. Tax calculation
2. Cross-border, VAT, and invoice message storage
3. Line-level addressing
4. Enhanced VAT fields
5. Business Manager utilities (connect, sync, void, commit, validate address)
6. Order reconciliation
7. Scheduled settings sync and HS code classification
8. Business licenses / tax registrations

### 2.3 Limitations and Constraints

- AvaTax service messages are in English.
- Address validation from the Business Manager utilities is intended for US and Canada addresses.
- Customs duty and import tax apply when the site taxation policy is Net.

### 2.4 Compatibility

This release is built for Storefront Next (Commerce App tax domain) using the `int_avatax` site cartridge and the `bm_avatax` Business Manager cartridge.

### 2.5 Privacy and Payment

Customer addresses are sent to AvaTax for tax calculation. No customer payment information is accessed or stored.

---

## 3.0 Implementation Guide

### 3.1 Setup

Install the app from Business Manager. The installation subtasks are shown in the UI (see `app-configuration/tasksList.json`).

1. Go to **Commerce Apps > App Catalog** from the **Merchant Tools** page.
2. In the **Avalara AvaTax** tile, select **Install**.
3. Follow the prompts to complete the installation subtasks.

The prompts walk through importing custom site settings, adding `int_avatax` to the storefront cartridge path, adding `bm_avatax` to the Business Manager cartridge path, configuring AvaTax service credentials, and enabling Avalara Business Manager module access.

For a walkthrough of Avalara custom settings after install, open **Merchant Tools > Avalara > Avalara Help**. That page links to Avalara Help Center articles for connecting Salesforce B2C Commerce to Avalara and configuring the integration.

### 3.2 Configuration

#### 3.2.1 Configure Avalara Services

Service definitions are imported as part of the installation subtasks. Confirm the following in **Administration > Operations > Services**:

| Type | ID |
|---|---|
| Service | `avatax.rest.all` |
| Service | `ceplogger.avatax.svc` |
| Service | `config.avatax.svc` |
| Credential | `credentials.avatax.rest` |
| Credential | `logentries.avatax.rest` |
| Profile | `profile.avatax.rest` |
| Profile | `logentries.avatax.profile` |

Configure credentials as follows, depending on whether the instance is development or production:

**`credentials.avatax.rest`**

- Development: `https://sandbox-rest.avatax.com`
- Production: `https://rest.avatax.com`

**`logentries.avatax.rest`**

- Development: `https://ceplogger.sbx.avalara.com/api/logger/`
- Production: `https://ceplogger.avalara.com/api/logger/`

Notes:

- Do not remove `ceplogger.avatax.svc`, `avatax.rest.all`, or `config.avatax.svc`, or rename any of these services.
- Enable **Communication Log Enabled** on `ceplogger.avatax.svc` and `avatax.rest.all` if you need service communication logs.

#### 3.2.2 Avalara Settings Configuration

Configure Avalara-related settings using the Avalara module in Business Manager.

1. Log in to Business Manager.
2. Select the desired site from the dropdown.
3. Navigate to **Merchant Tools > Avalara > Avalara settings**.

**Account settings**

- **Connect to Sandbox / Connect to Production** — verifies the connection to Avalara using the service credentials from section 3.2.1. After a successful connection, a site-specific configuration page is created (or migrated) on the Avalara Portal. Use the **in Avalara** hyperlink in the success message to open that page.
- **Sync** — after you change values on the Avalara Portal, Sync fetches those settings into the site `AVSettings` preference. Run Connect at least once for the site before using Sync. The **Last synced on** field shows the last successful sync.
- **Mapped fields reporting tool** — opens the tax calculation field mappings page (`avataxObjectMapping.html`). Mapping changes are made in `cartridges/site_cartridges/int_avatax/cartridge/scripts/helpers/calculateTaxHelper.js`. See section 4.4.

**Customs duty & import tax**

- **Taxation policy** (read-only) — derived from the current site settings. Customs duty and import tax apply when the policy is Net.

Connector settings on the Avalara Portal configuration page (synced into `AVSettings`):

- **Calculate tax** — enables AvaTax tax calculation for the current site.
- **Validate addresses with Avalara** — stored with the connector settings. Address validation from this package is available as a Business Manager utility (see section 3.4). AvaTax validates addresses in the United States and Canada.
- **Save transactions to Avalara** — when enabled, placed orders are saved to AvaTax as SalesInvoice documents. When disabled, tax estimates still appear on the storefront, but orders are not saved to AvaTax.
- **Post transactions as Committed** — when enabled, successful orders are marked Committed when posted to AvaTax.
- **Avalara company name / company code** — the AvaTax company used for transactions on this site. Importer of record and nexus settings for that company apply to the storefront.
- **Customer code** — value sent as the customer code for authenticated customers:
  - `customer_number` — profile customer number
  - `customer_email` — customer email
  - `custom_attribute` — a named profile attribute
  - Guest customers use the email entered during checkout, or `guest-cust-code` if no email is available
- **Shipping tax code** — used when a shipping method has no tax class. If not specified, AvaTax freight code `FR` is used.

**Address settings** (origin / ship-from)

These fields are the company location used as ship-from for tax calculation:

- Location code — if provided, AvaTax prefers it over the other address fields. Location code is configured as a company location in the Avalara account.
- Address line 1, line 2, line 3
- City
- State
- Zip / Postal code
- Country code — 2- or 3-character ISO country code

The Avalara Portal configuration page is site-specific. A different configuration is created for each site (for example `RefArch` and `RefArchGlobal`). The tile is identified as `StorefrontSiteID_NumericalID` (for example `RefArch_26330375`) under **Settings > Integrations** in the Avalara Portal.

**Notes**

- Navigate to **Merchant Tools > Site Preferences > Order > Order Access Settings** and set **Limit Storefront Order Access** to **No**.
- Select the required promotion preference under **Merchant Tools > Site Preferences > Promotion > Discount Taxation**.

---

### 3.3 Cross Border, VAT, and Invoice Messages

This section can be skipped if the storefront does not ship products from one country to another and does not need to store customs duty or cross-border details.

AvaTax returns taxes and invoice messages based on origin and destination locations in different countries. If customs duties apply, those values are stored in custom attributes.

#### Cross-border tax calculation

Product attributes for cross-border tax calculation are configured on the product in **Merchant Tools > Products and Catalogs > Products > {product}**, under the **Avalara | AvaTax** section. Values are mapped in `cartridges/site_cartridges/int_avatax/cartridge/scripts/helpers/calculateTaxHelper.js`.

| Attribute | Description |
|---|---|
| **hsCode** | HS code for the line. Priority: `lineLevelAddress.json` for the product ID, then `product.custom.ATAutomatedHSCode`, then `product.custom.ATHSCode`, then `product.custom.ATProductCategory`. |
| **IsPreferredProgram** | Maps from `product.custom.ATIsPreferredProgram`. |
| **CountryOfManufacture** | ISO country code where the product was manufactured. Maps from `product.custom.ATCountryOfManufacture`. |
| **NetWeight** | Maps from `product.custom.ATNetWeightValue` and `product.custom.ATNetWeightUOM`. |
| **Height** | Maps from `product.custom.ATHeightValue` and `product.custom.ATHeightUOM`. |
| **Width** | Maps from `product.custom.ATWidthValue` and `product.custom.ATWidthUOM`. |
| **Length** | Maps from `product.custom.ATLengthValue` and `product.custom.ATLengthUOM`. |
| **HS Code Classification Required?** | When enabled (`product.custom.ATEnableHSCodeAutomatedJob`), the product is included in the `Avalara-HSCode-Classification` job. |
| **Automated HS Code Classification** | Read-only HS code written by the classification job (`product.custom.ATAutomatedHSCode`). |

#### Values stored on basket and order

These custom attributes are written on the basket during checkout and on the order after placement:

| Value | Objects |
|---|---|
| Custom duty | `basket.custom.ATCustomsDuty`, `order.custom.ATCustomsDuty` |
| Taxes | `basket.custom.ATTax`, `order.custom.ATTax` |
| Cross-border messages | `basket.custom.ATLandedCost`, `order.custom.ATLandedCost` |
| Transaction summary | `basket.custom.ATGenericMessage`, `order.custom.ATGenericMessage` |
| Invoice messages | `basket.custom.ATInvoiceMessage`, `order.custom.ATInvoiceMessage` |
| Tax break-up (JSON) | `basket.custom.ATTaxDetail`, `order.custom.ATTaxDetail` |
| VAT code(s) | `basket.custom.ATVatCode`, `order.custom.ATVatCode` |

Invoice messages from the AvaTax response are stored as a concatenated string of message content. VAT codes are stored as `Line {lineNumber}: {vatCode};` entries.

#### Tax breakdown details

When taxes are calculated, per-jurisdiction details for each line item (product, shipping, gift certificate, and so on) are stored in `ATTaxDetail` as a JSON string.

Example:

```json
[
  {
    "lineitemid": "750518703299",
    "shipmentid": "me",
    "taxes": [
      {
        "jurisdictiontype": "State",
        "jurisdiction": "WASHINGTON",
        "exempt": 0,
        "nontaxable": 0,
        "taxable": 299.99,
        "rate": 0.065,
        "tax": 19.5,
        "taxName": "WA STATE TAX",
        "taxSubTypeId": "S",
        "taxType": "Sales"
      }
    ]
  }
]
```

| Attribute | Description |
|---|---|
| **lineitemid** | Line item object ID (for example product ID). |
| **shipmentid** | Shipment the line item belongs to. |
| **jurisdictiontype** | Tax jurisdiction type (Country, State, City, County, Special, and so on). |
| **jurisdiction** | Jurisdiction name (for example Washington, Ontario). |
| **taxName** | Short tax description. |
| **nontaxable** | Amount that is not taxable. |
| **exempt** | Amount that is tax-exempt. |
| **taxable** | Amount that is taxed. |
| **rate** | Tax rate used. |
| **tax** | Calculated tax amount. |

---

### 3.4 Utilities

Additional utilities are under **Merchant Tools > Avalara > Avalara settings > Utilities**:

1. **Void transaction** — voids/cancels an order previously posted to AvaTax. Enter the order number. The service response is shown in the text area.
2. **Commit transaction** — commits an order previously posted to AvaTax. Enter the order number. The service response is shown in the text area.
3. **Validate address** — validates the shipping address of an order and returns a validated address. Enter the order number.

Order cancellation on the storefront also voids the AvaTax transaction through the `sfcc.app.tax.cancel` hook. Order placement creates (and optionally commits) the SalesInvoice through the `sfcc.app.tax.commit` hook.

---

### 3.5 Jobs / Schedulers

After a successful metadata import, the following jobs are available under **Administration > Operations > Jobs**.

1. **Avalara-Settings-Sync**

   Recurring sync of Avalara Portal connector settings into `AVSettings`. The default interval is 1 hour for sites `RefArch` and `RefArchGlobal`. Change the schedule on **Schedule and History**, or change the site scope on **Job Steps > Scope**.

   Connect to Sandbox/Production must have been completed at least once for the site, or the job will not run successfully.

   On sandboxes, scheduled custom jobs are disabled by Salesforce platform restrictions. Manual **Run Now** is available. Scheduling is enabled on staging and production.

2. **Avalara-HSCode-Classification**

   Retrieves products with **HS Code Classification Required?** enabled and writes the HS code to **Automated HS Code Classification** (`ATAutomatedHSCode`). See section 3.3.

---

### 3.6 Line Level Addressing

A merchant seller identifier and a per-product ship-from address can be assigned so that different products in one transaction can have different origin addresses. Configure this in:

`cartridges/site_cartridges/int_avatax/cartridge/scripts/lineLevelAddress.json`

| Attribute | Description |
|---|---|
| **productID** | Product ID key in `lladdresses`. |
| **merchantId** | Merchant seller identifier for the product (`merchantSellerIdentifier` on the AvaTax line). |
| **transport** | Transport parameter for the product line. Accepted values: `Seller`, `Buyer`, `ThirdPartyforSeller`, `ThirdPartyforBuyer`, `None`. |
| **hsCode** | HS code for the product ID. |
| **shipfrom** | Ship-from address (`line1`, `line2`, `line3`, `city`, `region`, `postalCode`, `countryCode`). |

If a product has no ship-from address in this file, the origin (corporate) address from the Avalara configuration is used.

HS code priority during tax calculation:

1. `lineLevelAddress.json` `hsCode` for the product ID
2. `product.custom.ATAutomatedHSCode`
3. `product.custom.ATHSCode`
4. `product.custom.ATProductCategory`

Merchant parameters associated with `merchantId` are loaded from `avaMerchantConf.json` (see section 3.7).

---

### 3.7 Enhanced VAT

The following fields are recorded on AvaTax transactions.

**Is Seller Importer Of Record**

After metadata import, `ATisSellerImporterOfRecord` is available on the customer profile under **Merchant Tools > Customers > Customers > {customer} > AvaTax**. The default is false. The value is sent on the transaction when that registered customer places an order. If the basket contains a line with an HS code and the profile flag is not set, the connector treats the seller as importer of record for that request.

**Business Identification Number**

`businessIdentificationNo` is taken from the customer profile **Tax ID** field and sent on the transaction and on line items.

**Merchant-related fields**

Merchant parameters are customized by `merchantSellerIdentifier` in:

`cartridges/site_cartridges/int_avatax/cartridge/scripts/avaMerchantConf.json`

| Attribute | Description |
|---|---|
| **merchantSellerIdentifier** | Key matching `merchantId` in `lineLevelAddress.json`. |
| **MerchantEstablishmentCountry** | Merchant establishment country. |
| **MerchantName** | Merchant name. |
| **MerchantVatId** | Merchant VAT ID. |

**Point of Order Origin Address**

`pointOfOrderOrigin` is sent at the product line level. Its value is the billing address entered during checkout.

**Transport**

Transport can be set at the product (line) level in `lineLevelAddress.json`. Accepted values: `Seller`, `Buyer`, `ThirdPartyforSeller`, `ThirdPartyforBuyer`, or `None`. An invalid or empty value should not be sent.

**Invoice messages and VAT code**

Invoice messages and VAT codes from the AvaTax response are stored on the basket/order as described in section 3.3, and are visible on the order in Business Manager under the Avalara attributes section.

**Tax included**

`taxIncluded` is derived from the site taxation policy and sent on every line:

- Gross site — `taxIncluded` is `true`
- Net site — `taxIncluded` is `false`

Taxation policy can be viewed under **Merchant Tools > Ordering > Taxation**, or as the read-only **Taxation policy** field on Avalara settings.

---

### 3.8 Business Licenses

To use the Business Licenses utility, navigate to **Merchant Tools > Avalara > Avalara settings > Tax registrations**.

- **Purchase registrations** opens the Avalara Online Buy flow to purchase registrations.
- **View registration status** opens the registrations dashboard in the Business License portal.

---

### 3.9 External Interfaces

All requests use the AvaTax REST v2 API:

https://developer.avalara.com/api-reference/avatax/rest/v2/

Commerce App tax hooks used by this package:

| Hook | Script | Purpose |
|---|---|---|
| `sfcc.app.tax.calculate` | `int_avatax/cartridge/scripts/hooks/calculate.js` | Real-time tax calculation |
| `sfcc.app.tax.commit` | `int_avatax/cartridge/scripts/hooks/commit.js` | Create/commit SalesInvoice on order placement |
| `sfcc.app.tax.cancel` | `int_avatax/cartridge/scripts/hooks/cancel.js` | Void transaction on order cancel |

---

### 3.10 Firewall Requirements

No firewall changes are required.

---

### 3.11 Testing

The `int_avatax` cartridge includes unit tests under `cartridges/site_cartridges/int_avatax/test/unit/`.

```bash
cd cartridges/site_cartridges/int_avatax
npm test
```

---

## 4.0 Operations, Maintenance

### 4.1 Data Storage

The custom attributes and `AVSettings` preference created during install are described in sections 3.2 and 3.3. For data stored by Avalara, see https://www.avalara.com/.

### 4.2 Availability

Cartridge functionality depends on the AvaTax API. Current status: https://status.avalara.com/

### 4.3 Support

For configuration or testing issues, contact Avalara customer support: https://www.avalara.com/us/en/about/support.html

In-product help articles are also listed under **Merchant Tools > Avalara > Avalara Help**.

### 4.4 Object Mapping

Line mappings for tax calculation are in one place:

`cartridges/site_cartridges/int_avatax/cartridge/scripts/helpers/calculateTaxHelper.js`

Modify the mapping there as required.

### 4.5 Object Mapping Documentation

1. Open `cartridges/bm_cartridges/bm_avatax/cartridge/static/default/avataxObjectMapping.html`.
2. Update the mapping reference in the HTML to match code changes.
3. To add a mapping, add a grid-table-row under the related table.

The same page is linked from Avalara settings as **Mapped fields reporting tool**.

---

## 5.0 FAQs

**How do I ensure accurate tax calculation?**

Configure tax codes, UPC codes, and discounts for products in Business Manager. AvaTax uses this information to calculate tax. Configure this in **Merchant Tools > Products and Catalogs > Products**, or through a product feed.

**When is tax calculated?**

Tax is calculated when Storefront Next / SCAPI invokes the `sfcc.app.tax.calculate` hook (typically when the basket is updated as a storefront basket during checkout). Additional calls occur when the basket changes — for example when products, discounts, addresses, or shipping methods change.

**How many calls are made to AvaTax?**

The number of calls depends on basket, address, and discount changes. A typical journey includes:

- SalesOrder document during checkout tax calculation
- SalesInvoice document on successful order placement (`sfcc.app.tax.commit`), committed if that setting is enabled

Request deduplication skips a new AvaTax call when the basket hash has not changed.

**How do I disable AvaTax on a site?**

Turn off **Calculate tax** on the Avalara Portal configuration page for the site, then Sync (or wait for `Avalara-Settings-Sync`).

**What happens when taxes cannot be calculated (for example, service unavailability)?**

Tax values are set to zero. The connector does not fall back to Salesforce B2C Commerce tax tables, so tax calculation remains AvaTax-owned for compliance.

**What happens when an order fails after taxes have been calculated?**

Basket-level calculations use a SalesOrder document and are not recorded as a committed invoice. A SalesInvoice is created only after successful order placement. If an order is cancelled, `sfcc.app.tax.cancel` voids the AvaTax transaction.

**Where can I find configuration help?**

**Merchant Tools > Avalara > Avalara Help** lists Avalara Help Center articles, including connecting Salesforce B2C Commerce to Avalara and configuring advanced settings.

---

## 6.0 Known Issues

No known existing issues. Report issues to Avalara support.

---

## 7.0 Release History

| Version | Changes |
|---|---|
| 1.0.2 | Storefront Next documentation and package version update. |
| 1.0.2 | Storefront Next Commerce App tax integration. Real-time tax calculation, commit/void hooks, cross-border and VAT attribute storage, line-level addressing, Enhanced VAT fields, Avalara Portal settings sync, HS code classification job, Business Manager utilities, order reconciliation, and Business Licenses. |
