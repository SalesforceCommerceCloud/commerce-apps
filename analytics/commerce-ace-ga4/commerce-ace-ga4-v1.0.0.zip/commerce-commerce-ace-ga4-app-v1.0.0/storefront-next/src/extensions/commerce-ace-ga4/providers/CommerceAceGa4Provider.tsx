import { useEffect, type ReactElement, type ReactNode } from 'react';
import { useLocation } from 'react-router';
import { useGa4 } from '../hooks/useGa4';

type Gtag = (...args: unknown[]) => void;

interface Ga4Window extends Window {
    gtag?: Gtag;
    dataLayer?: unknown[];
}

export interface CommerceAceGa4ProviderProps {
    children: ReactNode;
}

/**
 * Application-root provider for Commerce Ace GA4 Analytics.
 *
 * Loads the gtag.js library once, bootstraps the GA4 data layer, and fires a
 * `page_view` event on every SPA route change. Register in target-config.json
 * under `contextProviders` — do NOT wrap components inline.
 *
 * MUST be a default export for the extension system's dynamic imports.
 */
export default function CommerceAceGa4Provider({ children }: CommerceAceGa4ProviderProps): ReactElement {
    const { measurementId, isReady, trackEvent } = useGa4();
    const location = useLocation();

    // Bootstrap gtag.js exactly once when the tracker becomes ready.
    useEffect(() => {
        if (!isReady || typeof window === 'undefined') {
            return;
        }
        const win = window as Ga4Window;
        win.dataLayer = win.dataLayer || [];
        if (!win.gtag) {
            // gtag.js reads the raw `arguments` object off the dataLayer queue.
            // This mirrors Google's official bootstrap snippet exactly — pushing
            // a plain array instead can cause commands to silently not register.
            // eslint-disable-next-line prefer-rest-params
            const gtag: Gtag = function () { win.dataLayer!.push(arguments); };
            win.gtag = gtag;
            gtag('js', new Date());
            // SPA page views are dispatched manually below, so disable the automatic one.
            gtag('config', measurementId, { send_page_view: false });
        }
    }, [isReady, measurementId]);

    // Fire a page_view on every route change.
    useEffect(() => {
        if (!isReady) {
            return;
        }
        trackEvent('page_view', {
            page_path: `${location.pathname}${location.search}`,
            page_location: typeof window !== 'undefined' ? window.location.href : undefined,
        });
    }, [isReady, trackEvent, location.pathname, location.search]);

    return (
        <>
            {isReady && <script src={`https://www.googletagmanager.com/gtag/js?id=${measurementId}`} async />}
            {children}
        </>
    );
}
