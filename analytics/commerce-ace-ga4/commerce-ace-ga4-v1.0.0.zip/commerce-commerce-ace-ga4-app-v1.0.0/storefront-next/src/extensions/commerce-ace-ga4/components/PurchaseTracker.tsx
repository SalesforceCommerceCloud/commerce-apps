import { useEffect, useRef, type ReactElement, type ReactNode } from 'react';
import { useParams } from 'react-router';
import { useTranslation } from 'react-i18next';
import { useScapiFetcher } from '@/hooks/use-scapi-fetcher';
import { useScapiFetcherEffect } from '@/hooks/use-scapi-fetcher-effect';
import { useGa4 } from '../hooks/useGa4';

export interface PurchaseTrackerProps {
    /**
     * Optional content for this insertion target.
     */
    children?: ReactNode;
    /**
     * Optional className for styling.
     */
    className?: string;
}

/**
 * Fires a GA4 `purchase` event on the order confirmation page.
 *
 * Mounted at the `sfcc.orderConfirmation.shipping.tracking` insertion target.
 * The confirmation route exposes no order context, but the order number is in
 * the URL (`/order-confirmation/:orderNo`), so the placed order is fetched
 * client-side via SCAPI and the `purchase` event is sent exactly once.
 *
 * MUST be a default export for the extension system's dynamic imports.
 *
 * @param props - Tracker props
 * @returns React element
 */
export default function PurchaseTracker({
    children,
    className,
}: PurchaseTrackerProps): ReactElement {
    const { t } = useTranslation('extCommerceAceGa4');
    const { trackEvent, isReady } = useGa4();
    const { orderNo } = useParams();

    // The order isn't in context here, but its number is in the route params.
    const orderFetcher = useScapiFetcher('shopperOrders', 'getOrder', {
        params: { path: { orderNo: orderNo ?? '' } },
    });

    // Trigger the fetch once, when ready and an order number is present.
    const loadedRef = useRef<string | null>(null);
    useEffect(() => {
        if (!isReady || !orderNo || loadedRef.current === orderNo) {
            return;
        }
        loadedRef.current = orderNo;
        void orderFetcher.load();
    }, [isReady, orderNo, orderFetcher]);

    // Fire `purchase` exactly once per order when the fetch resolves.
    const firedRef = useRef<string | null>(null);
    useScapiFetcherEffect(orderFetcher, {
        onSuccess: (order) => {
            if (!order?.orderNo || firedRef.current === order.orderNo) {
                return;
            }
            firedRef.current = order.orderNo;
            trackEvent('purchase', {
                transaction_id: order.orderNo,
                currency: order.currency || 'USD',
                value: order.orderTotal ?? 0,
                tax: order.taxTotal ?? 0,
                shipping: order.shippingTotal ?? 0,
                items: (order.productItems ?? []).map((item) => ({
                    item_id: item.productId,
                    item_name: item.productName || item.itemText || item.productId,
                    price: item.basePrice ?? item.price ?? 0,
                    quantity: item.quantity ?? 1,
                })),
            });
        },
    });

    return (
        <div className={className} data-testid="commerce-ace-ga4-purchase-tracker">
            <span className="sr-only">{t('commerceAceGa4.purchase.label')}</span>
            {children}
        </div>
    );
}
