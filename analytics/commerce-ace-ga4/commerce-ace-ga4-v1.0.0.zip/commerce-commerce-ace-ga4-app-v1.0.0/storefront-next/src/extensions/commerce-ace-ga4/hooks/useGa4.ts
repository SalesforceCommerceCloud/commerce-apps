import { useCallback } from 'react';
import { useConfig } from '@salesforce/storefront-next-runtime/config';

export interface CommerceAceGa4Config {
    /**
     * Google Analytics 4 Measurement ID (format `G-XXXXXXXXXX`).
     */
    measurementId: string;
    /**
     * Master on/off switch for all tracking.
     */
    enabled: boolean;
}

export type AppConfig = {
    extension?: {
        commerceAceGa4?: Partial<CommerceAceGa4Config>;
    };
}

type Gtag = (...args: unknown[]) => void;

interface Ga4Window extends Window {
    gtag?: Gtag;
    dataLayer?: unknown[];
}

export interface UseGa4Result {
    /**
     * Resolved GA4 Measurement ID, or an empty string when unset.
     */
    measurementId: string;
    /**
     * Whether tracking is enabled via configuration.
     */
    enabled: boolean;
    /**
     * True only when tracking is enabled AND a Measurement ID is present.
     */
    isReady: boolean;
    /**
     * Send a GA4 event. No-op until the tracker is ready and gtag has loaded.
     */
    trackEvent: (eventName: string, params?: Record<string, unknown>) => void;
}

/**
 * Shared hook exposing GA4 configuration and a typed `trackEvent` helper.
 *
 * Reads the merchant configuration via `useConfig` and guards every send so
 * components can call `trackEvent` unconditionally without leaking events when
 * the integration is disabled or unconfigured.
 *
 * @returns GA4 readiness state and a `trackEvent` function
 */
export function useGa4(): UseGa4Result {
    const appConfig = useConfig<AppConfig>();
    const measurementId = appConfig.extension?.commerceAceGa4?.measurementId || '';
    const enabled = appConfig.extension?.commerceAceGa4?.enabled !== false;
    const dynamicGtag = typeof window !== 'undefined' && typeof (window as any).gtag === 'function';
    const isReady = (enabled && measurementId.length > 0) || dynamicGtag;

    const trackEvent = useCallback(
        (eventName: string, params: Record<string, unknown> = {}) => {
            if (!isReady || typeof window === 'undefined') {
                return;
            }
            const win = window as Ga4Window;
            win.gtag?.('event', eventName, params);
        },
        [isReady],
    );

    return { measurementId, enabled, isReady, trackEvent };
}
