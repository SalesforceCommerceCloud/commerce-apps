// Components (runtime values — default exports)
export { default as ProductViewTracker } from './components/ProductViewTracker';
export { default as CheckoutTracker } from './components/CheckoutTracker';
export { default as PurchaseTracker } from './components/PurchaseTracker';

// Provider (runtime value — default export)
export { default as CommerceAceGa4Provider } from './providers/CommerceAceGa4Provider';

// Hooks (runtime value)
export { useGa4 } from './hooks/useGa4';

// Types
export type { ProductViewTrackerProps } from './components/ProductViewTracker';
export type { CheckoutTrackerProps } from './components/CheckoutTracker';
export type { PurchaseTrackerProps } from './components/PurchaseTracker';
export type { CommerceAceGa4ProviderProps } from './providers/CommerceAceGa4Provider';
export type { AppConfig, CommerceAceGa4Config, UseGa4Result } from './hooks/useGa4';
