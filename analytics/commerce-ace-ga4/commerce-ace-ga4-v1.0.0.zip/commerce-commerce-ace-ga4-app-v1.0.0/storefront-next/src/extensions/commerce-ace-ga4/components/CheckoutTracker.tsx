import { useEffect, type ReactElement, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { useBasket } from '@/providers/basket';
import { useGa4 } from '../hooks/useGa4';

export interface CheckoutTrackerProps {
    /**
     * Default order-summary content for this wrapper target — rendered transparently.
     */
    children?: ReactNode;
    /**
     * Optional className for styling.
     */
    className?: string;
}

/**
 * Fires a GA4 `begin_checkout` event from the checkout order summary.
 *
 * Mounted at the `sfcc.checkout.orderSummary` wrapper target. The target injects
 * no props, so the current basket is read from the storefront's basket context
 * (`useBasket`). Renders the default order summary as children while emitting
 * analytics as a side effect.
 *
 * MUST be a default export for the extension system's dynamic imports.
 *
 * @param props - Tracker props
 * @returns React element
 */
export default function CheckoutTracker({
    children,
    className,
}: CheckoutTrackerProps): ReactElement {
    const { t } = useTranslation('extCommerceAceGa4');
    const { trackEvent, isReady } = useGa4();
    const basket = useBasket();

    const itemCount = basket?.productItems?.length ?? 0;

    useEffect(() => {
        if (!isReady || !basket || itemCount === 0) {
            return;
        }
        trackEvent('begin_checkout', {
            currency: basket.currency || 'USD',
            value: basket.orderTotal ?? basket.productSubTotal ?? 0,
            items: (basket.productItems ?? []).map((item) => ({
                item_id: item.productId,
                item_name: item.productName || item.itemText || item.productId,
                price: item.basePrice ?? item.price ?? 0,
                quantity: item.quantity ?? 1,
            })),
        });
        // Re-fire when the basket identity, line-item count, or total changes.
    }, [isReady, trackEvent, basket?.basketId, itemCount, basket?.currency, basket?.orderTotal]);

    return (
        <div className={className} data-testid="commerce-ace-ga4-checkout-tracker">
            <span className="sr-only">{t('commerceAceGa4.checkout.label')}</span>
            {children}
        </div>
    );
}
