import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import PurchaseTracker from '../components/PurchaseTracker';

// `orderData.value` lets each test stage the order the fetcher "resolves" with.
const { trackEvent, useParamsMock, orderData } = vi.hoisted(() => ({
    trackEvent: vi.fn(),
    useParamsMock: vi.fn(),
    orderData: { value: null as unknown },
}));

vi.mock('react-router', () => ({
    useParams: () => useParamsMock(),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { changeLanguage: () => Promise.resolve() },
    }),
}));

vi.mock('../hooks/useGa4', () => ({
    useGa4: () => ({ measurementId: 'G-TEST', enabled: true, isReady: true, trackEvent }),
}));

vi.mock('@/hooks/use-scapi-fetcher', () => ({
    useScapiFetcher: () => ({ load: vi.fn(() => Promise.resolve()) }),
}));

// Synchronously invoke onSuccess with the staged order, simulating a resolved fetch.
vi.mock('@/hooks/use-scapi-fetcher-effect', () => ({
    useScapiFetcherEffect: (_fetcher: unknown, opts: { onSuccess?: (order: unknown) => void }) => {
        if (orderData.value) {
            opts.onSuccess?.(orderData.value);
        }
    },
}));

describe('PurchaseTracker', () => {
    beforeEach(() => {
        trackEvent.mockClear();
        useParamsMock.mockReset();
        orderData.value = null;
    });

    it('renders the tracking marker', () => {
        useParamsMock.mockReturnValue({ orderNo: 'ORDER-1' });
        render(<PurchaseTracker />);
        expect(screen.getByTestId('commerce-ace-ga4-purchase-tracker')).toBeInTheDocument();
    });

    it('fires a purchase event when the order resolves', () => {
        useParamsMock.mockReturnValue({ orderNo: 'ORDER-1' });
        orderData.value = {
            orderNo: 'ORDER-1',
            currency: 'GBP',
            orderTotal: 99,
            taxTotal: 9,
            shippingTotal: 5,
            productItems: [
                { productId: 'p1', productName: 'Thing', basePrice: 50, quantity: 1 },
            ],
        };
        render(<PurchaseTracker />);
        expect(trackEvent).toHaveBeenCalledWith(
            'purchase',
            expect.objectContaining({
                transaction_id: 'ORDER-1',
                currency: 'GBP',
                value: 99,
                tax: 9,
                shipping: 5,
            })
        );
    });

    it('does not fire before the order resolves', () => {
        useParamsMock.mockReturnValue({ orderNo: 'ORDER-1' });
        orderData.value = null;
        render(<PurchaseTracker />);
        expect(trackEvent).not.toHaveBeenCalled();
    });
});
