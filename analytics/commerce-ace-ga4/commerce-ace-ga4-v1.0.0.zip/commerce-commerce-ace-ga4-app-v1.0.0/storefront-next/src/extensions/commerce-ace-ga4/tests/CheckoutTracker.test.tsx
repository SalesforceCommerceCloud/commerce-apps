import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import CheckoutTracker from '../components/CheckoutTracker';

const { trackEvent, useBasketMock } = vi.hoisted(() => ({
    trackEvent: vi.fn(),
    useBasketMock: vi.fn(),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { changeLanguage: () => Promise.resolve() },
    }),
}));

vi.mock('../hooks/useGa4', () => ({
    useGa4: () => ({ measurementId: 'G-TEST', enabled: true, isReady: true, trackEvent }),
}));

vi.mock('@/providers/basket', () => ({
    useBasket: () => useBasketMock(),
}));

describe('CheckoutTracker', () => {
    beforeEach(() => {
        trackEvent.mockClear();
        useBasketMock.mockReset();
    });

    it('renders the tracking marker', () => {
        useBasketMock.mockReturnValue(undefined);
        render(<CheckoutTracker />);
        expect(screen.getByTestId('commerce-ace-ga4-checkout-tracker')).toBeInTheDocument();
    });

    it('renders wrapped order summary content', () => {
        useBasketMock.mockReturnValue(undefined);
        render(
            <CheckoutTracker>
                <span>order summary</span>
            </CheckoutTracker>
        );
        expect(screen.getByText('order summary')).toBeInTheDocument();
    });

    it('fires a begin_checkout event from the basket context', () => {
        useBasketMock.mockReturnValue({
            basketId: 'b1',
            currency: 'EUR',
            orderTotal: 42,
            productItems: [
                { productId: 'p1', productName: 'Thing', basePrice: 21, quantity: 2 },
            ],
        });
        render(<CheckoutTracker />);
        expect(trackEvent).toHaveBeenCalledWith(
            'begin_checkout',
            expect.objectContaining({
                currency: 'EUR',
                value: 42,
                items: [expect.objectContaining({ item_id: 'p1', item_name: 'Thing', price: 21, quantity: 2 })],
            })
        );
    });

    it('does not fire with an empty basket', () => {
        useBasketMock.mockReturnValue(undefined);
        render(<CheckoutTracker />);
        expect(trackEvent).not.toHaveBeenCalled();
    });
});
