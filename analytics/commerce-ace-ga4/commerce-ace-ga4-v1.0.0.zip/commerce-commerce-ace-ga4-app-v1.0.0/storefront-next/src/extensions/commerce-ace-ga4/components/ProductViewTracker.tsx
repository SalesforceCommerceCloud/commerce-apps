import { useEffect, type ReactElement, type ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { useProduct } from '@/providers/product-context';
import { useGa4 } from '../hooks/useGa4';

export interface ProductViewTrackerProps {
    /**
     * Default content for this wrapper target — rendered transparently.
     */
    children?: ReactNode;
    /**
     * Optional className for styling.
     */
    className?: string;
}

/**
 * Fires a GA4 `view_item` event on the product detail page.
 *
 * Mounted at the `sfcc.pdp.after.addToCart` wrapper target. The target injects
 * no props, so the current product is read from the storefront's product
 * context (`useProduct`). Renders its children transparently while emitting
 * analytics as a side effect.
 *
 * MUST be a default export for the extension system's dynamic imports.
 *
 * @param props - Tracker props
 * @returns React element
 */
export default function ProductViewTracker({
    children,
    className,
}: ProductViewTrackerProps): ReactElement {
    const { t } = useTranslation('extCommerceAceGa4');
    const { trackEvent, isReady } = useGa4();
    const product = useProduct();

    useEffect(() => {
        if (!isReady || !product?.id) {
            return;
        }
        trackEvent('view_item', {
            currency: product.currency || 'USD',
            value: product.price ?? 0,
            items: [
                {
                    item_id: product.id,
                    item_name: product.name || product.id,
                    price: product.price ?? 0,
                },
            ],
        });
        // Fire once per product view; re-fires when the shopper navigates to a different product.
    }, [isReady, trackEvent, product?.id, product?.name, product?.price, product?.currency]);

    return (
        <div className={className} data-testid="commerce-ace-ga4-product-view-tracker">
            <span className="sr-only">{t('commerceAceGa4.productView.label')}</span>
            {children}
        </div>
    );
}
