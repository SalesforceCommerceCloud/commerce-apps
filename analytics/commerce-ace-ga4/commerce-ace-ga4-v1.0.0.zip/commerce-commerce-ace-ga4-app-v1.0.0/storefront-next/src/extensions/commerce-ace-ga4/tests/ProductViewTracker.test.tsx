import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import ProductViewTracker from '../components/ProductViewTracker';

// vi.mock is hoisted — declare shared mocks via vi.hoisted so they exist first.
const { trackEvent, useProductMock } = vi.hoisted(() => ({
    trackEvent: vi.fn(),
    useProductMock: vi.fn(),
}));

vi.mock('react-i18next', () => ({
    useTranslation: () => ({
        t: (key: string) => key,
        i18n: { changeLanguage: () => Promise.resolve() },
    }),
}));

vi.mock('../hooks/useGa4', () => ({
    useGa4: () => ({ measurementId: 'G-TEST', enabled: true, isReady: true, trackEvent }),
}));

vi.mock('@/providers/product-context', () => ({
    useProduct: () => useProductMock(),
}));

describe('ProductViewTracker', () => {
    beforeEach(() => {
        trackEvent.mockClear();
        useProductMock.mockReset();
    });

    it('renders the tracking marker', () => {
        useProductMock.mockReturnValue(null);
        render(<ProductViewTracker />);
        expect(screen.getByTestId('commerce-ace-ga4-product-view-tracker')).toBeInTheDocument();
    });

    it('renders wrapped children transparently', () => {
        useProductMock.mockReturnValue(null);
        render(
            <ProductViewTracker>
                <span>child content</span>
            </ProductViewTracker>
        );
        expect(screen.getByText('child content')).toBeInTheDocument();
    });

    it('fires a view_item event from the product context', () => {
        useProductMock.mockReturnValue({ id: 'abc', name: 'Widget', price: 10, currency: 'USD' });
        render(<ProductViewTracker />);
        expect(trackEvent).toHaveBeenCalledWith(
            'view_item',
            expect.objectContaining({
                currency: 'USD',
                value: 10,
                items: [expect.objectContaining({ item_id: 'abc', item_name: 'Widget', price: 10 })],
            })
        );
    });

    it('does not fire without a product', () => {
        useProductMock.mockReturnValue(null);
        render(<ProductViewTracker />);
        expect(trackEvent).not.toHaveBeenCalled();
    });
});
