import React from 'react';
import { render, screen } from '@testing-library/react';
import { describe, it, expect, beforeEach, vi } from 'vitest';
import CommerceAceGa4Provider from '../providers/CommerceAceGa4Provider';

const { trackEvent } = vi.hoisted(() => ({ trackEvent: vi.fn() }));

vi.mock('react-router', () => ({
    useLocation: () => ({ pathname: '/product/123', search: '?color=red' }),
}));

vi.mock('../hooks/useGa4', () => ({
    useGa4: () => ({ measurementId: 'G-TEST', enabled: true, isReady: true, trackEvent }),
}));

describe('CommerceAceGa4Provider', () => {
    beforeEach(() => {
        trackEvent.mockClear();
    });

    it('renders its children', () => {
        render(
            <CommerceAceGa4Provider>
                <span>app content</span>
            </CommerceAceGa4Provider>
        );
        expect(screen.getByText('app content')).toBeInTheDocument();
    });

    it('fires a page_view event for the current route', () => {
        render(
            <CommerceAceGa4Provider>
                <span>app content</span>
            </CommerceAceGa4Provider>
        );
        expect(trackEvent).toHaveBeenCalledWith(
            'page_view',
            expect.objectContaining({ page_path: '/product/123?color=red' })
        );
    });
});
