# Commerce Ace GA4 Analytics for Storefront

Connects Storefront Next to Google Analytics 4, streaming page-view, product-view, checkout, and purchase events to the merchant's GA4 property.

## Overview

This is a **UI-only** Storefront Next extension. It loads the Google Analytics 4 (gtag.js) library once at the application root and streams e-commerce events to a merchant-configured GA4 Measurement ID. No SFCC cartridges or backend services are required.

## Features

- **Automatic page-view tracking** — fires a GA4 `page_view` on every SPA route change (home, PLP, PDP, cart, checkout).
- **Product-view tracking** — fires a GA4 `view_item` event on the product detail page.
- **Checkout tracking** — fires a GA4 `begin_checkout` event from the checkout order summary.
- **Purchase tracking** — fires a GA4 `purchase` event on order confirmation.
- Fully internationalized (en-US, en-GB, it-IT).

## Prerequisites

- A Salesforce Commerce Cloud Storefront Next instance.
- A Google Analytics 4 property and its **Measurement ID** (format `G-XXXXXXXXXX`).

## Installation

1. Download the app from the Commerce App Registry.
2. Install the extension into your Storefront Next project.
3. Configure the GA4 Measurement ID (see Configuration).
4. Deploy and verify events in the GA4 DebugView.

## Configuration

This extension uses the standard Storefront Next configuration system. Set the following `PUBLIC__` environment variables (double underscores map to nested config paths):

```bash
PUBLIC__app__extension__commerceAceGa4__measurementId=G-XXXXXXXXXX
PUBLIC__app__extension__commerceAceGa4__enabled=true
```

| Key | Description | Default |
| :-- | :---------- | :------ |
| `measurementId` | Your GA4 Measurement ID (`G-XXXXXXXXXX`). Tracking is disabled until this is set. | `''` |
| `enabled` | Master on/off switch for all tracking. | `true` |

## Post-Installation Checklist

- [ ] Set the GA4 `measurementId`.
- [ ] Confirm `enabled` is `true`.
- [ ] Open GA4 **DebugView** and browse the storefront to confirm `page_view`, `view_item`, `begin_checkout`, and `purchase` events arrive.
- [ ] Verify the components render across the supported locales.

## Testing

```bash
# From the Storefront Next project root
npm test
```

## Support

For questions or issues:
- Documentation: https://commerceace.com/docs

## License

[Your license information]

## Changelog

### v1.0.0
- Initial release.
